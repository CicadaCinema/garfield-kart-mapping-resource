﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000AE RID: 174
public class CharacterList : MonoBehaviour
{
	// Token: 0x04000423 RID: 1059
	public List<E_UnlockableItemSate> States = new List<E_UnlockableItemSate>();
}

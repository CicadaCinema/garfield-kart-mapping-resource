﻿using System;
using UnityEngine;

// Token: 0x02000060 RID: 96
[AddComponentMenu("NGUI/Tween/Scale")]
public class TweenScale : UITweener
{
	// Token: 0x1700005D RID: 93
	// (get) Token: 0x0600027E RID: 638 RVA: 0x00003E8A File Offset: 0x0000208A
	public Transform cachedTransform
	{
		get
		{
			if (this.mTrans == null)
			{
				this.mTrans = base.transform;
			}
			return this.mTrans;
		}
	}

	// Token: 0x1700005E RID: 94
	// (get) Token: 0x0600027F RID: 639 RVA: 0x00003EAF File Offset: 0x000020AF
	// (set) Token: 0x06000280 RID: 640 RVA: 0x00003EBC File Offset: 0x000020BC
	public Vector3 scale
	{
		get
		{
			return this.cachedTransform.localScale;
		}
		set
		{
			this.cachedTransform.localScale = value;
		}
	}

	// Token: 0x06000281 RID: 641 RVA: 0x000186AC File Offset: 0x000168AC
	protected override void OnUpdate(float factor, bool isFinished)
	{
		this.cachedTransform.localScale = this.from * (1f - factor) + this.to * factor;
		if (this.updateTable)
		{
			if (this.mTable == null)
			{
				this.mTable = NGUITools.FindInParents<UITable>(base.gameObject);
				if (this.mTable == null)
				{
					this.updateTable = false;
					return;
				}
			}
			this.mTable.repositionNow = true;
		}
	}

	// Token: 0x06000282 RID: 642 RVA: 0x0001873C File Offset: 0x0001693C
	public static TweenScale Begin(GameObject go, float duration, Vector3 scale)
	{
		TweenScale tweenScale = UITweener.Begin<TweenScale>(go, duration);
		tweenScale.from = tweenScale.scale;
		tweenScale.to = scale;
		if (duration <= 0f)
		{
			tweenScale.Sample(1f, true);
			tweenScale.enabled = false;
		}
		return tweenScale;
	}

	// Token: 0x040001FB RID: 507
	public Vector3 from = Vector3.one;

	// Token: 0x040001FC RID: 508
	public Vector3 to = Vector3.one;

	// Token: 0x040001FD RID: 509
	public bool updateTable;

	// Token: 0x040001FE RID: 510
	private Transform mTrans;

	// Token: 0x040001FF RID: 511
	private UITable mTable;
}

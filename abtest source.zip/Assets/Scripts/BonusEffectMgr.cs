﻿using System;
using UnityEngine;

// Token: 0x020000CE RID: 206
public class BonusEffectMgr
{
	// Token: 0x0600055B RID: 1371 RVA: 0x0002B3FC File Offset: 0x000295FC
	public BonusEffectMgr(Kart _Target)
	{
		this.Target = _Target;
		for (int i = 0; i < 9; i++)
		{
			this.m_pEffect[i] = null;
		}
	}

	// Token: 0x170000EE RID: 238
	// (get) Token: 0x0600055C RID: 1372 RVA: 0x00005DB2 File Offset: 0x00003FB2
	// (set) Token: 0x0600055D RID: 1373 RVA: 0x00005DBA File Offset: 0x00003FBA
	public Kart Target
	{
		get
		{
			return this.m_pTarget;
		}
		set
		{
			this.m_pTarget = value;
		}
	}

	// Token: 0x0600055E RID: 1374 RVA: 0x0002B440 File Offset: 0x00029640
	public void Start()
	{
		GameObject gameObject = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("BonusEffect/BoostBonusEffect"));
		this.m_pEffect[0] = gameObject.GetComponent<BonusEffect>();
		gameObject = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("BonusEffect/UpsideDownBonusEffect"));
		this.m_pEffect[1] = gameObject.GetComponent<UpsideDownBonusEffect>();
		gameObject = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("BonusEffect/SpinBonusEffect"));
		this.m_pEffect[2] = gameObject.GetComponent<SpinBonusEffect>();
		gameObject = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("BonusEffect/JumpBonusEffect"));
		this.m_pEffect[8] = gameObject.GetComponent<JumpBonusEffect>();
		gameObject = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("BonusEffect/NapBonusEffect"));
		this.m_pEffect[3] = gameObject.GetComponent<NapBonusEffect>();
		gameObject = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("BonusEffect/MagicBonusEffect"));
		this.m_pEffect[5] = gameObject.GetComponent<MagicBonusEffect>();
		gameObject = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("BonusEffect/LevitateBonusEffect"));
		this.m_pEffect[7] = gameObject.GetComponent<LevitateBonusEffect>();
		gameObject = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("BonusEffect/ParfumeBonusEffect"));
		this.m_pEffect[4] = gameObject.GetComponent<ParfumeBonusEffect>();
		for (int i = 0; i < 9; i++)
		{
			if (this.m_pEffect[i] != null)
			{
				this.m_pEffect[i].BonusEffectMgr = this;
			}
		}
	}

	// Token: 0x0600055F RID: 1375 RVA: 0x0002B59C File Offset: 0x0002979C
	public void Dispose()
	{
		for (int i = 0; i < this.m_pEffect.Length; i++)
		{
			if (this.m_pEffect[i] != null)
			{
				UnityEngine.Object.Destroy(this.m_pEffect[i].gameObject);
			}
		}
	}

	// Token: 0x06000560 RID: 1376 RVA: 0x00003B80 File Offset: 0x00001D80
	public void Update()
	{
	}

	// Token: 0x06000561 RID: 1377 RVA: 0x0002B5E8 File Offset: 0x000297E8
	public void Reset()
	{
		for (int i = 0; i < 9; i++)
		{
			if (this.m_pEffect[i] != null && this.m_pEffect[i].Activated)
			{
				this.m_pEffect[i].Deactivate();
			}
		}
	}

	// Token: 0x06000562 RID: 1378 RVA: 0x00005DC3 File Offset: 0x00003FC3
	public bool ActivateBonusEffect(EBonusEffect _BonusEffect)
	{
		return _BonusEffect != EBonusEffect.BONUSEFFECT_COUNT && this.m_pEffect[(int)_BonusEffect] != null && this.m_pEffect[(int)_BonusEffect].Activate();
	}

	// Token: 0x06000563 RID: 1379 RVA: 0x00005DEF File Offset: 0x00003FEF
	public void DeactivateBonusEffect(EBonusEffect _BonusEffect)
	{
		if (_BonusEffect != EBonusEffect.BONUSEFFECT_COUNT && this.m_pEffect[(int)_BonusEffect] != null)
		{
			this.m_pEffect[(int)_BonusEffect].Deactivate();
		}
	}

	// Token: 0x06000564 RID: 1380 RVA: 0x00005E19 File Offset: 0x00004019
	public bool IsBonusEffectActivated(EBonusEffect _BonusEffect)
	{
		return _BonusEffect != EBonusEffect.BONUSEFFECT_COUNT && this.m_pEffect[(int)_BonusEffect] != null && this.m_pEffect[(int)_BonusEffect].Activated;
	}

	// Token: 0x06000565 RID: 1381 RVA: 0x00005E45 File Offset: 0x00004045
	public BonusEffect GetBonusEffect(EBonusEffect _BonusEffect)
	{
		if (_BonusEffect != EBonusEffect.BONUSEFFECT_COUNT && this.m_pEffect[(int)_BonusEffect] != null)
		{
			return this.m_pEffect[(int)_BonusEffect];
		}
		return null;
	}

	// Token: 0x04000539 RID: 1337
	private BonusEffect[] m_pEffect = new BonusEffect[9];

	// Token: 0x0400053A RID: 1338
	private Kart m_pTarget;
}

﻿using System;
using UnityEngine;

// Token: 0x020000DD RID: 221
public class MagicBonusEffect : BonusEffect
{
	// Token: 0x060005E9 RID: 1513 RVA: 0x00006342 File Offset: 0x00004542
	public override void Start()
	{
		this.m_bStoppedByAnim = false;
		base.Start();
	}

	// Token: 0x060005EA RID: 1514 RVA: 0x0002F350 File Offset: 0x0002D550
	public override bool Activate()
	{
		if (this.FirstKart.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_LEVITATE).Activated || this.SecondKart.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_LEVITATE).Activated)
		{
			return true;
		}
		base.Activate();
		Transform transform = this.FirstKart.transform;
		Transform transform2 = this.SecondKart.transform;
		Vector3 position = transform.position;
		Vector3 position2 = transform2.position;
		Vector3 direction = position2 - position;
		RaycastHit[] array = Physics.RaycastAll(position, direction, direction.magnitude, this.m_oLayerMask);
		foreach (RaycastHit raycastHit in array)
		{
			RcPortalTrigger component = raycastHit.collider.GetComponent<RcPortalTrigger>();
			if (component != null)
			{
				component.OnTriggerEnter(transform.parent.collider);
				component.OnTriggerEnter(transform2.parent.collider);
			}
		}
		Quaternion rotation = transform.rotation;
		Quaternion rotation2 = transform2.rotation;
		this.FirstKart.KartSound.PlaySound(14);
		this.SecondKart.KartSound.PlaySound(14);
		this.FirstKart.Teleport(position2, rotation2, this.SecondKart.GetVehiclePhysic().GetLinearVelocity());
		this.SecondKart.Teleport(position, rotation, this.FirstKart.GetVehiclePhysic().GetLinearVelocity());
		this.FirstKart.KartSound.PlayVoice(KartSound.EVoices.Good);
		this.SecondKart.KartSound.PlayVoice(KartSound.EVoices.Bad);
		CameraBase component2 = Camera.mainCamera.GetComponent<CameraBase>();
		CamStateTransMagic component3 = Camera.mainCamera.GetComponent<CamStateTransMagic>();
		if (component2.CurrentState == ECamState.Follow && (this.FirstKart.GetControlType() == RcVehicle.ControlType.Human || this.SecondKart.GetControlType() == RcVehicle.ControlType.Human))
		{
			float magnitude = (position - position2).magnitude;
			component3.TranslationDistance = magnitude;
			Vector3 translationDirection = position - position2;
			translationDirection.Normalize();
			component3.TranslationDirection = translationDirection;
			component3.Step = magnitude / component3.TranslationTime;
			component2.SwitchCamera(ECamState.Follow, ECamState.TransMagic);
		}
		if (this.FirstKart.OnBeSwaped != null)
		{
			this.FirstKart.OnBeSwaped(this.SecondKart);
		}
		if (this.SecondKart.OnBeSwaped != null)
		{
			this.SecondKart.OnBeSwaped(this.FirstKart);
		}
		this.FirstKart.RaceStats.ForceRefreshRespawn();
		this.SecondKart.RaceStats.ForceRefreshRespawn();
		this.Deactivate();
		return true;
	}

	// Token: 0x040005DF RID: 1503
	public LayerMask m_oLayerMask;

	// Token: 0x040005E0 RID: 1504
	[HideInInspector]
	public Kart FirstKart;

	// Token: 0x040005E1 RID: 1505
	[HideInInspector]
	public Kart SecondKart;
}

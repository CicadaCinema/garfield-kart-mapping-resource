﻿using System;

// Token: 0x020000CA RID: 202
public enum EBonusEffectDirection
{
	// Token: 0x0400051C RID: 1308
	LEFT,
	// Token: 0x0400051D RID: 1309
	RIGHT,
	// Token: 0x0400051E RID: 1310
	FRONT,
	// Token: 0x0400051F RID: 1311
	BACK
}

﻿using System;
using UnityEngine;

// Token: 0x0200015B RID: 347
public abstract class RewardConditionBase : MonoBehaviour
{
	// Token: 0x0600098D RID: 2445
	public abstract bool CanGiveReward();
}

﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

// Token: 0x02000268 RID: 616
public class ASE_Flurry
{
	// Token: 0x060010D4 RID: 4308
	[DllImport("__Internal")]
	private static extern void ASE_FlurryStartSession(string sApiKey);

	// Token: 0x060010D5 RID: 4309 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void Init(string sApiKey)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010D6 RID: 4310 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void Stop()
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010D7 RID: 4311
	[DllImport("__Internal")]
	private static extern void ASE_FlurryLogEvent(string sEventName);

	// Token: 0x060010D8 RID: 4312 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void LogEvent(string sEventName)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010D9 RID: 4313
	[DllImport("__Internal")]
	private static extern void ASE_FlurryLogEventWithParameters(string sEventName, string[] sKeys, string[] sValues);

	// Token: 0x060010DA RID: 4314 RVA: 0x00067E58 File Offset: 0x00066058
	public static void LogEvent(string sEventName, Dictionary<string, string> dict)
	{
		if (ASE_Tools.Available)
		{
			string[] array;
			string[] array2;
			ASE_Tools.DictionaryToArrays(dict, out array, out array2);
		}
	}

	// Token: 0x060010DB RID: 4315 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void LogEvent(string sEventName, string[] sKeys, string[] sValues)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010DC RID: 4316
	[DllImport("__Internal")]
	private static extern void ASE_FlurryLogEventTimed(string sEventName, bool bTimed);

	// Token: 0x060010DD RID: 4317 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void LogEvent(string sEventName, bool bTimed)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010DE RID: 4318
	[DllImport("__Internal")]
	private static extern void ASE_FlurryLogEventTimedWithParameters(string sEventName, bool bTimed, string[] sKeys, string[] sValues);

	// Token: 0x060010DF RID: 4319 RVA: 0x00067E7C File Offset: 0x0006607C
	public static void LogEvent(string sEventName, bool bTimed, Dictionary<string, string> dict)
	{
		if (ASE_Tools.Available)
		{
			string[] array;
			string[] array2;
			ASE_Tools.DictionaryToArrays(dict, out array, out array2);
		}
	}

	// Token: 0x060010E0 RID: 4320 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void LogEvent(string sEventName, bool bTimed, string[] sKeys, string[] sValues)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010E1 RID: 4321
	[DllImport("__Internal")]
	private static extern void ASE_FlurryEndTimedEvent(string sEventName);

	// Token: 0x060010E2 RID: 4322 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void EndTimedEvent(string sEventName)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010E3 RID: 4323
	[DllImport("__Internal")]
	private static extern void ASE_FlurryEndTimedEventWithParameters(string sEventName, string[] sKeys, string[] sValues);

	// Token: 0x060010E4 RID: 4324 RVA: 0x00067E58 File Offset: 0x00066058
	public static void EndTimedEvent(string sEventName, Dictionary<string, string> dict)
	{
		if (ASE_Tools.Available)
		{
			string[] array;
			string[] array2;
			ASE_Tools.DictionaryToArrays(dict, out array, out array2);
		}
	}

	// Token: 0x060010E5 RID: 4325 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void EndTimedEvent(string sEventName, string[] sKeys, string[] sValues)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010E6 RID: 4326
	[DllImport("__Internal")]
	private static extern void ASE_FlurrySetEventLoggingEnabled(bool bValue);

	// Token: 0x060010E7 RID: 4327 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetEventLoggingEnabled(bool bValue)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010E8 RID: 4328
	[DllImport("__Internal")]
	private static extern void ASE_FlurrySetLogLevel(int nLevel);

	// Token: 0x060010E9 RID: 4329 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetLogLevel(int nLevel)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010EA RID: 4330
	[DllImport("__Internal")]
	private static extern void ASE_FlurrySetGender(int nGender);

	// Token: 0x060010EB RID: 4331 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetGender(ASE_Flurry.Gender gender)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010EC RID: 4332
	[DllImport("__Internal")]
	private static extern void ASE_FlurrySetAge(int nAge);

	// Token: 0x060010ED RID: 4333 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetAge(int nAge)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010EE RID: 4334
	[DllImport("__Internal")]
	private static extern void ASE_FlurrySetUserID(string sUserID);

	// Token: 0x060010EF RID: 4335 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetUserID(string sUserID)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x02000269 RID: 617
	public enum Gender
	{
		// Token: 0x04000FF7 RID: 4087
		UNKNOWN = -1,
		// Token: 0x04000FF8 RID: 4088
		FEMALE,
		// Token: 0x04000FF9 RID: 4089
		MALE
	}
}

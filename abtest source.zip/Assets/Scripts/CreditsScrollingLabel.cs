﻿using System;
using UnityEngine;

// Token: 0x02000193 RID: 403
public class CreditsScrollingLabel : MonoBehaviour
{
	// Token: 0x14000001 RID: 1
	// (add) Token: 0x06000AE0 RID: 2784 RVA: 0x000097A3 File Offset: 0x000079A3
	// (remove) Token: 0x06000AE1 RID: 2785 RVA: 0x000097BC File Offset: 0x000079BC
	public event CreditsScrollingLabel.ScrollingLabelEndHandler OnLabelEnd;

	// Token: 0x1700017D RID: 381
	// (get) Token: 0x06000AE2 RID: 2786 RVA: 0x000097D5 File Offset: 0x000079D5
	// (set) Token: 0x06000AE3 RID: 2787 RVA: 0x00003B80 File Offset: 0x00001D80
	public bool Updating
	{
		get
		{
			return this.Updatable;
		}
		private set
		{
		}
	}

	// Token: 0x06000AE4 RID: 2788 RVA: 0x000097DD File Offset: 0x000079DD
	public void Awake()
	{
		this.Label = base.GetComponent<UILabel>();
	}

	// Token: 0x06000AE5 RID: 2789 RVA: 0x00049A88 File Offset: 0x00047C88
	public void Update()
	{
		if (this.Updatable)
		{
			Vector3 localPosition = base.transform.localPosition;
			localPosition.y += Time.deltaTime * this.Speed;
			base.transform.localPosition = localPosition;
			if (localPosition.y >= this.EndOffset)
			{
				this.Updatable = false;
				if (this.OnLabelEnd != null)
				{
					this.OnLabelEnd(this);
				}
			}
		}
	}

	// Token: 0x06000AE6 RID: 2790 RVA: 0x00049B04 File Offset: 0x00047D04
	public void SetItem(string Text, CreditsItemDesc Desc, GameObject pCreditFont)
	{
		if (this.Label)
		{
			this.Label.text = Text;
			this.Label.transform.localScale = new Vector3(Desc.FontSize, Desc.FontSize, 1f);
			this.Label.font = pCreditFont.GetComponent<UIFont>();
			this.Label.color = Desc.FontColor;
			this.Label.MarkAsChanged();
			this.Updatable = true;
		}
	}

	// Token: 0x06000AE7 RID: 2791 RVA: 0x000097EB File Offset: 0x000079EB
	public void Reset()
	{
		this.Updatable = false;
	}

	// Token: 0x04000AAD RID: 2733
	public float Speed = 5f;

	// Token: 0x04000AAE RID: 2734
	private UILabel Label;

	// Token: 0x04000AAF RID: 2735
	public float EndOffset = 200f;

	// Token: 0x04000AB0 RID: 2736
	private bool Updatable;

	// Token: 0x02000194 RID: 404
	// (Invoke) Token: 0x06000AE9 RID: 2793
	public delegate void ScrollingLabelEndHandler(CreditsScrollingLabel Label);
}

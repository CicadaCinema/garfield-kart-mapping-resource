﻿using System;
using UnityEngine;

// Token: 0x020000A5 RID: 165
public class AISettings : MonoBehaviour
{
	// Token: 0x040003C8 RID: 968
	public PathSettings PathSettings = new PathSettings();

	// Token: 0x040003C9 RID: 969
	public ChanceSettings ChanceSettings = new ChanceSettings();

	// Token: 0x040003CA RID: 970
	public BehaviourSettings BehaviourSettings = new BehaviourSettings();
}

﻿using System;

// Token: 0x020000F5 RID: 245
public enum EBonusCustomEffect
{
	// Token: 0x04000696 RID: 1686
	QUANTITY,
	// Token: 0x04000697 RID: 1687
	DURATION,
	// Token: 0x04000698 RID: 1688
	SPEED,
	// Token: 0x04000699 RID: 1689
	HEIGHT,
	// Token: 0x0400069A RID: 1690
	STICK,
	// Token: 0x0400069B RID: 1691
	EXPLOSION_RADIUS,
	// Token: 0x0400069C RID: 1692
	INERTIA,
	// Token: 0x0400069D RID: 1693
	ATTRACT,
	// Token: 0x0400069E RID: 1694
	REPULSE
}

﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200003F RID: 63
public class BetterList<T>
{
	// Token: 0x06000150 RID: 336 RVA: 0x00013ED8 File Offset: 0x000120D8
	public IEnumerator<T> GetEnumerator()
	{
		if (this.buffer != null)
		{
			for (int i = 0; i < this.size; i++)
			{
				yield return this.buffer[i];
			}
		}
		yield break;
	}

	// Token: 0x1700002C RID: 44
	public T this[int i]
	{
		get
		{
			return this.buffer[i];
		}
		set
		{
			this.buffer[i] = value;
		}
	}

	// Token: 0x06000153 RID: 339 RVA: 0x00013EF4 File Offset: 0x000120F4
	private void AllocateMore()
	{
		T[] array = (this.buffer == null) ? new T[32] : new T[Mathf.Max(this.buffer.Length << 1, 32)];
		if (this.buffer != null && this.size > 0)
		{
			this.buffer.CopyTo(array, 0);
		}
		this.buffer = array;
	}

	// Token: 0x06000154 RID: 340 RVA: 0x00013F5C File Offset: 0x0001215C
	private void Trim()
	{
		if (this.size > 0)
		{
			if (this.size < this.buffer.Length)
			{
				T[] array = new T[this.size];
				for (int i = 0; i < this.size; i++)
				{
					array[i] = this.buffer[i];
				}
				this.buffer = array;
			}
		}
		else
		{
			this.buffer = null;
		}
	}

	// Token: 0x06000155 RID: 341 RVA: 0x000031B3 File Offset: 0x000013B3
	public void Clear()
	{
		this.size = 0;
	}

	// Token: 0x06000156 RID: 342 RVA: 0x000031BC File Offset: 0x000013BC
	public void Release()
	{
		this.size = 0;
		this.buffer = null;
	}

	// Token: 0x06000157 RID: 343 RVA: 0x00013FD4 File Offset: 0x000121D4
	public void Add(T item)
	{
		if (this.buffer == null || this.size == this.buffer.Length)
		{
			this.AllocateMore();
		}
		this.buffer[this.size++] = item;
	}

	// Token: 0x06000158 RID: 344 RVA: 0x00014024 File Offset: 0x00012224
	public void Insert(int index, T item)
	{
		if (this.buffer == null || this.size == this.buffer.Length)
		{
			this.AllocateMore();
		}
		if (index < this.size)
		{
			for (int i = this.size; i > index; i--)
			{
				this.buffer[i] = this.buffer[i - 1];
			}
			this.buffer[index] = item;
			this.size++;
		}
		else
		{
			this.Add(item);
		}
	}

	// Token: 0x06000159 RID: 345 RVA: 0x000140BC File Offset: 0x000122BC
	public bool Contains(T item)
	{
		if (this.buffer == null)
		{
			return false;
		}
		for (int i = 0; i < this.size; i++)
		{
			if (this.buffer[i].Equals(item))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x0600015A RID: 346 RVA: 0x00014114 File Offset: 0x00012314
	public bool Remove(T item)
	{
		if (this.buffer != null)
		{
			EqualityComparer<T> @default = EqualityComparer<T>.Default;
			for (int i = 0; i < this.size; i++)
			{
				if (@default.Equals(this.buffer[i], item))
				{
					this.size--;
					this.buffer[i] = default(T);
					for (int j = i; j < this.size; j++)
					{
						this.buffer[j] = this.buffer[j + 1];
					}
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x0600015B RID: 347 RVA: 0x000141B8 File Offset: 0x000123B8
	public void RemoveAt(int index)
	{
		if (this.buffer != null && index < this.size)
		{
			this.size--;
			this.buffer[index] = default(T);
			for (int i = index; i < this.size; i++)
			{
				this.buffer[i] = this.buffer[i + 1];
			}
		}
	}

	// Token: 0x0600015C RID: 348 RVA: 0x00014230 File Offset: 0x00012430
	public T Pop()
	{
		if (this.buffer != null && this.size != 0)
		{
			T result = this.buffer[--this.size];
			this.buffer[this.size] = default(T);
			return result;
		}
		return default(T);
	}

	// Token: 0x0600015D RID: 349 RVA: 0x000031CC File Offset: 0x000013CC
	public T[] ToArray()
	{
		this.Trim();
		return this.buffer;
	}

	// Token: 0x0600015E RID: 350 RVA: 0x00014298 File Offset: 0x00012498
	public void Sort(Comparison<T> comparer)
	{
		bool flag = true;
		while (flag)
		{
			flag = false;
			for (int i = 1; i < this.size; i++)
			{
				if (comparer(this.buffer[i - 1], this.buffer[i]) > 0)
				{
					T t = this.buffer[i];
					this.buffer[i] = this.buffer[i - 1];
					this.buffer[i - 1] = t;
					flag = true;
				}
			}
		}
	}

	// Token: 0x04000171 RID: 369
	public T[] buffer;

	// Token: 0x04000172 RID: 370
	public int size;
}

﻿using System;

// Token: 0x02000131 RID: 305
public enum EAdvantage
{
	// Token: 0x040008B1 RID: 2225
	None = -1,
	// Token: 0x040008B2 RID: 2226
	PuzzleRadar,
	// Token: 0x040008B3 RID: 2227
	BoostStart,
	// Token: 0x040008B4 RID: 2228
	FirstPlaceOnStart,
	// Token: 0x040008B5 RID: 2229
	RestartRace,
	// Token: 0x040008B6 RID: 2230
	TwoPoints,
	// Token: 0x040008B7 RID: 2231
	FourPoints,
	// Token: 0x040008B8 RID: 2232
	LasagnaBonus,
	// Token: 0x040008B9 RID: 2233
	SpringBonus,
	// Token: 0x040008BA RID: 2234
	PieBonus
}

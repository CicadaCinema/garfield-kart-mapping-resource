﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200025E RID: 606
public class ASE_Tools
{
	// Token: 0x17000217 RID: 535
	// (get) Token: 0x06001092 RID: 4242 RVA: 0x0000D267 File Offset: 0x0000B467
	public static bool Available
	{
		get
		{
			return Application.platform == RuntimePlatform.IPhonePlayer || Application.platform == RuntimePlatform.Android;
		}
	}

	// Token: 0x06001093 RID: 4243 RVA: 0x00067DC4 File Offset: 0x00065FC4
	public static void DictionaryToArrays(Dictionary<string, string> dict, out string[] sKeys, out string[] sValues)
	{
		sKeys = null;
		sValues = null;
		if (dict == null)
		{
			return;
		}
		sKeys = new string[dict.Count];
		sValues = new string[dict.Count];
		int num = 0;
		foreach (KeyValuePair<string, string> keyValuePair in dict)
		{
			sKeys[num] = keyValuePair.Key;
			sValues[num] = keyValuePair.Value;
			num++;
		}
	}

	// Token: 0x06001094 RID: 4244 RVA: 0x0000D280 File Offset: 0x0000B480
	public static int GetDataEvent(string sData)
	{
		if (string.IsNullOrEmpty(sData))
		{
			return -1;
		}
		return (int)(sData[0] - 'A');
	}

	// Token: 0x06001095 RID: 4245 RVA: 0x0000D299 File Offset: 0x0000B499
	public static string GetDataMessage(string sData)
	{
		if (string.IsNullOrEmpty(sData) || sData.Length < 1)
		{
			return string.Empty;
		}
		return sData.Substring(1);
	}
}

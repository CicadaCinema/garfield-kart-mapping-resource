﻿using System;
using UnityEngine;

// Token: 0x020001CF RID: 463
public class LodInspector : MonoBehaviour
{
	// Token: 0x06000C89 RID: 3209 RVA: 0x0000AB66 File Offset: 0x00008D66
	public void OnWillRenderObject()
	{
		if (this.m_pLodRemote)
		{
			this.m_pLodRemote.SetCurrentLod(this.m_iLodId);
		}
	}

	// Token: 0x04000C31 RID: 3121
	public int m_iLodId;

	// Token: 0x04000C32 RID: 3122
	public LodRemote m_pLodRemote;
}

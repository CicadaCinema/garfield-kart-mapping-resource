﻿using System;
using System.Xml.Serialization;

// Token: 0x02000241 RID: 577
public class SerializablePair<T, U>
{
	// Token: 0x0600101B RID: 4123 RVA: 0x00065D18 File Offset: 0x00063F18
	public SerializablePair()
	{
		this._key = default(T);
		this._value = default(U);
	}

	// Token: 0x0600101C RID: 4124 RVA: 0x0000CDC3 File Offset: 0x0000AFC3
	public SerializablePair(T pFirst, U pSecond)
	{
		this._key = pFirst;
		this._value = pSecond;
	}

	// Token: 0x17000209 RID: 521
	// (get) Token: 0x0600101D RID: 4125 RVA: 0x0000CDD9 File Offset: 0x0000AFD9
	// (set) Token: 0x0600101E RID: 4126 RVA: 0x0000CDE1 File Offset: 0x0000AFE1
	[XmlElement("A")]
	public T Key
	{
		get
		{
			return this._key;
		}
		set
		{
			this._key = value;
		}
	}

	// Token: 0x1700020A RID: 522
	// (get) Token: 0x0600101F RID: 4127 RVA: 0x0000CDEA File Offset: 0x0000AFEA
	// (set) Token: 0x06001020 RID: 4128 RVA: 0x0000CDF2 File Offset: 0x0000AFF2
	[XmlElement("B")]
	public U Value
	{
		get
		{
			return this._value;
		}
		set
		{
			this._value = value;
		}
	}

	// Token: 0x04000F80 RID: 3968
	private T _key;

	// Token: 0x04000F81 RID: 3969
	private U _value;
}

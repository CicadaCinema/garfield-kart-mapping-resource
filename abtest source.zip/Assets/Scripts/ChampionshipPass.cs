﻿using System;

// Token: 0x02000176 RID: 374
public class ChampionshipPass
{
	// Token: 0x04000A12 RID: 2578
	public ChampionShipData ChampionshipSelectionned;

	// Token: 0x04000A13 RID: 2579
	public EChampionshipPassState State;

	// Token: 0x04000A14 RID: 2580
	public EDifficulty Difficulty;
}

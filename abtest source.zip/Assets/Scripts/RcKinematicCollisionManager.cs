﻿using System;
using UnityEngine;

// Token: 0x02000221 RID: 545
public class RcKinematicCollisionManager : MonoBehaviour
{
	// Token: 0x06000F53 RID: 3923 RVA: 0x000020F3 File Offset: 0x000002F3
	private RcKinematicCollisionManager()
	{
	}

	// Token: 0x06000F54 RID: 3924 RVA: 0x0000C7FD File Offset: 0x0000A9FD
	public void Start()
	{
		this.vehicles = (RcKinematicPhysic[])UnityEngine.Object.FindObjectsOfType(typeof(RcKinematicPhysic));
	}

	// Token: 0x06000F55 RID: 3925 RVA: 0x00060CE0 File Offset: 0x0005EEE0
	public void FixedUpdate()
	{
		if (Singleton<GameConfigurator>.Instance.m_bMobilePlatform && (this.vehicles[0].m_iCountFixedUpdate & 3) == 0)
		{
			return;
		}
		foreach (RcKinematicPhysic rcKinematicPhysic in this.vehicles)
		{
			foreach (RcKinematicPhysic rcKinematicPhysic2 in this.vehicles)
			{
				if (!(rcKinematicPhysic == rcKinematicPhysic2) && !(rcKinematicPhysic == null) && !(rcKinematicPhysic2 == null) && rcKinematicPhysic.Enable && rcKinematicPhysic2.Enable && !rcKinematicPhysic.IsLocked() && !rcKinematicPhysic2.IsLocked())
				{
					if ((rcKinematicPhysic.GetTransform().position - rcKinematicPhysic2.GetTransform().position).sqrMagnitude < 1f)
					{
						this.ManageVehicleContact(rcKinematicPhysic, rcKinematicPhysic2);
					}
				}
			}
		}
	}

	// Token: 0x06000F56 RID: 3926 RVA: 0x00060DE4 File Offset: 0x0005EFE4
	protected void ManageVehicleContact(RcKinematicPhysic vehicle1, RcKinematicPhysic vehicle2)
	{
		Vector3 position = vehicle1.transform.position;
		Vector3 position2 = vehicle2.transform.position;
		Vector3 linearVelocity = vehicle1.GetLinearVelocity();
		Vector3 linearVelocity2 = vehicle2.GetLinearVelocity();
		float magnitude = linearVelocity.magnitude;
		float magnitude2 = linearVelocity2.magnitude;
		float num = 1f;
		float num2 = 1f;
		if (magnitude > 0f || magnitude2 > 0f)
		{
			num = 0.5f + magnitude * vehicle1.m_fMass / (magnitude * vehicle1.m_fMass + magnitude2 * vehicle2.m_fMass);
			num2 = 0.5f + magnitude2 * vehicle2.m_fMass / (magnitude * vehicle1.m_fMass + magnitude2 * vehicle2.m_fMass);
		}
		Vector3 vector = position - position2;
		float num3 = RcUtils.FastSqrtApprox(vector.sqrMagnitude);
		vector.Normalize();
		Vector3 vector2 = (vehicle1.m_fMass * linearVelocity + vehicle2.m_fMass * linearVelocity2) / (vehicle1.m_fMass + vehicle2.m_fMass);
		Vector3 vector3 = vector2;
		if (vector3.sqrMagnitude <= 0.0001f)
		{
			vector3 = Vector3.Cross(vector, Vector3.up);
		}
		bool flag = RcUtils.IsOnRight(position, position + vector3, position2);
		bool flag2 = !flag;
		Vector3 a = Vector3.Cross(Vector3.up, vector3);
		a.Normalize();
		Vector3 a2 = 1.3f * vector2;
		Vector3 a3 = 1.3f * vector2;
		if (num < num2)
		{
			a2 -= vehicle1.m_fVehicleCollBackPrc * vector2;
		}
		else
		{
			a3 -= vehicle2.m_fVehicleCollBackPrc * vector2;
		}
		float magnitude3 = a2.magnitude;
		a2 += Vector3.up * vehicle1.m_fVehicleCollUpImpulseIntensity;
		a2 += num2 * vehicle1.m_fVehicleCollSideImpulseIntensity * a * ((!flag) ? 1f : -1f);
		a2.Normalize();
		a2 *= magnitude3;
		if (magnitude3 <= 1f)
		{
			a2 += vector * (1f - magnitude3);
		}
		float magnitude4 = a3.magnitude;
		a3 += Vector3.up * vehicle2.m_fVehicleCollUpImpulseIntensity;
		a3 += num * vehicle2.m_fVehicleCollSideImpulseIntensity * a * ((!flag2) ? 1f : -1f);
		a3.Normalize();
		a3 *= magnitude4;
		if (magnitude4 <= 1f)
		{
			a3 -= vector * (1f - magnitude4);
		}
		Vector3 impulse = a2 - linearVelocity;
		Vector3 impulse2 = a3 - linearVelocity2;
		Vector3 fVehicleCollInertiaDamping = vehicle1.m_fVehicleCollInertiaDamping;
		Vector3 fVehicleCollInertiaDamping2 = vehicle2.m_fVehicleCollInertiaDamping;
		if (!vehicle1.BInertiaMode && (Network.peerType == NetworkPeerType.Disconnected || vehicle1.transform.parent.gameObject.networkView.isMine))
		{
			vehicle1.SwitchToInertiaMode(vehicle1.m_fVehicleCollInertiaDelay, impulse, true, false, fVehicleCollInertiaDamping);
		}
		if (!vehicle2.BInertiaMode && (Network.peerType == NetworkPeerType.Disconnected || vehicle2.transform.parent.gameObject.networkView.isMine))
		{
			vehicle2.SwitchToInertiaMode(vehicle2.m_fVehicleCollInertiaDelay, impulse2, true, false, fVehicleCollInertiaDamping2);
		}
		CollisionData collisionInfos = new CollisionData
		{
			normal = vector,
			solid = vehicle1.GetVehicleBody(),
			other = vehicle2.GetVehicleBody(),
			surface = vehicle2.gameObject.layer,
			position = (position + position2) / 2f,
			depth = 1f - num3
		};
		vehicle1.FireOnCollision(collisionInfos);
		collisionInfos.solid = vehicle2.GetVehicleBody();
		collisionInfos.other = vehicle1.GetVehicleBody();
		collisionInfos.surface = vehicle1.gameObject.layer;
		vehicle2.FireOnCollision(collisionInfos);
	}

	// Token: 0x04000EBD RID: 3773
	protected RcKinematicPhysic[] vehicles;
}

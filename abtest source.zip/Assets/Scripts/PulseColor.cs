﻿using System;
using UnityEngine;

// Token: 0x02000097 RID: 151
public class PulseColor : MonoBehaviour
{
	// Token: 0x0600040E RID: 1038 RVA: 0x0002454C File Offset: 0x0002274C
	public void Update()
	{
		float t = Mathf.PingPong(Time.time, this.duration) / this.duration;
		base.renderer.material.color = Color.Lerp(this.colorStart, this.colorEnd, t);
	}

	// Token: 0x04000382 RID: 898
	public Color colorStart = Color.red;

	// Token: 0x04000383 RID: 899
	public Color colorEnd = Color.green;

	// Token: 0x04000384 RID: 900
	public float duration = 1f;
}

﻿using System;
using UnityEngine;

// Token: 0x020000CF RID: 207
public class BonusEntity : MonoBehaviour
{
	// Token: 0x06000566 RID: 1382 RVA: 0x0002B63C File Offset: 0x0002983C
	public BonusEntity()
	{
		this.ReactivationDelay = 1f;
		this.m_fTimeBeforeReactivation = 0f;
		this.m_bActive = false;
		this.m_pCollider = null;
		this.m_fTimer = 0f;
		this.m_eState = BonusEntity.BonusState.BONUS_NONE;
		this.m_bBehind = false;
		this.m_eItem = EITEM.ITEM_NONE;
		this.m_bSynchronizePosition = false;
	}

	// Token: 0x170000EF RID: 239
	// (get) Token: 0x06000567 RID: 1383 RVA: 0x00005E6C File Offset: 0x0000406C
	public bool BSynchronizePosition
	{
		get
		{
			return this.m_bSynchronizePosition;
		}
	}

	// Token: 0x170000F0 RID: 240
	// (get) Token: 0x06000568 RID: 1384 RVA: 0x00005E74 File Offset: 0x00004074
	public bool BSynchronizeRotation
	{
		get
		{
			return this.m_bSynchronizeRotation;
		}
	}

	// Token: 0x06000569 RID: 1385 RVA: 0x00005E7C File Offset: 0x0000407C
	public BonusEntity.BonusState GetState()
	{
		return this.m_eState;
	}

	// Token: 0x170000F1 RID: 241
	// (get) Token: 0x0600056A RID: 1386 RVA: 0x00005E84 File Offset: 0x00004084
	// (set) Token: 0x0600056B RID: 1387 RVA: 0x00005E8C File Offset: 0x0000408C
	public bool Activate
	{
		get
		{
			return this.m_bActive;
		}
		set
		{
			this.m_bActive = value;
		}
	}

	// Token: 0x170000F2 RID: 242
	// (get) Token: 0x0600056C RID: 1388 RVA: 0x00005E95 File Offset: 0x00004095
	// (set) Token: 0x0600056D RID: 1389 RVA: 0x00005E9D File Offset: 0x0000409D
	public float Timer
	{
		get
		{
			return this.m_fTimer;
		}
		set
		{
			this.m_fTimer = value;
		}
	}

	// Token: 0x170000F3 RID: 243
	// (get) Token: 0x0600056E RID: 1390 RVA: 0x00005EA6 File Offset: 0x000040A6
	// (set) Token: 0x0600056F RID: 1391 RVA: 0x00005EAE File Offset: 0x000040AE
	public Kart Launcher
	{
		get
		{
			return this.m_pLauncher;
		}
		set
		{
			this.m_pLauncher = value;
		}
	}

	// Token: 0x170000F4 RID: 244
	// (get) Token: 0x06000570 RID: 1392 RVA: 0x00005EB7 File Offset: 0x000040B7
	public Vector3 LaunchDirection
	{
		get
		{
			return this.m_pLauncher.LaunchDirection;
		}
	}

	// Token: 0x170000F5 RID: 245
	// (get) Token: 0x06000571 RID: 1393 RVA: 0x00005EC4 File Offset: 0x000040C4
	public Vector3 LaunchHorizontalDirection
	{
		get
		{
			return this.m_pLauncher.LaunchHorizontalDirection;
		}
	}

	// Token: 0x06000572 RID: 1394 RVA: 0x00005ED1 File Offset: 0x000040D1
	public Vector3 GetPosition()
	{
		return this.m_pTransform.position;
	}

	// Token: 0x06000573 RID: 1395 RVA: 0x0002B69C File Offset: 0x0002989C
	public Vector2 GetFlatPosition()
	{
		return new Vector2(this.m_pTransform.position.x, this.m_pTransform.position.z);
	}

	// Token: 0x06000574 RID: 1396 RVA: 0x00005EDE File Offset: 0x000040DE
	public bool IsStatic()
	{
		return this.m_bBehind;
	}

	// Token: 0x06000575 RID: 1397 RVA: 0x0002B6D4 File Offset: 0x000298D4
	public virtual void Awake()
	{
		Singleton<BonusMgr>.Instance.AddBonus(base.transform.parent.gameObject, this.m_eItem);
		this.m_pCollider = base.GetComponent<Collider>();
		this.m_pTransform = base.gameObject.transform;
		this.m_iAnimParameterBehind = Animator.StringToHash("Projectile_LaunchBack");
		this.m_iAnimParameterFront = Animator.StringToHash("Projectile_LaunchFront");
		this.m_iAnimStateBehind = Animator.StringToHash("Projectile_Launch.Projectile_LaunchBack");
		this.m_iAnimStateFront = Animator.StringToHash("Projectile_Launch.Projectile_LaunchFront");
		this.m_pNetworkBonusEntity = base.transform.parent.GetComponentInChildren<NetworkBonusEntity>();
		if (this.m_pNetworkBonusEntity != null)
		{
			this.m_pNetworkView = this.m_pNetworkBonusEntity.GetComponent<NetworkView>();
		}
		else
		{
			this.m_pNetworkView = base.transform.parent.GetComponentInChildren<NetworkView>();
		}
		this.SetActive(false);
	}

	// Token: 0x06000576 RID: 1398 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void Start()
	{
	}

	// Token: 0x06000577 RID: 1399 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void OnSerializeNetworkView(BitStream stream, NetworkMessageInfo info)
	{
	}

	// Token: 0x06000578 RID: 1400 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void OnDestroy()
	{
	}

	// Token: 0x06000579 RID: 1401 RVA: 0x0002B7B8 File Offset: 0x000299B8
	public virtual void Update()
	{
		if (this.ReactivationDelay > 0f && this.m_fTimeBeforeReactivation > 0f)
		{
			this.m_fTimeBeforeReactivation -= Time.deltaTime;
			if (this.m_fTimeBeforeReactivation <= 0f)
			{
				this.SetActive(true);
			}
		}
	}

	// Token: 0x0600057A RID: 1402 RVA: 0x00005EE6 File Offset: 0x000040E6
	public virtual void OnEnable()
	{
		this.m_fTimer = Time.time;
	}

	// Token: 0x0600057B RID: 1403 RVA: 0x00005EF3 File Offset: 0x000040F3
	protected void ActivateGameObject(bool _Active)
	{
		base.gameObject.SetActive(_Active);
		if (this.m_pNetworkBonusEntity != null)
		{
			this.m_pNetworkBonusEntity.enabled = _Active;
		}
	}

	// Token: 0x0600057C RID: 1404 RVA: 0x0002B810 File Offset: 0x00029A10
	public virtual void SetActive(bool _Active)
	{
		this.m_bActive = _Active;
		this.m_fTimeBeforeReactivation = ((!_Active) ? this.ReactivationDelay : 0f);
		if (base.renderer)
		{
			base.renderer.enabled = _Active;
		}
		if (this.m_pCollider)
		{
			this.m_pCollider.enabled = _Active;
		}
	}

	// Token: 0x0600057D RID: 1405 RVA: 0x0002B878 File Offset: 0x00029A78
	public virtual void Launch()
	{
		this.m_eState = BonusEntity.BonusState.BONUS_LAUNCHREQUEST;
		if (this.m_pLauncher != null)
		{
			this.m_pLauncher.Anim.LaunchBonusAnimOnCharacter((!this.m_bBehind) ? this.m_iAnimParameterFront : this.m_iAnimParameterBehind, (!this.m_bBehind) ? this.m_iAnimStateFront : this.m_iAnimStateBehind, true);
		}
	}

	// Token: 0x0600057E RID: 1406 RVA: 0x00005F1E File Offset: 0x0000411E
	public virtual void DoDestroy()
	{
		this.m_eState = BonusEntity.BonusState.BONUS_DESTROYED;
	}

	// Token: 0x0600057F RID: 1407 RVA: 0x0002B8E8 File Offset: 0x00029AE8
	public virtual void OnTriggerEnter(Collider other)
	{
		if (this.m_bActive)
		{
			if (Network.isServer && this.m_pNetworkView != null)
			{
				Transform parent = other.gameObject.transform.parent;
				GameObject gameObject = null;
				if (parent)
				{
					Transform transform = parent.Find("NetworkDelegate");
					if (transform)
					{
						gameObject = transform.gameObject;
					}
				}
				if (other.gameObject.networkView != null || (gameObject && gameObject.networkView != null))
				{
					NetworkViewID viewID;
					if (other.gameObject.networkView != null)
					{
						viewID = other.gameObject.networkView.viewID;
					}
					else
					{
						viewID = gameObject.networkView.viewID;
					}
					this.m_pNetworkView.RPC("OnNetworkViewTriggerEnter", RPCMode.All, new object[]
					{
						viewID
					});
				}
				else
				{
					this.m_pNetworkView.RPC("OnLayerTriggerEnter", RPCMode.All, new object[]
					{
						other.gameObject.layer
					});
				}
			}
			else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
			{
				this.DoOnTriggerEnter(other.gameObject, other.gameObject.layer);
			}
		}
	}

	// Token: 0x06000580 RID: 1408 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void DoOnTriggerEnter(GameObject other, int otherlayer)
	{
	}

	// Token: 0x06000581 RID: 1409 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void DoOnTriggerExit(GameObject other, int otherlayer)
	{
	}

	// Token: 0x06000582 RID: 1410 RVA: 0x00005F27 File Offset: 0x00004127
	public void NetDestroy()
	{
		if (Network.isServer)
		{
			this.m_pNetworkView.RPC("OnNetworkDestroy", RPCMode.All, new object[0]);
		}
		else if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoDestroy();
		}
	}

	// Token: 0x06000583 RID: 1411 RVA: 0x00005F5F File Offset: 0x0000415F
	public void NetworkInitialize(NetworkViewID LauncherViewID)
	{
		if (Network.peerType != NetworkPeerType.Disconnected)
		{
			this.m_pNetworkView.RPC("NetworkInitialize", RPCMode.Others, new object[]
			{
				LauncherViewID
			});
		}
	}

	// Token: 0x06000584 RID: 1412 RVA: 0x00005F8B File Offset: 0x0000418B
	public void DoNetworkInitialize(NetworkViewID LauncherViewID)
	{
		if (this.Activate)
		{
			this.SetActive(false);
		}
		this.Launcher = Singleton<BonusMgr>.Instance.Karts[LauncherViewID];
	}

	// Token: 0x06000585 RID: 1413 RVA: 0x00005FB5 File Offset: 0x000041B5
	public void NetLaunch(NetworkViewID launcherViewID)
	{
		this.m_pNetworkView.RPC("Launch", RPCMode.All, new object[]
		{
			launcherViewID
		});
	}

	// Token: 0x0400053B RID: 1339
	[SerializeField]
	public float ReactivationDelay;

	// Token: 0x0400053C RID: 1340
	protected float m_fTimeBeforeReactivation;

	// Token: 0x0400053D RID: 1341
	protected bool m_bActive;

	// Token: 0x0400053E RID: 1342
	protected Collider m_pCollider;

	// Token: 0x0400053F RID: 1343
	private float m_fTimer;

	// Token: 0x04000540 RID: 1344
	protected Kart m_pLauncher;

	// Token: 0x04000541 RID: 1345
	protected BonusEntity.BonusState m_eState;

	// Token: 0x04000542 RID: 1346
	protected Transform m_pTransform;

	// Token: 0x04000543 RID: 1347
	private int m_iAnimParameterBehind;

	// Token: 0x04000544 RID: 1348
	private int m_iAnimParameterFront;

	// Token: 0x04000545 RID: 1349
	private int m_iAnimStateBehind;

	// Token: 0x04000546 RID: 1350
	private int m_iAnimStateFront;

	// Token: 0x04000547 RID: 1351
	protected bool m_bBehind;

	// Token: 0x04000548 RID: 1352
	protected EITEM m_eItem;

	// Token: 0x04000549 RID: 1353
	protected NetworkBonusEntity m_pNetworkBonusEntity;

	// Token: 0x0400054A RID: 1354
	protected NetworkView m_pNetworkView;

	// Token: 0x0400054B RID: 1355
	protected bool m_bSynchronizePosition;

	// Token: 0x0400054C RID: 1356
	protected bool m_bSynchronizeRotation;

	// Token: 0x020000D0 RID: 208
	public enum BonusState
	{
		// Token: 0x0400054E RID: 1358
		BONUS_NONE,
		// Token: 0x0400054F RID: 1359
		BONUS_LAUNCHREQUEST,
		// Token: 0x04000550 RID: 1360
		BONUS_LAUNCHED,
		// Token: 0x04000551 RID: 1361
		BONUS_ANIMLAUNCHED,
		// Token: 0x04000552 RID: 1362
		BONUS_ONGROUND,
		// Token: 0x04000553 RID: 1363
		BONUS_TRIGGERED,
		// Token: 0x04000554 RID: 1364
		BONUS_DESTROYED
	}
}

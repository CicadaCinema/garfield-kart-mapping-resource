﻿using System;
using UnityEngine;

// Token: 0x020001E5 RID: 485
[Serializable]
public class RacingAI
{
	// Token: 0x170001B1 RID: 433
	// (get) Token: 0x06000CFC RID: 3324 RVA: 0x0000AEEC File Offset: 0x000090EC
	// (set) Token: 0x06000CFD RID: 3325 RVA: 0x0000AEF4 File Offset: 0x000090F4
	public E_AILevel Level
	{
		get
		{
			return this._level;
		}
		set
		{
			this._level = value;
		}
	}

	// Token: 0x170001B2 RID: 434
	// (get) Token: 0x06000CFE RID: 3326 RVA: 0x0000AEFD File Offset: 0x000090FD
	public PidController PidController
	{
		get
		{
			return this._pidController;
		}
	}

	// Token: 0x170001B3 RID: 435
	// (get) Token: 0x06000CFF RID: 3327 RVA: 0x0000AF05 File Offset: 0x00009105
	// (set) Token: 0x06000D00 RID: 3328 RVA: 0x0000AF0D File Offset: 0x0000910D
	public PathPosition PathPosition
	{
		get
		{
			return this._pathPosition;
		}
		set
		{
			this._pathPosition = value;
		}
	}

	// Token: 0x170001B4 RID: 436
	// (get) Token: 0x06000D01 RID: 3329 RVA: 0x0000AF16 File Offset: 0x00009116
	public int CurrentPathIndex
	{
		get
		{
			return this._pathPosition.index;
		}
	}

	// Token: 0x170001B5 RID: 437
	// (get) Token: 0x06000D02 RID: 3330 RVA: 0x0000AF23 File Offset: 0x00009123
	public float ClosestSegmentRatio
	{
		get
		{
			return this._pathPosition.ratio;
		}
	}

	// Token: 0x170001B6 RID: 438
	// (get) Token: 0x06000D03 RID: 3331 RVA: 0x0000AF30 File Offset: 0x00009130
	// (set) Token: 0x06000D04 RID: 3332 RVA: 0x0000AF38 File Offset: 0x00009138
	public E_AIMode Mode
	{
		get
		{
			return this._mode;
		}
		set
		{
			this._mode = value;
		}
	}

	// Token: 0x170001B7 RID: 439
	// (get) Token: 0x06000D05 RID: 3333 RVA: 0x0000AF41 File Offset: 0x00009141
	public E_AIMode PreviousMode
	{
		get
		{
			return this._previousMode;
		}
	}

	// Token: 0x170001B8 RID: 440
	// (get) Token: 0x06000D06 RID: 3334 RVA: 0x0000AF49 File Offset: 0x00009149
	// (set) Token: 0x06000D07 RID: 3335 RVA: 0x0000AF51 File Offset: 0x00009151
	public bool IsRailTransition
	{
		get
		{
			return this._railTransition;
		}
		set
		{
			this._railTransition = value;
		}
	}

	// Token: 0x170001B9 RID: 441
	// (get) Token: 0x06000D08 RID: 3336 RVA: 0x0000AF5A File Offset: 0x0000915A
	// (set) Token: 0x06000D09 RID: 3337 RVA: 0x0000AF62 File Offset: 0x00009162
	public float DrivePriority
	{
		get
		{
			return this._drivePriority;
		}
		set
		{
			this._drivePriority = value;
		}
	}

	// Token: 0x170001BA RID: 442
	// (get) Token: 0x06000D0A RID: 3338 RVA: 0x0000AF6B File Offset: 0x0000916B
	public float AntiJamRemainingTime
	{
		get
		{
			return this._antiJamTime;
		}
	}

	// Token: 0x170001BB RID: 443
	// (get) Token: 0x06000D0B RID: 3339 RVA: 0x0000AF73 File Offset: 0x00009173
	public float AntiReverseRemainingTime
	{
		get
		{
			return this._antiReverseTime;
		}
	}

	// Token: 0x170001BC RID: 444
	// (get) Token: 0x06000D0C RID: 3340 RVA: 0x0000AF7B File Offset: 0x0000917B
	public float AntiBigJamRemainingTime
	{
		get
		{
			return this._antiBigJamTime;
		}
	}

	// Token: 0x170001BD RID: 445
	// (get) Token: 0x06000D0D RID: 3341 RVA: 0x0000AF83 File Offset: 0x00009183
	public float StartModeTime
	{
		get
		{
			return this._startModeTime;
		}
	}

	// Token: 0x170001BE RID: 446
	// (get) Token: 0x06000D0E RID: 3342 RVA: 0x0000AF8B File Offset: 0x0000918B
	public float StartModeDelay
	{
		get
		{
			return this._startModeDelay;
		}
	}

	// Token: 0x170001BF RID: 447
	// (get) Token: 0x06000D0F RID: 3343 RVA: 0x0000AF93 File Offset: 0x00009193
	public RcVehicle Vehicle
	{
		get
		{
			return this._virtualController.GetVehicle();
		}
	}

	// Token: 0x170001C0 RID: 448
	// (set) Token: 0x06000D10 RID: 3344 RVA: 0x0000AFA0 File Offset: 0x000091A0
	public RcFastPath IdealPath
	{
		set
		{
			this._idealPath = value;
		}
	}

	// Token: 0x170001C1 RID: 449
	// (get) Token: 0x06000D11 RID: 3345 RVA: 0x0000AFA9 File Offset: 0x000091A9
	// (set) Token: 0x06000D12 RID: 3346 RVA: 0x0000AFB1 File Offset: 0x000091B1
	public RcVirtualController VirtualController
	{
		get
		{
			return this._virtualController;
		}
		set
		{
			this._virtualController = value;
		}
	}

	// Token: 0x170001C2 RID: 450
	// (get) Token: 0x06000D13 RID: 3347 RVA: 0x0000AFBA File Offset: 0x000091BA
	public float Steer
	{
		get
		{
			return this._virtualController.GetSteer();
		}
	}

	// Token: 0x170001C3 RID: 451
	// (get) Token: 0x06000D14 RID: 3348 RVA: 0x0000AFC7 File Offset: 0x000091C7
	public float SpeedBehaviour
	{
		get
		{
			return this._virtualController.GetSpeedBehaviour();
		}
	}

	// Token: 0x170001C4 RID: 452
	// (get) Token: 0x06000D15 RID: 3349 RVA: 0x0000AFD4 File Offset: 0x000091D4
	public RcFastPath CurrentPath
	{
		get
		{
			return this._idealPath;
		}
	}

	// Token: 0x06000D16 RID: 3350 RVA: 0x00055920 File Offset: 0x00053B20
	~RacingAI()
	{
		this.Term();
	}

	// Token: 0x06000D17 RID: 3351 RVA: 0x00055950 File Offset: 0x00053B50
	public virtual void Update()
	{
		this._lastPathRecomputeTime += Time.deltaTime;
		if (!this.Vehicle.IsLocked())
		{
			this._captureTime += Time.deltaTime;
			if (this._captureTime > this._bigJameCheck)
			{
				Vector3 vector = this.Vehicle.GetPosition() - this._capturedPos;
				float num = this._bigJamSpeed * this._bigJameCheck * this._bigJamSpeed * this._bigJameCheck;
				if (vector.sqrMagnitude < num && this.Vehicle.GetMaxSpeed() > this._bigJamSpeed)
				{
					this._bigJamTime += this._bigJameCheck;
				}
				else
				{
					this._bigJamTime = 0f;
				}
				this._captureTime = 0f;
				this._capturedPos = this.Vehicle.GetPosition();
			}
			if (this._mode == E_AIMode.DRIVEN_MODE)
			{
				bool flag = true;
				if (this._jamTime < 0f || (flag && Mathf.Abs(this.Vehicle.GetRealSpeedMs()) < this._jamSpeed && this.Vehicle.GetMaxSpeed() > this._jamSpeed))
				{
					this._jamTime += Time.deltaTime;
				}
				else
				{
					this._jamTime = 0f;
				}
			}
			if (this._pathPosition.index != -1 && this._idealPath != null)
			{
				Vector3 targetPoint = this.GetTargetPoint();
				PathPosition pathPosition = this._pathPosition;
				this._idealPath.UpdatePathPosition(ref pathPosition, targetPoint, 3, 0, false, this._idealPath.IsLooping());
				float num2 = Vector3.Dot(this._idealPath.GetSegment(pathPosition.index).normalized, this.Vehicle.GetCameraAt());
				num2 *= 57.29578f;
				if (num2 < this._reverseDot * 0.0174532924f)
				{
					this._reverseTime += Time.deltaTime;
				}
				else
				{
					this._reverseTime = 0f;
				}
				if (num2 > this._stopAntiReverseDot * 0.0174532924f)
				{
					this._antiReverseTime = 0f;
				}
			}
		}
		if (this._bigJamTime >= this._antiBigJamStart)
		{
			this.StartAntiBigJam();
		}
		if (this._jamTime > this._antiJamStart)
		{
			this.StartAntiJam();
		}
		if (this._reverseTime >= this._antiReverseStart)
		{
			this.StartAntiReverse();
		}
		if (this._antiJamTime > 0f)
		{
			this._antiJamTime -= Time.deltaTime;
		}
		if (this._antiBigJamTime > 0f)
		{
			this._antiBigJamTime -= Time.deltaTime;
		}
		if (this._antiReverseTime > 0f)
		{
			this._antiReverseTime -= Time.deltaTime;
		}
		if (this._mode == E_AIMode.START_MODE && this._startModeTime > 0f)
		{
			this._startModeTime -= Time.deltaTime;
		}
	}

	// Token: 0x06000D18 RID: 3352 RVA: 0x00055C58 File Offset: 0x00053E58
	public virtual void Init()
	{
		this._forcePathRecomputing = true;
		this._pidController = new PidController();
		RcVehicle vehicle = this.Vehicle;
		vehicle.OnAutoPilotChanged = (Action)Delegate.Combine(vehicle.OnAutoPilotChanged, new Action(this.EventRaised));
		RcVehicle vehicle2 = this.Vehicle;
		vehicle2.OnTeleported = (Action)Delegate.Combine(vehicle2.OnTeleported, new Action(this.Reset));
	}

	// Token: 0x06000D19 RID: 3353 RVA: 0x00055CC8 File Offset: 0x00053EC8
	private void EventRaised()
	{
		this._pathPosition = PathPosition.UNDEFINED_POSITION;
		this._railTransition = false;
		this._catchMode = false;
		this._mode = E_AIMode.IDLE_MODE;
		this._previousMode = E_AIMode.IDLE_MODE;
		this._previousRailPoint = Vector3.zero;
		this._drivePriority = 0f;
		this._jamTime = 0f;
		this._antiJamTime = 0f;
		this._forcePathRecomputing = true;
	}

	// Token: 0x06000D1A RID: 3354 RVA: 0x00004C05 File Offset: 0x00002E05
	public bool MustRecomputePath()
	{
		return true;
	}

	// Token: 0x06000D1B RID: 3355 RVA: 0x0000AFDC File Offset: 0x000091DC
	public void StartStartMode()
	{
		this._startModeTime = this._startModeDelay;
	}

	// Token: 0x06000D1C RID: 3356 RVA: 0x0000AFEA File Offset: 0x000091EA
	public virtual void StartAntiJam()
	{
		this._antiJamTime = this._antiJamDelay;
		this._jamTime = -this._antiJamReload;
	}

	// Token: 0x06000D1D RID: 3357 RVA: 0x0000B005 File Offset: 0x00009205
	public void StartAntiBigJam()
	{
		this.Vehicle.ForceRespawn();
		this._bigJamTime = -this._antiBigJamReload;
	}

	// Token: 0x06000D1E RID: 3358 RVA: 0x0000B01F File Offset: 0x0000921F
	public void StartAntiReverse()
	{
		this._antiReverseTime = this._antiReverseDelay;
		this._reverseTime = -this._antiReverseReload;
	}

	// Token: 0x06000D1F RID: 3359 RVA: 0x0000B03A File Offset: 0x0000923A
	public void SetForcePathRecomputing(bool pForce)
	{
		this._forcePathRecomputing = pForce;
	}

	// Token: 0x06000D20 RID: 3360 RVA: 0x0000B043 File Offset: 0x00009243
	public void ForcePathRecomputing()
	{
		this._forcePathRecomputing = true;
	}

	// Token: 0x06000D21 RID: 3361 RVA: 0x0000B04C File Offset: 0x0000924C
	public void SetDriveParameters(float pWantedSteer, float pSpeedBehaviour)
	{
		this._virtualController.setDriveParameters(pWantedSteer, pSpeedBehaviour);
	}

	// Token: 0x06000D22 RID: 3362 RVA: 0x00055D30 File Offset: 0x00053F30
	public void Reset()
	{
		this._pathPosition = PathPosition.UNDEFINED_POSITION;
		this._railTransition = false;
		this._catchMode = false;
		this._forcePathRecomputing = true;
		this._mode = E_AIMode.IDLE_MODE;
		this._previousMode = E_AIMode.IDLE_MODE;
		this._previousRailPoint = Vector3.zero;
		this._drivePriority = 0f;
		this._jamTime = 0f;
		this._reverseTime = 0f;
		this._antiJamTime = 0f;
	}

	// Token: 0x06000D23 RID: 3363 RVA: 0x00055DA4 File Offset: 0x00053FA4
	public void Term()
	{
		RcVehicle vehicle = this.Vehicle;
		vehicle.OnStateChanged = (Action)Delegate.Remove(vehicle.OnStateChanged, new Action(this.EventRaised));
		RcVehicle vehicle2 = this.Vehicle;
		vehicle2.OnAutoPilotChanged = (Action)Delegate.Remove(vehicle2.OnAutoPilotChanged, new Action(this.EventRaised));
	}

	// Token: 0x06000D24 RID: 3364 RVA: 0x00055E00 File Offset: 0x00054000
	public Vector3 GetTargetPoint()
	{
		Vector3 zero = Vector3.zero;
		float num = this.Vehicle.GetWheelSpeedMS() * this._forecastTime;
		if (num < this._minForecastDist)
		{
			num = this._minForecastDist;
		}
		float closestSegmentRatio = this.ClosestSegmentRatio;
		if (closestSegmentRatio > 0f)
		{
			float segmentLength = this.CurrentPath.GetSegmentLength(this.CurrentPathIndex);
			num += segmentLength * closestSegmentRatio;
		}
		this.CurrentPath.GetPosAtDist(this.CurrentPathIndex, ref num, out zero);
		return zero;
	}

	// Token: 0x06000D25 RID: 3365 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void DebugDrawGizmos()
	{
	}

	// Token: 0x06000D26 RID: 3366 RVA: 0x00055E7C File Offset: 0x0005407C
	public virtual void DebugDraw()
	{
		GUI.contentColor = new Color(200f, 200f, 200f);
		GUI.Label(new Rect(20f, 75f, 200f, 20f), "Mode : " + this._mode.ToString());
		GUI.Label(new Rect(20f, 100f, 200f, 20f), "Target Point : " + this.GetTargetPoint().ToString());
		GUI.Label(new Rect(20f, 125f, 200f, 20f), "Path Index : " + this.CurrentPathIndex.ToString());
		GUI.Label(new Rect(20f, 150f, 200f, 20f), "Seg Ratio : " + this.ClosestSegmentRatio.ToString());
		GUI.Label(new Rect(20f, 175f, 200f, 20f), "Pid Output : " + this._pidController.GetOutput().ToString());
		GUI.Label(new Rect(20f, 200f, 200f, 20f), "Steer : " + this._virtualController.GetSteer().ToString());
		GUI.Label(new Rect(20f, 225f, 200f, 20f), "Speed : " + this._virtualController.GetSpeedBehaviour().ToString());
		if (GUI.Button(new Rect(20f, 250f, 40f, 20f), "Respawn"))
		{
			this.Vehicle.Respawn();
		}
	}

	// Token: 0x04000CA0 RID: 3232
	public const int COLLISION_HISTORY_SIZE = 5;

	// Token: 0x04000CA1 RID: 3233
	public const float RAIL_TRANSITION_SPEED_MS = 10f;

	// Token: 0x04000CA2 RID: 3234
	private const float SAMPLING = 200f;

	// Token: 0x04000CA3 RID: 3235
	private RcVirtualController _virtualController;

	// Token: 0x04000CA4 RID: 3236
	protected Vector3 _previousRailPoint = Vector3.zero;

	// Token: 0x04000CA5 RID: 3237
	private RcFastPath _idealPath = new RcFastPath(220);

	// Token: 0x04000CA6 RID: 3238
	protected float _drivePriority;

	// Token: 0x04000CA7 RID: 3239
	protected PathPosition _pathPosition = PathPosition.UNDEFINED_POSITION;

	// Token: 0x04000CA8 RID: 3240
	protected bool _catchMode;

	// Token: 0x04000CA9 RID: 3241
	protected bool _railTransition;

	// Token: 0x04000CAA RID: 3242
	public PidController _pidController;

	// Token: 0x04000CAB RID: 3243
	private E_AIMode _mode;

	// Token: 0x04000CAC RID: 3244
	protected E_AIMode _previousMode;

	// Token: 0x04000CAD RID: 3245
	protected float _jamTime;

	// Token: 0x04000CAE RID: 3246
	protected float _antiJamTime;

	// Token: 0x04000CAF RID: 3247
	protected float _bigJamTime;

	// Token: 0x04000CB0 RID: 3248
	protected float _antiBigJamTime = 5f;

	// Token: 0x04000CB1 RID: 3249
	protected float _reverseTime;

	// Token: 0x04000CB2 RID: 3250
	protected float _antiReverseTime;

	// Token: 0x04000CB3 RID: 3251
	protected Vector3 _capturedPos = Vector3.zero;

	// Token: 0x04000CB4 RID: 3252
	protected float _captureTime;

	// Token: 0x04000CB5 RID: 3253
	protected float _jamSpeed = 3f;

	// Token: 0x04000CB6 RID: 3254
	protected float _collCheck = 0.5f;

	// Token: 0x04000CB7 RID: 3255
	protected float _bigJamSpeed = 3f;

	// Token: 0x04000CB8 RID: 3256
	protected float _bigJameCheck = 3f;

	// Token: 0x04000CB9 RID: 3257
	protected float _antiJamStart = 0.5f;

	// Token: 0x04000CBA RID: 3258
	protected float _antiBigJamStart = 15f;

	// Token: 0x04000CBB RID: 3259
	protected float _antiReverseStart = 1.5f;

	// Token: 0x04000CBC RID: 3260
	protected float _antiJamDelay = 1.5f;

	// Token: 0x04000CBD RID: 3261
	protected float _antiJamReload = 2.2f;

	// Token: 0x04000CBE RID: 3262
	protected float _antiBigJamReload;

	// Token: 0x04000CBF RID: 3263
	protected float _reverseDot = 85f;

	// Token: 0x04000CC0 RID: 3264
	protected float _stopAntiReverseDot = 75f;

	// Token: 0x04000CC1 RID: 3265
	protected float _antiReverseDelay = 1.5f;

	// Token: 0x04000CC2 RID: 3266
	protected float _antiReverseReload = 2.2f;

	// Token: 0x04000CC3 RID: 3267
	protected float _startModeDelay = 2f;

	// Token: 0x04000CC4 RID: 3268
	protected float _startModeTime;

	// Token: 0x04000CC5 RID: 3269
	protected float _lastPathRecomputeTime;

	// Token: 0x04000CC6 RID: 3270
	protected float _closeDistance;

	// Token: 0x04000CC7 RID: 3271
	protected float _farDistance;

	// Token: 0x04000CC8 RID: 3272
	protected float _closeDynamic;

	// Token: 0x04000CC9 RID: 3273
	protected float _closeStatic;

	// Token: 0x04000CCA RID: 3274
	protected float _farDynamic;

	// Token: 0x04000CCB RID: 3275
	protected float _farStatic;

	// Token: 0x04000CCC RID: 3276
	public float _forecastTime = 0.6f;

	// Token: 0x04000CCD RID: 3277
	public float _minForecastDist = 5f;

	// Token: 0x04000CCE RID: 3278
	protected bool _debugInfoOn;

	// Token: 0x04000CCF RID: 3279
	protected bool _forcePathRecomputing;

	// Token: 0x04000CD0 RID: 3280
	protected bool _mobilePathTarget;

	// Token: 0x04000CD1 RID: 3281
	protected E_AILevel _level;
}

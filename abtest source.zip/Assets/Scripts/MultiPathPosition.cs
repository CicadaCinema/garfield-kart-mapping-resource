﻿using System;

// Token: 0x02000200 RID: 512
public struct MultiPathPosition
{
	// Token: 0x06000DDB RID: 3547 RVA: 0x0000B83C File Offset: 0x00009A3C
	public MultiPathPosition(PathPosition p, RcMultiPathSection s)
	{
		this.pathPosition = p;
		this.section = s;
	}

	// Token: 0x170001D7 RID: 471
	// (get) Token: 0x06000DDC RID: 3548 RVA: 0x0000B84C File Offset: 0x00009A4C
	public static MultiPathPosition UNDEFINED_MP_POS
	{
		get
		{
			return new MultiPathPosition(PathPosition.UNDEFINED_POSITION, null);
		}
	}

	// Token: 0x04000D68 RID: 3432
	public PathPosition pathPosition;

	// Token: 0x04000D69 RID: 3433
	public RcMultiPathSection section;
}

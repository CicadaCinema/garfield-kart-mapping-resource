﻿using System;
using UnityEngine;

// Token: 0x020000E8 RID: 232
public class NetworkUfoBonusEntity : NetworkMovableBonusEntity
{
	// Token: 0x06000634 RID: 1588 RVA: 0x00006528 File Offset: 0x00004728
	[RPC]
	public void OnSynchronizeDestroy()
	{
		this.m_pBonusEntity.DoDestroy();
	}

	// Token: 0x06000635 RID: 1589 RVA: 0x00006666 File Offset: 0x00004866
	[RPC]
	public void OnChooseGoodRay(int RandomGood)
	{
		((UFOBonusEntity)this.m_pBonusEntity).DoChooseGoodRay(RandomGood);
	}

	// Token: 0x06000636 RID: 1590 RVA: 0x00006679 File Offset: 0x00004879
	[RPC]
	public void OnLeaveUfo()
	{
		((UFOBonusEntity)this.m_pBonusEntity).DoLeaveUfo();
	}

	// Token: 0x06000637 RID: 1591 RVA: 0x0000668B File Offset: 0x0000488B
	[RPC]
	public void OnSynchronizePosition(float fPos)
	{
		((UFOBonusEntity)this.m_pBonusEntity).DoSynchronizePosition(fPos);
	}

	// Token: 0x06000638 RID: 1592 RVA: 0x0000669E File Offset: 0x0000489E
	[RPC]
	public void OnRemoveUFO(bool bRemove)
	{
		((UFOBonusEntity)this.m_pBonusEntity).DoRemoveUFO(bRemove);
	}

	// Token: 0x06000639 RID: 1593 RVA: 0x000066B1 File Offset: 0x000048B1
	[RPC]
	public void OnSynchronizeUfoLaunch(float Dist, Vector3 LeftPos)
	{
		((UFOBonusEntity)this.m_pBonusEntity).DoSynchronizeUfoLaunch(Dist, LeftPos);
	}
}

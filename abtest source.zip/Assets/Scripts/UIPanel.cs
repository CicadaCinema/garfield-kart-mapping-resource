﻿using System;
using UnityEngine;

// Token: 0x0200007E RID: 126
[AddComponentMenu("NGUI/UI/Panel")]
[ExecuteInEditMode]
public class UIPanel : MonoBehaviour
{
	// Token: 0x170000A0 RID: 160
	// (get) Token: 0x06000368 RID: 872 RVA: 0x00004A5A File Offset: 0x00002C5A
	public GameObject cachedGameObject
	{
		get
		{
			if (this.mGo == null)
			{
				this.mGo = base.gameObject;
			}
			return this.mGo;
		}
	}

	// Token: 0x170000A1 RID: 161
	// (get) Token: 0x06000369 RID: 873 RVA: 0x00004A7F File Offset: 0x00002C7F
	public Transform cachedTransform
	{
		get
		{
			if (this.mTrans == null)
			{
				this.mTrans = base.transform;
			}
			return this.mTrans;
		}
	}

	// Token: 0x170000A2 RID: 162
	// (get) Token: 0x0600036A RID: 874 RVA: 0x00004AA4 File Offset: 0x00002CA4
	// (set) Token: 0x0600036B RID: 875 RVA: 0x0001F24C File Offset: 0x0001D44C
	public float alpha
	{
		get
		{
			return this.mAlpha;
		}
		set
		{
			float num = Mathf.Clamp01(value);
			if (this.mAlpha != num)
			{
				this.mAlpha = num;
				for (int i = 0; i < this.mDrawCalls.size; i++)
				{
					UIDrawCall uidrawCall = this.mDrawCalls[i];
					this.MarkMaterialAsChanged(uidrawCall.material, false);
				}
				for (int j = 0; j < this.mWidgets.size; j++)
				{
					this.mWidgets[j].MarkAsChangedLite();
				}
			}
		}
	}

	// Token: 0x0600036C RID: 876 RVA: 0x0001F2D8 File Offset: 0x0001D4D8
	public void SetAlphaRecursive(float val, bool rebuildList)
	{
		if (rebuildList || this.mChildPanels == null)
		{
			this.mChildPanels = base.GetComponentsInChildren<UIPanel>(true);
		}
		int i = 0;
		int num = this.mChildPanels.Length;
		while (i < num)
		{
			this.mChildPanels[i].alpha = val;
			i++;
		}
	}

	// Token: 0x170000A3 RID: 163
	// (get) Token: 0x0600036D RID: 877 RVA: 0x00004AAC File Offset: 0x00002CAC
	// (set) Token: 0x0600036E RID: 878 RVA: 0x0001F32C File Offset: 0x0001D52C
	public UIPanel.DebugInfo debugInfo
	{
		get
		{
			return this.mDebugInfo;
		}
		set
		{
			if (this.mDebugInfo != value)
			{
				this.mDebugInfo = value;
				BetterList<UIDrawCall> drawCalls = this.drawCalls;
				HideFlags hideFlags = (this.mDebugInfo != UIPanel.DebugInfo.Geometry) ? HideFlags.HideAndDontSave : (HideFlags.DontSave | HideFlags.NotEditable);
				int i = 0;
				int size = drawCalls.size;
				while (i < size)
				{
					UIDrawCall uidrawCall = drawCalls[i];
					GameObject gameObject = uidrawCall.gameObject;
					NGUITools.SetActiveSelf(gameObject, false);
					gameObject.hideFlags = hideFlags;
					NGUITools.SetActiveSelf(gameObject, true);
					i++;
				}
			}
		}
	}

	// Token: 0x170000A4 RID: 164
	// (get) Token: 0x0600036F RID: 879 RVA: 0x00004AB4 File Offset: 0x00002CB4
	// (set) Token: 0x06000370 RID: 880 RVA: 0x00004ABC File Offset: 0x00002CBC
	public UIDrawCall.Clipping clipping
	{
		get
		{
			return this.mClipping;
		}
		set
		{
			if (this.mClipping != value)
			{
				this.mClipping = value;
				this.mMatrixTime = 0f;
				this.UpdateDrawcalls();
			}
		}
	}

	// Token: 0x170000A5 RID: 165
	// (get) Token: 0x06000371 RID: 881 RVA: 0x00004AE2 File Offset: 0x00002CE2
	// (set) Token: 0x06000372 RID: 882 RVA: 0x0001F3AC File Offset: 0x0001D5AC
	public Vector4 clipRange
	{
		get
		{
			return this.mClipRange;
		}
		set
		{
			if (this.mClipRange != value)
			{
				this.mCullTime = ((this.mCullTime != 0f) ? (Time.realtimeSinceStartup + 0.15f) : 0.001f);
				this.mClipRange = value;
				this.mMatrixTime = 0f;
				this.UpdateDrawcalls();
			}
		}
	}

	// Token: 0x170000A6 RID: 166
	// (get) Token: 0x06000373 RID: 883 RVA: 0x00004AEA File Offset: 0x00002CEA
	// (set) Token: 0x06000374 RID: 884 RVA: 0x00004AF2 File Offset: 0x00002CF2
	public Vector2 clipSoftness
	{
		get
		{
			return this.mClipSoftness;
		}
		set
		{
			if (this.mClipSoftness != value)
			{
				this.mClipSoftness = value;
				this.UpdateDrawcalls();
			}
		}
	}

	// Token: 0x170000A7 RID: 167
	// (get) Token: 0x06000375 RID: 885 RVA: 0x00004B12 File Offset: 0x00002D12
	public BetterList<UIWidget> widgets
	{
		get
		{
			return this.mWidgets;
		}
	}

	// Token: 0x170000A8 RID: 168
	// (get) Token: 0x06000376 RID: 886 RVA: 0x0001F410 File Offset: 0x0001D610
	public BetterList<UIDrawCall> drawCalls
	{
		get
		{
			int i = this.mDrawCalls.size;
			while (i > 0)
			{
				UIDrawCall x = this.mDrawCalls[--i];
				if (x == null)
				{
					this.mDrawCalls.RemoveAt(i);
				}
			}
			return this.mDrawCalls;
		}
	}

	// Token: 0x06000377 RID: 887 RVA: 0x0001F464 File Offset: 0x0001D664
	private bool IsVisible(Vector3 a, Vector3 b, Vector3 c, Vector3 d)
	{
		this.UpdateTransformMatrix();
		a = this.worldToLocal.MultiplyPoint3x4(a);
		b = this.worldToLocal.MultiplyPoint3x4(b);
		c = this.worldToLocal.MultiplyPoint3x4(c);
		d = this.worldToLocal.MultiplyPoint3x4(d);
		UIPanel.mTemp[0] = a.x;
		UIPanel.mTemp[1] = b.x;
		UIPanel.mTemp[2] = c.x;
		UIPanel.mTemp[3] = d.x;
		float num = Mathf.Min(UIPanel.mTemp);
		float num2 = Mathf.Max(UIPanel.mTemp);
		UIPanel.mTemp[0] = a.y;
		UIPanel.mTemp[1] = b.y;
		UIPanel.mTemp[2] = c.y;
		UIPanel.mTemp[3] = d.y;
		float num3 = Mathf.Min(UIPanel.mTemp);
		float num4 = Mathf.Max(UIPanel.mTemp);
		return num2 >= this.mMin.x && num4 >= this.mMin.y && num <= this.mMax.x && num3 <= this.mMax.y;
	}

	// Token: 0x06000378 RID: 888 RVA: 0x0001F59C File Offset: 0x0001D79C
	public bool IsVisible(Vector3 worldPos)
	{
		if (this.mAlpha < 0.001f)
		{
			return false;
		}
		if (this.mClipping == UIDrawCall.Clipping.None)
		{
			return true;
		}
		this.UpdateTransformMatrix();
		Vector3 vector = this.worldToLocal.MultiplyPoint3x4(worldPos);
		return vector.x >= this.mMin.x && vector.y >= this.mMin.y && vector.x <= this.mMax.x && vector.y <= this.mMax.y;
	}

	// Token: 0x06000379 RID: 889 RVA: 0x0001F640 File Offset: 0x0001D840
	public bool IsVisible(UIWidget w)
	{
		if (this.mAlpha < 0.001f)
		{
			return false;
		}
		if (!w.enabled || !NGUITools.GetActive(w.cachedGameObject) || w.alpha < 0.001f)
		{
			return false;
		}
		if (this.mClipping == UIDrawCall.Clipping.None)
		{
			return true;
		}
		Vector2 relativeSize = w.relativeSize;
		Vector2 vector = Vector2.Scale(w.pivotOffset, relativeSize);
		Vector2 v = vector;
		vector.x += relativeSize.x;
		vector.y -= relativeSize.y;
		Transform cachedTransform = w.cachedTransform;
		Vector3 a = cachedTransform.TransformPoint(vector);
		Vector3 b = cachedTransform.TransformPoint(new Vector2(vector.x, v.y));
		Vector3 c = cachedTransform.TransformPoint(new Vector2(v.x, vector.y));
		Vector3 d = cachedTransform.TransformPoint(v);
		return this.IsVisible(a, b, c, d);
	}

	// Token: 0x0600037A RID: 890 RVA: 0x00004B1A File Offset: 0x00002D1A
	public void MarkMaterialAsChanged(Material mat, bool sort)
	{
		if (mat != null)
		{
			if (sort)
			{
				this.mDepthChanged = true;
			}
			if (!this.mChanged.Contains(mat))
			{
				this.mChanged.Add(mat);
			}
		}
	}

	// Token: 0x0600037B RID: 891 RVA: 0x0001F74C File Offset: 0x0001D94C
	public void AddWidget(UIWidget w)
	{
		if (w != null && !this.mWidgets.Contains(w))
		{
			this.mWidgets.Add(w);
			if (!this.mChanged.Contains(w.material))
			{
				this.mChanged.Add(w.material);
			}
			this.mDepthChanged = true;
		}
	}

	// Token: 0x0600037C RID: 892 RVA: 0x0001F7B0 File Offset: 0x0001D9B0
	public void RemoveWidget(UIWidget w)
	{
		if (w != null && w != null && this.mWidgets.Remove(w) && w.material != null)
		{
			this.mChanged.Add(w.material);
		}
	}

	// Token: 0x0600037D RID: 893 RVA: 0x0001F808 File Offset: 0x0001DA08
	private UIDrawCall GetDrawCall(Material mat, bool createIfMissing)
	{
		int i = 0;
		int size = this.drawCalls.size;
		while (i < size)
		{
			UIDrawCall uidrawCall = this.drawCalls.buffer[i];
			if (uidrawCall.material == mat)
			{
				return uidrawCall;
			}
			i++;
		}
		UIDrawCall uidrawCall2 = null;
		if (createIfMissing)
		{
			GameObject gameObject = new GameObject("_UIDrawCall [" + mat.name + "]");
			UnityEngine.Object.DontDestroyOnLoad(gameObject);
			gameObject.layer = this.cachedGameObject.layer;
			uidrawCall2 = gameObject.AddComponent<UIDrawCall>();
			uidrawCall2.material = mat;
			this.mDrawCalls.Add(uidrawCall2);
		}
		return uidrawCall2;
	}

	// Token: 0x0600037E RID: 894 RVA: 0x00004B52 File Offset: 0x00002D52
	private void Awake()
	{
		this.mGo = base.gameObject;
		this.mTrans = base.transform;
	}

	// Token: 0x0600037F RID: 895 RVA: 0x0001F8B0 File Offset: 0x0001DAB0
	private void Start()
	{
		this.mLayer = this.mGo.layer;
		UICamera uicamera = UICamera.FindCameraForLayer(this.mLayer);
		this.mCam = ((!(uicamera != null)) ? NGUITools.FindCameraForLayer(this.mLayer) : uicamera.cachedCamera);
	}

	// Token: 0x06000380 RID: 896 RVA: 0x0001F904 File Offset: 0x0001DB04
	private void OnEnable()
	{
		int i = 0;
		while (i < this.mWidgets.size)
		{
			UIWidget uiwidget = this.mWidgets.buffer[i];
			if (uiwidget != null)
			{
				this.MarkMaterialAsChanged(uiwidget.material, true);
				i++;
			}
			else
			{
				this.mWidgets.RemoveAt(i);
			}
		}
	}

	// Token: 0x06000381 RID: 897 RVA: 0x0001F968 File Offset: 0x0001DB68
	private void OnDisable()
	{
		int i = this.mDrawCalls.size;
		while (i > 0)
		{
			UIDrawCall uidrawCall = this.mDrawCalls.buffer[--i];
			if (uidrawCall != null)
			{
				NGUITools.DestroyImmediate(uidrawCall.gameObject);
			}
		}
		this.mDrawCalls.Clear();
		this.mChanged.Clear();
	}

	// Token: 0x06000382 RID: 898 RVA: 0x0001F9CC File Offset: 0x0001DBCC
	private void UpdateTransformMatrix()
	{
		if (this.mUpdateTime == 0f || this.mMatrixTime != this.mUpdateTime)
		{
			this.mMatrixTime = this.mUpdateTime;
			this.worldToLocal = this.cachedTransform.worldToLocalMatrix;
			if (this.mClipping != UIDrawCall.Clipping.None)
			{
				Vector2 a = new Vector2(this.mClipRange.z, this.mClipRange.w);
				if (a.x == 0f)
				{
					a.x = ((!(this.mCam == null)) ? this.mCam.pixelWidth : ((float)Screen.width));
				}
				if (a.y == 0f)
				{
					a.y = ((!(this.mCam == null)) ? this.mCam.pixelHeight : ((float)Screen.height));
				}
				a *= 0.5f;
				this.mMin.x = this.mClipRange.x - a.x;
				this.mMin.y = this.mClipRange.y - a.y;
				this.mMax.x = this.mClipRange.x + a.x;
				this.mMax.y = this.mClipRange.y + a.y;
			}
		}
	}

	// Token: 0x06000383 RID: 899 RVA: 0x0001FB44 File Offset: 0x0001DD44
	public void UpdateDrawcalls()
	{
		Vector4 zero = Vector4.zero;
		if (this.mClipping != UIDrawCall.Clipping.None)
		{
			zero = new Vector4(this.mClipRange.x, this.mClipRange.y, this.mClipRange.z * 0.5f, this.mClipRange.w * 0.5f);
		}
		if (zero.z == 0f)
		{
			zero.z = (float)Screen.width * 0.5f;
		}
		if (zero.w == 0f)
		{
			zero.w = (float)Screen.height * 0.5f;
		}
		RuntimePlatform platform = Application.platform;
		if (platform == RuntimePlatform.WindowsPlayer || platform == RuntimePlatform.WindowsWebPlayer || platform == RuntimePlatform.WindowsEditor)
		{
			zero.x -= 0.5f;
			zero.y += 0.5f;
		}
		Transform cachedTransform = this.cachedTransform;
		int i = 0;
		int size = this.mDrawCalls.size;
		while (i < size)
		{
			UIDrawCall uidrawCall = this.mDrawCalls.buffer[i];
			uidrawCall.clipping = this.mClipping;
			uidrawCall.clipRange = zero;
			uidrawCall.clipSoftness = this.mClipSoftness;
			uidrawCall.depthPass = (this.depthPass && this.mClipping == UIDrawCall.Clipping.None);
			Transform transform = uidrawCall.transform;
			transform.position = cachedTransform.position;
			transform.rotation = cachedTransform.rotation;
			transform.localScale = cachedTransform.lossyScale;
			i++;
		}
	}

	// Token: 0x06000384 RID: 900 RVA: 0x0001FCD0 File Offset: 0x0001DED0
	private void Fill(Material mat)
	{
		int i = 0;
		while (i < this.mWidgets.size)
		{
			UIWidget uiwidget = this.mWidgets.buffer[i];
			if (uiwidget == null)
			{
				this.mWidgets.RemoveAt(i);
			}
			else
			{
				if (uiwidget.material == mat && uiwidget.isVisible)
				{
					if (!(uiwidget.panel == this))
					{
						this.mWidgets.RemoveAt(i);
						continue;
					}
					if (this.generateNormals)
					{
						uiwidget.WriteToBuffers(this.mVerts, this.mUvs, this.mCols, this.mNorms, this.mTans);
					}
					else
					{
						uiwidget.WriteToBuffers(this.mVerts, this.mUvs, this.mCols, null, null);
					}
				}
				i++;
			}
		}
		if (this.mVerts.size > 0)
		{
			UIDrawCall drawCall = this.GetDrawCall(mat, true);
			drawCall.depthPass = (this.depthPass && this.mClipping == UIDrawCall.Clipping.None);
			drawCall.Set(this.mVerts, (!this.generateNormals) ? null : this.mNorms, (!this.generateNormals) ? null : this.mTans, this.mUvs, this.mCols);
		}
		else
		{
			UIDrawCall drawCall2 = this.GetDrawCall(mat, false);
			if (drawCall2 != null)
			{
				this.mDrawCalls.Remove(drawCall2);
				NGUITools.DestroyImmediate(drawCall2.gameObject);
			}
		}
		this.mVerts.Clear();
		this.mNorms.Clear();
		this.mTans.Clear();
		this.mUvs.Clear();
		this.mCols.Clear();
	}

	// Token: 0x06000385 RID: 901 RVA: 0x0001FE9C File Offset: 0x0001E09C
	private void LateUpdate()
	{
		this.mUpdateTime = Time.realtimeSinceStartup;
		this.UpdateTransformMatrix();
		if (this.mLayer != this.cachedGameObject.layer)
		{
			this.mLayer = this.mGo.layer;
			UICamera uicamera = UICamera.FindCameraForLayer(this.mLayer);
			this.mCam = ((!(uicamera != null)) ? NGUITools.FindCameraForLayer(this.mLayer) : uicamera.cachedCamera);
			UIPanel.SetChildLayer(this.cachedTransform, this.mLayer);
			int i = 0;
			int size = this.drawCalls.size;
			while (i < size)
			{
				this.mDrawCalls.buffer[i].gameObject.layer = this.mLayer;
				i++;
			}
		}
		bool forceVisible = !this.cullWhileDragging && (this.clipping == UIDrawCall.Clipping.None || this.mCullTime > this.mUpdateTime);
		int j = 0;
		int size2 = this.mWidgets.size;
		while (j < size2)
		{
			UIWidget uiwidget = this.mWidgets[j];
			if (uiwidget.UpdateGeometry(this, forceVisible) && !this.mChanged.Contains(uiwidget.material))
			{
				this.mChanged.Add(uiwidget.material);
			}
			j++;
		}
		if (this.mChanged.size != 0 && this.onChange != null)
		{
			this.onChange();
		}
		if (this.mDepthChanged)
		{
			this.mDepthChanged = false;
			this.mWidgets.Sort(new Comparison<UIWidget>(UIWidget.CompareFunc));
		}
		int k = 0;
		int size3 = this.mChanged.size;
		while (k < size3)
		{
			this.Fill(this.mChanged.buffer[k]);
			k++;
		}
		this.UpdateDrawcalls();
		this.mChanged.Clear();
	}

	// Token: 0x06000386 RID: 902 RVA: 0x00020094 File Offset: 0x0001E294
	public void Refresh()
	{
		UIWidget[] componentsInChildren = base.GetComponentsInChildren<UIWidget>();
		int i = 0;
		int num = componentsInChildren.Length;
		while (i < num)
		{
			componentsInChildren[i].Update();
			i++;
		}
		this.LateUpdate();
	}

	// Token: 0x06000387 RID: 903 RVA: 0x000200CC File Offset: 0x0001E2CC
	public Vector3 CalculateConstrainOffset(Vector2 min, Vector2 max)
	{
		float num = this.clipRange.z * 0.5f;
		float num2 = this.clipRange.w * 0.5f;
		Vector2 minRect = new Vector2(min.x, min.y);
		Vector2 maxRect = new Vector2(max.x, max.y);
		Vector2 minArea = new Vector2(this.clipRange.x - num, this.clipRange.y - num2);
		Vector2 maxArea = new Vector2(this.clipRange.x + num, this.clipRange.y + num2);
		if (this.clipping == UIDrawCall.Clipping.SoftClip)
		{
			minArea.x += this.clipSoftness.x;
			minArea.y += this.clipSoftness.y;
			maxArea.x -= this.clipSoftness.x;
			maxArea.y -= this.clipSoftness.y;
		}
		return NGUIMath.ConstrainRect(minRect, maxRect, minArea, maxArea);
	}

	// Token: 0x06000388 RID: 904 RVA: 0x00020214 File Offset: 0x0001E414
	public bool ConstrainTargetToBounds(Transform target, ref Bounds targetBounds, bool immediate)
	{
		Vector3 b = this.CalculateConstrainOffset(targetBounds.min, targetBounds.max);
		if (b.magnitude > 0f)
		{
			if (immediate)
			{
				target.localPosition += b;
				targetBounds.center += b;
				SpringPosition component = target.GetComponent<SpringPosition>();
				if (component != null)
				{
					component.enabled = false;
				}
			}
			else
			{
				SpringPosition springPosition = SpringPosition.Begin(target.gameObject, target.localPosition + b, 13f);
				springPosition.ignoreTimeScale = true;
				springPosition.worldSpace = false;
			}
			return true;
		}
		return false;
	}

	// Token: 0x06000389 RID: 905 RVA: 0x000202C8 File Offset: 0x0001E4C8
	public bool ConstrainTargetToBounds(Transform target, bool immediate)
	{
		Bounds bounds = NGUIMath.CalculateRelativeWidgetBounds(this.cachedTransform, target);
		return this.ConstrainTargetToBounds(target, ref bounds, immediate);
	}

	// Token: 0x0600038A RID: 906 RVA: 0x000202EC File Offset: 0x0001E4EC
	private static void SetChildLayer(Transform t, int layer)
	{
		for (int i = 0; i < t.childCount; i++)
		{
			Transform child = t.GetChild(i);
			if (child.GetComponent<UIPanel>() == null)
			{
				if (child.GetComponent<UIWidget>() != null)
				{
					child.gameObject.layer = layer;
				}
				UIPanel.SetChildLayer(child, layer);
			}
		}
	}

	// Token: 0x0600038B RID: 907 RVA: 0x00020350 File Offset: 0x0001E550
	public static UIPanel Find(Transform trans, bool createIfMissing)
	{
		Transform y = trans;
		UIPanel uipanel = null;
		while (uipanel == null && trans != null)
		{
			uipanel = trans.GetComponent<UIPanel>();
			if (uipanel != null)
			{
				break;
			}
			if (trans.parent == null)
			{
				break;
			}
			trans = trans.parent;
		}
		if (createIfMissing && uipanel == null && trans != y)
		{
			uipanel = trans.gameObject.AddComponent<UIPanel>();
			UIPanel.SetChildLayer(uipanel.cachedTransform, uipanel.cachedGameObject.layer);
		}
		return uipanel;
	}

	// Token: 0x0600038C RID: 908 RVA: 0x00004B6C File Offset: 0x00002D6C
	public static UIPanel Find(Transform trans)
	{
		return UIPanel.Find(trans, true);
	}

	// Token: 0x040002EC RID: 748
	public UIPanel.OnChangeDelegate onChange;

	// Token: 0x040002ED RID: 749
	public bool showInPanelTool = true;

	// Token: 0x040002EE RID: 750
	public bool generateNormals;

	// Token: 0x040002EF RID: 751
	public bool depthPass;

	// Token: 0x040002F0 RID: 752
	public bool widgetsAreStatic;

	// Token: 0x040002F1 RID: 753
	public bool cullWhileDragging;

	// Token: 0x040002F2 RID: 754
	[HideInInspector]
	public Matrix4x4 worldToLocal = Matrix4x4.identity;

	// Token: 0x040002F3 RID: 755
	[SerializeField]
	[HideInInspector]
	private float mAlpha = 1f;

	// Token: 0x040002F4 RID: 756
	[HideInInspector]
	[SerializeField]
	private UIPanel.DebugInfo mDebugInfo = UIPanel.DebugInfo.Gizmos;

	// Token: 0x040002F5 RID: 757
	[SerializeField]
	[HideInInspector]
	private UIDrawCall.Clipping mClipping;

	// Token: 0x040002F6 RID: 758
	[SerializeField]
	[HideInInspector]
	private Vector4 mClipRange = Vector4.zero;

	// Token: 0x040002F7 RID: 759
	[SerializeField]
	[HideInInspector]
	private Vector2 mClipSoftness = new Vector2(40f, 40f);

	// Token: 0x040002F8 RID: 760
	private BetterList<UIWidget> mWidgets = new BetterList<UIWidget>();

	// Token: 0x040002F9 RID: 761
	private BetterList<Material> mChanged = new BetterList<Material>();

	// Token: 0x040002FA RID: 762
	private BetterList<UIDrawCall> mDrawCalls = new BetterList<UIDrawCall>();

	// Token: 0x040002FB RID: 763
	private BetterList<Vector3> mVerts = new BetterList<Vector3>();

	// Token: 0x040002FC RID: 764
	private BetterList<Vector3> mNorms = new BetterList<Vector3>();

	// Token: 0x040002FD RID: 765
	private BetterList<Vector4> mTans = new BetterList<Vector4>();

	// Token: 0x040002FE RID: 766
	private BetterList<Vector2> mUvs = new BetterList<Vector2>();

	// Token: 0x040002FF RID: 767
	private BetterList<Color32> mCols = new BetterList<Color32>();

	// Token: 0x04000300 RID: 768
	private GameObject mGo;

	// Token: 0x04000301 RID: 769
	private Transform mTrans;

	// Token: 0x04000302 RID: 770
	private Camera mCam;

	// Token: 0x04000303 RID: 771
	private int mLayer = -1;

	// Token: 0x04000304 RID: 772
	private bool mDepthChanged;

	// Token: 0x04000305 RID: 773
	private float mCullTime;

	// Token: 0x04000306 RID: 774
	private float mUpdateTime;

	// Token: 0x04000307 RID: 775
	private float mMatrixTime;

	// Token: 0x04000308 RID: 776
	private static float[] mTemp = new float[4];

	// Token: 0x04000309 RID: 777
	private Vector2 mMin = Vector2.zero;

	// Token: 0x0400030A RID: 778
	private Vector2 mMax = Vector2.zero;

	// Token: 0x0400030B RID: 779
	private UIPanel[] mChildPanels;

	// Token: 0x0200007F RID: 127
	public enum DebugInfo
	{
		// Token: 0x0400030D RID: 781
		None,
		// Token: 0x0400030E RID: 782
		Gizmos,
		// Token: 0x0400030F RID: 783
		Geometry
	}

	// Token: 0x02000080 RID: 128
	// (Invoke) Token: 0x0600038E RID: 910
	public delegate void OnChangeDelegate();
}

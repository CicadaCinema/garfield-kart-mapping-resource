﻿using System;
using UnityEngine;

// Token: 0x020000FE RID: 254
public class AbstractPopup : MonoBehaviour
{
	// Token: 0x060006E3 RID: 1763 RVA: 0x00006DCC File Offset: 0x00004FCC
	public virtual void Awake()
	{
		this.m_pMenuEntryPoint = GameObject.Find("MenuEntryPoint").GetComponent<MenuEntryPoint>();
		base.transform.gameObject.SetActive(false);
	}

	// Token: 0x060006E4 RID: 1764 RVA: 0x00006DF4 File Offset: 0x00004FF4
	public virtual void Show(string _TextId)
	{
		if (this.Text != null && _TextId != null)
		{
			this.Text.key = _TextId;
		}
		base.gameObject.SetActive(true);
	}

	// Token: 0x060006E5 RID: 1765 RVA: 0x00006D1D File Offset: 0x00004F1D
	public void Hide()
	{
		base.gameObject.SetActive(false);
	}

	// Token: 0x060006E6 RID: 1766 RVA: 0x00006E25 File Offset: 0x00005025
	public void OnQuit()
	{
		this.m_pMenuEntryPoint.QuitPopup();
	}

	// Token: 0x040006C9 RID: 1737
	protected MenuEntryPoint m_pMenuEntryPoint;

	// Token: 0x040006CA RID: 1738
	public UILocalize Text;
}

﻿using System;

// Token: 0x02000240 RID: 576
public class RandomManager : Singleton<RandomManager>
{
	// Token: 0x06001016 RID: 4118 RVA: 0x0000CD7B File Offset: 0x0000AF7B
	public void Init()
	{
		this._random = new Random();
	}

	// Token: 0x06001017 RID: 4119 RVA: 0x0000CD88 File Offset: 0x0000AF88
	public int Next()
	{
		return this._random.Next();
	}

	// Token: 0x06001018 RID: 4120 RVA: 0x0000CD95 File Offset: 0x0000AF95
	public int Next(int pMaxValue)
	{
		return this._random.Next(pMaxValue + 1);
	}

	// Token: 0x06001019 RID: 4121 RVA: 0x0000CDA5 File Offset: 0x0000AFA5
	public int Next(int pMinValue, int pMaxValue)
	{
		return this._random.Next(pMinValue, pMaxValue + 1);
	}

	// Token: 0x0600101A RID: 4122 RVA: 0x0000CDB6 File Offset: 0x0000AFB6
	public double NextDouble()
	{
		return this._random.NextDouble();
	}

	// Token: 0x04000F7F RID: 3967
	private Random _random = new Random();
}

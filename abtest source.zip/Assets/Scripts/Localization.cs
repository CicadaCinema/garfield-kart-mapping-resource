﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000043 RID: 67
[AddComponentMenu("NGUI/Internal/Localization")]
public class Localization : MonoBehaviour
{
	// Token: 0x17000032 RID: 50
	// (get) Token: 0x06000171 RID: 369 RVA: 0x0000329E File Offset: 0x0000149E
	public static bool isActive
	{
		get
		{
			return Localization.mInstance != null;
		}
	}

	// Token: 0x17000033 RID: 51
	// (get) Token: 0x06000172 RID: 370 RVA: 0x000145F4 File Offset: 0x000127F4
	public static Localization instance
	{
		get
		{
			if (Localization.mInstance == null)
			{
				Localization.mInstance = (UnityEngine.Object.FindObjectOfType(typeof(Localization)) as Localization);
				if (Localization.mInstance == null)
				{
					GameObject gameObject = new GameObject("_Localization");
					UnityEngine.Object.DontDestroyOnLoad(gameObject);
					Localization.mInstance = gameObject.AddComponent<Localization>();
				}
			}
			return Localization.mInstance;
		}
	}

	// Token: 0x17000034 RID: 52
	// (get) Token: 0x06000173 RID: 371 RVA: 0x000032AB File Offset: 0x000014AB
	// (set) Token: 0x06000174 RID: 372 RVA: 0x0001465C File Offset: 0x0001285C
	public string currentLanguage
	{
		get
		{
			return this.mLanguage;
		}
		set
		{
			if (this.mLanguage != value)
			{
				this.startingLanguage = value;
				if (!string.IsNullOrEmpty(value))
				{
					if (this.languages != null)
					{
						int i = 0;
						int num = this.languages.Length;
						while (i < num)
						{
							TextAsset textAsset = this.languages[i];
							if (textAsset != null && textAsset.name == value)
							{
								this.Load(textAsset);
								return;
							}
							i++;
						}
					}
					TextAsset textAsset2 = Resources.Load(value, typeof(TextAsset)) as TextAsset;
					if (textAsset2 != null)
					{
						this.Load(textAsset2);
						return;
					}
				}
				this.mDictionary.Clear();
				PlayerPrefs.DeleteKey("Language");
			}
		}
	}

	// Token: 0x06000175 RID: 373 RVA: 0x00014720 File Offset: 0x00012920
	private void Awake()
	{
		if (Localization.mInstance == null)
		{
			Localization.mInstance = this;
			UnityEngine.Object.DontDestroyOnLoad(base.gameObject);
			this.currentLanguage = PlayerPrefs.GetString("Language", this.startingLanguage);
			if (string.IsNullOrEmpty(this.mLanguage) && this.languages != null && this.languages.Length > 0)
			{
				this.currentLanguage = this.languages[0].name;
			}
		}
		else
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}
	}

	// Token: 0x06000176 RID: 374 RVA: 0x000032B3 File Offset: 0x000014B3
	private void OnEnable()
	{
		if (Localization.mInstance == null)
		{
			Localization.mInstance = this;
		}
	}

	// Token: 0x06000177 RID: 375 RVA: 0x000032CB File Offset: 0x000014CB
	private void OnDestroy()
	{
		if (Localization.mInstance == this)
		{
			Localization.mInstance = null;
		}
	}

	// Token: 0x06000178 RID: 376 RVA: 0x000147B0 File Offset: 0x000129B0
	private void Load(TextAsset asset)
	{
		this.mLanguage = asset.name;
		PlayerPrefs.SetString("Language", this.mLanguage);
		ByteReader byteReader = new ByteReader(asset);
		this.mDictionary = byteReader.ReadDictionary();
		UIRoot.Broadcast("OnLocalize", this);
	}

	// Token: 0x06000179 RID: 377 RVA: 0x000147F8 File Offset: 0x000129F8
	public string Get(string key)
	{
		string text;
		return (!this.mDictionary.TryGetValue(key, out text)) ? key : text;
	}

	// Token: 0x0600017A RID: 378 RVA: 0x000032E3 File Offset: 0x000014E3
	public static string Localize(string key)
	{
		return (!(Localization.instance != null)) ? key : Localization.instance.Get(key);
	}

	// Token: 0x0400017E RID: 382
	private static Localization mInstance;

	// Token: 0x0400017F RID: 383
	public string startingLanguage = "English";

	// Token: 0x04000180 RID: 384
	public TextAsset[] languages;

	// Token: 0x04000181 RID: 385
	private Dictionary<string, string> mDictionary = new Dictionary<string, string>();

	// Token: 0x04000182 RID: 386
	private string mLanguage;
}

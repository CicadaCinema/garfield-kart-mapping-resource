﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000213 RID: 531
public class RcPhysicWheel : MonoBehaviour
{
	// Token: 0x06000EAA RID: 3754 RVA: 0x0000C18E File Offset: 0x0000A38E
	public void Awake()
	{
		if (this.m_pWheelMeshTransform == null)
		{
			this.m_pWheelMeshTransform = base.transform;
		}
	}

	// Token: 0x06000EAB RID: 3755 RVA: 0x0005D384 File Offset: 0x0005B584
	public virtual void Start()
	{
		this.m_fAnimDistance = 6.28318548f * this.m_fRadius;
		Renderer[] componentsInChildren = this.m_pVehicleTransform.GetComponentsInChildren<Renderer>();
		this.m_pWheelMaterial.Clear();
		foreach (Renderer renderer in componentsInChildren)
		{
			foreach (Material material in renderer.materials)
			{
				if (material.name.Contains(this.materialSuffix))
				{
					this.m_pWheelMaterial.Add(material);
					break;
				}
			}
		}
	}

	// Token: 0x170001DF RID: 479
	// (set) Token: 0x06000EAC RID: 3756 RVA: 0x0000C1AD File Offset: 0x0000A3AD
	public Vector3 VMaxSqueeze
	{
		set
		{
			this.m_vMaxSqueeze = value;
		}
	}

	// Token: 0x170001E0 RID: 480
	// (get) Token: 0x06000EAD RID: 3757 RVA: 0x0000C1B6 File Offset: 0x0000A3B6
	public bool BOnGround
	{
		get
		{
			return this.m_bOnGround;
		}
	}

	// Token: 0x170001E1 RID: 481
	// (get) Token: 0x06000EAE RID: 3758 RVA: 0x0000C1BE File Offset: 0x0000A3BE
	// (set) Token: 0x06000EAF RID: 3759 RVA: 0x0000C1C6 File Offset: 0x0000A3C6
	public float FGripFactor
	{
		get
		{
			return this.m_fGripFactor;
		}
		set
		{
			this.m_fGripFactor = value;
		}
	}

	// Token: 0x170001E2 RID: 482
	// (get) Token: 0x06000EB0 RID: 3760 RVA: 0x0000C1CF File Offset: 0x0000A3CF
	// (set) Token: 0x06000EB1 RID: 3761 RVA: 0x0000C1D7 File Offset: 0x0000A3D7
	public float FForwardGrip
	{
		get
		{
			return this.m_fForwardGrip;
		}
		set
		{
			this.m_fForwardGrip = value;
		}
	}

	// Token: 0x170001E3 RID: 483
	// (get) Token: 0x06000EB2 RID: 3762 RVA: 0x0000C1E0 File Offset: 0x0000A3E0
	// (set) Token: 0x06000EB3 RID: 3763 RVA: 0x0000C1E8 File Offset: 0x0000A3E8
	public float FHandBrake
	{
		get
		{
			return this.m_fHandBrake;
		}
		set
		{
			this.m_fHandBrake = value;
		}
	}

	// Token: 0x170001E4 RID: 484
	// (get) Token: 0x06000EB4 RID: 3764 RVA: 0x0000C1F1 File Offset: 0x0000A3F1
	// (set) Token: 0x06000EB5 RID: 3765 RVA: 0x0000C1F9 File Offset: 0x0000A3F9
	public float FSideGrip
	{
		get
		{
			return this.m_fSideGrip;
		}
		set
		{
			this.m_fSideGrip = value;
		}
	}

	// Token: 0x170001E5 RID: 485
	// (get) Token: 0x06000EB6 RID: 3766 RVA: 0x0000C202 File Offset: 0x0000A402
	public bool BMotorOn
	{
		get
		{
			return this.m_bMotorOn;
		}
	}

	// Token: 0x170001E6 RID: 486
	// (get) Token: 0x06000EB7 RID: 3767 RVA: 0x0000C20A File Offset: 0x0000A40A
	public Vector2 VCollisionGrip
	{
		get
		{
			return this.m_vCollisionGrip;
		}
	}

	// Token: 0x170001E7 RID: 487
	// (get) Token: 0x06000EB8 RID: 3768 RVA: 0x0000C212 File Offset: 0x0000A412
	public Vector2 VDriftGrip
	{
		get
		{
			return this.m_vDriftGrip;
		}
	}

	// Token: 0x170001E8 RID: 488
	// (get) Token: 0x06000EB9 RID: 3769 RVA: 0x0000C21A File Offset: 0x0000A41A
	public Vector2 VNormalGrip
	{
		get
		{
			return this.m_vNormalGrip;
		}
	}

	// Token: 0x170001E9 RID: 489
	// (get) Token: 0x06000EBA RID: 3770 RVA: 0x0000C222 File Offset: 0x0000A422
	// (set) Token: 0x06000EBB RID: 3771 RVA: 0x0000C22A File Offset: 0x0000A42A
	public float FSideSlip
	{
		get
		{
			return this.m_fSideSlip;
		}
		set
		{
			this.m_fSideSlip = value;
		}
	}

	// Token: 0x170001EA RID: 490
	// (get) Token: 0x06000EBC RID: 3772 RVA: 0x0000C233 File Offset: 0x0000A433
	// (set) Token: 0x06000EBD RID: 3773 RVA: 0x0000C23B File Offset: 0x0000A43B
	public float FSurfaceNoise
	{
		get
		{
			return this.m_fSurfaceNoise;
		}
		set
		{
			this.m_fSurfaceNoise = value;
		}
	}

	// Token: 0x170001EB RID: 491
	// (get) Token: 0x06000EBE RID: 3774 RVA: 0x0000C244 File Offset: 0x0000A444
	public float FStretch
	{
		get
		{
			return this.m_fStretch;
		}
	}

	// Token: 0x170001EC RID: 492
	// (get) Token: 0x06000EBF RID: 3775 RVA: 0x0000C24C File Offset: 0x0000A44C
	public GroundCharac OGroundCharac
	{
		get
		{
			return this.m_oGroundCharac;
		}
	}

	// Token: 0x170001ED RID: 493
	// (get) Token: 0x06000EC0 RID: 3776 RVA: 0x0000C254 File Offset: 0x0000A454
	// (set) Token: 0x06000EC1 RID: 3777 RVA: 0x0000C25C File Offset: 0x0000A45C
	public bool BSteeringOn
	{
		get
		{
			return this.m_bSteeringOn;
		}
		set
		{
			this.m_bSteeringOn = value;
		}
	}

	// Token: 0x170001EE RID: 494
	// (get) Token: 0x06000EC2 RID: 3778 RVA: 0x0000C265 File Offset: 0x0000A465
	// (set) Token: 0x06000EC3 RID: 3779 RVA: 0x0000C26D File Offset: 0x0000A46D
	public float FSteeringAngle
	{
		get
		{
			return this.m_fSteeringAngle;
		}
		set
		{
			this.m_fSteeringAngle = value;
		}
	}

	// Token: 0x170001EF RID: 495
	// (get) Token: 0x06000EC4 RID: 3780 RVA: 0x0000C276 File Offset: 0x0000A476
	// (set) Token: 0x06000EC5 RID: 3781 RVA: 0x0000C27E File Offset: 0x0000A47E
	public float FSteeringAnimationAngle
	{
		get
		{
			return this.m_fSteeringAnimationAngle;
		}
		set
		{
			this.m_fSteeringAnimationAngle = value;
		}
	}

	// Token: 0x170001F0 RID: 496
	// (get) Token: 0x06000EC6 RID: 3782 RVA: 0x0000C287 File Offset: 0x0000A487
	// (set) Token: 0x06000EC7 RID: 3783 RVA: 0x0000C28F File Offset: 0x0000A48F
	public float FDifferentialFactor
	{
		get
		{
			return this.m_fDifferentialFactor;
		}
		set
		{
			this.m_fDifferentialFactor = value;
		}
	}

	// Token: 0x170001F1 RID: 497
	// (get) Token: 0x06000EC8 RID: 3784 RVA: 0x0000C298 File Offset: 0x0000A498
	public Vector3 VRestContactPoint
	{
		get
		{
			return this.m_vRestContactPoint;
		}
	}

	// Token: 0x170001F2 RID: 498
	// (get) Token: 0x06000EC9 RID: 3785 RVA: 0x0000C2A0 File Offset: 0x0000A4A0
	public Vector3 VOffset
	{
		get
		{
			return this.m_vOffset;
		}
	}

	// Token: 0x170001F3 RID: 499
	// (get) Token: 0x06000ECA RID: 3786 RVA: 0x0000C2A8 File Offset: 0x0000A4A8
	public RcPhysicWheel.WheelAxle EAxle
	{
		get
		{
			return this.m_eAxle;
		}
	}

	// Token: 0x170001F4 RID: 500
	// (get) Token: 0x06000ECB RID: 3787 RVA: 0x0000C2B0 File Offset: 0x0000A4B0
	public RcPhysicWheel.WheelSide ESide
	{
		get
		{
			return this.m_eSide;
		}
	}

	// Token: 0x170001F5 RID: 501
	// (get) Token: 0x06000ECC RID: 3788 RVA: 0x0000C2B8 File Offset: 0x0000A4B8
	// (set) Token: 0x06000ECD RID: 3789 RVA: 0x0000C2C0 File Offset: 0x0000A4C0
	public float FGripMaxNormalRatio
	{
		get
		{
			return this.m_fGripMaxNormalRatio;
		}
		set
		{
			this.m_fGripMaxNormalRatio = value;
		}
	}

	// Token: 0x170001F6 RID: 502
	// (get) Token: 0x06000ECE RID: 3790 RVA: 0x0000C2C9 File Offset: 0x0000A4C9
	// (set) Token: 0x06000ECF RID: 3791 RVA: 0x0000C2D1 File Offset: 0x0000A4D1
	public float FMassRep
	{
		get
		{
			return this.m_fMassRep;
		}
		set
		{
			this.m_fMassRep = value;
		}
	}

	// Token: 0x170001F7 RID: 503
	// (get) Token: 0x06000ED0 RID: 3792 RVA: 0x0000C2DA File Offset: 0x0000A4DA
	// (set) Token: 0x06000ED1 RID: 3793 RVA: 0x0000C2E2 File Offset: 0x0000A4E2
	public float FStabilityControl
	{
		get
		{
			return this.m_fStabilityControl;
		}
		set
		{
			this.m_fStabilityControl = value;
		}
	}

	// Token: 0x170001F8 RID: 504
	// (get) Token: 0x06000ED2 RID: 3794 RVA: 0x0000C2EB File Offset: 0x0000A4EB
	// (set) Token: 0x06000ED3 RID: 3795 RVA: 0x0000C2F3 File Offset: 0x0000A4F3
	public Transform VehicleRoot
	{
		get
		{
			return this.m_pVehicleRoot;
		}
		set
		{
			this.m_pVehicleRoot = value;
			this.hack = Quaternion.Inverse(this.m_pVehicleRoot.localRotation);
		}
	}

	// Token: 0x06000ED4 RID: 3796 RVA: 0x0000C312 File Offset: 0x0000A512
	public void ResetMotion()
	{
		this.m_fMovement = 0f;
		this.m_vVelocity = Vector3.zero;
	}

	// Token: 0x06000ED5 RID: 3797 RVA: 0x0000C32A File Offset: 0x0000A52A
	public void UpdateMotion(float fWheelVelocity, Vector3 vVehicleVelocity)
	{
		this.m_fMovement += fWheelVelocity * Time.fixedDeltaTime;
		this.m_vVelocity = vVehicleVelocity;
	}

	// Token: 0x06000ED6 RID: 3798 RVA: 0x0000C347 File Offset: 0x0000A547
	public float GetRestStretch()
	{
		return this.m_fMassRep * Vector3.Dot(Physics.gravity, Vector3.down) / this.m_fSpring;
	}

	// Token: 0x06000ED7 RID: 3799 RVA: 0x0005D428 File Offset: 0x0005B628
	public virtual Vector3 GetWorldPos()
	{
		Quaternion rotation = this.m_pVehicleRoot.rotation;
		Vector3 position = this.m_pVehicleRoot.position;
		return position + rotation * this.hack * (this.m_vModelToMesh + this.m_vOffset + this.m_fStretch * Vector3.up);
	}

	// Token: 0x06000ED8 RID: 3800 RVA: 0x0005D48C File Offset: 0x0005B68C
	public virtual void UpdateNode()
	{
		if (this.m_pVehicleRoot == null)
		{
			return;
		}
		Quaternion quaternion = this.m_pVehicleRoot.rotation * this.hack;
		this.m_pWheelMeshTransform.position = this.GetWorldPos();
		Vector3 axis = quaternion * Vector3.up;
		if (this.m_bAnimateSqueeze)
		{
			float num = (1f - Vector3.Dot(this.m_vMaxSqueeze, Vector3.up)) * this.m_fRadius;
			float num2 = 0f;
			if (this.m_fStretch > this.m_fMaxCompression - 2f * num)
			{
				num2 = RcUtils.LinearInterpolation(this.m_fMaxCompression - 2f * num, 0f, this.m_fMaxCompression, 1f, this.m_fStretch, true);
				this.m_pWheelMeshTransform.position -= quaternion * (0.5f * num2 * num * Vector3.up);
			}
			Vector3 one = Vector3.one;
			one.x = RcUtils.LinearInterpolation(0f, 1f, 1f, this.m_vMaxSqueeze.x, num2, true);
			one.y = RcUtils.LinearInterpolation(0f, 1f, 1f, this.m_vMaxSqueeze.y, num2, true);
			one.z = RcUtils.LinearInterpolation(0f, 1f, 1f, this.m_vMaxSqueeze.z, num2, true);
			this.m_pWheelMeshTransform.localScale = one;
		}
		Quaternion quaternion2 = quaternion;
		if (this.m_bMirrorMesh)
		{
			Quaternion rhs = Quaternion.AngleAxis(180f, Vector3.up);
			quaternion2 *= rhs;
		}
		if (this.m_bSteeringOn && this.m_bAnimateSteering)
		{
			float angle = this.m_fSteeringAnimationAngle * 180f / 3.14159274f;
			Quaternion lhs = Quaternion.AngleAxis(angle, axis);
			quaternion2 = lhs * quaternion2;
		}
		if (this.m_fAnimDistance > 0f)
		{
			int num3 = (int)(this.m_fMovement / this.m_fAnimDistance);
			float num4 = this.m_fMovement / this.m_fAnimDistance - (float)num3;
			if (this.m_fHandBrake > 0f)
			{
				num4 *= 1f - this.m_fHandBrake;
			}
			if (this.m_bMirrorMesh)
			{
				num4 *= -1f;
			}
			if (num4 != 0f)
			{
				if (this.m_bAnimateRollByUV && this.m_pWheelMaterial.Count > 0)
				{
					foreach (Material material in this.m_pWheelMaterial)
					{
						Vector2 mainTextureOffset = material.mainTextureOffset;
						mainTextureOffset.x = num4 * this.m_fUVAnimScale;
						material.mainTextureOffset = mainTextureOffset;
					}
				}
				else if (this.m_bAnimateRollByRotation)
				{
					Quaternion rhs2 = Quaternion.AngleAxis(-num4 * 360f, Vector3.left);
					quaternion2 *= rhs2;
				}
			}
		}
		this.m_pWheelMeshTransform.rotation = quaternion2;
	}

	// Token: 0x06000ED9 RID: 3801 RVA: 0x0005D7B0 File Offset: 0x0005B9B0
	public virtual void DebugDrawInfo(int xOffset, int yOffset)
	{
		string text;
		if (this.m_bOnGround)
		{
			text = "ground";
		}
		else
		{
			text = "air";
		}
		GUI.contentColor = Color.green;
		GUI.Label(new Rect((float)xOffset, (float)yOffset, 200f, 200f), text);
		Quaternion rotation = this.m_pVehicleTransform.rotation;
		Vector3 lhs = rotation * Vector3.forward;
		Vector3 lhs2 = rotation * Vector3.left;
		float num = Vector3.Dot(lhs, this.m_vVelocity) * 3.6f;
		float num2 = Vector3.Dot(lhs2, this.m_vVelocity) * 3.6f;
		text = string.Format("fV : {0:000.00}", num);
		GUI.Label(new Rect((float)xOffset, (float)(yOffset + 20), 200f, 200f), text);
		text = string.Format("sV : {0:000.00}", num2);
		GUI.Label(new Rect((float)xOffset, (float)(yOffset + 40), 200f, 200f), text);
		text = string.Format("strech : {0:0.00}", this.m_fStretch);
		GUI.Label(new Rect((float)xOffset, (float)(yOffset + 60), 200f, 200f), text);
	}

	// Token: 0x04000E24 RID: 3620
	public Transform m_pVehicleTransform;

	// Token: 0x04000E25 RID: 3621
	public Transform m_pWheelMeshTransform;

	// Token: 0x04000E26 RID: 3622
	public RcPhysicWheel.WheelSide m_eSide = RcPhysicWheel.WheelSide.Center;

	// Token: 0x04000E27 RID: 3623
	public RcPhysicWheel.WheelAxle m_eAxle = RcPhysicWheel.WheelAxle.Center;

	// Token: 0x04000E28 RID: 3624
	public string materialSuffix = "Wheel";

	// Token: 0x04000E29 RID: 3625
	public bool m_bAnimateRollByRotation;

	// Token: 0x04000E2A RID: 3626
	public bool m_bAnimateRollByUV = true;

	// Token: 0x04000E2B RID: 3627
	public bool m_bAnimateSteering = true;

	// Token: 0x04000E2C RID: 3628
	public bool m_bAnimateSqueeze = true;

	// Token: 0x04000E2D RID: 3629
	public float m_fUVAnimScale = -1f;

	// Token: 0x04000E2E RID: 3630
	protected Vector3 m_vMaxSqueeze = Vector3.one;

	// Token: 0x04000E2F RID: 3631
	public bool m_bMotorOn = true;

	// Token: 0x04000E30 RID: 3632
	public bool m_bSteeringOn = true;

	// Token: 0x04000E31 RID: 3633
	public bool m_bMirrorMesh;

	// Token: 0x04000E32 RID: 3634
	public Vector3 m_vOffset = Vector3.zero;

	// Token: 0x04000E33 RID: 3635
	public Vector3 m_vModelToMesh = Vector3.zero;

	// Token: 0x04000E34 RID: 3636
	public float m_fSpring = 30f;

	// Token: 0x04000E35 RID: 3637
	public float m_fDamping = 3f;

	// Token: 0x04000E36 RID: 3638
	public float m_fMaxCompression = 0.3f;

	// Token: 0x04000E37 RID: 3639
	public Vector2 m_vCollisionGrip = Vector2.one;

	// Token: 0x04000E38 RID: 3640
	public Vector2 m_vDriftGrip = Vector2.one;

	// Token: 0x04000E39 RID: 3641
	public Vector2 m_vNormalGrip = Vector2.one;

	// Token: 0x04000E3A RID: 3642
	public float m_fRadius = 0.3f;

	// Token: 0x04000E3B RID: 3643
	protected float m_fStretch;

	// Token: 0x04000E3C RID: 3644
	protected float m_fMovement;

	// Token: 0x04000E3D RID: 3645
	protected GroundCharac m_oGroundCharac;

	// Token: 0x04000E3E RID: 3646
	protected Vector3 m_vRestContactPoint = Vector3.zero;

	// Token: 0x04000E3F RID: 3647
	protected bool m_bOnGround;

	// Token: 0x04000E40 RID: 3648
	protected float m_fDifferentialFactor;

	// Token: 0x04000E41 RID: 3649
	protected float m_fGripFactor;

	// Token: 0x04000E42 RID: 3650
	protected float m_fForwardGrip;

	// Token: 0x04000E43 RID: 3651
	protected float m_fSideGrip;

	// Token: 0x04000E44 RID: 3652
	protected float m_fSideSlip;

	// Token: 0x04000E45 RID: 3653
	protected float m_fContactDepth;

	// Token: 0x04000E46 RID: 3654
	protected float m_fSuspensionFactor = 1f;

	// Token: 0x04000E47 RID: 3655
	protected float m_fMassRep;

	// Token: 0x04000E48 RID: 3656
	protected float m_fSteeringAngle;

	// Token: 0x04000E49 RID: 3657
	protected float m_fSteeringAnimationAngle;

	// Token: 0x04000E4A RID: 3658
	protected float m_fGripMaxNormalRatio;

	// Token: 0x04000E4B RID: 3659
	protected float m_fAnimDistance;

	// Token: 0x04000E4C RID: 3660
	protected float m_fHandBrake;

	// Token: 0x04000E4D RID: 3661
	protected float m_fStabilityControl;

	// Token: 0x04000E4E RID: 3662
	protected Vector3 m_vVelocity = Vector3.zero;

	// Token: 0x04000E4F RID: 3663
	protected float m_fSurfaceNoise;

	// Token: 0x04000E50 RID: 3664
	protected Transform m_pVehicleRoot;

	// Token: 0x04000E51 RID: 3665
	protected List<Material> m_pWheelMaterial = new List<Material>();

	// Token: 0x04000E52 RID: 3666
	protected Quaternion hack;

	// Token: 0x02000214 RID: 532
	public enum WheelSide
	{
		// Token: 0x04000E54 RID: 3668
		Left,
		// Token: 0x04000E55 RID: 3669
		Right,
		// Token: 0x04000E56 RID: 3670
		Center
	}

	// Token: 0x02000215 RID: 533
	public enum WheelAxle
	{
		// Token: 0x04000E58 RID: 3672
		Front,
		// Token: 0x04000E59 RID: 3673
		Rear,
		// Token: 0x04000E5A RID: 3674
		Center
	}
}

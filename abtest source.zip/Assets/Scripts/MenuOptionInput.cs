﻿using System;
using UnityEngine;

// Token: 0x02000121 RID: 289
public class MenuOptionInput : AbstractMenu
{
	// Token: 0x060007F6 RID: 2038 RVA: 0x0003C7D0 File Offset: 0x0003A9D0
	public override void OnEnter()
	{
		base.OnEnter();
		this.m_fGyroSensibility = Singleton<GameOptionManager>.Instance.GetGyroSensibility();
		E_InputType inputType = Singleton<GameOptionManager>.Instance.GetInputType();
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			if (inputType == E_InputType.Gyroscopic)
			{
				this.m_pBtnGyro.isChecked = true;
				this.m_pBtnTouched.isChecked = false;
			}
			else
			{
				this.m_pBtnTouched.isChecked = true;
				this.m_pBtnGyro.isChecked = false;
			}
			if (this.m_pGyroSlider)
			{
				this.m_pGyroSlider.sliderValue = this.m_fGyroSensibility;
			}
		}
	}

	// Token: 0x060007F7 RID: 2039 RVA: 0x00007960 File Offset: 0x00005B60
	public void OnSelectInput(int iInput)
	{
		Singleton<GameOptionManager>.Instance.SetInputType((E_InputType)iInput, true);
	}

	// Token: 0x060007F8 RID: 2040 RVA: 0x0000796E File Offset: 0x00005B6E
	public void OnChangeSensibility(float fValue)
	{
		this.m_fGyroSensibility = fValue;
		Singleton<GameOptionManager>.Instance.SetGyroSensibility(this.m_fGyroSensibility, false);
	}

	// Token: 0x060007F9 RID: 2041 RVA: 0x00007988 File Offset: 0x00005B88
	public override void OnExit()
	{
		Singleton<GameOptionManager>.Instance.SetGyroSensibility(this.m_fGyroSensibility, true);
		base.OnExit();
	}

	// Token: 0x0400082C RID: 2092
	public UICheckbox m_pBtnGyro;

	// Token: 0x0400082D RID: 2093
	public UICheckbox m_pBtnTouched;

	// Token: 0x0400082E RID: 2094
	public UISlider m_pGyroSlider;

	// Token: 0x0400082F RID: 2095
	private float m_fGyroSensibility;
}

﻿using System;
using UnityEngine;

// Token: 0x0200019A RID: 410
[Serializable]
public class ChampionshipButton
{
	// Token: 0x04000AE2 RID: 2786
	public GameObject ButtonChampionship;

	// Token: 0x04000AE3 RID: 2787
	public UITexturePattern Reward;

	// Token: 0x04000AE4 RID: 2788
	public BoxCollider Collider;

	// Token: 0x04000AE5 RID: 2789
	public GameObject ButtonPass;

	// Token: 0x04000AE6 RID: 2790
	public UILabel ButtonPassLabel;

	// Token: 0x04000AE7 RID: 2791
	public GameObject Hidden;
}

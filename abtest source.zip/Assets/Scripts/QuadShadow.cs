﻿using System;
using UnityEngine;

// Token: 0x02000150 RID: 336
public class QuadShadow : MonoBehaviour
{
	// Token: 0x0600096F RID: 2415 RVA: 0x000088EE File Offset: 0x00006AEE
	public void Start()
	{
		this.m_pBoneAttach = base.transform.parent;
	}

	// Token: 0x06000970 RID: 2416 RVA: 0x00008901 File Offset: 0x00006B01
	public void Update()
	{
		this.m_bUpdated = false;
	}

	// Token: 0x06000971 RID: 2417 RVA: 0x0000890A File Offset: 0x00006B0A
	public void OnWillRenderObject()
	{
		if (!this.m_bUpdated)
		{
			this.ComputeQuadShadow();
		}
	}

	// Token: 0x06000972 RID: 2418 RVA: 0x00042D74 File Offset: 0x00040F74
	private void ComputeQuadShadow()
	{
		RaycastHit raycastHit;
		if (Physics.Raycast(this.m_pBoneAttach.position + Vector3.up, Vector3.down, out raycastHit, this.m_fMaxDistProj, this.m_oLayerProj.value))
		{
			base.transform.position = raycastHit.point;
			Quaternion identity = Quaternion.identity;
			Vector3 lhs = Vector3.Cross(this.m_pBoneAttach.up, raycastHit.normal);
			Vector3 a = Vector3.Cross(lhs, raycastHit.normal);
			identity.SetLookRotation(raycastHit.normal, -a);
			base.transform.rotation = identity;
			base.transform.localScale = Vector3.one;
		}
		else
		{
			base.transform.localScale = Vector3.zero;
		}
		this.m_bUpdated = true;
	}

	// Token: 0x040009AC RID: 2476
	private bool m_bUpdated;

	// Token: 0x040009AD RID: 2477
	public float m_fMaxDistProj = 10f;

	// Token: 0x040009AE RID: 2478
	public LayerMask m_oLayerProj;

	// Token: 0x040009AF RID: 2479
	private Transform m_pBoneAttach;
}

﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000C7 RID: 199
public class SoundManager : MonoBehaviour
{
	// Token: 0x0600052F RID: 1327 RVA: 0x00005AE3 File Offset: 0x00003CE3
	public void Awake()
	{
		this.Music.ignoreListenerPause = true;
	}

	// Token: 0x06000530 RID: 1328 RVA: 0x0002A794 File Offset: 0x00028994
	public void Update()
	{
		if (this.Music.clip != null && !this.Music.isPlaying && LoadingManager.loadingFinished)
		{
			LoadingManager.loadingFinished = false;
			this.Music.Play();
		}
	}

	// Token: 0x06000531 RID: 1329 RVA: 0x00005AF1 File Offset: 0x00003CF1
	public void SetMusic(ERaceMusicLoops _Music)
	{
		this.Music.clip = this.MusicsList[(int)_Music];
	}

	// Token: 0x06000532 RID: 1330 RVA: 0x00005B0A File Offset: 0x00003D0A
	public void PlayMusic()
	{
		if (this.Music.clip != null && !this.Music.isPlaying)
		{
			this.Music.Play();
		}
	}

	// Token: 0x06000533 RID: 1331 RVA: 0x00005B3D File Offset: 0x00003D3D
	public void PlayMusic(ERaceMusicLoops _Music)
	{
		this.SetMusic(_Music);
		if (_Music != ERaceMusicLoops.InterRace && _Music != ERaceMusicLoops.TrackPresentation)
		{
			this.PlayMusic();
		}
	}

	// Token: 0x06000534 RID: 1332 RVA: 0x00005B59 File Offset: 0x00003D59
	public void StopMusic()
	{
		if (this.Music.isPlaying)
		{
			this.Music.Stop();
		}
	}

	// Token: 0x06000535 RID: 1333 RVA: 0x00005B76 File Offset: 0x00003D76
	public void PlaySound(ERaceSounds _Sound)
	{
		if (this.SoundsList[(int)_Sound] != null && !this.SoundsList[(int)_Sound].isPlaying)
		{
			this.SoundsList[(int)_Sound].Play();
		}
	}

	// Token: 0x06000536 RID: 1334 RVA: 0x00005BB6 File Offset: 0x00003DB6
	public void StopSound(ERaceSounds _Sound)
	{
		if (this.SoundsList[(int)_Sound] != null && this.SoundsList[(int)_Sound].isPlaying)
		{
			this.SoundsList[(int)_Sound].Stop();
		}
	}

	// Token: 0x06000537 RID: 1335 RVA: 0x0002A7E4 File Offset: 0x000289E4
	public void ApplyVolume()
	{
		float sfxVolume = Singleton<GameOptionManager>.Instance.GetSfxVolume();
		for (int i = 0; i < this.SoundsList.Count; i++)
		{
			if (this.SoundsList[i])
			{
				this.SoundsList[i].volume = sfxVolume;
			}
		}
	}

	// Token: 0x0400050E RID: 1294
	public List<AudioSource> SoundsList = new List<AudioSource>();

	// Token: 0x0400050F RID: 1295
	public AudioSource Music;

	// Token: 0x04000510 RID: 1296
	public List<AudioClip> MusicsList = new List<AudioClip>();
}

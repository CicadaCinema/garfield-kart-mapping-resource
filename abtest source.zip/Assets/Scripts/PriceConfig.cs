﻿using System;
using UnityEngine;

// Token: 0x02000133 RID: 307
public class PriceConfig : MonoBehaviour
{
	// Token: 0x060008A3 RID: 2211 RVA: 0x00008125 File Offset: 0x00006325
	public int GetCustoPrice(ERarity _Rarity)
	{
		return this.CustoPrices[Tricks.LogBase2((int)_Rarity)];
	}

	// Token: 0x060008A4 RID: 2212 RVA: 0x00008134 File Offset: 0x00006334
	public int GetHatPrice(ERarity _Rarity, bool _Unique)
	{
		if (_Unique)
		{
			return this.UniqueHatPrices[Tricks.LogBase2((int)_Rarity)];
		}
		return this.HatPrices[Tricks.LogBase2((int)_Rarity)];
	}

	// Token: 0x060008A5 RID: 2213 RVA: 0x00008157 File Offset: 0x00006357
	public int GetKartPrice()
	{
		return this.KartPrices;
	}

	// Token: 0x040008CB RID: 2251
	[SerializeField]
	[HideInInspector]
	public int[] CustoPrices = new int[Enum.GetValues(typeof(ERarity)).Length];

	// Token: 0x040008CC RID: 2252
	[SerializeField]
	[HideInInspector]
	public int[] HatPrices = new int[Enum.GetValues(typeof(ERarity)).Length];

	// Token: 0x040008CD RID: 2253
	[SerializeField]
	[HideInInspector]
	public int[] UniqueHatPrices = new int[Enum.GetValues(typeof(ERarity)).Length];

	// Token: 0x040008CE RID: 2254
	[SerializeField]
	[HideInInspector]
	public int KartPrices;
}

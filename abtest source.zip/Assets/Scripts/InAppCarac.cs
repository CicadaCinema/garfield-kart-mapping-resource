﻿using System;

// Token: 0x0200013E RID: 318
public class InAppCarac : IconCarac
{
	// Token: 0x040008F6 RID: 2294
	public string ProdutId;

	// Token: 0x040008F7 RID: 2295
	public int CoinsEarn;
}

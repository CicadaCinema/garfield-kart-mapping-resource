﻿using System;
using UnityEngine;

// Token: 0x020000FB RID: 251
public class PlayerData
{
	// Token: 0x060006C3 RID: 1731 RVA: 0x00034504 File Offset: 0x00032704
	public PlayerData(ECharacter pCharacter, ECharacter pKart, string pCustom, string pHat, int iNbStars, string sPseudo, Color cColor)
	{
		this._character = pCharacter;
		this._kart = pKart;
		this._custom = pCustom;
		this._hat = pHat;
		this._nbStars = iNbStars;
		this._pseudo = sPseudo;
		this._characColor = cColor;
	}

	// Token: 0x17000104 RID: 260
	// (get) Token: 0x060006C4 RID: 1732 RVA: 0x00006C36 File Offset: 0x00004E36
	// (set) Token: 0x060006C5 RID: 1733 RVA: 0x00006C3E File Offset: 0x00004E3E
	public ECharacter Character
	{
		get
		{
			return this._character;
		}
		set
		{
			this._character = value;
		}
	}

	// Token: 0x17000105 RID: 261
	// (get) Token: 0x060006C6 RID: 1734 RVA: 0x00006C47 File Offset: 0x00004E47
	// (set) Token: 0x060006C7 RID: 1735 RVA: 0x00006C4F File Offset: 0x00004E4F
	public ECharacter Kart
	{
		get
		{
			return this._kart;
		}
		set
		{
			this._kart = value;
		}
	}

	// Token: 0x17000106 RID: 262
	// (get) Token: 0x060006C8 RID: 1736 RVA: 0x00006C58 File Offset: 0x00004E58
	// (set) Token: 0x060006C9 RID: 1737 RVA: 0x00006C60 File Offset: 0x00004E60
	public string Custom
	{
		get
		{
			return this._custom;
		}
		set
		{
			this._custom = value;
		}
	}

	// Token: 0x17000107 RID: 263
	// (get) Token: 0x060006CA RID: 1738 RVA: 0x00006C69 File Offset: 0x00004E69
	// (set) Token: 0x060006CB RID: 1739 RVA: 0x00006C71 File Offset: 0x00004E71
	public string Hat
	{
		get
		{
			return this._hat;
		}
		set
		{
			this._hat = value;
		}
	}

	// Token: 0x17000108 RID: 264
	// (get) Token: 0x060006CC RID: 1740 RVA: 0x00006C7A File Offset: 0x00004E7A
	// (set) Token: 0x060006CD RID: 1741 RVA: 0x00006C82 File Offset: 0x00004E82
	public int KartIndex
	{
		get
		{
			return this._kartIndex;
		}
		set
		{
			this._kartIndex = value;
		}
	}

	// Token: 0x17000109 RID: 265
	// (get) Token: 0x060006CE RID: 1742 RVA: 0x00006C8B File Offset: 0x00004E8B
	// (set) Token: 0x060006CF RID: 1743 RVA: 0x00006C93 File Offset: 0x00004E93
	public int NbStars
	{
		get
		{
			return this._nbStars;
		}
		set
		{
			this._nbStars = value;
		}
	}

	// Token: 0x1700010A RID: 266
	// (get) Token: 0x060006D0 RID: 1744 RVA: 0x00006C9C File Offset: 0x00004E9C
	// (set) Token: 0x060006D1 RID: 1745 RVA: 0x00006CA4 File Offset: 0x00004EA4
	public string Pseudo
	{
		get
		{
			return this._pseudo;
		}
		set
		{
			this._pseudo = value;
		}
	}

	// Token: 0x1700010B RID: 267
	// (get) Token: 0x060006D2 RID: 1746 RVA: 0x00006CAD File Offset: 0x00004EAD
	// (set) Token: 0x060006D3 RID: 1747 RVA: 0x00006CB5 File Offset: 0x00004EB5
	public Color CharacColor
	{
		get
		{
			return this._characColor;
		}
		set
		{
			this._characColor = value;
		}
	}

	// Token: 0x040006B6 RID: 1718
	private ECharacter _character;

	// Token: 0x040006B7 RID: 1719
	private ECharacter _kart;

	// Token: 0x040006B8 RID: 1720
	private string _custom;

	// Token: 0x040006B9 RID: 1721
	private string _hat;

	// Token: 0x040006BA RID: 1722
	private int _kartIndex;

	// Token: 0x040006BB RID: 1723
	private int _nbStars;

	// Token: 0x040006BC RID: 1724
	private string _pseudo;

	// Token: 0x040006BD RID: 1725
	private Color _characColor = Color.yellow;
}

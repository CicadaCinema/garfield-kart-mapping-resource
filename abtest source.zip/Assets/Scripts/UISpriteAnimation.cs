﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000087 RID: 135
[RequireComponent(typeof(UISprite))]
[ExecuteInEditMode]
[AddComponentMenu("NGUI/UI/Sprite Animation")]
public class UISpriteAnimation : MonoBehaviour
{
	// Token: 0x170000BB RID: 187
	// (get) Token: 0x060003C4 RID: 964 RVA: 0x00004D5F File Offset: 0x00002F5F
	public int frames
	{
		get
		{
			return this.mSpriteNames.Count;
		}
	}

	// Token: 0x170000BC RID: 188
	// (get) Token: 0x060003C5 RID: 965 RVA: 0x00004D6C File Offset: 0x00002F6C
	// (set) Token: 0x060003C6 RID: 966 RVA: 0x00004D74 File Offset: 0x00002F74
	public int framesPerSecond
	{
		get
		{
			return this.mFPS;
		}
		set
		{
			this.mFPS = value;
		}
	}

	// Token: 0x170000BD RID: 189
	// (get) Token: 0x060003C7 RID: 967 RVA: 0x00004D7D File Offset: 0x00002F7D
	// (set) Token: 0x060003C8 RID: 968 RVA: 0x00004D85 File Offset: 0x00002F85
	public string namePrefix
	{
		get
		{
			return this.mPrefix;
		}
		set
		{
			if (this.mPrefix != value)
			{
				this.mPrefix = value;
				this.RebuildSpriteList();
			}
		}
	}

	// Token: 0x170000BE RID: 190
	// (get) Token: 0x060003C9 RID: 969 RVA: 0x00004DA5 File Offset: 0x00002FA5
	// (set) Token: 0x060003CA RID: 970 RVA: 0x00004DAD File Offset: 0x00002FAD
	public bool loop
	{
		get
		{
			return this.mLoop;
		}
		set
		{
			this.mLoop = value;
		}
	}

	// Token: 0x170000BF RID: 191
	// (get) Token: 0x060003CB RID: 971 RVA: 0x00004DB6 File Offset: 0x00002FB6
	public bool isPlaying
	{
		get
		{
			return this.mActive;
		}
	}

	// Token: 0x060003CC RID: 972 RVA: 0x00004DBE File Offset: 0x00002FBE
	private void Start()
	{
		this.RebuildSpriteList();
	}

	// Token: 0x060003CD RID: 973 RVA: 0x00022B40 File Offset: 0x00020D40
	private void Update()
	{
		if (this.mActive && this.mSpriteNames.Count > 1 && Application.isPlaying && (float)this.mFPS > 0f)
		{
			this.mDelta += Time.deltaTime;
			float num = 1f / (float)this.mFPS;
			if (num < this.mDelta)
			{
				this.mDelta = ((num <= 0f) ? 0f : (this.mDelta - num));
				if (++this.mIndex >= this.mSpriteNames.Count)
				{
					this.mIndex = 0;
					this.mActive = this.loop;
				}
				if (this.mActive)
				{
					this.mSprite.spriteName = this.mSpriteNames[this.mIndex];
					this.mSprite.MakePixelPerfect();
				}
			}
		}
	}

	// Token: 0x060003CE RID: 974 RVA: 0x00022C3C File Offset: 0x00020E3C
	private void RebuildSpriteList()
	{
		if (this.mSprite == null)
		{
			this.mSprite = base.GetComponent<UISprite>();
		}
		this.mSpriteNames.Clear();
		if (this.mSprite != null && this.mSprite.atlas != null)
		{
			List<UIAtlas.Sprite> spriteList = this.mSprite.atlas.spriteList;
			int i = 0;
			int count = spriteList.Count;
			while (i < count)
			{
				UIAtlas.Sprite sprite = spriteList[i];
				if (string.IsNullOrEmpty(this.mPrefix) || sprite.name.StartsWith(this.mPrefix))
				{
					this.mSpriteNames.Add(sprite.name);
				}
				i++;
			}
			this.mSpriteNames.Sort();
		}
	}

	// Token: 0x060003CF RID: 975 RVA: 0x00022D0C File Offset: 0x00020F0C
	public void Reset()
	{
		this.mActive = true;
		this.mIndex = 0;
		if (this.mSprite != null && this.mSpriteNames.Count > 0)
		{
			this.mSprite.spriteName = this.mSpriteNames[this.mIndex];
			this.mSprite.MakePixelPerfect();
		}
	}

	// Token: 0x04000334 RID: 820
	[HideInInspector]
	[SerializeField]
	private int mFPS = 30;

	// Token: 0x04000335 RID: 821
	[SerializeField]
	[HideInInspector]
	private string mPrefix = string.Empty;

	// Token: 0x04000336 RID: 822
	[SerializeField]
	[HideInInspector]
	private bool mLoop = true;

	// Token: 0x04000337 RID: 823
	private UISprite mSprite;

	// Token: 0x04000338 RID: 824
	private float mDelta;

	// Token: 0x04000339 RID: 825
	private int mIndex;

	// Token: 0x0400033A RID: 826
	private bool mActive = true;

	// Token: 0x0400033B RID: 827
	private List<string> mSpriteNames = new List<string>();
}

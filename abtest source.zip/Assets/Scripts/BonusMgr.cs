﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000D2 RID: 210
public class BonusMgr : Singleton<BonusMgr>
{
	// Token: 0x170000F6 RID: 246
	// (get) Token: 0x06000587 RID: 1415 RVA: 0x0002BAAC File Offset: 0x00029CAC
	public Dictionary<NetworkViewID, Kart> Karts
	{
		get
		{
			if (Network.peerType != NetworkPeerType.Disconnected && this.m_cKarts.Count == 0)
			{
				Kart[] array = (Kart[])UnityEngine.Object.FindObjectsOfType(typeof(Kart));
				foreach (Kart kart in array)
				{
					this.m_cKarts[kart.networkViewID] = kart;
				}
			}
			return this.m_cKarts;
		}
	}

	// Token: 0x06000588 RID: 1416 RVA: 0x0002BB1C File Offset: 0x00029D1C
	public void Init()
	{
		this.UfoLaunched = false;
		this.nbPie = 0;
		this.nbAutolockPie = 0;
		this.nbSpring = 0;
		this.nbMagic = 0;
		this.nbDiamond = 0;
		if (!Network.isClient)
		{
			for (int i = 0; i < 20; i++)
			{
				this.GenerateItem(EITEM.ITEM_AUTOLOCK_PIE);
				this.GenerateItem(EITEM.ITEM_PIE);
				this.GenerateItem(EITEM.ITEM_SPRING);
			}
			for (int j = 0; j < 8; j++)
			{
				this.GenerateItem(EITEM.ITEM_DIAMOND);
			}
			for (int k = 0; k < 10; k++)
			{
				this.GenerateItem(EITEM.ITEM_MAGIC);
			}
			this.GenerateItem(EITEM.ITEM_UFO);
		}
	}

	// Token: 0x06000589 RID: 1417 RVA: 0x0002BBC0 File Offset: 0x00029DC0
	public void Reset()
	{
		if (this.m_pUFOEntity != null)
		{
			this.DestroyEntities(this.m_pPieEntities);
			this.DestroyEntities(this.m_pAutolockPieEntities);
			this.DestroyEntities(this.m_pSpringEntities);
			this.DestroyEntities(this.m_pMagicEntities);
			this.DestroyEntities(this.m_pDiamondEntities);
			UnityEngine.Object.Destroy(this.m_pUFOEntity.transform.parent.gameObject);
		}
		this.nbPie = 0;
		this.nbAutolockPie = 0;
		this.nbSpring = 0;
		this.nbMagic = 0;
		this.nbDiamond = 0;
		this.m_cKarts.Clear();
	}

	// Token: 0x0600058A RID: 1418 RVA: 0x0002BC64 File Offset: 0x00029E64
	private void DestroyEntities(BonusEntity[] pEntities)
	{
		for (int i = 0; i < pEntities.Length; i++)
		{
			if (pEntities[i] != null)
			{
				UnityEngine.Object.Destroy(pEntities[i].transform.parent.gameObject);
			}
		}
	}

	// Token: 0x0600058B RID: 1419 RVA: 0x0002BCAC File Offset: 0x00029EAC
	private void GenerateItem(EITEM _Item)
	{
		string path = string.Empty;
		switch (_Item)
		{
		case EITEM.ITEM_PIE:
			path = "Bonus/PieBonusEntity";
			break;
		case EITEM.ITEM_AUTOLOCK_PIE:
			path = "Bonus/AutolockPieBonusEntity";
			break;
		case EITEM.ITEM_SPRING:
			path = "Bonus/SpringBonusEntity";
			break;
		case EITEM.ITEM_DIAMOND:
			path = "Bonus/DiamondBonusEntity";
			break;
		case EITEM.ITEM_UFO:
			path = "Bonus/UfoBonusEntity";
			break;
		case EITEM.ITEM_MAGIC:
			path = "Bonus/MagicBonusEntity";
			break;
		}
		UnityEngine.Object @object = Resources.Load(path);
		if (Network.isServer)
		{
			Network.Instantiate(@object, Vector3.zero, Quaternion.identity, 0);
		}
		else if (Network.peerType == NetworkPeerType.Disconnected)
		{
			UnityEngine.Object.Instantiate(@object);
		}
	}

	// Token: 0x0600058C RID: 1420 RVA: 0x0002BD70 File Offset: 0x00029F70
	public void AddBonus(GameObject _Bonus, EITEM _Item)
	{
		string name = string.Empty;
		switch (_Item)
		{
		case EITEM.ITEM_PIE:
			name = "Pie" + this.nbPie;
			goto IL_CE;
		case EITEM.ITEM_AUTOLOCK_PIE:
			name = "AutolockPie" + this.nbAutolockPie;
			goto IL_CE;
		case EITEM.ITEM_SPRING:
			name = "Spring" + this.nbSpring;
			goto IL_CE;
		case EITEM.ITEM_DIAMOND:
			name = "Diamond" + this.nbDiamond;
			goto IL_CE;
		case EITEM.ITEM_UFO:
			name = "UFO0";
			goto IL_CE;
		case EITEM.ITEM_MAGIC:
			name = "Magic" + this.nbMagic;
			goto IL_CE;
		}
		return;
		IL_CE:
		GameObject gameObject = new GameObject(name);
		_Bonus.transform.parent = gameObject.transform;
		switch (_Item)
		{
		case EITEM.ITEM_PIE:
			this.m_pPieEntities[this.nbPie] = _Bonus.GetComponentInChildren<PieBonusEntity>();
			this.m_pPieEntities[this.nbPie].Index = this.nbPie;
			this.nbPie++;
			break;
		case EITEM.ITEM_AUTOLOCK_PIE:
			this.m_pAutolockPieEntities[this.nbAutolockPie] = _Bonus.GetComponentInChildren<AutolockPieBonusEntity>();
			this.m_pAutolockPieEntities[this.nbAutolockPie].Index = this.nbAutolockPie;
			this.nbAutolockPie++;
			break;
		case EITEM.ITEM_SPRING:
			this.m_pSpringEntities[this.nbSpring++] = _Bonus.GetComponentInChildren<SpringBonusEntity>();
			break;
		case EITEM.ITEM_DIAMOND:
			this.m_pDiamondEntities[this.nbDiamond++] = _Bonus.GetComponentInChildren<DiamondBonusEntity>();
			break;
		case EITEM.ITEM_UFO:
			this.m_pUFOEntity = _Bonus.GetComponentInChildren<UFOBonusEntity>();
			break;
		case EITEM.ITEM_MAGIC:
		{
			BonusEntity bonusEntity = null;
			int num = 0;
			while (num < _Bonus.transform.childCount && bonusEntity == null)
			{
				bonusEntity = _Bonus.transform.GetChild(num).GetComponent<MagicBonusEntity>();
				num++;
			}
			this.m_pMagicEntities[this.nbMagic++] = (MagicBonusEntity)bonusEntity;
			break;
		}
		}
	}

	// Token: 0x0600058D RID: 1421 RVA: 0x0002BFD4 File Offset: 0x0002A1D4
	public void RequestBonus(EITEM _Item, Kart _Kart, bool _Behind)
	{
		switch (_Item)
		{
		case EITEM.ITEM_PIE:
			if (Network.peerType == NetworkPeerType.Disconnected)
			{
				BonusEntity bonusEntity = this.ActiveLastUsed(_Item, _Kart);
				(bonusEntity as PieBonusEntity).Launch(_Behind);
			}
			else if (Network.isServer)
			{
				BonusEntity bonusEntity2 = this.ActiveLastUsed(_Item, _Kart);
				(bonusEntity2 as PieBonusEntity).NetLaunch(_Kart.networkViewID, _Behind);
			}
			break;
		case EITEM.ITEM_AUTOLOCK_PIE:
			if (Network.peerType == NetworkPeerType.Disconnected)
			{
				BonusEntity bonusEntity3 = this.ActiveLastUsed(_Item, _Kart);
				(bonusEntity3 as AutolockPieBonusEntity).Launch(_Kart, _Behind);
			}
			else if (Network.isServer)
			{
				BonusEntity bonusEntity4 = this.ActiveLastUsed(_Item, _Kart);
				(bonusEntity4 as AutolockPieBonusEntity).NetLaunch(_Kart.networkViewID, _Behind);
			}
			break;
		case EITEM.ITEM_SPRING:
			if (_Behind)
			{
				if (Network.peerType == NetworkPeerType.Disconnected)
				{
					BonusEntity bonusEntity5 = this.ActiveLastUsed(_Item, _Kart);
					(bonusEntity5 as SpringBonusEntity).Launch();
				}
				else if (Network.isServer)
				{
					BonusEntity bonusEntity6 = this.ActiveLastUsed(_Item, _Kart);
					(bonusEntity6 as SpringBonusEntity).NetLaunch(_Kart.networkViewID);
				}
			}
			else
			{
				_Kart.GetBonusMgr().GetBonusEffectMgr().ActivateBonusEffect(EBonusEffect.BONUSEFFECT_JUMP);
			}
			break;
		case EITEM.ITEM_LASAGNA:
			_Kart.GetBonusMgr().GetBonusEffectMgr().ActivateBonusEffect(EBonusEffect.BONUSEFFECT_BOOST);
			_Kart.KartSound.PlaySound(17);
			break;
		case EITEM.ITEM_DIAMOND:
			if (Network.peerType == NetworkPeerType.Disconnected)
			{
				BonusEntity bonusEntity7 = this.ActiveLastUsed(_Item, _Kart);
				(bonusEntity7 as DiamondBonusEntity).Launch(_Behind);
			}
			else if (Network.isServer)
			{
				BonusEntity bonusEntity8 = this.ActiveLastUsed(_Item, _Kart);
				(bonusEntity8 as DiamondBonusEntity).NetLaunch(_Kart.networkViewID, _Behind);
			}
			break;
		case EITEM.ITEM_UFO:
			this.m_pUFOEntity.Launcher = _Kart;
			this.m_pUFOEntity.Launch();
			break;
		case EITEM.ITEM_NAP:
		{
			int rank = _Kart.RaceStats.GetRank();
			Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.NapUsed);
			_Kart.Anim.LaunchSuccessAnim(true);
			_Kart.KartSound.PlayVoice((UnityEngine.Random.value <= 0.5f) ? KartSound.EVoices.Good : KartSound.EVoices.Good2);
			for (int i = 0; i < Singleton<GameManager>.Instance.GameMode.PlayerCount; i++)
			{
				Kart kart = Singleton<GameManager>.Instance.GameMode.GetKart(i);
				if (kart != null && kart.Index != _Kart.Index)
				{
					int rank2 = kart.RaceStats.GetRank();
					if (rank2 < rank)
					{
						ParfumeBonusEffect parfumeBonusEffect = (ParfumeBonusEffect)kart.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_ATTRACTED);
						if (!parfumeBonusEffect.Activated || parfumeBonusEffect.StinkParfume)
						{
							((NapBonusEffect)kart.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_SLEPT)).Launcher = _Kart;
							kart.GetBonusMgr().GetBonusEffectMgr().ActivateBonusEffect(EBonusEffect.BONUSEFFECT_SLEPT);
						}
					}
				}
			}
			break;
		}
		case EITEM.ITEM_PARFUME:
			_Kart.GetBonusMgr().GetBonusEffectMgr().ActivateBonusEffect(EBonusEffect.BONUSEFFECT_ATTRACTED);
			break;
		case EITEM.ITEM_MAGIC:
			if (Network.peerType == NetworkPeerType.Disconnected)
			{
				BonusEntity bonusEntity9 = this.ActiveLastUsed(_Item, _Kart);
				(bonusEntity9 as MagicBonusEntity).Launch();
			}
			else if (Network.isServer)
			{
				BonusEntity bonusEntity10 = this.ActiveLastUsed(_Item, _Kart);
				(bonusEntity10 as MagicBonusEntity).NetLaunch(_Kart.networkViewID);
			}
			break;
		}
	}

	// Token: 0x0600058E RID: 1422 RVA: 0x0002C33C File Offset: 0x0002A53C
	public BonusEntity ActiveLastUsed(EITEM _Item, Kart _Kart)
	{
		BonusEntity[] array = null;
		int lastUsed = this.GetLastUsed(_Item, ref array);
		if (array != null && array[lastUsed] != null)
		{
			if (array[lastUsed].Activate)
			{
				array[lastUsed].SetActive(false);
			}
			array[lastUsed].Launcher = _Kart;
			return array[lastUsed];
		}
		return null;
	}

	// Token: 0x0600058F RID: 1423 RVA: 0x0002C390 File Offset: 0x0002A590
	public int GetLastUsed(EITEM _Item, ref BonusEntity[] _Tab)
	{
		float num = 0f;
		int result = 0;
		switch (_Item)
		{
		case EITEM.ITEM_PIE:
			_Tab = this.m_pPieEntities;
			break;
		case EITEM.ITEM_AUTOLOCK_PIE:
			_Tab = this.m_pAutolockPieEntities;
			break;
		case EITEM.ITEM_SPRING:
			_Tab = this.m_pSpringEntities;
			break;
		case EITEM.ITEM_DIAMOND:
			_Tab = this.m_pDiamondEntities;
			break;
		case EITEM.ITEM_MAGIC:
			_Tab = this.m_pMagicEntities;
			break;
		}
		for (int i = 0; i < _Tab.Length; i++)
		{
			if (!_Tab[i].gameObject.activeSelf)
			{
				return i;
			}
			if (num == 0f || _Tab[i].Timer < num)
			{
				result = i;
				num = _Tab[i].Timer;
			}
		}
		return result;
	}

	// Token: 0x06000590 RID: 1424 RVA: 0x0002C470 File Offset: 0x0002A670
	public void StartScene()
	{
		this.UfoLaunched = false;
		GameObject gameObject = GameObject.Find("SplineRespawn");
		RcMultiPath idealPath = null;
		if (gameObject != null)
		{
			idealPath = gameObject.GetComponent<RcMultiPath>();
		}
		for (int i = 0; i < 20; i++)
		{
			if (this.m_pAutolockPieEntities[i] != null)
			{
				this.m_pAutolockPieEntities[i].IdealPath = idealPath;
			}
		}
		for (int j = 0; j < 20; j++)
		{
			if (this.m_pPieEntities[j] != null)
			{
				this.m_pPieEntities[j].IdealPath = idealPath;
			}
		}
		this.m_pUFOEntity.IdealPath = idealPath;
		GameObject gameObject2 = GameObject.Find("Race");
		if (gameObject2 != null)
		{
			RcRace component = gameObject2.GetComponent<RcRace>();
			this.m_pUFOEntity.Race = component;
		}
	}

	// Token: 0x0400055F RID: 1375
	public const int MAX_BONUS_ENTITY = 20;

	// Token: 0x04000560 RID: 1376
	public const int MAX_BONUS_DIAMOND = 8;

	// Token: 0x04000561 RID: 1377
	public const int MAX_BONUS_MAGIC = 10;

	// Token: 0x04000562 RID: 1378
	public PieBonusEntity[] m_pPieEntities = new PieBonusEntity[20];

	// Token: 0x04000563 RID: 1379
	public AutolockPieBonusEntity[] m_pAutolockPieEntities = new AutolockPieBonusEntity[20];

	// Token: 0x04000564 RID: 1380
	public SpringBonusEntity[] m_pSpringEntities = new SpringBonusEntity[20];

	// Token: 0x04000565 RID: 1381
	public MagicBonusEntity[] m_pMagicEntities = new MagicBonusEntity[10];

	// Token: 0x04000566 RID: 1382
	public DiamondBonusEntity[] m_pDiamondEntities = new DiamondBonusEntity[8];

	// Token: 0x04000567 RID: 1383
	private UFOBonusEntity m_pUFOEntity;

	// Token: 0x04000568 RID: 1384
	public bool UfoLaunched;

	// Token: 0x04000569 RID: 1385
	private int nbPie;

	// Token: 0x0400056A RID: 1386
	private int nbAutolockPie;

	// Token: 0x0400056B RID: 1387
	private int nbSpring;

	// Token: 0x0400056C RID: 1388
	private int nbMagic;

	// Token: 0x0400056D RID: 1389
	private int nbDiamond;

	// Token: 0x0400056E RID: 1390
	private Dictionary<NetworkViewID, Kart> m_cKarts = new Dictionary<NetworkViewID, Kart>();
}

﻿using System;
using UnityEngine;

// Token: 0x02000174 RID: 372
public class TutorialGameState : GameState
{
	// Token: 0x06000A02 RID: 2562 RVA: 0x00003B80 File Offset: 0x00001D80
	public void Awake()
	{
	}

	// Token: 0x06000A03 RID: 2563 RVA: 0x00008CE6 File Offset: 0x00006EE6
	public override void Enter()
	{
		Camera.main.GetComponent<CameraBase>().SwitchCamera(ECamState.Follow, ECamState.TransCut);
		base.gameMode.Hud.EnterTutorial(new Action<bool>(this.Next));
	}

	// Token: 0x06000A04 RID: 2564 RVA: 0x00008D15 File Offset: 0x00006F15
	public override void Exit()
	{
		Singleton<GameSaveManager>.Instance.SetShowTutorial(this.m_bShowNextTime, true);
		base.gameMode.Hud.ExitTutorial();
		base.gameMode.Hud.StartRace();
	}

	// Token: 0x06000A05 RID: 2565 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void Update()
	{
	}

	// Token: 0x06000A06 RID: 2566 RVA: 0x00008D48 File Offset: 0x00006F48
	public void Next(bool ShowNextTime)
	{
		this.m_bShowNextTime = ShowNextTime;
		this.OnStateChanged(E_GameState.Start);
	}

	// Token: 0x04000A0C RID: 2572
	public float MinDisplayTime = 2f;

	// Token: 0x04000A0D RID: 2573
	private bool m_bShowNextTime;
}

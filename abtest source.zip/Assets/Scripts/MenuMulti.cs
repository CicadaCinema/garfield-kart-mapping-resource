﻿using System;
using UnityEngine;

// Token: 0x0200019D RID: 413
public class MenuMulti : AbstractMenu
{
	// Token: 0x06000B19 RID: 2841 RVA: 0x00009A39 File Offset: 0x00007C39
	public override void Awake()
	{
		base.Awake();
		this.networkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
	}

	// Token: 0x06000B1A RID: 2842 RVA: 0x0004AF7C File Offset: 0x0004917C
	public override void OnEnter()
	{
		base.OnEnter();
		if (this.Input != null)
		{
			this.Input.text = Singleton<GameSaveManager>.Instance.GetPseudo();
			this.Input.defaultText = Localization.instance.Get("MENU_PLAYER");
			this.Input.maxChars = 8;
			this.Input.selected = false;
		}
		base.StartCoroutine(this.networkMgr.CheckIP());
	}

	// Token: 0x06000B1B RID: 2843 RVA: 0x00009A5B File Offset: 0x00007C5B
	public override void OnExit()
	{
		this.OnSubmit();
		base.OnExit();
	}

	// Token: 0x06000B1C RID: 2844 RVA: 0x00009A69 File Offset: 0x00007C69
	public void OnButtonLocal()
	{
		if (ASE_Tools.Available)
		{
			ASE_Flurry.LogEvent("MJ_SELECTION_LOCAL");
		}
		this.OnSubmit();
		this.networkMgr.BLanOnly = true;
		this.ActSwapMenu(EMenus.MENU_MULTI_JOIN);
	}

	// Token: 0x06000B1D RID: 2845 RVA: 0x00009A98 File Offset: 0x00007C98
	public void OnButtonOnLine()
	{
		if (ASE_Tools.Available)
		{
			ASE_Flurry.LogEvent("MJ_SELECTION_EN_LIGNE");
		}
		this.OnSubmit();
		this.networkMgr.BLanOnly = false;
		this.ActSwapMenu(EMenus.MENU_MULTI_JOIN);
	}

	// Token: 0x06000B1E RID: 2846 RVA: 0x0004AFFC File Offset: 0x000491FC
	private void OnSubmit()
	{
		if (this.Input != null)
		{
			if (ASE_Tools.Available)
			{
				ASE_Flurry.LogEvent("MJ_TON_NOM");
			}
			string text = NGUITools.StripSymbols(this.Input.text);
			string text2 = text.Trim();
			if (!string.IsNullOrEmpty(text2) && text2 != Localization.instance.Get("MENU_PLAYER"))
			{
				Singleton<GameSaveManager>.Instance.SetPseudo(text2, true);
			}
			else if (this.Input.text.Equals(string.Empty))
			{
				Singleton<GameSaveManager>.Instance.SetPseudo(string.Empty, true);
			}
			this.Input.selected = false;
		}
	}

	// Token: 0x06000B1F RID: 2847 RVA: 0x00009AC7 File Offset: 0x00007CC7
	public override void Update()
	{
		if (Application.platform == RuntimePlatform.Android && UnityEngine.Input.GetKeyDown(KeyCode.Escape))
		{
			this.ActSwapMenu(EMenus.MENU_WELCOME);
		}
	}

	// Token: 0x06000B20 RID: 2848 RVA: 0x00009AE9 File Offset: 0x00007CE9
	public override void ActSwapMenu(EMenus NextMenu)
	{
		if (ASE_Tools.Available && NextMenu == EMenus.MENU_WELCOME)
		{
			ASE_Flurry.LogEvent("MJ_RETOUR_MENU_PRINCIPAL");
		}
		base.ActSwapMenu(NextMenu);
	}

	// Token: 0x04000AF0 RID: 2800
	private NetworkMgr networkMgr;

	// Token: 0x04000AF1 RID: 2801
	public int nameLengthLimit = 8;

	// Token: 0x04000AF2 RID: 2802
	public UIInput Input;
}

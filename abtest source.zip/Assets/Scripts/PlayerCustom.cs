﻿using System;
using UnityEngine;

// Token: 0x020000FA RID: 250
public class PlayerCustom : MonoBehaviour
{
	// Token: 0x17000102 RID: 258
	// (get) Token: 0x060006BC RID: 1724 RVA: 0x00006BDB File Offset: 0x00004DDB
	// (set) Token: 0x060006BD RID: 1725 RVA: 0x00006BE3 File Offset: 0x00004DE3
	public KartCustom KartCustom
	{
		get
		{
			return this.m_pKartCustom;
		}
		set
		{
			this.m_pKartCustom = value;
		}
	}

	// Token: 0x17000103 RID: 259
	// (get) Token: 0x060006BE RID: 1726 RVA: 0x00006BEC File Offset: 0x00004DEC
	// (set) Token: 0x060006BF RID: 1727 RVA: 0x00006BF4 File Offset: 0x00004DF4
	public BonusCustom BonusCustom
	{
		get
		{
			return this.m_pBonusCustom;
		}
		set
		{
			this.m_pBonusCustom = value;
		}
	}

	// Token: 0x060006C0 RID: 1728 RVA: 0x00006BFD File Offset: 0x00004DFD
	public void Awake()
	{
		this.m_pBonusCustom = null;
		this.m_pKartCustom = null;
		this.m_pPlayerCarac = null;
	}

	// Token: 0x060006C1 RID: 1729 RVA: 0x00006C14 File Offset: 0x00004E14
	public void Start()
	{
		this.m_pPlayerCarac = base.transform.parent.FindChild("Tunning").GetComponent<PlayerCarac>();
	}

	// Token: 0x060006C2 RID: 1730 RVA: 0x00034428 File Offset: 0x00032628
	public float GetBonusValue(EITEM _Bonus, EBonusCustomEffect _Effect)
	{
		if (this.m_pBonusCustom != null && _Bonus == this.m_pBonusCustom.Category && _Effect == this.m_pBonusCustom.Effect && this.m_pPlayerCarac != null && this.m_pPlayerCarac.CharacterCarac != null)
		{
			float num = 0f;
			if (this.m_pPlayerCarac.CharacterCarac.Owner == this.m_pBonusCustom.Character)
			{
				if (_Effect == EBonusCustomEffect.QUANTITY || _Effect == EBonusCustomEffect.STICK)
				{
					num = this.m_pBonusCustom.MegaValue;
				}
				else
				{
					num = this.m_pBonusCustom.MegaValue * this.m_pBonusCustom.Value / 100f;
				}
			}
			return this.m_pBonusCustom.Value + num;
		}
		return 0f;
	}

	// Token: 0x040006B3 RID: 1715
	private BonusCustom m_pBonusCustom;

	// Token: 0x040006B4 RID: 1716
	private KartCustom m_pKartCustom;

	// Token: 0x040006B5 RID: 1717
	private PlayerCarac m_pPlayerCarac;
}

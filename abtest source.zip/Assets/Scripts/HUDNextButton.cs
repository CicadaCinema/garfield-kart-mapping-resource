﻿using System;
using UnityEngine;

// Token: 0x02000113 RID: 275
public class HUDNextButton : MonoBehaviour
{
	// Token: 0x06000790 RID: 1936 RVA: 0x0000760A File Offset: 0x0000580A
	public void Update()
	{
		if (this.m_fElapsedTime < this.Timer)
		{
			this.m_fElapsedTime += Time.deltaTime;
		}
	}

	// Token: 0x06000791 RID: 1937 RVA: 0x0000762F File Offset: 0x0000582F
	private void OnClick()
	{
		if (HUDNextButton.OnNextClick != null && this.m_fElapsedTime > this.Timer)
		{
			HUDNextButton.OnNextClick();
			this.m_fElapsedTime = 0f;
		}
	}

	// Token: 0x0400076F RID: 1903
	public float Timer = 0.3f;

	// Token: 0x04000770 RID: 1904
	public static Action OnNextClick;

	// Token: 0x04000771 RID: 1905
	private float m_fElapsedTime;
}

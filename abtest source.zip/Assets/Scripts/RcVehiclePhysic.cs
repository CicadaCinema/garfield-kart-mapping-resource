﻿using System;
using UnityEngine;

// Token: 0x0200022A RID: 554
public abstract class RcVehiclePhysic : MonoBehaviour
{
	// Token: 0x06000F8D RID: 3981 RVA: 0x00063F0C File Offset: 0x0006210C
	public RcVehiclePhysic()
	{
		this.m_pVehicle = null;
		this.m_pVehicleRigidBody = null;
		this.m_iNbWheels = 0;
		this.m_fWVelocity = 0f;
		this.m_bTouchedDeath = false;
		this.m_fDeathDelay = 1.5f;
		this.m_pCollisionListeners = new RcCollisionListener[8];
		this.m_bEnabled = true;
	}

	// Token: 0x170001FE RID: 510
	// (get) Token: 0x06000F8E RID: 3982 RVA: 0x0000C98C File Offset: 0x0000AB8C
	public float FDeathDelay
	{
		get
		{
			return this.m_fDeathDelay;
		}
	}

	// Token: 0x170001FF RID: 511
	// (get) Token: 0x06000F8F RID: 3983 RVA: 0x0000C994 File Offset: 0x0000AB94
	public bool BTouchedDeath
	{
		get
		{
			return this.m_bTouchedDeath;
		}
	}

	// Token: 0x06000F90 RID: 3984 RVA: 0x0000C99C File Offset: 0x0000AB9C
	public void ResetTouchedDeath()
	{
		this.m_bTouchedDeath = false;
	}

	// Token: 0x06000F91 RID: 3985 RVA: 0x0000C9A5 File Offset: 0x0000ABA5
	public Transform GetTransform()
	{
		return this.m_pTransform;
	}

	// Token: 0x17000200 RID: 512
	// (get) Token: 0x06000F92 RID: 3986 RVA: 0x0000C9AD File Offset: 0x0000ABAD
	// (set) Token: 0x06000F93 RID: 3987 RVA: 0x0000C9B5 File Offset: 0x0000ABB5
	public bool Enable
	{
		get
		{
			return this.m_bEnabled;
		}
		set
		{
			this.m_bEnabled = value;
		}
	}

	// Token: 0x06000F94 RID: 3988 RVA: 0x0000C9BE File Offset: 0x0000ABBE
	public int GetNbWheels()
	{
		return this.m_iNbWheels;
	}

	// Token: 0x06000F95 RID: 3989 RVA: 0x00063F70 File Offset: 0x00062170
	public virtual void Start()
	{
		this.m_pVehicleRigidBody = base.transform.parent.GetComponentInChildren<Rigidbody>();
		this.m_pVehicleRigidBodyTransform = this.m_pVehicleRigidBody.transform;
		this.m_pVehicle = base.transform.parent.GetComponentInChildren<RcVehicle>();
		this.m_pTransform = base.transform;
	}

	// Token: 0x06000F96 RID: 3990 RVA: 0x00063FC8 File Offset: 0x000621C8
	public virtual void Stop()
	{
		for (int i = 0; i < 8; i++)
		{
			this.m_pCollisionListeners[i] = null;
		}
	}

	// Token: 0x06000F97 RID: 3991 RVA: 0x0000C9C6 File Offset: 0x0000ABC6
	public virtual void Update()
	{
		this.m_fWVelocity = this.m_pVehicle.GetWheelSpeedMS() * (1f - this.m_pVehicle.GetHandicap());
	}

	// Token: 0x06000F98 RID: 3992 RVA: 0x00003B7D File Offset: 0x00001D7D
	public virtual bool IsGoingTooFast()
	{
		return false;
	}

	// Token: 0x06000F99 RID: 3993 RVA: 0x00063FF0 File Offset: 0x000621F0
	public void AddCollisionListener(RcCollisionListener _Listener)
	{
		for (int i = 0; i < 8; i++)
		{
			if (this.m_pCollisionListeners[i] == null)
			{
				this.m_pCollisionListeners[i] = _Listener;
				return;
			}
		}
	}

	// Token: 0x06000F9A RID: 3994 RVA: 0x00064028 File Offset: 0x00062228
	public void RemoveCollisionListener(RcCollisionListener _Listener)
	{
		for (int i = 0; i < 8; i++)
		{
			if (this.m_pCollisionListeners[i] == _Listener)
			{
				this.m_pCollisionListeners[i] = null;
				return;
			}
		}
	}

	// Token: 0x06000F9B RID: 3995 RVA: 0x00064060 File Offset: 0x00062260
	public virtual void FireOnCollision(CollisionData collisionInfos)
	{
		for (int i = 0; i < 8; i++)
		{
			if (this.m_pCollisionListeners[i] != null)
			{
				this.m_pCollisionListeners[i].OnCollision(collisionInfos);
			}
		}
	}

	// Token: 0x06000F9C RID: 3996 RVA: 0x0000B3D6 File Offset: 0x000095D6
	public virtual float GetDriftRatio()
	{
		return 0f;
	}

	// Token: 0x06000F9D RID: 3997 RVA: 0x0000C9EB File Offset: 0x0000ABEB
	public bool HasVehicleBody()
	{
		return this.m_pVehicleRigidBody != null;
	}

	// Token: 0x06000F9E RID: 3998 RVA: 0x0000C9F9 File Offset: 0x0000ABF9
	public Rigidbody GetVehicleBody()
	{
		return this.m_pVehicleRigidBody;
	}

	// Token: 0x06000F9F RID: 3999 RVA: 0x0000CA01 File Offset: 0x0000AC01
	public Transform GetVehicleBodyTransform()
	{
		return this.m_pVehicleRigidBodyTransform;
	}

	// Token: 0x06000FA0 RID: 4000 RVA: 0x0000CA09 File Offset: 0x0000AC09
	private GameObject GetVehicleNode()
	{
		return base.gameObject;
	}

	// Token: 0x06000FA1 RID: 4001 RVA: 0x0000CA11 File Offset: 0x0000AC11
	public RcVehicle GetVehicle()
	{
		return this.m_pVehicle;
	}

	// Token: 0x06000FA2 RID: 4002 RVA: 0x0000CA19 File Offset: 0x0000AC19
	public int GetGroundSurface()
	{
		return this.m_iGroundSurface;
	}

	// Token: 0x06000FA3 RID: 4003
	public abstract Vector3 GetLinearVelocity();

	// Token: 0x06000FA4 RID: 4004
	public abstract Vector3 ForecastPosition(float dtSec);

	// Token: 0x06000FA5 RID: 4005
	public abstract void SetGripFactor(float _factor);

	// Token: 0x06000FA6 RID: 4006
	public abstract float GetGripFactor();

	// Token: 0x06000FA7 RID: 4007
	public abstract float GetWheelSpeed();

	// Token: 0x06000FA8 RID: 4008
	public abstract float GetFrontToRearWheelLength();

	// Token: 0x06000FA9 RID: 4009 RVA: 0x0000CA21 File Offset: 0x0000AC21
	public void Teleport(Vector3 vTeleportPos, Quaternion qTeleportOrientation)
	{
		this.Teleport(vTeleportPos, qTeleportOrientation, Vector3.zero);
	}

	// Token: 0x06000FAA RID: 4010 RVA: 0x0000CA30 File Offset: 0x0000AC30
	public void Teleport(Vector3 vTeleportPos, Quaternion qTeleportOrientation, Vector3 linearVelocity)
	{
		this.Teleport(vTeleportPos, qTeleportOrientation, linearVelocity, Vector3.zero);
	}

	// Token: 0x06000FAB RID: 4011
	public abstract void Teleport(Vector3 vTeleportPos, Quaternion qTeleportOrientation, Vector3 linearVelocity, Vector3 angularVelocity);

	// Token: 0x06000FAC RID: 4012
	public abstract void NetMove(Vector3 vTeleportPos, Quaternion qTeleportOrientation, Vector3 linearVelocity, Vector3 angularVelocity);

	// Token: 0x06000FAD RID: 4013
	public abstract RcPhysicWheel[] GetWheels();

	// Token: 0x06000FAE RID: 4014
	public abstract void Reset();

	// Token: 0x06000FAF RID: 4015
	public abstract Vector3 GetAngularVelocity();

	// Token: 0x06000FB0 RID: 4016
	public abstract void SetLinearVelocity(Vector3 velocity);

	// Token: 0x06000FB1 RID: 4017
	public abstract void SetAngularVelocity(Vector3 velocity);

	// Token: 0x04000F1F RID: 3871
	private const int MAX_VEHICLE_COLLISION_LISTENER = 8;

	// Token: 0x04000F20 RID: 3872
	protected RcVehicle m_pVehicle;

	// Token: 0x04000F21 RID: 3873
	protected Rigidbody m_pVehicleRigidBody;

	// Token: 0x04000F22 RID: 3874
	protected int m_iGroundSurface;

	// Token: 0x04000F23 RID: 3875
	protected Vector3 m_fGroundNormal = Vector3.up;

	// Token: 0x04000F24 RID: 3876
	protected int m_iNbWheels;

	// Token: 0x04000F25 RID: 3877
	protected float m_fWVelocity;

	// Token: 0x04000F26 RID: 3878
	protected bool m_bTouchedDeath;

	// Token: 0x04000F27 RID: 3879
	protected RcCollisionListener[] m_pCollisionListeners;

	// Token: 0x04000F28 RID: 3880
	protected Transform m_pVehicleRigidBodyTransform;

	// Token: 0x04000F29 RID: 3881
	protected Transform m_pTransform;

	// Token: 0x04000F2A RID: 3882
	protected float m_fDeathDelay;

	// Token: 0x04000F2B RID: 3883
	protected bool m_bEnabled;
}

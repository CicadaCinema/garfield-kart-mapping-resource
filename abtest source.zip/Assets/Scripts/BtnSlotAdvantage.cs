﻿using System;
using UnityEngine;

// Token: 0x02000190 RID: 400
public class BtnSlotAdvantage : MonoBehaviour
{
	// Token: 0x1700017B RID: 379
	// (get) Token: 0x06000ACD RID: 2765 RVA: 0x000096AE File Offset: 0x000078AE
	public bool IsEmpty
	{
		get
		{
			return this.m_bEmpty;
		}
	}

	// Token: 0x1700017C RID: 380
	// (get) Token: 0x06000ACE RID: 2766 RVA: 0x000096B6 File Offset: 0x000078B6
	public bool IsActive
	{
		get
		{
			return this.m_bIsActive;
		}
	}

	// Token: 0x06000ACF RID: 2767 RVA: 0x000496D0 File Offset: 0x000478D0
	public void Start()
	{
		Transform parent = base.transform.parent;
		while (parent)
		{
			if (parent.GetComponent<PanelAdvantages>())
			{
				break;
			}
			parent = parent.parent;
		}
		if (parent)
		{
			this.m_pPanelAdvantages = parent.GetComponent<PanelAdvantages>();
		}
		this.m_pIcon.gameObject.SetActive(false);
	}

	// Token: 0x06000AD0 RID: 2768 RVA: 0x00049740 File Offset: 0x00047940
	public void SetEnable(bool bIsEnabled)
	{
		base.gameObject.SetActive(bIsEnabled);
		if (bIsEnabled)
		{
			this.OnUpdatePanel();
		}
		else
		{
			this.m_pIcon.gameObject.SetActive(false);
			if (!this.m_bEmpty)
			{
				this.m_pItem.UnlockItem();
				this.m_bEmpty = true;
			}
		}
	}

	// Token: 0x06000AD1 RID: 2769 RVA: 0x000096BE File Offset: 0x000078BE
	public void OnUpdatePanel()
	{
		if (this.m_bEmpty)
		{
			this.m_pIcon.gameObject.SetActive(false);
		}
		else
		{
			this.m_pIcon.gameObject.SetActive(true);
		}
	}

	// Token: 0x06000AD2 RID: 2770 RVA: 0x00049798 File Offset: 0x00047998
	public void SetItem(BtnItemAdvantage pItem)
	{
		this.m_pItem = pItem;
		this.m_pIcon.ChangeTexture((int)this.m_pItem.m_eAdvantage);
		this.m_pIcon.transform.localScale = this.m_pItem.m_pIcon.transform.localScale;
		this.m_pItem.LockItem();
		this.m_pItem.OnUpdatePanel();
		this.m_bEmpty = false;
		this.OnUpdatePanel();
		if (this.DropAdvantageSound)
		{
			this.DropAdvantageSound.Play();
		}
	}

	// Token: 0x06000AD3 RID: 2771 RVA: 0x00049828 File Offset: 0x00047A28
	private void OnPress(bool bIsPressed)
	{
		if (bIsPressed)
		{
			if (this.m_bEmpty)
			{
				return;
			}
			if (!this.m_pItem)
			{
				return;
			}
			this.m_pItem.UnlockItem();
			this.m_bEmpty = true;
			this.OnUpdatePanel();
			Transform advantageBtnItem = this.m_pPanelAdvantages.GetAdvantageBtnItem(this.m_pItem.m_eAdvantage);
			if (advantageBtnItem)
			{
				advantageBtnItem.gameObject.SendMessage("OnClick");
			}
		}
	}

	// Token: 0x06000AD4 RID: 2772 RVA: 0x000096F2 File Offset: 0x000078F2
	public void ValidSlot()
	{
		if (!this.m_bEmpty)
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.AddAdvantage(this.m_pItem.m_eAdvantage);
		}
	}

	// Token: 0x06000AD5 RID: 2773 RVA: 0x000498A4 File Offset: 0x00047AA4
	public void Initialize()
	{
		if (this.m_bEmpty)
		{
			return;
		}
		if (this.m_pPanelAdvantages && !this.m_pPanelAdvantages.IsAdvantageAvailable(this.m_pItem.m_eAdvantage))
		{
			this.m_pItem.UnlockItem();
			this.m_bEmpty = true;
			this.OnUpdatePanel();
		}
	}

	// Token: 0x06000AD6 RID: 2774 RVA: 0x00009719 File Offset: 0x00007919
	public void OnEnable()
	{
		this.m_bIsActive = true;
	}

	// Token: 0x06000AD7 RID: 2775 RVA: 0x00009722 File Offset: 0x00007922
	public void OnDisable()
	{
		this.m_bIsActive = false;
	}

	// Token: 0x04000AA0 RID: 2720
	private PanelAdvantages m_pPanelAdvantages;

	// Token: 0x04000AA1 RID: 2721
	public UITexturePattern m_pIcon;

	// Token: 0x04000AA2 RID: 2722
	private bool m_bEmpty = true;

	// Token: 0x04000AA3 RID: 2723
	private BtnItemAdvantage m_pItem;

	// Token: 0x04000AA4 RID: 2724
	public AudioSource DropAdvantageSound;

	// Token: 0x04000AA5 RID: 2725
	public bool m_bIsActive;
}

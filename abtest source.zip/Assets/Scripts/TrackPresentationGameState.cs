﻿using System;
using UnityEngine;

// Token: 0x02000173 RID: 371
public class TrackPresentationGameState : GameState
{
	// Token: 0x060009FB RID: 2555 RVA: 0x00008C75 File Offset: 0x00006E75
	public void Awake()
	{
		GameEntryPoint.OnVehicleCreated = (Action)Delegate.Combine(GameEntryPoint.OnVehicleCreated, new Action(this.VehicleCreated));
		this.networkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
	}

	// Token: 0x060009FC RID: 2556 RVA: 0x00008CB1 File Offset: 0x00006EB1
	public new void OnDestroy()
	{
		GameEntryPoint.OnVehicleCreated = (Action)Delegate.Remove(GameEntryPoint.OnVehicleCreated, new Action(this.VehicleCreated));
	}

	// Token: 0x060009FD RID: 2557 RVA: 0x00045578 File Offset: 0x00043778
	public override void Enter()
	{
		Singleton<GameManager>.Instance.GameMode.MainMusic.Stop();
		Singleton<GameManager>.Instance.SoundManager.PlayMusic(ERaceMusicLoops.TrackPresentation);
		this.m_bKeyPressed = false;
		GameObject gameObject = GameObject.Find("SplineRespawn");
		RcMultiPath pathToFollow = null;
		if (gameObject != null)
		{
			pathToFollow = gameObject.GetComponent<RcMultiPath>();
		}
		Camera.main.GetComponent<CamStatePath>().Setup(pathToFollow);
		Camera.main.GetComponent<CameraBase>().SwitchCamera(ECamState.Path, ECamState.TransCut);
		HUDInGame hud = this.m_pGameMode.Hud;
		if (hud != null)
		{
			hud.EnterTrackPresentation();
		}
	}

	// Token: 0x060009FE RID: 2558 RVA: 0x00045610 File Offset: 0x00043810
	public override void Exit()
	{
		if (Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantage() == EAdvantage.PuzzleRadar)
		{
			Kart humanKart = this.m_pGameMode.GetHumanKart();
			foreach (PuzzlePiece puzzlePiece in UnityEngine.Object.FindSceneObjectsOfType(typeof(PuzzlePiece)))
			{
				puzzlePiece.Player = humanKart;
			}
		}
		HUDInGame hud = Singleton<GameManager>.Instance.GameMode.Hud;
		if (hud != null)
		{
			hud.ExitTrackPresentation();
		}
	}

	// Token: 0x060009FF RID: 2559 RVA: 0x00008C0B File Offset: 0x00006E0B
	private void VehicleCreated()
	{
		((InGameGameMode)this.m_pGameMode).VehicleCreated();
	}

	// Token: 0x06000A00 RID: 2560 RVA: 0x00045698 File Offset: 0x00043898
	public override void Update()
	{
		EVehiclePlacementState placeVehicles = ((InGameGameMode)this.m_pGameMode).PlaceVehicles;
		if (placeVehicles == EVehiclePlacementState.Init)
		{
			if (this.m_pGameMode.Hud.TrackPresentation != null && this.m_pGameMode.Hud.TrackPresentation.ValidateAdvantage())
			{
				((InGameGameMode)this.m_pGameMode).ValidateAdvantage();
			}
		}
		else if (placeVehicles == EVehiclePlacementState.ReadyToTeleport)
		{
			if (!this.m_bKeyPressed)
			{
				this.m_bKeyPressed = true;
				if (Network.peerType != NetworkPeerType.Disconnected && !this.networkMgr.WaitingSynchronization)
				{
					this.networkMgr.StartSynchronization();
				}
			}
			if (this.m_bKeyPressed && (Network.peerType == NetworkPeerType.Disconnected || !this.networkMgr.WaitingSynchronization))
			{
				((InGameGameMode)this.m_pGameMode).TeleportVehiclesOnStartLine();
				this.m_bKeyPressed = false;
			}
		}
		if (placeVehicles == EVehiclePlacementState.ReadyToStart)
		{
			if (!this.m_bKeyPressed)
			{
				this.m_bKeyPressed = true;
				if (Network.peerType != NetworkPeerType.Disconnected && !this.networkMgr.WaitingSynchronization)
				{
					this.networkMgr.StartSynchronization();
				}
			}
			if (this.m_bKeyPressed && (Network.peerType == NetworkPeerType.Disconnected || !this.networkMgr.WaitingSynchronization))
			{
				this.OnStateChanged(E_GameState.CarPresentation);
			}
		}
	}

	// Token: 0x04000A0A RID: 2570
	private bool m_bKeyPressed;

	// Token: 0x04000A0B RID: 2571
	private NetworkMgr networkMgr;
}

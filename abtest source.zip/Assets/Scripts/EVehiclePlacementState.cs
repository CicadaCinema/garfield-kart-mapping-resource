﻿using System;

// Token: 0x02000184 RID: 388
public enum EVehiclePlacementState
{
	// Token: 0x04000A40 RID: 2624
	Init,
	// Token: 0x04000A41 RID: 2625
	ValidateAdvantage,
	// Token: 0x04000A42 RID: 2626
	ComputeInitialPlacement,
	// Token: 0x04000A43 RID: 2627
	ReadyToTeleport,
	// Token: 0x04000A44 RID: 2628
	NeedToTeleport,
	// Token: 0x04000A45 RID: 2629
	Teleported,
	// Token: 0x04000A46 RID: 2630
	ReadyToStart
}

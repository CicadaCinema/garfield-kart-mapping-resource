﻿using System;

// Token: 0x020001A4 RID: 420
public class MenuRewardsAdvantages : MenuRewards
{
	// Token: 0x06000B61 RID: 2913 RVA: 0x0004C9C0 File Offset: 0x0004ABC0
	public override void OnEnter()
	{
		base.OnEnter();
		this._advantages = Singleton<RewardManager>.Instance.PopAdvantage();
		string key = string.Empty;
		switch (Singleton<GameConfigurator>.Instance.Difficulty)
		{
		case EDifficulty.NORMAL:
			key = "MENU_DIFFICULTY_NORMAL";
			break;
		case EDifficulty.HARD:
			key = "MENU_DIFFICULTY_HARD";
			break;
		case EDifficulty.EASY:
			key = "MENU_DIFFICULTY_EASY";
			break;
		}
		this.LbMessage.text = string.Format(Localization.instance.Get("MENU_REWARDS_AVANTAGES_GROUP"), Localization.instance.Get(key));
	}

	// Token: 0x06000B62 RID: 2914 RVA: 0x0004CA58 File Offset: 0x0004AC58
	public override void OnGoNext()
	{
		foreach (string text in this._advantages)
		{
			if (text != null)
			{
				EAdvantage eadvantage = (EAdvantage)((int)Enum.Parse(typeof(EAdvantage), text));
				if (eadvantage != EAdvantage.None)
				{
					Singleton<GameSaveManager>.Instance.SetAdvantageState(eadvantage, E_UnlockableItemSate.NewLocked, false);
				}
			}
		}
		Singleton<GameSaveManager>.Instance.Save();
		base.OnGoNext();
	}

	// Token: 0x04000B29 RID: 2857
	private string[] _advantages;
}

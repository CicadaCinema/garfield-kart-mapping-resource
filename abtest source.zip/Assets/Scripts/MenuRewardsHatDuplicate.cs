﻿using System;

// Token: 0x020001AC RID: 428
public class MenuRewardsHatDuplicate : MenuRewards
{
	// Token: 0x06000B7B RID: 2939 RVA: 0x0004CF94 File Offset: 0x0004B194
	public override void OnEnter()
	{
		base.OnEnter();
		Tuple<string, ERarity> tuple = Singleton<RewardManager>.Instance.PopUnlockedHat();
		this._hat = tuple.Item1;
		this._rarity = tuple.Item2;
		Tuple<string, UIAtlas, string, ERarity> infos = base.GetInfos(this._hat, E_RewardType.Hat);
		this.LbRewardName.text = infos.Item1;
		if (this.Sprite != null)
		{
			this.Sprite.spriteName = infos.Item3;
		}
		if (this.SpriteRarity != null)
		{
			this.SpriteRarity.ChangeTexture(Tricks.LogBase2((int)infos.Item4));
		}
		this.LbMessage.text = Localization.instance.Get("MENU_REWARDS_HATS_DOUBLON");
		this.LTradePrice.text = this.TradePrice.ToString();
		this.LResellPrice.text = this.ResellPrice.ToString();
	}

	// Token: 0x06000B7C RID: 2940 RVA: 0x0000A011 File Offset: 0x00008211
	public void OnTrade()
	{
		if (Singleton<GameSaveManager>.Instance.GetCoins() > this.TradePrice)
		{
			Singleton<GameSaveManager>.Instance.SpendCoins(this.TradePrice, false);
			Singleton<RewardManager>.Instance.TradeReward(this._rarity);
		}
		this.OnGoNext();
	}

	// Token: 0x06000B7D RID: 2941 RVA: 0x0000A04F File Offset: 0x0000824F
	public void OnResell()
	{
		Singleton<GameSaveManager>.Instance.EarnCoins(this.ResellPrice, false, false);
		this.OnGoNext();
	}

	// Token: 0x04000B3C RID: 2876
	private string _hat;

	// Token: 0x04000B3D RID: 2877
	private ERarity _rarity;

	// Token: 0x04000B3E RID: 2878
	public int ResellPrice;

	// Token: 0x04000B3F RID: 2879
	public int TradePrice;

	// Token: 0x04000B40 RID: 2880
	public UILabel LTradePrice;

	// Token: 0x04000B41 RID: 2881
	public UILabel LResellPrice;
}

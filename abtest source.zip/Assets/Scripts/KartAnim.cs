﻿using System;
using UnityEngine;

// Token: 0x02000141 RID: 321
public class KartAnim : MonoBehaviour
{
	// Token: 0x060008FD RID: 2301 RVA: 0x000403DC File Offset: 0x0003E5DC
	public KartAnim()
	{
		this.m_pKart = null;
		this._kartAnimController = null;
		this._characterAnimController = null;
		this.steeringFactor = 0f;
		this.steeringMassFactor = 0f;
		this.accelerationMassFactor = 0f;
	}

	// Token: 0x17000154 RID: 340
	// (get) Token: 0x060008FE RID: 2302 RVA: 0x00008406 File Offset: 0x00006606
	// (set) Token: 0x060008FF RID: 2303 RVA: 0x0000840E File Offset: 0x0000660E
	public bool CanQueueAnim
	{
		get
		{
			return this.m_bCanQueueAnim;
		}
		set
		{
			this.m_bCanQueueAnim = value;
		}
	}

	// Token: 0x06000900 RID: 2304 RVA: 0x00003B80 File Offset: 0x00001D80
	public void Awake()
	{
	}

	// Token: 0x06000901 RID: 2305 RVA: 0x00040438 File Offset: 0x0003E638
	public void Start()
	{
		this.m_pKart = base.transform.parent.GetComponentInChildren<Kart>();
		this._kartAnimController = new GkAnimController(this.m_pKartAnimatorOwner.GetComponent<Animator>());
		this._characterAnimController = new GkAnimController(this.m_pCharacterAnimatorOwner.GetComponent<Animator>());
		RcPhysicWheel[] wheels = this.m_pKart.GetVehiclePhysic().GetWheels();
		int nbWheels = this.m_pKart.GetNbWheels();
		for (int i = 0; i < nbWheels; i++)
		{
			RcPhysicWheel rcPhysicWheel = wheels[i];
			rcPhysicWheel.VMaxSqueeze = this.m_vMaxWheelSqueeze;
		}
		this.m_iSuccesAnim = Animator.StringToHash("Base Layer.Succes_1");
	}

	// Token: 0x06000902 RID: 2306 RVA: 0x00008417 File Offset: 0x00006617
	public void LaunchDefeatAnim(bool pLaunch)
	{
		if (this.m_bCanQueueAnim)
		{
			this._characterAnimController.Animator.SetBool("Defeat", pLaunch);
		}
	}

	// Token: 0x06000903 RID: 2307 RVA: 0x0000843A File Offset: 0x0000663A
	public void LaunchVictoryAnim(bool pLaunch)
	{
		if (this.m_bCanQueueAnim)
		{
			this._characterAnimController.Animator.SetBool("Victory", pLaunch);
		}
	}

	// Token: 0x06000904 RID: 2308 RVA: 0x0000845D File Offset: 0x0000665D
	public void LaunchSuccessAnim(bool pLaunch)
	{
		if (this.m_bCanQueueAnim)
		{
			this._characterAnimController.Animator.SetBool("Projectile_Succes", pLaunch);
		}
	}

	// Token: 0x06000905 RID: 2309 RVA: 0x000404D8 File Offset: 0x0003E6D8
	public void Update()
	{
		float deltaTime = Time.deltaTime;
		float v = RcUtils.LinearInterpolation(-20f, -1f, 20f, 0.5f, this.m_pKart.GetWheelAccelMSS(), true);
		this.SteeringAnim(deltaTime);
		if (this.m_pKart.IsBoosting())
		{
			v = 1f;
		}
		float v2 = 0.5f * (1f + Mathf.Abs(this.m_pKart.GetArcadeDriftFactor())) * RcUtils.LinearInterpolation(-10f, -1f, 10f, 1f, Mathf.Abs(this.m_pKart.GetWheelSpeedMS()) * Mathf.Abs(this.m_pKart.GetWheelSpeedMS()) * this.m_pKart.GetSteeringAngle(), true);
		RcUtils.COMPUTE_INERTIA(ref this.steeringMassFactor, v2, 0.995f, deltaTime * 1000f);
		RcUtils.COMPUTE_INERTIA(ref this.accelerationMassFactor, v, 0.995f, deltaTime * 1000f);
		this._kartAnimController.Animator.SetFloat("Speed", Mathf.Abs(this.m_pKart.GetWheelSpeedMS()));
		this._kartAnimController.Animator.SetFloat("Direction", this.steeringMassFactor);
		this._kartAnimController.Animator.SetFloat("Acceleration", -this.accelerationMassFactor);
		this._characterAnimController.Animator.SetFloat("Speed", this.m_pKart.GetWheelSpeedMS());
		this._characterAnimController.Animator.SetBool("Boost", this.m_pKart.IsBoosting());
		this._characterAnimController.Animator.SetFloat("Direction", -this.steeringFactor);
		this._kartAnimController.Update();
		this._characterAnimController.Update();
		if (this._characterAnimController.Animator.GetCurrentAnimatorStateInfo(0).nameHash == this.m_iSuccesAnim)
		{
			this.LaunchSuccessAnim(false);
		}
	}

	// Token: 0x06000906 RID: 2310 RVA: 0x000406BC File Offset: 0x0003E8BC
	public void SteeringAnim(float dt)
	{
		if (dt == 0f)
		{
			return;
		}
		float v = this.m_pKart.GetSteeringFactor();
		this.steeringFactor = Tricks.ComputeInertia(this.steeringFactor, v, 200f, dt * 1000f);
		RcPhysicWheel[] wheels = this.m_pKart.GetVehiclePhysic().GetWheels();
		int nbWheels = this.m_pKart.GetNbWheels();
		for (int i = 0; i < nbWheels; i++)
		{
			RcPhysicWheel rcPhysicWheel = wheels[i];
			if (rcPhysicWheel.BSteeringOn)
			{
				rcPhysicWheel.FSteeringAnimationAngle = -this.steeringFactor * 3.14159274f / 6f;
			}
		}
	}

	// Token: 0x06000907 RID: 2311 RVA: 0x00008480 File Offset: 0x00006680
	public void LaunchBonusAnim(int pAnimParameter, int pAnimState, bool pCanStop, bool pOnKart, bool pOnCharacter)
	{
		if (pOnKart)
		{
			this._kartAnimController.Play(pAnimParameter, pAnimState, pCanStop);
		}
		if (pOnCharacter)
		{
			this._characterAnimController.Play(pAnimParameter, pAnimState, pCanStop);
		}
	}

	// Token: 0x06000908 RID: 2312 RVA: 0x000084AC File Offset: 0x000066AC
	public void StopBonusAnim(int pAnimState, bool pOnKart, bool pOnCharacter)
	{
		if (pOnKart)
		{
			this._kartAnimController.Stop(pAnimState);
		}
		if (pOnCharacter)
		{
			this._characterAnimController.Stop(pAnimState);
		}
	}

	// Token: 0x06000909 RID: 2313 RVA: 0x000084D2 File Offset: 0x000066D2
	public void ForceStopBonusAnim(int pAnimParameter, bool pOnKart, bool pOnCharacter)
	{
		if (pOnKart)
		{
			this._kartAnimController.ForceStop(pAnimParameter);
		}
		if (pOnCharacter)
		{
			this._characterAnimController.ForceStop(pAnimParameter);
		}
	}

	// Token: 0x0600090A RID: 2314 RVA: 0x000084F8 File Offset: 0x000066F8
	public void LaunchBonusAnimAll(int pAnimParameter, int pAnimState, bool pCanStop)
	{
		this.LaunchBonusAnim(pAnimParameter, pAnimState, pCanStop, true, true);
	}

	// Token: 0x0600090B RID: 2315 RVA: 0x00008505 File Offset: 0x00006705
	public void StopBonusAnimAll(int pAnimState)
	{
		this.StopBonusAnim(pAnimState, true, true);
	}

	// Token: 0x0600090C RID: 2316 RVA: 0x00008510 File Offset: 0x00006710
	public void ForceStopBonusAnimAll()
	{
		this._kartAnimController.StopAll();
		this._characterAnimController.StopAll();
	}

	// Token: 0x0600090D RID: 2317 RVA: 0x00008528 File Offset: 0x00006728
	public void LaunchBonusAnimOnKart(int pAnimParameter, int pAnimState, bool pCanStop)
	{
		this.LaunchBonusAnim(pAnimParameter, pAnimState, pCanStop, true, false);
	}

	// Token: 0x0600090E RID: 2318 RVA: 0x0004075C File Offset: 0x0003E95C
	public void StopBonusAnimOnKart(int pAnimState)
	{
		if (this._kartAnimController.Animator.GetCurrentAnimatorStateInfo(0).nameHash == pAnimState)
		{
			this.StopBonusAnim(pAnimState, true, false);
		}
	}

	// Token: 0x0600090F RID: 2319 RVA: 0x00008535 File Offset: 0x00006735
	public void LaunchBonusAnimOnCharacter(int pAnimParameter, int pAnimState, bool pCanStop)
	{
		this.LaunchBonusAnim(pAnimParameter, pAnimState, pCanStop, false, true);
	}

	// Token: 0x06000910 RID: 2320 RVA: 0x00040794 File Offset: 0x0003E994
	public void StopBonusAnimOnCharacter(int pAnimState)
	{
		if (this._characterAnimController.Animator.GetCurrentAnimatorStateInfo(0).nameHash == pAnimState)
		{
			this.StopBonusAnim(pAnimState, false, true);
		}
	}

	// Token: 0x04000929 RID: 2345
	public Transform m_pKartAnimatorOwner;

	// Token: 0x0400092A RID: 2346
	public Transform m_pCharacterAnimatorOwner;

	// Token: 0x0400092B RID: 2347
	public Vector3 m_vMaxWheelSqueeze = Vector3.one;

	// Token: 0x0400092C RID: 2348
	private Kart m_pKart;

	// Token: 0x0400092D RID: 2349
	private GkAnimController _kartAnimController;

	// Token: 0x0400092E RID: 2350
	private GkAnimController _characterAnimController;

	// Token: 0x0400092F RID: 2351
	private float steeringFactor;

	// Token: 0x04000930 RID: 2352
	private float steeringMassFactor;

	// Token: 0x04000931 RID: 2353
	private float accelerationMassFactor;

	// Token: 0x04000932 RID: 2354
	private int m_iSuccesAnim;

	// Token: 0x04000933 RID: 2355
	private bool m_bCanQueueAnim = true;
}

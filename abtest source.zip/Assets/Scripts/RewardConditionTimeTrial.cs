﻿using System;

// Token: 0x02000160 RID: 352
public class RewardConditionTimeTrial : RewardConditionBase
{
	// Token: 0x06000995 RID: 2453 RVA: 0x0004351C File Offset: 0x0004171C
	public override bool CanGiveReward()
	{
		E_TimeTrialMedal medal = Singleton<GameSaveManager>.Instance.GetMedal(this.Track, false);
		E_TimeTrialMedal medal2 = Singleton<RewardManager>.Instance.Medal;
		return medal < this.Medal && medal2 >= this.Medal;
	}

	// Token: 0x040009CF RID: 2511
	public string Track;

	// Token: 0x040009D0 RID: 2512
	public E_TimeTrialMedal Medal;
}

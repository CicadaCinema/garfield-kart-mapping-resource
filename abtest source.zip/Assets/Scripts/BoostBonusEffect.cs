﻿using System;
using UnityEngine;

// Token: 0x020000D3 RID: 211
public class BoostBonusEffect : BonusEffect
{
	// Token: 0x06000591 RID: 1425 RVA: 0x00005FD7 File Offset: 0x000041D7
	public BoostBonusEffect()
	{
		this.SpeedUp = 0f;
		this.Acceleration = 0f;
		this.InertiaVehicle = false;
		this.m_bStoppedByAnim = false;
	}

	// Token: 0x06000592 RID: 1426 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void OnDestroy()
	{
	}

	// Token: 0x06000593 RID: 1427 RVA: 0x00006003 File Offset: 0x00004203
	public override void Start()
	{
		base.Start();
	}

	// Token: 0x06000594 RID: 1428 RVA: 0x0000600B File Offset: 0x0000420B
	public override void Update()
	{
		base.Update();
	}

	// Token: 0x06000595 RID: 1429 RVA: 0x0002C548 File Offset: 0x0002A748
	public override bool Activate()
	{
		base.Activate();
		Kart target = this.m_pBonusEffectMgr.Target;
		float boostDelay = this.EffectDuration + this.m_pBonusEffectMgr.Target.GetBonusMgr().GetBonusValue(EITEM.ITEM_LASAGNA, EBonusCustomEffect.DURATION) * this.EffectDuration / 100f;
		target.Boost(this.SpeedUp, boostDelay, this.Acceleration, true);
		target.KartSound.PlayVoice(KartSound.EVoices.Good);
		if (target.OnBoost != null)
		{
			target.OnBoost();
		}
		return true;
	}

	// Token: 0x0400056F RID: 1391
	[SerializeField]
	[HideInInspector]
	public float SpeedUp;

	// Token: 0x04000570 RID: 1392
	[SerializeField]
	[HideInInspector]
	public float Acceleration;
}

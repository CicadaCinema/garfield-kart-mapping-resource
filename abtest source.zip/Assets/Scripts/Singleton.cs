﻿using System;

// Token: 0x02000243 RID: 579
public class Singleton<T>
{
	// Token: 0x06001028 RID: 4136 RVA: 0x0000CE0C File Offset: 0x0000B00C
	protected Singleton()
	{
		if (Singleton<T>._sInstance != null)
		{
			throw new Exception("instance already exist");
		}
		Singleton<T>._sInstance = this;
		if (Singleton<T>._sInstance == null)
		{
			throw new Exception("instance creation failed");
		}
	}

	// Token: 0x1700020B RID: 523
	// (get) Token: 0x0600102A RID: 4138 RVA: 0x0000CE5A File Offset: 0x0000B05A
	public static T Instance
	{
		get
		{
			if (Singleton<T>._sInstance == null)
			{
				Singleton<T>._sInstance = Activator.CreateInstance(typeof(T));
			}
			return (T)((object)Singleton<T>._sInstance);
		}
	}

	// Token: 0x0600102B RID: 4139 RVA: 0x0000CE84 File Offset: 0x0000B084
	public static void DestroyInstance()
	{
		Singleton<T>._sInstance = null;
		GC.Collect();
	}

	// Token: 0x04000F82 RID: 3970
	private static object _sInstance = Activator.CreateInstance(typeof(T));
}

﻿using System;
using UnityEngine;

// Token: 0x020000CB RID: 203
public class BonusEffect : MonoBehaviour
{
	// Token: 0x06000549 RID: 1353 RVA: 0x0002B1DC File Offset: 0x000293DC
	public BonusEffect()
	{
		this.Activated = false;
		this.m_fCurrentDuration = 0f;
		this.EffectDuration = 0f;
		this.m_pBonusEffectMgr = null;
		this.InertiaVehicle = true;
		this.m_iAnimParameter = -1;
		this.m_iAnimState = -1;
		this.m_bStoppedByAnim = true;
		this.m_eEffectDirection = EBonusEffectDirection.LEFT;
	}

	// Token: 0x170000EC RID: 236
	// (get) Token: 0x0600054B RID: 1355 RVA: 0x00005CF4 File Offset: 0x00003EF4
	// (set) Token: 0x0600054A RID: 1354 RVA: 0x00005CEB File Offset: 0x00003EEB
	public BonusEffectMgr BonusEffectMgr
	{
		get
		{
			return this.m_pBonusEffectMgr;
		}
		set
		{
			this.m_pBonusEffectMgr = value;
		}
	}

	// Token: 0x170000ED RID: 237
	// (get) Token: 0x0600054C RID: 1356 RVA: 0x00005CFC File Offset: 0x00003EFC
	// (set) Token: 0x0600054D RID: 1357 RVA: 0x00005D04 File Offset: 0x00003F04
	public EBonusEffectDirection BonusEffectDirection
	{
		get
		{
			return this.m_eEffectDirection;
		}
		set
		{
			this.m_eEffectDirection = value;
		}
	}

	// Token: 0x0600054E RID: 1358 RVA: 0x00005D0D File Offset: 0x00003F0D
	public virtual void Start()
	{
		this.Activated = false;
		if (this.m_bStoppedByAnim && this.m_Animation != null)
		{
			this.EffectDuration = this.m_Animation.length;
		}
	}

	// Token: 0x0600054F RID: 1359 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void OnDestroy()
	{
	}

	// Token: 0x06000550 RID: 1360 RVA: 0x0002B244 File Offset: 0x00029444
	public virtual void Update()
	{
		if (this.Activated && this.EffectDuration > 0f && this.m_fCurrentDuration > 0f)
		{
			this.m_fCurrentDuration -= Time.deltaTime;
			if (this.m_fCurrentDuration < 0f)
			{
				this.Deactivate();
				Kart target = this.m_pBonusEffectMgr.Target;
				target.Anim.StopBonusAnimAll(this.m_iAnimState);
			}
		}
	}

	// Token: 0x06000551 RID: 1361 RVA: 0x00005D43 File Offset: 0x00003F43
	public virtual void SetDuration()
	{
		this.m_fCurrentDuration = this.EffectDuration;
	}

	// Token: 0x06000552 RID: 1362 RVA: 0x0002B2C4 File Offset: 0x000294C4
	public virtual bool Activate()
	{
		this.Activated = true;
		this.SetDuration();
		if (this.InertiaVehicle)
		{
			Kart target = this.m_pBonusEffectMgr.Target;
			RcKinematicPhysic rcKinematicPhysic = (RcKinematicPhysic)target.GetVehiclePhysic();
			if (this.m_iAnimParameter != -1)
			{
				target.Anim.LaunchBonusAnimAll(this.m_iAnimParameter, this.m_iAnimState, this.m_bStoppedByAnim);
			}
			if (this.InertiaDamping != Vector3.one)
			{
				rcKinematicPhysic.SwitchToInertiaMode(this.m_fCurrentDuration, this.ImpulseForce, false, true, this.InertiaDamping);
			}
			else
			{
				rcKinematicPhysic.SwitchToInertiaMode(this.m_fCurrentDuration, this.ImpulseForce, false, true);
			}
		}
		return true;
	}

	// Token: 0x06000553 RID: 1363 RVA: 0x00005D51 File Offset: 0x00003F51
	public virtual void Deactivate()
	{
		this.Activated = false;
	}

	// Token: 0x04000520 RID: 1312
	public bool Activated;

	// Token: 0x04000521 RID: 1313
	[HideInInspector]
	[SerializeField]
	public float EffectDuration;

	// Token: 0x04000522 RID: 1314
	protected float m_fCurrentDuration;

	// Token: 0x04000523 RID: 1315
	protected BonusEffectMgr m_pBonusEffectMgr;

	// Token: 0x04000524 RID: 1316
	protected bool InertiaVehicle;

	// Token: 0x04000525 RID: 1317
	protected int m_iAnimParameter;

	// Token: 0x04000526 RID: 1318
	protected int m_iAnimState;

	// Token: 0x04000527 RID: 1319
	protected bool m_bStoppedByAnim;

	// Token: 0x04000528 RID: 1320
	public AnimationClip m_Animation;

	// Token: 0x04000529 RID: 1321
	protected EBonusEffectDirection m_eEffectDirection;

	// Token: 0x0400052A RID: 1322
	public Vector3 ImpulseForce;

	// Token: 0x0400052B RID: 1323
	public Vector3 InertiaDamping = Vector3.one;
}

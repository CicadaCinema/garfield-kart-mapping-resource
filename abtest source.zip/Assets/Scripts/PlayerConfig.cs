﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000132 RID: 306
public class PlayerConfig : MonoBehaviour
{
	// Token: 0x1700013E RID: 318
	// (get) Token: 0x06000895 RID: 2197 RVA: 0x0000808A File Offset: 0x0000628A
	// (set) Token: 0x06000896 RID: 2198 RVA: 0x00008092 File Offset: 0x00006292
	public Color PlayerColor
	{
		get
		{
			return this.playerColor;
		}
		set
		{
			this.playerColor = value;
		}
	}

	// Token: 0x1700013F RID: 319
	// (get) Token: 0x06000897 RID: 2199 RVA: 0x0003F164 File Offset: 0x0003D364
	public int NbStars
	{
		get
		{
			int num = 0;
			if (this.HasEasyChampionShipStar)
			{
				num++;
			}
			if (this.HasNormalChampionShipStar)
			{
				num++;
			}
			if (this.HasHardChampionShipStar)
			{
				num++;
			}
			if (this.HasTimeTrialStar)
			{
				num++;
			}
			if (this.HasEndStar)
			{
				num++;
			}
			return num;
		}
	}

	// Token: 0x06000898 RID: 2200 RVA: 0x0000809B File Offset: 0x0000629B
	public void Awake()
	{
		this.m_pSelectedAdvantage = EAdvantage.None;
		this.playerColor = Color.yellow;
	}

	// Token: 0x06000899 RID: 2201 RVA: 0x000080AF File Offset: 0x000062AF
	public List<EAdvantage> GetAdvantages()
	{
		return this.m_pAdvantages;
	}

	// Token: 0x0600089A RID: 2202 RVA: 0x000080B7 File Offset: 0x000062B7
	public EAdvantage GetAdvantage()
	{
		return this.m_pSelectedAdvantage;
	}

	// Token: 0x17000140 RID: 320
	// (get) Token: 0x0600089B RID: 2203 RVA: 0x000080BF File Offset: 0x000062BF
	// (set) Token: 0x0600089C RID: 2204 RVA: 0x000080C7 File Offset: 0x000062C7
	public ECharacter Character
	{
		get
		{
			return this.m_eCharacter;
		}
		set
		{
			this.m_eCharacter = value;
		}
	}

	// Token: 0x17000141 RID: 321
	// (get) Token: 0x0600089D RID: 2205 RVA: 0x000080D0 File Offset: 0x000062D0
	// (set) Token: 0x0600089E RID: 2206 RVA: 0x000080D8 File Offset: 0x000062D8
	public ECharacter Kart
	{
		get
		{
			return this.m_eKart;
		}
		set
		{
			this.m_eKart = value;
		}
	}

	// Token: 0x0600089F RID: 2207 RVA: 0x000080E1 File Offset: 0x000062E1
	public void ResetAdvantages()
	{
		this.m_pSelectedAdvantage = EAdvantage.None;
	}

	// Token: 0x060008A0 RID: 2208 RVA: 0x000080EA File Offset: 0x000062EA
	public void AddAdvantage(EAdvantage _Advantage)
	{
		this.m_pAdvantages.Add(_Advantage);
	}

	// Token: 0x060008A1 RID: 2209 RVA: 0x000080F8 File Offset: 0x000062F8
	public void SelectAdvantage(EAdvantage _Advantage)
	{
		this.m_pSelectedAdvantage = _Advantage;
		this.m_pAdvantages.Remove(this.m_pSelectedAdvantage);
		Singleton<GameSaveManager>.Instance.UseAdvantage(this.m_pSelectedAdvantage, 1, true);
	}

	// Token: 0x040008BB RID: 2235
	public List<string> CharacterPrefab = new List<string>();

	// Token: 0x040008BC RID: 2236
	public List<string> KartPrefab = new List<string>();

	// Token: 0x040008BD RID: 2237
	private List<EAdvantage> m_pAdvantages = new List<EAdvantage>();

	// Token: 0x040008BE RID: 2238
	public ECharacter m_eCharacter;

	// Token: 0x040008BF RID: 2239
	public ECharacter m_eKart;

	// Token: 0x040008C0 RID: 2240
	public BonusCustom m_oHat;

	// Token: 0x040008C1 RID: 2241
	public KartCustom m_oKartCustom;

	// Token: 0x040008C2 RID: 2242
	private EAdvantage m_pSelectedAdvantage;

	// Token: 0x040008C3 RID: 2243
	public static readonly EAdvantage FirstAdvantageBonus = EAdvantage.LasagnaBonus;

	// Token: 0x040008C4 RID: 2244
	public static readonly EAdvantage LastAdvantageBonus = EAdvantage.PieBonus;

	// Token: 0x040008C5 RID: 2245
	public bool HasEasyChampionShipStar;

	// Token: 0x040008C6 RID: 2246
	public bool HasNormalChampionShipStar;

	// Token: 0x040008C7 RID: 2247
	public bool HasHardChampionShipStar;

	// Token: 0x040008C8 RID: 2248
	public bool HasTimeTrialStar;

	// Token: 0x040008C9 RID: 2249
	public bool HasEndStar;

	// Token: 0x040008CA RID: 2250
	private Color playerColor;
}

﻿using System;
using System.Collections.Generic;

// Token: 0x0200014E RID: 334
public class PlayerCarac : RcVehicleCarac
{
	// Token: 0x0600095A RID: 2394 RVA: 0x000087C8 File Offset: 0x000069C8
	public PlayerCarac()
	{
		this.m_pKartArcadeGearBox = null;
		this.m_pKart = null;
		this.CharacterWeight = new List<float>();
	}

	// Token: 0x1700015A RID: 346
	// (get) Token: 0x0600095B RID: 2395 RVA: 0x000087E9 File Offset: 0x000069E9
	// (set) Token: 0x0600095C RID: 2396 RVA: 0x000087F1 File Offset: 0x000069F1
	public KartCarac KartCarac
	{
		get
		{
			return this.m_pKartCarac;
		}
		set
		{
			this.m_pKartCarac = value;
		}
	}

	// Token: 0x1700015B RID: 347
	// (get) Token: 0x0600095D RID: 2397 RVA: 0x000087FA File Offset: 0x000069FA
	// (set) Token: 0x0600095E RID: 2398 RVA: 0x00008802 File Offset: 0x00006A02
	public CharacterCarac CharacterCarac
	{
		get
		{
			return this.m_pCharacterCarac;
		}
		set
		{
			this.m_pCharacterCarac = value;
		}
	}

	// Token: 0x0600095F RID: 2399 RVA: 0x00042A28 File Offset: 0x00040C28
	public override void Start()
	{
		base.Start();
		this.m_pKartArcadeGearBox = base.transform.parent.FindChild("Tunning").GetComponent<KartArcadeGearBox>();
		this.m_pKart = base.transform.parent.GetComponentInChildren<Kart>();
		this.m_fDecelTimeDiff = this.m_fDecelerationTime - this.MaxDecelerationTime;
		this.m_fBrakingTimeDiff = this.m_fBrakingTime - this.MaxBrakingTime;
		this.m_fSteeringTimeDiff = this.m_fTimeToMaxSteering - this.MaxSteeringTime;
		this.m_fResetSteeringNoInputDiff = this.m_fResetSteeringNoInput - this.MaxResetSteeringNoInput;
		this.m_fDriftResetSteeringNoInputDiff = this.m_fDriftResetSteeringNoInput - this.MaxDriftResetSteeringNoInput;
		this.m_fResetSteeringOppositeInputDiff = this.m_fResetSteeringOppositeInput - this.MaxResetSteeringOppositeInput;
	}

	// Token: 0x06000960 RID: 2400 RVA: 0x00042AE4 File Offset: 0x00040CE4
	public void ApplySpeedRefAdvantages(int _Index)
	{
		float speedRef = base.GetSpeedRef(_Index);
		float num = 0f;
		if (this.m_pKartArcadeGearBox != null)
		{
			num = this.m_pKartArcadeGearBox.GetDifficultyPercent();
		}
		float num2 = speedRef + num * speedRef / 100f;
		if (this.m_pKartArcadeGearBox != null)
		{
			float percentAdvantages = this.m_pKartArcadeGearBox.GetPercentAdvantages(DrivingCaracteristics.SPEED);
			num2 += percentAdvantages * this.m_pKartArcadeGearBox.GetSpeedDiff() / 100f;
		}
		this.m_vSpeedRef[_Index] = num2;
	}

	// Token: 0x06000961 RID: 2401 RVA: 0x00042B70 File Offset: 0x00040D70
	public float ApplyManiabilityPercentageOnSpeed(float _Value, float _ValueDiff)
	{
		float num = _Value;
		if (num != 0f)
		{
			if (this.m_pKartArcadeGearBox != null)
			{
				float percentAdvantages = this.m_pKartArcadeGearBox.GetPercentAdvantages(DrivingCaracteristics.MANIABILITY);
				num -= percentAdvantages * _ValueDiff / 100f;
			}
			return this.m_pKart.GetMaxSpeed() / num;
		}
		return 0f;
	}

	// Token: 0x06000962 RID: 2402 RVA: 0x00042BD0 File Offset: 0x00040DD0
	public float ApplyManiabilityPercentage(float _Value, float _ValueDiff)
	{
		float num = _Value;
		if (num != 0f && this.m_pKartArcadeGearBox != null)
		{
			float percentAdvantages = this.m_pKartArcadeGearBox.GetPercentAdvantages(DrivingCaracteristics.MANIABILITY);
			num -= percentAdvantages * _ValueDiff / 100f;
		}
		return num;
	}

	// Token: 0x06000963 RID: 2403 RVA: 0x0000880B File Offset: 0x00006A0B
	public void ApplyDecelerationMSSAdvantages()
	{
		this.m_fDecelerationMSS = this.ApplyManiabilityPercentageOnSpeed(this.m_fDecelerationTime, this.m_fDecelTimeDiff);
	}

	// Token: 0x06000964 RID: 2404 RVA: 0x00008825 File Offset: 0x00006A25
	public void ApplyBrakingMSSAdvantages()
	{
		this.m_fBrakingMSS = this.ApplyManiabilityPercentageOnSpeed(this.m_fBrakingTime, this.m_fBrakingTimeDiff);
	}

	// Token: 0x06000965 RID: 2405 RVA: 0x0000883F File Offset: 0x00006A3F
	public void ApplyTimeToMaxSteeringAdvantages()
	{
		this.m_fTimeToMaxSteering = this.ApplyManiabilityPercentage(base.GetTimeToMaxSteering(), this.m_fSteeringTimeDiff);
	}

	// Token: 0x06000966 RID: 2406 RVA: 0x00008859 File Offset: 0x00006A59
	public void ApplyResetSteeringNoInputAdvantages()
	{
		this.m_fResetSteeringNoInput = this.ApplyManiabilityPercentage(base.GetResetSteeringNoInput(), this.m_fResetSteeringNoInputDiff);
	}

	// Token: 0x06000967 RID: 2407 RVA: 0x00008873 File Offset: 0x00006A73
	public void ApplyDriftResetSteeringNoInputAdvantages()
	{
		this.m_fDriftResetSteeringNoInput = this.ApplyManiabilityPercentage(base.GetDriftResetSteeringNoInput(), this.m_fDriftResetSteeringNoInputDiff);
	}

	// Token: 0x06000968 RID: 2408 RVA: 0x0000888D File Offset: 0x00006A8D
	public void ApplyResetSteeringOppositeInputAdvantages()
	{
		this.m_fResetSteeringOppositeInput = this.ApplyManiabilityPercentage(base.GetResetSteeringOppositeInput(), this.m_fResetSteeringOppositeInputDiff);
	}

	// Token: 0x06000969 RID: 2409 RVA: 0x00042C1C File Offset: 0x00040E1C
	public void ApplyWeight()
	{
		RcKinematicPhysic rcKinematicPhysic = (RcKinematicPhysic)this.m_pKart.GetVehiclePhysic();
		if (rcKinematicPhysic != null && this.CharacterWeight.Count >= Enum.GetValues(typeof(EWeight)).Length)
		{
			rcKinematicPhysic.m_fMass = this.CharacterWeight[(int)this.CharacterCarac.Weight];
		}
	}

	// Token: 0x0600096A RID: 2410 RVA: 0x00042C88 File Offset: 0x00040E88
	public void StartScene()
	{
		for (int i = 0; i < this.m_vSpeedRef.Count; i++)
		{
			this.ApplySpeedRefAdvantages(i);
		}
		this.ApplyDecelerationMSSAdvantages();
		this.ApplyBrakingMSSAdvantages();
		this.ApplyTimeToMaxSteeringAdvantages();
		this.ApplyResetSteeringNoInputAdvantages();
		this.ApplyDriftResetSteeringNoInputAdvantages();
		this.ApplyResetSteeringOppositeInputAdvantages();
		this.ApplyWeight();
	}

	// Token: 0x04000997 RID: 2455
	public float MaxDecelerationTime;

	// Token: 0x04000998 RID: 2456
	public float MaxBrakingTime;

	// Token: 0x04000999 RID: 2457
	public float MaxSteeringTime;

	// Token: 0x0400099A RID: 2458
	public float MaxResetSteeringNoInput;

	// Token: 0x0400099B RID: 2459
	public float MaxDriftResetSteeringNoInput;

	// Token: 0x0400099C RID: 2460
	public float MaxResetSteeringOppositeInput;

	// Token: 0x0400099D RID: 2461
	public List<float> CharacterWeight;

	// Token: 0x0400099E RID: 2462
	private float m_fDecelTimeDiff;

	// Token: 0x0400099F RID: 2463
	private float m_fBrakingTimeDiff;

	// Token: 0x040009A0 RID: 2464
	private float m_fSteeringTimeDiff;

	// Token: 0x040009A1 RID: 2465
	private float m_fResetSteeringNoInputDiff;

	// Token: 0x040009A2 RID: 2466
	private float m_fDriftResetSteeringNoInputDiff;

	// Token: 0x040009A3 RID: 2467
	private float m_fResetSteeringOppositeInputDiff;

	// Token: 0x040009A4 RID: 2468
	private KartArcadeGearBox m_pKartArcadeGearBox;

	// Token: 0x040009A5 RID: 2469
	private KartCarac m_pKartCarac;

	// Token: 0x040009A6 RID: 2470
	private CharacterCarac m_pCharacterCarac;

	// Token: 0x040009A7 RID: 2471
	private Kart m_pKart;
}

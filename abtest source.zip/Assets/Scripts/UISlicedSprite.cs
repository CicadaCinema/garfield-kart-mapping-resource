﻿using System;
using UnityEngine;

// Token: 0x02000083 RID: 131
[ExecuteInEditMode]
public class UISlicedSprite : UISprite
{
	// Token: 0x170000AC RID: 172
	// (get) Token: 0x0600039F RID: 927 RVA: 0x00004C05 File Offset: 0x00002E05
	public override UISprite.Type type
	{
		get
		{
			return UISprite.Type.Sliced;
		}
	}
}

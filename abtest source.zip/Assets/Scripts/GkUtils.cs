﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200018C RID: 396
public static class GkUtils
{
	// Token: 0x06000AAA RID: 2730 RVA: 0x00048634 File Offset: 0x00046834
	public static List<string> GetHats(ERarity pRarity, bool pIncludeDefault)
	{
		List<string> list = new List<string>();
		UnityEngine.Object[] array = Resources.LoadAll("Hat", typeof(BonusCustom));
		foreach (UnityEngine.Object @object in array)
		{
			if (@object is BonusCustom)
			{
				BonusCustom bonusCustom = (BonusCustom)@object;
				if (pIncludeDefault || !@object.name.Contains("Default"))
				{
					ERarity rarity = bonusCustom.Rarity;
					if ((pRarity & rarity) != (ERarity)0)
					{
						list.Add(@object.name);
					}
				}
			}
		}
		return list;
	}

	// Token: 0x06000AAB RID: 2731 RVA: 0x000486C8 File Offset: 0x000468C8
	public static string[] GetTracks()
	{
		UnityEngine.Object @object = Resources.Load("Tracks", typeof(TrackList));
		return ((TrackList)@object).Tracks;
	}

	// Token: 0x06000AAC RID: 2732 RVA: 0x000486F8 File Offset: 0x000468F8
	public static List<string> GetHats(bool pIncludeDefault)
	{
		List<string> list = new List<string>();
		UnityEngine.Object[] array = Resources.LoadAll("Hat", typeof(BonusCustom));
		foreach (UnityEngine.Object @object in array)
		{
			if (@object is BonusCustom && (pIncludeDefault || !@object.name.Contains("Default")))
			{
				list.Add(@object.name);
			}
		}
		return list;
	}

	// Token: 0x06000AAD RID: 2733 RVA: 0x00048774 File Offset: 0x00046974
	public static List<string> GetCustoms(ERarity pRarity, bool pIncludeDefault)
	{
		List<string> list = new List<string>();
		UnityEngine.Object[] array = Resources.LoadAll("Kart", typeof(KartCustom));
		foreach (UnityEngine.Object @object in array)
		{
			if (@object is KartCustom)
			{
				KartCustom kartCustom = (KartCustom)@object;
				if (pIncludeDefault || !@object.name.Contains("Default"))
				{
					ERarity rarity = kartCustom.Rarity;
					if ((pRarity & rarity) != (ERarity)0)
					{
						list.Add(@object.name);
					}
				}
			}
		}
		return list;
	}

	// Token: 0x06000AAE RID: 2734 RVA: 0x00048808 File Offset: 0x00046A08
	public static List<string> GetChampionShips()
	{
		List<string> list = new List<string>();
		UnityEngine.Object[] array = Resources.LoadAll("ChampionShip", typeof(ChampionShipData));
		foreach (UnityEngine.Object @object in array)
		{
			if (@object is ChampionShipData)
			{
				list.Add(@object.name);
			}
		}
		return list;
	}

	// Token: 0x06000AAF RID: 2735 RVA: 0x00048868 File Offset: 0x00046A68
	public static List<string> GetCustoms(bool pIncludeDefault)
	{
		List<string> list = new List<string>();
		UnityEngine.Object[] array = Resources.LoadAll("Kart", typeof(KartCustom));
		foreach (UnityEngine.Object @object in array)
		{
			if (@object is KartCustom && (pIncludeDefault || !@object.name.Contains("Default")))
			{
				list.Add(@object.name);
			}
		}
		return list;
	}

	// Token: 0x06000AB0 RID: 2736 RVA: 0x000488E4 File Offset: 0x00046AE4
	public static List<ECharacter> GetKarts()
	{
		List<ECharacter> list = new List<ECharacter>();
		UnityEngine.Object[] array = Resources.LoadAll("Kart", typeof(KartCarac));
		foreach (UnityEngine.Object @object in array)
		{
			if (@object is KartCarac)
			{
				list.Add(((KartCarac)@object).Owner);
			}
		}
		return list;
	}

	// Token: 0x06000AB1 RID: 2737 RVA: 0x00048948 File Offset: 0x00046B48
	public static List<EAdvantage> GetAdvantages()
	{
		List<EAdvantage> list = new List<EAdvantage>();
		UnityEngine.Object[] array = Resources.LoadAll("Advantages", typeof(AdvantageData));
		foreach (UnityEngine.Object @object in array)
		{
			if (@object is AdvantageData)
			{
				AdvantageData advantageData = (AdvantageData)@object;
				list.Add(advantageData.AdvantageType);
			}
		}
		return list;
	}

	// Token: 0x06000AB2 RID: 2738 RVA: 0x000489B0 File Offset: 0x00046BB0
	public static List<ECharacter> GetCharacters()
	{
		List<ECharacter> list = new List<ECharacter>();
		UnityEngine.Object[] array = Resources.LoadAll("Character", typeof(CharacterCarac));
		foreach (UnityEngine.Object @object in array)
		{
			if (@object is CharacterCarac)
			{
				CharacterCarac characterCarac = (CharacterCarac)@object;
				list.Add(characterCarac.Owner);
			}
		}
		return list;
	}

	// Token: 0x06000AB3 RID: 2739 RVA: 0x00048A18 File Offset: 0x00046C18
	public static void UnlockAll()
	{
		List<string> hats = GkUtils.GetHats(true);
		foreach (string pHat in hats)
		{
			Singleton<GameSaveManager>.Instance.SetHatState(pHat, E_UnlockableItemSate.Unlocked, false);
		}
		List<string> customs = GkUtils.GetCustoms(true);
		foreach (string pCustom in customs)
		{
			Singleton<GameSaveManager>.Instance.SetCustomState(pCustom, E_UnlockableItemSate.Unlocked, false);
		}
		List<ECharacter> karts = GkUtils.GetKarts();
		foreach (ECharacter pKart in karts)
		{
			Singleton<GameSaveManager>.Instance.SetKartState(pKart, E_UnlockableItemSate.Unlocked, false);
		}
		List<string> championShips = GkUtils.GetChampionShips();
		foreach (string pChampionShip in championShips)
		{
			Singleton<GameSaveManager>.Instance.SetChampionShipState(pChampionShip, EDifficulty.EASY, E_UnlockableItemSate.Unlocked, false);
			Singleton<GameSaveManager>.Instance.SetChampionShipState(pChampionShip, EDifficulty.NORMAL, E_UnlockableItemSate.Unlocked, false);
			Singleton<GameSaveManager>.Instance.SetChampionShipState(pChampionShip, EDifficulty.HARD, E_UnlockableItemSate.Unlocked, false);
		}
		List<EAdvantage> advantages = GkUtils.GetAdvantages();
		foreach (EAdvantage pAdvantage in advantages)
		{
			Singleton<GameSaveManager>.Instance.SetAdvantageState(pAdvantage, E_UnlockableItemSate.Unlocked, false);
			Singleton<GameSaveManager>.Instance.SetAdvantageQuantity(pAdvantage, 99, false);
		}
		List<ECharacter> characters = GkUtils.GetCharacters();
		foreach (ECharacter pCharacter in characters)
		{
			Singleton<GameSaveManager>.Instance.SetCharacterState(pCharacter, E_UnlockableItemSate.Unlocked, false);
		}
		Singleton<GameSaveManager>.Instance.Save();
	}
}

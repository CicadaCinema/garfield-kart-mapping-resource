﻿using System;

// Token: 0x0200012A RID: 298
public enum EDifficulty
{
	// Token: 0x04000859 RID: 2137
	NORMAL,
	// Token: 0x0400085A RID: 2138
	HARD,
	// Token: 0x0400085B RID: 2139
	EASY
}

﻿using System;

// Token: 0x020000F8 RID: 248
public class KartCustom : DrivingCarac
{
	// Token: 0x060006B6 RID: 1718 RVA: 0x00006BC4 File Offset: 0x00004DC4
	public override void Start()
	{
		base.Start();
	}

	// Token: 0x060006B7 RID: 1719 RVA: 0x00034350 File Offset: 0x00032550
	public static int Compare(KartCustom oItem1, KartCustom oItem2)
	{
		int num = IconCarac.CompareNameDefault(oItem1, oItem2);
		if (num == 0)
		{
			num = KartCustom.CompareStateHidden(oItem1, oItem2);
			if (num == 0)
			{
				num = KartCustom.CompareRarity(oItem1, oItem2);
				if (num == 0)
				{
					num = KartCustom.CompareState(oItem1, oItem2);
					if (num == 0)
					{
						num = IconCarac.CompareName(oItem1, oItem2);
					}
				}
			}
		}
		return num;
	}

	// Token: 0x060006B8 RID: 1720 RVA: 0x00006BCC File Offset: 0x00004DCC
	private static int CompareRarity(KartCustom oItem1, KartCustom oItem2)
	{
		return oItem1.Rarity - oItem2.Rarity;
	}

	// Token: 0x060006B9 RID: 1721 RVA: 0x000343A0 File Offset: 0x000325A0
	private static int CompareState(KartCustom oItem1, KartCustom oItem2)
	{
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		return IconCarac.SuppressNewState(instance.GetCustomState(oItem2.name)) - IconCarac.SuppressNewState(instance.GetCustomState(oItem1.name));
	}

	// Token: 0x060006BA RID: 1722 RVA: 0x000343D8 File Offset: 0x000325D8
	private static int CompareStateHidden(KartCustom oItem1, KartCustom oItem2)
	{
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		bool flag = instance.GetCustomState(oItem2.name) == E_UnlockableItemSate.Hidden;
		if (instance.GetCustomState(oItem1.name) == E_UnlockableItemSate.Hidden)
		{
			if (flag)
			{
				return 0;
			}
			return 1;
		}
		else
		{
			if (flag)
			{
				return -1;
			}
			return 0;
		}
	}

	// Token: 0x040006AC RID: 1708
	public ERarity Rarity;

	// Token: 0x040006AD RID: 1709
	public ECharacter Character;

	// Token: 0x040006AE RID: 1710
	public E_UnlockableItemSate State;
}

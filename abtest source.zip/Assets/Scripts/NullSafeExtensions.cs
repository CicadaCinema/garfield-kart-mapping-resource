﻿using System;

// Token: 0x0200023E RID: 574
public static class NullSafeExtensions
{
}

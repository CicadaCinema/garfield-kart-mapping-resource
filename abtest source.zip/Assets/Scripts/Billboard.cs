﻿using System;
using UnityEngine;

// Token: 0x020000FF RID: 255
public class Billboard : MonoBehaviour
{
	// Token: 0x060006E8 RID: 1768 RVA: 0x00006E32 File Offset: 0x00005032
	public void Start()
	{
		if (this.m_Camera == null)
		{
			this.SetCamera(GameObject.FindGameObjectWithTag("MainCamera").camera);
		}
		this.m_pTransform = base.transform;
	}

	// Token: 0x060006E9 RID: 1769 RVA: 0x00006E66 File Offset: 0x00005066
	public void SetCamera(Camera C)
	{
		this.m_Camera = C;
		this.m_pCamTransform = C.transform;
	}

	// Token: 0x060006EA RID: 1770 RVA: 0x000345E0 File Offset: 0x000327E0
	public void Update()
	{
		this.m_pTransform.LookAt(this.m_pTransform.position - this.m_pCamTransform.rotation * Vector3.back, this.m_pCamTransform.rotation * Vector3.up);
	}

	// Token: 0x040006CB RID: 1739
	public Camera m_Camera;

	// Token: 0x040006CC RID: 1740
	private Transform m_pTransform;

	// Token: 0x040006CD RID: 1741
	private Transform m_pCamTransform;
}

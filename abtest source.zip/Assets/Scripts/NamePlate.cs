﻿using System;
using UnityEngine;

// Token: 0x02000125 RID: 293
public class NamePlate : MonoBehaviour
{
	// Token: 0x06000804 RID: 2052 RVA: 0x00007A7F File Offset: 0x00005C7F
	public void Start()
	{
		this.m_oThisTransform = base.transform;
		this.m_oMainCam = Camera.main;
		this.m_oCamTransform = this.m_oMainCam.transform;
		this.m_fSquaredDisplayDistance = this.m_fDisplayDistance * this.m_fDisplayDistance;
	}

	// Token: 0x06000805 RID: 2053 RVA: 0x00007ABC File Offset: 0x00005CBC
	public void setTarget(Transform T)
	{
		this.m_oTargetTransform = T;
	}

	// Token: 0x06000806 RID: 2054 RVA: 0x00007AC5 File Offset: 0x00005CC5
	public void setDisplayDistance(float D)
	{
		this.m_fDisplayDistance = D;
		this.m_fSquaredDisplayDistance = this.m_fDisplayDistance * this.m_fDisplayDistance;
	}

	// Token: 0x06000807 RID: 2055 RVA: 0x0003CA9C File Offset: 0x0003AC9C
	public void Update()
	{
		float sqrMagnitude = (this.m_oCamTransform.position - this.m_oTargetTransform.position).sqrMagnitude;
		if (sqrMagnitude < this.m_fSquaredDisplayDistance)
		{
			Vector3 position = this.m_oMainCam.WorldToViewportPoint(this.m_oTargetTransform.position + this.m_vOffset);
			if (position.z > 0f)
			{
				this.m_cDisplay.material.color = new Color(1f, 1f, 1f, (this.m_fSquaredDisplayDistance - sqrMagnitude) / this.m_fSquaredDisplayDistance);
				this.m_cDisplay.enabled = true;
				this.m_oThisTransform.position = position;
			}
			else
			{
				this.m_cDisplay.enabled = false;
			}
		}
		else
		{
			this.m_cDisplay.enabled = false;
		}
	}

	// Token: 0x04000841 RID: 2113
	public GUIText m_cDisplay;

	// Token: 0x04000842 RID: 2114
	public Vector3 m_vOffset = Vector3.up * 2f;

	// Token: 0x04000843 RID: 2115
	public Transform m_oTargetTransform;

	// Token: 0x04000844 RID: 2116
	private float m_fDisplayDistance = 20f;

	// Token: 0x04000845 RID: 2117
	private float m_fSquaredDisplayDistance;

	// Token: 0x04000846 RID: 2118
	private Camera m_oMainCam;

	// Token: 0x04000847 RID: 2119
	private Transform m_oThisTransform;

	// Token: 0x04000848 RID: 2120
	private Transform m_oCamTransform;
}

﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x020000B1 RID: 177
public class GameEntryPoint : MonoBehaviour
{
	// Token: 0x170000DD RID: 221
	// (get) Token: 0x0600047D RID: 1149 RVA: 0x0000540B File Offset: 0x0000360B
	public GameEntryPoint.ECreationState State
	{
		get
		{
			return this.m_eState;
		}
	}

	// Token: 0x0600047E RID: 1150 RVA: 0x00027DE0 File Offset: 0x00025FE0
	public void Awake()
	{
		string path;
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			path = "Camera/followCamMobile";
		}
		else
		{
			path = "Camera/followCam";
		}
		UnityEngine.Object.Instantiate(Resources.Load(path) as GameObject);
		this.m_eState = GameEntryPoint.ECreationState.None;
		this.networkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
		this.m_pSounds = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("Sounds"));
		if (this.m_pSounds)
		{
			SoundManager component = this.m_pSounds.GetComponent<SoundManager>();
			Singleton<GameManager>.Instance.SoundManager = component;
		}
		Screen.sleepTimeout = -1;
	}

	// Token: 0x0600047F RID: 1151 RVA: 0x00027E90 File Offset: 0x00026090
	public IEnumerator Start()
	{
		if (DebugMgr.Instance != null && Singleton<GameConfigurator>.Instance.StartScene.Equals("MenuRoot"))
		{
			Singleton<GameConfigurator>.Instance.StartScene = DebugMgr.Instance.dbgData.SceneToLaunch;
		}
		while (LoadingManager.IsLoading())
		{
			yield return null;
		}
		Singleton<GameManager>.Instance.LaunchGame();
		if (Singleton<GameConfigurator>.Instance.PlayerConfig)
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.ResetAdvantages();
		}
		if (Network.peerType != NetworkPeerType.Disconnected)
		{
			this.networkMgr.StartSynchronization();
		}
		this.m_eState = GameEntryPoint.ECreationState.SceneLoaded;
		this.m_iStep = 0;
		yield break;
	}

	// Token: 0x06000480 RID: 1152 RVA: 0x00005413 File Offset: 0x00003613
	public void OnDestroy()
	{
		Screen.sleepTimeout = -2;
		Singleton<BonusMgr>.DestroyInstance();
		Network.RemoveRPCs(Network.player, 0);
	}

	// Token: 0x06000481 RID: 1153 RVA: 0x00027EAC File Offset: 0x000260AC
	public void Update()
	{
		if (this.m_eState == GameEntryPoint.ECreationState.SceneLoaded)
		{
			foreach (RcPortalTrigger rcPortalTrigger in UnityEngine.Object.FindSceneObjectsOfType(typeof(RcPortalTrigger)))
			{
				rcPortalTrigger.enabled = false;
			}
			if (Network.peerType == NetworkPeerType.Disconnected || !this.networkMgr.WaitingSynchronization)
			{
				Singleton<BonusMgr>.Instance.Init();
				Singleton<GameManager>.Instance.CreatePlayers();
				this.m_eState = GameEntryPoint.ECreationState.PlayersCreated;
				if (Network.peerType != NetworkPeerType.Disconnected)
				{
					this.networkMgr.StartSynchronization();
				}
			}
		}
		else if (this.m_eState == GameEntryPoint.ECreationState.PlayersCreated && this.m_iStep++ > 5 && (Network.peerType == NetworkPeerType.Disconnected || !this.networkMgr.WaitingSynchronization))
		{
			if (GameEntryPoint.OnVehicleCreated != null)
			{
				GameEntryPoint.OnVehicleCreated();
			}
			Singleton<GameManager>.Instance.GameMode.StartScene();
			Singleton<BonusMgr>.Instance.NullSafe(delegate(BonusMgr i)
			{
				i.StartScene();
			});
			this.m_eState = GameEntryPoint.ECreationState.SceneStarted;
		}
	}

	// Token: 0x0400043E RID: 1086
	private GameEntryPoint.ECreationState m_eState;

	// Token: 0x0400043F RID: 1087
	private int m_iStep;

	// Token: 0x04000440 RID: 1088
	private NetworkMgr networkMgr;

	// Token: 0x04000441 RID: 1089
	private GameObject m_pSounds;

	// Token: 0x04000442 RID: 1090
	public static Action OnVehicleCreated;

	// Token: 0x020000B2 RID: 178
	public enum ECreationState
	{
		// Token: 0x04000445 RID: 1093
		None,
		// Token: 0x04000446 RID: 1094
		SceneLoaded,
		// Token: 0x04000447 RID: 1095
		PlayersCreated,
		// Token: 0x04000448 RID: 1096
		SceneStarted
	}
}

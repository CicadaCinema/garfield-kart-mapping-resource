﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200018B RID: 395
public class TutorialGameMode : InGameGameMode
{
	// Token: 0x17000173 RID: 371
	// (get) Token: 0x06000A88 RID: 2696 RVA: 0x0000941B File Offset: 0x0000761B
	// (set) Token: 0x06000A89 RID: 2697 RVA: 0x00009423 File Offset: 0x00007623
	public bool ShowHUDBonus
	{
		get
		{
			return this.m_bShowHUDBonus;
		}
		set
		{
			this.m_bShowHUDBonus = value;
			base.Hud.ActivateHUDBonus(value);
		}
	}

	// Token: 0x17000174 RID: 372
	// (get) Token: 0x06000A8A RID: 2698 RVA: 0x00009438 File Offset: 0x00007638
	public bool Ended
	{
		get
		{
			return this.m_eCurrentState == ETutorialState.End;
		}
	}

	// Token: 0x17000175 RID: 373
	// (get) Token: 0x06000A8B RID: 2699 RVA: 0x00009444 File Offset: 0x00007644
	public int DriftSuccessLevel
	{
		get
		{
			if (this.m_bRedDrift)
			{
				return 3;
			}
			if (this.m_bBlueDrift)
			{
				return 2;
			}
			if (this.m_bDriftAttempt)
			{
				return 1;
			}
			return 0;
		}
	}

	// Token: 0x17000176 RID: 374
	// (get) Token: 0x06000A8C RID: 2700 RVA: 0x0000946E File Offset: 0x0000766E
	// (set) Token: 0x06000A8D RID: 2701 RVA: 0x00009476 File Offset: 0x00007676
	public bool WannaItem
	{
		get
		{
			return this.m_bWannaItem;
		}
		set
		{
			this.m_bWannaItem = value;
		}
	}

	// Token: 0x17000177 RID: 375
	// (get) Token: 0x06000A8E RID: 2702 RVA: 0x0000947F File Offset: 0x0000767F
	// (set) Token: 0x06000A8F RID: 2703 RVA: 0x00009487 File Offset: 0x00007687
	public EITEM DesiredItem
	{
		get
		{
			return this.m_eDesiredItem;
		}
		set
		{
			this.m_eDesiredItem = value;
		}
	}

	// Token: 0x17000178 RID: 376
	// (get) Token: 0x06000A90 RID: 2704 RVA: 0x00009490 File Offset: 0x00007690
	public bool Launched
	{
		get
		{
			return this.m_bLaunched;
		}
	}

	// Token: 0x17000179 RID: 377
	// (get) Token: 0x06000A91 RID: 2705 RVA: 0x00009498 File Offset: 0x00007698
	public bool InstructionShown
	{
		get
		{
			return this.m_bInstructionShown;
		}
	}

	// Token: 0x1700017A RID: 378
	// (get) Token: 0x06000A92 RID: 2706 RVA: 0x000094A0 File Offset: 0x000076A0
	public new ETutorialState State
	{
		get
		{
			return this.m_eCurrentState;
		}
	}

	// Token: 0x06000A93 RID: 2707 RVA: 0x000094A8 File Offset: 0x000076A8
	public override void Awake()
	{
		base.Awake();
	}

	// Token: 0x06000A94 RID: 2708 RVA: 0x000094B0 File Offset: 0x000076B0
	public override void InitState()
	{
		this._state = E_GameState.RaceTutorial;
	}

	// Token: 0x06000A95 RID: 2709 RVA: 0x00047D68 File Offset: 0x00045F68
	public override void Start()
	{
		base.Start();
		Transform parent = base.Hud.transform.Find("Camera");
		this.m_oFinish = base.Hud.HUDFinish;
		this.m_fSuccessAnimDuration = this.m_oFinish.AnimDuration;
		UnityEngine.Object[] array = Resources.LoadAll("TutorialStates", typeof(GameObject));
		foreach (GameObject gameObject in array)
		{
			IGTutorialState component = gameObject.GetComponent<IGTutorialState>();
			if (component)
			{
				this.m_oPanels[(int)component.ID] = (GameObject)UnityEngine.Object.Instantiate(gameObject);
				this.m_oPanels[(int)component.ID].SetActive(false);
				this.m_oPanels[(int)component.ID].transform.parent = parent;
				component = this.m_oPanels[(int)component.ID].GetComponent<IGTutorialState>();
				component.GameMode = this;
				this.m_oPanelScripts[(int)component.ID] = component;
			}
		}
		UnityEngine.Object[] array3 = UnityEngine.Object.FindObjectsOfType(typeof(BoxBonusEntity));
		foreach (BoxBonusEntity boxBonusEntity in array3)
		{
			this.m_cBBEs.Add(boxBonusEntity.gameObject);
			boxBonusEntity.gameObject.SetActive(false);
		}
		UnityEngine.Object[] array5 = UnityEngine.Object.FindObjectsOfType(typeof(PuzzlePiece));
		foreach (PuzzlePiece puzzlePiece in array5)
		{
			puzzlePiece.gameObject.SetActive(false);
		}
		if (Application.platform == RuntimePlatform.IPhonePlayer || Application.platform == RuntimePlatform.Android)
		{
			Singleton<GameOptionManager>.Instance.SetInputType(E_InputType.Gyroscopic, false);
		}
		this.m_bInstructionShown = false;
	}

	// Token: 0x06000A96 RID: 2710 RVA: 0x00047F40 File Offset: 0x00046140
	public override void StartScene()
	{
		base.StartScene();
		UnityEngine.Object[] array = UnityEngine.Object.FindObjectsOfType(typeof(RcVehicleRaceStats));
		foreach (RcVehicleRaceStats rcVehicleRaceStats in array)
		{
			rcVehicleRaceStats.CanCompleteLap = false;
		}
		this.SetAIActive(false);
		Singleton<GameManager>.Instance.GameMode.GetHumanKart().SetLocked(false);
	}

	// Token: 0x06000A97 RID: 2711 RVA: 0x000094B9 File Offset: 0x000076B9
	public void FirstPanel()
	{
		if (this.m_bLaunched)
		{
			return;
		}
		this.StartState(ETutorialState.Acceleration);
		this.m_bLaunched = true;
		this._hasStart = true;
	}

	// Token: 0x06000A98 RID: 2712 RVA: 0x00047FA8 File Offset: 0x000461A8
	public new void Update()
	{
		base.Update();
		if (this.m_oPanels[(int)this.m_eCurrentState].activeSelf && this.m_oPanelScripts[(int)this.m_eCurrentState].CanBeDisabled() && Input.anyKeyDown)
		{
			this.m_oPanels[(int)this.m_eCurrentState].SetActive(false);
			Time.timeScale = 1f;
			this.m_bInstructionShown = true;
		}
		this.m_fRedisplayTimer += Time.deltaTime;
		if (!this.m_bSuccess && this.m_fRedisplayTimer >= this.m_oPanelScripts[(int)this.m_eCurrentState].MaxStateTime)
		{
			this.StartState(this.m_eCurrentState);
		}
		if (this.m_oFinish && this.m_oFinish.isDisplaying)
		{
			this.m_fAfterSuccessTimer += Time.deltaTime;
			if (this.m_fAfterSuccessTimer >= this.m_oPanelScripts[(int)this.m_eCurrentState].AfterSuccessDelay && this.m_fAfterSuccessTimer >= this.m_fSuccessAnimDuration)
			{
				this.NextState();
				this.m_oFinish.Hide();
			}
		}
		if (this.m_bFail)
		{
			this.m_fAfterFailTimer += Time.deltaTime;
			if (this.m_fAfterFailTimer >= this.AfterFailTimer)
			{
				this.m_bFail = false;
				this.m_fAfterFailTimer = 0f;
				this.NextState();
			}
		}
		if (this.m_bDriftAttempt)
		{
			if (this.m_eCurrentState != ETutorialState.Drift)
			{
				this.m_bDriftAttempt = false;
			}
			else
			{
				this.m_fDriftAttemptTimer += Time.deltaTime;
				if (this.m_fDriftAttemptTimer >= this.DriftAttemptTimer)
				{
					this.NextState();
					this.m_bDriftAttempt = false;
				}
			}
		}
	}

	// Token: 0x06000A99 RID: 2713 RVA: 0x000094DC File Offset: 0x000076DC
	public void NextState()
	{
		this.StartState(this.m_oPanels[(int)this.m_eCurrentState].GetComponent<IGTutorialState>().NextState);
	}

	// Token: 0x06000A9A RID: 2714 RVA: 0x00048168 File Offset: 0x00046368
	private void StartState(ETutorialState State)
	{
		Time.timeScale = 0f;
		this.m_oPanels[(int)this.m_eCurrentState].SetActive(false);
		this.m_oPanelScripts[(int)this.m_eCurrentState].OnExit();
		this.m_eCurrentState = State;
		this.m_oPanelScripts[(int)this.m_eCurrentState].OnEnter();
		this.m_oPanels[(int)this.m_eCurrentState].SetActive(true);
		this.m_bInstructionShown = false;
		this.m_fRedisplayTimer = 0f;
		this.m_fAfterSuccessTimer = 0f;
		this.m_bSuccess = false;
		if (this.m_eCurrentState == ETutorialState.End)
		{
			this.GrandFinal();
		}
	}

	// Token: 0x06000A9B RID: 2715 RVA: 0x00048208 File Offset: 0x00046408
	public void SetAIActive(bool bActivate)
	{
		for (int i = 0; i < 6; i++)
		{
			if (i != Singleton<GameManager>.Instance.GameMode.GetHumanPlayerVehicleId())
			{
				Kart kartWithVehicleId = Singleton<GameManager>.Instance.GameMode.GetKartWithVehicleId(i);
				kartWithVehicleId.SetLocked(!bActivate);
			}
		}
	}

	// Token: 0x06000A9C RID: 2716 RVA: 0x000094FB File Offset: 0x000076FB
	public void OnSuccess()
	{
		if (!this.Launched || !this.m_oFinish)
		{
			return;
		}
		this.m_oFinish.Show();
		this.m_fAfterSuccessTimer = 0f;
		this.m_bSuccess = true;
	}

	// Token: 0x06000A9D RID: 2717 RVA: 0x00009536 File Offset: 0x00007736
	public void OnFail()
	{
		this.m_fAfterFailTimer = 0f;
		this.m_bFail = true;
	}

	// Token: 0x06000A9E RID: 2718 RVA: 0x0000954A File Offset: 0x0000774A
	public void Accelerate()
	{
		if (this.m_eCurrentState != ETutorialState.Acceleration || this.m_bSuccess)
		{
			return;
		}
		this.OnSuccess();
	}

	// Token: 0x06000A9F RID: 2719 RVA: 0x00048258 File Offset: 0x00046458
	public void Direction(float Steer)
	{
		if (this.m_eCurrentState < ETutorialState.Direction_PC || this.m_eCurrentState > ETutorialState.Direction_Tactile || this.m_bSuccess)
		{
			return;
		}
		if (Singleton<GameOptionManager>.Instance.GetInputType() == E_InputType.Gyroscopic)
		{
			if (Steer < 0f)
			{
				this.m_iLeftGyro++;
			}
			else if (Steer > 0f)
			{
				this.m_iRightGyro++;
			}
			if (this.m_iLeftGyro > 0 && this.m_iRightGyro > 0)
			{
				this.OnSuccess();
			}
		}
		else
		{
			if (Steer < 0f)
			{
				this.m_iLeft++;
			}
			else if (Steer > 0f)
			{
				this.m_iRight++;
			}
			if (this.m_iLeft > 0 && this.m_iRight > 0)
			{
				this.m_iLeft = 0;
				this.m_iRight = 0;
				this.OnSuccess();
			}
		}
	}

	// Token: 0x06000AA0 RID: 2720 RVA: 0x00009569 File Offset: 0x00007769
	public void Brake()
	{
		if (this.m_eCurrentState != ETutorialState.Brake)
		{
			return;
		}
		this.OnSuccess();
	}

	// Token: 0x06000AA1 RID: 2721 RVA: 0x0000957E File Offset: 0x0000777E
	public void DriftAttempt()
	{
		if (this.m_eCurrentState != ETutorialState.Drift)
		{
			return;
		}
		this.m_bDriftAttempt = true;
	}

	// Token: 0x06000AA2 RID: 2722 RVA: 0x00048358 File Offset: 0x00046558
	public void BlueDrift()
	{
		if ((this.m_eCurrentState != ETutorialState.Drift && this.m_eCurrentState != ETutorialState.Drift_TryAgain && this.m_eCurrentState != ETutorialState.Drift_Perfect) || this.m_bSuccess)
		{
			return;
		}
		this.m_bBlueDrift = true;
		if (this.m_eCurrentState == ETutorialState.Drift_Perfect)
		{
			this.m_iDriftCount++;
			if (this.m_iDriftCount >= this.DriftTraining)
			{
				this.OnSuccess();
			}
		}
		else
		{
			this.OnSuccess();
		}
	}

	// Token: 0x06000AA3 RID: 2723 RVA: 0x000483DC File Offset: 0x000465DC
	public void RedDrift()
	{
		if ((this.m_eCurrentState != ETutorialState.Drift && this.m_eCurrentState != ETutorialState.Drift_TryAgain && this.m_eCurrentState != ETutorialState.Drift_NotBad && this.m_eCurrentState != ETutorialState.Drift_Perfect) || this.m_bSuccess)
		{
			return;
		}
		this.m_bRedDrift = true;
		if (this.m_eCurrentState == ETutorialState.Drift_Perfect)
		{
			this.m_iDriftCount++;
			if (this.m_iDriftCount >= this.DriftTraining)
			{
				this.OnSuccess();
			}
		}
		else
		{
			this.OnSuccess();
		}
	}

	// Token: 0x06000AA4 RID: 2724 RVA: 0x0004846C File Offset: 0x0004666C
	public void GotItem(EITEM Item)
	{
		if ((this.m_eCurrentState != ETutorialState.Bonus && this.m_eCurrentState != ETutorialState.Bonus_2) || this.m_bSuccess || !this.WannaItem)
		{
			return;
		}
		if (Item == this.DesiredItem)
		{
			this.OnSuccess();
			this.WannaItem = false;
		}
	}

	// Token: 0x06000AA5 RID: 2725 RVA: 0x000484C4 File Offset: 0x000466C4
	public void UsedBonus(EITEM Item, bool Behind)
	{
		if ((this.m_eCurrentState != ETutorialState.Bonus_Lasagna && this.m_eCurrentState != ETutorialState.Bonus_Pie && this.m_eCurrentState != ETutorialState.Bonus_PieFailed && this.m_eCurrentState != ETutorialState.Bonus_PieBehind) || this.m_bSuccess)
		{
			return;
		}
		if (Item == this.DesiredItem)
		{
			((BonusTutorialState)this.m_oPanelScripts[(int)this.m_eCurrentState]).LaunchedBehind = Behind;
			LaunchType type = ((BonusTutorialState)this.m_oPanelScripts[(int)this.m_eCurrentState]).Type;
			if (type == LaunchType.ANY || (type == LaunchType.FRONT && !Behind) || (type == LaunchType.BACK && Behind))
			{
				this.OnSuccess();
			}
			else
			{
				this.OnFail();
			}
		}
	}

	// Token: 0x06000AA6 RID: 2726 RVA: 0x00009594 File Offset: 0x00007794
	public void GrandFinal()
	{
		this.SetAIActive(true);
		base.Hud.ShowEndTutorialHUD();
	}

	// Token: 0x06000AA7 RID: 2727 RVA: 0x00048580 File Offset: 0x00046780
	public void ReactivateBBEs()
	{
		foreach (GameObject gameObject in this.m_cBBEs)
		{
			gameObject.gameObject.SetActive(true);
		}
	}

	// Token: 0x06000AA8 RID: 2728 RVA: 0x000485E0 File Offset: 0x000467E0
	public override void PlaceVehiclesOnStartLine()
	{
		GameObject gameObject = GameObject.Find("StartTuto");
		if (gameObject != null)
		{
			for (int i = 0; i < this.m_pPlayers.Length; i++)
			{
				this.StartPositions[i] = gameObject.transform.GetChild(i);
			}
		}
	}

	// Token: 0x06000AA9 RID: 2729 RVA: 0x000095A8 File Offset: 0x000077A8
	public void Pause(bool _Pause)
	{
		if (!this.m_bInstructionShown)
		{
			this.m_oPanels[(int)this.m_eCurrentState].SetActive(!_Pause);
		}
	}

	// Token: 0x04000A6C RID: 2668
	public float AfterFailTimer = 2f;

	// Token: 0x04000A6D RID: 2669
	private bool m_bLaunched;

	// Token: 0x04000A6E RID: 2670
	private bool m_bSuccess;

	// Token: 0x04000A6F RID: 2671
	private bool m_bFail;

	// Token: 0x04000A70 RID: 2672
	private float m_fRedisplayTimer;

	// Token: 0x04000A71 RID: 2673
	private float m_fAfterSuccessTimer;

	// Token: 0x04000A72 RID: 2674
	private float m_fAfterFailTimer;

	// Token: 0x04000A73 RID: 2675
	private ETutorialState m_eCurrentState;

	// Token: 0x04000A74 RID: 2676
	private GameObject[] m_oPanels = new GameObject[Enum.GetNames(typeof(ETutorialState)).Length];

	// Token: 0x04000A75 RID: 2677
	private IGTutorialState[] m_oPanelScripts = new IGTutorialState[Enum.GetNames(typeof(ETutorialState)).Length];

	// Token: 0x04000A76 RID: 2678
	private GameObject m_oSuccesLabel;

	// Token: 0x04000A77 RID: 2679
	private HUDFinish m_oFinish;

	// Token: 0x04000A78 RID: 2680
	private float m_fSuccessAnimDuration;

	// Token: 0x04000A79 RID: 2681
	private bool m_bInstructionShown;

	// Token: 0x04000A7A RID: 2682
	private bool m_bShowHUDBonus;

	// Token: 0x04000A7B RID: 2683
	private List<GameObject> m_cBBEs = new List<GameObject>();

	// Token: 0x04000A7C RID: 2684
	public float DriftAttemptTimer = 10f;

	// Token: 0x04000A7D RID: 2685
	private bool m_bDriftAttempt;

	// Token: 0x04000A7E RID: 2686
	private bool m_bBlueDrift;

	// Token: 0x04000A7F RID: 2687
	private bool m_bRedDrift;

	// Token: 0x04000A80 RID: 2688
	private float m_fDriftAttemptTimer;

	// Token: 0x04000A81 RID: 2689
	public int DriftTraining = 2;

	// Token: 0x04000A82 RID: 2690
	private int m_iDriftCount;

	// Token: 0x04000A83 RID: 2691
	private int m_iLeftGyro;

	// Token: 0x04000A84 RID: 2692
	private int m_iRightGyro;

	// Token: 0x04000A85 RID: 2693
	private int m_iLeft;

	// Token: 0x04000A86 RID: 2694
	private int m_iRight;

	// Token: 0x04000A87 RID: 2695
	private bool m_bWannaItem;

	// Token: 0x04000A88 RID: 2696
	private EITEM m_eDesiredItem;
}

﻿using System;

// Token: 0x0200009C RID: 156
[Serializable]
public class GkAIManager : RacingAIManager
{
	// Token: 0x06000423 RID: 1059 RVA: 0x00024DF0 File Offset: 0x00022FF0
	public override void Init(AIPathHandler pPathModule)
	{
		base.Init(pPathModule);
		this._pathSettings = Singleton<GameConfigurator>.Instance.AISettings.PathSettings;
		this._behaviourSettings = Singleton<GameConfigurator>.Instance.AISettings.BehaviourSettings;
		this._difficulty = Singleton<GameConfigurator>.Instance.Difficulty;
	}

	// Token: 0x06000424 RID: 1060 RVA: 0x00024E40 File Offset: 0x00023040
	public override RacingAI CreateAI()
	{
		GkRacingAI gkRacingAI = new GkRacingAI();
		GkRacingAI gkRacingAI2 = gkRacingAI;
		gkRacingAI2.OnNeedPath = (Action<GkRacingAI>)Delegate.Combine(gkRacingAI2.OnNeedPath, new Action<GkRacingAI>(this.GivePath));
		return gkRacingAI;
	}

	// Token: 0x06000425 RID: 1061 RVA: 0x00024E78 File Offset: 0x00023078
	protected override void CheckPositionOnPath(RacingAI pAi)
	{
		if (pAi.CurrentPath is RcFastValuePath)
		{
			RcFastValuePath rcFastValuePath = (RcFastValuePath)pAi.CurrentPath;
			RcFastValuePathComp point = rcFastValuePath.GetPoint(pAi.CurrentPathIndex);
			if (point is GkFastPathValueComp)
			{
				GkFastPathValueComp gkFastPathValueComp = (GkFastPathValueComp)point;
				float value = gkFastPathValueComp.GetValue();
				Kart kart = (Kart)pAi.Vehicle;
				EITEM item = kart.GetBonusMgr().GetItem(0);
				bool flag = gkFastPathValueComp.ChangePath;
				if (value != 0f)
				{
					if (gkFastPathValueComp.UseBonus)
					{
						if (item == (EITEM)value)
						{
							if (kart.IsInShortCut || this.IsMore(this._behaviourSettings.ShootChance.GetChance(pAi.Level)))
							{
								((GkRacingAI)pAi).ActivateBonus(kart, gkFastPathValueComp.Behind);
							}
						}
						else
						{
							flag = gkFastPathValueComp.ChangePathIfNoCondition;
						}
					}
					else
					{
						flag = (item == (EITEM)value);
					}
				}
				if (flag)
				{
					kart.IsInShortCut = false;
					if ((int)pAi.Vehicle.GetArcadeDriftFactor() == 0)
					{
						if (gkFastPathValueComp.Path != null)
						{
							if (this.TakeShortcut(pAi.Level))
							{
								this._pathModule.SetPathAvailable((RcFastValuePath)pAi.CurrentPath);
								pAi.IdealPath = this._pathModule.GetShortcut(gkFastPathValueComp.Path.GetInstanceID());
								pAi.PathPosition = PathPosition.UNDEFINED_POSITION;
								kart.IsInShortCut = true;
							}
						}
						else
						{
							this.GivePath((GkRacingAI)pAi);
						}
					}
				}
			}
			else if (point is GkFastPathDriftValueComp)
			{
				GkFastPathDriftValueComp gkFastPathDriftValueComp = (GkFastPathDriftValueComp)point;
				E_DriftOrientation orientation = gkFastPathDriftValueComp.Orientation;
				if (orientation == E_DriftOrientation.None || this.IsMore(this._behaviourSettings.ShootChance.GetChance(pAi.Level)))
				{
					int num = (int)orientation;
					pAi.Vehicle.SetArcadeDriftFactor((float)num);
					if (orientation != E_DriftOrientation.None)
					{
						((Kart)pAi.Vehicle).Jump(0f, 0f);
					}
				}
			}
		}
	}

	// Token: 0x06000426 RID: 1062 RVA: 0x00025088 File Offset: 0x00023288
	public void GivePath(GkRacingAI pAi)
	{
		E_PathType pathType = this.GetPathType(pAi.Level);
		this._pathModule.SetPathAvailable((RcFastValuePath)pAi.CurrentPath);
		pAi.IdealPath = this._pathModule.GetPath(pathType, pAi.Level);
		pAi.PathPosition = PathPosition.UNDEFINED_POSITION;
	}

	// Token: 0x06000427 RID: 1063 RVA: 0x00024DCC File Offset: 0x00022FCC
	public bool IsMore(int pValue)
	{
		int num = Singleton<RandomManager>.Instance.Next(1, 100);
		return pValue >= num;
	}

	// Token: 0x06000428 RID: 1064 RVA: 0x000250DC File Offset: 0x000232DC
	public bool TakeShortcut(E_AILevel pLevel)
	{
		if (Singleton<GameManager>.Instance.GameMode.State != E_GameState.Race)
		{
			return false;
		}
		switch (pLevel)
		{
		case E_AILevel.GOOD:
			if (this._difficulty == EDifficulty.EASY)
			{
				return this.IsMore(this._pathSettings.EasyShortcutPathChance.Good);
			}
			if (this._difficulty == EDifficulty.NORMAL)
			{
				return this.IsMore(this._pathSettings.NormalShortcutPathChance.Good);
			}
			return this._difficulty == EDifficulty.HARD && this.IsMore(this._pathSettings.HardShortcutPathChance.Good);
		case E_AILevel.AVERAGE:
			if (this._difficulty == EDifficulty.EASY)
			{
				return this.IsMore(this._pathSettings.EasyShortcutPathChance.Average);
			}
			if (this._difficulty == EDifficulty.NORMAL)
			{
				return this.IsMore(this._pathSettings.NormalShortcutPathChance.Average);
			}
			return this._difficulty == EDifficulty.HARD && this.IsMore(this._pathSettings.HardShortcutPathChance.Average);
		case E_AILevel.BAD:
			if (this._difficulty == EDifficulty.EASY)
			{
				return this.IsMore(this._pathSettings.EasyShortcutPathChance.Bad);
			}
			if (this._difficulty == EDifficulty.NORMAL)
			{
				return this.IsMore(this._pathSettings.NormalShortcutPathChance.Bad);
			}
			return this._difficulty == EDifficulty.HARD && this.IsMore(this._pathSettings.HardShortcutPathChance.Bad);
		default:
			return false;
		}
	}

	// Token: 0x06000429 RID: 1065 RVA: 0x0002525C File Offset: 0x0002345C
	public E_PathType GetPathType(E_AILevel pLevel)
	{
		switch (pLevel)
		{
		case E_AILevel.GOOD:
			if (this._difficulty == EDifficulty.EASY)
			{
				return this.GetPathType(this._pathSettings.EasyGoodPathChance);
			}
			if (this._difficulty == EDifficulty.NORMAL)
			{
				return this.GetPathType(this._pathSettings.NormalGoodPathChance);
			}
			if (this._difficulty == EDifficulty.HARD)
			{
				return this.GetPathType(this._pathSettings.HardGoodPathChance);
			}
			return E_PathType.NONE;
		case E_AILevel.AVERAGE:
			if (this._difficulty == EDifficulty.EASY)
			{
				return this.GetPathType(this._pathSettings.EasyAveragePathChance);
			}
			if (this._difficulty == EDifficulty.NORMAL)
			{
				return this.GetPathType(this._pathSettings.NormalAveragePathChance);
			}
			if (this._difficulty == EDifficulty.HARD)
			{
				return this.GetPathType(this._pathSettings.HardAveragePathChance);
			}
			return E_PathType.NONE;
		case E_AILevel.BAD:
			if (this._difficulty == EDifficulty.EASY)
			{
				return this.GetPathType(this._pathSettings.EasyBadPathChance);
			}
			if (this._difficulty == EDifficulty.NORMAL)
			{
				return this.GetPathType(this._pathSettings.NormalBadPathChance);
			}
			if (this._difficulty == EDifficulty.HARD)
			{
				return this.GetPathType(this._pathSettings.HardBadPathChance);
			}
			return E_PathType.NONE;
		default:
			return E_PathType.NONE;
		}
	}

	// Token: 0x0600042A RID: 1066 RVA: 0x00025398 File Offset: 0x00023598
	private E_PathType GetPathType(Chance pChance)
	{
		int num = Singleton<RandomManager>.Instance.Next(0, 99);
		int good = pChance.Good;
		int average = pChance.Average;
		if (num >= 0 && num < good)
		{
			return E_PathType.GOOD;
		}
		if (num >= good && num < good + average)
		{
			return E_PathType.AVERAGE;
		}
		if (num >= good + average && num < 100)
		{
			return E_PathType.BAD;
		}
		return E_PathType.NONE;
	}

	// Token: 0x0600042B RID: 1067 RVA: 0x000253F8 File Offset: 0x000235F8
	public void SetBoostStart(GameMode oGameMode)
	{
		Chance chance = this._behaviourSettings.BoostStart100ccChance;
		switch (Singleton<GameConfigurator>.Instance.Difficulty)
		{
		case EDifficulty.NORMAL:
			chance = this._behaviourSettings.BoostStart100ccChance;
			break;
		case EDifficulty.HARD:
			chance = this._behaviourSettings.BoostStart150ccChance;
			break;
		case EDifficulty.EASY:
			chance = this._behaviourSettings.BoostStart50ccChance;
			break;
		}
		for (int i = 0; i < 6; i++)
		{
			if (this.AIs[i] != null && this.AIs[i].Vehicle.GetControlType() == RcVehicle.ControlType.AI && this.IsMore(chance.GetChance(this.AIs[i].Level)))
			{
				oGameMode.SetAdvantage(this.AIs[i].Vehicle.GetVehicleId(), EAdvantage.BoostStart);
			}
		}
	}

	// Token: 0x04000399 RID: 921
	protected PathSettings _pathSettings;

	// Token: 0x0400039A RID: 922
	protected BehaviourSettings _behaviourSettings;

	// Token: 0x0400039B RID: 923
	protected EDifficulty _difficulty;
}

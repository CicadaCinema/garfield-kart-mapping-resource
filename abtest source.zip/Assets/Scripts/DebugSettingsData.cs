﻿using System;
using UnityEngine;

// Token: 0x02000231 RID: 561
public class DebugSettingsData : ScriptableObject
{
	// Token: 0x06000FD3 RID: 4051 RVA: 0x00064628 File Offset: 0x00062828
	public DebugSettingsData()
	{
		this.DisplayFPS = true;
		this.ShortcutLoadingScreen = false;
		this.DisplayAnnotation = true;
		this.DisplaySpeed = true;
		this.DisplayCustom = false;
		this.RandomPlayer = false;
		this.LogTimeStamp = true;
		this.LogCategory = true;
		for (int i = 0; i < this.Categories.Length; i++)
		{
			this.Categories[i] = true;
		}
	}

	// Token: 0x04000F3A RID: 3898
	public bool DisplayFPS;

	// Token: 0x04000F3B RID: 3899
	public bool DisplayAnnotation;

	// Token: 0x04000F3C RID: 3900
	public bool DisplaySpeed;

	// Token: 0x04000F3D RID: 3901
	public bool ShortcutLoadingScreen;

	// Token: 0x04000F3E RID: 3902
	public bool UseInAppService;

	// Token: 0x04000F3F RID: 3903
	public bool DisplayCustom;

	// Token: 0x04000F40 RID: 3904
	public bool LogTimeStamp;

	// Token: 0x04000F41 RID: 3905
	public bool LogCategory;

	// Token: 0x04000F42 RID: 3906
	public bool RandomPlayer;

	// Token: 0x04000F43 RID: 3907
	public ECharacter DefaultCharacter;

	// Token: 0x04000F44 RID: 3908
	public ECharacter DefaultKart;

	// Token: 0x04000F45 RID: 3909
	public GameObject DefaultKartCustom;

	// Token: 0x04000F46 RID: 3910
	public GameObject DefaultHat;

	// Token: 0x04000F47 RID: 3911
	public EAdvantage DefaultAdvOne;

	// Token: 0x04000F48 RID: 3912
	public EAdvantage DefaultAdvTwo;

	// Token: 0x04000F49 RID: 3913
	public EAdvantage DefaultAdvThree;

	// Token: 0x04000F4A RID: 3914
	public EAdvantage DefaultAdvFour;

	// Token: 0x04000F4B RID: 3915
	public bool[] Categories = new bool[Enum.GetValues(typeof(EDbgCategory)).Length];

	// Token: 0x04000F4C RID: 3916
	public string SceneToLaunch;

	// Token: 0x04000F4D RID: 3917
	public E_GameModeType GameMode;
}

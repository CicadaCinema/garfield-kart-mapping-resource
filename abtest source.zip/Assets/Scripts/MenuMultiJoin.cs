﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200019F RID: 415
public class MenuMultiJoin : AbstractMenu
{
    private bool connecting = false;
	// Token: 0x06000B2C RID: 2860 RVA: 0x00009BE7 File Offset: 0x00007DE7
	public override void Awake()
	{
		base.Awake();
		this.networkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
	}

	// Token: 0x06000B2D RID: 2861 RVA: 0x00009C09 File Offset: 0x00007E09
	public override void OnEnter()
	{
		base.OnEnter();
		this.serverId = -1;
		this.m_fRefreshTimer = this.m_fAutoRefreshDelay;
		if (this.ConnectingLabel != null)
		{
			this.ConnectingLabel.enabled = false;
		}
	}

	// Token: 0x06000B2E RID: 2862 RVA: 0x00009C41 File Offset: 0x00007E41
	public void RefreshList()
	{
		this.m_fRefreshTimer = 0f;
		MasterServer.ClearHostList();
		MasterServer.RequestHostList("GK12");
	}

	// Token: 0x06000B2F RID: 2863 RVA: 0x00009C5D File Offset: 0x00007E5D
	public override void OnExit()
	{
		this.RemoveAllServers();
		base.OnExit();
	}

	// Token: 0x06000B30 RID: 2864 RVA: 0x0004B4DC File Offset: 0x000496DC
	public override void Update()
	{
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			this.ActSwapMenu(EMenus.MENU_MULTI);
		}
		float deltaTime = Time.deltaTime;
		this.m_fTimeScroll -= deltaTime;
		if (this.m_oScrollPanel != null && this.m_fSpeedScroll != 0f && this.m_fTimeScroll < 0f)
		{
			this.m_fTimeScroll = 0.1f;
			UIDraggablePanel component = this.m_oScrollPanel.GetComponent<UIDraggablePanel>();
			if (component)
			{
				component.Scroll(this.m_fSpeedScroll);
			}
		}
		if (this.serverId != -1 && this.networkMgr.DoneTesting)
		{
			string[] array = this.m_oHostDataDic[this.serverId].comment.Split(new char[]
			{
				','
			});
			string text = array[3];
			ConnectionTesterStatus serverNATType = (ConnectionTesterStatus)int.Parse(array[5]);
			if (!((!(this.networkMgr.ExternalIP != string.Empty)) ? text.Equals(this.networkMgr.networkView.owner.externalIP) : text.Equals(this.networkMgr.ExternalIP)) && !this.networkMgr.CanConnectTo(serverNATType))
			{
				this.oPopup = (PopupDialog)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG, false);
				if (this.oPopup)
				{
					this.oPopup.Show("MENU_POPUP_NAT_ERROR");
				}
			}
			Network.Connect(this.m_oHostDataDic[this.serverId]);
			if (this.ConnectingLabel != null)
			{
				this.ConnectingLabel.enabled = false;
			}
			this.serverId = -1;
		}
		this.m_fRefreshTimer += Time.deltaTime;
		if (this.m_fRefreshTimer > this.m_fAutoRefreshDelay || this.m_fRefreshTimer > 1f)
		{
			HostData[] array2 = MasterServer.PollHostList();
			List<int> list = new List<int>();
			foreach (KeyValuePair<int, HostData> keyValuePair in this.m_oHostDataDic)
			{
				bool flag = false;
				foreach (HostData hostData in array2)
				{
					string[] array4 = hostData.comment.Split(new char[]
					{
						','
					});
					if (hostData.guid == keyValuePair.Value.guid && array4.Length > 4 && array4[4] == "waitPlayers")
					{
						BtnServer component2 = this.m_oButtonServerList[keyValuePair.Key].GetComponent<BtnServer>();
						keyValuePair.Value.connectedPlayers = hostData.connectedPlayers;
						component2.SetPlayerCount(hostData.connectedPlayers);
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					list.Add(keyValuePair.Key);
				}
			}
			foreach (int iId in list)
			{
				this.RemoveServer(iId);
			}
			List<HostData> list2 = new List<HostData>();
			foreach (HostData hostData2 in array2)
			{
				string[] array6 = hostData2.comment.Split(new char[]
				{
					','
				});
				bool flag2 = false;
				if (array6.Length <= 4 || !(array6[4] == "startGame"))
				{
					foreach (KeyValuePair<int, HostData> keyValuePair2 in this.m_oHostDataDic)
					{
						if (hostData2.guid == keyValuePair2.Value.guid)
						{
							flag2 = true;
							break;
						}
					}
					if (!flag2)
					{
						list2.Add(hostData2);
					}
				}
			}
			foreach (HostData hostData3 in list2)
			{
				string[] array7 = hostData3.comment.Split(new char[]
				{
					','
				});
				int type = (!array7[0].Equals("Single race")) ? 1 : 0;
				bool flag3 = array7[1].Equals("LAN") || this.networkMgr.BLanOnly;
				string sGameName = array7[2];
				string text2 = string.Empty;
				if (array7.Length > 3)
				{
					text2 = array7[3];
				}
				if (!flag3 || text2.Equals(this.networkMgr.ExternalIP))
				{
					this.AddServer(this.m_iNextId++, hostData3, type, sGameName);
				}
			}
		}
		if (this.m_fRefreshTimer > this.m_fAutoRefreshDelay)
		{
			this.RefreshList();
		}
	}

	// Token: 0x06000B31 RID: 2865 RVA: 0x00009C6B File Offset: 0x00007E6B
	public void AddServer(int iId, HostData host, int type, string sGameName)
	{
		this.m_oHostDataDic.Add(iId, host);
		this.AddServer(iId, sGameName, host.connectedPlayers, type);
	}

	// Token: 0x06000B32 RID: 2866 RVA: 0x0004BA3C File Offset: 0x00049C3C
	public void AddServer(int iId, string sServerName, int iNbPlayers, int iGameType)
	{
		if (!this.m_oScrollPanel)
		{
			return;
		}
		GameObject gameObject = this.m_oScrollPanel.transform.GetChild(0).gameObject;
		GameObject gameObject2 = (GameObject)UnityEngine.Object.Instantiate(this.m_oButtonServerTemplate);
		if (!gameObject2)
		{
			return;
		}
		gameObject2.transform.parent = gameObject.transform;
		this.m_oButtonServerList.Add(iId, gameObject2);
		BtnServer component = gameObject2.GetComponent<BtnServer>();
		if (!component)
		{
			return;
		}
		component.Init(iId, sServerName, iNbPlayers, iGameType, base.gameObject, this.m_oScrollPanel);
		gameObject.SendMessage("Reposition");
		if (this.NoGame && this.NoGame.activeSelf)
		{
			this.NoGame.SetActive(false);
		}
	}

	// Token: 0x06000B33 RID: 2867 RVA: 0x0004BB10 File Offset: 0x00049D10
	public void RemoveServer(int iId)
	{
		GameObject obj;
		if (this.m_oButtonServerList.TryGetValue(iId, out obj))
		{
			UnityEngine.Object.Destroy(obj);
			this.m_oButtonServerList.Remove(iId);
		}
		this.m_oHostDataDic.Remove(iId);
		GameObject gameObject = this.m_oScrollPanel.transform.GetChild(0).gameObject;
		gameObject.SendMessage("Reposition");
		if (this.m_oButtonServerList.Count == 0 && this.NoGame && !this.NoGame.activeSelf)
		{
			this.NoGame.SetActive(true);
		}
	}

	// Token: 0x06000B34 RID: 2868 RVA: 0x0004BBB0 File Offset: 0x00049DB0
	public void RemoveAllServers()
	{
		foreach (KeyValuePair<int, GameObject> keyValuePair in this.m_oButtonServerList)
		{
			UnityEngine.Object.Destroy(keyValuePair.Value);
		}
		this.m_oButtonServerList.Clear();
		this.m_oHostDataDic.Clear();
		if (this.NoGame && !this.NoGame.activeSelf)
		{
			this.NoGame.SetActive(true);
		}
	}

	// Token: 0x06000B35 RID: 2869 RVA: 0x00009C8A File Offset: 0x00007E8A
	public void OnButtonUpDown(int iStep)
	{
		this.m_fSpeedScroll = (float)iStep * 0.1f;
	}

	// Token: 0x06000B36 RID: 2870 RVA: 0x00009C9A File Offset: 0x00007E9A
	public void OnButtonRefresh()
	{
		this.m_fRefreshTimer = this.m_fAutoRefreshDelay + 1f;
	}

	// Token: 0x06000B37 RID: 2871 RVA: 0x0004BC54 File Offset: 0x00049E54
	public void OnServer(int iId)
	{
		GameObject gameObject;
		if (this.m_oButtonServerList.TryGetValue(iId, out gameObject))
		{
			BtnServer component = gameObject.GetComponent<BtnServer>();
			if (component && this.serverId == -1)
			{
				if (component.GetPlayerCount() >= 6)
				{
					PopupDialog popupDialog = (PopupDialog)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG, false);
					if (popupDialog)
					{
						popupDialog.Show("MENU_POPUP_FULL");
					}
				}
				else
				{
					this.sServerName = component.GetServerName();
					this.iGameType = component.GetGameType();
					Network.Disconnect();
					if (this.ConnectingLabel != null)
					{
						this.ConnectingLabel.enabled = true;
					}
					this.serverId = iId;
				}
			}
		}
	}

	// Token: 0x06000B38 RID: 2872 RVA: 0x0004BD10 File Offset: 0x00049F10
	public void OnConnectedToServer()
	{
		if (this.oPopup != null)
		{
			this.oPopup.Hide();
			this.oPopup.OnQuit();
			this.oPopup = null;
		}
		if (this.ConnectingLabel != null)
		{
			this.ConnectingLabel.enabled = false;
		}
		MenuMultiWaitingRoom menuMultiWaitingRoom = this.m_pMenuEntryPoint.MenuRefList[7] as MenuMultiWaitingRoom;
		menuMultiWaitingRoom.Init(EMenus.MENU_MULTI_JOIN, this.serverId, this.sServerName, this.iGameType);
		this.ActSwapMenu(EMenus.MENU_MULTI_PLAYERS_LIST);
		Singleton<GameConfigurator>.Instance.GameModeType = ((this.iGameType != 0) ? E_GameModeType.CHAMPIONSHIP : E_GameModeType.SINGLE);
	}

	// Token: 0x06000B39 RID: 2873 RVA: 0x0004BDBC File Offset: 0x00049FBC
	public void OnFailedToConnect(NetworkConnectionError error)
	{
		this.serverId = -1;
		PopupDialog popupDialog = (PopupDialog)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG, false);
		if (popupDialog)
		{
			string textId = error.ToString();
			if (error == NetworkConnectionError.AlreadyConnectedToServer)
			{
				textId = "Please only click once.\r\nRestart your game.";
			}
			popupDialog.Show(textId);
		}
	}

	// Token: 0x06000B3A RID: 2874 RVA: 0x0004BE0C File Offset: 0x0004A00C
	public void OnFailedToConnectToMasterServer(NetworkConnectionError Error)
	{
		this.ActSwapMenu(EMenus.MENU_SOLO);
		PopupDialog popupDialog = (PopupDialog)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG, false);
		if (popupDialog)
		{
			popupDialog.Show(Error.ToString());
		}
		Network.Disconnect();
	}

	// Token: 0x04000AF8 RID: 2808
	public GameObject m_oScrollPanel;

	// Token: 0x04000AF9 RID: 2809
	public GameObject m_oButtonServerTemplate;

	// Token: 0x04000AFA RID: 2810
	public float m_fAutoRefreshDelay = 3f;

	// Token: 0x04000AFB RID: 2811
	public GameObject NoGame;

	// Token: 0x04000AFC RID: 2812
	private NetworkMgr networkMgr;

	// Token: 0x04000AFD RID: 2813
	private float m_fRefreshTimer;

	// Token: 0x04000AFE RID: 2814
	private string sServerName;

	// Token: 0x04000AFF RID: 2815
	private int iGameType;

	// Token: 0x04000B00 RID: 2816
	private int serverId = -1;

	// Token: 0x04000B01 RID: 2817
	private int m_iNextId;

	// Token: 0x04000B02 RID: 2818
	public UILabel ConnectingLabel;

	// Token: 0x04000B03 RID: 2819
	private Dictionary<int, GameObject> m_oButtonServerList = new Dictionary<int, GameObject>();

	// Token: 0x04000B04 RID: 2820
	private Dictionary<int, HostData> m_oHostDataDic = new Dictionary<int, HostData>();

	// Token: 0x04000B05 RID: 2821
	private PopupDialog oPopup;

	// Token: 0x04000B06 RID: 2822
	private float m_fSpeedScroll;

	// Token: 0x04000B07 RID: 2823
	private float m_fTimeScroll = 0.3f;
}

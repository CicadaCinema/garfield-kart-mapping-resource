﻿using System;

// Token: 0x020000D1 RID: 209
public enum EBonusCategory
{
	// Token: 0x04000556 RID: 1366
	PIE,
	// Token: 0x04000557 RID: 1367
	AUTOLOCK_PIE,
	// Token: 0x04000558 RID: 1368
	SPRING,
	// Token: 0x04000559 RID: 1369
	LASAGNA,
	// Token: 0x0400055A RID: 1370
	DIAMOND,
	// Token: 0x0400055B RID: 1371
	UFO,
	// Token: 0x0400055C RID: 1372
	NAP,
	// Token: 0x0400055D RID: 1373
	PARFUME,
	// Token: 0x0400055E RID: 1374
	MAGIC
}

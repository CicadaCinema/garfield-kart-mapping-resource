﻿using System;
using UnityEngine;

// Token: 0x02000029 RID: 41
[AddComponentMenu("NGUI/Interaction/Saved Option")]
public class UISavedOption : MonoBehaviour
{
	// Token: 0x17000010 RID: 16
	// (get) Token: 0x060000D6 RID: 214 RVA: 0x00002CEB File Offset: 0x00000EEB
	private string key
	{
		get
		{
			return (!string.IsNullOrEmpty(this.keyName)) ? this.keyName : ("NGUI State: " + base.name);
		}
	}

	// Token: 0x060000D7 RID: 215 RVA: 0x00011CE4 File Offset: 0x0000FEE4
	private void Awake()
	{
		this.mList = base.GetComponent<UIPopupList>();
		this.mCheck = base.GetComponent<UICheckbox>();
		if (this.mList != null)
		{
			UIPopupList uipopupList = this.mList;
			uipopupList.onSelectionChange = (UIPopupList.OnSelectionChange)Delegate.Combine(uipopupList.onSelectionChange, new UIPopupList.OnSelectionChange(this.SaveSelection));
		}
		if (this.mCheck != null)
		{
			UICheckbox uicheckbox = this.mCheck;
			uicheckbox.onStateChange = (UICheckbox.OnStateChange)Delegate.Combine(uicheckbox.onStateChange, new UICheckbox.OnStateChange(this.SaveState));
		}
	}

	// Token: 0x060000D8 RID: 216 RVA: 0x00011D7C File Offset: 0x0000FF7C
	private void OnDestroy()
	{
		if (this.mCheck != null)
		{
			UICheckbox uicheckbox = this.mCheck;
			uicheckbox.onStateChange = (UICheckbox.OnStateChange)Delegate.Remove(uicheckbox.onStateChange, new UICheckbox.OnStateChange(this.SaveState));
		}
		if (this.mList != null)
		{
			UIPopupList uipopupList = this.mList;
			uipopupList.onSelectionChange = (UIPopupList.OnSelectionChange)Delegate.Remove(uipopupList.onSelectionChange, new UIPopupList.OnSelectionChange(this.SaveSelection));
		}
	}

	// Token: 0x060000D9 RID: 217 RVA: 0x00011DFC File Offset: 0x0000FFFC
	private void OnEnable()
	{
		if (this.mList != null)
		{
			string @string = PlayerPrefs.GetString(this.key);
			if (!string.IsNullOrEmpty(@string))
			{
				this.mList.selection = @string;
			}
			return;
		}
		if (this.mCheck != null)
		{
			this.mCheck.isChecked = (PlayerPrefs.GetInt(this.key, 1) != 0);
		}
		else
		{
			string string2 = PlayerPrefs.GetString(this.key);
			UICheckbox[] componentsInChildren = base.GetComponentsInChildren<UICheckbox>(true);
			int i = 0;
			int num = componentsInChildren.Length;
			while (i < num)
			{
				UICheckbox uicheckbox = componentsInChildren[i];
				uicheckbox.isChecked = (uicheckbox.name == string2);
				i++;
			}
		}
	}

	// Token: 0x060000DA RID: 218 RVA: 0x00011EB8 File Offset: 0x000100B8
	private void OnDisable()
	{
		if (this.mCheck == null && this.mList == null)
		{
			UICheckbox[] componentsInChildren = base.GetComponentsInChildren<UICheckbox>(true);
			int i = 0;
			int num = componentsInChildren.Length;
			while (i < num)
			{
				UICheckbox uicheckbox = componentsInChildren[i];
				if (uicheckbox.isChecked)
				{
					this.SaveSelection(uicheckbox.name);
					break;
				}
				i++;
			}
		}
	}

	// Token: 0x060000DB RID: 219 RVA: 0x00002D18 File Offset: 0x00000F18
	private void SaveSelection(string selection)
	{
		PlayerPrefs.SetString(this.key, selection);
	}

	// Token: 0x060000DC RID: 220 RVA: 0x00002D26 File Offset: 0x00000F26
	private void SaveState(bool state)
	{
		PlayerPrefs.SetInt(this.key, (!state) ? 0 : 1);
	}

	// Token: 0x040000FB RID: 251
	public string keyName;

	// Token: 0x040000FC RID: 252
	private UIPopupList mList;

	// Token: 0x040000FD RID: 253
	private UICheckbox mCheck;
}

﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020001E1 RID: 481
public class PathRecorder : MonoBehaviour
{
	// Token: 0x170001AB RID: 427
	// (get) Token: 0x06000CEC RID: 3308 RVA: 0x0000AE40 File Offset: 0x00009040
	private Vector3 _Position
	{
		get
		{
			return this._target.transform.position;
		}
	}

	// Token: 0x06000CED RID: 3309 RVA: 0x00003B80 File Offset: 0x00001D80
	public void Start()
	{
	}

	// Token: 0x06000CEE RID: 3310 RVA: 0x000553E8 File Offset: 0x000535E8
	public void Update()
	{
		if (this._target)
		{
			if (Input.GetKeyDown(KeyCode.R) && Application.isPlaying && Application.isEditor)
			{
				this._recording = !this._recording;
			}
			if (this._recording && Application.isPlaying && Application.isEditor)
			{
				float num = Time.deltaTime * 1000f;
				if (num == 0f)
				{
					return;
				}
				this._pathTempo += num;
				if (this._pathTempo > this.Sampling)
				{
					this._pathTempo -= this.Sampling;
					PathRecorder.Path.Add(this._Position);
				}
			}
		}
		else if (Singleton<GameManager>.Instance.GameMode != null)
		{
			this._target = Singleton<GameManager>.Instance.GameMode.GetPlayer(0);
		}
	}

	// Token: 0x06000CEF RID: 3311 RVA: 0x000554E0 File Offset: 0x000536E0
	public void OnGUI()
	{
		string str = "On";
		if (!this._recording)
		{
			str = "Off";
		}
		GUI.contentColor = new Color(200f, 200f, 200f);
		GUI.Label(new Rect(20f, 50f, 200f, 20f), "Path Recorder : " + str);
	}

	// Token: 0x04000C83 RID: 3203
	public static List<Vector3> Path = new List<Vector3>();

	// Token: 0x04000C84 RID: 3204
	private float _pathTempo;

	// Token: 0x04000C85 RID: 3205
	public float Sampling;

	// Token: 0x04000C86 RID: 3206
	private bool _recording;

	// Token: 0x04000C87 RID: 3207
	private GameObject _target;
}

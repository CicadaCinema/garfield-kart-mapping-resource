﻿using System;
using UnityEngine;

// Token: 0x02000205 RID: 517
public abstract class RcGearBox : MonoBehaviour
{
	// Token: 0x06000E0C RID: 3596 RVA: 0x00003B7D File Offset: 0x00001D7D
	public virtual bool IsGoingTooFast()
	{
		return false;
	}

	// Token: 0x06000E0D RID: 3597
	public abstract float ComputeAcceleration(float _speedMS);

	// Token: 0x06000E0E RID: 3598
	public abstract float GetMaxSpeed();

	// Token: 0x06000E0F RID: 3599
	public abstract int GetCurrentGear();

	// Token: 0x06000E10 RID: 3600
	public abstract float GetBackwardMaxSpeed();

	// Token: 0x06000E11 RID: 3601
	public abstract float ComputeRpm(float speedMs);
}

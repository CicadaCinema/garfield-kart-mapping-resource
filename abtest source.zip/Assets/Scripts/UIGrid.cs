﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000021 RID: 33
[ExecuteInEditMode]
[AddComponentMenu("NGUI/Interaction/Grid")]
public class UIGrid : MonoBehaviour
{
	// Token: 0x060000AF RID: 175 RVA: 0x00002BCE File Offset: 0x00000DCE
	private void Start()
	{
		this.mStarted = true;
		this.Reposition();
	}

	// Token: 0x060000B0 RID: 176 RVA: 0x00002BDD File Offset: 0x00000DDD
	private void Update()
	{
		if (this.repositionNow)
		{
			this.repositionNow = false;
			this.Reposition();
		}
	}

	// Token: 0x060000B1 RID: 177 RVA: 0x00002BF7 File Offset: 0x00000DF7
	public static int SortByName(Transform a, Transform b)
	{
		return string.Compare(a.name, b.name);
	}

	// Token: 0x060000B2 RID: 178 RVA: 0x000109F0 File Offset: 0x0000EBF0
	public void Reposition()
	{
		if (!this.mStarted)
		{
			this.repositionNow = true;
			return;
		}
		Transform transform = base.transform;
		int num = 0;
		int num2 = 0;
		if (this.sorted)
		{
			List<Transform> list = new List<Transform>();
			for (int i = 0; i < transform.childCount; i++)
			{
				Transform child = transform.GetChild(i);
				if (child && (!this.hideInactive || NGUITools.GetActive(child.gameObject)))
				{
					list.Add(child);
				}
			}
			list.Sort(new Comparison<Transform>(UIGrid.SortByName));
			int j = 0;
			int count = list.Count;
			while (j < count)
			{
				Transform transform2 = list[j];
				if (NGUITools.GetActive(transform2.gameObject) || !this.hideInactive)
				{
					float z = transform2.localPosition.z;
					transform2.localPosition = ((this.arrangement != UIGrid.Arrangement.Horizontal) ? new Vector3(this.cellWidth * (float)num2, -this.cellHeight * (float)num, z) : new Vector3(this.cellWidth * (float)num, -this.cellHeight * (float)num2, z));
					if (++num >= this.maxPerLine && this.maxPerLine > 0)
					{
						num = 0;
						num2++;
					}
				}
				j++;
			}
		}
		else
		{
			for (int k = 0; k < transform.childCount; k++)
			{
				Transform child2 = transform.GetChild(k);
				if (NGUITools.GetActive(child2.gameObject) || !this.hideInactive)
				{
					float z2 = child2.localPosition.z;
					child2.localPosition = ((this.arrangement != UIGrid.Arrangement.Horizontal) ? new Vector3(this.cellWidth * (float)num2, -this.cellHeight * (float)num, z2) : new Vector3(this.cellWidth * (float)num, -this.cellHeight * (float)num2, z2));
					if (++num >= this.maxPerLine && this.maxPerLine > 0)
					{
						num = 0;
						num2++;
					}
				}
			}
		}
		UIDraggablePanel uidraggablePanel = NGUITools.FindInParents<UIDraggablePanel>(base.gameObject);
		if (uidraggablePanel != null)
		{
			uidraggablePanel.UpdateScrollbars(true);
		}
	}

	// Token: 0x040000C4 RID: 196
	public UIGrid.Arrangement arrangement;

	// Token: 0x040000C5 RID: 197
	public int maxPerLine;

	// Token: 0x040000C6 RID: 198
	public float cellWidth = 200f;

	// Token: 0x040000C7 RID: 199
	public float cellHeight = 200f;

	// Token: 0x040000C8 RID: 200
	public bool repositionNow;

	// Token: 0x040000C9 RID: 201
	public bool sorted;

	// Token: 0x040000CA RID: 202
	public bool hideInactive = true;

	// Token: 0x040000CB RID: 203
	private bool mStarted;

	// Token: 0x02000022 RID: 34
	public enum Arrangement
	{
		// Token: 0x040000CD RID: 205
		Horizontal,
		// Token: 0x040000CE RID: 206
		Vertical
	}
}

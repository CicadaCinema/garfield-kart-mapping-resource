﻿using System;
using UnityEngine;

// Token: 0x0200005F RID: 95
[AddComponentMenu("NGUI/Tween/Rotation")]
public class TweenRotation : UITweener
{
	// Token: 0x1700005B RID: 91
	// (get) Token: 0x06000278 RID: 632 RVA: 0x00003E03 File Offset: 0x00002003
	public Transform cachedTransform
	{
		get
		{
			if (this.mTrans == null)
			{
				this.mTrans = base.transform;
			}
			return this.mTrans;
		}
	}

	// Token: 0x1700005C RID: 92
	// (get) Token: 0x06000279 RID: 633 RVA: 0x00003E28 File Offset: 0x00002028
	// (set) Token: 0x0600027A RID: 634 RVA: 0x00003E35 File Offset: 0x00002035
	public Quaternion rotation
	{
		get
		{
			return this.cachedTransform.localRotation;
		}
		set
		{
			this.cachedTransform.localRotation = value;
		}
	}

	// Token: 0x0600027B RID: 635 RVA: 0x00003E43 File Offset: 0x00002043
	protected override void OnUpdate(float factor, bool isFinished)
	{
		this.cachedTransform.localRotation = Quaternion.Slerp(Quaternion.Euler(this.from), Quaternion.Euler(this.to), factor);
	}

	// Token: 0x0600027C RID: 636 RVA: 0x00018654 File Offset: 0x00016854
	public static TweenRotation Begin(GameObject go, float duration, Quaternion rot)
	{
		TweenRotation tweenRotation = UITweener.Begin<TweenRotation>(go, duration);
		tweenRotation.from = tweenRotation.rotation.eulerAngles;
		tweenRotation.to = rot.eulerAngles;
		if (duration <= 0f)
		{
			tweenRotation.Sample(1f, true);
			tweenRotation.enabled = false;
		}
		return tweenRotation;
	}

	// Token: 0x040001F8 RID: 504
	public Vector3 from;

	// Token: 0x040001F9 RID: 505
	public Vector3 to;

	// Token: 0x040001FA RID: 506
	private Transform mTrans;
}

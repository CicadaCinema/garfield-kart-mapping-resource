﻿using System;
using UnityEngine;

// Token: 0x0200011B RID: 283
[Serializable]
public class AdvantageSlots
{
	// Token: 0x040007DE RID: 2014
	public UITexturePattern Sprite;

	// Token: 0x040007DF RID: 2015
	public GameObject Parent;
}

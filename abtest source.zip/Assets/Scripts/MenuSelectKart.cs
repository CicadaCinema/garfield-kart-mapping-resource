﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020001B2 RID: 434
public class MenuSelectKart : AbstractMenu
{
	// Token: 0x17000180 RID: 384
	// (get) Token: 0x06000B8E RID: 2958 RVA: 0x0000A0F7 File Offset: 0x000082F7
	public GameObject ButtonPersonage
	{
		get
		{
			if (!this.m_oButtonPersonage)
			{
				this.m_oButtonPersonage = GameObject.Find("ButtonPersonage");
			}
			return this.m_oButtonPersonage;
		}
	}

	// Token: 0x06000B8F RID: 2959 RVA: 0x0004D4CC File Offset: 0x0004B6CC
	public override void Awake()
	{
		base.Awake();
		this.m_oNetworkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
		UnityEngine.Object[] array = Resources.LoadAll("Character", typeof(CharacterCarac));
		foreach (UnityEngine.Object @object in array)
		{
			this.m_oCharacterList.Add((CharacterCarac)@object);
		}
		UnityEngine.Object[] array3 = Resources.LoadAll("Hat", typeof(BonusCustom));
		foreach (UnityEngine.Object object2 in array3)
		{
			this.m_oHatList.Add((BonusCustom)object2);
		}
		UnityEngine.Object[] array5 = Resources.LoadAll("Kart", typeof(KartCarac));
		foreach (UnityEngine.Object object3 in array5)
		{
			this.m_oKartList.Add((KartCarac)object3);
		}
		UnityEngine.Object[] array7 = Resources.LoadAll("Kart", typeof(KartCustom));
		foreach (UnityEngine.Object object4 in array7)
		{
			if (object4.name.Contains("_Def"))
			{
				this.m_oKartCustomList.Insert(0, (KartCustom)object4);
			}
			else
			{
				this.m_oKartCustomList.Add((KartCustom)object4);
			}
		}
		UnityEngine.Object[] array9 = Resources.LoadAll("InApp", typeof(InAppCarac));
		foreach (UnityEngine.Object object5 in array9)
		{
			this.m_oCoinsCaracList.Add((InAppCarac)object5);
		}
		UnityEngine.Object[] array11 = Resources.LoadAll("Advantages", typeof(AdvantageData));
		foreach (UnityEngine.Object object6 in array11)
		{
			this.m_oAdvantagesList.Add((AdvantageData)object6);
		}
		this.SortLists();
		InAppManager instance = Singleton<InAppManager>.Instance;
		instance.OnPurchaseSucceed = (AInAppService.PurchaseDelegate)Delegate.Combine(instance.OnPurchaseSucceed, new AInAppService.PurchaseDelegate(this.PurchaseSucceed));
		InAppManager instance2 = Singleton<InAppManager>.Instance;
		instance2.OnPurchaseFailed = (AInAppService.PurchaseDelegate)Delegate.Combine(instance2.OnPurchaseFailed, new AInAppService.PurchaseDelegate(this.PurchaseFailed));
		InAppManager instance3 = Singleton<InAppManager>.Instance;
		instance3.OnPurchaseCancelled = (AInAppService.PurchaseDelegate)Delegate.Combine(instance3.OnPurchaseCancelled, new AInAppService.PurchaseDelegate(this.PurchaseFailed));
		this.m_oGrid = this.m_oScrollPanel.transform.GetChild(0);
		this.m_bNeedSelectTabAtUpdate = true;
		this.m_bNeedGoBuyCoins = false;
		string text = string.Empty;
		string text2 = string.Empty;
		Singleton<GameSaveManager>.Instance.GetPlayerConfig(ref Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter, ref Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart, ref text, ref text2);
		if (Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter == ECharacter.NONE)
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter = ECharacter.GARFIELD;
		}
		else
		{
			E_UnlockableItemSate e_UnlockableItemSate = Singleton<GameSaveManager>.Instance.GetCharacterState(Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter);
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewUnlocked || e_UnlockableItemSate == E_UnlockableItemSate.Unlocked)
			{
				this.m_eLastValidCharacter = Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter;
			}
			else
			{
				this.m_eLastValidCharacter = ECharacter.GARFIELD;
			}
		}
		if (Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart == ECharacter.NONE)
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart = ECharacter.JON;
		}
		else
		{
			E_UnlockableItemSate e_UnlockableItemSate = Singleton<GameSaveManager>.Instance.GetKartState(Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart);
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewUnlocked || e_UnlockableItemSate == E_UnlockableItemSate.Unlocked)
			{
				this.m_eLastValidKart = Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart;
			}
			else
			{
				this.m_eLastValidKart = ECharacter.JON;
			}
		}
		if (text2 == "None")
		{
			text2 = Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter.ToString()[0] + "_DefaultHat";
		}
		else
		{
			E_UnlockableItemSate e_UnlockableItemSate = Singleton<GameSaveManager>.Instance.GetHatState(text2);
			if (e_UnlockableItemSate != E_UnlockableItemSate.NewUnlocked && e_UnlockableItemSate != E_UnlockableItemSate.Unlocked)
			{
				text2 = Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter.ToString()[0] + "_DefaultHat";
			}
		}
		foreach (BonusCustom bonusCustom in this.m_oHatList)
		{
			if (bonusCustom.name == text2)
			{
				this.m_oLastValidHat = bonusCustom;
				Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat = bonusCustom;
			}
		}
		if (text == "None")
		{
			text = "K" + Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart.ToString()[0] + "C_Default";
		}
		else
		{
			E_UnlockableItemSate e_UnlockableItemSate = Singleton<GameSaveManager>.Instance.GetCustomState(text);
			if (e_UnlockableItemSate != E_UnlockableItemSate.NewUnlocked && e_UnlockableItemSate != E_UnlockableItemSate.Unlocked)
			{
				text = "K" + Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart.ToString()[0] + "C_Default";
			}
		}
		foreach (KartCustom kartCustom in this.m_oKartCustomList)
		{
			if (kartCustom.name == text)
			{
				this.m_oLastValidKartCustom = kartCustom;
				Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom = kartCustom;
			}
		}
		this.m_pEntryPoint = GameObject.Find("EntryPoint").GetComponent<EntryPoint>();
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			this.ShowShop = true;
		}
	}

	// Token: 0x06000B90 RID: 2960 RVA: 0x0004DAF4 File Offset: 0x0004BCF4
	public void OnDestroy()
	{
		InAppManager instance = Singleton<InAppManager>.Instance;
		instance.OnPurchaseSucceed = (AInAppService.PurchaseDelegate)Delegate.Remove(instance.OnPurchaseSucceed, new AInAppService.PurchaseDelegate(this.PurchaseSucceed));
		InAppManager instance2 = Singleton<InAppManager>.Instance;
		instance2.OnPurchaseFailed = (AInAppService.PurchaseDelegate)Delegate.Remove(instance2.OnPurchaseFailed, new AInAppService.PurchaseDelegate(this.PurchaseFailed));
		InAppManager instance3 = Singleton<InAppManager>.Instance;
		instance3.OnPurchaseCancelled = (AInAppService.PurchaseDelegate)Delegate.Remove(instance3.OnPurchaseCancelled, new AInAppService.PurchaseDelegate(this.PurchaseFailed));
		this.m_oCharacterList.Clear();
		this.m_oHatList.Clear();
		this.m_oKartList.Clear();
		this.m_oKartCustomList.Clear();
		this.m_oCoinsCaracList.Clear();
		this.m_oAdvantagesList.Clear();
		this.m_oNetworkMgr.ResetReadyStates();
	}

	// Token: 0x06000B91 RID: 2961 RVA: 0x0000A11F File Offset: 0x0000831F
	public override void Start()
	{
		base.Start();
	}

	// Token: 0x06000B92 RID: 2962 RVA: 0x0000A127 File Offset: 0x00008327
	public override void OnEnter()
	{
		this.OnEnter(0);
		this.wasServer = Network.isServer;
		this.SortLists();
	}

	// Token: 0x06000B93 RID: 2963 RVA: 0x0004DBC0 File Offset: 0x0004BDC0
	public override void OnEnter(int iEntryPoint)
	{
		base.OnEnter();
		this.goNet = false;
		this.NetworkReady.SetActive(false);
		if (!this.ShowShop)
		{
			this.m_oButtonCoins.SetActive(false);
		}
		else
		{
			this.m_oButtonCoins.SetActive(true);
		}
		if (Network.isServer)
		{
			this.m_oNetworkMgr.networkView.RPC("SetMenu", RPCMode.Others, new object[]
			{
				4
			});
			this.m_oNetworkMgr.networkView.RPC("ShareTrackChoice", RPCMode.All, new object[]
			{
				(int)Singleton<GameConfigurator>.Instance.GameModeType,
				Singleton<GameConfigurator>.Instance.ChampionShipData.Index,
				Singleton<GameConfigurator>.Instance.CurrentTrackIndex,
				(int)Singleton<GameConfigurator>.Instance.Difficulty
			});
		}
		this.m_eAdvantageRestrictions = MenuSelectKart.EAdvantageRestrictions.TIMETRIAL_RESTRICTION;
		if (iEntryPoint == 1)
		{
			this.m_eAdvantageRestrictions = MenuSelectKart.EAdvantageRestrictions.NO_RESTRICTION;
			if (this.m_oButtonAdvantages && this.m_oButtonAdvantages.collider)
			{
				this.m_oButtonAdvantages.collider.enabled = true;
			}
			this.m_oPanelText.gameObject.SetActive(false);
			this.m_oPanelInApp.SetActive(true);
			this.m_oBuyItemButton.SetActive(false);
			this.AnchorTopLeft.SetActive(false);
			this.ClientStateGO.SetActive(false);
		}
		else
		{
			this.m_oPanelText.gameObject.SetActive(true);
			this.m_oPanelInApp.SetActive(false);
			this.AnchorTopLeft.SetActive(true);
			this.DifficultyIcon.ChangeTexture((int)Singleton<GameConfigurator>.Instance.Difficulty);
			if ((Network.peerType == NetworkPeerType.Disconnected || this.m_oNetworkMgr.TrackChoiceReceived) && Singleton<GameConfigurator>.Instance.ChampionShipData != null)
			{
				this.UpdateTrackInfo();
			}
			else
			{
				this.m_bTrackInfoLoadingDone = false;
				this.m_eAdvantageRestrictions = MenuSelectKart.EAdvantageRestrictions.MULTI_CHAMP_RESTRICTION;
			}
			if (this.m_oButtonAdvantages && this.m_oButtonAdvantages.collider)
			{
				if (this.m_eAdvantageRestrictions == MenuSelectKart.EAdvantageRestrictions.TIMETRIAL_RESTRICTION)
				{
					this.m_oButtonAdvantages.collider.enabled = false;
					this.m_oButtonAdvantages.SetActive(false);
					if (this.m_iCurrentTab == 4)
					{
						this.OpenBuyCoinsTab(true);
					}
				}
				else
				{
					this.m_oButtonAdvantages.SetActive(true);
					this.m_oButtonAdvantages.collider.enabled = true;
				}
			}
			if (Network.peerType != NetworkPeerType.Disconnected)
			{
				this.ClientStateGO.SetActive(true);
			}
			else
			{
				this.ClientStateGO.SetActive(false);
			}
		}
		if (this.m_oButtonNext)
		{
			this.m_oButtonNext.SetActive(true);
		}
		if (this.m_oKartPreview)
		{
			this.m_oKartPreview.SendMessage("Init");
		}
		if (!this.m_bNeedSelectTabAtUpdate)
		{
			int iCurrentTab = this.m_iCurrentTab;
			this.m_iCurrentTab = -1;
			this.OnSelectTab(iCurrentTab);
			this.UpdatePreviewKart();
		}
		if (iEntryPoint == 1)
		{
			if (!this.m_bNeedSelectTabAtUpdate)
			{
				this.OpenBuyCoinsTab(false);
			}
			else
			{
				this.m_bNeedGoBuyCoins = true;
			}
		}
		this.m_bBackToPreviousState = (iEntryPoint != 0);
		if (this.m_oPanelAdvantages)
		{
			PanelAdvantages component = this.m_oPanelAdvantages.GetComponent<PanelAdvantages>();
			component.Initialize();
		}
		if (Network.peerType == NetworkPeerType.Disconnected || this.m_oTimerLabel == null)
		{
			this.m_bLimitTime = false;
		}
		else
		{
			this.m_fElapsedTime = 0f;
			this.m_bLimitTime = true;
		}
		if (this.m_oTimerLabel != null)
		{
			this.m_oTimerLabel.enabled = false;
		}
		this.m_elapsedTime = 0f;
		if (Network.peerType != NetworkPeerType.Disconnected)
		{
			for (int i = 0; i < this.ClientState.Count; i++)
			{
				this.ClientState[i].ChangeTexture(this.m_oNetworkMgr.SelectedColors.Count);
				this.ClientState[i].gameObject.SetActive(i < this.m_oNetworkMgr.ReadyToGo.Count);
			}
		}
	}

	// Token: 0x06000B94 RID: 2964 RVA: 0x0004E000 File Offset: 0x0004C200
	private void UpdateTrackInfo()
	{
		this.ChampionshipIcon.ChangeTexture(Singleton<GameConfigurator>.Instance.ChampionShipData.Index);
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
		{
			if (Network.isServer || Network.isClient)
			{
				this.m_eAdvantageRestrictions = MenuSelectKart.EAdvantageRestrictions.MULTI_CHAMP_RESTRICTION;
			}
			else
			{
				this.m_eAdvantageRestrictions = MenuSelectKart.EAdvantageRestrictions.CHAMPIONSHIP_RESTRICTION;
			}
			this.TrackName.text = Singleton<GameConfigurator>.Instance.ChampionShipData.ChampionShipName;
			this.GameModeIcon.ChangeTexture(0);
		}
		else if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.SINGLE)
		{
			this.GameModeIcon.ChangeTexture(1);
			this.TrackName.text = Singleton<GameConfigurator>.Instance.ChampionShipData.TracksName[Singleton<GameConfigurator>.Instance.CurrentTrackIndex];
			if (Network.isServer || Network.isClient)
			{
				this.m_eAdvantageRestrictions = MenuSelectKart.EAdvantageRestrictions.MULTI_SINGLE_RESTRICTION;
			}
			else
			{
				this.m_eAdvantageRestrictions = MenuSelectKart.EAdvantageRestrictions.SINGLE_RESTRICTION;
			}
		}
		else if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
		{
			this.GameModeIcon.ChangeTexture(2);
			this.TrackName.text = Singleton<GameConfigurator>.Instance.ChampionShipData.TracksName[Singleton<GameConfigurator>.Instance.CurrentTrackIndex];
		}
		this.m_bTrackInfoLoadingDone = true;
	}

	// Token: 0x06000B95 RID: 2965 RVA: 0x0000A141 File Offset: 0x00008341
	public override void OnExit()
	{
		if (this.m_oKartPreview)
		{
			this.m_oKartPreview.SendMessage("DestroyKartPreview");
		}
		base.OnExit();
	}

	// Token: 0x06000B96 RID: 2966 RVA: 0x0004E140 File Offset: 0x0004C340
	public void LateUpdate()
	{
		if (this.m_bNeedSelectTabAtUpdate)
		{
			int iCurrentTab = this.m_iCurrentTab;
			this.m_iCurrentTab = -1;
			this.OnSelectTab(iCurrentTab);
			this.UpdatePreviewKart();
			if (this.m_bNeedGoBuyCoins)
			{
				this.OpenBuyCoinsTab(false);
				this.m_bNeedGoBuyCoins = false;
			}
			this.m_bNeedSelectTabAtUpdate = false;
		}
		if (this.m_bLimitTime)
		{
			this.m_fElapsedTime += Time.deltaTime;
			if (this.m_fElapsedTime > (float)(this.m_iTimeLimit - this.m_iStartDisplaying))
			{
				this.m_oTimerLabel.enabled = true;
				this.m_oTimerLabel.text = ((int)((float)this.m_iTimeLimit - this.m_fElapsedTime)).ToString();
				if (this.m_fElapsedTime >= (float)this.m_iTimeLimit)
				{
					this.m_oTimerLabel.enabled = false;
					this.m_bLimitTime = false;
					this.OnTimeOut();
				}
			}
		}
		this.m_elapsedTime += Time.deltaTime;
	}

	// Token: 0x06000B97 RID: 2967 RVA: 0x0004E23C File Offset: 0x0004C43C
	public override void Update()
	{
		if (Application.platform == RuntimePlatform.Android && Input.GetKeyDown(KeyCode.Escape))
		{
			this.OnButtonBack();
		}
		if (Network.isServer && this.goNet && !this.m_oNetworkMgr.WaitingSynchronization)
		{
			this.m_oNetworkMgr.DispatchIds();
			this.m_oNetworkMgr.networkView.RPC("Go", RPCMode.All, new object[]
			{
				Singleton<GameConfigurator>.Instance.StartScene
			});
		}
		if (Network.peerType != NetworkPeerType.Disconnected)
		{
			Dictionary<NetworkPlayer, bool> readyToGo = this.m_oNetworkMgr.ReadyToGo;
			int num = 0;
			foreach (KeyValuePair<NetworkPlayer, bool> keyValuePair in readyToGo)
			{
				if (keyValuePair.Value)
				{
					this.ClientState[num].ChangeTexture(this.m_oNetworkMgr.SelectedColors.IndexOf(this.m_oNetworkMgr.PlayersColor[keyValuePair.Key]));
				}
				num++;
			}
		}
		else if (this.goNet && this.wasServer)
		{
			this.Go(null);
		}
		if (!this.m_bTrackInfoLoadingDone && this.m_oNetworkMgr.TrackChoiceReceived && Singleton<GameConfigurator>.Instance.ChampionShipData != null)
		{
			this.UpdateTrackInfo();
		}
	}

	// Token: 0x06000B98 RID: 2968 RVA: 0x0004E3BC File Offset: 0x0004C5BC
	public void OnButtonGo()
	{
		string key;
		if (this.IsNextButtonValid(out key))
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantages().Clear();
			PanelAdvantages component = this.m_oPanelAdvantages.GetComponent<PanelAdvantages>();
			if (component)
			{
				component.ValidSlots();
			}
			if (Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantages().Count == 0 && Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TIME_TRIAL && !Singleton<ChallengeManager>.Instance.IsActive)
			{
				this.OnSelectTab(4);
				this.m_oButtonAdvantages.GetComponent<UICheckbox>().isChecked = true;
				Popup2Choices popup2Choices = (Popup2Choices)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG_2CHOICES, false);
				if (popup2Choices)
				{
					Popup2Choices popup2Choices2 = popup2Choices;
					Popup2Choices.Callback oCbRight = new Popup2Choices.Callback(this.Go);
					popup2Choices2.Show("MENU_POPUP_NO_ADVANTAGE", null, oCbRight, null, "MENU_POPUP_NO", "MENU_POPUP_YES");
				}
			}
			else
			{
				this.Go(null);
			}
		}
		else
		{
			PopupDialog popupDialog = (PopupDialog)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG, true);
			popupDialog.gameObject.SetActive(true);
			UILabel component2 = popupDialog.Text.gameObject.GetComponent<UILabel>();
			if (component2)
			{
				component2.text = string.Format(Localization.instance.Get("MENU_SHOP_OBJECT_UNAVAILABLE"), Localization.instance.Get(key));
			}
		}
	}

	// Token: 0x06000B99 RID: 2969 RVA: 0x0004E510 File Offset: 0x0004C710
	private void RevertToLastValidState()
	{
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		PlayerConfig playerConfig = Singleton<GameConfigurator>.Instance.PlayerConfig;
		E_UnlockableItemSate e_UnlockableItemSate = instance.GetCharacterState(playerConfig.m_eCharacter);
		if (e_UnlockableItemSate != E_UnlockableItemSate.NewUnlocked && e_UnlockableItemSate != E_UnlockableItemSate.Unlocked)
		{
			playerConfig.m_eCharacter = this.m_eLastValidCharacter;
			if (playerConfig.m_oHat.Owner != ECharacter.NONE && playerConfig.m_oHat.Owner != this.m_eLastValidCharacter)
			{
				if (this.m_oLastValidHat.Owner == ECharacter.NONE || this.m_oLastValidHat.Owner == this.m_eLastValidCharacter)
				{
					playerConfig.m_oHat = this.m_oLastValidHat;
				}
				else
				{
					foreach (BonusCustom bonusCustom in this.m_oHatList)
					{
						if (bonusCustom.Owner == this.m_eLastValidCharacter)
						{
							playerConfig.m_oHat = bonusCustom;
							break;
						}
					}
				}
			}
		}
		e_UnlockableItemSate = instance.GetKartState(playerConfig.m_eKart);
		if (e_UnlockableItemSate != E_UnlockableItemSate.NewUnlocked && e_UnlockableItemSate != E_UnlockableItemSate.Unlocked)
		{
			playerConfig.m_eKart = this.m_eLastValidKart;
			if (playerConfig.m_oKartCustom.Character != ECharacter.NONE && playerConfig.m_oKartCustom.Character != this.m_eLastValidKart)
			{
				if (this.m_oLastValidKartCustom.Character == ECharacter.NONE || this.m_oLastValidKartCustom.Character == this.m_eLastValidKart)
				{
					playerConfig.m_oKartCustom = this.m_oLastValidKartCustom;
				}
				else
				{
					foreach (KartCustom kartCustom in this.m_oKartCustomList)
					{
						if (kartCustom.Owner == this.m_eLastValidKart)
						{
							playerConfig.m_oKartCustom = kartCustom;
							break;
						}
					}
				}
			}
		}
		e_UnlockableItemSate = instance.GetHatState(playerConfig.m_oHat.name);
		if (e_UnlockableItemSate != E_UnlockableItemSate.NewUnlocked && e_UnlockableItemSate != E_UnlockableItemSate.Unlocked)
		{
			playerConfig.m_oHat = this.m_oLastValidHat;
		}
		e_UnlockableItemSate = instance.GetCustomState(playerConfig.m_oKartCustom.name);
		if (e_UnlockableItemSate != E_UnlockableItemSate.NewUnlocked && e_UnlockableItemSate != E_UnlockableItemSate.Unlocked)
		{
			playerConfig.m_oKartCustom = this.m_oLastValidKartCustom;
		}
		KartCarac kartCarac = (KartCarac)Resources.Load("Kart/" + playerConfig.KartPrefab[(int)playerConfig.m_eKart], typeof(KartCarac));
		CharacterCarac characterCarac = (CharacterCarac)Resources.Load("Character/" + playerConfig.CharacterPrefab[(int)playerConfig.m_eCharacter], typeof(CharacterCarac));
		Singleton<GameConfigurator>.Instance.NbSlots = kartCarac.NbSlots + characterCarac.NbSlots + playerConfig.m_oHat.NbSlots + playerConfig.m_oKartCustom.NbSlots;
	}

	// Token: 0x06000B9A RID: 2970 RVA: 0x0004E7F0 File Offset: 0x0004C9F0
	private void OnTimeOut()
	{
		this.RevertToLastValidState();
		Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantages().Clear();
		PanelAdvantages component = this.m_oPanelAdvantages.GetComponent<PanelAdvantages>();
		if (component)
		{
			component.ValidSlots();
		}
		this.Go(null);
	}

	// Token: 0x06000B9B RID: 2971 RVA: 0x0004E83C File Offset: 0x0004CA3C
	public void OnButtonBack()
	{
		this.RevertToLastValidState();
		Singleton<GameSaveManager>.Instance.SetPlayerConfig(Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter, Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart, Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom.name, Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat.name, true);
		if (LogManager.Instance != null)
		{
		}
		if (this.m_bBackToPreviousState)
		{
			this.m_pMenuEntryPoint.SetPreviousState();
			if (ASE_Tools.Available)
			{
				ASE_ChartBoost.ShowInterstitial("Default");
			}
			return;
		}
		if (Network.isClient || Network.isServer)
		{
			this.ActSwapMenu(EMenus.MENU_MULTI_JOIN);
			Network.Disconnect();
		}
		else
		{
			this.ActSwapMenu(EMenus.MENU_SELECT_TRACK);
		}
	}

	// Token: 0x06000B9C RID: 2972 RVA: 0x0004E904 File Offset: 0x0004CB04
	public void Go(object oParam = null)
	{
		Singleton<GameSaveManager>.Instance.SetPlayerConfig(Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter, Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart, Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom.name, Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat.name, true);
		if (LogManager.Instance != null)
		{
			PlayerConfig playerConfig = Singleton<GameConfigurator>.Instance.PlayerConfig;
			foreach (EAdvantage eadvantage in playerConfig.GetAdvantages())
			{
			}
			if ((Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer) || Singleton<GameOptionManager>.Instance.GetInputType() == E_InputType.Gyroscopic)
			{
			}
		}
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			LoadingManager.LoadLevel(Singleton<GameConfigurator>.Instance.StartScene);
		}
		else if (!this.goNet)
		{
			this.goNet = true;
			this.m_oButtonNext.SetActive(false);
			this.NetworkReady.SetActive(true);
			if (!this.m_oNetworkMgr.WaitingSynchronization)
			{
				this.m_oNetworkMgr.networkView.RPC("SetReadyToGo", RPCMode.All, new object[]
				{
					Network.player,
					true
				});
				this.m_oNetworkMgr.StartSynchronization();
			}
		}
	}

	// Token: 0x06000B9D RID: 2973 RVA: 0x0004EA80 File Offset: 0x0004CC80
	public void RemoveAllItems()
	{
		if (this.m_oScrollPanel && this.m_oGrid)
		{
			for (int i = this.m_oGrid.GetChildCount(); i > 0; i--)
			{
				UnityEngine.Object.Destroy(this.m_oGrid.GetChild(i - 1).gameObject);
			}
		}
	}

	// Token: 0x06000B9E RID: 2974 RVA: 0x0004EAE4 File Offset: 0x0004CCE4
	public void OnSelectTab(int iTab)
	{
		if (iTab == this.m_iCurrentTab)
		{
			return;
		}
		bool active = true;
		this.m_iCurrentTab = iTab;
		this.RemoveAllItems();
		if (this.m_oPanelAdvantages)
		{
			PanelAdvantages component = this.m_oPanelAdvantages.GetComponent<PanelAdvantages>();
			if (component && component.enabled)
			{
				if (this.m_iCurrentTab == 5)
				{
					component.HiddenExit();
				}
				else
				{
					component.OnExit();
				}
			}
			if (this.m_oKartPreview && this.m_oKartPreview.collider)
			{
				this.m_oKartPreview.collider.enabled = true;
			}
		}
		Camera camera = this.m_oCamera;
		this.m_oPanelText.gameObject.SetActive(true);
		this.m_oPanelInApp.SetActive(false);
		switch (this.m_iCurrentTab)
		{
		case 0:
			this.InitCharacters();
			break;
		case 1:
			this.InitKarts();
			break;
		case 2:
			this.InitHats();
			break;
		case 3:
			this.InitKartCustoms();
			break;
		case 4:
			active = false;
			this.InitAdvantages();
			camera = this.m_oCameraShop;
			break;
		case 5:
			this.m_oPanelText.gameObject.SetActive(false);
			this.m_oPanelInApp.SetActive(true);
			this.m_oBuyItemButton.SetActive(false);
			active = false;
			this.InitCoins();
			camera = this.m_oCameraShop;
			break;
		}
		if (this.m_pMenuEntryPoint && this.m_oCamera && this.m_oCameraShop)
		{
			this.m_pMenuEntryPoint.SetCamera(camera);
		}
		if (this.m_oPanelDataKart)
		{
			this.m_oPanelDataKart.SetActive(active);
		}
		if (this.m_oPanelDataIcon)
		{
			this.m_oPanelDataIcon.SetActive(active);
		}
	}

	// Token: 0x06000B9F RID: 2975 RVA: 0x0004ECD4 File Offset: 0x0004CED4
	private BtnItem AddItem()
	{
		GameObject gameObject = (GameObject)UnityEngine.Object.Instantiate(this.m_oButtonItemTemplate);
		if (!gameObject)
		{
			return null;
		}
		Vector3 position = gameObject.transform.position;
		position.z = 0f;
		gameObject.transform.position = position;
		gameObject.transform.parent = this.m_oGrid.transform;
		return gameObject.GetComponent<BtnItem>();
	}

	// Token: 0x06000BA0 RID: 2976 RVA: 0x0004ED44 File Offset: 0x0004CF44
	public void InitCharacters()
	{
		if (!this.m_oScrollPanel || !this.m_oButtonItemTemplate || !this.m_oGrid)
		{
			return;
		}
		Transform oBtn = null;
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		ECharacter eCharacter = Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter;
		foreach (CharacterCarac characterCarac in this.m_oCharacterList)
		{
			E_UnlockableItemSate characterState = instance.GetCharacterState(characterCarac.Owner);
			BtnItem btnItem = this.AddItem();
			bool flag = characterCarac.Owner == eCharacter;
			btnItem.Init(base.gameObject, this.m_oScrollPanel, characterCarac.spriteName, ERarity.Base, 0, characterCarac, characterState, flag);
			if (flag)
			{
				oBtn = btnItem.gameObject.transform;
				this.UpdateTextPanel(characterCarac, characterState);
			}
		}
		this.UpdatePanel(oBtn);
	}

	// Token: 0x06000BA1 RID: 2977 RVA: 0x0004EE58 File Offset: 0x0004D058
	public void InitKarts()
	{
		if (!this.m_oScrollPanel || !this.m_oButtonItemTemplate || !this.m_oGrid)
		{
			return;
		}
		Transform oBtn = null;
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		ECharacter eKart = Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart;
		foreach (KartCarac kartCarac in this.m_oKartList)
		{
			E_UnlockableItemSate kartState = instance.GetKartState(kartCarac.Owner);
			BtnItem btnItem = this.AddItem();
			bool flag = kartCarac.Owner == eKart;
			btnItem.Init(base.gameObject, this.m_oScrollPanel, kartCarac.spriteName, ERarity.Base, Singleton<GameConfigurator>.Instance.PriceConfig.GetKartPrice(), kartCarac, kartState, flag);
			if (flag)
			{
				oBtn = btnItem.gameObject.transform;
				this.UpdateTextPanel(kartCarac, kartState);
			}
		}
		this.UpdatePanel(oBtn);
	}

	// Token: 0x06000BA2 RID: 2978 RVA: 0x0004EF78 File Offset: 0x0004D178
	public void InitHats()
	{
		if (!this.m_oScrollPanel || !this.m_oButtonItemTemplate || !this.m_oGrid)
		{
			return;
		}
		Transform oBtn = null;
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		ECharacter eCharacter = Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter;
		string name = Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat.name;
		foreach (BonusCustom bonusCustom in this.m_oHatList)
		{
			if (bonusCustom.Owner == ECharacter.NONE || bonusCustom.Owner == eCharacter)
			{
				E_UnlockableItemSate hatState = instance.GetHatState(bonusCustom.name);
				if (hatState != E_UnlockableItemSate.Hidden || (hatState == E_UnlockableItemSate.Hidden && bonusCustom.Rarity == ERarity.Base))
				{
					BtnItem btnItem = this.AddItem();
					bool flag = bonusCustom.name == name;
					btnItem.Init(base.gameObject, this.m_oScrollPanel, bonusCustom.spriteName, bonusCustom.Rarity, Singleton<GameConfigurator>.Instance.PriceConfig.GetHatPrice(bonusCustom.Rarity, bonusCustom.Owner == ECharacter.NONE), bonusCustom, hatState, flag);
					if (flag)
					{
						oBtn = btnItem.gameObject.transform;
						this.UpdateTextPanel(bonusCustom, hatState);
					}
				}
			}
		}
		this.UpdatePanel(oBtn);
	}

	// Token: 0x06000BA3 RID: 2979 RVA: 0x0004F100 File Offset: 0x0004D300
	public void InitKartCustoms()
	{
		if (!this.m_oScrollPanel || !this.m_oButtonItemTemplate)
		{
			return;
		}
		Transform oBtn = null;
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		ECharacter eKart = Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart;
		string name = Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom.name;
		foreach (KartCustom kartCustom in this.m_oKartCustomList)
		{
			if (kartCustom.Character == ECharacter.NONE || kartCustom.Character == eKart)
			{
				E_UnlockableItemSate customState = instance.GetCustomState(kartCustom.name);
				if (customState != E_UnlockableItemSate.Hidden || (customState == E_UnlockableItemSate.Hidden && kartCustom.Rarity == ERarity.Base))
				{
					BtnItem btnItem = this.AddItem();
					bool flag = kartCustom.name == name;
					btnItem.Init(base.gameObject, this.m_oScrollPanel, kartCustom.spriteName, kartCustom.Rarity, Singleton<GameConfigurator>.Instance.PriceConfig.GetCustoPrice(kartCustom.Rarity), kartCustom, customState, flag);
					if (flag)
					{
						oBtn = btnItem.gameObject.transform;
						this.UpdateTextPanel(kartCustom, customState);
					}
				}
			}
		}
		this.UpdatePanel(oBtn);
	}

	// Token: 0x06000BA4 RID: 2980 RVA: 0x0004F270 File Offset: 0x0004D470
	public bool IsAdvantageAvailable(EAdvantage eAdvantage)
	{
		foreach (AdvantageData advantageData in this.m_oAdvantagesList)
		{
			if (advantageData.AdvantageType == eAdvantage)
			{
				return this.IsAdvantageAvailable(advantageData);
			}
		}
		return false;
	}

	// Token: 0x06000BA5 RID: 2981 RVA: 0x0004F2E0 File Offset: 0x0004D4E0
	private bool IsAdvantageAvailable(AdvantageData oAdvantage)
	{
		switch (this.m_eAdvantageRestrictions)
		{
		case MenuSelectKart.EAdvantageRestrictions.SINGLE_RESTRICTION:
			return oAdvantage.bIsAvailableInSingle;
		case MenuSelectKart.EAdvantageRestrictions.CHAMPIONSHIP_RESTRICTION:
			return oAdvantage.bIsAvailableInChampionship;
		case MenuSelectKart.EAdvantageRestrictions.MULTI_SINGLE_RESTRICTION:
			return oAdvantage.bIsAvailableInSingle && oAdvantage.bIsAvailableInMulti;
		case MenuSelectKart.EAdvantageRestrictions.MULTI_CHAMP_RESTRICTION:
			return oAdvantage.bIsAvailableInChampionship && oAdvantage.bIsAvailableInMulti;
		}
		return true;
	}

	// Token: 0x06000BA6 RID: 2982 RVA: 0x0004F360 File Offset: 0x0004D560
	public void InitAdvantages()
	{
		if (!this.m_oPanelAdvantages)
		{
			return;
		}
		PanelAdvantages component = this.m_oPanelAdvantages.GetComponent<PanelAdvantages>();
		if (component)
		{
			component.OnEnter();
		}
		if (this.m_oKartPreview && this.m_oKartPreview.collider)
		{
			this.m_oKartPreview.collider.enabled = false;
		}
		if (!this.m_oScrollPanel || !this.m_oButtonItemTemplate || !this.m_oGrid)
		{
			return;
		}
		bool flag = true;
		Transform oBtn = null;
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		foreach (AdvantageData advantageData in this.m_oAdvantagesList)
		{
			E_UnlockableItemSate advantageState = instance.GetAdvantageState(advantageData.AdvantageType);
			if (advantageState != E_UnlockableItemSate.Hidden && this.IsAdvantageAvailable(advantageData))
			{
				BtnItem btnItem = this.AddItem();
				btnItem.m_oAtlas = this.m_oAdvAtlas;
				btnItem.Init(base.gameObject, this.m_oScrollPanel, advantageData.spriteName, ERarity.Base, advantageData.Price, advantageData, advantageState, flag);
				if (flag)
				{
					flag = false;
					oBtn = btnItem.gameObject.transform;
					this.UpdateTextPanel(advantageData, advantageState);
				}
			}
		}
		foreach (AdvantageData advantageData2 in this.m_oAdvantagesList)
		{
			E_UnlockableItemSate advantageState2 = instance.GetAdvantageState(advantageData2.AdvantageType);
			if (advantageState2 == E_UnlockableItemSate.Hidden && this.IsAdvantageAvailable(advantageData2))
			{
				BtnItem btnItem2 = this.AddItem();
				btnItem2.m_oAtlas = this.m_oAdvAtlas;
				btnItem2.Init(base.gameObject, this.m_oScrollPanel, advantageData2.spriteName, ERarity.Base, advantageData2.Price, advantageData2, advantageState2, flag);
				if (flag)
				{
					flag = false;
					oBtn = btnItem2.gameObject.transform;
					this.UpdateTextPanel(advantageData2, advantageState2);
				}
			}
		}
		this.UpdatePanel(oBtn);
	}

	// Token: 0x06000BA7 RID: 2983 RVA: 0x0004F5A0 File Offset: 0x0004D7A0
	public void InitCoins()
	{
		if (!this.m_oScrollPanel || !this.m_oButtonItemTemplate)
		{
			return;
		}
		bool flag = true;
		Transform oBtn = null;
		foreach (InAppCarac inAppCarac in this.m_oCoinsCaracList)
		{
			BtnItem btnItem = this.AddItem();
			btnItem.Init(base.gameObject, this.m_oScrollPanel, inAppCarac.spriteName, ERarity.Base, 0, inAppCarac, E_UnlockableItemSate.Locked, flag);
			if (flag)
			{
				flag = false;
				oBtn = btnItem.gameObject.transform;
				this.UpdateInAppPanel(inAppCarac);
			}
		}
		this.UpdatePanel(oBtn);
	}

	// Token: 0x06000BA8 RID: 2984 RVA: 0x0004F664 File Offset: 0x0004D864
	public void OnClickItem(UnityEngine.Object oData)
	{
		E_UnlockableItemSate e_UnlockableItemSate = E_UnlockableItemSate.Hidden;
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		switch (this.m_iCurrentTab)
		{
		case 0:
			Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter = ((CharacterCarac)oData).Owner;
			if (Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat.Owner != ECharacter.NONE && Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat.Owner != Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter)
			{
				foreach (BonusCustom bonusCustom in this.m_oHatList)
				{
					if (bonusCustom.Owner == Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter)
					{
						Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat = bonusCustom;
						break;
					}
				}
			}
			e_UnlockableItemSate = instance.GetCharacterState(((CharacterCarac)oData).Owner);
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewUnlocked || e_UnlockableItemSate == E_UnlockableItemSate.Unlocked)
			{
				this.m_eLastValidCharacter = ((CharacterCarac)oData).Owner;
				E_UnlockableItemSate hatState = instance.GetHatState(Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat.name);
				if (hatState == E_UnlockableItemSate.NewUnlocked || hatState == E_UnlockableItemSate.Unlocked)
				{
					this.m_oLastValidHat = Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat;
				}
			}
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewLocked)
			{
				e_UnlockableItemSate = E_UnlockableItemSate.Locked;
				instance.SetCharacterState(((CharacterCarac)oData).Owner, E_UnlockableItemSate.Locked, true);
			}
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewUnlocked)
			{
				e_UnlockableItemSate = E_UnlockableItemSate.Unlocked;
				instance.SetCharacterState(((CharacterCarac)oData).Owner, E_UnlockableItemSate.Unlocked, true);
			}
			break;
		case 1:
			Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart = ((KartCarac)oData).Owner;
			if (Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom.Character != ECharacter.NONE && Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom.Character != Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart)
			{
				foreach (KartCustom kartCustom in this.m_oKartCustomList)
				{
					if (kartCustom.Character == Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart)
					{
						Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom = kartCustom;
						break;
					}
				}
			}
			e_UnlockableItemSate = instance.GetKartState(((KartCarac)oData).Owner);
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewLocked)
			{
				e_UnlockableItemSate = E_UnlockableItemSate.Locked;
				instance.SetKartState(((KartCarac)oData).Owner, E_UnlockableItemSate.Locked, true);
			}
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewUnlocked)
			{
				e_UnlockableItemSate = E_UnlockableItemSate.Unlocked;
				instance.SetKartState(((KartCarac)oData).Owner, E_UnlockableItemSate.Unlocked, true);
			}
			if (e_UnlockableItemSate == E_UnlockableItemSate.Unlocked)
			{
				this.m_eLastValidKart = ((KartCarac)oData).Owner;
				E_UnlockableItemSate customState = instance.GetCustomState(Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom.name);
				if (customState == E_UnlockableItemSate.NewUnlocked || customState == E_UnlockableItemSate.Unlocked)
				{
					this.m_oLastValidKartCustom = Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom;
				}
			}
			break;
		case 2:
			Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat = (BonusCustom)oData;
			e_UnlockableItemSate = instance.GetHatState(((BonusCustom)oData).name);
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewLocked)
			{
				e_UnlockableItemSate = E_UnlockableItemSate.Locked;
				instance.SetHatState(((BonusCustom)oData).name, E_UnlockableItemSate.Locked, true);
			}
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewUnlocked)
			{
				e_UnlockableItemSate = E_UnlockableItemSate.Unlocked;
				instance.SetHatState(((BonusCustom)oData).name, E_UnlockableItemSate.Unlocked, true);
			}
			if (e_UnlockableItemSate == E_UnlockableItemSate.Unlocked)
			{
				this.m_oLastValidHat = (BonusCustom)oData;
			}
			if (this.HatSound)
			{
				this.HatSound.Play();
			}
			break;
		case 3:
			Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom = (KartCustom)oData;
			e_UnlockableItemSate = instance.GetCustomState(((KartCustom)oData).name);
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewLocked)
			{
				e_UnlockableItemSate = E_UnlockableItemSate.Locked;
				instance.SetCustomState(((KartCustom)oData).name, E_UnlockableItemSate.Locked, true);
			}
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewUnlocked)
			{
				e_UnlockableItemSate = E_UnlockableItemSate.Unlocked;
				instance.SetCustomState(((KartCustom)oData).name, E_UnlockableItemSate.Unlocked, true);
			}
			if (this.CustomSound)
			{
				this.CustomSound.Play();
			}
			if (e_UnlockableItemSate == E_UnlockableItemSate.Unlocked)
			{
				this.m_oLastValidKartCustom = (KartCustom)oData;
			}
			break;
		case 4:
			e_UnlockableItemSate = instance.GetAdvantageState(((AdvantageData)oData).AdvantageType);
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewLocked)
			{
				e_UnlockableItemSate = E_UnlockableItemSate.Locked;
				instance.SetAdvantageState(((AdvantageData)oData).AdvantageType, E_UnlockableItemSate.Locked, true);
			}
			if (e_UnlockableItemSate == E_UnlockableItemSate.NewUnlocked)
			{
				e_UnlockableItemSate = E_UnlockableItemSate.Unlocked;
				instance.SetAdvantageState(((AdvantageData)oData).AdvantageType, E_UnlockableItemSate.Unlocked, true);
			}
			if (this.AdvantageSound)
			{
				this.AdvantageSound.Play();
			}
			break;
		case 5:
			e_UnlockableItemSate = E_UnlockableItemSate.Locked;
			if (this.CoinsSound)
			{
				this.CoinsSound.Play();
			}
			break;
		}
		this.RefreshItem((IconCarac)oData, e_UnlockableItemSate);
		this.UpdatePreviewKart();
		if (this.m_iCurrentTab == 5)
		{
			this.UpdateInAppPanel((IconCarac)oData);
		}
		else
		{
			this.UpdateTextPanel((IconCarac)oData, e_UnlockableItemSate);
		}
	}

	// Token: 0x06000BA9 RID: 2985 RVA: 0x0004FB8C File Offset: 0x0004DD8C
	private void UpdatePanel(Transform oBtn)
	{
		this.m_oGrid.gameObject.SendMessage("Reposition");
		if (!oBtn)
		{
			return;
		}
		UIDraggablePanel component = this.m_oScrollPanel.GetComponent<UIDraggablePanel>();
		if (component)
		{
			UIPanel component2 = component.GetComponent<UIPanel>();
			Bounds bounds = NGUIMath.CalculateRelativeWidgetBounds(component.transform, oBtn);
			Vector3 relative = new Vector3(component2.clipRange.x - (bounds.max.x + bounds.min.x) * 0.5f, 0f, 0f);
			SpringPanel component3 = component2.gameObject.GetComponent<SpringPanel>();
			if (component3)
			{
				component3.enabled = false;
			}
			component.MoveRelative(relative);
		}
	}

	// Token: 0x06000BAA RID: 2986 RVA: 0x0004FC58 File Offset: 0x0004DE58
	private void UpdateTextPanel(IconCarac oCarac, E_UnlockableItemSate eState)
	{
		base.BroadcastMessage("OnUpdatePanel", null, SendMessageOptions.DontRequireReceiver);
		if (!oCarac || !this.m_oItemTitle || !this.m_oItemDescription)
		{
			return;
		}
		this.m_oItemTitle.text = Localization.instance.Get(oCarac.m_TitleTextId);
		if (this.m_oItemTitle.text.Length == 0)
		{
			this.m_oItemTitle.text = oCarac.name;
		}
		this.m_oItemDescription.text = Localization.instance.Get(oCarac.m_InfoTextId);
		if (!this.m_oBuyItemButton)
		{
			return;
		}
		if (eState == E_UnlockableItemSate.Locked || eState == E_UnlockableItemSate.NewLocked)
		{
			this.m_oBuyItemButton.SetActive(true);
		}
		else
		{
			this.m_oBuyItemButton.SetActive(false);
		}
		this.m_pIconSelected = oCarac;
	}

	// Token: 0x06000BAB RID: 2987 RVA: 0x0004FD40 File Offset: 0x0004DF40
	private void UpdateInAppPanel(IconCarac oCarac)
	{
		base.BroadcastMessage("OnUpdatePanel", null, SendMessageOptions.DontRequireReceiver);
		if (!oCarac || !this.m_oItemTitle || !this.m_oItemDescription || !this.m_pEntryPoint)
		{
			return;
		}
		InAppProductData inAppData = this.m_pEntryPoint.GetInAppData(((InAppCarac)oCarac).ProdutId);
		if (inAppData != null)
		{
			this.m_oInAppTitle.text = Localization.instance.Get(oCarac.m_TitleTextId);
			this.m_oInAppDescription.text = string.Format("{0:# ### ### ###}", ((InAppCarac)oCarac).CoinsEarn);
			this.m_oInAppPrice.text = inAppData.Price;
			this.m_oBuyItemButton.SetActive(false);
			this.m_pIconSelected = oCarac;
		}
	}

	// Token: 0x06000BAC RID: 2988 RVA: 0x0004FE18 File Offset: 0x0004E018
	private bool IsNextButtonValid(out string sItemTypeInvalidTextId)
	{
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		sItemTypeInvalidTextId = string.Empty;
		E_UnlockableItemSate e_UnlockableItemSate = instance.GetCharacterState(Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter);
		if (e_UnlockableItemSate != E_UnlockableItemSate.NewUnlocked && e_UnlockableItemSate != E_UnlockableItemSate.Unlocked)
		{
			return false;
		}
		sItemTypeInvalidTextId = "MENU_SHOP_OBJECT_KART";
		e_UnlockableItemSate = instance.GetKartState(Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart);
		if (e_UnlockableItemSate != E_UnlockableItemSate.NewUnlocked && e_UnlockableItemSate != E_UnlockableItemSate.Unlocked)
		{
			return false;
		}
		sItemTypeInvalidTextId = "MENU_SHOP_OBJECT_HAT";
		e_UnlockableItemSate = instance.GetHatState(Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat.name);
		if (e_UnlockableItemSate != E_UnlockableItemSate.NewUnlocked && e_UnlockableItemSate != E_UnlockableItemSate.Unlocked)
		{
			return false;
		}
		sItemTypeInvalidTextId = "MENU_SHOP_OBJECT_CUSTO";
		e_UnlockableItemSate = instance.GetCustomState(Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom.name);
		return e_UnlockableItemSate == E_UnlockableItemSate.NewUnlocked || e_UnlockableItemSate == E_UnlockableItemSate.Unlocked;
	}

	// Token: 0x06000BAD RID: 2989 RVA: 0x0004FEEC File Offset: 0x0004E0EC
	private void UpdatePreviewKart()
	{
		if (!this.m_oKartPreview)
		{
			return;
		}
		KartPreviewBuilder component = this.m_oKartPreview.GetComponent<KartPreviewBuilder>();
		component.Build(Singleton<GameConfigurator>.Instance.PlayerConfig.m_eCharacter, Singleton<GameConfigurator>.Instance.PlayerConfig.m_eKart, Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom.name, Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat.name);
	}

	// Token: 0x06000BAE RID: 2990 RVA: 0x0004FF64 File Offset: 0x0004E164
	public void OnPurchase()
	{
		int num = 0;
		switch (this.m_iCurrentTab)
		{
		case 0:
			return;
		case 1:
			num = Singleton<GameConfigurator>.Instance.PriceConfig.GetKartPrice();
			break;
		case 2:
			num = Singleton<GameConfigurator>.Instance.PriceConfig.GetHatPrice(((BonusCustom)this.m_pIconSelected).Rarity, ((BonusCustom)this.m_pIconSelected).Owner == ECharacter.NONE);
			break;
		case 3:
			num = Singleton<GameConfigurator>.Instance.PriceConfig.GetCustoPrice(((KartCustom)this.m_pIconSelected).Rarity);
			break;
		case 4:
			num = ((AdvantageData)this.m_pIconSelected).Price;
			break;
		case 5:
			this.OnPopupShow();
			Singleton<InAppManager>.Instance.PurchaseProduct(((InAppCarac)this.m_pIconSelected).ProdutId);
			return;
		}
		this.m_pMenuEntryPoint.ShowPurchasePopup(string.Format(Localization.instance.Get("MENU_POPUP_BUY_ITEM_CONFIRMATION"), Localization.instance.Get(this.m_pIconSelected.m_TitleTextId), num), num, new MenuEntryPoint.Callback(this.PurchaseItem), new MenuEntryPoint.Callback(this.OpenBuyCoinsTab), true);
	}

	// Token: 0x06000BAF RID: 2991 RVA: 0x000500A0 File Offset: 0x0004E2A0
	public void PurchaseItem(object oParam)
	{
		switch (this.m_iCurrentTab)
		{
		case 0:
			return;
		case 1:
			Singleton<GameSaveManager>.Instance.SetKartState(((KartCarac)this.m_pIconSelected).Owner, E_UnlockableItemSate.Unlocked, true);
			this.m_oKartList.Sort(new Comparison<KartCarac>(KartCarac.Compare));
			break;
		case 2:
			Singleton<GameSaveManager>.Instance.SetHatState(((BonusCustom)this.m_pIconSelected).name, E_UnlockableItemSate.Unlocked, true);
			this.m_oHatList.Sort(new Comparison<BonusCustom>(BonusCustom.Compare));
			break;
		case 3:
			Singleton<GameSaveManager>.Instance.SetCustomState(((KartCustom)this.m_pIconSelected).name, E_UnlockableItemSate.Unlocked, true);
			this.m_oKartCustomList.Sort(new Comparison<KartCustom>(KartCustom.Compare));
			break;
		case 4:
			Singleton<GameSaveManager>.Instance.EarnAdvantage(((AdvantageData)this.m_pIconSelected).AdvantageType, 1, true);
			this.UpdateTextPanel(this.m_pIconSelected, E_UnlockableItemSate.Locked);
			return;
		case 5:
			return;
		}
		int iCurrentTab = this.m_iCurrentTab;
		this.m_iCurrentTab = -1;
		this.OnSelectTab(iCurrentTab);
	}

	// Token: 0x06000BB0 RID: 2992 RVA: 0x000501C0 File Offset: 0x0004E3C0
	private bool SpendCoins(int iPrice)
	{
		bool flag = Singleton<GameSaveManager>.Instance.GetCoins() >= iPrice;
		if (flag)
		{
			Singleton<GameSaveManager>.Instance.SpendCoins(iPrice, true);
		}
		return flag;
	}

	// Token: 0x06000BB1 RID: 2993 RVA: 0x000501FC File Offset: 0x0004E3FC
	private void PurchaseSucceed(string pProductId)
	{
		this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG, "MENU_POPUP_BUY_OK", true);
		foreach (InAppCarac inAppCarac in this.m_oCoinsCaracList)
		{
			if (inAppCarac.ProdutId == pProductId)
			{
				Singleton<GameSaveManager>.Instance.EarnCoins(inAppCarac.CoinsEarn, false, true);
				break;
			}
		}
	}

	// Token: 0x06000BB2 RID: 2994 RVA: 0x0000A169 File Offset: 0x00008369
	private void PurchaseFailed(string pError)
	{
		this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG, "MENU_POPUP_BUY_FAILED", true);
	}

	// Token: 0x06000BB3 RID: 2995 RVA: 0x0000A17D File Offset: 0x0000837D
	private void PurchaseCancelled(string pError)
	{
		this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG, "MENU_POPUP_BUY_CANCELLED", true);
	}

	// Token: 0x06000BB4 RID: 2996 RVA: 0x0005028C File Offset: 0x0004E48C
	private void RefreshItem(UnityEngine.Object oItemData, E_UnlockableItemSate eState)
	{
		foreach (BtnItem btnItem in this.m_oGrid.GetComponentsInChildren<BtnItem>())
		{
			if (btnItem.IsDataEqual(oItemData))
			{
				btnItem.RefreshState(eState);
				break;
			}
		}
	}

	// Token: 0x06000BB5 RID: 2997 RVA: 0x000502D8 File Offset: 0x0004E4D8
	private void OpenBuyCoinsTab(object oActiveNextButton)
	{
		bool active = (bool)oActiveNextButton;
		if (this.m_oButtonCoins && this.m_oButtonCoins.activeSelf)
		{
			this.m_oButtonCoins.SendMessage("OnClick");
		}
		else
		{
			this.ButtonPersonage.SendMessage("OnClick");
		}
		if (this.m_oButtonNext)
		{
			this.m_oButtonNext.SetActive(active);
		}
	}

	// Token: 0x06000BB6 RID: 2998 RVA: 0x0000A191 File Offset: 0x00008391
	public MenuSelectKart.EAdvantageRestrictions GetAdvantageRestrictions()
	{
		return this.m_eAdvantageRestrictions;
	}

	// Token: 0x06000BB7 RID: 2999 RVA: 0x0000A199 File Offset: 0x00008399
	public void SetPanelTextAlpha(float fAlpha)
	{
		if (this.m_oPanelText)
		{
			this.m_oPanelText.alpha = Tricks.ComputeInertia(this.m_oPanelText.alpha, fAlpha, 0.15f, Time.deltaTime);
		}
	}

	// Token: 0x06000BB8 RID: 3000 RVA: 0x0000A1D1 File Offset: 0x000083D1
	public void OnDisconnectedFromServer()
	{
		if (Network.isClient)
		{
			this.RevertToLastValidState();
			this.ActSwapMenu(EMenus.MENU_MULTI_JOIN);
		}
	}

	// Token: 0x06000BB9 RID: 3001 RVA: 0x00050350 File Offset: 0x0004E550
	public void SortLists()
	{
		this.m_oCharacterList.Sort(new Comparison<CharacterCarac>(CharacterCarac.Compare));
		this.m_oHatList.Sort(new Comparison<BonusCustom>(BonusCustom.Compare));
		this.m_oKartList.Sort(new Comparison<KartCarac>(KartCarac.Compare));
		this.m_oKartCustomList.Sort(new Comparison<KartCustom>(KartCustom.Compare));
		this.m_oAdvantagesList.Sort(new Comparison<AdvantageData>(AdvantageData.Compare));
	}

	// Token: 0x04000B50 RID: 2896
	public GameObject m_oScrollPanel;

	// Token: 0x04000B51 RID: 2897
	public GameObject m_oButtonItemTemplate;

	// Token: 0x04000B52 RID: 2898
	public GameObject m_oKartPreview;

	// Token: 0x04000B53 RID: 2899
	public UILabel m_oItemTitle;

	// Token: 0x04000B54 RID: 2900
	public UILabel m_oItemDescription;

	// Token: 0x04000B55 RID: 2901
	public GameObject m_oBuyItemButton;

	// Token: 0x04000B56 RID: 2902
	private int m_iCurrentTab;

	// Token: 0x04000B57 RID: 2903
	private Transform m_oGrid;

	// Token: 0x04000B58 RID: 2904
	private bool m_bNeedSelectTabAtUpdate;

	// Token: 0x04000B59 RID: 2905
	private bool m_bNeedGoBuyCoins;

	// Token: 0x04000B5A RID: 2906
	private bool m_bBackToPreviousState;

	// Token: 0x04000B5B RID: 2907
	private IconCarac m_pIconSelected;

	// Token: 0x04000B5C RID: 2908
	private NetworkMgr m_oNetworkMgr;

	// Token: 0x04000B5D RID: 2909
	private bool goNet;

	// Token: 0x04000B5E RID: 2910
	private bool wasServer;

	// Token: 0x04000B5F RID: 2911
	private Transform m_oBtnItemSelected;

	// Token: 0x04000B60 RID: 2912
	public GameObject m_oPanelAdvantages;

	// Token: 0x04000B61 RID: 2913
	public GameObject m_oPanelDataKart;

	// Token: 0x04000B62 RID: 2914
	public GameObject m_oPanelDataIcon;

	// Token: 0x04000B63 RID: 2915
	public GameObject m_oButtonCoins;

	// Token: 0x04000B64 RID: 2916
	public GameObject m_oButtonNext;

	// Token: 0x04000B65 RID: 2917
	public GameObject m_oButtonAdvantages;

	// Token: 0x04000B66 RID: 2918
	public GameObject m_oButtonPersonage;

	// Token: 0x04000B67 RID: 2919
	public GameObject NetworkReady;

	// Token: 0x04000B68 RID: 2920
	public UIPanel m_oPanelText;

	// Token: 0x04000B69 RID: 2921
	public GameObject m_oPanelInApp;

	// Token: 0x04000B6A RID: 2922
	public UILabel m_oInAppTitle;

	// Token: 0x04000B6B RID: 2923
	public UILabel m_oInAppDescription;

	// Token: 0x04000B6C RID: 2924
	public UILabel m_oInAppPrice;

	// Token: 0x04000B6D RID: 2925
	public UIAtlas m_oAdvAtlas;

	// Token: 0x04000B6E RID: 2926
	private ECharacter m_eLastValidCharacter;

	// Token: 0x04000B6F RID: 2927
	private ECharacter m_eLastValidKart;

	// Token: 0x04000B70 RID: 2928
	private BonusCustom m_oLastValidHat;

	// Token: 0x04000B71 RID: 2929
	private KartCustom m_oLastValidKartCustom;

	// Token: 0x04000B72 RID: 2930
	public int m_iTimeLimit = 25;

	// Token: 0x04000B73 RID: 2931
	public int m_iStartDisplaying = 10;

	// Token: 0x04000B74 RID: 2932
	public UILabel m_oTimerLabel;

	// Token: 0x04000B75 RID: 2933
	public float m_elapsedTime;

	// Token: 0x04000B76 RID: 2934
	private bool m_bLimitTime = true;

	// Token: 0x04000B77 RID: 2935
	private float m_fElapsedTime;

	// Token: 0x04000B78 RID: 2936
	private bool m_bTrackInfoLoadingDone;

	// Token: 0x04000B79 RID: 2937
	public AudioSource CustomSound;

	// Token: 0x04000B7A RID: 2938
	public AudioSource HatSound;

	// Token: 0x04000B7B RID: 2939
	public AudioSource AdvantageSound;

	// Token: 0x04000B7C RID: 2940
	public AudioSource CoinsSound;

	// Token: 0x04000B7D RID: 2941
	public UILabel TrackName;

	// Token: 0x04000B7E RID: 2942
	public UITexturePattern ChampionshipIcon;

	// Token: 0x04000B7F RID: 2943
	public UITexturePattern GameModeIcon;

	// Token: 0x04000B80 RID: 2944
	public UITexturePattern DifficultyIcon;

	// Token: 0x04000B81 RID: 2945
	public List<UITexturePattern> ClientState;

	// Token: 0x04000B82 RID: 2946
	public GameObject ClientStateGO;

	// Token: 0x04000B83 RID: 2947
	public GameObject AnchorTopLeft;

	// Token: 0x04000B84 RID: 2948
	public Camera m_oCameraShop;

	// Token: 0x04000B85 RID: 2949
	public bool ShowShop;

	// Token: 0x04000B86 RID: 2950
	private EntryPoint m_pEntryPoint;

	// Token: 0x04000B87 RID: 2951
	private MenuSelectKart.EAdvantageRestrictions m_eAdvantageRestrictions;

	// Token: 0x04000B88 RID: 2952
	private List<CharacterCarac> m_oCharacterList = new List<CharacterCarac>();

	// Token: 0x04000B89 RID: 2953
	private List<BonusCustom> m_oHatList = new List<BonusCustom>();

	// Token: 0x04000B8A RID: 2954
	private List<KartCarac> m_oKartList = new List<KartCarac>();

	// Token: 0x04000B8B RID: 2955
	private List<KartCustom> m_oKartCustomList = new List<KartCustom>();

	// Token: 0x04000B8C RID: 2956
	private List<InAppCarac> m_oCoinsCaracList = new List<InAppCarac>();

	// Token: 0x04000B8D RID: 2957
	private List<AdvantageData> m_oAdvantagesList = new List<AdvantageData>();

	// Token: 0x020001B3 RID: 435
	public enum EAdvantageRestrictions
	{
		// Token: 0x04000B8F RID: 2959
		NO_RESTRICTION,
		// Token: 0x04000B90 RID: 2960
		SINGLE_RESTRICTION,
		// Token: 0x04000B91 RID: 2961
		CHAMPIONSHIP_RESTRICTION,
		// Token: 0x04000B92 RID: 2962
		TIMETRIAL_RESTRICTION,
		// Token: 0x04000B93 RID: 2963
		MULTI_SINGLE_RESTRICTION,
		// Token: 0x04000B94 RID: 2964
		MULTI_CHAMP_RESTRICTION
	}
}

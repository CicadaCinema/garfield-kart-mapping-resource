﻿using System;
using UnityEngine;

// Token: 0x02000006 RID: 6
[AddComponentMenu("NGUI/Interaction/Button Color")]
public class UIButtonColor : MonoBehaviour
{
	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000012 RID: 18 RVA: 0x00002218 File Offset: 0x00000418
	// (set) Token: 0x06000013 RID: 19 RVA: 0x00002231 File Offset: 0x00000431
	public Color defaultColor
	{
		get
		{
			if (!this.mStarted)
			{
				this.Init();
			}
			return this.mColor;
		}
		set
		{
			this.mColor = value;
		}
	}

	// Token: 0x06000014 RID: 20 RVA: 0x0000223A File Offset: 0x0000043A
	private void Start()
	{
		if (!this.mStarted)
		{
			this.Init();
			this.mStarted = true;
		}
	}

	// Token: 0x06000015 RID: 21 RVA: 0x00002254 File Offset: 0x00000454
	protected virtual void OnEnable()
	{
		if (this.mStarted && this.mHighlighted)
		{
			this.OnHover(UICamera.IsHighlighted(base.gameObject));
		}
	}

	// Token: 0x06000016 RID: 22 RVA: 0x0000D564 File Offset: 0x0000B764
	private void OnDisable()
	{
		if (this.mStarted && this.tweenTarget != null)
		{
			TweenColor component = this.tweenTarget.GetComponent<TweenColor>();
			if (component != null)
			{
				component.color = this.mColor;
				component.enabled = false;
			}
		}
	}

	// Token: 0x06000017 RID: 23 RVA: 0x0000D5B8 File Offset: 0x0000B7B8
	protected void Init()
	{
		if (this.tweenTarget == null)
		{
			this.tweenTarget = base.gameObject;
		}
		UIWidget component = this.tweenTarget.GetComponent<UIWidget>();
		if (component != null)
		{
			this.mColor = component.color;
		}
		else
		{
			Renderer renderer = this.tweenTarget.renderer;
			if (renderer != null)
			{
				this.mColor = renderer.material.color;
			}
			else
			{
				Light light = this.tweenTarget.light;
				if (light != null)
				{
					this.mColor = light.color;
				}
				else
				{
					Debug.LogWarning(NGUITools.GetHierarchy(base.gameObject) + " has nothing for UIButtonColor to color", this);
					base.enabled = false;
				}
			}
		}
		this.OnEnable();
	}

	// Token: 0x06000018 RID: 24 RVA: 0x0000D68C File Offset: 0x0000B88C
	public virtual void OnPress(bool isPressed)
	{
		if (base.enabled)
		{
			if (!this.mStarted)
			{
				this.Start();
			}
			TweenColor.Begin(this.tweenTarget, this.duration, (!isPressed) ? ((!UICamera.IsHighlighted(base.gameObject)) ? this.mColor : this.hover) : this.pressed);
		}
	}

	// Token: 0x06000019 RID: 25 RVA: 0x0000D6FC File Offset: 0x0000B8FC
	public virtual void OnHover(bool isOver)
	{
		if (base.enabled)
		{
			if (!this.mStarted)
			{
				this.Start();
			}
			TweenColor.Begin(this.tweenTarget, this.duration, (!isOver) ? this.mColor : this.hover);
			this.mHighlighted = isOver;
		}
	}

	// Token: 0x04000006 RID: 6
	public GameObject tweenTarget;

	// Token: 0x04000007 RID: 7
	public Color hover = new Color(0.6f, 1f, 0.2f, 1f);

	// Token: 0x04000008 RID: 8
	public Color pressed = Color.grey;

	// Token: 0x04000009 RID: 9
	public float duration = 0.2f;

	// Token: 0x0400000A RID: 10
	protected Color mColor;

	// Token: 0x0400000B RID: 11
	protected bool mStarted;

	// Token: 0x0400000C RID: 12
	protected bool mHighlighted;
}

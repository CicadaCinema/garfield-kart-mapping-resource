﻿using System;
using UnityEngine;

// Token: 0x02000047 RID: 71
[AddComponentMenu("NGUI/Internal/Spring Panel")]
[RequireComponent(typeof(UIPanel))]
public class SpringPanel : IgnoreTimeScale
{
	// Token: 0x060001D4 RID: 468 RVA: 0x000035EC File Offset: 0x000017EC
	private void Start()
	{
		this.mPanel = base.GetComponent<UIPanel>();
		this.mDrag = base.GetComponent<UIDraggablePanel>();
		this.mTrans = base.transform;
	}

	// Token: 0x060001D5 RID: 469 RVA: 0x000168E8 File Offset: 0x00014AE8
	private void Update()
	{
		float deltaTime = base.UpdateRealTimeDelta();
		if (this.mThreshold == 0f)
		{
			this.mThreshold = (this.target - this.mTrans.localPosition).magnitude * 0.005f;
		}
		bool flag = false;
		Vector3 localPosition = this.mTrans.localPosition;
		Vector3 vector = NGUIMath.SpringLerp(this.mTrans.localPosition, this.target, this.strength, deltaTime);
		if (this.mThreshold >= Vector3.Magnitude(vector - this.target))
		{
			vector = this.target;
			base.enabled = false;
			flag = true;
		}
		this.mTrans.localPosition = vector;
		Vector3 vector2 = vector - localPosition;
		Vector4 clipRange = this.mPanel.clipRange;
		clipRange.x -= vector2.x;
		clipRange.y -= vector2.y;
		this.mPanel.clipRange = clipRange;
		if (this.mDrag != null)
		{
			this.mDrag.UpdateScrollbars(false);
		}
		if (flag && this.onFinished != null)
		{
			this.onFinished();
		}
	}

	// Token: 0x060001D6 RID: 470 RVA: 0x00016A24 File Offset: 0x00014C24
	public static SpringPanel Begin(GameObject go, Vector3 pos, float strength)
	{
		SpringPanel springPanel = go.GetComponent<SpringPanel>();
		if (springPanel == null)
		{
			springPanel = go.AddComponent<SpringPanel>();
		}
		springPanel.target = pos;
		springPanel.strength = strength;
		springPanel.onFinished = null;
		if (!springPanel.enabled)
		{
			springPanel.mThreshold = 0f;
			springPanel.enabled = true;
		}
		return springPanel;
	}

	// Token: 0x0400018A RID: 394
	public Vector3 target = Vector3.zero;

	// Token: 0x0400018B RID: 395
	public float strength = 10f;

	// Token: 0x0400018C RID: 396
	public SpringPanel.OnFinished onFinished;

	// Token: 0x0400018D RID: 397
	private UIPanel mPanel;

	// Token: 0x0400018E RID: 398
	private Transform mTrans;

	// Token: 0x0400018F RID: 399
	private float mThreshold;

	// Token: 0x04000190 RID: 400
	private UIDraggablePanel mDrag;

	// Token: 0x02000048 RID: 72
	// (Invoke) Token: 0x060001D8 RID: 472
	public delegate void OnFinished();
}

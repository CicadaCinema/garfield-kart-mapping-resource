﻿using System;

// Token: 0x020001D3 RID: 467
public enum Quality
{
	// Token: 0x04000C38 RID: 3128
	Unknow,
	// Token: 0x04000C39 RID: 3129
	Low,
	// Token: 0x04000C3A RID: 3130
	Medium,
	// Token: 0x04000C3B RID: 3131
	High,
	// Token: 0x04000C3C RID: 3132
	Highest
}

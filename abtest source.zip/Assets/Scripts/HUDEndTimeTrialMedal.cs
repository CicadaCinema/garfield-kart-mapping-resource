﻿using System;
using UnityEngine;

// Token: 0x0200010B RID: 267
public class HUDEndTimeTrialMedal : HUDEndTimeTrial
{
	// Token: 0x0600073B RID: 1851 RVA: 0x00036688 File Offset: 0x00034888
	public override void Awake()
	{
		base.Awake();
		for (int i = 0; i < this.GetNbPlayers(); i++)
		{
			string text = base.gameObject.name + "/Panel/Anchor_Center/Panel" + (i + 1).ToString() + "Place";
		}
		string str = base.gameObject.name + "/Panel/Anchor_Center/";
		GameObject gameObject = GameObject.Find(str + "BestTime");
		this.m_LapTime = gameObject.GetComponent<UILabel>();
		this.m_LapRecord = GameObject.Find(str + "BestTimeRecordText");
	}

	// Token: 0x0600073C RID: 1852 RVA: 0x00036724 File Offset: 0x00034924
	public override void FillStats(PlayerData[] pPlayerData)
	{
		string startScene = Singleton<GameConfigurator>.Instance.StartScene;
		Kart humanKart = Singleton<GameManager>.Instance.GameMode.GetHumanKart();
		RcVehicleRaceStats raceStats = humanKart.RaceStats;
		GameObject gameObject = GameObject.Find("Race");
		TimeTrialConfig component = gameObject.GetComponent<TimeTrialConfig>();
		E_TimeTrialMedal medal = Singleton<GameSaveManager>.Instance.GetMedal(startScene, true);
		E_TimeTrialMedal e_TimeTrialMedal = medal;
		if (e_TimeTrialMedal != E_TimeTrialMedal.Platinium)
		{
			e_TimeTrialMedal++;
		}
		int num = 1;
		if (!TimeTrialGameMode.BeatTime(e_TimeTrialMedal))
		{
			this.m_iIndexToFillPlayerData = 1;
			num = 0;
		}
		base.FillStats(pPlayerData);
		if (this.GuiPerso[this.m_iIndexToFillPlayerData] != null)
		{
			this.GuiPerso[this.m_iIndexToFillPlayerData].spriteName = "GUI_HUD_Select";
		}
		int num2 = 0;
		Singleton<GameSaveManager>.Instance.GetTimeTrialRecord(startScene, ref num2);
		if (raceStats.GetRaceTime() < num2 || num2 < 0)
		{
			this.RecordGO[this.m_iIndexToFillPlayerData].gameObject.SetActive(true);
		}
		else
		{
			this.RecordGO[this.m_iIndexToFillPlayerData].gameObject.SetActive(false);
		}
		this.RecordGO[num].gameObject.SetActive(false);
		foreach (GameObject gameObject2 in this.m_Stars[num])
		{
			gameObject2.SetActive(false);
		}
		switch (medal)
		{
		case E_TimeTrialMedal.None:
			this.RaceTime[num].text = TimeSpan.FromMilliseconds((double)component.Bronze).FormatRaceTime();
			break;
		case E_TimeTrialMedal.Bronze:
			this.RaceTime[num].text = TimeSpan.FromMilliseconds((double)component.Silver).FormatRaceTime();
			break;
		case E_TimeTrialMedal.Silver:
			this.RaceTime[num].text = TimeSpan.FromMilliseconds((double)component.Gold).FormatRaceTime();
			break;
		case E_TimeTrialMedal.Gold:
			this.RaceTime[num].text = TimeSpan.FromMilliseconds((double)component.Platinium).FormatRaceTime();
			break;
		case E_TimeTrialMedal.Platinium:
		{
			int num3 = 0;
			string pseudo = Singleton<GameSaveManager>.Instance.GetPseudo();
			ECharacter echaracter = ECharacter.NONE;
			ECharacter echaracter2 = ECharacter.NONE;
			string empty = string.Empty;
			string empty2 = string.Empty;
			Singleton<GameSaveManager>.Instance.GetTimeTrial(startScene, ref num3, ref echaracter, ref echaracter2, ref empty, ref empty2);
			this.CharacterName[num].text = pseudo;
			this.RaceTime[num].text = TimeSpan.FromMilliseconds((double)num3).FormatRaceTime();
			foreach (CharacterCarac characterCarac in this.m_oCharacterList)
			{
				if (characterCarac.Owner == echaracter)
				{
					this.m_Character[num].spriteName = characterCarac.spriteName;
					break;
				}
			}
			foreach (KartCarac kartCarac in this.m_oKartList)
			{
				if (kartCarac.Owner == echaracter2)
				{
					this.m_Kart[num].spriteName = kartCarac.spriteName;
					break;
				}
			}
			if (empty.Contains("_Def"))
			{
				this.m_Custom[num].SetActive(false);
			}
			else
			{
				this.m_Custom[num].SetActive(true);
				foreach (KartCustom kartCustom in this.m_oKartCustomList)
				{
					if (kartCustom.name == empty)
					{
						this.m_CustomSprite[num].spriteName = kartCustom.spriteName;
						this.m_CustomRarity[num].ChangeTexture((int)kartCustom.Rarity);
						break;
					}
				}
			}
			break;
		}
		}
		if (medal != E_TimeTrialMedal.Platinium)
		{
			this.m_Custom[num].SetActive(false);
			this.m_CharacterGO[num].SetActive(false);
			this.m_KartGO[num].SetActive(false);
			this.UFOIcons[num].SetActive(true);
			this.AlienIcons[num].SetActive(true);
			this.CharacterName[num].text = Localization.instance.Get("MENU_TUTO_UFO_TITLE");
		}
		else
		{
			this.UFOIcons[num].SetActive(false);
			this.AlienIcons[num].SetActive(false);
		}
	}

	// Token: 0x0600073D RID: 1853 RVA: 0x00004F14 File Offset: 0x00003114
	public override int GetNbPlayers()
	{
		return 2;
	}

	// Token: 0x0600073E RID: 1854 RVA: 0x00036C38 File Offset: 0x00034E38
	public override void ShowLapTime(RcVehicleRaceStats pStats)
	{
		int num = 0;
		string startScene = Singleton<GameConfigurator>.Instance.StartScene;
		Singleton<GameSaveManager>.Instance.GetTimeTrialBestTime(startScene, ref num);
		if (pStats.GetBestLapTime() < num || num < 0)
		{
			this.m_LapTime.text = TimeSpan.FromMilliseconds((double)pStats.GetBestLapTime()).FormatRaceTime();
			this.m_LapRecord.SetActive(true);
		}
		else
		{
			this.m_LapTime.text = TimeSpan.FromMilliseconds((double)num).FormatRaceTime();
			this.m_LapRecord.SetActive(false);
		}
	}

	// Token: 0x04000721 RID: 1825
	public GameObject[] AlienIcons;

	// Token: 0x04000722 RID: 1826
	public GameObject[] UFOIcons;

	// Token: 0x04000723 RID: 1827
	private UILabel m_LapTime;

	// Token: 0x04000724 RID: 1828
	private GameObject m_LapRecord;
}

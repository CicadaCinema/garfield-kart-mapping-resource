﻿using System;

// Token: 0x020001C1 RID: 449
public class PopupDialog : AbstractPopup
{
}

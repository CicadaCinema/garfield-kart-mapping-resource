﻿using System;
using UnityEngine;

// Token: 0x0200008E RID: 142
[ExecuteInEditMode]
public class UITiledSprite : UISlicedSprite
{
	// Token: 0x170000C7 RID: 199
	// (get) Token: 0x060003ED RID: 1005 RVA: 0x00004F14 File Offset: 0x00003114
	public override UISprite.Type type
	{
		get
		{
			return UISprite.Type.Tiled;
		}
	}
}

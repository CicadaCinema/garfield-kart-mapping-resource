﻿using System;

// Token: 0x02000139 RID: 313
public enum DrivingCaracteristics
{
	// Token: 0x040008E5 RID: 2277
	SPEED,
	// Token: 0x040008E6 RID: 2278
	ACCELERATION,
	// Token: 0x040008E7 RID: 2279
	MANIABILITY
}

﻿using System;
using UnityEngine;

// Token: 0x0200013D RID: 317
public class IconCarac : MonoBehaviour
{
	// Token: 0x17000143 RID: 323
	// (get) Token: 0x060008BD RID: 2237 RVA: 0x00008246 File Offset: 0x00006446
	// (set) Token: 0x060008BE RID: 2238 RVA: 0x0003F3F4 File Offset: 0x0003D5F4
	public string spriteName
	{
		get
		{
			return this.m_sSpriteName;
		}
		set
		{
			if (string.IsNullOrEmpty(value))
			{
				if (string.IsNullOrEmpty(this.m_sSpriteName))
				{
					return;
				}
				this.m_sSpriteName = string.Empty;
			}
			else if (this.m_sSpriteName != value)
			{
				this.m_sSpriteName = value;
			}
		}
	}

	// Token: 0x060008BF RID: 2239 RVA: 0x0003F448 File Offset: 0x0003D648
	public static int CompareNameDefault(IconCarac oItem1, IconCarac oItem2)
	{
		bool flag = oItem2.name.Contains("_Def");
		if (oItem1.name.Contains("_Def"))
		{
			if (flag)
			{
				return IconCarac.CompareName(oItem1, oItem2);
			}
			return -1;
		}
		else
		{
			if (flag)
			{
				return 1;
			}
			return 0;
		}
	}

	// Token: 0x060008C0 RID: 2240 RVA: 0x0000824E File Offset: 0x0000644E
	public static int CompareName(IconCarac oItem1, IconCarac oItem2)
	{
		return oItem1.name.CompareTo(oItem2.name);
	}

	// Token: 0x060008C1 RID: 2241 RVA: 0x0003F494 File Offset: 0x0003D694
	public static E_UnlockableItemSate SuppressNewState(E_UnlockableItemSate eState)
	{
		switch (eState)
		{
		case E_UnlockableItemSate.NewLocked:
			return E_UnlockableItemSate.Locked;
		case E_UnlockableItemSate.NewUnlocked:
			return E_UnlockableItemSate.Unlocked;
		}
		return eState;
	}

	// Token: 0x040008F3 RID: 2291
	public string m_sSpriteName;

	// Token: 0x040008F4 RID: 2292
	public string m_TitleTextId;

	// Token: 0x040008F5 RID: 2293
	public string m_InfoTextId;
}

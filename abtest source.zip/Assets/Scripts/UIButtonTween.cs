﻿using System;
using AnimationOrTween;
using UnityEngine;

// Token: 0x02000011 RID: 17
[AddComponentMenu("NGUI/Interaction/Button Tween")]
public class UIButtonTween : MonoBehaviour
{
	// Token: 0x06000049 RID: 73 RVA: 0x0000257B File Offset: 0x0000077B
	private void Start()
	{
		this.mStarted = true;
		if (this.tweenTarget == null)
		{
			this.tweenTarget = base.gameObject;
		}
	}

	// Token: 0x0600004A RID: 74 RVA: 0x000025A1 File Offset: 0x000007A1
	private void OnEnable()
	{
		if (this.mStarted && this.mHighlighted)
		{
			this.OnHover(UICamera.IsHighlighted(base.gameObject));
		}
	}

	// Token: 0x0600004B RID: 75 RVA: 0x0000E2F8 File Offset: 0x0000C4F8
	private void OnHover(bool isOver)
	{
		if (base.enabled)
		{
			if (this.trigger == Trigger.OnHover || (this.trigger == Trigger.OnHoverTrue && isOver) || (this.trigger == Trigger.OnHoverFalse && !isOver))
			{
				this.Play(isOver);
			}
			this.mHighlighted = isOver;
		}
	}

	// Token: 0x0600004C RID: 76 RVA: 0x0000E350 File Offset: 0x0000C550
	private void OnPress(bool isPressed)
	{
		if (base.enabled && (this.trigger == Trigger.OnPress || (this.trigger == Trigger.OnPressTrue && isPressed) || (this.trigger == Trigger.OnPressFalse && !isPressed)))
		{
			this.Play(isPressed);
		}
	}

	// Token: 0x0600004D RID: 77 RVA: 0x000025CA File Offset: 0x000007CA
	private void OnClick()
	{
		if (base.enabled && this.trigger == Trigger.OnClick)
		{
			this.Play(true);
		}
	}

	// Token: 0x0600004E RID: 78 RVA: 0x000025E9 File Offset: 0x000007E9
	private void OnDoubleClick()
	{
		if (base.enabled && this.trigger == Trigger.OnDoubleClick)
		{
			this.Play(true);
		}
	}

	// Token: 0x0600004F RID: 79 RVA: 0x0000E3A0 File Offset: 0x0000C5A0
	private void OnSelect(bool isSelected)
	{
		if (base.enabled && (this.trigger == Trigger.OnSelect || (this.trigger == Trigger.OnSelectTrue && isSelected) || (this.trigger == Trigger.OnSelectFalse && !isSelected)))
		{
			this.Play(true);
		}
	}

	// Token: 0x06000050 RID: 80 RVA: 0x0000E3F4 File Offset: 0x0000C5F4
	private void OnActivate(bool isActive)
	{
		if (base.enabled && (this.trigger == Trigger.OnActivate || (this.trigger == Trigger.OnActivateTrue && isActive) || (this.trigger == Trigger.OnActivateFalse && !isActive)))
		{
			this.Play(isActive);
		}
	}

	// Token: 0x06000051 RID: 81 RVA: 0x0000E444 File Offset: 0x0000C644
	private void Update()
	{
		if (this.disableWhenFinished != DisableCondition.DoNotDisable && this.mTweens != null)
		{
			bool flag = true;
			bool flag2 = true;
			int i = 0;
			int num = this.mTweens.Length;
			while (i < num)
			{
				UITweener uitweener = this.mTweens[i];
				if (uitweener.tweenGroup == this.tweenGroup)
				{
					if (uitweener.enabled)
					{
						flag = false;
						break;
					}
					if (uitweener.direction != (Direction)this.disableWhenFinished)
					{
						flag2 = false;
					}
				}
				i++;
			}
			if (flag)
			{
				if (flag2)
				{
					NGUITools.SetActive(this.tweenTarget, false);
				}
				this.mTweens = null;
			}
		}
	}

	// Token: 0x06000052 RID: 82 RVA: 0x0000E4F0 File Offset: 0x0000C6F0
	public void Play(bool forward)
	{
		GameObject gameObject = (!(this.tweenTarget == null)) ? this.tweenTarget : base.gameObject;
		if (!NGUITools.GetActive(gameObject))
		{
			if (this.ifDisabledOnPlay != EnableCondition.EnableThenPlay)
			{
				return;
			}
			NGUITools.SetActive(gameObject, true);
		}
		this.mTweens = ((!this.includeChildren) ? gameObject.GetComponents<UITweener>() : gameObject.GetComponentsInChildren<UITweener>());
		if (this.mTweens.Length == 0)
		{
			if (this.disableWhenFinished != DisableCondition.DoNotDisable)
			{
				NGUITools.SetActive(this.tweenTarget, false);
			}
		}
		else
		{
			bool flag = false;
			if (this.playDirection == Direction.Reverse)
			{
				forward = !forward;
			}
			int i = 0;
			int num = this.mTweens.Length;
			while (i < num)
			{
				UITweener uitweener = this.mTweens[i];
				if (uitweener.tweenGroup == this.tweenGroup)
				{
					if (!flag && !NGUITools.GetActive(gameObject))
					{
						flag = true;
						NGUITools.SetActive(gameObject, true);
					}
					if (this.playDirection == Direction.Toggle)
					{
						uitweener.Toggle();
					}
					else
					{
						uitweener.Play(forward);
					}
					if (this.resetOnPlay)
					{
						uitweener.Reset();
					}
					uitweener.onFinished = this.onFinished;
					if (this.eventReceiver != null && !string.IsNullOrEmpty(this.callWhenFinished))
					{
						uitweener.eventReceiver = this.eventReceiver;
						uitweener.callWhenFinished = this.callWhenFinished;
					}
				}
				i++;
			}
		}
	}

	// Token: 0x0400004D RID: 77
	public GameObject tweenTarget;

	// Token: 0x0400004E RID: 78
	public int tweenGroup;

	// Token: 0x0400004F RID: 79
	public Trigger trigger;

	// Token: 0x04000050 RID: 80
	public Direction playDirection = Direction.Forward;

	// Token: 0x04000051 RID: 81
	public bool resetOnPlay;

	// Token: 0x04000052 RID: 82
	public EnableCondition ifDisabledOnPlay;

	// Token: 0x04000053 RID: 83
	public DisableCondition disableWhenFinished;

	// Token: 0x04000054 RID: 84
	public bool includeChildren;

	// Token: 0x04000055 RID: 85
	public GameObject eventReceiver;

	// Token: 0x04000056 RID: 86
	public string callWhenFinished;

	// Token: 0x04000057 RID: 87
	public UITweener.OnFinished onFinished;

	// Token: 0x04000058 RID: 88
	private UITweener[] mTweens;

	// Token: 0x04000059 RID: 89
	private bool mStarted;

	// Token: 0x0400005A RID: 90
	private bool mHighlighted;
}

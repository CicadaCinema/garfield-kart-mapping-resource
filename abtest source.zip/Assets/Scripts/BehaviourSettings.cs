﻿using System;

// Token: 0x020000A6 RID: 166
[Serializable]
public class BehaviourSettings
{
	// Token: 0x040003CB RID: 971
	public float EasyBonusDelay = 0.5f;

	// Token: 0x040003CC RID: 972
	public float NormalBonusDelay = 0.5f;

	// Token: 0x040003CD RID: 973
	public float HardBonusDelay = 0.25f;

	// Token: 0x040003CE RID: 974
	public float BonusDelayBeforeUseMin = 2f;

	// Token: 0x040003CF RID: 975
	public float BonusDelayBeforeUseMax = 5f;

	// Token: 0x040003D0 RID: 976
	public float BonusDelayMax = 20f;

	// Token: 0x040003D1 RID: 977
	public float PieBeforeDistance;

	// Token: 0x040003D2 RID: 978
	public float PieBehindDistance;

	// Token: 0x040003D3 RID: 979
	public float MagicDistance;

	// Token: 0x040003D4 RID: 980
	public float DiamondBehindDistance;

	// Token: 0x040003D5 RID: 981
	public float DiamondBeforeDistance;

	// Token: 0x040003D6 RID: 982
	public float ParfumeDistance;

	// Token: 0x040003D7 RID: 983
	public float DefenseZoneRadius = 5f;

	// Token: 0x040003D8 RID: 984
	public Chance ShootChance = new Chance(90, 60, 30);

	// Token: 0x040003D9 RID: 985
	public Chance BoostStart50ccChance = new Chance(75, 30, 0);

	// Token: 0x040003DA RID: 986
	public Chance BoostStart100ccChance = new Chance(75, 30, 0);

	// Token: 0x040003DB RID: 987
	public Chance BoostStart150ccChance = new Chance(95, 50, 0);

	// Token: 0x040003DC RID: 988
	public float KeepItemChance = 33f;

	// Token: 0x040003DD RID: 989
	public float RatioSphereCollider = 1.3f;

	// Token: 0x040003DE RID: 990
	public float PCoefficient = 1f;

	// Token: 0x040003DF RID: 991
	public float ICoefficient = 0.1f;

	// Token: 0x040003E0 RID: 992
	public float DCoefficient = 0.1f;

	// Token: 0x040003E1 RID: 993
	public float m_fMinRatioIdealFromMaxSpeed = 0.8f;
}

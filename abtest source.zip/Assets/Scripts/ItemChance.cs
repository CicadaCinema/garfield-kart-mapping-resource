﻿using System;

// Token: 0x0200009B RID: 155
[Serializable]
public class ItemChance : Chance
{
	// Token: 0x06000421 RID: 1057 RVA: 0x00005116 File Offset: 0x00003316
	public ItemChance(int pGood, int pAverage, int pBad, int pNone) : base(pGood, pAverage, pBad)
	{
		this.None = pNone;
	}

	// Token: 0x04000398 RID: 920
	public int None;
}

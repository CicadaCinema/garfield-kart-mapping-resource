﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000106 RID: 262
public class HUDCountdown : MonoBehaviour
{
	// Token: 0x06000723 RID: 1827 RVA: 0x00035868 File Offset: 0x00033A68
	public void Awake()
	{
		this.Sprite3.gameObject.SetActive(false);
		this.Sprite2.gameObject.SetActive(false);
		this.Sprite1.gameObject.SetActive(false);
		this.SpriteGo.gameObject.SetActive(false);
	}

	// Token: 0x06000724 RID: 1828 RVA: 0x000358BC File Offset: 0x00033ABC
	public void SetCountdown(int countdown)
	{
		base.gameObject.SetActive(countdown >= 0);
		if (countdown > 0)
		{
			this.Sprite3.gameObject.SetActive(countdown == 3);
			this.Sprite2.gameObject.SetActive(countdown == 2);
			this.Sprite1.gameObject.SetActive(countdown == 1);
			this.SpriteGo.gameObject.SetActive(false);
		}
		else if (countdown == 0)
		{
			this.Sprite1.gameObject.SetActive(false);
			this.SpriteGo.gameObject.SetActive(true);
			base.StartCoroutine(this.DelayedHideGo());
		}
		else
		{
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x06000725 RID: 1829 RVA: 0x0003597C File Offset: 0x00033B7C
	protected IEnumerator DelayedHideGo()
	{
		yield return new WaitForSeconds(this.GoHideDelay);
		this.SetCountdown(-1);
		yield break;
	}

	// Token: 0x04000701 RID: 1793
	public UISprite Sprite3;

	// Token: 0x04000702 RID: 1794
	public UISprite Sprite2;

	// Token: 0x04000703 RID: 1795
	public UISprite Sprite1;

	// Token: 0x04000704 RID: 1796
	public UISprite SpriteGo;

	// Token: 0x04000705 RID: 1797
	public float GoHideDelay = 1f;
}

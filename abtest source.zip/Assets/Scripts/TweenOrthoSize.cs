﻿using System;
using UnityEngine;

// Token: 0x0200005D RID: 93
[AddComponentMenu("NGUI/Tween/Orthographic Size")]
[RequireComponent(typeof(Camera))]
public class TweenOrthoSize : UITweener
{
	// Token: 0x17000057 RID: 87
	// (get) Token: 0x0600026C RID: 620 RVA: 0x00003D2F File Offset: 0x00001F2F
	public Camera cachedCamera
	{
		get
		{
			if (this.mCam == null)
			{
				this.mCam = base.camera;
			}
			return this.mCam;
		}
	}

	// Token: 0x17000058 RID: 88
	// (get) Token: 0x0600026D RID: 621 RVA: 0x00003D54 File Offset: 0x00001F54
	// (set) Token: 0x0600026E RID: 622 RVA: 0x00003D61 File Offset: 0x00001F61
	public float orthoSize
	{
		get
		{
			return this.cachedCamera.orthographicSize;
		}
		set
		{
			this.cachedCamera.orthographicSize = value;
		}
	}

	// Token: 0x0600026F RID: 623 RVA: 0x00003D6F File Offset: 0x00001F6F
	protected override void OnUpdate(float factor, bool isFinished)
	{
		this.cachedCamera.orthographicSize = this.from * (1f - factor) + this.to * factor;
	}

	// Token: 0x06000270 RID: 624 RVA: 0x000185C4 File Offset: 0x000167C4
	public static TweenOrthoSize Begin(GameObject go, float duration, float to)
	{
		TweenOrthoSize tweenOrthoSize = UITweener.Begin<TweenOrthoSize>(go, duration);
		tweenOrthoSize.from = tweenOrthoSize.orthoSize;
		tweenOrthoSize.to = to;
		if (duration <= 0f)
		{
			tweenOrthoSize.Sample(1f, true);
			tweenOrthoSize.enabled = false;
		}
		return tweenOrthoSize;
	}

	// Token: 0x040001F2 RID: 498
	public float from;

	// Token: 0x040001F3 RID: 499
	public float to;

	// Token: 0x040001F4 RID: 500
	private Camera mCam;
}

﻿using System;
using UnityEngine;

// Token: 0x020001EE RID: 494
public class CamStateRespawn : CamState
{
	// Token: 0x170001D0 RID: 464
	// (get) Token: 0x06000D65 RID: 3429 RVA: 0x00004C05 File Offset: 0x00002E05
	public override ECamState state
	{
		get
		{
			return ECamState.Respawn;
		}
	}

	// Token: 0x06000D66 RID: 3430 RVA: 0x0000B23F File Offset: 0x0000943F
	public void Setup(Vector3 _RespawnPos, Quaternion _RespawnOrient)
	{
		this.m_RespawnPos = _RespawnPos;
		this.m_RespawnOrient = _RespawnOrient;
	}

	// Token: 0x06000D67 RID: 3431 RVA: 0x00057870 File Offset: 0x00055A70
	public override void Enter(Transform _Transform, Transform _Target)
	{
		base.Enter(_Transform, _Target);
		this.m_fCurrTime = this.m_fCamLength;
		base.m_Transform.position = this.m_RespawnPos;
		base.m_Transform.position -= this.m_RespawnOrient * Vector3.forward * this.Distance;
		base.m_Transform.position += this.m_RespawnOrient * Vector3.up * this.Height;
	}

	// Token: 0x06000D68 RID: 3432 RVA: 0x0000B24F File Offset: 0x0000944F
	public override ECamState Manage(float dt)
	{
		base.m_Transform.LookAt(base.m_Target);
		this.m_fCurrTime -= dt;
		if (this.m_fCurrTime < 0f)
		{
			return ECamState.Follow;
		}
		return this.state;
	}

	// Token: 0x06000D69 RID: 3433 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void Exit()
	{
	}

	// Token: 0x04000D15 RID: 3349
	private Vector3 m_RespawnPos;

	// Token: 0x04000D16 RID: 3350
	private Quaternion m_RespawnOrient;

	// Token: 0x04000D17 RID: 3351
	public float Distance = 10f;

	// Token: 0x04000D18 RID: 3352
	public float Height = 5f;

	// Token: 0x04000D19 RID: 3353
	public float m_fCamLength = 0.5f;

	// Token: 0x04000D1A RID: 3354
	protected float m_fCurrTime;
}

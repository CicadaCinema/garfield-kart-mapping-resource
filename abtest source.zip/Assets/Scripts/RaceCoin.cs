﻿using System;
using UnityEngine;

// Token: 0x02000151 RID: 337
public class RaceCoin : RaceItem
{
	// Token: 0x06000974 RID: 2420 RVA: 0x00008925 File Offset: 0x00006B25
	public override void Awake()
	{
		this._sendEvent = false;
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}
		else
		{
			base.Awake();
		}
	}

	// Token: 0x06000975 RID: 2421 RVA: 0x00042E44 File Offset: 0x00041044
	public override void DoOnTriggerEnter(GameObject other, int otherlayer)
	{
		if (other == null)
		{
			return;
		}
		RcVehicle componentInChildren = other.GetComponentInChildren<RcVehicle>();
		if (componentInChildren != null)
		{
			this._sendEvent = (componentInChildren.GetControlType() == RcVehicle.ControlType.Human && Singleton<GameManager>.Instance.GameMode.State == E_GameState.Race);
			this.DoTrigger(componentInChildren);
		}
	}

	// Token: 0x06000976 RID: 2422 RVA: 0x00042EA0 File Offset: 0x000410A0
	protected override void DoTrigger(RcVehicle pVehicle)
	{
		base.DoTrigger(pVehicle);
		if (this._sendEvent)
		{
			Kart kart = (Kart)pVehicle;
			kart.KartSound.PlaySoundImmediately(18);
			Singleton<RewardManager>.Instance.EarnCoins();
		}
	}

	// Token: 0x040009B0 RID: 2480
	private bool _sendEvent;
}

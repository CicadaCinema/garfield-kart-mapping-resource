﻿using System;

// Token: 0x020001A9 RID: 425
public class MenuRewardsCustomDuplicate : MenuRewards
{
	// Token: 0x06000B70 RID: 2928 RVA: 0x0004CCF4 File Offset: 0x0004AEF4
	public override void OnEnter()
	{
		base.OnEnter();
        try
        {
            Tuple<string, ERarity> tuple = Singleton<RewardManager>.Instance.PopUnlockedCustom();
            this._custom = tuple.Item1;
            this._rarity = tuple.Item2;
            Tuple<string, UIAtlas, string, ERarity> infos = base.GetInfos(this._custom, E_RewardType.Custom);
            this.LbRewardName.text = infos.Item1;
            if (this.Sprite != null)
            {
                this.Sprite.spriteName = infos.Item3;
            }
            if (this.SpriteRarity != null)
            {
                this.SpriteRarity.ChangeTexture(Tricks.LogBase2((int)infos.Item4));
            }
            this.LbMessage.text = Localization.instance.Get("MENU_REWARDS_CUSTOMITATIONS_DOUBLON");
            this.LTradePrice.text = this.TradePrice.ToString();
            this.LResellPrice.text = this.ResellPrice.ToString();
        } catch (Exception e)
        {
            ActSwapMenu(EMenus.MENU_WELCOME);
        }
	}

	// Token: 0x06000B71 RID: 2929 RVA: 0x00009F85 File Offset: 0x00008185
	public void OnTrade()
	{
		if (Singleton<GameSaveManager>.Instance.GetCoins() > this.TradePrice)
		{
			Singleton<GameSaveManager>.Instance.SpendCoins(this.TradePrice, false);
			Singleton<RewardManager>.Instance.TradeReward(this._rarity);
		}
		this.OnGoNext();
	}

	// Token: 0x06000B72 RID: 2930 RVA: 0x00009FC3 File Offset: 0x000081C3
	public void OnResell()
	{
		Singleton<GameSaveManager>.Instance.EarnCoins(this.ResellPrice, false, false);
		this.OnGoNext();
	}

	// Token: 0x04000B30 RID: 2864
	private string _custom;

	// Token: 0x04000B31 RID: 2865
	private ERarity _rarity;

	// Token: 0x04000B32 RID: 2866
	public int ResellPrice;

	// Token: 0x04000B33 RID: 2867
	public int TradePrice;

	// Token: 0x04000B34 RID: 2868
	public UILabel LTradePrice;

	// Token: 0x04000B35 RID: 2869
	public UILabel LResellPrice;
}

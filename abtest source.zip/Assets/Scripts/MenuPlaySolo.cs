﻿using System;
using UnityEngine;

// Token: 0x020001A2 RID: 418
public class MenuPlaySolo : AbstractMenu
{
	// Token: 0x06000B53 RID: 2899 RVA: 0x0004C678 File Offset: 0x0004A878
	public override void OnEnter()
	{
		this.isEntered = true;
		base.OnEnter();
		if (this.Input != null)
		{
			this.Input.text = Singleton<GameSaveManager>.Instance.GetPseudo();
			this.Input.defaultText = Localization.instance.Get("MENU_PLAYER");
			this.Input.maxChars = 8;
			this.Input.selected = false;
		}
		this.MultiButton.SetActive(true);
		this.MultiBackgroundButton.SetActive(true);
		this.MultiTextTitle.SetActive(true);
	}

	// Token: 0x06000B54 RID: 2900 RVA: 0x00009DA3 File Offset: 0x00007FA3
	public override void OnExit()
	{
		if (this.isEntered)
		{
			this.OnSubmit();
		}
		base.OnExit();
	}

	// Token: 0x06000B55 RID: 2901 RVA: 0x00009DBC File Offset: 0x00007FBC
	public void OnButtonSingleRace()
	{
		if (ASE_Tools.Available)
		{
			ASE_Flurry.LogEvent("1J_DEMARRER_COURSE_UNIQUE");
		}
		this.OnSubmit();
		this.ActSwapMenu(EMenus.MENU_CHAMPIONSHIP);
		Singleton<GameConfigurator>.Instance.GameModeType = E_GameModeType.SINGLE;
	}

	// Token: 0x06000B56 RID: 2902 RVA: 0x00009DEA File Offset: 0x00007FEA
	public void OnButtonChampionship()
	{
		if (ASE_Tools.Available)
		{
			ASE_Flurry.LogEvent("1J_DEMARRER_GRAND_PRIX");
		}
		this.OnSubmit();
		this.ActSwapMenu(EMenus.MENU_CHAMPIONSHIP);
		Singleton<GameConfigurator>.Instance.GameModeType = E_GameModeType.CHAMPIONSHIP;
	}

	// Token: 0x06000B57 RID: 2903 RVA: 0x00009E18 File Offset: 0x00008018
	public void OnButtonTimeTrial()
	{
        LoadingManager.LoadLevel("test");

		if (ASE_Tools.Available)
		{
			ASE_Flurry.LogEvent("1J_DEMARRER_CONTRE_LA_MONTRE");
		}
		this.OnSubmit();
		this.ActSwapMenu(EMenus.MENU_CHAMPIONSHIP);
		Singleton<GameConfigurator>.Instance.GameModeType = E_GameModeType.TIME_TRIAL;
	}

	// Token: 0x06000B58 RID: 2904 RVA: 0x0004C710 File Offset: 0x0004A910
	private void OnSubmit()
	{
		if (this.Input != null)
		{
			if (ASE_Tools.Available)
			{
				ASE_Flurry.LogEvent("1J_TON_NOM");
			}
			string text = NGUITools.StripSymbols(this.Input.text);
			string text2 = text.Trim();
			if (!string.IsNullOrEmpty(text2) && text2 != Localization.instance.Get("MENU_PLAYER"))
			{
				Singleton<GameSaveManager>.Instance.SetPseudo(text2, true);
			}
			else if (this.Input.text.Equals(string.Empty))
			{
				Singleton<GameSaveManager>.Instance.SetPseudo(string.Empty, true);
			}
			this.Input.selected = false;
		}
	}

	// Token: 0x06000B59 RID: 2905 RVA: 0x00009E46 File Offset: 0x00008046
	public override void ActSwapMenu(EMenus NextMenu)
	{
		if (ASE_Tools.Available)
		{
			if (NextMenu == EMenus.MENU_WELCOME)
			{
				ASE_Flurry.LogEvent("1J_RETOUR_MENU_PRINCIPAL");
			}
			else if (NextMenu == EMenus.MENU_MULTI)
			{
				ASE_Flurry.LogEvent("MJ_SELECTION_ONGLET_MULTI");
			}
		}
		base.ActSwapMenu(NextMenu);
	}

	// Token: 0x04000B1D RID: 2845
	public UIInput Input;

	// Token: 0x04000B1E RID: 2846
	private bool isEntered;

	// Token: 0x04000B1F RID: 2847
	public GameObject MultiButton;

	// Token: 0x04000B20 RID: 2848
	public GameObject MultiBackgroundButton;

	// Token: 0x04000B21 RID: 2849
	public GameObject MultiTextTitle;
}

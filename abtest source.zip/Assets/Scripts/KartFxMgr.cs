﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000145 RID: 325
public class KartFxMgr : MonoBehaviour, RcCollisionListener
{
	// Token: 0x06000929 RID: 2345 RVA: 0x00041054 File Offset: 0x0003F254
	public KartFxMgr()
	{
		this.m_pKart = null;
		this.SurfacesFx = new List<KartFxMgr.SurfaceFx>();
	}

	// Token: 0x0600092A RID: 2346 RVA: 0x000410B0 File Offset: 0x0003F2B0
	public void OnDestroy()
	{
		this.Stop();
		if (this.KartFxs != null)
		{
			for (int i = 0; i < this.KartFxs.Length; i++)
			{
				if (this.KartFxs[i] != null && !this.KartFxs[i].FollowKart)
				{
					UnityEngine.Object.Destroy(this.KartFxs[i].Object);
				}
			}
		}
	}

	// Token: 0x0600092B RID: 2347 RVA: 0x00041118 File Offset: 0x0003F318
	public void Start()
	{
		this.m_pKart = base.transform.parent.FindChild("Tunning").GetComponent<Kart>();
		if (this.m_pKart)
		{
			this.m_pKart.AddCollisionListener(this);
		}
		this.m_bDriftColor = false;
	}

	// Token: 0x0600092C RID: 2348 RVA: 0x000085BA File Offset: 0x000067BA
	public void Stop()
	{
		if (this.m_pKart)
		{
			this.m_pKart.RemoveCollisionListener(this);
			this.m_pKart = null;
		}
	}

	// Token: 0x0600092D RID: 2349 RVA: 0x00041168 File Offset: 0x0003F368
	public void InstantiateAndAttach(Transform _Parent)
	{
		for (int i = 0; i < this.SurfacesFx.Count; i++)
		{
			if (this.SurfacesFx[i].AssociateFx != null)
			{
				this.SurfaceFxGameObject.Add((GameObject)UnityEngine.Object.Instantiate(this.SurfacesFx[i].AssociateFx));
				this.SurfaceFxGameObject[i].transform.position = _Parent.position;
				this.SurfaceFxGameObject[i].transform.parent = _Parent;
			}
		}
		for (int j = 0; j < this.KartFxs.Length; j++)
		{
			if (this.KartFxs[j].AssociateFx != null)
			{
				this.KartFxs[j].Object = (GameObject)UnityEngine.Object.Instantiate(this.KartFxs[j].AssociateFx);
				if (this.KartFxs[j].FollowKart)
				{
					this.KartFxs[j].Transform.parent = _Parent;
				}
				if (j == 3)
				{
					this.m_pDriftBaseColor = this.KartFxs[j].ParticleSystem.startColor;
				}
			}
		}
	}

	// Token: 0x0600092E RID: 2350 RVA: 0x000412A0 File Offset: 0x0003F4A0
	public void Update()
	{
		if (this.m_pKart == null)
		{
			return;
		}
		float wheelSpeed = this.m_pKart.GetVehiclePhysic().GetWheelSpeed();
		bool flag = wheelSpeed >= this.SpeedToProduceSurfaceFx || wheelSpeed <= -this.SpeedToProduceSurfaceFx;
		for (int i = 0; i < this.SurfacesFx.Count; i++)
		{
			if (!flag)
			{
				if (this.SurfaceFxGameObject[i].particleSystem.isPlaying)
				{
					this.SurfaceFxGameObject[i].particleSystem.Stop();
				}
			}
			else
			{
				bool flag2 = false;
				for (int j = 0; j < this.m_pKart.GetVehiclePhysic().GetNbWheels(); j++)
				{
					int surface = this.m_pKart.GetGroundCharac(j).surface;
					if (this.m_pKart.IsOnGround(j) && (1 << surface & this.SurfacesFx[i].SurfaceLayer.value) != 0)
					{
						flag2 = true;
						break;
					}
				}
				if (flag2 && !this.SurfaceFxGameObject[i].particleSystem.isPlaying)
				{
					this.SurfaceFxGameObject[i].particleSystem.startSpeed = Mathf.Abs(wheelSpeed);
					this.SurfaceFxGameObject[i].particleSystem.Play();
					this.StopAllOtherSurfaceFx(this.SurfaceFxGameObject[i]);
					break;
				}
				if (flag2 && this.SurfaceFxGameObject[i].particleSystem.isPlaying)
				{
					this.SurfaceFxGameObject[i].particleSystem.startSpeed = Mathf.Abs(wheelSpeed);
				}
				else if (!flag2 && this.SurfaceFxGameObject[i].particleSystem.isPlaying)
				{
					this.SurfaceFxGameObject[i].particleSystem.Stop();
				}
			}
		}
		for (int k = 0; k < this.m_pKart.GetVehiclePhysic().GetNbWheels(); k++)
		{
			int surface2 = this.m_pKart.GetGroundCharac(k).surface;
			if ((1 << surface2 & this.WaterLayer.value) != 0)
			{
				this.PlayKartFx(eKartFx.Dive);
			}
		}
	}

	// Token: 0x0600092F RID: 2351 RVA: 0x00041500 File Offset: 0x0003F700
	public void StopAllOtherSurfaceFx(GameObject _ExeptMe)
	{
		foreach (GameObject gameObject in this.SurfaceFxGameObject)
		{
			if (gameObject != _ExeptMe && gameObject.particleSystem.isPlaying)
			{
				gameObject.particleSystem.Stop();
			}
		}
	}

	// Token: 0x06000930 RID: 2352 RVA: 0x0004157C File Offset: 0x0003F77C
	public void PlayKartFx(eKartFx _Fx)
	{
		if ((this.KartFxs[(int)_Fx].ParticleSystem.loop && !this.KartFxs[(int)_Fx].ParticleSystem.isPlaying) || !this.KartFxs[(int)_Fx].ParticleSystem.loop)
		{
			if (!this.KartFxs[(int)_Fx].FollowKart)
			{
				this.KartFxs[(int)_Fx].Transform.position = this.m_pKart.Transform.position;
			}
			this.KartFxs[(int)_Fx].ParticleSystem.Play();
		}
	}

	// Token: 0x06000931 RID: 2353 RVA: 0x00041618 File Offset: 0x0003F818
	public void PlayKartFx(eKartFx _Fx, Vector3 _pos)
	{
		if ((this.KartFxs[(int)_Fx].ParticleSystem.loop && !this.KartFxs[(int)_Fx].ParticleSystem.isPlaying) || !this.KartFxs[(int)_Fx].ParticleSystem.loop)
		{
			this.KartFxs[(int)_Fx].Transform.position = _pos;
			this.KartFxs[(int)_Fx].ParticleSystem.Play();
		}
	}

	// Token: 0x06000932 RID: 2354 RVA: 0x00041694 File Offset: 0x0003F894
	public void StopKartFx(eKartFx _Fx)
	{
		if (this.KartFxs[(int)_Fx] != null && this.KartFxs[(int)_Fx].ParticleSystem != null && this.KartFxs[(int)_Fx].ParticleSystem.isPlaying)
		{
			if (!this.KartFxs[(int)_Fx].FollowKart)
			{
				this.KartFxs[(int)_Fx].Transform.position = this.m_pKart.Transform.position;
			}
			this.KartFxs[(int)_Fx].ParticleSystem.Stop();
			this.KartFxs[(int)_Fx].ParticleSystem.Clear();
		}
	}

	// Token: 0x06000933 RID: 2355 RVA: 0x000085DF File Offset: 0x000067DF
	public void StopDriftFx()
	{
		this.StopKartFx(eKartFx.DriftLeft);
		this.StopKartFx(eKartFx.DriftLeft2);
		this.StopKartFx(eKartFx.DriftRight);
		this.StopKartFx(eKartFx.DriftRight2);
		this.m_bDriftColor = false;
	}

	// Token: 0x06000934 RID: 2356 RVA: 0x00041738 File Offset: 0x0003F938
	public void OnCollision(CollisionData collisionInfo)
	{
		Vector3 a = Vector3.zero;
		Vector3 b = Vector3.zero;
		if (this.m_pKart)
		{
			a = this.m_pKart.GetVehiclePhysic().GetLinearVelocity();
		}
		if (collisionInfo.other != null)
		{
			b = collisionInfo.other.velocity;
		}
		float f = Vector3.Dot(a - b, collisionInfo.normal);
		if (Mathf.Abs(f) > 2f && !this.m_pKart.IsLocked() && this.m_pKart.GetWheelSpeedMS() > 13.9f)
		{
			this.PlayKartFx(eKartFx.Impact, collisionInfo.position);
		}
	}

	// Token: 0x06000935 RID: 2357 RVA: 0x000417E8 File Offset: 0x0003F9E8
	public void BoostDrift(float _BoostLevel, float _Threshold)
	{
		if (_BoostLevel == 0f)
		{
			this.KartFxs[3].ParticleSystem.startColor = this.m_pDriftBaseColor;
			this.KartFxs[4].ParticleSystem.startColor = this.m_pDriftBaseColor;
		}
		else if (_BoostLevel >= _Threshold)
		{
			Color color = new Color((_BoostLevel - _Threshold) / (100f - _Threshold), 0.5f, 0.4f);
			this.KartFxs[3].ParticleSystem.startColor = color;
			this.KartFxs[4].ParticleSystem.startColor = color;
			this.m_pDriftColor = color;
			this.m_bDriftColor = true;
		}
	}

	// Token: 0x06000936 RID: 2358 RVA: 0x0004188C File Offset: 0x0003FA8C
	public void Boost()
	{
		Color startColor;
		if (!this.m_bDriftColor)
		{
			startColor = this.m_pDriftBaseColor;
		}
		else
		{
			startColor = this.m_pDriftColor;
		}
		this.KartFxs[0].ParticleSystem.startColor = startColor;
		this.KartFxs[8].ParticleSystem.startColor = startColor;
		this.KartFxs[0].ParticleSystem.Play();
		this.KartFxs[8].ParticleSystem.Play();
		this.m_bDriftColor = false;
	}

	// Token: 0x04000951 RID: 2385
	private Kart m_pKart;

	// Token: 0x04000952 RID: 2386
	public float SpeedToProduceSurfaceFx = 7f;

	// Token: 0x04000953 RID: 2387
	public List<KartFxMgr.SurfaceFx> SurfacesFx;

	// Token: 0x04000954 RID: 2388
	private List<GameObject> SurfaceFxGameObject = new List<GameObject>();

	// Token: 0x04000955 RID: 2389
	[HideInInspector]
	[SerializeField]
	public KartFxMgr.KartFx[] KartFxs = new KartFxMgr.KartFx[Enum.GetValues(typeof(eKartFx)).Length];

	// Token: 0x04000956 RID: 2390
	public LayerMask WaterLayer;

	// Token: 0x04000957 RID: 2391
	private Color m_pDriftBaseColor;

	// Token: 0x04000958 RID: 2392
	private Color m_pDriftColor;

	// Token: 0x04000959 RID: 2393
	private bool m_bDriftColor;

	// Token: 0x02000146 RID: 326
	[Serializable]
	public class SurfaceFx
	{
		// Token: 0x06000937 RID: 2359 RVA: 0x00008604 File Offset: 0x00006804
		public SurfaceFx()
		{
			this.AssociateFx = null;
		}

		// Token: 0x0400095A RID: 2394
		public LayerMask SurfaceLayer;

		// Token: 0x0400095B RID: 2395
		public GameObject AssociateFx;
	}

	// Token: 0x02000147 RID: 327
	[Serializable]
	public class KartFx
	{
		// Token: 0x06000938 RID: 2360 RVA: 0x00008613 File Offset: 0x00006813
		public KartFx()
		{
			this.AssociateFx = null;
			this.FollowKart = true;
			this.m_pTransform = null;
			this.m_pObject = null;
			this.m_pParticles = null;
		}

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x06000939 RID: 2361 RVA: 0x0000863E File Offset: 0x0000683E
		// (set) Token: 0x0600093A RID: 2362 RVA: 0x00008646 File Offset: 0x00006846
		public Transform Transform
		{
			get
			{
				return this.m_pTransform;
			}
			set
			{
				this.m_pTransform = value;
			}
		}

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x0600093B RID: 2363 RVA: 0x0000864F File Offset: 0x0000684F
		// (set) Token: 0x0600093C RID: 2364 RVA: 0x00008657 File Offset: 0x00006857
		public GameObject Object
		{
			get
			{
				return this.m_pObject;
			}
			set
			{
				this.m_pObject = value;
				this.Transform = this.m_pObject.transform;
				this.m_pParticles = this.m_pObject.particleSystem;
			}
		}

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x0600093D RID: 2365 RVA: 0x00008682 File Offset: 0x00006882
		public ParticleSystem ParticleSystem
		{
			get
			{
				return this.m_pParticles;
			}
		}

		// Token: 0x0400095C RID: 2396
		public GameObject AssociateFx;

		// Token: 0x0400095D RID: 2397
		public bool FollowKart;

		// Token: 0x0400095E RID: 2398
		private Transform m_pTransform;

		// Token: 0x0400095F RID: 2399
		private GameObject m_pObject;

		// Token: 0x04000960 RID: 2400
		private ParticleSystem m_pParticles;
	}
}

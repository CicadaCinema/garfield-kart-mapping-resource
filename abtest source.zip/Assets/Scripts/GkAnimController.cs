﻿using System;
using UnityEngine;

// Token: 0x0200013B RID: 315
[Serializable]
public class GkAnimController
{
	// Token: 0x060008B3 RID: 2227 RVA: 0x000081E5 File Offset: 0x000063E5
	public GkAnimController(Animator pAnimator)
	{
		this._animator = pAnimator;
		this._bonusParameter = -1;
		this._bonusState = -1;
		this._canStop = true;
	}

	// Token: 0x17000142 RID: 322
	// (get) Token: 0x060008B4 RID: 2228 RVA: 0x00008209 File Offset: 0x00006409
	public Animator Animator
	{
		get
		{
			return this._animator;
		}
	}

	// Token: 0x060008B5 RID: 2229 RVA: 0x0003F2CC File Offset: 0x0003D4CC
	public void Update()
	{
		AnimatorStateInfo currentAnimatorStateInfo = this._animator.GetCurrentAnimatorStateInfo(0);
		if (this._bonusState != -1 && currentAnimatorStateInfo.nameHash == this._bonusState && this._canStop && !this._animator.IsInTransition(0))
		{
			this._animator.SetBool(this._bonusParameter, false);
			this._bonusParameter = -1;
			this._bonusState = -1;
		}
	}

	// Token: 0x060008B6 RID: 2230 RVA: 0x0003F340 File Offset: 0x0003D540
	public void Play(int pAnimParameter, int pAnimState, bool pCanStop)
	{
		if (this._bonusState != -1 && this._bonusParameter != -1)
		{
			this._animator.SetBool(this._bonusParameter, false);
		}
		this._bonusParameter = pAnimParameter;
		this._bonusState = pAnimState;
		this._canStop = pCanStop;
		this._animator.SetBool(pAnimParameter, true);
	}

	// Token: 0x060008B7 RID: 2231 RVA: 0x00008211 File Offset: 0x00006411
	public void Stop(int pAnimState)
	{
		if (this._bonusState == pAnimState)
		{
			this._canStop = true;
		}
	}

	// Token: 0x060008B8 RID: 2232 RVA: 0x00008226 File Offset: 0x00006426
	public void ForceStop(int pAnimParameter)
	{
		this._animator.SetBool(pAnimParameter, false);
	}

	// Token: 0x060008B9 RID: 2233 RVA: 0x00008235 File Offset: 0x00006435
	public void StopAll()
	{
		this._canStop = true;
	}

	// Token: 0x040008EF RID: 2287
	private Animator _animator;

	// Token: 0x040008F0 RID: 2288
	private int _bonusParameter;

	// Token: 0x040008F1 RID: 2289
	private int _bonusState;

	// Token: 0x040008F2 RID: 2290
	private bool _canStop;
}

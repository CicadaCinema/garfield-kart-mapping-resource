﻿using System;

// Token: 0x02000108 RID: 264
public class HUDEndChampionsShipRace : HUDEndRace
{
	// Token: 0x0600072D RID: 1837 RVA: 0x00035A00 File Offset: 0x00033C00
	public override void FillPositions()
	{
		base.FillPositions();
		if (Singleton<GameConfigurator>.Instance.ChampionShipData != null)
		{
			string championShipName = Singleton<GameConfigurator>.Instance.ChampionShipData.ChampionShipName;
			this.LabelTitle.text = string.Format(Localization.instance.Get("HUD_DYN_CHAMPIONSHIP_ROUND"), championShipName, Singleton<GameConfigurator>.Instance.CurrentTrackIndex);
		}
	}

	// Token: 0x0600072E RID: 1838 RVA: 0x00035A68 File Offset: 0x00033C68
	public override void GetScoreInfos(int iIndex, out int iKartIndex, out int iScore, out int iTotalScore, out bool bEquality)
	{
		ChampionShipScoreData championShipScoreData = (ChampionShipScoreData)Singleton<GameConfigurator>.Instance.RankingManager.GetRacePos(iIndex);
		if (iIndex > 0)
		{
			bEquality = (championShipScoreData.RaceScore == Singleton<GameConfigurator>.Instance.RankingManager.GetRacePos(iIndex - 1).RaceScore);
		}
		else
		{
			bEquality = false;
		}
		iKartIndex = championShipScoreData.KartIndex;
		iScore = championShipScoreData.RaceScore;
		iTotalScore = championShipScoreData.PreviousChampionshipScore;
	}

	// Token: 0x0600072F RID: 1839 RVA: 0x000070B0 File Offset: 0x000052B0
	public override int GetTrackIndex()
	{
		return Singleton<GameConfigurator>.Instance.CurrentTrackIndex - 1;
	}
}

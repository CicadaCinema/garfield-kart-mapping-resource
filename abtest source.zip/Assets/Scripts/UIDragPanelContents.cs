﻿using System;
using UnityEngine;

// Token: 0x0200001A RID: 26
[ExecuteInEditMode]
[AddComponentMenu("NGUI/Interaction/Drag Panel Contents")]
public class UIDragPanelContents : MonoBehaviour
{
	// Token: 0x06000076 RID: 118 RVA: 0x0000F320 File Offset: 0x0000D520
	private void Awake()
	{
		if (this.panel != null)
		{
			if (this.draggablePanel == null)
			{
				this.draggablePanel = this.panel.GetComponent<UIDraggablePanel>();
				if (this.draggablePanel == null)
				{
					this.draggablePanel = this.panel.gameObject.AddComponent<UIDraggablePanel>();
				}
			}
			this.panel = null;
		}
	}

	// Token: 0x06000077 RID: 119 RVA: 0x000027F3 File Offset: 0x000009F3
	private void Start()
	{
		if (this.draggablePanel == null)
		{
			this.draggablePanel = NGUITools.FindInParents<UIDraggablePanel>(base.gameObject);
		}
	}

	// Token: 0x06000078 RID: 120 RVA: 0x00002817 File Offset: 0x00000A17
	private void OnPress(bool pressed)
	{
		if (base.enabled && NGUITools.GetActive(base.gameObject) && this.draggablePanel != null)
		{
			this.draggablePanel.Press(pressed);
		}
	}

	// Token: 0x06000079 RID: 121 RVA: 0x00002851 File Offset: 0x00000A51
	private void OnDrag(Vector2 delta)
	{
		if (base.enabled && NGUITools.GetActive(base.gameObject) && this.draggablePanel != null)
		{
			this.draggablePanel.Drag();
		}
	}

	// Token: 0x0600007A RID: 122 RVA: 0x0000288A File Offset: 0x00000A8A
	private void OnScroll(float delta)
	{
		if (base.enabled && NGUITools.GetActive(base.gameObject) && this.draggablePanel != null)
		{
			this.draggablePanel.Scroll(delta);
		}
	}

	// Token: 0x04000085 RID: 133
	public UIDraggablePanel draggablePanel;

	// Token: 0x04000086 RID: 134
	[SerializeField]
	[HideInInspector]
	private UIPanel panel;
}

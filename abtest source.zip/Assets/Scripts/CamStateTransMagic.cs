﻿using System;
using UnityEngine;

// Token: 0x020001F0 RID: 496
public class CamStateTransMagic : CamStateTransition
{
	// Token: 0x170001D2 RID: 466
	// (get) Token: 0x06000D6F RID: 3439 RVA: 0x0000B2D6 File Offset: 0x000094D6
	public override ECamState state
	{
		get
		{
			return ECamState.TransMagic;
		}
	}

	// Token: 0x06000D70 RID: 3440 RVA: 0x00057904 File Offset: 0x00055B04
	protected override bool Merge(float dt)
	{
		if (this.TranslationDistance > 0f)
		{
			this.TranslationDistance -= this.Step * dt;
			if (this.TranslationDistance < 0f)
			{
				this.TranslationDistance = 0f;
			}
		}
		else if (this.TranslationDistance < 0f)
		{
			this.TranslationDistance += this.Step * dt;
			if (this.TranslationDistance > 0f)
			{
				this.TranslationDistance = 0f;
			}
		}
		base.m_Transform.position = this.m_ToState.m_Transform.position;
		if (this.TranslationDistance != 0f)
		{
			base.m_Transform.position += this.TranslationDistance * this.TranslationDirection;
		}
		if (this.TranslationDistance >= 0f)
		{
			base.m_Transform.LookAt(base.m_Target);
		}
		return this.TranslationDistance == 0f;
	}

	// Token: 0x04000D1B RID: 3355
	[HideInInspector]
	public float TranslationDistance;

	// Token: 0x04000D1C RID: 3356
	[HideInInspector]
	public Vector3 TranslationDirection = Vector3.zero;

	// Token: 0x04000D1D RID: 3357
	[HideInInspector]
	public float Step;

	// Token: 0x04000D1E RID: 3358
	public float TranslationTime = 2f;
}

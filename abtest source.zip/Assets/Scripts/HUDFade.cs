﻿using System;
using UnityEngine;

// Token: 0x0200010C RID: 268
public class HUDFade : MonoBehaviour
{
	// Token: 0x17000113 RID: 275
	// (get) Token: 0x06000740 RID: 1856 RVA: 0x00007200 File Offset: 0x00005400
	private float _Duration
	{
		get
		{
			return this.m_fTimer;
		}
	}

	// Token: 0x06000741 RID: 1857 RVA: 0x00036CC4 File Offset: 0x00034EC4
	public void OnDestroy()
	{
		if (this._kart != null)
		{
			Kart kart = this._kart;
			kart.OnRespawn = (Action)Delegate.Remove(kart.OnRespawn, new Action(this.FadeOut));
			Kart kart2 = this._kart;
			kart2.OnKilled = (Action)Delegate.Remove(kart2.OnKilled, new Action(this.FadeIn));
		}
	}

	// Token: 0x06000742 RID: 1858 RVA: 0x00003B80 File Offset: 0x00001D80
	public void Start()
	{
	}

	// Token: 0x06000743 RID: 1859 RVA: 0x00036D30 File Offset: 0x00034F30
	public void Update()
	{
		if (this._kart == null)
		{
			this._kart = Singleton<GameManager>.Instance.GameMode.GetHumanKart();
			if (this._kart != null)
			{
				Kart kart = this._kart;
				kart.OnRespawn = (Action)Delegate.Combine(kart.OnRespawn, new Action(this.FadeOut));
				Kart kart2 = this._kart;
				kart2.OnKilled = (Action)Delegate.Combine(kart2.OnKilled, new Action(this.FadeIn));
			}
		}
		if (this._enabled)
		{
			this._elapsedTime += Time.deltaTime;
			float duration = this._Duration;
			if (this._elapsedTime >= duration)
			{
				this._elapsedTime = duration;
				this._enabled = false;
			}
			float time = this.GetTime(duration);
			this.FadeTexture.alpha = Mathf.Lerp(0f, 1f, time);
		}
	}

	// Token: 0x06000744 RID: 1860 RVA: 0x00007208 File Offset: 0x00005408
	public void FadeIn()
	{
		this.DoFadeIn(this.FadeInDuration);
	}

	// Token: 0x06000745 RID: 1861 RVA: 0x00007216 File Offset: 0x00005416
	public void DoFadeIn(float _Time)
	{
		this._enabled = true;
		this._elapsedTime = 0f;
		this._fadeType = HUDFade.E_FadeType.FadeIn;
		this.FadeTexture.alpha = 0f;
		this.m_fTimer = _Time;
	}

	// Token: 0x06000746 RID: 1862 RVA: 0x00007248 File Offset: 0x00005448
	public void FadeOut()
	{
		this.DoFadeOut(this.FadeOutDuration);
	}

	// Token: 0x06000747 RID: 1863 RVA: 0x00007256 File Offset: 0x00005456
	public void DoFadeOut(float _Time)
	{
		this._enabled = true;
		this._elapsedTime = 0f;
		this._fadeType = HUDFade.E_FadeType.FadeOut;
		this.FadeTexture.alpha = 1f;
		this.m_fTimer = _Time;
	}

	// Token: 0x06000748 RID: 1864 RVA: 0x00036E24 File Offset: 0x00035024
	private float GetTime(float pDuration)
	{
		float num = this._elapsedTime / pDuration;
		if (this._fadeType == HUDFade.E_FadeType.FadeIn)
		{
			return num;
		}
		if (this._fadeType == HUDFade.E_FadeType.FadeOut)
		{
			return 1f - num;
		}
		return 0f;
	}

	// Token: 0x06000749 RID: 1865 RVA: 0x00007288 File Offset: 0x00005488
	public void ForceIn()
	{
		this.FadeTexture.alpha = 1f;
	}

	// Token: 0x04000725 RID: 1829
	public UITexture FadeTexture;

	// Token: 0x04000726 RID: 1830
	public float FadeInDuration = 0.25f;

	// Token: 0x04000727 RID: 1831
	public float FadeOutDuration = 0.25f;

	// Token: 0x04000728 RID: 1832
	private float _elapsedTime;

	// Token: 0x04000729 RID: 1833
	private bool _enabled;

	// Token: 0x0400072A RID: 1834
	private float m_fTimer;

	// Token: 0x0400072B RID: 1835
	private Kart _kart;

	// Token: 0x0400072C RID: 1836
	private HUDFade.E_FadeType _fadeType;

	// Token: 0x0200010D RID: 269
	public enum E_FadeType
	{
		// Token: 0x0400072E RID: 1838
		FadeIn,
		// Token: 0x0400072F RID: 1839
		FadeOut
	}
}

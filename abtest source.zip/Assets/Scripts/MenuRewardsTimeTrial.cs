﻿using System;

// Token: 0x020001B1 RID: 433
public class MenuRewardsTimeTrial : MenuRewards
{
	// Token: 0x06000B8C RID: 2956 RVA: 0x0004D344 File Offset: 0x0004B544
	public override void OnEnter()
	{
		base.OnEnter();
		Tuple<int, string> tuple = Singleton<RewardManager>.Instance.PopTimeTrial();
		if (this.MedalSprite)
		{
			this.MedalSprite.ChangeTexture(tuple.Item1 - 1);
		}
		this.LbRewardName.text = Localization.instance.Get("TRACK_NAME_" + tuple.Item2);
		this.LbMessage.text = string.Format(Localization.instance.Get("MENU_REWARDS_TIME_TRIAL_MEDAL"), Localization.instance.Get("MENU_REWARDS_MEDAL" + tuple.Item1));
		if (tuple.Item1 == 4)
		{
			this.LbNextMedal.text = string.Format(Localization.instance.Get("MENU_REWARDS_TIME_TRIAL_NEXT_RECORD"), new object[0]);
		}
		else
		{
			this.LbNextMedal.text = string.Format(Localization.instance.Get("MENU_REWARDS_TIME_TRIAL_NEXT_MEDAL"), Localization.instance.Get("MENU_REWARDS_MEDAL" + (tuple.Item1 + 1)));
		}
	}

	// Token: 0x04000B4E RID: 2894
	public UILabel LbNextMedal;

	// Token: 0x04000B4F RID: 2895
	public UITexturePattern MedalSprite;
}

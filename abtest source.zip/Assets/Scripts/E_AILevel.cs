﻿using System;

// Token: 0x020001E3 RID: 483
public enum E_AILevel
{
	// Token: 0x04000C95 RID: 3221
	GOOD = 1,
	// Token: 0x04000C96 RID: 3222
	AVERAGE,
	// Token: 0x04000C97 RID: 3223
	BAD,
	// Token: 0x04000C98 RID: 3224
	NONE
}

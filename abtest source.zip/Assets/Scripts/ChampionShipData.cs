﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000177 RID: 375
public class ChampionShipData : MonoBehaviour
{
	// Token: 0x17000162 RID: 354
	// (get) Token: 0x06000A09 RID: 2569 RVA: 0x00008D94 File Offset: 0x00006F94
	public string ChampionShipName
	{
		get
		{
			return this.m_sChampionShipName;
		}
	}

	// Token: 0x17000163 RID: 355
	// (get) Token: 0x06000A0A RID: 2570 RVA: 0x00008D9C File Offset: 0x00006F9C
	public string[] TracksName
	{
		get
		{
			return this.m_sTracksName;
		}
	}

	// Token: 0x06000A0B RID: 2571 RVA: 0x000457F0 File Offset: 0x000439F0
	public void Localize()
	{
		this.m_sChampionShipName = Localization.instance.Get(this.ChampionShipNameId);
		for (int i = 0; i < 4; i++)
		{
			this.m_sTracksName[i] = Localization.instance.Get(this.TracksNameId[i]);
		}
	}

	// Token: 0x04000A15 RID: 2581
	public string[] Tracks = new string[4];

	// Token: 0x04000A16 RID: 2582
	public string[] TracksNameId = new string[4];

	// Token: 0x04000A17 RID: 2583
	public string ChampionShipNameId;

	// Token: 0x04000A18 RID: 2584
	public E_UnlockableItemSate EasyState;

	// Token: 0x04000A19 RID: 2585
	public E_UnlockableItemSate NormalState;

	// Token: 0x04000A1A RID: 2586
	public E_UnlockableItemSate HardState;

	// Token: 0x04000A1B RID: 2587
	public int Index;

	// Token: 0x04000A1C RID: 2588
	private string m_sChampionShipName;

	// Token: 0x04000A1D RID: 2589
	private string[] m_sTracksName = new string[4];

	// Token: 0x04000A1E RID: 2590
	public List<RewardBase> Rewards = new List<RewardBase>();
}

﻿using System;

// Token: 0x020001AF RID: 431
public class MenuRewardsKarts : MenuRewards
{
	// Token: 0x06000B86 RID: 2950 RVA: 0x0004D218 File Offset: 0x0004B418
	public override void OnEnter()
	{
		base.OnEnter();
		this._kart = Singleton<RewardManager>.Instance.PopKart();
		Tuple<string, UIAtlas, string, ERarity> infos = base.GetInfos(this._kart.ToString(), E_RewardType.Kart);
		this.LbRewardName.text = infos.Item1;
		if (this.Sprite != null)
		{
			this.Sprite.spriteName = infos.Item3;
		}
	}

	// Token: 0x06000B87 RID: 2951 RVA: 0x0000A09D File Offset: 0x0000829D
	public override void OnGoNext()
	{
		Singleton<GameSaveManager>.Instance.SetKartState(this._kart, E_UnlockableItemSate.NewUnlocked, false);
		base.OnGoNext();
	}

	// Token: 0x04000B48 RID: 2888
	private ECharacter _kart;
}

﻿using System;
using UnityEngine;

// Token: 0x020000E2 RID: 226
public class NetworkBonusEntity : MonoBehaviour
{
	// Token: 0x06000618 RID: 1560 RVA: 0x00030718 File Offset: 0x0002E918
	public virtual void Awake()
	{
		base.networkView.observed = this;
		this.m_pBonusEntity = null;
		int num = 0;
		while (num < base.transform.parent.childCount && this.m_pBonusEntity == null)
		{
			this.m_pBonusEntity = base.transform.parent.GetChild(num).GetComponent<BonusEntity>();
			num++;
		}
		if (this.m_pBonusEntity == null)
		{
		}
	}

	// Token: 0x06000619 RID: 1561 RVA: 0x000064FC File Offset: 0x000046FC
	public virtual void Start()
	{
		base.networkView.observed = this;
	}

	// Token: 0x0600061A RID: 1562 RVA: 0x0000650A File Offset: 0x0000470A
	[RPC]
	public void OnLayerTriggerEnter(int layer)
	{
		this.m_pBonusEntity.DoOnTriggerEnter(null, layer);
	}

	// Token: 0x0600061B RID: 1563 RVA: 0x00030798 File Offset: 0x0002E998
	[RPC]
	public void OnNetworkViewTriggerEnter(NetworkViewID viewId)
	{
		NetworkView networkView = NetworkView.Find(viewId);
		if (networkView != null)
		{
			Transform parent = networkView.gameObject.transform.parent;
			if (parent != null)
			{
				BonusEntity componentInChildren = parent.GetComponentInChildren<BonusEntity>();
				if (componentInChildren != null)
				{
					this.m_pBonusEntity.DoOnTriggerEnter(componentInChildren.gameObject, componentInChildren.gameObject.layer);
					return;
				}
			}
			this.m_pBonusEntity.DoOnTriggerEnter(networkView.gameObject, networkView.gameObject.layer);
		}
	}

	// Token: 0x0600061C RID: 1564 RVA: 0x00006519 File Offset: 0x00004719
	[RPC]
	public void OnLayerTriggerExit(int layer)
	{
		this.m_pBonusEntity.DoOnTriggerExit(null, layer);
	}

	// Token: 0x0600061D RID: 1565 RVA: 0x00030824 File Offset: 0x0002EA24
	[RPC]
	public void OnNetworkViewTriggerExit(NetworkViewID viewId)
	{
		NetworkView networkView = NetworkView.Find(viewId);
		if (networkView != null)
		{
			this.m_pBonusEntity.DoOnTriggerExit(networkView.gameObject, networkView.gameObject.layer);
		}
	}

	// Token: 0x0600061E RID: 1566 RVA: 0x00006528 File Offset: 0x00004728
	[RPC]
	public virtual void OnNetworkDestroy()
	{
		this.m_pBonusEntity.DoDestroy();
	}

	// Token: 0x0600061F RID: 1567 RVA: 0x00006535 File Offset: 0x00004735
	[RPC]
	public virtual void NetworkInitialize(NetworkViewID LauncherViewID)
	{
		this.m_pBonusEntity.DoNetworkInitialize(LauncherViewID);
	}

	// Token: 0x0400060C RID: 1548
	protected BonusEntity m_pBonusEntity;
}

﻿using System;
using UnityEngine;

// Token: 0x020000ED RID: 237
public class UFO : MonoBehaviour
{
	// Token: 0x0600066C RID: 1644 RVA: 0x000322A0 File Offset: 0x000304A0
	public UFO()
	{
		this.m_pCollider = null;
		for (int i = 0; i < 3; i++)
		{
			this.m_pRayParticles[i] = null;
		}
		this.ApparitionParticle = null;
		this.ApparitionParticleGO = null;
		this.m_InitialParticlePos = Vector3.zero;
		this.m_InitialBoxCenter = Vector3.zero;
		this.m_pTransform = null;
		this.m_pFinalPosition = Vector3.zero;
		this.m_InitialPos = Vector3.zero;
		this.m_Direction = Vector3.zero;
		this.m_Speed = 0f;
		this.m_fScale = 1f;
		this.m_pParent = null;
		this.m_bLeaveIsPlaying = false;
	}

	// Token: 0x170000FE RID: 254
	// (get) Token: 0x0600066D RID: 1645 RVA: 0x00006902 File Offset: 0x00004B02
	public UFOBonusEntity Parent
	{
		get
		{
			return this.m_pParent;
		}
	}

	// Token: 0x170000FF RID: 255
	// (get) Token: 0x0600066E RID: 1646 RVA: 0x0000690A File Offset: 0x00004B0A
	public Transform Transform
	{
		get
		{
			return this.m_pTransform;
		}
	}

	// Token: 0x0600066F RID: 1647 RVA: 0x00032354 File Offset: 0x00030554
	public void Awake()
	{
		this.m_pParent = base.gameObject.transform.parent.GetComponent<UFOBonusEntity>();
		this.m_pCollider = base.GetComponent<BoxCollider>();
		this.m_InitialPos = base.transform.localPosition;
		this.m_pRayParticles[0] = base.transform.Find("fx_alien_beam_activated").particleSystem;
		this.m_pRayParticles[1] = base.transform.Find("fx_alien_good").particleSystem;
		this.m_pRayParticles[2] = base.transform.Find("fx_alien_bad").particleSystem;
		this.ApparitionParticleGO = (GameObject)UnityEngine.Object.Instantiate(this.ApparitionParticle);
		this.ApparitionParticleGO.transform.parent = this.m_pParent.transform.parent;
		this.m_InitialParticlePos = this.m_pRayParticles[0].gameObject.transform.localPosition;
		this.m_InitialBoxCenter = this.m_pCollider.center;
		this.m_pTransform = base.transform;
		this.m_iLayerVehicle = 1 << LayerMask.NameToLayer("Vehicle");
		string name = base.gameObject.name;
		this.m_iUfoIndex = name.Substring(name.Length - 1, 1);
	}

	// Token: 0x06000670 RID: 1648 RVA: 0x00032498 File Offset: 0x00030698
	public void Launch(Vector3 _FinalPosition, float _Timer, float Dist)
	{
		this.m_pFinalPosition = _FinalPosition;
		float magnitude = (this.m_pFinalPosition - this.m_pTransform.position).magnitude;
		this.m_Speed = magnitude / _Timer;
		this.m_Direction = (this.m_pFinalPosition - this.m_pTransform.position).normalized;
		this.m_fScale = Dist;
		if (this.m_pAnimator)
		{
			this.m_pAnimator.Play("UFO_Run" + this.m_iUfoIndex);
		}
	}

	// Token: 0x06000671 RID: 1649 RVA: 0x00006912 File Offset: 0x00004B12
	public void MoveToTarget(Kart _Target, float _Timer)
	{
		this.m_pTarget = _Target;
		this.m_Timer = _Timer;
	}

	// Token: 0x06000672 RID: 1650 RVA: 0x00006922 File Offset: 0x00004B22
	public void Reset()
	{
		this.m_pTransform.localPosition = this.m_InitialPos;
		this.GoodRay = false;
		this.m_pTarget = null;
		this.DeactivateComponents();
		this.m_bLeaveIsPlaying = false;
		base.gameObject.SetActive(false);
	}

	// Token: 0x06000673 RID: 1651 RVA: 0x0000695C File Offset: 0x00004B5C
	public void DeactivateComponents()
	{
		this.DeactivateCollider();
		this.DeactivateParticle();
	}

	// Token: 0x06000674 RID: 1652 RVA: 0x0000696A File Offset: 0x00004B6A
	public void DeactivateCollider()
	{
		this.m_pCollider.center = this.m_InitialBoxCenter;
		this.m_pCollider.enabled = false;
	}

	// Token: 0x06000675 RID: 1653 RVA: 0x0003252C File Offset: 0x0003072C
	public void DeactivateParticle()
	{
		for (int i = 0; i < this.m_pRayParticles.Length; i++)
		{
			this.m_pRayParticles[i].gameObject.transform.localPosition = this.m_InitialParticlePos;
			this.m_pRayParticles[i].Stop();
			this.m_pRayParticles[i].gameObject.SetActive(false);
		}
	}

	// Token: 0x06000676 RID: 1654 RVA: 0x00032590 File Offset: 0x00030790
	public void InPlace(bool _ActiveComponents)
	{
		this.m_pTransform.position = this.m_pFinalPosition;
		if (_ActiveComponents)
		{
			this.m_pCollider.center -= Vector3.up * ((this.m_pParent.UfoHeight + 2f) / 2f);
			Vector3 size = this.m_pCollider.size;
			size.x = this.m_fScale;
			size.y = this.m_pParent.UfoHeight + 2f;
			size.z = this.m_fScale;
			this.m_pCollider.size = size;
			this.m_pCollider.enabled = true;
			if (this.m_pAnimator)
			{
				this.m_pAnimator.Play("UFO_Launch");
			}
			for (int i = 0; i < this.m_pRayParticles.Length; i++)
			{
				this.m_pRayParticles[i].gameObject.SetActive(true);
				this.m_pRayParticles[i].gameObject.transform.position -= Vector3.up * (this.m_pParent.UfoHeight + 1f);
				this.m_pRayParticles[i].startSize = this.m_fScale * 2f;
				this.m_pRayParticles[i].Play();
			}
			this.m_pRayParticles[1].renderer.enabled = false;
			this.m_pRayParticles[2].renderer.enabled = false;
		}
	}

	// Token: 0x06000677 RID: 1655 RVA: 0x00032718 File Offset: 0x00030918
	public void Move(float _deltaTime)
	{
		if (this.m_pTarget != null)
		{
			this.m_Timer -= _deltaTime;
			this.m_pFinalPosition = this.m_pTarget.GetPosition() + Vector3.up * this.m_pParent.UfoHeight;
			float magnitude = (this.m_pFinalPosition - this.m_pTransform.position).magnitude;
			this.m_Speed = magnitude / this.m_Timer;
			this.m_Direction = (this.m_pFinalPosition - this.m_pTransform.position).normalized;
		}
		this.m_pTransform.position += this.m_Direction * this.m_Speed * _deltaTime;
	}

	// Token: 0x06000678 RID: 1656 RVA: 0x000327F0 File Offset: 0x000309F0
	public virtual void OnTriggerEnter(Collider other)
	{
		if (Network.isServer)
		{
			if (other.gameObject.networkView != null)
			{
				NetworkViewID viewID = other.gameObject.networkView.viewID;
				base.networkView.RPC("OnNetworkViewTriggerEnter", RPCMode.All, new object[]
				{
					viewID
				});
			}
		}
		else if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoOnTriggerEnter(other.gameObject);
		}
	}

	// Token: 0x06000679 RID: 1657 RVA: 0x0003286C File Offset: 0x00030A6C
	[RPC]
	public void OnNetworkViewTriggerEnter(NetworkViewID viewId)
	{
		NetworkView networkView = NetworkView.Find(viewId);
		if (networkView != null)
		{
			this.DoOnTriggerEnter(networkView.gameObject);
		}
	}

	// Token: 0x0600067A RID: 1658 RVA: 0x00032898 File Offset: 0x00030A98
	public void DoOnTriggerEnter(GameObject other)
	{
		if (this.m_pCollider.enabled)
		{
			int num = 1 << other.layer;
			if ((num & this.m_iLayerVehicle) != 0)
			{
				Kart componentInChildren = other.GetComponentInChildren<Kart>();
				if (componentInChildren != null && this.m_pParent != null)
				{
					if (componentInChildren.OnUfoCatchMe != null)
					{
						componentInChildren.OnUfoCatchMe(componentInChildren);
					}
					ParfumeBonusEffect parfumeBonusEffect = (ParfumeBonusEffect)componentInChildren.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_ATTRACTED);
					if (!parfumeBonusEffect.Activated || parfumeBonusEffect.StinkParfume)
					{
						if (!this.GoodRay)
						{
							this.m_pRayParticles[0].gameObject.SetActive(false);
							this.m_pRayParticles[2].renderer.enabled = true;
							this.m_pParent.MatchToTarget(this, componentInChildren);
							LevitateBonusEffect levitateBonusEffect = componentInChildren.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_LEVITATE) as LevitateBonusEffect;
							levitateBonusEffect.Owner = this;
							componentInChildren.GetBonusMgr().GetBonusEffectMgr().ActivateBonusEffect(EBonusEffect.BONUSEFFECT_LEVITATE);
							this.DeactivateCollider();
							if (this.m_pAnimator)
							{
								this.m_pAnimator.Play("UFO_Suck");
							}
							if (Singleton<GameManager>.Instance.GameMode != null && Singleton<GameManager>.Instance.GameMode.Hud != null)
							{
								Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp.SetUfoToBad();
							}
							if (this.SoundBad)
							{
								this.SoundBad.Play();
							}
							componentInChildren.KartSound.PlayVoice(KartSound.EVoices.Bad);
							if (this.m_pParent && this.m_pParent.Launcher && this.m_pParent.Launcher != componentInChildren)
							{
								this.m_pParent.Launcher.KartSound.PlayVoice(KartSound.EVoices.Good);
								this.m_pParent.Launcher.Anim.LaunchSuccessAnim(true);
							}
						}
						else
						{
							this.m_pRayParticles[0].gameObject.SetActive(false);
							this.m_pRayParticles[1].renderer.enabled = true;
							if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
							{
								this.m_pParent.RemoveUFO(true);
							}
							if (Singleton<GameManager>.Instance.GameMode != null && Singleton<GameManager>.Instance.GameMode.Hud != null)
							{
								Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp.SetUfoToGood();
							}
							if (this.SoundGood)
							{
								this.SoundGood.Play();
							}
							if (this.m_pParent && this.m_pParent.Launcher)
							{
								this.m_pParent.Launcher.KartSound.PlayVoice(KartSound.EVoices.Bad);
							}
							componentInChildren.KartSound.PlayVoice(KartSound.EVoices.Good);
							componentInChildren.Anim.LaunchSuccessAnim(true);
						}
					}
				}
			}
		}
	}

	// Token: 0x0600067B RID: 1659 RVA: 0x00006989 File Offset: 0x00004B89
	public Vector3 GetPosition()
	{
		return this.m_pTransform.position;
	}

	// Token: 0x0600067C RID: 1660 RVA: 0x00032BA4 File Offset: 0x00030DA4
	public void PlayLeaveAnim()
	{
		this.ApparitionParticleGO.transform.position = this.m_pTransform.position;
		this.ApparitionParticleGO.particleSystem.Play();
		this.DeactivateComponents();
		if (this.m_pAnimator)
		{
			this.m_pAnimator.Play("UFO_Leave");
		}
		this.m_bLeaveIsPlaying = true;
		if (this.SoundDisappear && this.SoundBad)
		{
			this.SoundDisappear.Play();
			this.SoundBad.Stop();
		}
	}

	// Token: 0x0600067D RID: 1661 RVA: 0x00006996 File Offset: 0x00004B96
	public void Leave()
	{
		this.m_bLeaveIsPlaying = false;
		base.gameObject.SetActive(false);
	}

	// Token: 0x0600067E RID: 1662 RVA: 0x000069AB File Offset: 0x00004BAB
	public bool AnimLeaveIsPlaying()
	{
		return this.m_bLeaveIsPlaying;
	}

	// Token: 0x0600067F RID: 1663 RVA: 0x000069B3 File Offset: 0x00004BB3
	public void Appear()
	{
		base.gameObject.SetActive(true);
		this.ApparitionParticleGO.transform.position = this.m_pTransform.position;
		this.ApparitionParticleGO.particleSystem.Play();
	}

	// Token: 0x06000680 RID: 1664 RVA: 0x000069EC File Offset: 0x00004BEC
	public void Idle()
	{
		if (this.m_pAnimator)
		{
			this.m_pAnimator.Play("UFO_Idle" + this.m_iUfoIndex);
		}
	}

	// Token: 0x06000681 RID: 1665 RVA: 0x00006A1A File Offset: 0x00004C1A
	public void RemoveUFO(bool _All)
	{
		this.m_pParent.RemoveUFO(_All);
	}

	// Token: 0x0400064E RID: 1614
	private BoxCollider m_pCollider;

	// Token: 0x0400064F RID: 1615
	private ParticleSystem[] m_pRayParticles = new ParticleSystem[3];

	// Token: 0x04000650 RID: 1616
	public GameObject ApparitionParticle;

	// Token: 0x04000651 RID: 1617
	private GameObject ApparitionParticleGO;

	// Token: 0x04000652 RID: 1618
	private Vector3 m_InitialParticlePos;

	// Token: 0x04000653 RID: 1619
	private Vector3 m_InitialBoxCenter;

	// Token: 0x04000654 RID: 1620
	private Vector3 m_InitialPos;

	// Token: 0x04000655 RID: 1621
	private Transform m_pTransform;

	// Token: 0x04000656 RID: 1622
	private Vector3 m_pFinalPosition;

	// Token: 0x04000657 RID: 1623
	private float m_Speed;

	// Token: 0x04000658 RID: 1624
	private Vector3 m_Direction;

	// Token: 0x04000659 RID: 1625
	private float m_fScale;

	// Token: 0x0400065A RID: 1626
	private UFOBonusEntity m_pParent;

	// Token: 0x0400065B RID: 1627
	private string m_iUfoIndex;

	// Token: 0x0400065C RID: 1628
	private int m_iLayerVehicle;

	// Token: 0x0400065D RID: 1629
	private Kart m_pTarget;

	// Token: 0x0400065E RID: 1630
	private float m_Timer;

	// Token: 0x0400065F RID: 1631
	public bool GoodRay;

	// Token: 0x04000660 RID: 1632
	public Animation m_pAnimator;

	// Token: 0x04000661 RID: 1633
	private bool m_bLeaveIsPlaying;

	// Token: 0x04000662 RID: 1634
	public AudioSource SoundGood;

	// Token: 0x04000663 RID: 1635
	public AudioSource SoundBad;

	// Token: 0x04000664 RID: 1636
	public AudioSource SoundDisappear;

	// Token: 0x04000665 RID: 1637
	public float LevitateOffset;

	// Token: 0x020000EE RID: 238
	public enum ParticleName
	{
		// Token: 0x04000667 RID: 1639
		NORMAL_RAY,
		// Token: 0x04000668 RID: 1640
		GOOD_RAY,
		// Token: 0x04000669 RID: 1641
		BAD_RAY
	}
}

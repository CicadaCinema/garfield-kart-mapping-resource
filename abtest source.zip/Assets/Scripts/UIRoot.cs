﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000081 RID: 129
[AddComponentMenu("NGUI/UI/Root")]
[ExecuteInEditMode]
public class UIRoot : MonoBehaviour
{
	// Token: 0x170000A9 RID: 169
	// (get) Token: 0x06000393 RID: 915 RVA: 0x00004BB1 File Offset: 0x00002DB1
	public static List<UIRoot> list
	{
		get
		{
			return UIRoot.mRoots;
		}
	}

	// Token: 0x170000AA RID: 170
	// (get) Token: 0x06000394 RID: 916 RVA: 0x000203F8 File Offset: 0x0001E5F8
	public int activeHeight
	{
		get
		{
			int num = Mathf.Max(2, Screen.height);
			if (this.scalingStyle == UIRoot.Scaling.FixedSize)
			{
				return this.manualHeight;
			}
			if (num < this.minimumHeight)
			{
				return this.minimumHeight;
			}
			if (num > this.maximumHeight)
			{
				return this.maximumHeight;
			}
			return num;
		}
	}

	// Token: 0x170000AB RID: 171
	// (get) Token: 0x06000395 RID: 917 RVA: 0x00004BB8 File Offset: 0x00002DB8
	public float pixelSizeAdjustment
	{
		get
		{
			return this.GetPixelSizeAdjustment(Screen.height);
		}
	}

	// Token: 0x06000396 RID: 918 RVA: 0x0002044C File Offset: 0x0001E64C
	public static float GetPixelSizeAdjustment(GameObject go)
	{
		UIRoot uiroot = NGUITools.FindInParents<UIRoot>(go);
		return (!(uiroot != null)) ? 1f : uiroot.pixelSizeAdjustment;
	}

	// Token: 0x06000397 RID: 919 RVA: 0x0002047C File Offset: 0x0001E67C
	public float GetPixelSizeAdjustment(int height)
	{
		height = Mathf.Max(2, height);
		if (this.scalingStyle == UIRoot.Scaling.FixedSize)
		{
			return (float)this.manualHeight / (float)height;
		}
		if (height < this.minimumHeight)
		{
			return (float)this.minimumHeight / (float)height;
		}
		if (height > this.maximumHeight)
		{
			return (float)this.maximumHeight / (float)height;
		}
		return 1f;
	}

	// Token: 0x06000398 RID: 920 RVA: 0x00004BC5 File Offset: 0x00002DC5
	private void Awake()
	{
		this.mTrans = base.transform;
		UIRoot.mRoots.Add(this);
		if (this.automatic)
		{
			this.scalingStyle = UIRoot.Scaling.PixelPerfect;
			this.automatic = false;
		}
	}

	// Token: 0x06000399 RID: 921 RVA: 0x00004BF7 File Offset: 0x00002DF7
	private void OnDestroy()
	{
		UIRoot.mRoots.Remove(this);
	}

	// Token: 0x0600039A RID: 922 RVA: 0x000204DC File Offset: 0x0001E6DC
	private void Start()
	{
		UIOrthoCamera componentInChildren = base.GetComponentInChildren<UIOrthoCamera>();
		if (componentInChildren != null)
		{
			Debug.LogWarning("UIRoot should not be active at the same time as UIOrthoCamera. Disabling UIOrthoCamera.", componentInChildren);
			Camera component = componentInChildren.gameObject.GetComponent<Camera>();
			componentInChildren.enabled = false;
			if (component != null)
			{
				component.orthographicSize = 1f;
			}
		}
	}

	// Token: 0x0600039B RID: 923 RVA: 0x00020534 File Offset: 0x0001E734
	private void Update()
	{
		if (this.mTrans != null)
		{
			float num = (float)this.activeHeight;
			if (num > 0f)
			{
				float num2 = 2f / num;
				Vector3 localScale = this.mTrans.localScale;
				if (Mathf.Abs(localScale.x - num2) > 1.401298E-45f || Mathf.Abs(localScale.y - num2) > 1.401298E-45f || Mathf.Abs(localScale.z - num2) > 1.401298E-45f)
				{
					this.mTrans.localScale = new Vector3(num2, num2, num2);
				}
			}
		}
	}

	// Token: 0x0600039C RID: 924 RVA: 0x000205D4 File Offset: 0x0001E7D4
	public static void Broadcast(string funcName)
	{
		int i = 0;
		int count = UIRoot.mRoots.Count;
		while (i < count)
		{
			UIRoot uiroot = UIRoot.mRoots[i];
			if (uiroot != null)
			{
				uiroot.BroadcastMessage(funcName, SendMessageOptions.DontRequireReceiver);
			}
			i++;
		}
	}

	// Token: 0x0600039D RID: 925 RVA: 0x00020620 File Offset: 0x0001E820
	public static void Broadcast(string funcName, object param)
	{
		if (param == null)
		{
			Debug.LogError("SendMessage is bugged when you try to pass 'null' in the parameter field. It behaves as if no parameter was specified.");
		}
		else
		{
			int i = 0;
			int count = UIRoot.mRoots.Count;
			while (i < count)
			{
				UIRoot uiroot = UIRoot.mRoots[i];
				if (uiroot != null)
				{
					uiroot.BroadcastMessage(funcName, param, SendMessageOptions.DontRequireReceiver);
				}
				i++;
			}
		}
	}

	// Token: 0x04000310 RID: 784
	private static List<UIRoot> mRoots = new List<UIRoot>();

	// Token: 0x04000311 RID: 785
	public UIRoot.Scaling scalingStyle = UIRoot.Scaling.FixedSize;

	// Token: 0x04000312 RID: 786
	[HideInInspector]
	public bool automatic;

	// Token: 0x04000313 RID: 787
	public int manualHeight = 720;

	// Token: 0x04000314 RID: 788
	public int minimumHeight = 320;

	// Token: 0x04000315 RID: 789
	public int maximumHeight = 1536;

	// Token: 0x04000316 RID: 790
	private Transform mTrans;

	// Token: 0x02000082 RID: 130
	public enum Scaling
	{
		// Token: 0x04000318 RID: 792
		PixelPerfect,
		// Token: 0x04000319 RID: 793
		FixedSize,
		// Token: 0x0400031A RID: 794
		FixedSizeOnMobiles
	}
}

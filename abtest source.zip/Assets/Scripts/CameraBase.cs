﻿using System;
using UnityEngine;

// Token: 0x020001F2 RID: 498
public class CameraBase : MonoBehaviour
{
	// Token: 0x170001D3 RID: 467
	// (get) Token: 0x06000D77 RID: 3447 RVA: 0x0000B323 File Offset: 0x00009523
	// (set) Token: 0x06000D78 RID: 3448 RVA: 0x00057A8C File Offset: 0x00055C8C
	public ECamState CurrentState
	{
		get
		{
			return this.m_CurrentState;
		}
		protected set
		{
			if (value != this.m_CurrentState)
			{
				if (this.m_CurrentState != ECamState.None)
				{
					this.GetCurrentStateClass().Exit();
				}
				this.m_PrevState = this.m_CurrentState;
				this.m_CurrentState = value;
				if (this.m_CurrentState > ECamState.None)
				{
					if (this.m_PrevState != ECamState.None)
					{
						this.GetCurrentStateClass().Enter(this.CamStates[(int)this.m_PrevState].m_Transform, this.CamStates[(int)this.m_PrevState].m_Target);
					}
					else
					{
						this.GetCurrentStateClass().Enter(base.transform, null);
					}
				}
			}
		}
	}

	// Token: 0x06000D79 RID: 3449 RVA: 0x00057B30 File Offset: 0x00055D30
	public void Start()
	{
		CamState[] components = base.GetComponents<CamState>();
		foreach (CamState camState in components)
		{
			if (this.CamStates[(int)camState.state] == null)
			{
				this.CamStates[(int)camState.state] = camState;
			}
		}
		this.m_pTransform = base.transform;
		this.m_PrevState = ECamState.None;
		this.CurrentState = this.m_StartState;
	}

	// Token: 0x06000D7A RID: 3450 RVA: 0x00057BA8 File Offset: 0x00055DA8
	public void FixedUpdate()
	{
		if (this.CurrentState == ECamState.None)
		{
			return;
		}
		ECamState currentState = this.CurrentState;
		ECamState currentState2 = this.GetCurrentStateClass().Manage(Time.fixedDeltaTime);
		this.m_pTransform.position = this.GetCurrentStateClass().m_Transform.position;
		this.m_pTransform.rotation = this.GetCurrentStateClass().m_Transform.rotation;
		if (currentState == this.CurrentState)
		{
			this.CurrentState = currentState2;
		}
	}

	// Token: 0x06000D7B RID: 3451 RVA: 0x0000B32B File Offset: 0x0000952B
	protected CamState GetCurrentStateClass()
	{
		return this.CamStates[(int)this.m_CurrentState];
	}

	// Token: 0x06000D7C RID: 3452 RVA: 0x0000B33A File Offset: 0x0000953A
	public void SwitchCamera(ECamState _newCam, ECamState _transition)
	{
		if (_transition < ECamState.TransCut)
		{
		}
		((CamStateTransition)this.CamStates[(int)_transition]).Setup(this.GetCurrentStateClass(), this.CamStates[(int)_newCam], true);
		this.CurrentState = _transition;
	}

	// Token: 0x04000D22 RID: 3362
	public ECamState m_StartState;

	// Token: 0x04000D23 RID: 3363
	private ECamState m_PrevState;

	// Token: 0x04000D24 RID: 3364
	private Transform m_pTransform;

	// Token: 0x04000D25 RID: 3365
	private ECamState m_CurrentState = ECamState.None;

	// Token: 0x04000D26 RID: 3366
	protected CamState[] CamStates = new CamState[9];
}

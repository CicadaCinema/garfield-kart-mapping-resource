﻿using System;

// Token: 0x020001AB RID: 427
public class MenuRewardsCustomUnlocked : MenuRewards
{
	// Token: 0x06000B77 RID: 2935 RVA: 0x0004CE74 File Offset: 0x0004B074
	public override void OnEnter()
	{
		base.OnEnter();
		Tuple<string, ERarity> tuple = Singleton<RewardManager>.Instance.PopUnlockedCustom();
		this._custom = tuple.Item1;
		this._rarity = tuple.Item2;
		Tuple<string, UIAtlas, string, ERarity> infos = base.GetInfos(this._custom, E_RewardType.Custom);
		this.LbRewardName.text = infos.Item1;
		if (this.Sprite != null)
		{
			this.Sprite.spriteName = infos.Item3;
		}
		if (this.SpriteRarity != null)
		{
			this.SpriteRarity.ChangeTexture(Tricks.LogBase2((int)infos.Item4));
		}
		this.LbMessage.text = Localization.instance.Get("MENU_REWARDS_CUSTOMITATIONS_UNITAIRE");
		this.LTradePrice.text = this.TradePrice.ToString();
	}

	// Token: 0x06000B78 RID: 2936 RVA: 0x0004CF44 File Offset: 0x0004B144
	public void OnTrade()
	{
		this._keepCusto = false;
		if (Singleton<GameSaveManager>.Instance.GetCoins() > this.TradePrice)
		{
			Singleton<GameSaveManager>.Instance.SpendCoins(this.TradePrice, false);
			Singleton<RewardManager>.Instance.TradeReward(this._rarity);
		}
		this.OnGoNext();
	}

	// Token: 0x06000B79 RID: 2937 RVA: 0x00009FEC File Offset: 0x000081EC
	public override void OnGoNext()
	{
		if (this._keepCusto)
		{
			Singleton<GameSaveManager>.Instance.SetCustomState(this._custom, E_UnlockableItemSate.NewUnlocked, false);
		}
		base.OnGoNext();
	}

	// Token: 0x04000B37 RID: 2871
	private bool _keepCusto = true;

	// Token: 0x04000B38 RID: 2872
	private string _custom;

	// Token: 0x04000B39 RID: 2873
	private ERarity _rarity;

	// Token: 0x04000B3A RID: 2874
	public int TradePrice;

	// Token: 0x04000B3B RID: 2875
	public UILabel LTradePrice;
}

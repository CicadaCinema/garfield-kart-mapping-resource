﻿using System;
using UnityEngine;

// Token: 0x0200023D RID: 573
public class ManageRenderSettings : MonoBehaviour
{
	// Token: 0x06001013 RID: 4115 RVA: 0x00065CC8 File Offset: 0x00063EC8
	public void Update()
	{
		RenderSettings.fog = true;
		RenderSettings.fogMode = FogMode.Linear;
		RenderSettings.fogColor = this.fogColor;
		RenderSettings.fogDensity = this.fogDensite;
		RenderSettings.ambientLight = this.ambientLight;
		RenderSettings.fogStartDistance = this.FStartDistance;
		RenderSettings.fogEndDistance = this.FEndDistance;
	}

	// Token: 0x04000F7A RID: 3962
	public float fogDensite = 0.1f;

	// Token: 0x04000F7B RID: 3963
	public Color ambientLight = new Color(0.2f, 0.3f, 0.4f, 0.5f);

	// Token: 0x04000F7C RID: 3964
	public Color fogColor = new Color(0.2f, 0.3f, 0.4f, 0.5f);

	// Token: 0x04000F7D RID: 3965
	public float FStartDistance = 1f;

	// Token: 0x04000F7E RID: 3966
	public float FEndDistance = 100f;
}

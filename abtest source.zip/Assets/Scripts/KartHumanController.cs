﻿using System;
using UnityEngine;

// Token: 0x020000F3 RID: 243
public class KartHumanController : RcHumanController
{
	// Token: 0x17000101 RID: 257
	// (get) Token: 0x060006A5 RID: 1701 RVA: 0x00006B39 File Offset: 0x00004D39
	public int LogJump
	{
		get
		{
			return this.m_iLogJump;
		}
	}

	// Token: 0x060006A6 RID: 1702 RVA: 0x00006B41 File Offset: 0x00004D41
	public override void Start()
	{
		base.Start();
	}

	// Token: 0x060006A7 RID: 1703 RVA: 0x0003406C File Offset: 0x0003226C
	public void Update()
	{
		if (base.GetVehicle().GetControlType() != RcVehicle.ControlType.Human || Time.timeScale == 0f)
		{
			return;
		}
		if (base.GetVehicle().IsAutoPilot())
		{
			return;
		}
		if (this.GetKart().IsOnGround() && !this.GetKart().IsLocked())
		{
			float action = Singleton<InputManager>.Instance.GetAction(EAction.DriftJump);
			if (action != 0f && this.GetKart().Jump(0f, 0f) && LogManager.Instance != null)
			{
				this.m_iLogJump++;
			}
		}
		if (Singleton<InputManager>.Instance.GetAction(EAction.LaunchBonus) == 1f)
		{
			this.GetKart().GetBonusMgr().ActivateBonus(false);
		}
		else if (Singleton<InputManager>.Instance.GetAction(EAction.DropBonus) == 1f)
		{
			this.GetKart().GetBonusMgr().ActivateBonus(true);
		}
	}

	// Token: 0x060006A8 RID: 1704 RVA: 0x00006B49 File Offset: 0x00004D49
	public override void Turn(float _Steer)
	{
		base.Turn(_Steer + this.Influence);
	}

	// Token: 0x060006A9 RID: 1705 RVA: 0x00006B59 File Offset: 0x00004D59
	public Kart GetKart()
	{
		return (Kart)this.m_pVehicle;
	}

	// Token: 0x0400068D RID: 1677
	public float Influence;

	// Token: 0x0400068E RID: 1678
	private int m_iLogJump;
}

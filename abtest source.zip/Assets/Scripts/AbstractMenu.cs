﻿using System;
using UnityEngine;

// Token: 0x020000FD RID: 253
public class AbstractMenu : MonoBehaviour
{
	// Token: 0x060006D6 RID: 1750 RVA: 0x00034558 File Offset: 0x00032758
	public virtual void Awake()
	{
		this.m_pMenuEntryPoint = GameObject.Find("MenuEntryPoint").GetComponent<MenuEntryPoint>();
		this.m_oMenuCamera = base.transform.GetComponentInChildren<UICamera>();
		if (this.m_oMenuCamera)
		{
			this.m_pLayerHud = this.m_oMenuCamera.eventReceiverMask;
		}
		base.transform.gameObject.SetActive(false);
	}

	// Token: 0x060006D7 RID: 1751 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void Start()
	{
	}

	// Token: 0x060006D8 RID: 1752 RVA: 0x00006CBE File Offset: 0x00004EBE
	public virtual void Update()
	{
		if (Application.platform == RuntimePlatform.Android && Input.GetKeyDown(KeyCode.Escape))
		{
			this.ActSwapMenu(EMenus.MENU_WELCOME);
		}
	}

	// Token: 0x060006D9 RID: 1753 RVA: 0x00006CE0 File Offset: 0x00004EE0
	public virtual void OnEnter()
	{
		base.gameObject.SetActive(true);
		if (this.m_pMenuEntryPoint)
		{
			this.m_pMenuEntryPoint.SetCamera(this.m_oCamera);
		}
		this.PlayMusic();
	}

	// Token: 0x060006DA RID: 1754 RVA: 0x00006D15 File Offset: 0x00004F15
	public virtual void OnEnter(int iEntryPoint)
	{
		this.OnEnter();
	}

	// Token: 0x060006DB RID: 1755 RVA: 0x00006D1D File Offset: 0x00004F1D
	public virtual void OnExit()
	{
		base.gameObject.SetActive(false);
	}

	// Token: 0x060006DC RID: 1756 RVA: 0x00006D2B File Offset: 0x00004F2B
	public virtual void OnPopupShow()
	{
		if (this.m_oMenuCamera)
		{
			this.m_oMenuCamera.eventReceiverMask = 0;
		}
	}

	// Token: 0x060006DD RID: 1757 RVA: 0x00006D4E File Offset: 0x00004F4E
	public virtual void OnPopupQuit()
	{
		if (this.m_oMenuCamera)
		{
			this.m_oMenuCamera.eventReceiverMask = this.m_pLayerHud;
		}
	}

	// Token: 0x060006DE RID: 1758 RVA: 0x000345C0 File Offset: 0x000327C0
	public GameObject FindMenu(string GameObjectName)
	{
		GameObject gameObject = GameObject.Find(GameObjectName);
		if (!gameObject)
		{
		}
		return gameObject;
	}

	// Token: 0x060006DF RID: 1759 RVA: 0x00006D71 File Offset: 0x00004F71
	public virtual void ActSwapMenu(EMenus NextMenu)
	{
		if (this.m_pMenuEntryPoint)
		{
			this.m_pMenuEntryPoint.SetState(NextMenu);
		}
	}

	// Token: 0x060006E0 RID: 1760 RVA: 0x00006D8F File Offset: 0x00004F8F
	public void ActShowPopup(EPopUps Popup)
	{
		if (this.m_pMenuEntryPoint)
		{
			this.m_pMenuEntryPoint.ShowPopup(Popup, null, true);
		}
	}

	// Token: 0x060006E1 RID: 1761 RVA: 0x00006DAF File Offset: 0x00004FAF
	public virtual void PlayMusic()
	{
		if (this.m_pMenuEntryPoint)
		{
			this.m_pMenuEntryPoint.PlayMenuMusic();
		}
	}

	// Token: 0x040006C5 RID: 1733
	protected MenuEntryPoint m_pMenuEntryPoint;

	// Token: 0x040006C6 RID: 1734
	public Camera m_oCamera;

	// Token: 0x040006C7 RID: 1735
	private UICamera m_oMenuCamera;

	// Token: 0x040006C8 RID: 1736
	protected LayerMask m_pLayerHud;
}

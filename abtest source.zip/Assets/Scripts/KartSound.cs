﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200014A RID: 330
public class KartSound : RcVehicleSnd
{
	// Token: 0x17000158 RID: 344
	// (get) Token: 0x0600094B RID: 2379 RVA: 0x00008753 File Offset: 0x00006953
	// (set) Token: 0x0600094C RID: 2380 RVA: 0x0000875B File Offset: 0x0000695B
	public bool CanSpeak
	{
		get
		{
			return this.m_bCanSpeak;
		}
		set
		{
			this.m_bCanSpeak = value;
		}
	}

	// Token: 0x17000159 RID: 345
	// (get) Token: 0x0600094D RID: 2381 RVA: 0x00008764 File Offset: 0x00006964
	// (set) Token: 0x0600094E RID: 2382 RVA: 0x0000876C File Offset: 0x0000696C
	public ECharacter Character
	{
		get
		{
			return this.m_eCharacter;
		}
		set
		{
			this.m_eCharacter = value;
		}
	}

	// Token: 0x0600094F RID: 2383 RVA: 0x00042048 File Offset: 0x00040248
	public override void Start()
	{
		base.Start();
		this.CanSpeak = false;
		this.m_iLastRank = -1;
		int length = Enum.GetValues(typeof(KartSound.EVoices)).Length;
		this.m_iNbBadVoices = (this.m_iNbColVoices = (this.m_iNbGoodVoices = 0));
		for (int i = 0; i < length; i++)
		{
			if (((KartSound.EVoices)i).ToString().Contains("Good"))
			{
				this.m_iNbGoodVoices++;
			}
			else if (((KartSound.EVoices)i).ToString().Contains("Bad"))
			{
				this.m_iNbBadVoices++;
			}
			else if (((KartSound.EVoices)i).ToString().Contains("Collision"))
			{
				this.m_iNbColVoices++;
			}
		}
	}

	// Token: 0x06000950 RID: 2384 RVA: 0x0004212C File Offset: 0x0004032C
	public override void Update()
	{
		base.Update();
		Kart kart = (Kart)this.m_pVehicle;
		for (int i = 0; i < kart.GetVehiclePhysic().GetNbWheels(); i++)
		{
			int surface = kart.GetGroundCharac(i).surface;
			if ((1 << surface & this.WaterLayer.value) != 0)
			{
				base.PlaySound(9);
			}
			else if ((1 << surface & this.KillLayer.value) != 0)
			{
				base.PlaySound(8);
			}
		}
		int rank = kart.RaceStats.GetRank();
		if (this.m_iLastRank != rank)
		{
			if (rank < this.m_iLastRank)
			{
				int num = Singleton<RandomManager>.Instance.Next(0, 4);
				if (num < 3)
				{
					kart.KartSound.PlayVoice(KartSound.EVoices.Good);
				}
			}
			this.m_iLastRank = rank;
		}
	}

	// Token: 0x06000951 RID: 2385 RVA: 0x00008775 File Offset: 0x00006975
	public void StartVoices()
	{
		this.CanSpeak = true;
	}

	// Token: 0x06000952 RID: 2386 RVA: 0x00042208 File Offset: 0x00040408
	public void PlayVoice(KartSound.EVoices eVoice)
	{
		if (!this.CanSpeak)
		{
			return;
		}
		int num = 0;
		if (eVoice == KartSound.EVoices.Good || eVoice == KartSound.EVoices.Bad || eVoice == KartSound.EVoices.Collision)
		{
			num = Singleton<RandomManager>.Instance.Next(0, ((eVoice != KartSound.EVoices.Good) ? ((eVoice != KartSound.EVoices.Bad) ? this.m_iNbColVoices : this.m_iNbBadVoices) : this.m_iNbGoodVoices) - 1);
		}
		int index = (int)((int)(eVoice + num) * (Enum.GetValues(typeof(ECharacter)).Length - 1) + this.m_eCharacter);
        if (this.VoiceList[index] != null && this.VoiceAudioSource != null && !this.VoiceAudioSource.isPlaying)
		{
			this.VoiceAudioSource.clip = this.VoiceList[index];
			this.VoiceAudioSource.Play();
			if (eVoice == KartSound.EVoices.Snore)
			{
				this.VoiceAudioSource.loop = true;
			}
		}
	}

	// Token: 0x06000953 RID: 2387 RVA: 0x0000877E File Offset: 0x0000697E
	public void StopVoice()
	{
		if (this.VoiceAudioSource != null && this.VoiceAudioSource.isPlaying)
		{
			this.VoiceAudioSource.Stop();
			this.VoiceAudioSource.loop = false;
		}
	}

	// Token: 0x06000954 RID: 2388 RVA: 0x00042300 File Offset: 0x00040500
	public override void ApplyVolume()
	{
		base.ApplyVolume();
		float sfxVolume = Singleton<GameOptionManager>.Instance.GetSfxVolume();
		if (this.VoiceAudioSource)
		{
			this.VoiceAudioSource.volume = sfxVolume;
		}
	}

	// Token: 0x06000955 RID: 2389 RVA: 0x000087B8 File Offset: 0x000069B8
	public override void PlayCollisionSound(bool bOther)
	{
		base.PlayCollisionSound(bOther);
		this.PlayVoice(KartSound.EVoices.Collision);
	}

	// Token: 0x06000956 RID: 2390 RVA: 0x0004233C File Offset: 0x0004053C
	public override int GetSkidSound()
	{
		Kart kart = (Kart)this.m_pVehicle;
		if (kart.MiniBoost < kart.ThresholdMiniBoost)
		{
			base.StopSound(19);
			return base.GetSkidSound();
		}
		base.StopSound(3);
		return 19;
	}

	// Token: 0x04000973 RID: 2419
	public LayerMask WaterLayer;

	// Token: 0x04000974 RID: 2420
	public LayerMask KillLayer;

	// Token: 0x04000975 RID: 2421
	private ECharacter m_eCharacter;

	// Token: 0x04000976 RID: 2422
	private int m_iNbGoodVoices;

	// Token: 0x04000977 RID: 2423
	private int m_iNbBadVoices;

	// Token: 0x04000978 RID: 2424
	private int m_iNbColVoices;

	// Token: 0x04000979 RID: 2425
	private int m_iLastRank;

	// Token: 0x0400097A RID: 2426
	public AudioSource VoiceAudioSource;

	// Token: 0x0400097B RID: 2427
	[HideInInspector]
	public List<AudioClip> VoiceList = new List<AudioClip>();

	// Token: 0x0400097C RID: 2428
	private bool m_bCanSpeak = true;

	// Token: 0x0200014B RID: 331
	public enum EKartSounds
	{
		// Token: 0x0400097E RID: 2430
		SND_MINIBOOST_OK = 7,
		// Token: 0x0400097F RID: 2431
		SND_FALL,
		// Token: 0x04000980 RID: 2432
		SND_FALL_WATER,
		// Token: 0x04000981 RID: 2433
		SND_TAKE_BONUS,
		// Token: 0x04000982 RID: 2434
		SND_CRASHED,
		// Token: 0x04000983 RID: 2435
		SND_SLIDE,
		// Token: 0x04000984 RID: 2436
		SND_ASLEEP,
		// Token: 0x04000985 RID: 2437
		SND_TELEPORTED,
		// Token: 0x04000986 RID: 2438
		SND_LEVITATE,
		// Token: 0x04000987 RID: 2439
		SND_SPRING,
		// Token: 0x04000988 RID: 2440
		SND_LASAGNA,
		// Token: 0x04000989 RID: 2441
		SND_TAKE_COINS,
		// Token: 0x0400098A RID: 2442
		SND_SKID2
	}

	// Token: 0x0200014C RID: 332
	public enum EVoices
	{
		// Token: 0x0400098C RID: 2444
		Awake,
		// Token: 0x0400098D RID: 2445
		Snore,
		// Token: 0x0400098E RID: 2446
		Good,
		// Token: 0x0400098F RID: 2447
		Good2,
		// Token: 0x04000990 RID: 2448
		Bad,
		// Token: 0x04000991 RID: 2449
		Bad2,
		// Token: 0x04000992 RID: 2450
		Collision,
		// Token: 0x04000993 RID: 2451
		Collision2,
		// Token: 0x04000994 RID: 2452
		Selection
	}
}

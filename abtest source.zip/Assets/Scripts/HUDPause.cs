﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000115 RID: 277
public class HUDPause : MonoBehaviour
{
	// Token: 0x1700012F RID: 303
	// (get) Token: 0x0600079A RID: 1946 RVA: 0x000076FB File Offset: 0x000058FB
	public GameObject PanelPauseChampionship
	{
		get
		{
			return this.m_pPanelPauseChampionship;
		}
	}

	// Token: 0x0600079B RID: 1947 RVA: 0x00037FE0 File Offset: 0x000361E0
	public void Awake()
	{
		this.m_oNetworkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
		this.m_pPanelPauseChampionship = null;
		this.m_pPanelPauseRaceMultiClient = null;
		this.m_pPanelPauseRace = null;
		this.m_pButtonRetryChampionship = null;
		this.m_pHudInGame = null;
		this.m_bEndOfRace = false;
		this.m_oLastPauseBeforeOptions = null;
		if (this.PrevButton)
		{
			this.PrevButton.SetActive(true);
		}
	}

	// Token: 0x0600079C RID: 1948 RVA: 0x00038054 File Offset: 0x00036254
	public void Start()
	{
		this.m_bPause = false;
		this.m_pHudInGame = base.gameObject.GetComponent<HUDInGame>();
		this.m_pPanelPauseChampionship = base.transform.Find("Camera/PanelPauseChampionship").gameObject;
		this.m_pPanelPauseRace = base.transform.Find("Camera/PanelPauseRace").gameObject;
		this.m_pControlsPanel = base.transform.Find("Camera/PanelOptionControles").gameObject;
		if (this.m_pControlsPanel)
		{
			this.m_pControlsPanel.SetActive(false);
		}
		if (this.m_pPanelPauseChampionship != null)
		{
			this.m_pButtonRetryChampionship = this.m_pPanelPauseChampionship.transform.Find("PanelButtonsPause/Anchor_Center/ButtonRecommencer").gameObject;
			this.m_pOptionsPauseChampionship = this.m_pPanelPauseChampionship.transform.Find("PanelButtonsPause/Anchor_Center/ButtonOptions").gameObject;
			if (this.m_pOptionsPauseChampionship)
			{
				if (Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
				{
					this.m_pOptionsPauseChampionship.SetActive(false);
				}
				if (Singleton<ChallengeManager>.Instance.IsActive)
				{
					this.m_pButtonRetryChampionship.SetActive(false);
				}
			}
			this.m_pPanelPauseChampionship.SetActive(false);
		}
		if (this.m_pPanelPauseRace != null)
		{
			this.m_pOptionsPauseRace = this.m_pPanelPauseRace.transform.Find("PanelButtonsPause/Anchor_Center/ButtonOptions").gameObject;
			this.m_pChangeTrackRace = this.m_pPanelPauseRace.transform.Find("PanelButtonsPause/Anchor_Center/ButtonChangerCircuit").gameObject;
			this.m_pChangeCharacterRace = this.m_pPanelPauseRace.transform.Find("PanelButtonsPause/Anchor_Center/ButtonChangePersonage").gameObject;
			this.m_pRetryRace = this.m_pPanelPauseRace.transform.Find("PanelButtonsPause/Anchor_Center/ButtonRecommencer").gameObject;
			if (this.m_pOptionsPauseRace)
			{
				if (Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
				{
					this.m_pOptionsPauseRace.SetActive(false);
				}
				if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
				{
					this.m_pChangeTrackRace.SetActive(false);
					this.m_pChangeCharacterRace.SetActive(false);
				}
				if (Singleton<ChallengeManager>.Instance.IsActive)
				{
					this.m_pChangeTrackRace.SetActive(false);
					this.m_pChangeCharacterRace.SetActive(false);
					this.m_pRetryRace.SetActive(false);
				}
			}
			this.m_pPanelPauseRace.SetActive(false);
		}
		this.m_pPanelPauseRaceMultiClient = base.transform.Find("Camera/PanelPauseRaceMultiClient").gameObject;
		if (this.m_pPanelPauseRaceMultiClient)
		{
			this.m_pOptionsPauseRaceMulti = this.m_pPanelPauseRaceMultiClient.transform.Find("PanelButtonsPause/Anchor_Center/ButtonOptions").gameObject;
			if (this.m_pOptionsPauseRaceMulti && Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
			{
				this.m_pOptionsPauseRaceMulti.SetActive(false);
			}
			this.m_pPanelPauseRaceMultiClient.SetActive(false);
		}
	}

	// Token: 0x0600079D RID: 1949 RVA: 0x00038348 File Offset: 0x00036548
	public void Update()
	{
		if (!this.m_bEndOfRace && !this.m_pHudInGame.EndHUDDisplayed && Singleton<GameManager>.Instance.GameMode.State != E_GameState.Tutorial && Singleton<InputManager>.Instance.GetAction(EAction.Pause) == 1f)
		{
			if (!this.m_bPause)
			{
				if (Singleton<GameManager>.Instance.SoundManager)
				{
					Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.Pause);
					Kart humanKart = Singleton<GameManager>.Instance.GameMode.GetHumanKart();
					if (humanKart)
					{
						KartSound kartSound = humanKart.KartSound;
						if (kartSound)
						{
							kartSound.PauseSounds(true);
						}
					}
				}
				if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
				{
					if (this.m_pPanelPauseChampionship != null)
					{
						this.m_pPanelPauseChampionship.SetActive(true);
						if (this.m_pOptionsPauseChampionship && Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
						{
							this.m_pOptionsPauseChampionship.SetActive(false);
						}
						else
						{
							this.m_pOptionsPauseChampionship.SetActive(true);
						}
						this.ResumeChampionshipLabel.key = "HUD_PAUSE_RESUME";
						this.WaitingForServerChampionshipLabel.SetActive(false);
						this.ShowPuzzlePiece(true);
						this.Pause();
						this.NeedToShowRetry();
					}
				}
				else
				{
					if (Network.peerType != NetworkPeerType.Disconnected && Network.isClient)
					{
						if (this.m_pPanelPauseRaceMultiClient != null)
						{
							this.m_pPanelPauseRaceMultiClient.SetActive(true);
							if (this.m_pOptionsPauseRaceMulti && Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
							{
								this.m_pOptionsPauseRaceMulti.SetActive(false);
							}
							this.WaitingForServerLabel.SetActive(false);
							this.ResumeRaceMultiClientButton.SetActive(true);
							this.OptionsButtonMultiClient.SetActive(true);
						}
					}
					else if (this.m_pPanelPauseRace != null)
					{
						this.m_pPanelPauseRace.SetActive(true);
						if (this.m_pOptionsPauseRace && Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
						{
							this.m_pOptionsPauseRace.SetActive(false);
						}
						this.ShowPuzzlePiece(false);
					}
					this.Pause();
				}
				if (this.m_bPause && Network.peerType == NetworkPeerType.Disconnected)
				{
					Time.timeScale = 0f;
				}
			}
			else
			{
				this.Unpause();
				if (Time.timeScale == 1f && Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
				{
					TutorialGameMode tutorialGameMode = (TutorialGameMode)Singleton<GameManager>.Instance.GameMode;
					if (!tutorialGameMode.InstructionShown)
					{
						Time.timeScale = 0f;
					}
				}
			}
		}
	}

	// Token: 0x0600079E RID: 1950 RVA: 0x000385FC File Offset: 0x000367FC
	public void NeedToShowRetry()
	{
		if (Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantage() == EAdvantage.RestartRace && this.m_pButtonRetryChampionship)
		{
			this.m_pButtonRetryChampionship.SetActive(true);
		}
		else
		{
			this.m_pButtonRetryChampionship.SetActive(false);
		}
	}

	// Token: 0x0600079F RID: 1951 RVA: 0x0003864C File Offset: 0x0003684C
	public void ShowEndOfRace()
	{
		this.m_bEndOfRace = true;
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
		{
			this.NeedToShowRetry();
			if (Singleton<GameConfigurator>.Instance.CurrentTrackIndex < Singleton<GameConfigurator>.Instance.ChampionShipData.Tracks.Length)
			{
				this.ResumeChampionshipLabel.key = "HUD_QUITCHAMPIONSHIP_CIRCUITSUIVANT";
				if (Network.isClient)
				{
					this.ResumeChampionshipButton.SetActive(false);
					this.WaitingForServerChampionshipLabel.SetActive(true);
					this.m_pOptionsPauseChampionship.SetActive(false);
					this.PrevButton.SetActive(false);
				}
				else
				{
					this.ResumeChampionshipButton.SetActive(true);
					this.WaitingForServerChampionshipLabel.SetActive(false);
					if (this.m_pOptionsPauseChampionship && Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
					{
						this.m_pOptionsPauseChampionship.SetActive(false);
					}
					else
					{
						this.m_pOptionsPauseChampionship.SetActive(true);
					}
					this.PrevButton.SetActive(true);
				}
			}
			else
			{
				this.ResumeChampionshipLabel.key = "HUD_QUITCHAMPIONSHIP_RESULTS";
				if (Network.isClient)
				{
					this.ResumeChampionshipButton.SetActive(false);
					this.WaitingForServerChampionshipLabel.SetActive(true);
					this.m_pOptionsPauseChampionship.SetActive(false);
				}
				else
				{
					this.ResumeChampionshipButton.SetActive(true);
					this.WaitingForServerChampionshipLabel.SetActive(false);
					if (this.m_pOptionsPauseChampionship && Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
					{
						this.m_pOptionsPauseChampionship.SetActive(false);
					}
					else
					{
						this.m_pOptionsPauseChampionship.SetActive(true);
					}
				}
			}
			this.m_pPanelPauseChampionship.SetActive(true);
			this.ShowPuzzlePiece(true);
		}
		else if (Network.peerType != NetworkPeerType.Disconnected && Network.isClient)
		{
			if (this.m_pPanelPauseRaceMultiClient != null)
			{
				this.m_pPanelPauseRaceMultiClient.SetActive(true);
				this.WaitingForServerLabel.SetActive(true);
				this.ResumeRaceMultiClientButton.SetActive(false);
				this.OptionsButtonMultiClient.SetActive(false);
			}
		}
		else if (this.m_pPanelPauseRace != null)
		{
			this.m_pPanelPauseRace.SetActive(true);
			if (this.m_pOptionsPauseRace && Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
			{
				this.m_pOptionsPauseRace.SetActive(false);
			}
			this.ShowPuzzlePiece(false);
			this.ResumeRaceButton.SetActive(false);
		}
	}

	// Token: 0x060007A0 RID: 1952 RVA: 0x00007703 File Offset: 0x00005903
	public void Pause()
	{
		this.m_bPause = true;
		if (this.m_pHudInGame != null)
		{
			this.m_pHudInGame.Pause(true);
		}
	}

	// Token: 0x060007A1 RID: 1953 RVA: 0x000388C8 File Offset: 0x00036AC8
	public void Unpause()
	{
		if (this.m_bPause)
		{
			if (this.m_pControlsPanel && this.m_pControlsPanel.activeSelf)
			{
				this.OnBackOptions();
			}
			if (this.m_pPanelPauseChampionship != null)
			{
				this.m_pPanelPauseChampionship.SetActive(false);
			}
			if (this.m_pPanelPauseRace != null)
			{
				this.m_pPanelPauseRace.SetActive(false);
			}
			if (this.m_pPanelPauseRaceMultiClient != null)
			{
				this.m_pPanelPauseRaceMultiClient.SetActive(false);
			}
			this.m_bPause = false;
			if (Network.peerType == NetworkPeerType.Disconnected)
			{
				Time.timeScale = 1f;
			}
			Kart humanKart = Singleton<GameManager>.Instance.GameMode.GetHumanKart();
			if (humanKart)
			{
				KartSound kartSound = humanKart.KartSound;
				if (kartSound)
				{
					kartSound.PauseSounds(false);
				}
			}
			if (this.m_pHudInGame != null)
			{
				this.m_pHudInGame.Pause(false);
			}
			if (Singleton<GameManager>.Instance.SoundManager)
			{
				Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.Pause);
			}
		}
	}

	// Token: 0x060007A2 RID: 1954 RVA: 0x000389F0 File Offset: 0x00036BF0
	public void OnRetry()
	{
		if (!this.m_bEndOfRace)
		{
			this.Unpause();
		}
		else
		{
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
			{
				Singleton<GameConfigurator>.Instance.CurrentTrackIndex--;
			}
			this.m_bEndOfRace = false;
		}
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
			{
				Singleton<GameConfigurator>.Instance.RestartChampionShipRace();
			}
			else
			{
				Singleton<GameConfigurator>.Instance.RankingManager.RestartRace();
			}
			if (Singleton<GameConfigurator>.Instance.PlayerConfig)
			{
				Singleton<GameConfigurator>.Instance.PlayerConfig.ResetAdvantages();
			}
			LoadingManager.LoadLevel(Application.loadedLevelName);
		}
		else if (Network.isServer)
		{
			this.m_oNetworkMgr.networkView.RPC("RetryRace", RPCMode.All, new object[0]);
		}
	}

	// Token: 0x060007A3 RID: 1955 RVA: 0x00038ACC File Offset: 0x00036CCC
	public void OnQuit()
	{
		this.Unpause();
		Singleton<GameConfigurator>.Instance.MenuToLaunch = EMenus.MENU_WELCOME;
		if (Singleton<GameConfigurator>.Instance.PlayerConfig)
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.ResetAdvantages();
		}
		LoadingManager.LoadLevel("MenuRoot");
		Network.Disconnect();
	}

	// Token: 0x060007A4 RID: 1956 RVA: 0x00038B20 File Offset: 0x00036D20
	public void OnChangeCharacter()
	{
		this.Unpause();
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			Singleton<GameConfigurator>.Instance.MenuToLaunch = EMenus.MENU_SELECT_KART;
			if (Singleton<GameConfigurator>.Instance.PlayerConfig)
			{
				Singleton<GameConfigurator>.Instance.PlayerConfig.ResetAdvantages();
			}
			LoadingManager.LoadLevel("MenuRoot");
		}
		else if (Network.isServer)
		{
			this.m_oNetworkMgr.networkView.RPC("QuitToMenu", RPCMode.All, new object[]
			{
				4
			});
		}
	}

	// Token: 0x060007A5 RID: 1957 RVA: 0x00038BAC File Offset: 0x00036DAC
	public void OnChangeTrack()
	{
		this.Unpause();
		if (Network.peerType != NetworkPeerType.Client)
		{
			Singleton<GameConfigurator>.Instance.MenuToLaunch = EMenus.MENU_SELECT_TRACK;
			if (Singleton<GameConfigurator>.Instance.PlayerConfig)
			{
				Singleton<GameConfigurator>.Instance.PlayerConfig.ResetAdvantages();
			}
			if (Network.isServer)
			{
				this.m_oNetworkMgr.networkView.RPC("QuitToMenu", RPCMode.Others, new object[]
				{
					7
				});
			}
			LoadingManager.LoadLevel("MenuRoot");
		}
	}

	// Token: 0x060007A6 RID: 1958 RVA: 0x00038C34 File Offset: 0x00036E34
	public void OnResume()
	{
		if (this.m_bEndOfRace)
		{
			if (Singleton<GameConfigurator>.Instance.PlayerConfig)
			{
				Singleton<GameConfigurator>.Instance.PlayerConfig.ResetAdvantages();
			}
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
			{
				if (Singleton<GameConfigurator>.Instance.CurrentTrackIndex < Singleton<GameConfigurator>.Instance.ChampionShipData.Tracks.Length)
				{
					((InGameGameMode)Singleton<GameManager>.Instance.GameMode).ResetRace();
					if (Network.isServer)
					{
						this.m_oNetworkMgr.networkView.RPC("NextRace", RPCMode.All, new object[0]);
					}
					else if (Network.peerType == NetworkPeerType.Disconnected)
					{
						ChampionShipGameMode.NextRace();
					}
				}
				else if (Network.isServer)
				{
					this.m_oNetworkMgr.networkView.RPC("ShowPodium", RPCMode.All, new object[0]);
				}
				else if (Network.peerType == NetworkPeerType.Disconnected)
				{
					Singleton<GameManager>.Instance.GameMode.State = E_GameState.Podium;
					this.m_pPanelPauseChampionship.SetActive(false);
				}
			}
			else
			{
				this.Unpause();
				if (Time.timeScale == 1f && Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
				{
					TutorialGameMode tutorialGameMode = (TutorialGameMode)Singleton<GameManager>.Instance.GameMode;
					if (!tutorialGameMode.InstructionShown)
					{
						Time.timeScale = 0f;
					}
				}
			}
		}
		else
		{
			this.Unpause();
			if (Time.timeScale == 1f && Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
			{
				TutorialGameMode tutorialGameMode2 = (TutorialGameMode)Singleton<GameManager>.Instance.GameMode;
				if (!tutorialGameMode2.InstructionShown)
				{
					Time.timeScale = 0f;
				}
			}
		}
	}

	// Token: 0x060007A7 RID: 1959 RVA: 0x00038DE4 File Offset: 0x00036FE4
	public void ShowPuzzlePiece(bool bChampionship)
	{
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
		{
			for (int i = 0; i < this.PuzzlePiecePauseRace.Count; i++)
			{
				this.PuzzlePiecePauseRace[i].gameObject.SetActive(false);
			}
		}
		else
		{
			List<UITexturePattern> list = (!bChampionship) ? this.PuzzlePiecePauseRace : this.PuzzlePiecePauseChampionship;
			string startScene = Singleton<GameConfigurator>.Instance.StartScene;
			for (int j = 0; j < list.Count; j++)
			{
				string pPiece = startScene + "_" + j.ToString();
				list[j].ChangeTexture((!Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(pPiece)) ? 0 : 1);
			}
		}
	}

	// Token: 0x060007A8 RID: 1960 RVA: 0x00038EAC File Offset: 0x000370AC
	public void OnBackOptions()
	{
		if (this.m_pControlsPanel)
		{
			HUDOptions component = this.m_pControlsPanel.GetComponent<HUDOptions>();
			if (component)
			{
				component.SaveSensibility();
			}
			this.m_pControlsPanel.SetActive(false);
		}
		if (this.m_oLastPauseBeforeOptions)
		{
			this.m_oLastPauseBeforeOptions.SetActive(true);
		}
	}

	// Token: 0x060007A9 RID: 1961 RVA: 0x00038F10 File Offset: 0x00037110
	public void OnOptions()
	{
		if (this.m_pControlsPanel)
		{
			this.m_pControlsPanel.SetActive(true);
			if (this.m_pPanelPauseChampionship.activeSelf)
			{
				this.m_oLastPauseBeforeOptions = this.m_pPanelPauseChampionship;
			}
			else if (this.m_pPanelPauseRace.activeSelf)
			{
				this.m_oLastPauseBeforeOptions = this.m_pPanelPauseRace;
			}
			else if (this.m_pPanelPauseRaceMultiClient)
			{
				this.m_oLastPauseBeforeOptions = this.m_pPanelPauseRaceMultiClient;
			}
			if (this.m_oLastPauseBeforeOptions)
			{
				this.m_oLastPauseBeforeOptions.SetActive(false);
			}
		}
	}

	// Token: 0x060007AA RID: 1962 RVA: 0x00038FB4 File Offset: 0x000371B4
	public void CreateNamePlates()
	{
		if (Network.peerType != NetworkPeerType.Disconnected)
		{
			PlayerData[] playerDataList = Singleton<GameConfigurator>.Instance.PlayerDataList;
			for (int i = 0; i < Singleton<GameManager>.Instance.GameMode.PlayerCount; i++)
			{
				Kart kart = Singleton<GameManager>.Instance.GameMode.GetKart(i);
				if (kart != null)
				{
					HUDInGame hud = Singleton<GameManager>.Instance.GameMode.Hud;
					if (hud != null)
					{
						GameObject original = (GameObject)Resources.Load("NamePlate");
						RaceScoreData scoreData = Singleton<GameConfigurator>.Instance.RankingManager.GetScoreData(kart.GetVehicleId());
						if (!scoreData.IsAI && kart.GetControlType() != RcVehicle.ControlType.Human)
						{
							GameObject gameObject = (GameObject)UnityEngine.Object.Instantiate(original);
							this.NamePlates.Add(gameObject);
							UILabel component = gameObject.GetComponent<UILabel>();
							if (component != null)
							{
								component.text = playerDataList[kart.GetVehicleId()].Pseudo;
								component.color = playerDataList[kart.GetVehicleId()].CharacColor;
								gameObject.transform.parent = kart.transform;
								gameObject.transform.localPosition = new Vector3(0f, 1.5f, 0f);
								gameObject.transform.localScale = new Vector3(0.5f, 0.5f, 1f);
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x060007AB RID: 1963 RVA: 0x0003911C File Offset: 0x0003731C
	public void OnApplicationPause(bool goingPause)
	{
		Debug.Log("OnApplicationPause + " + goingPause);
		if (!goingPause && LoadingManager.loadingFinished)
		{
			if (this.m_bPause)
			{
				Kart humanKart = Singleton<GameManager>.Instance.GameMode.GetHumanKart();
				if (humanKart)
				{
					KartSound kartSound = humanKart.KartSound;
					if (kartSound)
					{
						kartSound.PauseSounds(true);
					}
				}
			}
			else
			{
				Singleton<InputManager>.Instance.SetAction(EAction.Pause, 1f);
			}
		}
	}

	// Token: 0x04000776 RID: 1910
	private bool m_bPause;

	// Token: 0x04000777 RID: 1911
	private GameObject m_pPanelPauseChampionship;

	// Token: 0x04000778 RID: 1912
	private GameObject m_pOptionsPauseChampionship;

	// Token: 0x04000779 RID: 1913
	private GameObject m_pButtonRetryChampionship;

	// Token: 0x0400077A RID: 1914
	public UILocalize ResumeChampionshipLabel;

	// Token: 0x0400077B RID: 1915
	public GameObject WaitingForServerChampionshipLabel;

	// Token: 0x0400077C RID: 1916
	public GameObject ResumeChampionshipButton;

	// Token: 0x0400077D RID: 1917
	public GameObject PrevButton;

	// Token: 0x0400077E RID: 1918
	private GameObject m_pPanelPauseRace;

	// Token: 0x0400077F RID: 1919
	public GameObject ResumeRaceButton;

	// Token: 0x04000780 RID: 1920
	private GameObject m_pOptionsPauseRace;

	// Token: 0x04000781 RID: 1921
	private GameObject m_pChangeTrackRace;

	// Token: 0x04000782 RID: 1922
	private GameObject m_pChangeCharacterRace;

	// Token: 0x04000783 RID: 1923
	private GameObject m_pRetryRace;

	// Token: 0x04000784 RID: 1924
	private GameObject m_pPanelPauseRaceMultiClient;

	// Token: 0x04000785 RID: 1925
	public GameObject ResumeRaceMultiClientButton;

	// Token: 0x04000786 RID: 1926
	public GameObject WaitingForServerLabel;

	// Token: 0x04000787 RID: 1927
	public GameObject OptionsButtonMultiClient;

	// Token: 0x04000788 RID: 1928
	private GameObject m_pOptionsPauseRaceMulti;

	// Token: 0x04000789 RID: 1929
	private GameObject m_pControlsPanel;

	// Token: 0x0400078A RID: 1930
	private GameObject m_oLastPauseBeforeOptions;

	// Token: 0x0400078B RID: 1931
	private HUDInGame m_pHudInGame;

	// Token: 0x0400078C RID: 1932
	private bool m_bEndOfRace;

	// Token: 0x0400078D RID: 1933
	private NetworkMgr m_oNetworkMgr;

	// Token: 0x0400078E RID: 1934
	public List<UITexturePattern> PuzzlePiecePauseChampionship = new List<UITexturePattern>();

	// Token: 0x0400078F RID: 1935
	public List<UITexturePattern> PuzzlePiecePauseRace = new List<UITexturePattern>();

	// Token: 0x04000790 RID: 1936
	public List<GameObject> NamePlates = new List<GameObject>();
}

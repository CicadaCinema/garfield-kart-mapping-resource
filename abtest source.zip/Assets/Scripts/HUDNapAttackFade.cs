﻿using System;
using UnityEngine;

// Token: 0x02000111 RID: 273
public class HUDNapAttackFade : MonoBehaviour
{
	// Token: 0x1700012E RID: 302
	// (get) Token: 0x06000788 RID: 1928 RVA: 0x0000753F File Offset: 0x0000573F
	private float _Duration
	{
		get
		{
			return (this._fadeType != HUDNapAttackFade.E_FadeType.FadeIn) ? this.FadeOutDuration : this.FadeInDuration;
		}
	}

	// Token: 0x06000789 RID: 1929 RVA: 0x0000755D File Offset: 0x0000575D
	public void OnDestroy()
	{
		NapBonusEffect.OnLaunched = (Action)Delegate.Remove(NapBonusEffect.OnLaunched, new Action(this.FadeIn));
	}

	// Token: 0x0600078A RID: 1930 RVA: 0x0000757F File Offset: 0x0000577F
	public void Start()
	{
		NapBonusEffect.OnLaunched = (Action)Delegate.Combine(NapBonusEffect.OnLaunched, new Action(this.FadeIn));
	}

	// Token: 0x0600078B RID: 1931 RVA: 0x00037E9C File Offset: 0x0003609C
	public void Update()
	{
		if (this._enabled)
		{
			this._elapsedTime += Time.deltaTime;
			float duration = this._Duration;
			if (this._elapsedTime >= duration)
			{
				this._elapsedTime = duration;
				this._enabled = false;
				if (this._fadeType == HUDNapAttackFade.E_FadeType.FadeIn)
				{
					this.FadeOut();
				}
			}
			float time = this.GetTime(duration);
			this.FadeTexture.alpha = Mathf.Lerp(0f, 1f, time);
		}
	}

	// Token: 0x0600078C RID: 1932 RVA: 0x000075A1 File Offset: 0x000057A1
	public void FadeIn()
	{
		this._enabled = true;
		this._elapsedTime = 0f;
		this._fadeType = HUDNapAttackFade.E_FadeType.FadeIn;
		this.FadeTexture.alpha = 0f;
	}

	// Token: 0x0600078D RID: 1933 RVA: 0x000075CC File Offset: 0x000057CC
	public void FadeOut()
	{
		this._enabled = true;
		this._elapsedTime = 0f;
		this._fadeType = HUDNapAttackFade.E_FadeType.FadeOut;
		this.FadeTexture.alpha = 1f;
	}

	// Token: 0x0600078E RID: 1934 RVA: 0x00037F1C File Offset: 0x0003611C
	private float GetTime(float pDuration)
	{
		float num = this._elapsedTime / pDuration;
		if (this._fadeType == HUDNapAttackFade.E_FadeType.FadeIn)
		{
			return num;
		}
		if (this._fadeType == HUDNapAttackFade.E_FadeType.FadeOut)
		{
			return 1f - num;
		}
		return 0f;
	}

	// Token: 0x04000766 RID: 1894
	public UITexture FadeTexture;

	// Token: 0x04000767 RID: 1895
	public float FadeInDuration = 0.25f;

	// Token: 0x04000768 RID: 1896
	public float FadeOutDuration = 0.25f;

	// Token: 0x04000769 RID: 1897
	private float _elapsedTime;

	// Token: 0x0400076A RID: 1898
	private bool _enabled;

	// Token: 0x0400076B RID: 1899
	private HUDNapAttackFade.E_FadeType _fadeType;

	// Token: 0x02000112 RID: 274
	public enum E_FadeType
	{
		// Token: 0x0400076D RID: 1901
		FadeIn,
		// Token: 0x0400076E RID: 1902
		FadeOut
	}
}

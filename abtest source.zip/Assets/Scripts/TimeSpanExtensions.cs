﻿using System;

// Token: 0x02000253 RID: 595
public static class TimeSpanExtensions
{
	// Token: 0x06001072 RID: 4210 RVA: 0x000676A0 File Offset: 0x000658A0
	public static string FormatRaceTime(this TimeSpan TS)
	{
		if (TS.TotalMilliseconds <= 0.0)
		{
			return "--:--.--";
		}
		return string.Format("{0:00}:{1:00}.{2:00}", TS.Minutes, TS.Seconds, TS.Milliseconds / 10);
	}
}

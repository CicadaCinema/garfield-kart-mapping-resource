﻿using System;
using UnityEngine;

// Token: 0x0200005E RID: 94
[AddComponentMenu("NGUI/Tween/Position")]
public class TweenPosition : UITweener
{
	// Token: 0x17000059 RID: 89
	// (get) Token: 0x06000272 RID: 626 RVA: 0x00003D93 File Offset: 0x00001F93
	public Transform cachedTransform
	{
		get
		{
			if (this.mTrans == null)
			{
				this.mTrans = base.transform;
			}
			return this.mTrans;
		}
	}

	// Token: 0x1700005A RID: 90
	// (get) Token: 0x06000273 RID: 627 RVA: 0x00003DB8 File Offset: 0x00001FB8
	// (set) Token: 0x06000274 RID: 628 RVA: 0x00003DC5 File Offset: 0x00001FC5
	public Vector3 position
	{
		get
		{
			return this.cachedTransform.localPosition;
		}
		set
		{
			this.cachedTransform.localPosition = value;
		}
	}

	// Token: 0x06000275 RID: 629 RVA: 0x00003DD3 File Offset: 0x00001FD3
	protected override void OnUpdate(float factor, bool isFinished)
	{
		this.cachedTransform.localPosition = this.from * (1f - factor) + this.to * factor;
	}

	// Token: 0x06000276 RID: 630 RVA: 0x0001860C File Offset: 0x0001680C
	public static TweenPosition Begin(GameObject go, float duration, Vector3 pos)
	{
		TweenPosition tweenPosition = UITweener.Begin<TweenPosition>(go, duration);
		tweenPosition.from = tweenPosition.position;
		tweenPosition.to = pos;
		if (duration <= 0f)
		{
			tweenPosition.Sample(1f, true);
			tweenPosition.enabled = false;
		}
		return tweenPosition;
	}

	// Token: 0x040001F5 RID: 501
	public Vector3 from;

	// Token: 0x040001F6 RID: 502
	public Vector3 to;

	// Token: 0x040001F7 RID: 503
	private Transform mTrans;
}

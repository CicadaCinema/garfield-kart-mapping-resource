﻿using System;
using System.Collections.Generic;

// Token: 0x02000232 RID: 562
public class EncodedDictionary<T> : List<SerializablePair<byte[], T>>
{
	// Token: 0x17000203 RID: 515
	public T this[byte[] pKey]
	{
		get
		{
			foreach (SerializablePair<byte[], T> serializablePair in this)
			{
				if (serializablePair.Key != null && this.ByteArrayEqual(serializablePair.Key, pKey))
				{
					return serializablePair.Value;
				}
			}
			return default(T);
		}
		set
		{
			foreach (SerializablePair<byte[], T> serializablePair in this)
			{
				if (serializablePair.Key != null && this.ByteArrayEqual(serializablePair.Key, pKey))
				{
					serializablePair.Value = value;
					break;
				}
			}
		}
	}

	// Token: 0x06000FD7 RID: 4055 RVA: 0x0000CB98 File Offset: 0x0000AD98
	public void Add(byte[] pKey, T pValue)
	{
		if (!this.ContainsKey(pKey))
		{
			this.Add(new SerializablePair<byte[], T>(pKey, pValue));
		}
	}

	// Token: 0x06000FD8 RID: 4056 RVA: 0x0000CBB3 File Offset: 0x0000ADB3
	public void TryGetValue(byte[] pKey, out T opValue)
	{
		opValue = this[pKey];
	}

	// Token: 0x06000FD9 RID: 4057 RVA: 0x000647AC File Offset: 0x000629AC
	public bool ContainsKey(byte[] pKey)
	{
		foreach (SerializablePair<byte[], T> serializablePair in this)
		{
			if (this.ByteArrayEqual(serializablePair.Key, pKey))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000FDA RID: 4058 RVA: 0x00064818 File Offset: 0x00062A18
	public bool ByteArrayEqual(byte[] pFirst, byte[] pSecond)
	{
		if (pFirst.Length != pSecond.Length)
		{
			return false;
		}
		for (int i = 0; i < pFirst.Length; i++)
		{
			if (pFirst[i] != pSecond[i])
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x06000FDB RID: 4059 RVA: 0x00064854 File Offset: 0x00062A54
	public bool ContainsKey(byte[] pKey, out SerializablePair<byte[], T> opItem)
	{
		opItem = null;
		foreach (SerializablePair<byte[], T> serializablePair in this)
		{
			if (this.ByteArrayEqual(serializablePair.Key, pKey))
			{
				opItem = serializablePair;
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000FDC RID: 4060 RVA: 0x000648C4 File Offset: 0x00062AC4
	public void Remove(byte[] pKey)
	{
		SerializablePair<byte[], T> item = null;
		if (this.ContainsKey(pKey, out item))
		{
			this.Remove(item);
		}
	}
}

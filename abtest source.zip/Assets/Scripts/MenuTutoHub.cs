﻿using System;
using UnityEngine;

// Token: 0x020001B6 RID: 438
public class MenuTutoHub : AbstractMenu
{
	// Token: 0x06000BC5 RID: 3013 RVA: 0x0005082C File Offset: 0x0004EA2C
	public void OnClickDriving()
	{
		Singleton<GameSaveManager>.Instance.SetShowTutorial(false, true);
		Singleton<GameConfigurator>.Instance.GameModeType = E_GameModeType.TUTORIAL;
		ChampionShipData data = (ChampionShipData)Resources.Load("ChampionShip/Champion_Ship_1", typeof(ChampionShipData));
		Singleton<GameConfigurator>.Instance.SetChampionshipData(data, false);
		Singleton<GameConfigurator>.Instance.StartScene = Singleton<GameConfigurator>.Instance.ChampionShipData.Tracks[0];
		Singleton<GameConfigurator>.Instance.CurrentTrackIndex = 0;
		LoadingManager.LoadLevel(Singleton<GameConfigurator>.Instance.StartScene);
	}

	// Token: 0x06000BC6 RID: 3014 RVA: 0x0000A24C File Offset: 0x0000844C
	public void OnClickBonus()
	{
		if (this.m_pMenuEntryPoint)
		{
			this.m_pMenuEntryPoint.SetState(EMenus.MENU_TUTORIAL, 0);
		}
	}

	// Token: 0x06000BC7 RID: 3015 RVA: 0x0000A26C File Offset: 0x0000846C
	public void OnClickCustom()
	{
		if (this.m_pMenuEntryPoint)
		{
			this.m_pMenuEntryPoint.SetState(EMenus.MENU_TUTORIAL, 2);
		}
	}
}

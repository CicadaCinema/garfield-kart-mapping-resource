﻿using System;

// Token: 0x0200015A RID: 346
public enum E_ConditionOperator
{
	// Token: 0x040009C2 RID: 2498
	AND,
	// Token: 0x040009C3 RID: 2499
	OR
}

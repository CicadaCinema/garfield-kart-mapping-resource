﻿using System;
using UnityEngine;

// Token: 0x02000094 RID: 148
[Serializable]
public class MoodBoxData
{
	// Token: 0x04000377 RID: 887
	public Color FogColor = Color.green;

	// Token: 0x04000378 RID: 888
	public float FogStart = -25f;

	// Token: 0x04000379 RID: 889
	public float FogEnd = 400f;

	// Token: 0x0400037A RID: 890
	public bool outside;
}

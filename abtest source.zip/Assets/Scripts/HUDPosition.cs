﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000116 RID: 278
public class HUDPosition : MonoBehaviour
{
	// Token: 0x17000130 RID: 304
	// (get) Token: 0x060007AD RID: 1965 RVA: 0x00007729 File Offset: 0x00005929
	public int LogPuzzle
	{
		get
		{
			return this.m_iLogPuzzle;
		}
	}

	// Token: 0x060007AE RID: 1966 RVA: 0x00007731 File Offset: 0x00005931
	public void OnDestroy()
	{
		RewardManager instance = Singleton<RewardManager>.Instance;
		instance.OnEarnCoins = (Action<int>)Delegate.Remove(instance.OnEarnCoins, new Action<int>(this.EarnCoins));
	}

	// Token: 0x060007AF RID: 1967 RVA: 0x00007759 File Offset: 0x00005959
	private void EarnCoins(int pTotalCoins)
	{
		this.Coins.text = pTotalCoins.ToString();
	}

	// Token: 0x060007B0 RID: 1968 RVA: 0x000391FC File Offset: 0x000373FC
	public void Start()
	{
		this.Coins.text = "0";
		RewardManager instance = Singleton<RewardManager>.Instance;
		instance.OnEarnCoins = (Action<int>)Delegate.Combine(instance.OnEarnCoins, new Action<int>(this.EarnCoins));
		if (this.mPositionSprite == null && this.Position != null)
		{
			this.mPositionSprite = this.Position.GetComponent<UISprite>();
		}
		if (this.mLabelLap == null && this.Lap != null)
		{
			this.mLabelLap = this.Lap.GetComponent<UILabel>();
			if (this.mLabelLap)
			{
				this.mLabelLap.text = string.Concat(new object[]
				{
					Localization.instance.Get("HUD_INGAME_LAP"),
					" : ",
					0,
					" / ",
					3
				});
			}
		}
		if (this.mLabelLapTime == null && this.LapTime != null)
		{
			this.mLabelLapTime = this.LapTime.GetComponent<UILabel>();
		}
		this.mSpriteNames.Clear();
		if (this.mPositionSprite != null && this.mPositionSprite.atlas != null)
		{
			List<UIAtlas.Sprite> spriteList = this.mPositionSprite.atlas.spriteList;
			int i = 0;
			int count = spriteList.Count;
			while (i < count)
			{
				UIAtlas.Sprite sprite = spriteList[i];
				if (string.IsNullOrEmpty("GK_HUD_Place") || sprite.name.StartsWith("GK_HUD_Place"))
				{
					this.mSpriteNames.Add(sprite.name);
				}
				i++;
			}
		}
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
		{
			this.mPositionSprite.gameObject.SetActive(false);
			this.Coins.gameObject.transform.parent.gameObject.SetActive(false);
		}
		else if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
		{
			foreach (GameObject gameObject in this.PuzzleGO)
			{
				gameObject.SetActive(false);
			}
			this.mLabelLap.gameObject.SetActive(false);
			this.Coins.gameObject.transform.parent.gameObject.SetActive(false);
			this.mLabelLapTime.gameObject.SetActive(false);
		}
		else
		{
			this.mLabelLapTime.gameObject.SetActive(false);
		}
		foreach (GameObject gameObject2 in this.PuzzleGO)
		{
			Animation componentInChildren = gameObject2.GetComponentInChildren<Animation>();
			this.m_cPuzzlesAnimation.Add(componentInChildren);
			UITexturePattern componentInChildren2 = gameObject2.GetComponentInChildren<UITexturePattern>();
			this.m_cPuzzlesSprites.Add(componentInChildren2);
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
			{
				gameObject2.SetActive(false);
			}
		}
		for (int j = 0; j < 3; j++)
		{
			string pPiece = Singleton<GameConfigurator>.Instance.StartScene + "_" + j.ToString();
			if (Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(pPiece))
			{
				this.TakePuzzlePiece(j);
			}
		}
	}

	// Token: 0x060007B1 RID: 1969 RVA: 0x000395A0 File Offset: 0x000377A0
	public void TakePuzzlePiece(int iIndex)
	{
		if (iIndex >= 0 && iIndex < this.PuzzleGO.Count)
		{
			bool flag = true;
			for (int i = 0; i < 2; i++)
			{
				if (i != iIndex)
				{
					string pPiece = Singleton<GameConfigurator>.Instance.StartScene + "_" + i.ToString();
					if (!Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(pPiece))
					{
						flag = false;
						break;
					}
				}
			}
			if (flag)
			{
				foreach (Animation animation in this.m_cPuzzlesAnimation)
				{
					animation.Play("Sprite_Turn");
				}
			}
			else if (this.m_cPuzzlesAnimation[iIndex] != null)
			{
				this.m_cPuzzlesAnimation[iIndex].Play("Sprite_Turn");
			}
			if (this.m_cPuzzlesSprites[iIndex] != null)
			{
				this.m_cPuzzlesSprites[iIndex].ChangeTexture(1);
				if (LogManager.Instance != null)
				{
					this.m_iLogPuzzle++;
				}
			}
		}
	}

	// Token: 0x060007B2 RID: 1970 RVA: 0x0000776D File Offset: 0x0000596D
	public void StopTimerAt(int raceTime)
	{
		if (!this.StopTimer)
		{
			this.m_RaceTimeMs = raceTime;
			this.StopTimer = true;
		}
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x000396E4 File Offset: 0x000378E4
	public void DisplayRaceStats(RcVehicleRaceStats _Stats)
	{
		int rank = _Stats.GetRank();
		int raceNbLap = _Stats.GetRaceNbLap();
		int nbLapCompleted = _Stats.GetNbLapCompleted();
		int currentLapTime = _Stats.GetCurrentLapTime();
		if (base.gameObject.activeSelf)
		{
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
			{
				if (!this.StopTimer)
				{
					this.m_RaceTimeMs = _Stats.GetRaceTime();
				}
				TimeSpan ts = TimeSpan.FromMilliseconds((double)this.m_RaceTimeMs);
				if (!this.StopTimer && nbLapCompleted > 1 && TimeSpan.FromMilliseconds((double)currentLapTime).Seconds < 3)
				{
					ts = TimeSpan.FromMilliseconds((double)_Stats.GetLastLapTime());
				}
				this.mLabelLapTime.text = ts.FormatRaceTime();
			}
			else if (this.m_iCurrentIndex != rank && rank >= 0 && rank < this.mSpriteNames.Count)
			{
				this.mPositionSprite.spriteName = this.mSpriteNames[rank];
				this.mPositionSprite.MakePixelPerfect();
				this.m_iCurrentIndex = rank;
			}
			if (this.m_iCurrentLap != nbLapCompleted)
			{
				if (this.mLabelLap)
				{
					this.mLabelLap.text = string.Concat(new object[]
					{
						Localization.instance.Get("HUD_INGAME_LAP"),
						" : ",
						nbLapCompleted,
						" / ",
						raceNbLap
					});
				}
				this.m_iCurrentLap = nbLapCompleted;
				if (this.m_iCurrentLap >= 2 && this.m_iCurrentLap <= 3)
				{
					Singleton<GameManager>.Instance.GameMode.Hud.HUDFinish.ShowLap(this.m_iCurrentLap);
				}
				if (Singleton<GameManager>.Instance.SoundManager && this.m_iCurrentLap > 1)
				{
					if (this.m_iCurrentLap < raceNbLap)
					{
						Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.NewLap);
					}
					else
					{
						Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.LastLap);
						Singleton<GameManager>.Instance.GameMode.MainMusic.pitch += this.LastLapPitchGain;
					}
				}
			}
		}
	}

	// Token: 0x04000791 RID: 1937
	public GameObject Lap;

	// Token: 0x04000792 RID: 1938
	public GameObject Position;

	// Token: 0x04000793 RID: 1939
	public GameObject LapTime;

	// Token: 0x04000794 RID: 1940
	public GameObject WrongWay;

	// Token: 0x04000795 RID: 1941
	public UILabel Coins;

	// Token: 0x04000796 RID: 1942
	public List<GameObject> PuzzleGO = new List<GameObject>();

	// Token: 0x04000797 RID: 1943
	protected List<string> mSpriteNames = new List<string>();

	// Token: 0x04000798 RID: 1944
	protected UISprite mPositionSprite;

	// Token: 0x04000799 RID: 1945
	protected UILabel mLabelLap;

	// Token: 0x0400079A RID: 1946
	protected UILabel mLabelLapTime;

	// Token: 0x0400079B RID: 1947
	private int m_iCurrentIndex = -1;

	// Token: 0x0400079C RID: 1948
	private int m_iCurrentLap = -1;

	// Token: 0x0400079D RID: 1949
	protected List<Animation> m_cPuzzlesAnimation = new List<Animation>();

	// Token: 0x0400079E RID: 1950
	protected List<UITexturePattern> m_cPuzzlesSprites = new List<UITexturePattern>();

	// Token: 0x0400079F RID: 1951
	public bool StopTimer;

	// Token: 0x040007A0 RID: 1952
	public float LastLapPitchGain = 0.1f;

	// Token: 0x040007A1 RID: 1953
	protected int m_RaceTimeMs;

	// Token: 0x040007A2 RID: 1954
	private int m_iLogPuzzle;
}

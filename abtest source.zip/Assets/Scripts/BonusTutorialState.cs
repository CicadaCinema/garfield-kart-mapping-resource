﻿using System;

// Token: 0x0200017F RID: 383
public class BonusTutorialState : IGTutorialState
{
	// Token: 0x17000168 RID: 360
	// (get) Token: 0x06000A2C RID: 2604 RVA: 0x00008F3E File Offset: 0x0000713E
	// (set) Token: 0x06000A2D RID: 2605 RVA: 0x00008F46 File Offset: 0x00007146
	public bool LaunchedBehind
	{
		get
		{
			return this.m_bLaunchedBehind;
		}
		set
		{
			this.m_bLaunchedBehind = value;
		}
	}

	// Token: 0x06000A2E RID: 2606 RVA: 0x00008F4F File Offset: 0x0000714F
	public override void OnEnter()
	{
		base.OnEnter();
		this.GameMode.ReactivateBBEs();
		this.GameMode.ShowHUDBonus = true;
		this.GameMode.WannaItem = true;
		this.GameMode.DesiredItem = this.DesiredItem;
	}

	// Token: 0x06000A2F RID: 2607 RVA: 0x00008F8B File Offset: 0x0000718B
	public override void OnExit()
	{
		this.GameMode.WannaItem = false;
		base.OnExit();
	}

	// Token: 0x17000169 RID: 361
	// (get) Token: 0x06000A30 RID: 2608 RVA: 0x00008F9F File Offset: 0x0000719F
	public override ETutorialState NextState
	{
		get
		{
			if (this.LaunchedBehind)
			{
				return this.ENextState_Behind;
			}
			return this.ENextState;
		}
	}

	// Token: 0x04000A2D RID: 2605
	public ETutorialState ENextState_Behind;

	// Token: 0x04000A2E RID: 2606
	public EITEM DesiredItem = EITEM.ITEM_LASAGNA;

	// Token: 0x04000A2F RID: 2607
	public LaunchType Type;

	// Token: 0x04000A30 RID: 2608
	private bool m_bLaunchedBehind;
}

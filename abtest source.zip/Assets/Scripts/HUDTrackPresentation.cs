﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200011C RID: 284
public class HUDTrackPresentation : MonoBehaviour
{
	// Token: 0x060007CF RID: 1999 RVA: 0x0003ABC4 File Offset: 0x00038DC4
	public void Start()
	{
		if (this.NoThanks == null)
		{
			this.NoThanks = GameObject.Find("NoThanks");
		}
		if (this.Valid == null)
		{
			this.Valid = GameObject.Find("Valid");
		}
		if (this.Valid != null)
		{
			this.ValidTexture = this.Valid.GetComponent<UITexturePattern>();
		}
		if (Network.peerType == NetworkPeerType.Disconnected || this.m_oTimerLabel == null)
		{
			this.m_bLimitTime = false;
		}
		else
		{
			this.m_fElapsedTime = 0f;
			this.m_bLimitTime = true;
		}
		if (this.m_oTimerLabel != null)
		{
			this.m_oTimerLabel.enabled = false;
		}
		foreach (GameObject gameObject in this.PuzzleGO)
		{
			UITexturePattern component = gameObject.GetComponent<UITexturePattern>();
			this.m_PuzzlePiece.Add(component);
		}
		this.m_bValidateAdvantage = false;
		this.m_iIndex = -1;
		this.NetworkSynchro.gameObject.SetActive(false);
		if (Singleton<GameConfigurator>.Instance.ChampionShipData != null)
		{
			this.ChampionshipIcon.ChangeTexture(Singleton<GameConfigurator>.Instance.ChampionShipData.Index);
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
			{
				this.TrackName.text = string.Format(Localization.instance.Get("HUD_DYN_CHAMPIONSHIP_ROUND"), Singleton<GameConfigurator>.Instance.ChampionShipData.ChampionShipName, Singleton<GameConfigurator>.Instance.CurrentTrackIndex + 1);
			}
			else
			{
				this.TrackName.text = Singleton<GameConfigurator>.Instance.ChampionShipData.TracksName[Singleton<GameConfigurator>.Instance.CurrentTrackIndex];
			}
		}
		if (Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantages().Count == 0)
		{
			this.Valid.SetActive(true);
			this.NoThanks.SetActive(false);
			this.AdvantageLabel.text = Localization.instance.Get("HUD_TRACKPRESENTATION_ADV_EMPTY");
		}
		else
		{
			this.Valid.SetActive(false);
			this.NoThanks.SetActive(true);
			this.AdvantageLabel.text = Localization.instance.Get("HUD_TRACKPRESENTATION_ADV");
		}
		this.DifficultySprite.ChangeTexture((int)Singleton<GameConfigurator>.Instance.Difficulty);
		this.PanelChallenge.NullSafe(delegate(GameObject p)
		{
			p.SetActive(false);
		});
		this.PanelTimeTrial.NullSafe(delegate(GameObject p)
		{
			p.SetActive(false);
		});
		this.PanelAdvantages.NullSafe(delegate(GameObject p)
		{
			p.SetActive(true);
		});
		if (Singleton<ChallengeManager>.Instance.IsActive)
		{
			string empty = string.Empty;
			string empty2 = string.Empty;
			Singleton<ChallengeManager>.Instance.GetLocalizedObjectives(out empty, out empty2);
			this.ChallengeFirstObjective.text = empty;
			this.ChallengeSecondObjective.text = empty2;
			this.PanelChallenge.NullSafe(delegate(GameObject p)
			{
				p.SetActive(true);
			});
			if (Singleton<ChallengeManager>.Instance.IsMonday)
			{
				this.PanelAdvantages.NullSafe(delegate(GameObject p)
				{
					p.SetActive(false);
				});
			}
		}
		switch (Singleton<GameConfigurator>.Instance.GameModeType)
		{
		case E_GameModeType.SINGLE:
		{
			if (this.GameModeSprite != null)
			{
				this.GameModeSprite.ChangeTexture(1);
			}
			string startScene = Singleton<GameConfigurator>.Instance.StartScene;
			for (int i = 0; i < this.m_PuzzlePiece.Count; i++)
			{
				string pPiece = startScene + "_" + i.ToString();
				this.m_PuzzlePiece[i].ChangeTexture((!Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(pPiece)) ? 0 : 1);
			}
			break;
		}
		case E_GameModeType.CHAMPIONSHIP:
		{
			if (this.GameModeSprite != null)
			{
				this.GameModeSprite.ChangeTexture(0);
			}
			string startScene2 = Singleton<GameConfigurator>.Instance.StartScene;
			for (int j = 0; j < this.m_PuzzlePiece.Count; j++)
			{
				string pPiece2 = startScene2 + "_" + j.ToString();
				this.m_PuzzlePiece[j].ChangeTexture((!Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(pPiece2)) ? 0 : 1);
			}
			break;
		}
		case E_GameModeType.TIME_TRIAL:
		{
			if (this.GameModeSprite != null)
			{
				this.GameModeSprite.ChangeTexture(2);
			}
			this.PanelTimeTrial.NullSafe(delegate(GameObject p)
			{
				p.SetActive(true);
			});
			this.PanelAdvantages.NullSafe(delegate(GameObject p)
			{
				p.SetActive(false);
			});
			Singleton<GameSaveManager>.Instance.EarnAdvantage(EAdvantage.BoostStart, 1, false);
			Singleton<GameConfigurator>.Instance.PlayerConfig.SelectAdvantage(EAdvantage.BoostStart);
			GameObject gameObject2 = GameObject.Find("Race");
			string startScene3 = Singleton<GameConfigurator>.Instance.StartScene;
			string empty3 = string.Empty;
			Singleton<GameSaveManager>.Instance.GetTimeTrialRecord(startScene3, ref empty3);
			this.BestTime.text = empty3;
			TimeTrialConfig component2 = gameObject2.GetComponent<TimeTrialConfig>();
			switch (Singleton<GameSaveManager>.Instance.GetMedal(startScene3, true))
			{
			case E_TimeTrialMedal.None:
				this.MedalTime.text = TimeSpan.FromMilliseconds((double)component2.Bronze).FormatRaceTime();
				this.MedalIcon.spriteName = "icon_medal_bronze";
				break;
			case E_TimeTrialMedal.Bronze:
				this.MedalTime.text = TimeSpan.FromMilliseconds((double)component2.Silver).FormatRaceTime();
				this.MedalIcon.spriteName = "icon_medal_silver";
				break;
			case E_TimeTrialMedal.Silver:
				this.MedalTime.text = TimeSpan.FromMilliseconds((double)component2.Gold).FormatRaceTime();
				this.MedalIcon.spriteName = "icon_medal_gold";
				break;
			case E_TimeTrialMedal.Gold:
				this.MedalTime.text = TimeSpan.FromMilliseconds((double)component2.Platinium).FormatRaceTime();
				this.MedalIcon.spriteName = "icon_medal_platinum";
				break;
			case E_TimeTrialMedal.Platinium:
				this.MedalPanel.SetActive(false);
				break;
			}
			foreach (GameObject gameObject3 in this.PuzzleGO)
			{
				gameObject3.SetActive(false);
			}
			this.NoThanks.SetActive(false);
			this.Valid.SetActive(true);
			break;
		}
		default:
		{
			string startScene4 = Singleton<GameConfigurator>.Instance.StartScene;
			for (int k = 0; k < this.m_PuzzlePiece.Count; k++)
			{
				string pPiece3 = startScene4 + "_" + k.ToString();
				this.m_PuzzlePiece[k].ChangeTexture((!Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(pPiece3)) ? 0 : 1);
			}
			break;
		}
		}
		if (DebugMgr.Instance != null && Singleton<GameConfigurator>.Instance.NbSlots == 0)
		{
			Singleton<GameConfigurator>.Instance.NbSlots = 3;
			DebugMgr.Instance.ApplyAdvantages();
		}
		this.ConfigureSlots();
	}

	// Token: 0x060007D0 RID: 2000 RVA: 0x0003B384 File Offset: 0x00039584
	public void Update()
	{
		if (this.m_bLimitTime)
		{
			this.m_fElapsedTime += Time.deltaTime;
			if (this.m_fElapsedTime > (float)(this.m_iTimeLimit - this.m_iStartDisplaying))
			{
				this.m_oTimerLabel.enabled = true;
				this.m_oTimerLabel.text = ((int)((float)this.m_iTimeLimit - this.m_fElapsedTime)).ToString();
				if (this.m_fElapsedTime >= (float)this.m_iTimeLimit)
				{
					this.m_oTimerLabel.enabled = false;
					this.m_bLimitTime = false;
					this.OnValid();
				}
			}
		}
	}

	// Token: 0x060007D1 RID: 2001 RVA: 0x0003B420 File Offset: 0x00039620
	public void ConfigureSlots()
	{
		for (int i = 0; i < this.AdvantageSlotsList.Count; i++)
		{
			if (i < Singleton<GameConfigurator>.Instance.NbSlots)
			{
				if (i < Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantages().Count)
				{
					EAdvantage eadvantage = Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantages()[i];
					if (eadvantage != EAdvantage.None)
					{
						this.AdvantageSlotsList[i].Sprite.gameObject.SetActive(true);
						this.AdvantageSlotsList[i].Parent.GetComponent<UICheckbox>().enabled = true;
						this.AdvantageSlotsList[i].Sprite.ChangeTexture((int)eadvantage);
					}
				}
				else
				{
					this.AdvantageSlotsList[i].Sprite.gameObject.SetActive(false);
					UICheckbox component = this.AdvantageSlotsList[i].Parent.GetComponent<UICheckbox>();
					component.enabled = false;
					this.AdvantageSlotsList[i].Parent.SetActive(false);
				}
			}
			else
			{
				this.AdvantageSlotsList[i].Parent.SetActive(false);
			}
		}
	}

	// Token: 0x060007D2 RID: 2002 RVA: 0x0000785C File Offset: 0x00005A5C
	public void OnSlot1(bool Checked)
	{
		this.SelectAdvantage(0, Checked);
	}

	// Token: 0x060007D3 RID: 2003 RVA: 0x00007866 File Offset: 0x00005A66
	public void OnSlot2(bool Checked)
	{
		this.SelectAdvantage(1, Checked);
	}

	// Token: 0x060007D4 RID: 2004 RVA: 0x00007870 File Offset: 0x00005A70
	public void OnSlot3(bool Checked)
	{
		this.SelectAdvantage(2, Checked);
	}

	// Token: 0x060007D5 RID: 2005 RVA: 0x0000787A File Offset: 0x00005A7A
	public void OnSlot4(bool Checked)
	{
		this.SelectAdvantage(3, Checked);
	}

	// Token: 0x060007D6 RID: 2006 RVA: 0x00007884 File Offset: 0x00005A84
	public void OnNoThanks(bool Checked)
	{
		this.SelectAdvantage(4, Checked);
	}

	// Token: 0x060007D7 RID: 2007 RVA: 0x0003B554 File Offset: 0x00039754
	public void OnValid()
	{
		if (this.m_bValidateAdvantage)
		{
			return;
		}
		if (this.m_iIndex > -1 && this.m_iIndex < Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantages().Count)
		{
			EAdvantage advantage = Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantages()[this.m_iIndex];
			Singleton<GameConfigurator>.Instance.PlayerConfig.SelectAdvantage(advantage);
		}
		this.m_bValidateAdvantage = true;
		for (int i = 0; i < this.AdvantageSlotsList.Count; i++)
		{
			if (i < Singleton<GameConfigurator>.Instance.NbSlots)
			{
				UICheckbox component = this.AdvantageSlotsList[i].Parent.GetComponent<UICheckbox>();
				component.enabled = false;
			}
		}
		this.PanelAdvantages.SetActive(false);
		if (Network.peerType != NetworkPeerType.Disconnected)
		{
			this.ValidTexture.ChangeTexture(1);
			this.NetworkSynchro.gameObject.SetActive(true);
			if (!Network.isServer)
			{
				this.NetworkSynchro.text = Localization.instance.Get("NETWORK_WAITING_SERVER");
			}
			else
			{
				this.NetworkSynchro.text = Localization.instance.Get("NETWORK_WAITING_CLIENTS");
			}
		}
	}

	// Token: 0x060007D8 RID: 2008 RVA: 0x0000788E File Offset: 0x00005A8E
	public void SelectAdvantage(int Index, bool Checked)
	{
		if (Checked)
		{
			this.m_iIndex = ((Index >= 4) ? -1 : Index);
			this.Valid.SetActive(true);
		}
		else
		{
			this.m_iIndex = -1;
			this.Valid.SetActive(false);
		}
	}

	// Token: 0x060007D9 RID: 2009 RVA: 0x000078CE File Offset: 0x00005ACE
	public bool ValidateAdvantage()
	{
		return this.m_bValidateAdvantage;
	}

	// Token: 0x040007E0 RID: 2016
	public GameObject PanelChallenge;

	// Token: 0x040007E1 RID: 2017
	public GameObject PanelTimeTrial;

	// Token: 0x040007E2 RID: 2018
	public GameObject PanelAdvantages;

	// Token: 0x040007E3 RID: 2019
	public UILabel TrackName;

	// Token: 0x040007E4 RID: 2020
	public UILabel AdvantageLabel;

	// Token: 0x040007E5 RID: 2021
	public UITexturePattern GameModeSprite;

	// Token: 0x040007E6 RID: 2022
	public UITexturePattern DifficultySprite;

	// Token: 0x040007E7 RID: 2023
	public UITexturePattern ChampionshipIcon;

	// Token: 0x040007E8 RID: 2024
	public List<AdvantageSlots> AdvantageSlotsList;

	// Token: 0x040007E9 RID: 2025
	public UILabel NetworkSynchro;

	// Token: 0x040007EA RID: 2026
	public GameObject NoThanks;

	// Token: 0x040007EB RID: 2027
	public GameObject Valid;

	// Token: 0x040007EC RID: 2028
	private UITexturePattern ValidTexture;

	// Token: 0x040007ED RID: 2029
	public UISprite MedalIcon;

	// Token: 0x040007EE RID: 2030
	public UILabel MedalTime;

	// Token: 0x040007EF RID: 2031
	public UILabel BestTime;

	// Token: 0x040007F0 RID: 2032
	public UILabel ChallengeFirstObjective;

	// Token: 0x040007F1 RID: 2033
	public UILabel ChallengeSecondObjective;

	// Token: 0x040007F2 RID: 2034
	private int m_iIndex;

	// Token: 0x040007F3 RID: 2035
	private bool m_bValidateAdvantage;

	// Token: 0x040007F4 RID: 2036
	public GameObject MedalPanel;

	// Token: 0x040007F5 RID: 2037
	public List<GameObject> PuzzleGO = new List<GameObject>();

	// Token: 0x040007F6 RID: 2038
	private List<UITexturePattern> m_PuzzlePiece = new List<UITexturePattern>();

	// Token: 0x040007F7 RID: 2039
	public int m_iTimeLimit = 30;

	// Token: 0x040007F8 RID: 2040
	public int m_iStartDisplaying = 10;

	// Token: 0x040007F9 RID: 2041
	public UILabel m_oTimerLabel;

	// Token: 0x040007FA RID: 2042
	private bool m_bLimitTime = true;

	// Token: 0x040007FB RID: 2043
	private float m_fElapsedTime;
}

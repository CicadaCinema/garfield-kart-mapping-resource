﻿using System;
using AnimationOrTween;
using UnityEngine;

// Token: 0x0200000C RID: 12
[AddComponentMenu("NGUI/Interaction/Button Play Animation")]
public class UIButtonPlayAnimation : MonoBehaviour
{
	// Token: 0x0600002F RID: 47 RVA: 0x00002431 File Offset: 0x00000631
	private void Start()
	{
		this.mStarted = true;
	}

	// Token: 0x06000030 RID: 48 RVA: 0x0000243A File Offset: 0x0000063A
	private void OnEnable()
	{
		if (this.mStarted && this.mHighlighted)
		{
			this.OnHover(UICamera.IsHighlighted(base.gameObject));
		}
	}

	// Token: 0x06000031 RID: 49 RVA: 0x0000DC50 File Offset: 0x0000BE50
	private void OnHover(bool isOver)
	{
		if (base.enabled)
		{
			if (this.trigger == Trigger.OnHover || (this.trigger == Trigger.OnHoverTrue && isOver) || (this.trigger == Trigger.OnHoverFalse && !isOver))
			{
				this.Play(isOver);
			}
			this.mHighlighted = isOver;
		}
	}

	// Token: 0x06000032 RID: 50 RVA: 0x0000DCA8 File Offset: 0x0000BEA8
	private void OnPress(bool isPressed)
	{
		if (base.enabled && (this.trigger == Trigger.OnPress || (this.trigger == Trigger.OnPressTrue && isPressed) || (this.trigger == Trigger.OnPressFalse && !isPressed)))
		{
			this.Play(isPressed);
		}
	}

	// Token: 0x06000033 RID: 51 RVA: 0x00002463 File Offset: 0x00000663
	private void OnClick()
	{
		if (base.enabled && this.trigger == Trigger.OnClick)
		{
			this.Play(true);
		}
	}

	// Token: 0x06000034 RID: 52 RVA: 0x00002482 File Offset: 0x00000682
	private void OnDoubleClick()
	{
		if (base.enabled && this.trigger == Trigger.OnDoubleClick)
		{
			this.Play(true);
		}
	}

	// Token: 0x06000035 RID: 53 RVA: 0x0000DCF8 File Offset: 0x0000BEF8
	private void OnSelect(bool isSelected)
	{
		if (base.enabled && (this.trigger == Trigger.OnSelect || (this.trigger == Trigger.OnSelectTrue && isSelected) || (this.trigger == Trigger.OnSelectFalse && !isSelected)))
		{
			this.Play(true);
		}
	}

	// Token: 0x06000036 RID: 54 RVA: 0x0000DD4C File Offset: 0x0000BF4C
	private void OnActivate(bool isActive)
	{
		if (base.enabled && (this.trigger == Trigger.OnActivate || (this.trigger == Trigger.OnActivateTrue && isActive) || (this.trigger == Trigger.OnActivateFalse && !isActive)))
		{
			this.Play(isActive);
		}
	}

	// Token: 0x06000037 RID: 55 RVA: 0x0000DD9C File Offset: 0x0000BF9C
	private void Play(bool forward)
	{
		if (this.target == null)
		{
			this.target = base.GetComponentInChildren<Animation>();
		}
		if (this.target != null)
		{
			if (this.clearSelection && UICamera.selectedObject == base.gameObject)
			{
				UICamera.selectedObject = null;
			}
			int num = (int)(-(int)this.playDirection);
			Direction direction = (Direction)((!forward) ? num : ((int)this.playDirection));
			ActiveAnimation activeAnimation = ActiveAnimation.Play(this.target, this.clipName, direction, this.ifDisabledOnPlay, this.disableWhenFinished);
			if (activeAnimation == null)
			{
				return;
			}
			if (this.resetOnPlay)
			{
				activeAnimation.Reset();
			}
			activeAnimation.onFinished = this.onFinished;
			if (this.eventReceiver != null && !string.IsNullOrEmpty(this.callWhenFinished))
			{
				activeAnimation.eventReceiver = this.eventReceiver;
				activeAnimation.callWhenFinished = this.callWhenFinished;
			}
			else
			{
				activeAnimation.eventReceiver = null;
			}
		}
	}

	// Token: 0x04000028 RID: 40
	public Animation target;

	// Token: 0x04000029 RID: 41
	public string clipName;

	// Token: 0x0400002A RID: 42
	public Trigger trigger;

	// Token: 0x0400002B RID: 43
	public Direction playDirection = Direction.Forward;

	// Token: 0x0400002C RID: 44
	public bool resetOnPlay;

	// Token: 0x0400002D RID: 45
	public bool clearSelection;

	// Token: 0x0400002E RID: 46
	public EnableCondition ifDisabledOnPlay;

	// Token: 0x0400002F RID: 47
	public DisableCondition disableWhenFinished;

	// Token: 0x04000030 RID: 48
	public GameObject eventReceiver;

	// Token: 0x04000031 RID: 49
	public string callWhenFinished;

	// Token: 0x04000032 RID: 50
	public ActiveAnimation.OnFinished onFinished;

	// Token: 0x04000033 RID: 51
	private bool mStarted;

	// Token: 0x04000034 RID: 52
	private bool mHighlighted;
}

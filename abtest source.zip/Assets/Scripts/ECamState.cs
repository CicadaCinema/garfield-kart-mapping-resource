﻿using System;

// Token: 0x020001E7 RID: 487
public enum ECamState
{
	// Token: 0x04000CEB RID: 3307
	None = -1,
	// Token: 0x04000CEC RID: 3308
	Follow,
	// Token: 0x04000CED RID: 3309
	Respawn,
	// Token: 0x04000CEE RID: 3310
	Kill,
	// Token: 0x04000CEF RID: 3311
	CarPres,
	// Token: 0x04000CF0 RID: 3312
	Path,
	// Token: 0x04000CF1 RID: 3313
	End,
	// Token: 0x04000CF2 RID: 3314
	TransCut,
	// Token: 0x04000CF3 RID: 3315
	MinTrans = 6,
	// Token: 0x04000CF4 RID: 3316
	TransMagic,
	// Token: 0x04000CF5 RID: 3317
	TransBezier,
	// Token: 0x04000CF6 RID: 3318
	NbStates
}

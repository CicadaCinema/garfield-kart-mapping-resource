﻿using System;

// Token: 0x02000237 RID: 567
public class InputData
{
	// Token: 0x06000FF0 RID: 4080 RVA: 0x0000CC83 File Offset: 0x0000AE83
	public InputData()
	{
		this.Value = 0f;
		this.NextValue = 0f;
		this.LifeTime = 0;
	}

	// Token: 0x04000F5B RID: 3931
	public float Value;

	// Token: 0x04000F5C RID: 3932
	public float NextValue;

	// Token: 0x04000F5D RID: 3933
	public int LifeTime;
}

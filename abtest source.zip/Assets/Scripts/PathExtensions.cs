﻿using System;
using System.IO;

// Token: 0x0200023F RID: 575
public static class PathExtensions
{
	// Token: 0x06001014 RID: 4116 RVA: 0x000649C8 File Offset: 0x00062BC8
	public static string Combine(params string[] pPaths)
	{
		string text = null;
		if (pPaths != null)
		{
			text = pPaths[0];
			for (int i = 1; i < pPaths.Length; i++)
			{
				text = Path.Combine(text, pPaths[i]);
			}
		}
		return text;
	}
}

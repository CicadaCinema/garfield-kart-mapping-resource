﻿using System;
using UnityEngine;

// Token: 0x020001BB RID: 443
public class PanelDataKart : MonoBehaviour
{
	// Token: 0x06000BF4 RID: 3060 RVA: 0x0005177C File Offset: 0x0004F97C
	public void Start()
	{
		this.m_fAcceleration = (this.m_fAccelerationTarget = 0f);
		this.m_fSpeed = (this.m_fSpeedTarget = 0f);
		this.m_fManiability = (this.m_fManiabilityTarget = 0f);
		Transform parent = base.transform.parent;
		this.m_pMenuSelectKart = parent.GetComponent<MenuSelectKart>();
		while (this.m_pMenuSelectKart == null)
		{
			parent = parent.parent;
			if (!parent)
			{
				return;
			}
			this.m_pMenuSelectKart = parent.GetComponent<MenuSelectKart>();
		}
	}

	// Token: 0x06000BF5 RID: 3061 RVA: 0x00051814 File Offset: 0x0004FA14
	public void Update()
	{
		Vector3 localScale = new Vector3(1f, 1f, 1f);
		if (this.m_oGaugeAcceleration)
		{
			localScale = this.m_oGaugeAcceleration.transform.localScale;
		}
		if (this.m_fAcceleration != this.m_fAccelerationTarget)
		{
			this.m_fAcceleration = Tricks.ComputeInertia(this.m_fAcceleration, this.m_fAccelerationTarget, this.m_fGaugeInertia, Time.deltaTime);
			if (this.m_oGaugeAcceleration)
			{
				this.m_oGaugeAcceleration.transform.localScale = new Vector3(this.m_fGaugeScaleMin + (this.m_fGaugeScaleMax - this.m_fGaugeScaleMin) * this.m_fAcceleration / 100f, localScale.y, localScale.z);
			}
		}
		if (this.m_fSpeed != this.m_fSpeedTarget)
		{
			this.m_fSpeed = Tricks.ComputeInertia(this.m_fSpeed, this.m_fSpeedTarget, this.m_fGaugeInertia, Time.deltaTime);
			if (this.m_oGaugeSpeed)
			{
				this.m_oGaugeSpeed.transform.localScale = new Vector3(this.m_fGaugeScaleMin + (this.m_fGaugeScaleMax - this.m_fGaugeScaleMin) * this.m_fSpeed / 100f, localScale.y, localScale.z);
			}
		}
		if (this.m_fManiability != this.m_fManiabilityTarget)
		{
			this.m_fManiability = Tricks.ComputeInertia(this.m_fManiability, this.m_fManiabilityTarget, this.m_fGaugeInertia, Time.deltaTime);
			if (this.m_oGaugeSteering)
			{
				this.m_oGaugeSteering.transform.localScale = new Vector3(this.m_fGaugeScaleMin + (this.m_fGaugeScaleMax - this.m_fGaugeScaleMin) * this.m_fManiability / 100f, localScale.y, localScale.z);
			}
		}
	}

	// Token: 0x06000BF6 RID: 3062 RVA: 0x000519F0 File Offset: 0x0004FBF0
	public void OnUpdatePanel()
	{
		PlayerConfig playerConfig = Singleton<GameConfigurator>.Instance.PlayerConfig;
		KartCarac kartCarac = (KartCarac)Resources.Load("Kart/" + playerConfig.KartPrefab[(int)playerConfig.m_eKart], typeof(KartCarac));
		CharacterCarac characterCarac = (CharacterCarac)Resources.Load("Character/" + playerConfig.CharacterPrefab[(int)playerConfig.m_eCharacter], typeof(CharacterCarac));
		this.m_fAccelerationTarget = kartCarac.Acceleration + characterCarac.Acceleration + playerConfig.m_oKartCustom.Acceleration;
		this.m_fSpeedTarget = kartCarac.Speed + characterCarac.Speed + playerConfig.m_oKartCustom.Speed;
		this.m_fManiabilityTarget = kartCarac.Maniability + characterCarac.Maniability + playerConfig.m_oKartCustom.Maniability;
		if (kartCarac.Owner == playerConfig.m_eCharacter)
		{
			switch (kartCarac.BonusCaracteristic)
			{
			case DrivingCaracteristics.SPEED:
				this.m_fSpeedTarget += kartCarac.Bonus;
				break;
			case DrivingCaracteristics.ACCELERATION:
				this.m_fAccelerationTarget += kartCarac.Bonus;
				break;
			case DrivingCaracteristics.MANIABILITY:
				this.m_fManiabilityTarget += kartCarac.Bonus;
				break;
			}
		}
		if (playerConfig.m_oKartCustom.Owner == playerConfig.m_eKart)
		{
			switch (playerConfig.m_oKartCustom.BonusCaracteristic)
			{
			case DrivingCaracteristics.SPEED:
				this.m_fSpeedTarget += playerConfig.m_oKartCustom.Bonus;
				break;
			case DrivingCaracteristics.ACCELERATION:
				this.m_fAccelerationTarget += playerConfig.m_oKartCustom.Bonus;
				break;
			case DrivingCaracteristics.MANIABILITY:
				this.m_fManiabilityTarget += playerConfig.m_oKartCustom.Bonus;
				break;
			}
		}
		int num = kartCarac.NbSlots + characterCarac.NbSlots + playerConfig.m_oHat.NbSlots + playerConfig.m_oKartCustom.NbSlots;
		if (this.m_pMenuSelectKart && this.m_pMenuSelectKart.GetAdvantageRestrictions() == MenuSelectKart.EAdvantageRestrictions.TIMETRIAL_RESTRICTION)
		{
			num = 0;
		}
		Singleton<GameConfigurator>.Instance.NbSlots = num;
		for (int i = 0; i < 4; i++)
		{
			this.m_oSpriteAdv[i].SetActive(i < num);
		}
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
		{
			this.m_oIconAdv.SetActive(false);
		}
		else
		{
			this.m_oIconAdv.SetActive(true);
		}
	}

	// Token: 0x04000BCA RID: 3018
	public GameObject m_oGaugeAcceleration;

	// Token: 0x04000BCB RID: 3019
	public GameObject m_oGaugeSpeed;

	// Token: 0x04000BCC RID: 3020
	public GameObject m_oGaugeSteering;

	// Token: 0x04000BCD RID: 3021
	public GameObject[] m_oSpriteAdv = new GameObject[4];

	// Token: 0x04000BCE RID: 3022
	public GameObject m_oIconAdv;

	// Token: 0x04000BCF RID: 3023
	private float m_fAcceleration;

	// Token: 0x04000BD0 RID: 3024
	private float m_fAccelerationTarget;

	// Token: 0x04000BD1 RID: 3025
	private float m_fSpeed;

	// Token: 0x04000BD2 RID: 3026
	private float m_fSpeedTarget;

	// Token: 0x04000BD3 RID: 3027
	private float m_fManiability;

	// Token: 0x04000BD4 RID: 3028
	private float m_fManiabilityTarget;

	// Token: 0x04000BD5 RID: 3029
	public float m_fGaugeInertia = 0.15f;

	// Token: 0x04000BD6 RID: 3030
	private float m_fGaugeScaleMin = 56f;

	// Token: 0x04000BD7 RID: 3031
	private float m_fGaugeScaleMax = 350f;

	// Token: 0x04000BD8 RID: 3032
	private MenuSelectKart m_pMenuSelectKart;
}

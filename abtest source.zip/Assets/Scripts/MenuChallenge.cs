﻿using System;
using UnityEngine;

// Token: 0x02000199 RID: 409
public class MenuChallenge : AbstractMenu
{
	// Token: 0x06000B03 RID: 2819 RVA: 0x0004A2E0 File Offset: 0x000484E0
	public override void Awake()
	{
		base.Awake();
		this.m_oGoMonday = this.ButtonNextGO.transform.Find("GoArrow").GetComponent<UISlicedSprite>();
		this.m_oGoNormalBackground = this.ButtonNextGO.transform.Find("Background").GetComponent<UISlicedSprite>();
		this.m_oLabelRetry = this.ButtonNextGO.transform.Find("LabelRecommencer").GetComponent<UILabel>();
	}

	// Token: 0x06000B04 RID: 2820 RVA: 0x0004A354 File Offset: 0x00048554
	public override void OnEnter()
	{
		base.OnEnter();
		Singleton<ChallengeManager>.Instance.ChampionshipData.Localize();
		if (Singleton<ChallengeManager>.Instance.GameMode == E_GameModeType.CHAMPIONSHIP)
		{
			this.GameModeIcon.ChangeTexture(0);
		}
		else if (Singleton<ChallengeManager>.Instance.GameMode == E_GameModeType.SINGLE)
		{
			this.GameModeIcon.ChangeTexture(1);
		}
		else if (Singleton<ChallengeManager>.Instance.GameMode == E_GameModeType.TIME_TRIAL)
		{
			this.GameModeIcon.ChangeTexture(2);
		}
		this.ChampionshipIcon.ChangeTexture(Singleton<ChallengeManager>.Instance.ChampionshipData.Index);
		this.DifficultyIcon.ChangeTexture((int)Singleton<ChallengeManager>.Instance.Difficulty);
		IconCarac iconCarac;
		if (Singleton<ChallengeManager>.Instance.RewardType == E_RewardType.Kart)
		{
			ECharacter index = (ECharacter)((int)Enum.Parse(typeof(ECharacter), Singleton<ChallengeManager>.Instance.Reward));
			iconCarac = (IconCarac)Resources.Load("Kart/" + Singleton<GameConfigurator>.Instance.PlayerConfig.KartPrefab[(int)index], typeof(IconCarac));
		}
		else
		{
			string str = string.Empty;
			if (Singleton<ChallengeManager>.Instance.RewardType == E_RewardType.Custom)
			{
				str = "Kart/";
			}
			else if (Singleton<ChallengeManager>.Instance.RewardType == E_RewardType.Hat)
			{
				str = "Hat/";
			}
			GameObject gameObject = (GameObject)Resources.Load(str + Singleton<ChallengeManager>.Instance.Reward);
			iconCarac = gameObject.GetComponent<IconCarac>();
		}
		this.RewardIcon.spriteName = iconCarac.spriteName;
		string empty = string.Empty;
		string text;
		Singleton<ChallengeManager>.Instance.GetLocalizedObjectives(out text, out empty);
		this.FirstObjective.text = text;
		this.SecondObjective.text = empty;
		this.RewardRarityIcon.ChangeTexture(Tricks.LogBase2((int)Singleton<ChallengeManager>.Instance.RewardRarity));
		if (Singleton<ChallengeManager>.Instance.GameMode == E_GameModeType.CHAMPIONSHIP)
		{
			this.TrackName.text = Singleton<ChallengeManager>.Instance.ChampionshipData.ChampionShipName;
		}
		else
		{
			this.TrackName.text = Singleton<ChallengeManager>.Instance.ChampionshipData.TracksName[Singleton<ChallengeManager>.Instance.TrackIndex];
		}
		this.ChampionshipName.text = Singleton<ChallengeManager>.Instance.ChampionshipData.ChampionShipName;
		string arg = (!Singleton<ChallengeManager>.Instance.IsMonday) ? Localization.instance.Get("MENU_CHALLENGE_DAY") : Localization.instance.Get("MENU_CHALLENGE_MONDAY");
		this.ChallengeName.text = string.Format(Localization.instance.Get("MENU_CHALLENGE_NAME"), arg);
		if (this.SpriteChallenge)
		{
			this.SpriteChallenge.ChangeTexture((!Singleton<ChallengeManager>.Instance.IsMonday) ? 0 : 1);
		}
		if (Singleton<ChallengeManager>.Instance.AlreadyPlayed)
		{
			this.ChallengeState.ChangeTexture((!Singleton<ChallengeManager>.Instance.Success) ? 1 : 0);
			this.m_oLabelRetry.enabled = true;
		}
		else
		{
			this.ChallengeState.gameObject.SetActive(false);
			this.m_oLabelRetry.enabled = false;
		}
		if (Singleton<ChallengeManager>.Instance.Success)
		{
			this.ButtonNextGO.SetActive(false);
		}
		else
		{
			this.ButtonNextGO.SetActive(true);
			if (Singleton<ChallengeManager>.Instance.IsMonday)
			{
				if (Singleton<ChallengeManager>.Instance.AlreadyPlayed)
				{
					this.ButtonNext.enabled = true;
					this.m_oGoNormalBackground.enabled = true;
					this.m_oGoMonday.enabled = false;
					this.ButtonNext.ChangeTexture(1);
				}
				else
				{
					this.ButtonNext.enabled = false;
					this.m_oGoNormalBackground.enabled = false;
					this.m_oGoMonday.enabled = true;
				}
			}
			else
			{
				this.ButtonNext.enabled = true;
				this.m_oGoNormalBackground.enabled = true;
				this.m_oGoMonday.enabled = false;
				this.ButtonNext.ChangeTexture(0);
			}
		}
		if (this.TrackScreenshot != null)
		{
			Resources.UnloadAsset(this.TrackScreenshot.mainTexture);
			this.TrackScreenshot.mainTexture = (Resources.Load(Singleton<ChallengeManager>.Instance.ChampionshipData.Tracks[Singleton<ChallengeManager>.Instance.TrackIndex], typeof(Texture2D)) as Texture2D);
		}
	}

	// Token: 0x06000B05 RID: 2821 RVA: 0x00009904 File Offset: 0x00007B04
	public override void OnExit()
	{
		base.OnExit();
		Resources.UnloadAsset(this.TrackScreenshot.mainTexture);
	}

	// Token: 0x06000B06 RID: 2822 RVA: 0x0004A7A4 File Offset: 0x000489A4
	public void OnNext()
	{
		if (Singleton<ChallengeManager>.Instance.IsMonday && Singleton<ChallengeManager>.Instance.AlreadyPlayed)
		{
			this.m_pMenuEntryPoint.ShowPurchasePopup(string.Format(Localization.instance.Get("MENU_POPUP_BUY_ITEM_CONFIRMATION_CHALLENGE"), this.PriceRetry), this.PriceRetry, new MenuEntryPoint.Callback(this.PurchaseItem), null, null);
		}
		else
		{
			Singleton<ChallengeManager>.Instance.Launch();
		}
	}

	// Token: 0x06000B07 RID: 2823 RVA: 0x0000991C File Offset: 0x00007B1C
	public void PurchaseItem(object oParam)
	{
		Singleton<ChallengeManager>.Instance.Launch();
	}

	// Token: 0x06000B08 RID: 2824 RVA: 0x00009928 File Offset: 0x00007B28
	public void OnRegenerate()
	{
		Singleton<ChallengeManager>.Instance.ForceInit(this.MondayChecked.isChecked);
	}

	// Token: 0x04000ACE RID: 2766
	public UITexturePattern GameModeIcon;

	// Token: 0x04000ACF RID: 2767
	public UITexturePattern ChampionshipIcon;

	// Token: 0x04000AD0 RID: 2768
	public UITexturePattern DifficultyIcon;

	// Token: 0x04000AD1 RID: 2769
	public UISprite RewardIcon;

	// Token: 0x04000AD2 RID: 2770
	public UILabel FirstObjective;

	// Token: 0x04000AD3 RID: 2771
	public UILabel SecondObjective;

	// Token: 0x04000AD4 RID: 2772
	public UITexturePattern RewardRarityIcon;

	// Token: 0x04000AD5 RID: 2773
	public UILabel TrackName;

	// Token: 0x04000AD6 RID: 2774
	public UILabel ChampionshipName;

	// Token: 0x04000AD7 RID: 2775
	public UICheckbox MondayChecked;

	// Token: 0x04000AD8 RID: 2776
	public UILabel ChallengeName;

	// Token: 0x04000AD9 RID: 2777
	public UITexturePattern ChallengeState;

	// Token: 0x04000ADA RID: 2778
	public UITexturePattern ButtonNext;

	// Token: 0x04000ADB RID: 2779
	public GameObject ButtonNextGO;

	// Token: 0x04000ADC RID: 2780
	public int PriceRetry;

	// Token: 0x04000ADD RID: 2781
	public UITexture TrackScreenshot;

	// Token: 0x04000ADE RID: 2782
	private UISlicedSprite m_oGoMonday;

	// Token: 0x04000ADF RID: 2783
	private UISlicedSprite m_oGoNormalBackground;

	// Token: 0x04000AE0 RID: 2784
	private UILabel m_oLabelRetry;

	// Token: 0x04000AE1 RID: 2785
	public UITexturePattern SpriteChallenge;
}

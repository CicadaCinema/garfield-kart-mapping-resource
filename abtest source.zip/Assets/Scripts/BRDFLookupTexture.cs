﻿using System;
using UnityEngine;

// Token: 0x0200025D RID: 605
[ExecuteInEditMode]
public class BRDFLookupTexture : MonoBehaviour
{
	// Token: 0x06001089 RID: 4233 RVA: 0x0000D20B File Offset: 0x0000B40B
	private void Awake()
	{
		if (!this.lookupTexture)
		{
			this.Bake();
		}
	}

	// Token: 0x0600108A RID: 4234 RVA: 0x0000D223 File Offset: 0x0000B423
	private static Color ColorRGB(int r, int g, int b)
	{
		return new Color((float)r / 255f, (float)g / 255f, (float)b / 255f, 0f);
	}

	// Token: 0x0600108B RID: 4235 RVA: 0x00067A44 File Offset: 0x00065C44
	private void CheckConsistency()
	{
		this.intensity = Mathf.Max(0f, this.intensity);
		this.wrapAround = Mathf.Clamp(this.wrapAround, -1f, 1f);
		this.metalic = Mathf.Clamp(this.metalic, 0f, 12f);
		this.diffuseIntensity = Mathf.Max(0f, this.diffuseIntensity);
		this.specularIntensity = Mathf.Max(0f, this.specularIntensity);
		this.specularShininess = Mathf.Clamp(this.specularShininess, 0.01f, 1f);
		this.translucency = Mathf.Clamp01(this.translucency);
	}

	// Token: 0x0600108C RID: 4236 RVA: 0x00067AF8 File Offset: 0x00065CF8
	private Color PixelFunc(float ndotl, float ndoth)
	{
		ndotl *= Mathf.Pow(ndoth, this.metalic);
		float num = (1f + this.metalic * 0.25f) * Mathf.Max(0f, this.diffuseIntensity - (1f - ndoth) * this.metalic);
		float t = Mathf.Clamp01(Mathf.InverseLerp(-this.wrapAround, 1f, ndotl * 2f - 1f));
		float t2 = Mathf.Clamp01(Mathf.InverseLerp(-1f, Mathf.Max(-0.99f, -this.wrapAround), ndotl * 2f - 1f));
		Color a = num * Color.Lerp(this.backColor, Color.Lerp(this.fillColor, this.keyColor, t), t2);
		a += this.backColor * (1f - num) * Mathf.Clamp01(this.diffuseIntensity);
		float num2 = this.specularShininess * 128f;
		float num3 = (num2 + 2f) * (num2 + 4f) / (25.1327419f * (Mathf.Pow(2f, -num2 / 2f) + num2));
		float a2 = this.specularIntensity * num3 * Mathf.Pow(ndoth, num2);
		float num4 = ndotl + 0.1f;
		float b = 0.5f * this.translucency * Mathf.Clamp01(1f - num4 * ndoth) * Mathf.Clamp01(1f - ndotl);
		Color a3 = a * this.intensity + this.translucentColor * b + new Color(0f, 0f, 0f, a2);
		return a3 * this.intensity;
	}

	// Token: 0x0600108D RID: 4237 RVA: 0x00067CB8 File Offset: 0x00065EB8
	private void TextureFunc(Texture2D tex)
	{
		for (int i = 0; i < tex.height; i++)
		{
			for (int j = 0; j < tex.width; j++)
			{
				float num = (float)tex.width;
				float num2 = (float)tex.height;
				float num3 = (float)j / num;
				float num4 = (float)i / num2;
				float ndotl = num3;
				float ndoth = num4;
				Color color = this.PixelFunc(ndotl, ndoth);
				tex.SetPixel(j, i, color);
			}
		}
	}

	// Token: 0x0600108E RID: 4238 RVA: 0x00067D30 File Offset: 0x00065F30
	private void GenerateLookupTexture(int width, int height)
	{
		Texture2D texture2D;
		if (this.lookupTexture && this.lookupTexture.width == width && this.lookupTexture.height == height)
		{
			texture2D = this.lookupTexture;
		}
		else
		{
			texture2D = new Texture2D(width, height, TextureFormat.ARGB32, false);
		}
		this.CheckConsistency();
		this.TextureFunc(texture2D);
		texture2D.Apply();
		texture2D.wrapMode = TextureWrapMode.Clamp;
		if (this.lookupTexture != texture2D)
		{
			UnityEngine.Object.DestroyImmediate(this.lookupTexture);
		}
		this.lookupTexture = texture2D;
	}

	// Token: 0x0600108F RID: 4239 RVA: 0x0000D247 File Offset: 0x0000B447
	public void Preview()
	{
		this.GenerateLookupTexture(32, 64);
	}

	// Token: 0x06001090 RID: 4240 RVA: 0x0000D253 File Offset: 0x0000B453
	public void Bake()
	{
		this.GenerateLookupTexture(this.lookupTextureWidth, this.lookupTextureHeight);
	}

	// Token: 0x04000FC2 RID: 4034
	public float intensity = 1f;

	// Token: 0x04000FC3 RID: 4035
	public float diffuseIntensity = 1f;

	// Token: 0x04000FC4 RID: 4036
	public Color keyColor = BRDFLookupTexture.ColorRGB(188, 158, 118);

	// Token: 0x04000FC5 RID: 4037
	public Color fillColor = BRDFLookupTexture.ColorRGB(86, 91, 108);

	// Token: 0x04000FC6 RID: 4038
	public Color backColor = BRDFLookupTexture.ColorRGB(44, 54, 57);

	// Token: 0x04000FC7 RID: 4039
	public float wrapAround;

	// Token: 0x04000FC8 RID: 4040
	public float metalic;

	// Token: 0x04000FC9 RID: 4041
	public float specularIntensity = 1f;

	// Token: 0x04000FCA RID: 4042
	public float specularShininess = 0.078125f;

	// Token: 0x04000FCB RID: 4043
	public float translucency;

	// Token: 0x04000FCC RID: 4044
	public Color translucentColor = BRDFLookupTexture.ColorRGB(255, 82, 82);

	// Token: 0x04000FCD RID: 4045
	public int lookupTextureWidth = 128;

	// Token: 0x04000FCE RID: 4046
	public int lookupTextureHeight = 128;

	// Token: 0x04000FCF RID: 4047
	public bool fastPreview = true;

	// Token: 0x04000FD0 RID: 4048
	public Texture2D lookupTexture;
}

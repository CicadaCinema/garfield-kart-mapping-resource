﻿using System;

// Token: 0x02000259 RID: 601
[Serializable]
public class Tuple<T1, T2, T3, T4, T5> : Tuple<T1, T2, T3, T4>
{
	// Token: 0x06001080 RID: 4224 RVA: 0x00067850 File Offset: 0x00065A50
	public Tuple() : this(default(T1), default(T2), default(T3), default(T4), default(T5))
	{
	}

	// Token: 0x06001081 RID: 4225 RVA: 0x0000D1AB File Offset: 0x0000B3AB
	public Tuple(T1 pItem1, T2 pItem2, T3 pItem3, T4 pItem4, T5 pItem5) : base(pItem1, pItem2, pItem3, pItem4)
	{
		this.Item5 = pItem5;
	}

	// Token: 0x04000FBE RID: 4030
	public T5 Item5;
}

﻿using System;

// Token: 0x02000138 RID: 312
public class CharacterCarac : DrivingCarac
{
	// Token: 0x060008AD RID: 2221 RVA: 0x00006BC4 File Offset: 0x00004DC4
	public override void Start()
	{
		base.Start();
	}

	// Token: 0x060008AE RID: 2222 RVA: 0x0003F230 File Offset: 0x0003D430
	public static int Compare(CharacterCarac oItem1, CharacterCarac oItem2)
	{
		int num = CharacterCarac.CompareState(oItem1, oItem2);
		if (num == 0)
		{
			num = IconCarac.CompareName(oItem1, oItem2);
		}
		return num;
	}

	// Token: 0x060008AF RID: 2223 RVA: 0x0003F254 File Offset: 0x0003D454
	private static int CompareState(CharacterCarac oItem1, CharacterCarac oItem2)
	{
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		return IconCarac.SuppressNewState(instance.GetCharacterState(oItem2.Owner)) - IconCarac.SuppressNewState(instance.GetCharacterState(oItem1.Owner));
	}

	// Token: 0x040008E2 RID: 2274
	public EWeight Weight;

	// Token: 0x040008E3 RID: 2275
	public E_UnlockableItemSate State;
}

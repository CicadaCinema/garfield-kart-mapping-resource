﻿using System;
using UnityEngine;

// Token: 0x0200018E RID: 398
public class BtnItemAdvantage : MonoBehaviour
{
	// Token: 0x06000ABD RID: 2749 RVA: 0x000491D0 File Offset: 0x000473D0
	public void Start()
	{
		Transform parent = base.transform.parent;
		while (parent)
		{
			if (parent.GetComponent<PanelAdvantages>())
			{
				break;
			}
			parent = parent.parent;
		}
		if (parent)
		{
			this.m_pPanelAdvantages = parent.GetComponent<PanelAdvantages>();
		}
		this.m_iNb = -1;
		this.m_iNbLocked = 0;
		this.m_bDisabledFromRestriction = false;
		this.m_bColliderDisabled = false;
		this.OnInitialize();
		this.OnUpdatePanel();
	}

	// Token: 0x06000ABE RID: 2750 RVA: 0x00049254 File Offset: 0x00047454
	public void OnInitialize()
	{
		if (this.m_pPanelAdvantages)
		{
			if (this.m_pPanelAdvantages.IsAdvantageAvailable(this.m_eAdvantage))
			{
				this.m_bDisabledFromRestriction = false;
				if (this.m_pIcon)
				{
					UISprite component = this.m_pIcon.GetComponent<UISprite>();
					if (component)
					{
						component.alpha = 1f;
					}
					component = this.m_pIconNumber.GetComponent<UISprite>();
					if (component)
					{
						component.alpha = 1f;
					}
					if (this.m_oLabel != null)
					{
						this.m_oLabel.alpha = 1f;
					}
				}
			}
			else
			{
				this.m_bDisabledFromRestriction = true;
				if (this.m_pIcon)
				{
					UISprite component2 = this.m_pIcon.GetComponent<UISprite>();
					if (component2)
					{
						component2.alpha = 0.3f;
					}
					component2 = this.m_pIconNumber.GetComponent<UISprite>();
					if (component2)
					{
						component2.alpha = 0.3f;
					}
					if (this.m_oLabel != null)
					{
						this.m_oLabel.alpha = 0.3f;
					}
				}
			}
			this.UpdateCollider();
			this.m_pItemLink = null;
		}
	}

	// Token: 0x06000ABF RID: 2751 RVA: 0x00049394 File Offset: 0x00047594
	private void OnPress(bool bIsPressed)
	{
		if (bIsPressed)
		{
			BtnSlotAdvantage freeSlot = this.m_pPanelAdvantages.GetFreeSlot();
			if (freeSlot != null)
			{
				freeSlot.SetItem(this);
			}
			else if (this.SlotsFullErrorSound)
			{
				this.SlotsFullErrorSound.Play();
			}
			if (!this.m_pItemLink)
			{
				this.m_pItemLink = this.m_pPanelAdvantages.GetAdvantageBtnItem(this.m_eAdvantage);
			}
			if (this.m_pItemLink)
			{
				this.m_pItemLink.gameObject.SendMessage("OnClick");
			}
			this.OnUpdatePanel();
		}
	}

	// Token: 0x06000AC0 RID: 2752 RVA: 0x00049438 File Offset: 0x00047638
	public void OnUpdatePanel()
	{
		int num = Singleton<GameSaveManager>.Instance.GetAdvantageQuantity(this.m_eAdvantage) - this.m_iNbLocked;
		if (this.m_iNb == num)
		{
			return;
		}
		if (this.m_oLabel && this.m_pIcon && this.m_pIconNumber)
		{
			if (num > 0)
			{
				this.m_oLabel.text = num.ToString();
				if (this.m_iNb <= 0)
				{
					this.m_oLabel.gameObject.SetActive(true);
					this.m_pIcon.SetActive(true);
					this.m_pIconNumber.SetActive(true);
					this.m_bColliderDisabled = false;
				}
			}
			else
			{
				this.m_oLabel.gameObject.SetActive(false);
				this.m_pIcon.SetActive(false);
				this.m_pIconNumber.SetActive(false);
				this.m_bColliderDisabled = true;
			}
			this.UpdateCollider();
			this.m_iNb = num;
		}
	}

	// Token: 0x06000AC1 RID: 2753 RVA: 0x000095ED File Offset: 0x000077ED
	public void LockItem()
	{
		this.m_iNbLocked++;
	}

	// Token: 0x06000AC2 RID: 2754 RVA: 0x000095FD File Offset: 0x000077FD
	public void UnlockItem()
	{
		this.m_iNbLocked--;
		if (this.m_iNbLocked < 0)
		{
		}
		this.OnUpdatePanel();
	}

	// Token: 0x06000AC3 RID: 2755 RVA: 0x0000961F File Offset: 0x0000781F
	private void UpdateCollider()
	{
		if (base.collider)
		{
			base.collider.enabled = (!this.m_bColliderDisabled && !this.m_bDisabledFromRestriction);
		}
	}

	// Token: 0x04000A8E RID: 2702
	private PanelAdvantages m_pPanelAdvantages;

	// Token: 0x04000A8F RID: 2703
	public EAdvantage m_eAdvantage;

	// Token: 0x04000A90 RID: 2704
	public UILabel m_oLabel;

	// Token: 0x04000A91 RID: 2705
	public GameObject m_pIcon;

	// Token: 0x04000A92 RID: 2706
	public GameObject m_pIconNumber;

	// Token: 0x04000A93 RID: 2707
	private int m_iNb;

	// Token: 0x04000A94 RID: 2708
	private int m_iNbLocked;

	// Token: 0x04000A95 RID: 2709
	public Transform m_pItemLink;

	// Token: 0x04000A96 RID: 2710
	private bool m_bDisabledFromRestriction;

	// Token: 0x04000A97 RID: 2711
	private bool m_bColliderDisabled;

	// Token: 0x04000A98 RID: 2712
	public AudioSource SlotsFullErrorSound;
}

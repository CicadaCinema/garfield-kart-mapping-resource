﻿using System;
using UnityEngine;

// Token: 0x020001FF RID: 511
public class RcFastValuePathComp : MonoBehaviour
{
	// Token: 0x06000DD8 RID: 3544 RVA: 0x0000B818 File Offset: 0x00009A18
	public RcFastValuePathComp()
	{
		this.m_fValue = 0f;
	}

	// Token: 0x06000DD9 RID: 3545 RVA: 0x0000B82B File Offset: 0x00009A2B
	public float GetValue()
	{
		return this.m_fValue;
	}

	// Token: 0x06000DDA RID: 3546 RVA: 0x0000B833 File Offset: 0x00009A33
	public int GetIntValue()
	{
		return (int)this.m_fValue;
	}

	// Token: 0x04000D67 RID: 3431
	public float m_fValue;
}

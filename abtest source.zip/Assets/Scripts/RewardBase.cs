﻿using System;
using UnityEngine;

// Token: 0x02000156 RID: 342
public abstract class RewardBase : MonoBehaviour
{
	// Token: 0x06000984 RID: 2436 RVA: 0x000432EC File Offset: 0x000414EC
	public void GiveReward()
	{
		RewardConditionBase[] components = base.gameObject.GetComponents<RewardConditionBase>();
		if (components.Length > 0)
		{
			bool flag = components[0].CanGiveReward();
			if (this.ConditionOperator == E_ConditionOperator.AND)
			{
				for (int i = 1; i < components.Length; i++)
				{
					flag = (flag && components[i].CanGiveReward());
				}
			}
			else
			{
				for (int j = 1; j < components.Length; j++)
				{
					flag = (flag || components[j].CanGiveReward());
				}
			}
			if (flag)
			{
				this.GetReward();
			}
		}
	}

	// Token: 0x06000985 RID: 2437
	protected abstract void GetReward();

	// Token: 0x040009BC RID: 2492
	public E_ConditionOperator ConditionOperator;
}

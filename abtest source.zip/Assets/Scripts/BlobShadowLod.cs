﻿using System;
using UnityEngine;

// Token: 0x02000135 RID: 309
public class BlobShadowLod : MonoBehaviour
{
	// Token: 0x060008A8 RID: 2216 RVA: 0x0000815F File Offset: 0x0000635F
	public void Start()
	{
		if (!this.m_pBlobShadow)
		{
			return;
		}
		if (Shader.globalMaximumLOD > 500)
		{
			this.m_pBlobShadow.material.shader = Shader.Find("Garfield/ProjectorMultiply");
		}
	}

	// Token: 0x060008A9 RID: 2217 RVA: 0x0000819B File Offset: 0x0000639B
	public void Update()
	{
		this.m_pBlobShadow.enabled = false;
	}

	// Token: 0x060008AA RID: 2218 RVA: 0x000081A9 File Offset: 0x000063A9
	public void OnWillRenderObject()
	{
		if (this.m_pBlobShadow)
		{
			this.m_pBlobShadow.enabled = true;
		}
	}

	// Token: 0x060008AB RID: 2219 RVA: 0x000081C7 File Offset: 0x000063C7
	public void OnRenderObject()
	{
		if (this.m_pBlobShadow)
		{
			this.m_pBlobShadow.enabled = false;
		}
	}

	// Token: 0x040008D3 RID: 2259
	public Projector m_pBlobShadow;
}

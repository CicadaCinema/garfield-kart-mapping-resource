﻿using System;

// Token: 0x0200009E RID: 158
public class GkFastPathDriftValueComp : RcFastValuePathComp
{
	// Token: 0x040003A0 RID: 928
	public E_DriftOrientation Orientation;
}

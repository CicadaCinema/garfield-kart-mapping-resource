﻿using System;
using UnityEngine;

// Token: 0x02000075 RID: 117
[AddComponentMenu("NGUI/UI/Input (Basic)")]
public class UIInput : MonoBehaviour
{
	// Token: 0x1700008B RID: 139
	// (get) Token: 0x0600031B RID: 795 RVA: 0x00004648 File Offset: 0x00002848
	// (set) Token: 0x0600031C RID: 796 RVA: 0x0001DAE8 File Offset: 0x0001BCE8
	public virtual string text
	{
		get
		{
			if (this.mDoInit)
			{
				this.Init();
			}
			return this.mText;
		}
		set
		{
			if (this.mDoInit)
			{
				this.Init();
			}
			this.mText = value;
			if (this.label != null)
			{
				if (string.IsNullOrEmpty(value))
				{
					value = this.mDefaultText;
				}
				this.label.supportEncoding = false;
				this.label.text = ((!this.selected) ? value : (value + this.caratChar));
				this.label.showLastPasswordChar = this.selected;
				this.label.color = ((!this.selected && !(value != this.mDefaultText)) ? this.mDefaultColor : this.activeColor);
			}
		}
	}

	// Token: 0x1700008C RID: 140
	// (get) Token: 0x0600031D RID: 797 RVA: 0x00004661 File Offset: 0x00002861
	// (set) Token: 0x0600031E RID: 798 RVA: 0x00004673 File Offset: 0x00002873
	public bool selected
	{
		get
		{
			return UICamera.selectedObject == base.gameObject;
		}
		set
		{
			if (!value && UICamera.selectedObject == base.gameObject)
			{
				UICamera.selectedObject = null;
			}
			else if (value)
			{
				UICamera.selectedObject = base.gameObject;
			}
		}
	}

	// Token: 0x1700008D RID: 141
	// (get) Token: 0x0600031F RID: 799 RVA: 0x000046AC File Offset: 0x000028AC
	// (set) Token: 0x06000320 RID: 800 RVA: 0x000046B4 File Offset: 0x000028B4
	public string defaultText
	{
		get
		{
			return this.mDefaultText;
		}
		set
		{
			if (this.label.text == this.mDefaultText)
			{
				this.label.text = value;
			}
			this.mDefaultText = value;
		}
	}

	// Token: 0x06000321 RID: 801 RVA: 0x0001DBB0 File Offset: 0x0001BDB0
	protected void Init()
	{
		if (this.mDoInit)
		{
			this.mDoInit = false;
			if (this.label == null)
			{
				this.label = base.GetComponentInChildren<UILabel>();
			}
			if (this.label != null)
			{
				if (this.useLabelTextAtStart)
				{
					this.mText = this.label.text;
				}
				this.mDefaultText = this.label.text;
				this.mDefaultColor = this.label.color;
				this.label.supportEncoding = false;
				this.label.password = this.isPassword;
				this.mPivot = this.label.pivot;
				this.mPosition = this.label.cachedTransform.localPosition.x;
			}
			else
			{
				base.enabled = false;
			}
		}
	}

	// Token: 0x06000322 RID: 802 RVA: 0x000046E4 File Offset: 0x000028E4
	private void OnEnable()
	{
		if (UICamera.IsHighlighted(base.gameObject))
		{
			this.OnSelect(true);
		}
	}

	// Token: 0x06000323 RID: 803 RVA: 0x000046FD File Offset: 0x000028FD
	private void OnDisable()
	{
		if (UICamera.IsHighlighted(base.gameObject))
		{
			this.OnSelect(false);
		}
	}

	// Token: 0x06000324 RID: 804 RVA: 0x0001DC94 File Offset: 0x0001BE94
	private void OnSelect(bool isSelected)
	{
		if (this.mDoInit)
		{
			this.Init();
		}
		if (this.label != null && base.enabled && NGUITools.GetActive(base.gameObject))
		{
			if (isSelected)
			{
				this.mText = ((this.useLabelTextAtStart || !(this.label.text == this.mDefaultText)) ? this.label.text : string.Empty);
				this.label.color = this.activeColor;
				if (this.isPassword)
				{
					this.label.password = true;
				}
				Input.imeCompositionMode = IMECompositionMode.On;
				Transform cachedTransform = this.label.cachedTransform;
				Vector3 position = this.label.pivotOffset;
				position.y += this.label.relativeSize.y;
				position = cachedTransform.TransformPoint(position);
				Input.compositionCursorPos = UICamera.currentCamera.WorldToScreenPoint(position);
				this.UpdateLabel();
			}
			else
			{
				if (string.IsNullOrEmpty(this.mText))
				{
					this.label.text = this.mDefaultText;
					this.label.color = this.mDefaultColor;
					if (this.isPassword)
					{
						this.label.password = false;
					}
				}
				else
				{
					this.label.text = this.mText;
				}
				this.label.showLastPasswordChar = false;
				Input.imeCompositionMode = IMECompositionMode.Off;
				this.RestoreLabel();
			}
		}
	}

	// Token: 0x06000325 RID: 805 RVA: 0x0001DE30 File Offset: 0x0001C030
	private void Update()
	{
		if (this.selected)
		{
			if (this.selectOnTab != null && Input.GetKeyDown(KeyCode.Tab))
			{
				UICamera.selectedObject = this.selectOnTab;
			}
			if (Input.GetKeyDown(KeyCode.V) && (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl)))
			{
				this.Append(NGUITools.clipboard);
			}
			if (this.mLastIME != Input.compositionString)
			{
				this.mLastIME = Input.compositionString;
				this.UpdateLabel();
			}
		}
	}

	// Token: 0x06000326 RID: 806 RVA: 0x0001DECC File Offset: 0x0001C0CC
	private void OnInput(string input)
	{
		if (this.mDoInit)
		{
			this.Init();
		}
		if (this.selected && base.enabled && NGUITools.GetActive(base.gameObject))
		{
			if (Application.platform == RuntimePlatform.Android)
			{
				return;
			}
			if (Application.platform == RuntimePlatform.IPhonePlayer)
			{
				return;
			}
			this.Append(input);
		}
	}

	// Token: 0x06000327 RID: 807 RVA: 0x0001DF30 File Offset: 0x0001C130
	private void Append(string input)
	{
		int i = 0;
		int length = input.Length;
		while (i < length)
		{
			char c = input[i];
			if (c == '\b')
			{
				if (this.mText.Length > 0)
				{
					this.mText = this.mText.Substring(0, this.mText.Length - 1);
					base.SendMessage("OnInputChanged", this, SendMessageOptions.DontRequireReceiver);
				}
			}
			else if (c == '\r' || c == '\n')
			{
				if ((UICamera.current.submitKey0 == KeyCode.Return || UICamera.current.submitKey1 == KeyCode.Return) && (!this.label.multiLine || (!Input.GetKey(KeyCode.LeftControl) && !Input.GetKey(KeyCode.RightControl))))
				{
					UIInput.current = this;
					if (this.onSubmit != null)
					{
						this.onSubmit(this.mText);
					}
					if (this.eventReceiver == null)
					{
						this.eventReceiver = base.gameObject;
					}
					this.eventReceiver.SendMessage(this.functionName, this.mText, SendMessageOptions.DontRequireReceiver);
					UIInput.current = null;
					this.selected = false;
					return;
				}
				if (this.validator != null)
				{
					c = this.validator(this.mText, c);
				}
				if (c != '\0')
				{
					if (c == '\n' || c == '\r')
					{
						if (this.label.multiLine)
						{
							this.mText += "\n";
						}
					}
					else
					{
						this.mText += c;
					}
					base.SendMessage("OnInputChanged", this, SendMessageOptions.DontRequireReceiver);
				}
			}
			else if (c >= ' ')
			{
				if (this.validator != null)
				{
					c = this.validator(this.mText, c);
				}
				if (c != '\0')
				{
					this.mText += c;
					base.SendMessage("OnInputChanged", this, SendMessageOptions.DontRequireReceiver);
				}
			}
			i++;
		}
		this.UpdateLabel();
	}

	// Token: 0x06000328 RID: 808 RVA: 0x0001E154 File Offset: 0x0001C354
	private void UpdateLabel()
	{
		if (this.mDoInit)
		{
			this.Init();
		}
		if (this.maxChars > 0 && this.mText.Length > this.maxChars)
		{
			this.mText = this.mText.Substring(0, this.maxChars);
		}
		if (this.label.font != null)
		{
			string text;
			if (this.isPassword && this.selected)
			{
				text = string.Empty;
				int i = 0;
				int length = this.mText.Length;
				while (i < length)
				{
					text += "*";
					i++;
				}
				text = text + Input.compositionString + this.caratChar;
			}
			else
			{
				text = ((!this.selected) ? this.mText : (this.mText + Input.compositionString + this.caratChar));
			}
			this.label.supportEncoding = false;
			if (!this.label.shrinkToFit)
			{
				if (this.label.multiLine)
				{
					text = this.label.font.WrapText(text, (float)this.label.lineWidth / this.label.cachedTransform.localScale.x, 0, false, UIFont.SymbolStyle.None);
				}
				else
				{
					string endOfLineThatFits = this.label.font.GetEndOfLineThatFits(text, (float)this.label.lineWidth / this.label.cachedTransform.localScale.x, false, UIFont.SymbolStyle.None);
					if (endOfLineThatFits != text)
					{
						text = endOfLineThatFits;
						Vector3 localPosition = this.label.cachedTransform.localPosition;
						localPosition.x = this.mPosition + (float)this.label.lineWidth;
						if (this.mPivot == UIWidget.Pivot.Left)
						{
							this.label.pivot = UIWidget.Pivot.Right;
						}
						else if (this.mPivot == UIWidget.Pivot.TopLeft)
						{
							this.label.pivot = UIWidget.Pivot.TopRight;
						}
						else if (this.mPivot == UIWidget.Pivot.BottomLeft)
						{
							this.label.pivot = UIWidget.Pivot.BottomRight;
						}
						this.label.cachedTransform.localPosition = localPosition;
					}
					else
					{
						this.RestoreLabel();
					}
				}
			}
			this.label.text = text;
			this.label.showLastPasswordChar = this.selected;
		}
	}

	// Token: 0x06000329 RID: 809 RVA: 0x0001E3B8 File Offset: 0x0001C5B8
	private void RestoreLabel()
	{
		if (this.label != null)
		{
			this.label.pivot = this.mPivot;
			Vector3 localPosition = this.label.cachedTransform.localPosition;
			localPosition.x = this.mPosition;
			this.label.cachedTransform.localPosition = localPosition;
		}
	}

	// Token: 0x040002AA RID: 682
	public static UIInput current;

	// Token: 0x040002AB RID: 683
	public UILabel label;

	// Token: 0x040002AC RID: 684
	public int maxChars;

	// Token: 0x040002AD RID: 685
	public string caratChar = "|";

	// Token: 0x040002AE RID: 686
	public UIInput.Validator validator;

	// Token: 0x040002AF RID: 687
	public UIInput.KeyboardType type;

	// Token: 0x040002B0 RID: 688
	public bool isPassword;

	// Token: 0x040002B1 RID: 689
	public bool autoCorrect;

	// Token: 0x040002B2 RID: 690
	public bool useLabelTextAtStart;

	// Token: 0x040002B3 RID: 691
	public Color activeColor = Color.white;

	// Token: 0x040002B4 RID: 692
	public GameObject selectOnTab;

	// Token: 0x040002B5 RID: 693
	public GameObject eventReceiver;

	// Token: 0x040002B6 RID: 694
	public string functionName = "OnSubmit";

	// Token: 0x040002B7 RID: 695
	public UIInput.OnSubmit onSubmit;

	// Token: 0x040002B8 RID: 696
	private string mText = string.Empty;

	// Token: 0x040002B9 RID: 697
	private string mDefaultText = string.Empty;

	// Token: 0x040002BA RID: 698
	private Color mDefaultColor = Color.white;

	// Token: 0x040002BB RID: 699
	private UIWidget.Pivot mPivot = UIWidget.Pivot.Left;

	// Token: 0x040002BC RID: 700
	private float mPosition;

	// Token: 0x040002BD RID: 701
	private string mLastIME = string.Empty;

	// Token: 0x040002BE RID: 702
	private bool mDoInit = true;

	// Token: 0x02000076 RID: 118
	public enum KeyboardType
	{
		// Token: 0x040002C0 RID: 704
		Default,
		// Token: 0x040002C1 RID: 705
		ASCIICapable,
		// Token: 0x040002C2 RID: 706
		NumbersAndPunctuation,
		// Token: 0x040002C3 RID: 707
		URL,
		// Token: 0x040002C4 RID: 708
		NumberPad,
		// Token: 0x040002C5 RID: 709
		PhonePad,
		// Token: 0x040002C6 RID: 710
		NamePhonePad,
		// Token: 0x040002C7 RID: 711
		EmailAddress
	}

	// Token: 0x02000077 RID: 119
	// (Invoke) Token: 0x0600032B RID: 811
	public delegate char Validator(string currentText, char nextChar);

	// Token: 0x02000078 RID: 120
	// (Invoke) Token: 0x0600032F RID: 815
	public delegate void OnSubmit(string inputString);
}

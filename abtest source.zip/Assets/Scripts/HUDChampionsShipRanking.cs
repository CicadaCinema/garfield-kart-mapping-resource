﻿using System;

// Token: 0x02000103 RID: 259
public class HUDChampionsShipRanking : HUDEndRace
{
	// Token: 0x06000710 RID: 1808 RVA: 0x0003552C File Offset: 0x0003372C
	public override void FillPositions()
	{
		base.FillPositions();
		if (Singleton<GameConfigurator>.Instance.ChampionShipData != null)
		{
			string championShipName = Singleton<GameConfigurator>.Instance.ChampionShipData.ChampionShipName;
			this.LabelTitle.text = string.Format(Localization.instance.Get("HUD_DYN_CHAMPIONSHIP_GENERAL"), championShipName);
		}
		for (int i = 0; i < this.PointsToAdd.Count; i++)
		{
			this.LabelPoint[i].text = this.PointsToAdd[i].ToString() + " pts";
		}
		foreach (UISprite uisprite in this.m_Advantage)
		{
			uisprite.gameObject.SetActive(false);
		}
	}

	// Token: 0x06000711 RID: 1809 RVA: 0x00035624 File Offset: 0x00033824
	public override void GetScoreInfos(int iIndex, out int iKartIndex, out int iScore, out int iTotalScore, out bool bEquality)
	{
		ChampionShipScoreData championshipPos = Singleton<GameConfigurator>.Instance.RankingManager.GetChampionshipPos(iIndex);
		if (LogManager.Instance == null || championshipPos.KartIndex == Singleton<GameManager>.Instance.GameMode.GetHumanPlayerVehicleId())
		{
		}
		if (iIndex > 0)
		{
			ChampionShipScoreData championshipPos2 = Singleton<GameConfigurator>.Instance.RankingManager.GetChampionshipPos(iIndex - 1);
			bEquality = (championshipPos.ChampionshipScore == championshipPos2.ChampionshipScore);
		}
		else
		{
			bEquality = false;
		}
		iKartIndex = championshipPos.KartIndex;
		iScore = championshipPos.ChampionshipScore;
		iTotalScore = 0;
	}

	// Token: 0x06000712 RID: 1810 RVA: 0x000070B0 File Offset: 0x000052B0
	public override int GetTrackIndex()
	{
		return Singleton<GameConfigurator>.Instance.CurrentTrackIndex - 1;
	}

	// Token: 0x06000713 RID: 1811 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void Update()
	{
	}
}

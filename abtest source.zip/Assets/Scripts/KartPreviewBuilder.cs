﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000149 RID: 329
public class KartPreviewBuilder : MonoBehaviour
{
	// Token: 0x06000943 RID: 2371 RVA: 0x000086F4 File Offset: 0x000068F4
	public void Init()
	{
		this.DestroyKartPreview();
		this.m_eKart = ECharacter.NONE;
		this.m_sCustomName = string.Empty;
		this.m_sHatName = string.Empty;
		this.m_eKart = ECharacter.NONE;
		this.m_iSuccesAnim = Animator.StringToHash("End_Of_Race.Victory");
	}

	// Token: 0x06000944 RID: 2372 RVA: 0x00041908 File Offset: 0x0003FB08
	public void DestroyKartPreview()
	{
		if (this.m_oKartPreview)
		{
			UnityEngine.Object.Destroy(this.m_oKartPreview);
			this.m_oKartPreview = null;
		}
		if (this.m_oKartCustomPreview)
		{
			UnityEngine.Object.Destroy(this.m_oKartCustomPreview);
			this.m_oKartCustomPreview = null;
		}
		if (this.m_oCharacterPreview)
		{
			UnityEngine.Object.Destroy(this.m_oCharacterPreview);
			this.m_oCharacterPreview = null;
		}
		if (this.m_oHatPreview)
		{
			UnityEngine.Object.Destroy(this.m_oHatPreview);
			this.m_oHatPreview = null;
		}
		Resources.UnloadUnusedAssets();
	}

	// Token: 0x06000945 RID: 2373 RVA: 0x000419A4 File Offset: 0x0003FBA4
	public void Build(ECharacter eCharacter, ECharacter eKart, string sCustomName, string sHatName)
	{
		PlayerConfig playerConfig = Singleton<GameConfigurator>.Instance.PlayerConfig;
		if (this.m_oKartPreview && this.m_eKart != eKart)
		{
			UnityEngine.Object.Destroy(this.m_oKartPreview);
			this.m_oKartPreview = null;
		}
		if (!this.m_oKartPreview)
		{
			this.m_oKartPreview = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("Kart/" + playerConfig.KartPrefab[(int)eKart]));
			this.ForceLod0(this.m_oKartPreview);
		}
		this.m_eKart = eKart;
		if (this.m_oCharacterPreview && this.m_eCharacter != eCharacter)
		{
			UnityEngine.Object.Destroy(this.m_oCharacterPreview);
			this.m_oCharacterPreview = null;
		}
		if (!this.m_oCharacterPreview)
		{
			this.m_oCharacterPreview = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("Character/" + playerConfig.CharacterPrefab[(int)eCharacter]));
			this.ForceLod0(this.m_oCharacterPreview);
			if (this.SelectionVoices[(int)eCharacter])
			{
				this.SelectionVoices[(int)eCharacter].Play();
			}
			if (this.m_oCharacterPreview)
			{
				this.m_pCharacterAnimator = this.m_oCharacterPreview.GetComponent<Animator>();
				if (this.m_pCharacterAnimator)
				{
					this.m_pCharacterAnimator.SetBool("Victory", true);
				}
			}
		}
		this.m_eCharacter = eCharacter;
		if (this.m_oKartCustomPreview && this.m_sCustomName != sCustomName)
		{
			UnityEngine.Object.Destroy(this.m_oKartCustomPreview);
			this.m_oKartCustomPreview = null;
		}
		if (!this.m_oKartCustomPreview)
		{
			this.m_oKartCustomPreview = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("Kart/" + sCustomName));
			this.ForceLod0(this.m_oKartCustomPreview);
		}
		this.m_sCustomName = sCustomName;
		if (this.m_oHatPreview && this.m_sHatName != sHatName)
		{
			UnityEngine.Object.Destroy(this.m_oHatPreview);
			this.m_oHatPreview = null;
		}
		if (!this.m_oHatPreview)
		{
			this.m_oHatPreview = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("Hat/" + sHatName));
			this.ForceLod0(this.m_oHatPreview);
		}
		Resources.UnloadUnusedAssets();
		this.m_sHatName = sHatName;
		this.m_oHatPreview.transform.parent = null;
		this.m_oCharacterPreview.transform.parent = null;
		this.m_oKartPreview.transform.parent = null;
		this.m_oKartCustomPreview.transform.parent = null;
		this.m_oKartPreview.transform.localPosition = Vector3.zero;
		this.m_oKartPreview.transform.localRotation = Quaternion.identity;
		this.m_oCharacterPreview.transform.localPosition = Vector3.zero;
		this.m_oCharacterPreview.transform.localRotation = Quaternion.identity;
		this.m_oHatPreview.transform.localPosition = Vector3.zero;
		this.m_oHatPreview.transform.localRotation = Quaternion.identity;
		this.m_oHatPreview.transform.localScale = Vector3.one;
		this.m_oKartCustomPreview.transform.localPosition = Vector3.zero;
		this.m_oKartCustomPreview.transform.localRotation = Quaternion.identity;
		Transform child = this.m_oCharacterPreview.transform.GetChild(0);
		this.m_oHatPreview.transform.parent = child.transform.Find("b_cat Attachment/b_cat Root/b_cat Pelvis/b_cat Spine/b_cat Neck/b_cat Head");
		if (this.m_oHatPreview.transform.parent == null)
		{
			this.m_oHatPreview.transform.parent = this.m_oCharacterPreview.transform.Find("b_cat Attachment/b_cat Root/b_cat Pelvis/b_cat Spine/b_cat Neck/b_cat Head");
		}
		this.m_oHatPreview.transform.localPosition = Vector3.zero;
		BonusCustom component = this.m_oHatPreview.GetComponent<BonusCustom>();
		if (component)
		{
			Template template = component.GetTemplate(eCharacter);
			if (template != null)
			{
				this.m_oHatPreview.transform.localPosition = template.Position;
				this.m_oHatPreview.transform.localScale = template.Scale;
			}
			this.m_oHatPreview.transform.localRotation = Quaternion.Euler(270f, 90f, 0f);
		}
		this.m_oCharacterPreview.transform.parent = this.m_oKartPreview.transform.Find("Kart(Clone)/b_kart_root/b_kart_body");
		this.m_oKartCustomPreview.transform.parent = this.m_oCharacterPreview.transform.parent;
		this.m_oKartCustomPreview.transform.localRotation = Quaternion.Euler(90f, 270f, 0f);
		this.m_oKartPreview.transform.parent = base.transform;
		this.m_oKartPreview.transform.localPosition = Vector3.zero;
		this.m_oKartPreview.transform.localRotation = Quaternion.identity;
		LodRemote component2 = this.m_oKartPreview.GetComponent<LodRemote>();
		if (component2)
		{
			component2.m_pLodGroupReceiver[0] = this.m_oCharacterPreview.GetComponent<LODGroup>();
			component2.m_pLodGroupReceiver[1] = this.m_oHatPreview.GetComponent<LODGroup>();
			component2.m_pLodGroupReceiver[2] = this.m_oKartCustomPreview.GetComponent<LODGroup>();
		}
		this.m_fSpeed = this.m_fSpeedRotation;
	}

	// Token: 0x06000946 RID: 2374 RVA: 0x00041F1C File Offset: 0x0004011C
	public void Update()
	{
		if (!this.m_bDrag)
		{
			float deltaTime = Time.deltaTime;
			if (deltaTime > 0f)
			{
				this.m_fSpeed = Tricks.ComputeInertia(this.m_fSpeed, this.m_fSpeedRotation, this.m_fRotationInertia, deltaTime);
				base.transform.Rotate(new Vector3(0f, this.m_fSpeed * deltaTime, 0f));
				if (this.m_pCharacterAnimator && this.m_pCharacterAnimator.GetCurrentAnimatorStateInfo(0).nameHash == this.m_iSuccesAnim)
				{
					this.m_pCharacterAnimator.SetBool("Victory", false);
				}
			}
		}
	}

	// Token: 0x06000947 RID: 2375 RVA: 0x00041FC8 File Offset: 0x000401C8
	private void OnDrag(Vector2 oDelta)
	{
		this.m_fSpeed = -0.3f * oDelta.x / Time.deltaTime;
		base.transform.Rotate(new Vector3(0f, this.m_fSpeed * Time.deltaTime, 0f));
	}

	// Token: 0x06000948 RID: 2376 RVA: 0x00008730 File Offset: 0x00006930
	private void OnPress(bool bIsPressed)
	{
		this.m_bDrag = bIsPressed;
	}

	// Token: 0x06000949 RID: 2377 RVA: 0x00042014 File Offset: 0x00040214
	private void ForceLod0(GameObject pObj)
	{
		if (!pObj)
		{
			return;
		}
		LODGroup component = pObj.GetComponent<LODGroup>();
		if (!component)
		{
			return;
		}
		component.ForceLOD(0);
	}

	// Token: 0x04000964 RID: 2404
	private GameObject m_oKartPreview;

	// Token: 0x04000965 RID: 2405
	private GameObject m_oCharacterPreview;

	// Token: 0x04000966 RID: 2406
	private GameObject m_oHatPreview;

	// Token: 0x04000967 RID: 2407
	private GameObject m_oKartCustomPreview;

	// Token: 0x04000968 RID: 2408
	private ECharacter m_eCharacter;

	// Token: 0x04000969 RID: 2409
	private ECharacter m_eKart;

	// Token: 0x0400096A RID: 2410
	private string m_sCustomName;

	// Token: 0x0400096B RID: 2411
	private string m_sHatName;

	// Token: 0x0400096C RID: 2412
	public float m_fSpeedRotation;

	// Token: 0x0400096D RID: 2413
	public float m_fRotationInertia = 0.3f;

	// Token: 0x0400096E RID: 2414
	private float m_fSpeed;

	// Token: 0x0400096F RID: 2415
	private bool m_bDrag;

	// Token: 0x04000970 RID: 2416
	private Animator m_pCharacterAnimator;

	// Token: 0x04000971 RID: 2417
	private int m_iSuccesAnim;

	// Token: 0x04000972 RID: 2418
	[HideInInspector]
	public List<AudioSource> SelectionVoices = new List<AudioSource>();
}

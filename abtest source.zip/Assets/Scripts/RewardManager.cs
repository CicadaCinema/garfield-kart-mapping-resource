﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000C3 RID: 195
public class RewardManager : Singleton<RewardManager>
{
	// Token: 0x170000E8 RID: 232
	// (get) Token: 0x060004F1 RID: 1265 RVA: 0x000058A4 File Offset: 0x00003AA4
	// (set) Token: 0x060004F2 RID: 1266 RVA: 0x000058AC File Offset: 0x00003AAC
	public int PlayerRank
	{
		get
		{
			return this._playerRank;
		}
		set
		{
			this._playerRank = value;
		}
	}

	// Token: 0x170000E9 RID: 233
	// (get) Token: 0x060004F3 RID: 1267 RVA: 0x000058B5 File Offset: 0x00003AB5
	// (set) Token: 0x060004F4 RID: 1268 RVA: 0x000058BD File Offset: 0x00003ABD
	public E_TimeTrialMedal Medal
	{
		get
		{
			return this._medal;
		}
		set
		{
			this._medal = value;
		}
	}

	// Token: 0x170000EA RID: 234
	// (get) Token: 0x060004F5 RID: 1269 RVA: 0x000058C6 File Offset: 0x00003AC6
	public int Coins
	{
		get
		{
			return this._coins;
		}
	}

	// Token: 0x170000EB RID: 235
	// (get) Token: 0x060004F6 RID: 1270 RVA: 0x000058CE File Offset: 0x00003ACE
	// (set) Token: 0x060004F7 RID: 1271 RVA: 0x000058D6 File Offset: 0x00003AD6
	public int RaceCoins
	{
		get
		{
			return this._raceCoins;
		}
		set
		{
			this._raceCoins = value;
		}
	}

	// Token: 0x060004F8 RID: 1272 RVA: 0x00029B80 File Offset: 0x00027D80
	public void Reset()
	{
		this._coins = 0;
		this._raceCoins = 0;
		this._puzzlePieces = new List<string>();
		this._comicStrips = new List<string>();
		this._unlockedHats = new List<Tuple<string, ERarity>>();
		this._unlockedCustoms = new List<Tuple<string, ERarity>>();
		this._lockedCustoms = new List<string>();
		this._lockedHats = new List<string>();
		this._characters = new List<string>();
		this._karts = new List<string>();
		this._lockedChampionShips = new List<Tuple<string, EDifficulty>>();
		this._unlockedChampionShips = new List<Tuple<string, EDifficulty>>();
		this._advantages = new List<string>();
		this._timeTrial = new Tuple<int, string>(-1, string.Empty);
		this._tradedReward = null;
		this._wonTimeTrialStar = false;
		this._wonEasyChampionShipStar = false;
		this._wonNormalChampionShipStar = false;
		this._wonHardChampionShipStar = false;
		this._wonEndStar = false;
		this.m_eFirstRewardToGive = E_RewardType.Custom;
	}

	// Token: 0x060004F9 RID: 1273 RVA: 0x000058DF File Offset: 0x00003ADF
	public void EarnCoins()
	{
		this._coins++;
		this._raceCoins++;
		if (this.OnEarnCoins != null)
		{
			this.OnEarnCoins(this._coins);
		}
	}

	// Token: 0x060004FA RID: 1274 RVA: 0x00005919 File Offset: 0x00003B19
	public void EarnCoins(int pQuantity)
	{
		this._coins += pQuantity;
		this._raceCoins += pQuantity;
	}

	// Token: 0x060004FB RID: 1275 RVA: 0x00029C58 File Offset: 0x00027E58
	public void UnlockPuzzlePiece(int pIndex)
	{
		string item = Singleton<GameConfigurator>.Instance.StartScene + "_" + pIndex.ToString();
		this._puzzlePieces.Add(item);
	}

	// Token: 0x060004FC RID: 1276 RVA: 0x00029C90 File Offset: 0x00027E90
	public void CanUnlockPuzzlePieces(bool pCanUnlock)
	{
		if (!pCanUnlock)
		{
			this._puzzlePieces.Clear();
		}
		if (this._puzzlePieces.Count > 0)
		{
			string startScene = Singleton<GameConfigurator>.Instance.StartScene;
			for (int i = 0; i < 3; i++)
			{
				string text = startScene + "_" + i.ToString();
				bool flag = this._puzzlePieces.Contains(text);
				if (!flag)
				{
					flag = Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(text);
				}
				if (!flag)
				{
					return;
				}
			}
			this._comicStrips.Add(startScene);
		}
	}

	// Token: 0x060004FD RID: 1277 RVA: 0x00005937 File Offset: 0x00003B37
	public void ShowHat(string pHat)
	{
		this._lockedHats.Add(pHat);
	}

	// Token: 0x060004FE RID: 1278 RVA: 0x00005945 File Offset: 0x00003B45
	public void UnlockHat(string pHat, ERarity pRarity)
	{
		this._unlockedHats.Add(new Tuple<string, ERarity>(pHat, pRarity));
	}

	// Token: 0x060004FF RID: 1279 RVA: 0x00005959 File Offset: 0x00003B59
	public void ShowCustom(string pCustom)
	{
		this._lockedCustoms.Add(pCustom);
	}

	// Token: 0x06000500 RID: 1280 RVA: 0x00005967 File Offset: 0x00003B67
	public void UnlockCustom(string pCustom, ERarity pRarity)
	{
		this._unlockedCustoms.Add(new Tuple<string, ERarity>(pCustom, pRarity));
	}

	// Token: 0x06000501 RID: 1281 RVA: 0x0000597B File Offset: 0x00003B7B
	public void UnlockCharacter(ECharacter pCharacter)
	{
		this._characters.Add(pCharacter.ToString());
	}

	// Token: 0x06000502 RID: 1282 RVA: 0x00005993 File Offset: 0x00003B93
	public void UnlockKart(ECharacter pKart)
	{
		this._karts.Add(pKart.ToString());
	}

	// Token: 0x06000503 RID: 1283 RVA: 0x000059AB File Offset: 0x00003BAB
	public void ShowChampionShip(string pChampionShip, EDifficulty pDifficulty)
	{
		this._lockedChampionShips.Add(new Tuple<string, EDifficulty>(pChampionShip, pDifficulty));
	}

	// Token: 0x06000504 RID: 1284 RVA: 0x000059BF File Offset: 0x00003BBF
	public void UnlockChampionShip(string pChampionShip, EDifficulty pDifficulty)
	{
		this._unlockedChampionShips.Add(new Tuple<string, EDifficulty>(pChampionShip, pDifficulty));
	}

	// Token: 0x06000505 RID: 1285 RVA: 0x000059D3 File Offset: 0x00003BD3
	public bool ContainsShownChampionShip(string pChampionShip, EDifficulty pDifficulty)
	{
		return this._lockedChampionShips.Contains(new Tuple<string, EDifficulty>(pChampionShip, pDifficulty));
	}

	// Token: 0x06000506 RID: 1286 RVA: 0x000059E7 File Offset: 0x00003BE7
	public void ShowAdvantage(EAdvantage pAdvantage)
	{
		this._advantages.Add(pAdvantage.ToString());
	}

	// Token: 0x06000507 RID: 1287 RVA: 0x000059FF File Offset: 0x00003BFF
	public void SetTimeTrialRank(int pRank)
	{
		this._timeTrial = new Tuple<int, string>(pRank, Singleton<GameConfigurator>.Instance.StartScene);
	}

	// Token: 0x06000508 RID: 1288 RVA: 0x00029D24 File Offset: 0x00027F24
	public EMenus GetState()
	{
		if (this._tradedReward != null)
		{
			if (this._tradedReward.Item3 == E_RewardType.Custom)
			{
				E_UnlockableItemSate customState = Singleton<GameSaveManager>.Instance.GetCustomState(this._tradedReward.Item1);
				if (customState == E_UnlockableItemSate.NewUnlocked || customState == E_UnlockableItemSate.Unlocked)
				{
					return EMenus.MENU_REWARDS_CUSTOMS_DUPLICATE;
				}
				return EMenus.MENU_REWARDS_CUSTOMS_UNLOCKED;
			}
			else
			{
				if (this._tradedReward.Item3 != E_RewardType.Hat)
				{
					return Singleton<GameConfigurator>.Instance.MenuToLaunch;
				}
				E_UnlockableItemSate hatState = Singleton<GameSaveManager>.Instance.GetHatState(this._tradedReward.Item1);
				if (hatState == E_UnlockableItemSate.NewUnlocked || hatState == E_UnlockableItemSate.Unlocked)
				{
					return EMenus.MENU_REWARDS_HATS_DUPLICATE;
				}
				return EMenus.MENU_REWARDS_HATS_UNLOCKED;
			}
		}
		else
		{
			if (this._timeTrial.Item1 >= 0)
			{
				return EMenus.MENU_REWARDS_TIME_TRIAL;
			}
			if (this.m_eFirstRewardToGive == E_RewardType.Custom && this._unlockedCustoms.Count > 0)
			{
				E_UnlockableItemSate customState2 = Singleton<GameSaveManager>.Instance.GetCustomState(this._unlockedCustoms[0].Item1);
				if (customState2 == E_UnlockableItemSate.NewUnlocked || customState2 == E_UnlockableItemSate.Unlocked)
				{
					return EMenus.MENU_REWARDS_CUSTOMS_DUPLICATE;
				}
				return EMenus.MENU_REWARDS_CUSTOMS_UNLOCKED;
			}
			else if (this.m_eFirstRewardToGive == E_RewardType.Hat && this._unlockedHats.Count > 0)
			{
				E_UnlockableItemSate hatState2 = Singleton<GameSaveManager>.Instance.GetHatState(this._unlockedHats[0].Item1);
				if (hatState2 == E_UnlockableItemSate.NewUnlocked || hatState2 == E_UnlockableItemSate.Unlocked)
				{
					return EMenus.MENU_REWARDS_HATS_DUPLICATE;
				}
				return EMenus.MENU_REWARDS_HATS_UNLOCKED;
			}
			else
			{
				if (this.m_eFirstRewardToGive == E_RewardType.Kart && this._karts.Count > 0)
				{
					return EMenus.MENU_REWARDS_KART;
				}
				if (this._characters.Count > 0)
				{
					return EMenus.MENU_REWARDS_CHARACTER;
				}
				if (this.m_eFirstRewardToGive != E_RewardType.Custom && this._unlockedCustoms.Count > 0)
				{
					E_UnlockableItemSate customState3 = Singleton<GameSaveManager>.Instance.GetCustomState(this._unlockedCustoms[0].Item1);
					if (customState3 == E_UnlockableItemSate.NewUnlocked || customState3 == E_UnlockableItemSate.Unlocked)
					{
						return EMenus.MENU_REWARDS_CUSTOMS_DUPLICATE;
					}
					return EMenus.MENU_REWARDS_CUSTOMS_UNLOCKED;
				}
				else if (this.m_eFirstRewardToGive != E_RewardType.Hat && this._unlockedHats.Count > 0)
				{
					E_UnlockableItemSate hatState3 = Singleton<GameSaveManager>.Instance.GetHatState(this._unlockedHats[0].Item1);
					if (hatState3 == E_UnlockableItemSate.NewUnlocked || hatState3 == E_UnlockableItemSate.Unlocked)
					{
						return EMenus.MENU_REWARDS_HATS_DUPLICATE;
					}
					return EMenus.MENU_REWARDS_HATS_UNLOCKED;
				}
				else
				{
					if (this._lockedCustoms.Count > 0)
					{
						return EMenus.MENU_REWARDS_CUSTOMS_SHOWN;
					}
					if (this._lockedHats.Count > 0)
					{
						return EMenus.MENU_REWARDS_HATS_SHOWN;
					}
					if (this._advantages.Count > 0)
					{
						return EMenus.MENU_REWARDS_ADVANTAGES;
					}
					if (this._comicStrips.Count > 0)
					{
						return EMenus.MENU_REWARDS_COMIC_STRIPS;
					}
					if (this._lockedChampionShips.Count > 0)
					{
						return EMenus.MENU_REWARDS_CHAMPION_SHIP_SHOWN;
					}
					if (this._unlockedChampionShips.Count > 0)
					{
						return EMenus.MENU_REWARDS_CHAMPION_SHIP_UNLOCKED;
					}
					if (this._wonEasyChampionShipStar || this._wonNormalChampionShipStar || this._wonHardChampionShipStar || this._wonTimeTrialStar || this._wonEndStar)
					{
						return EMenus.MENU_REWARDS_STAR;
					}
					Singleton<GameSaveManager>.Instance.Save();
					this.Reset();
					return Singleton<GameConfigurator>.Instance.MenuToLaunch;
				}
			}
		}
	}

	// Token: 0x06000509 RID: 1289 RVA: 0x0002A00C File Offset: 0x0002820C
	public E_Star PopStar()
	{
		if (this._wonEasyChampionShipStar)
		{
			this._wonEasyChampionShipStar = false;
			return E_Star.ChEasy;
		}
		if (this._wonHardChampionShipStar)
		{
			this._wonHardChampionShipStar = false;
			return E_Star.ChHard;
		}
		if (this._wonTimeTrialStar)
		{
			this._wonTimeTrialStar = false;
			return E_Star.TimeTrial;
		}
		if (this._wonNormalChampionShipStar)
		{
			this._wonNormalChampionShipStar = false;
			return E_Star.ChNormal;
		}
		if (this._wonEndStar)
		{
			this._wonEndStar = false;
			return E_Star.End;
		}
		return E_Star.None;
	}

	// Token: 0x0600050A RID: 1290 RVA: 0x00005A17 File Offset: 0x00003C17
	public string PopComicStrip()
	{
		return this.PopItem(ref this._comicStrips);
	}

	// Token: 0x0600050B RID: 1291 RVA: 0x0002A080 File Offset: 0x00028280
	public Tuple<string, ERarity> PopUnlockedCustom()
	{
		if (this._tradedReward == null)
		{
			return this.PopItem(ref this._unlockedCustoms);
		}
		Tuple<string, ERarity> result = new Tuple<string, ERarity>(this._tradedReward.Item1, this._tradedReward.Item2);
		this._tradedReward = null;
		return result;
	}

	// Token: 0x0600050C RID: 1292 RVA: 0x0002A0CC File Offset: 0x000282CC
	public Tuple<string, ERarity> PopUnlockedHat()
	{
		if (this._tradedReward == null)
		{
			return this.PopItem(ref this._unlockedHats);
		}
		Tuple<string, ERarity> result = new Tuple<string, ERarity>(this._tradedReward.Item1, this._tradedReward.Item2);
		this._tradedReward = null;
		return result;
	}

	// Token: 0x0600050D RID: 1293 RVA: 0x0002A118 File Offset: 0x00028318
	public ECharacter PopCharacter()
	{
		string value = this.PopItem(ref this._characters);
		return (ECharacter)((int)Enum.Parse(typeof(ECharacter), value));
	}

	// Token: 0x0600050E RID: 1294 RVA: 0x0002A148 File Offset: 0x00028348
	public ECharacter PopKart()
	{
		string value = this.PopItem(ref this._karts);
		return (ECharacter)((int)Enum.Parse(typeof(ECharacter), value));
	}

	// Token: 0x0600050F RID: 1295 RVA: 0x00005A25 File Offset: 0x00003C25
	public Tuple<string, EDifficulty> PopLockedChampionShip()
	{
		return this.PopItem(ref this._lockedChampionShips);
	}

	// Token: 0x06000510 RID: 1296 RVA: 0x00005A33 File Offset: 0x00003C33
	public Tuple<string, EDifficulty> PopUnlockedChampionShip()
	{
		return this.PopItem(ref this._unlockedChampionShips);
	}

	// Token: 0x06000511 RID: 1297 RVA: 0x0002A178 File Offset: 0x00028378
	public string[] PopLockedCustoms()
	{
		string[] array = new string[this._lockedCustoms.Count];
		this._lockedCustoms.CopyTo(array);
		this._lockedCustoms.Clear();
		return array;
	}

	// Token: 0x06000512 RID: 1298 RVA: 0x0002A1B0 File Offset: 0x000283B0
	public string[] PopLockedHats()
	{
		string[] array = new string[this._lockedHats.Count];
		this._lockedHats.CopyTo(array);
		this._lockedHats.Clear();
		return array;
	}

	// Token: 0x06000513 RID: 1299 RVA: 0x0002A1E8 File Offset: 0x000283E8
	public string[] PopAdvantage()
	{
		string[] array = new string[this._advantages.Count];
		this._advantages.CopyTo(array);
		this._advantages.Clear();
		return array;
	}

	// Token: 0x06000514 RID: 1300 RVA: 0x0002A220 File Offset: 0x00028420
	private string PopItem(ref List<string> rpItemList)
	{
		string result = rpItemList[0];
		rpItemList.RemoveAt(0);
		return result;
	}

	// Token: 0x06000515 RID: 1301 RVA: 0x0002A240 File Offset: 0x00028440
	private Tuple<string, ERarity> PopItem(ref List<Tuple<string, ERarity>> rpItemList)
	{
		Tuple<string, ERarity> result = rpItemList[0];
		rpItemList.RemoveAt(0);
		return result;
	}

	// Token: 0x06000516 RID: 1302 RVA: 0x0002A260 File Offset: 0x00028460
	private Tuple<string, EDifficulty> PopItem(ref List<Tuple<string, EDifficulty>> rpItemList)
	{
		Tuple<string, EDifficulty> result = rpItemList[0];
		rpItemList.RemoveAt(0);
		return result;
	}

	// Token: 0x06000517 RID: 1303 RVA: 0x0002A280 File Offset: 0x00028480
	public Tuple<int, string> PopTimeTrial()
	{
		Tuple<int, string> timeTrial = this._timeTrial;
		this._timeTrial = new Tuple<int, string>(-1, string.Empty);
		return timeTrial;
	}

	// Token: 0x06000518 RID: 1304 RVA: 0x0002A2A8 File Offset: 0x000284A8
	public void CheckCoins()
	{
		UnityEngine.Object[] array = Resources.LoadAll("Reward", typeof(RewardBase));
		foreach (UnityEngine.Object @object in array)
		{
			if (@object is RewardBase)
			{
				((RewardBase)@object).GiveReward();
			}
		}
		Singleton<GameSaveManager>.Instance.EarnCoins(this._coins, true, true);
		this._raceCoins = 0;
		this._coins = 0;
	}

	// Token: 0x06000519 RID: 1305 RVA: 0x00005A41 File Offset: 0x00003C41
	private void UnlockRandomItem(string pReward, E_RewardType pRewardType, ERarity pRarity)
	{
		if (pRewardType == E_RewardType.Custom)
		{
			this.UnlockCustom(pReward, pRarity);
		}
		else if (pRewardType == E_RewardType.Hat)
		{
			this.UnlockHat(pReward, pRarity);
		}
	}

	// Token: 0x0600051A RID: 1306 RVA: 0x0002A31C File Offset: 0x0002851C
	private void GetRandomItem(ERarity pRarity, ref string rpReward, ref E_RewardType rpRewardType)
	{
		List<string> availableHats = Singleton<GameSaveManager>.Instance.GetAvailableHats(pRarity, false);
		List<string> availableCustoms = Singleton<GameSaveManager>.Instance.GetAvailableCustoms(pRarity, false);
		int num = availableHats.Count + availableCustoms.Count;
		int num2 = Singleton<RandomManager>.Instance.Next(0, num - 1);
		if (num2 >= 0 && num2 < availableHats.Count)
		{
			rpReward = availableHats[num2];
			rpRewardType = E_RewardType.Hat;
		}
		else if (num2 >= availableHats.Count)
		{
			int index = num2 - availableHats.Count;
			rpReward = availableCustoms[index];
			rpRewardType = E_RewardType.Custom;
		}
	}

	// Token: 0x0600051B RID: 1307 RVA: 0x0002A3A8 File Offset: 0x000285A8
	private void GiveTimeTrialMedalCoins(int pLastMedal, int pNewMedal)
	{
		if (pLastMedal < pNewMedal)
		{
			for (int i = pLastMedal; i <= pNewMedal; i++)
			{
				if (i > 0)
				{
					this.EarnCoins(RewardManager._sMedalPrice[i - 1]);
				}
			}
		}
	}

	// Token: 0x0600051C RID: 1308 RVA: 0x0002A3E8 File Offset: 0x000285E8
	public void EndChallenge(bool pSuccess, string pReward, E_RewardType pRewardType, ERarity pRarity)
	{
		if (pSuccess)
		{
			switch (pRewardType)
			{
			case E_RewardType.Kart:
				this.UnlockKart((ECharacter)((int)Enum.Parse(typeof(ECharacter), pReward)));
				this.m_eFirstRewardToGive = E_RewardType.Kart;
				break;
			case E_RewardType.Custom:
				this.UnlockCustom(pReward, pRarity);
				this.m_eFirstRewardToGive = E_RewardType.Custom;
				break;
			case E_RewardType.Hat:
				this.UnlockHat(pReward, pRarity);
				this.m_eFirstRewardToGive = E_RewardType.Hat;
				break;
			}
			if (Singleton<ChallengeManager>.Instance.IsMonday)
			{
				this.EarnCoins(500);
			}
			else
			{
				this.EarnCoins(200);
			}
		}
		this.CheckCoins();
	}

	// Token: 0x0600051D RID: 1309 RVA: 0x00005A66 File Offset: 0x00003C66
	public void EndSingleRace(int pRank, bool pIsSingleRace)
	{
		if (pIsSingleRace && pRank == 0)
		{
			this.EarnCoins(5);
		}
		this.EarnCoins(Singleton<GameConfigurator>.Instance.GameSettings.ChampionShipScores[pRank]);
		this.CheckCoins();
	}

	// Token: 0x0600051E RID: 1310 RVA: 0x0002A498 File Offset: 0x00028698
	public void GiveChampionShipReward(int pFinalRank, int pNbFirstPlace)
	{
		if (pFinalRank == 0)
		{
			if (this._characters.Count == 0)
			{
				ERarity championShipItemRarity = this.GetChampionShipItemRarity(pNbFirstPlace);
				string empty = string.Empty;
				E_RewardType pRewardType = E_RewardType.Custom;
				this.GetRandomItem(championShipItemRarity, ref empty, ref pRewardType);
				this.UnlockRandomItem(empty, pRewardType, championShipItemRarity);
			}
			this.EarnCoins(20);
		}
		this.CheckCoins();
	}

	// Token: 0x0600051F RID: 1311 RVA: 0x0002A4F0 File Offset: 0x000286F0
	public void EndChampionShip(int pFinalRank, int pNbFirstPlace)
	{
		string name = Singleton<GameConfigurator>.Instance.ChampionShipData.name;
		EDifficulty difficulty = Singleton<GameConfigurator>.Instance.Difficulty;
		int rank = Singleton<GameSaveManager>.Instance.GetRank(name, difficulty);
		if (rank == -1 || pFinalRank < rank)
		{
			Singleton<GameSaveManager>.Instance.SetRank(name, pFinalRank, difficulty, true);
		}
	}

	// Token: 0x06000520 RID: 1312 RVA: 0x0002A544 File Offset: 0x00028744
	public void EndTimeTrial(string pTrack, E_TimeTrialMedal pMedal, float pDiffTime)
	{
		if (pMedal != E_TimeTrialMedal.None)
		{
			E_TimeTrialMedal medal = Singleton<GameSaveManager>.Instance.GetMedal(pTrack, false);
			if (pMedal != medal || (pMedal == E_TimeTrialMedal.Platinium && pDiffTime > 0f))
			{
				ERarity timeTrialItemRarity = this.GetTimeTrialItemRarity(pMedal);
				string empty = string.Empty;
				E_RewardType pRewardType = E_RewardType.Custom;
				this.GetRandomItem(timeTrialItemRarity, ref empty, ref pRewardType);
				this.UnlockRandomItem(empty, pRewardType, timeTrialItemRarity);
				if (pMedal != medal)
				{
					this.GiveTimeTrialMedalCoins((int)medal, (int)pMedal);
					this.SetTimeTrialRank((int)pMedal);
				}
			}
		}
		if (pDiffTime >= 0f && pDiffTime <= 1f)
		{
			int num = (int)Mathf.Lerp(5f, 50f, 1f - pDiffTime);
			if (num > 0)
			{
				this.EarnCoins(num);
			}
		}
		this.CheckCoins();
	}

	// Token: 0x06000521 RID: 1313 RVA: 0x0002A5FC File Offset: 0x000287FC
	public void GetChallengeReward(bool pIsMonday, ref string rpReward, ref E_RewardType rpRewardType, ref ERarity rpRarity)
	{
		rpRarity = ERarity.Unique;
		bool flag = !pIsMonday;
		if (!pIsMonday)
		{
			rpRarity = this.GetChallengeItemRarity();
		}
		else
		{
			List<ECharacter> availableKarts = Singleton<GameSaveManager>.Instance.GetAvailableKarts();
			if (availableKarts.Count > 0)
			{
				int index = Singleton<RandomManager>.Instance.Next(0, availableKarts.Count - 1);
				rpReward = availableKarts[index].ToString();
				rpRewardType = E_RewardType.Kart;
			}
			else
			{
				flag = true;
			}
		}
		if (flag)
		{
			this.GetRandomItem(rpRarity, ref rpReward, ref rpRewardType);
		}
	}

	// Token: 0x06000522 RID: 1314 RVA: 0x0002A680 File Offset: 0x00028880
	public void TradeReward(ERarity pRarity)
	{
		string empty = string.Empty;
		E_RewardType pItem = E_RewardType.Custom;
		this.GetRandomItem(pRarity, ref empty, ref pItem);
		this._tradedReward = new Tuple<string, ERarity, E_RewardType>(empty, pRarity, pItem);
	}

	// Token: 0x06000523 RID: 1315 RVA: 0x0002A6B0 File Offset: 0x000288B0
	public ERarity GetChallengeItemRarity()
	{
		int num = Singleton<RandomManager>.Instance.Next(0, 99);
		if (num < 65)
		{
			return ERarity.Base;
		}
		return ERarity.Rare;
	}

	// Token: 0x06000524 RID: 1316 RVA: 0x0002A6D8 File Offset: 0x000288D8
	public ERarity GetTimeTrialItemRarity(E_TimeTrialMedal pMedal)
	{
		switch (pMedal)
		{
		case E_TimeTrialMedal.Bronze:
		case E_TimeTrialMedal.Silver:
			return ERarity.Base;
		case E_TimeTrialMedal.Gold:
			return ERarity.Rare;
		case E_TimeTrialMedal.Platinium:
			return ERarity.Unique;
		default:
			return ERarity.Base;
		}
	}

	// Token: 0x06000525 RID: 1317 RVA: 0x0002A70C File Offset: 0x0002890C
	public ERarity GetChampionShipItemRarity(int pNbFirstPlace)
	{
		switch (Singleton<GameConfigurator>.Instance.Difficulty)
		{
		case EDifficulty.NORMAL:
			if (pNbFirstPlace < 3)
			{
				return ERarity.Base;
			}
			if (pNbFirstPlace < 4)
			{
				return ERarity.Rare;
			}
			return ERarity.Unique;
		case EDifficulty.HARD:
			if (pNbFirstPlace < 4)
			{
				return ERarity.Rare;
			}
			return ERarity.Unique;
		case EDifficulty.EASY:
			if (pNbFirstPlace < 3)
			{
				return ERarity.Base;
			}
			return ERarity.Rare;
		default:
			return ERarity.Base;
		}
	}

	// Token: 0x06000526 RID: 1318 RVA: 0x00005A98 File Offset: 0x00003C98
	public void WinEasyChampionShipStar()
	{
		this._wonEasyChampionShipStar = true;
	}

	// Token: 0x06000527 RID: 1319 RVA: 0x00005AA1 File Offset: 0x00003CA1
	public void WinNormalChampionShipStar()
	{
		this._wonNormalChampionShipStar = true;
	}

	// Token: 0x06000528 RID: 1320 RVA: 0x00005AAA File Offset: 0x00003CAA
	public void WinHardChampionShipStar()
	{
		this._wonHardChampionShipStar = true;
	}

	// Token: 0x06000529 RID: 1321 RVA: 0x00005AB3 File Offset: 0x00003CB3
	public void WinTimeTrialStar()
	{
		this._wonTimeTrialStar = true;
	}

	// Token: 0x0600052A RID: 1322 RVA: 0x00005ABC File Offset: 0x00003CBC
	public void WinEndStar()
	{
		this._wonEndStar = true;
	}

	// Token: 0x0600052B RID: 1323 RVA: 0x0002A768 File Offset: 0x00028968
	public void GiveSharingReward()
	{
		ERarity pRarity = ERarity.Base;
		string empty = string.Empty;
		E_RewardType pRewardType = E_RewardType.Custom;
		this.GetRandomItem(pRarity, ref empty, ref pRewardType);
		this.UnlockRandomItem(empty, pRewardType, pRarity);
	}

	// Token: 0x040004E0 RID: 1248
	private static readonly List<int> _sMedalPrice = new List<int>
	{
		100,
		100,
		200,
		300
	};

	// Token: 0x040004E1 RID: 1249
	private int _coins;

	// Token: 0x040004E2 RID: 1250
	private int _raceCoins;

	// Token: 0x040004E3 RID: 1251
	private List<string> _puzzlePieces;

	// Token: 0x040004E4 RID: 1252
	public List<string> _comicStrips;

	// Token: 0x040004E5 RID: 1253
	private List<string> _lockedCustoms;

	// Token: 0x040004E6 RID: 1254
	private List<Tuple<string, ERarity>> _unlockedCustoms;

	// Token: 0x040004E7 RID: 1255
	private List<string> _lockedHats;

	// Token: 0x040004E8 RID: 1256
	private List<Tuple<string, ERarity>> _unlockedHats;

	// Token: 0x040004E9 RID: 1257
	private List<string> _characters;

	// Token: 0x040004EA RID: 1258
	private List<string> _karts;

	// Token: 0x040004EB RID: 1259
	private List<Tuple<string, EDifficulty>> _lockedChampionShips;

	// Token: 0x040004EC RID: 1260
	private List<Tuple<string, EDifficulty>> _unlockedChampionShips;

	// Token: 0x040004ED RID: 1261
	private List<string> _advantages;

	// Token: 0x040004EE RID: 1262
	private Tuple<int, string> _timeTrial;

	// Token: 0x040004EF RID: 1263
	private int _playerRank = -1;

	// Token: 0x040004F0 RID: 1264
	private E_TimeTrialMedal _medal;

	// Token: 0x040004F1 RID: 1265
	private Tuple<string, ERarity, E_RewardType> _tradedReward;

	// Token: 0x040004F2 RID: 1266
	private bool _wonTimeTrialStar;

	// Token: 0x040004F3 RID: 1267
	private bool _wonEasyChampionShipStar;

	// Token: 0x040004F4 RID: 1268
	private bool _wonNormalChampionShipStar;

	// Token: 0x040004F5 RID: 1269
	private bool _wonHardChampionShipStar;

	// Token: 0x040004F6 RID: 1270
	private bool _wonEndStar;

	// Token: 0x040004F7 RID: 1271
	private E_RewardType m_eFirstRewardToGive;

	// Token: 0x040004F8 RID: 1272
	public Action<int> OnEarnCoins;
}

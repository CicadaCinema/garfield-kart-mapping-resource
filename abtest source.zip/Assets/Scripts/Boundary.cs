﻿using System;
using UnityEngine;

// Token: 0x0200023A RID: 570
public class Boundary
{
	// Token: 0x04000F5F RID: 3935
	public Vector2 min = Vector2.zero;

	// Token: 0x04000F60 RID: 3936
	public Vector2 max = Vector2.zero;
}

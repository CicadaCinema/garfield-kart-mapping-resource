﻿using System;

// Token: 0x02000175 RID: 373
public enum EChampionshipPassState
{
	// Token: 0x04000A0F RID: 2575
	None,
	// Token: 0x04000A10 RID: 2576
	Selected,
	// Token: 0x04000A11 RID: 2577
	Validated
}

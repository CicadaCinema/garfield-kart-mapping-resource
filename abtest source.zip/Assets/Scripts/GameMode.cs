﻿using System;
using UnityEngine;

// Token: 0x02000169 RID: 361
public abstract class GameMode : MonoBehaviour
{
	// Token: 0x060009AC RID: 2476 RVA: 0x000020F3 File Offset: 0x000002F3
	public GameMode()
	{
	}

	// Token: 0x1700015C RID: 348
	// (get) Token: 0x060009AD RID: 2477 RVA: 0x00008A76 File Offset: 0x00006C76
	// (set) Token: 0x060009AE RID: 2478 RVA: 0x00043EA4 File Offset: 0x000420A4
	public E_GameState State
	{
		get
		{
			return this._state;
		}
		set
		{
			this._state = value;
			if (this._currentGameState != null)
			{
				this._currentGameState.Exit();
				this._currentGameState.enabled = false;
			}
			this._currentGameState = this._gameStates[(int)this._state];
			this._currentGameState.enabled = true;
			this._currentGameState.Enter();
		}
	}

	// Token: 0x1700015D RID: 349
	// (get) Token: 0x060009AF RID: 2479 RVA: 0x00008A7E File Offset: 0x00006C7E
	public AudioSource MainMusic
	{
		get
		{
			return this.m_pMainMusic;
		}
	}

	// Token: 0x1700015E RID: 350
	// (get) Token: 0x060009B0 RID: 2480 RVA: 0x00008A86 File Offset: 0x00006C86
	public bool ReadyToStart
	{
		get
		{
			return this.m_bReadyToStart;
		}
	}

	// Token: 0x1700015F RID: 351
	// (get) Token: 0x060009B1 RID: 2481 RVA: 0x00008A8E File Offset: 0x00006C8E
	public int PlayerCount
	{
		get
		{
			return this.m_pPlayers.Length;
		}
	}

	// Token: 0x17000160 RID: 352
	// (get) Token: 0x060009B2 RID: 2482 RVA: 0x00008A98 File Offset: 0x00006C98
	public HUDInGame Hud
	{
		get
		{
			return this._hud;
		}
	}

	// Token: 0x060009B3 RID: 2483 RVA: 0x00008AA0 File Offset: 0x00006CA0
	protected virtual void StateChange(E_GameState pNewState)
	{
		this.State = pNewState;
	}

	// Token: 0x060009B4 RID: 2484 RVA: 0x00043F0C File Offset: 0x0004210C
	public virtual void Dispose()
	{
		for (int i = 0; i < this.m_pPlayers.Length; i++)
		{
			if (this.m_pPlayers[i].Item1 != null)
			{
				UnityEngine.Object.Destroy(this.m_pPlayers[i].Item1);
			}
		}
		if (this._hud != null)
		{
			UnityEngine.Object.Destroy(this._hud.gameObject);
		}
		for (int j = 0; j < this._gameStates.Length; j++)
		{
			if (this._gameStates[j] != null)
			{
				UnityEngine.Object.Destroy(this._gameStates[j]);
			}
		}
	}

	// Token: 0x060009B5 RID: 2485 RVA: 0x00043FB8 File Offset: 0x000421B8
	public virtual void Awake()
	{
		this.m_bReadyToStart = false;
		this._gameStates = new GameState[Enum.GetValues(typeof(E_GameState)).Length];
		this.m_pPlayers = new Tuple<GameObject, Kart>[6];
		for (int i = 0; i < 6; i++)
		{
			this.m_pPlayers[i] = new Tuple<GameObject, Kart>(null, null);
		}
		GameObject gameObject = GameObject.Find(Singleton<GameConfigurator>.Instance.StartScene + "LD");
		if (gameObject)
		{
			this.m_pMainMusic = gameObject.GetComponent<AudioSource>();
			if (this.m_pMainMusic)
			{
				this.m_pMainMusic.ignoreListenerPause = true;
			}
		}
		this.InitState();
		Singleton<RewardManager>.Instance.RaceCoins = 0;
	}

	// Token: 0x060009B6 RID: 2486
	public abstract void StartScene();

	// Token: 0x060009B7 RID: 2487
	public abstract void CreatePlayers();

	// Token: 0x060009B8 RID: 2488 RVA: 0x00008AA9 File Offset: 0x00006CA9
	public virtual void InitState()
	{
		this._state = E_GameState.TrackPresentation;
      
	}

	// Token: 0x060009B9 RID: 2489 RVA: 0x00044078 File Offset: 0x00042278
	public void CreatePlayer(ECharacter _Character, ECharacter _Kart, string customName, string hatName, int iNbStars, int pIndex, bool pLock, bool pIsAI)
	{
		UnityEngine.Object @object = Resources.Load("Player");
		GameObject gameObject;
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			gameObject = (GameObject)UnityEngine.Object.Instantiate(@object, Vector3.zero, Quaternion.identity);
		}
		else
		{
			gameObject = (GameObject)Network.Instantiate(@object, Vector3.zero, Quaternion.identity, 0);
		}
		PlayerBuilder componentInChildren = gameObject.GetComponentInChildren<PlayerBuilder>();
		Vector3 vector = new Vector3(Singleton<GameConfigurator>.Instance.PlayerConfig.PlayerColor.r, Singleton<GameConfigurator>.Instance.PlayerConfig.PlayerColor.g, Singleton<GameConfigurator>.Instance.PlayerConfig.PlayerColor.b);
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			componentInChildren.Build((int)_Character, (int)_Kart, customName, hatName, iNbStars, pIndex, pLock, pIsAI, string.Empty, vector);
		}
		else
		{
			componentInChildren.networkView.RPC("Build", RPCMode.All, new object[]
			{
				(int)_Character,
				(int)_Kart,
				customName,
				hatName,
				iNbStars,
				pIndex,
				pLock,
				pIsAI,
				Singleton<GameSaveManager>.Instance.GetPseudo(),
				vector
			});
		}
		gameObject.GetComponentInChildren<Kart>().Disable();
		KartSound componentInChildren2 = gameObject.GetComponentInChildren<KartSound>();
		if (componentInChildren2)
		{
			componentInChildren2.Character = _Character;
		}
	}

	// Token: 0x060009BA RID: 2490 RVA: 0x00008AB2 File Offset: 0x00006CB2
	public GameObject GetPlayer(int _Index)
	{
		if (_Index < 0 || _Index >= this.m_pPlayers.Length)
		{
			return null;
		}
		return this.m_pPlayers[_Index].Item1;
	}

	// Token: 0x060009BB RID: 2491 RVA: 0x00008AD8 File Offset: 0x00006CD8
	public Kart GetKart(int _Index)
	{
		if (_Index < 0 || _Index >= this.m_pPlayers.Length)
		{
			return null;
		}
		return this.m_pPlayers[_Index].Item2;
	}

	// Token: 0x060009BC RID: 2492 RVA: 0x000441E8 File Offset: 0x000423E8
	public GameObject GetPlayerWithVehicleId(int _Index)
	{
		if (_Index < 0 || _Index >= this.m_pPlayers.Length)
		{
			return null;
		}
		for (int i = 0; i < this.m_pPlayers.Length; i++)
		{
			if (this.m_pPlayers[i].Item2 != null && this.m_pPlayers[i].Item2.GetVehicleId() == _Index)
			{
				return this.m_pPlayers[i].Item1;
			}
		}
		return null;
	}

	// Token: 0x060009BD RID: 2493 RVA: 0x00044264 File Offset: 0x00042464
	public Kart GetKartWithVehicleId(int _Index)
	{
		if (_Index < 0 || _Index >= this.m_pPlayers.Length)
		{
			return null;
		}
		for (int i = 0; i < this.m_pPlayers.Length; i++)
		{
			if (this.m_pPlayers[i].Item2 != null && this.m_pPlayers[i].Item2.GetVehicleId() == _Index)
			{
				return this.m_pPlayers[i].Item2;
			}
		}
		return null;
	}

	// Token: 0x060009BE RID: 2494 RVA: 0x000442E0 File Offset: 0x000424E0
	public GameObject GetHumanPlayer(ref int _iHumanIndex)
	{
		for (int i = 0; i < this.m_pPlayers.Length; i++)
		{
			if (this.m_pPlayers[i] != null && this.m_pPlayers[i].Item2 != null && this.m_pPlayers[i].Item2.GetControlType() == RcVehicle.ControlType.Human)
			{
				_iHumanIndex = i;
				return this.m_pPlayers[i].Item1;
			}
		}
		return null;
	}

	// Token: 0x060009BF RID: 2495 RVA: 0x00044354 File Offset: 0x00042554
	public Kart GetHumanKart(ref int _iHumanIndex)
	{
		for (int i = 0; i < this.m_pPlayers.Length; i++)
		{
			if (this.m_pPlayers[i] != null && this.m_pPlayers[i].Item2 != null && this.m_pPlayers[i].Item2.GetControlType() == RcVehicle.ControlType.Human)
			{
				_iHumanIndex = i;
				return this.m_pPlayers[i].Item2;
			}
		}
		return null;
	}

	// Token: 0x060009C0 RID: 2496 RVA: 0x000443C8 File Offset: 0x000425C8
	public GameObject GetPlayer(ECharacter _Character, bool bOnlyAI)
	{
		for (int i = 0; i < this.m_pPlayers.Length; i++)
		{
			if (this.m_pPlayers[i] != null && this.m_pPlayers[i].Item2 != null && this.m_pPlayers[i].Item1 != null)
			{
				bool flag = this.m_pPlayers[i].Item2.GetControlType() != RcVehicle.ControlType.Human;
				CharacterCarac componentInChildren = this.m_pPlayers[i].Item1.GetComponentInChildren<CharacterCarac>();
				if (((bOnlyAI && flag) || !bOnlyAI) && componentInChildren && componentInChildren.Owner == _Character)
				{
					return this.m_pPlayers[i].Item1;
				}
			}
		}
		return null;
	}

	// Token: 0x060009C1 RID: 2497 RVA: 0x00044494 File Offset: 0x00042694
	public GameObject GetPlayer(NetworkPlayer nplayer)
	{
		for (int i = 0; i < this.m_pPlayers.Length; i++)
		{
			if (this.m_pPlayers[i] != null && this.m_pPlayers[i].Item1 != null && this.m_pPlayers[i].Item1.networkView.owner == nplayer)
			{
				return this.m_pPlayers[i].Item1;
			}
		}
		return null;
	}

	// Token: 0x060009C2 RID: 2498 RVA: 0x00044510 File Offset: 0x00042710
	public GameObject GetPlayer(NetworkViewID viewID)
	{
		for (int i = 0; i < this.m_pPlayers.Length; i++)
		{
			if (this.m_pPlayers[i] != null && this.m_pPlayers[i].Item1 != null && this.m_pPlayers[i].Item1.networkView.viewID == viewID)
			{
				return this.m_pPlayers[i].Item1;
			}
		}
		return null;
	}

	// Token: 0x060009C3 RID: 2499 RVA: 0x0004458C File Offset: 0x0004278C
	public Kart GetKart(ECharacter _Character, bool bOnlyAI)
	{
		for (int i = 0; i < this.m_pPlayers.Length; i++)
		{
			if (this.m_pPlayers[i] != null && this.m_pPlayers[i].Item2 != null && this.m_pPlayers[i].Item1 != null)
			{
				bool flag = this.m_pPlayers[i].Item2.GetControlType() != RcVehicle.ControlType.Human;
				CharacterCarac componentInChildren = this.m_pPlayers[i].Item1.GetComponentInChildren<CharacterCarac>();
				if (((bOnlyAI && flag) || !bOnlyAI) && componentInChildren && componentInChildren.Owner == _Character)
				{
					return this.m_pPlayers[i].Item2;
				}
			}
		}
		return null;
	}

	// Token: 0x060009C4 RID: 2500 RVA: 0x00044658 File Offset: 0x00042858
	public GameObject GetHumanPlayer()
	{
		int num = 0;
		return this.GetHumanPlayer(ref num);
	}

	// Token: 0x060009C5 RID: 2501 RVA: 0x00044670 File Offset: 0x00042870
	public Kart GetHumanKart()
	{
		int num = 0;
		return this.GetHumanKart(ref num);
	}

	// Token: 0x060009C6 RID: 2502 RVA: 0x00044688 File Offset: 0x00042888
	public int GetHumanPlayerVehicleId()
	{
		int num = 0;
		Kart humanKart = this.GetHumanKart(ref num);
		if (humanKart)
		{
			return humanKart.GetVehicleId();
		}
		return -1;
	}

	// Token: 0x060009C7 RID: 2503 RVA: 0x000446B4 File Offset: 0x000428B4
	public void AddPlayer(GameObject _Player, Kart _Kart)
	{
		for (int i = 0; i < 6; i++)
		{
			if (this.m_pPlayers[i] != null && this.m_pPlayers[i].Item1 == null)
			{
				this.m_pPlayers[i].Item1 = _Player;
				this.m_pPlayers[i].Item2 = _Kart;
				break;
			}
		}
	}

	// Token: 0x060009C8 RID: 2504 RVA: 0x0004471C File Offset: 0x0004291C
	public void ComputePlayerAdvantages()
	{
		for (int i = 0; i < this.m_pPlayers.Length; i++)
		{
			if (this.m_pPlayers[i].Item1 != null && this.m_pPlayers[i].Item2 != null)
			{
				KartArcadeGearBox kartArcadeGearBox = (KartArcadeGearBox)this.m_pPlayers[i].Item2.GetGearBox();
				if (kartArcadeGearBox)
				{
					kartArcadeGearBox.StartScene();
				}
				PlayerCarac componentInChildren = this.m_pPlayers[i].Item1.GetComponentInChildren<PlayerCarac>();
				if (componentInChildren)
				{
					componentInChildren.StartScene();
				}
			}
		}
	}

	// Token: 0x060009C9 RID: 2505 RVA: 0x000447C0 File Offset: 0x000429C0
	public void FailedChallenge()
	{
		if (this._state == E_GameState.Race)
		{
			this._hud.ShowFailedChallenge();
			RcHumanController componentInChildren = this.GetHumanPlayer().GetComponentInChildren<RcHumanController>();
			if (componentInChildren)
			{
				componentInChildren.SetAutopilotEnabled(true);
			}
		}
	}

	// Token: 0x060009CA RID: 2506 RVA: 0x00044804 File Offset: 0x00042A04
	public void SetAdvantage(int iIndex, EAdvantage eAdvantage)
	{
		if (iIndex < 0 || iIndex >= this.m_pPlayers.Length)
		{
			return;
		}
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoSelectAdvantage(iIndex, (int)eAdvantage);
		}
		else
		{
			base.networkView.RPC("DoSelectAdvantage", RPCMode.All, new object[]
			{
				iIndex,
				(int)eAdvantage
			});
		}
	}

	// Token: 0x060009CB RID: 2507 RVA: 0x00044868 File Offset: 0x00042A68
	[RPC]
	public void DoSelectAdvantage(int iIndex, int eAdvantage)
	{
		GameObject playerWithVehicleId = this.GetPlayerWithVehicleId(iIndex);
		if (playerWithVehicleId)
		{
			Kart componentInChildren = playerWithVehicleId.GetComponentInChildren<Kart>();
			if (componentInChildren)
			{
				componentInChildren.SelectedAdvantage = (EAdvantage)eAdvantage;
			}
		}
	}

	// Token: 0x040009E8 RID: 2536
	protected Tuple<GameObject, Kart>[] m_pPlayers;

	// Token: 0x040009E9 RID: 2537
	protected HUDInGame _hud;

	// Token: 0x040009EA RID: 2538
	protected GameState[] _gameStates;

	// Token: 0x040009EB RID: 2539
	protected GameState _currentGameState;

	// Token: 0x040009EC RID: 2540
	protected E_GameState _state;

	// Token: 0x040009ED RID: 2541
	protected bool m_bReadyToStart;

	// Token: 0x040009EE RID: 2542
	private AudioSource m_pMainMusic;
}

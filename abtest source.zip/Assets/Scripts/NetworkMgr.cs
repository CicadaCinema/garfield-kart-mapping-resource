﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020001C4 RID: 452
public class NetworkMgr : MonoBehaviour
{
	// Token: 0x06000C11 RID: 3089 RVA: 0x0005208C File Offset: 0x0005028C
	public NetworkMgr()
	{
		this.m_SynchronizeIndex = 0;
		this.m_SynchronizeCounter = 0;
		this.m_WaitingSynchronization = false;
		this.peerNames = new Dictionary<NetworkPlayer, string>();
		this.readyToGo = new Dictionary<NetworkPlayer, bool>();
		this.m_SelectorColors = new Dictionary<Color, bool>();
		this.playersColor = new Dictionary<NetworkPlayer, Color>();
	}

	// Token: 0x17000181 RID: 385
	// (get) Token: 0x06000C12 RID: 3090 RVA: 0x0000A628 File Offset: 0x00008828
	public ConnectionTesterStatus ConnectionStatus
	{
		get
		{
			return this.m_eConnectionTestResult;
		}
	}

	// Token: 0x17000182 RID: 386
	// (get) Token: 0x06000C13 RID: 3091 RVA: 0x0000A630 File Offset: 0x00008830
	public bool TrackChoiceReceived
	{
		get
		{
			return this.m_bTrackChoiceReceived;
		}
	}

	// Token: 0x06000C14 RID: 3092 RVA: 0x00052140 File Offset: 0x00050340
	public bool CanConnectTo(ConnectionTesterStatus serverNATType)
	{
		return (this.m_eConnectionTestResult != ConnectionTesterStatus.LimitedNATPunchthroughPortRestricted || serverNATType != ConnectionTesterStatus.LimitedNATPunchthroughSymmetric) && (this.m_eConnectionTestResult != ConnectionTesterStatus.LimitedNATPunchthroughSymmetric || serverNATType != ConnectionTesterStatus.LimitedNATPunchthroughPortRestricted) && (this.m_eConnectionTestResult != ConnectionTesterStatus.LimitedNATPunchthroughSymmetric || serverNATType != ConnectionTesterStatus.LimitedNATPunchthroughSymmetric);
	}

	// Token: 0x17000183 RID: 387
	// (get) Token: 0x06000C15 RID: 3093 RVA: 0x0000A638 File Offset: 0x00008838
	public bool UsingNAT
	{
		get
		{
			return this.m_bUseNat;
		}
	}

	// Token: 0x17000184 RID: 388
	// (get) Token: 0x06000C16 RID: 3094 RVA: 0x0000A640 File Offset: 0x00008840
	public bool DoneTesting
	{
		get
		{
			return this.m_bDoneTesting;
		}
	}

	// Token: 0x17000185 RID: 389
	// (get) Token: 0x06000C17 RID: 3095 RVA: 0x0000A648 File Offset: 0x00008848
	public bool CanConnect
	{
		get
		{
			return this.m_bCanConnect;
		}
	}

	// Token: 0x17000186 RID: 390
	// (get) Token: 0x06000C18 RID: 3096 RVA: 0x0000A650 File Offset: 0x00008850
	public string ExternalIP
	{
		get
		{
			return this.m_sExternalIP;
		}
	}

	// Token: 0x17000187 RID: 391
	// (get) Token: 0x06000C19 RID: 3097 RVA: 0x0000A658 File Offset: 0x00008858
	public int SynchronizationCounter
	{
		get
		{
			return this.m_SynchronizeIndex;
		}
	}

	// Token: 0x17000188 RID: 392
	// (get) Token: 0x06000C1A RID: 3098 RVA: 0x0000A660 File Offset: 0x00008860
	public Dictionary<NetworkPlayer, string> PeerNames
	{
		get
		{
			return this.peerNames;
		}
	}

	// Token: 0x17000189 RID: 393
	// (get) Token: 0x06000C1B RID: 3099 RVA: 0x0000A668 File Offset: 0x00008868
	public Dictionary<NetworkPlayer, bool> ReadyToGo
	{
		get
		{
			return this.readyToGo;
		}
	}

	// Token: 0x1700018A RID: 394
	// (get) Token: 0x06000C1C RID: 3100 RVA: 0x0000A670 File Offset: 0x00008870
	// (set) Token: 0x06000C1D RID: 3101 RVA: 0x0000A678 File Offset: 0x00008878
	public Dictionary<Color, bool> SelectorColors
	{
		get
		{
			return this.m_SelectorColors;
		}
		set
		{
			this.m_SelectorColors = value;
		}
	}

	// Token: 0x1700018B RID: 395
	// (get) Token: 0x06000C1E RID: 3102 RVA: 0x0000A681 File Offset: 0x00008881
	// (set) Token: 0x06000C1F RID: 3103 RVA: 0x0000A689 File Offset: 0x00008889
	public Dictionary<NetworkPlayer, Color> PlayersColor
	{
		get
		{
			return this.playersColor;
		}
		set
		{
			this.playersColor = value;
		}
	}

	// Token: 0x06000C20 RID: 3104 RVA: 0x00052190 File Offset: 0x00050390
	public IEnumerator CheckIP()
	{
		WWW myExtIPWWW = new WWW("http://api.externalip.net/ip/");
		if (myExtIPWWW == null)
		{
			yield break;
		}
		yield return myExtIPWWW;
		if (string.IsNullOrEmpty(myExtIPWWW.error))
		{
			this.m_sExternalIP = myExtIPWWW.text;
		}
		yield break;
	}

	// Token: 0x06000C21 RID: 3105 RVA: 0x0000A692 File Offset: 0x00008892
	public void StartTestConnection()
	{
		this.m_bDoneTesting = false;
		this.m_bTestAsked = true;
		this.m_fTimer = 0f;
	}

	// Token: 0x06000C22 RID: 3106 RVA: 0x0000A6AD File Offset: 0x000088AD
	public void StopTestConnection()
	{
		this.m_bDoneTesting = true;
		this.m_bTestAsked = false;
	}

	// Token: 0x06000C23 RID: 3107 RVA: 0x000521AC File Offset: 0x000503AC
	private void TestConnection()
	{
		if (this.m_bTestAsked && !this.m_bDoneTesting)
		{
			this.m_eConnectionTestResult = Network.TestConnection();
			ConnectionTesterStatus eConnectionTestResult = this.m_eConnectionTestResult;
			switch (eConnectionTestResult + 2)
			{
			case ConnectionTesterStatus.PrivateIPNoNATPunchthrough:
				this.m_bDoneTesting = true;
				goto IL_152;
			case ConnectionTesterStatus.PrivateIPHasNATPunchThrough:
				this.m_bDoneTesting = false;
				goto IL_152;
			case ConnectionTesterStatus.PublicIPNoServerStarted:
				this.m_bUseNat = false;
				this.m_bDoneTesting = true;
				this.m_bCanConnect = true;
				goto IL_152;
			case ConnectionTesterStatus.LimitedNATPunchthroughPortRestricted:
				this.m_bUseNat = false;
				if (!this.m_bProbingPublicIP)
				{
					this.m_eConnectionTestResult = Network.TestConnectionNAT();
					this.m_bProbingPublicIP = true;
					Debug.LogWarning("Testing if blocked public IP can be circumvented");
					this.m_fTimerNAT = Time.time + 10f;
				}
				else if (Time.time > this.m_fTimerNAT)
				{
					this.m_bProbingPublicIP = false;
					this.m_bUseNat = true;
					this.m_bDoneTesting = true;
				}
				goto IL_152;
			case ConnectionTesterStatus.LimitedNATPunchthroughSymmetric:
				goto IL_152;
			case ConnectionTesterStatus.NATpunchthroughFullCone:
				this.m_bUseNat = true;
				this.m_bDoneTesting = true;
				goto IL_152;
			case ConnectionTesterStatus.NATpunchthroughAddressRestrictedCone:
				this.m_bUseNat = true;
				this.m_bDoneTesting = true;
				goto IL_152;
			case (ConnectionTesterStatus)9:
			case (ConnectionTesterStatus)10:
				this.m_bUseNat = true;
				this.m_bDoneTesting = true;
				this.m_bCanConnect = true;
				goto IL_152;
			}
			this.m_bDoneTesting = true;
			IL_152:
			this.m_fTimer += Time.deltaTime;
			if (this.m_fTimer > this.m_fTestingTimeout)
			{
				this.m_bDoneTesting = true;
			}
		}
	}

	// Token: 0x1700018C RID: 396
	// (get) Token: 0x06000C24 RID: 3108 RVA: 0x0000A6BD File Offset: 0x000088BD
	// (set) Token: 0x06000C25 RID: 3109 RVA: 0x0000A6C5 File Offset: 0x000088C5
	public bool BLanOnly
	{
		get
		{
			return this.m_bLanOnly;
		}
		set
		{
			this.m_bLanOnly = value;
		}
	}

	// Token: 0x1700018D RID: 397
	// (get) Token: 0x06000C26 RID: 3110 RVA: 0x0000A6CE File Offset: 0x000088CE
	// (set) Token: 0x06000C27 RID: 3111 RVA: 0x0000A6D6 File Offset: 0x000088D6
	public string SPlayerName
	{
		get
		{
			return this.m_sPlayerName;
		}
		set
		{
			this.m_sPlayerName = value;
		}
	}

	// Token: 0x1700018E RID: 398
	// (get) Token: 0x06000C28 RID: 3112 RVA: 0x0000A6DF File Offset: 0x000088DF
	// (set) Token: 0x06000C29 RID: 3113 RVA: 0x0000A70C File Offset: 0x0000890C
	public string SGameName
	{
		get
		{
			if (this.m_sGameName == string.Empty)
			{
				return Localization.instance.Get("MENU_GAME_NAME");
			}
			return this.m_sGameName;
		}
		set
		{
			this.m_sGameName = value;
		}
	}

	// Token: 0x1700018F RID: 399
	// (get) Token: 0x06000C2A RID: 3114 RVA: 0x0000A715 File Offset: 0x00008915
	public NetworkViewID GameModeId
	{
		get
		{
			return this.gameModeId;
		}
	}

	// Token: 0x17000190 RID: 400
	// (get) Token: 0x06000C2B RID: 3115 RVA: 0x0000A71D File Offset: 0x0000891D
	public bool WaitingSynchronization
	{
		get
		{
			return this.m_WaitingSynchronization;
		}
	}

	// Token: 0x17000191 RID: 401
	// (get) Token: 0x06000C2C RID: 3116 RVA: 0x0000A725 File Offset: 0x00008925
	public int InitialNbPlayers
	{
		get
		{
			return this.initialNbPlayers;
		}
	}

	// Token: 0x17000192 RID: 402
	// (get) Token: 0x06000C2D RID: 3117 RVA: 0x0000A72D File Offset: 0x0000892D
	public int NbPeers
	{
		get
		{
			if (Network.peerType == NetworkPeerType.Disconnected)
			{
				return 1;
			}
			return this.peerNames.Count;
		}
	}

	// Token: 0x06000C2E RID: 3118 RVA: 0x0000A746 File Offset: 0x00008946
	public void OnDestroy()
	{
		Network.Disconnect();
	}

	// Token: 0x06000C2F RID: 3119 RVA: 0x00052338 File Offset: 0x00050538
	public void Awake()
	{
		Application.runInBackground = true;
		this.m_SynchronizeIndex = 0;
		this.m_SynchronizeCounter = 0;
		this.m_WaitingSynchronization = false;
		MasterServer.ipAddress = "94.23.51.63";
		MasterServer.port = 23466;
		Network.natFacilitatorIP = MasterServer.ipAddress;
		Network.natFacilitatorPort = 50005;
		UnityEngine.Object.DontDestroyOnLoad(this);
		this.selectorColorsInit();
	}

	// Token: 0x06000C30 RID: 3120 RVA: 0x00052394 File Offset: 0x00050594
	public void selectorColorsInit()
	{
		this.m_SelectorColors.Clear();
		foreach (Color key in this.SelectedColors)
		{
			this.m_SelectorColors.Add(key, false);
		}
	}

	// Token: 0x06000C31 RID: 3121 RVA: 0x00052400 File Offset: 0x00050600
	public void Update()
	{
		this.TestConnection();
		if (Network.isServer && this.m_SynchronizeCounter > Network.connections.Length && this.m_SynchronizeCounter > 0)
		{
			this.m_SynchronizeCounter = 0;
			if (Network.connections.Length > 0)
			{
				base.networkView.RPC("EndSynchronization", RPCMode.All, new object[]
				{
					this.m_SynchronizeIndex + 1
				});
			}
			else
			{
				this.EndSynchronization(this.m_SynchronizeIndex + 1);
				Network.Disconnect();
			}
		}
		if (!this.waitForNamesSynchro)
		{
			this.waitForNamesSynchro = true;
			foreach (KeyValuePair<NetworkPlayer, string> keyValuePair in this.peerNames)
			{
				base.networkView.RPC("SetPeerName", RPCMode.Others, new object[]
				{
					keyValuePair.Key,
					keyValuePair.Value,
					false
				});
			}
		}
		if (!this.waitForColorsSynchro)
		{
			this.waitForColorsSynchro = true;
			foreach (KeyValuePair<NetworkPlayer, Color> keyValuePair2 in this.playersColor)
			{
				Vector3 vector = new Vector3(keyValuePair2.Value.r, keyValuePair2.Value.g, keyValuePair2.Value.b);
				base.networkView.RPC("SetPlayersColor", RPCMode.Others, new object[]
				{
					keyValuePair2.Key,
					vector,
					false
				});
			}
		}
	}

	// Token: 0x06000C32 RID: 3122 RVA: 0x0000A74D File Offset: 0x0000894D
	public int GetNetworkID()
	{
		return this.networkID;
	}

	// Token: 0x06000C33 RID: 3123 RVA: 0x000525E4 File Offset: 0x000507E4
	public void OnPlayerDisconnected(NetworkPlayer player)
	{
		Network.RemoveRPCs(player, 0);
		if (Singleton<GameManager>.Instance.GameMode != null)
		{
			if (Singleton<GameManager>.Instance.GameMode.State != E_GameState.Podium)
			{
				GameObject player2 = Singleton<GameManager>.Instance.GameMode.GetPlayer(player);
				NetworkViewID viewID = player2.networkView.viewID;
				player2.networkView.viewID = Network.AllocateViewID();
				base.networkView.RPC("NotifyPlayerDisconnection", RPCMode.Others, new object[]
				{
					viewID,
					player2.networkView.viewID
				});
				Kart componentInChildren = player2.GetComponentInChildren<Kart>();
				componentInChildren.SetControlType(RcVehicle.ControlType.AI);
				componentInChildren.SetAutoPilot(true);
				RaceScoreData scoreData = Singleton<GameConfigurator>.Instance.RankingManager.GetScoreData(componentInChildren.Index);
				if (scoreData != null)
				{
					scoreData.IsAI = true;
				}
				((InGameGameMode)Singleton<GameManager>.Instance.GameMode).PlayerDisconnected(componentInChildren);
				RcVirtualController componentInChildren2 = componentInChildren.gameObject.transform.parent.GetComponentInChildren<RcVirtualController>();
				componentInChildren2.SetDrivingEnabled(true);
				((InGameGameMode)Singleton<GameManager>.Instance.GameMode).AIManager.RegisterVirtualController(componentInChildren2, E_AILevel.AVERAGE);
				this.initialNbPlayers--;
			}
		}
		else
		{
			Network.DestroyPlayerObjects(player);
		}
		base.networkView.RPC("RemoveNetworkPlayer", RPCMode.All, new object[]
		{
			player
		});
	}

	// Token: 0x06000C34 RID: 3124 RVA: 0x00052744 File Offset: 0x00050944
	public void OnServerInitialized(NetworkPlayer player)
	{
		this.m_SynchronizeIndex = 0;
		this.m_SynchronizeCounter = 0;
		this.m_WaitingSynchronization = false;
		this.m_sPlayerName = Singleton<GameSaveManager>.Instance.GetPseudo();
		this.selectorColorsInit();
		this.playersColor.Clear();
		this.peerNames.Clear();
		this.readyToGo.Clear();
		Color color = this.selectFreeColor();
		this.peerNames.Add(Network.player, this.m_sPlayerName);
		this.readyToGo.Add(Network.player, false);
		this.m_SelectorColors[color] = true;
		this.playersColor.Add(Network.player, color);
	}

	// Token: 0x06000C35 RID: 3125 RVA: 0x000527EC File Offset: 0x000509EC
	public void OnPlayerConnected(NetworkPlayer player)
	{
		foreach (KeyValuePair<NetworkPlayer, bool> keyValuePair in this.readyToGo)
		{
			base.networkView.RPC("SetReadyToGo", RPCMode.Others, new object[]
			{
				keyValuePair.Key,
				keyValuePair.Value
			});
		}
		if (Network.isServer)
		{
			base.networkView.RPC("SetGameModeID", RPCMode.Others, new object[]
			{
				this.gameModeId
			});
		}
	}

	// Token: 0x06000C36 RID: 3126 RVA: 0x000528A4 File Offset: 0x00050AA4
	public void DispatchIds()
	{
		if (Network.isServer)
		{
			this.networkID = 0;
			this.initialNbPlayers = 1;
			NetworkPlayer[] connections = Network.connections;
			this.initialNbPlayers += connections.Length;
			int num = this.networkID;
			foreach (NetworkPlayer target in connections)
			{
				base.networkView.RPC("SetNetworkID", target, new object[]
				{
					++num,
					this.initialNbPlayers
				});
			}
		}
	}

	// Token: 0x06000C37 RID: 3127 RVA: 0x00052940 File Offset: 0x00050B40
	public void OnDisconnectedFromServer(NetworkDisconnection info)
	{
		if (!Network.isServer)
		{
			this.peerNames.Clear();
			this.readyToGo.Clear();
			if (!LoadingManager.SLevelToLoad.Equals("MenuRoot"))
			{
				Singleton<GameConfigurator>.Instance.MenuToLaunch = EMenus.MENU_WELCOME;
				LoadingManager.LoadLevel("MenuRoot");
			}
		}
	}

	// Token: 0x06000C38 RID: 3128 RVA: 0x00052998 File Offset: 0x00050B98
	public Color selectFreeColor()
	{
		Color result = Color.white;
		foreach (KeyValuePair<Color, bool> keyValuePair in this.m_SelectorColors)
		{
			if (!keyValuePair.Value)
			{
				result = keyValuePair.Key;
				break;
			}
		}
		return result;
	}

	// Token: 0x06000C39 RID: 3129 RVA: 0x00052A0C File Offset: 0x00050C0C
	public void OnConnectedToServer()
	{
		this.m_SynchronizeIndex = 0;
		this.m_SynchronizeCounter = 0;
		this.m_WaitingSynchronization = false;
		this.selectorColorsInit();
		this.playersColor.Clear();
		this.peerNames.Clear();
		this.readyToGo.Clear();
		this.m_sPlayerName = Singleton<GameSaveManager>.Instance.GetPseudo();
		base.networkView.RPC("SetPeerName", RPCMode.Server, new object[]
		{
			Network.player,
			this.m_sPlayerName,
			true
		});
		base.networkView.RPC("SetReadyToGo", RPCMode.All, new object[]
		{
			Network.player,
			false
		});
		base.networkView.RPC("SetPlayersColor", RPCMode.Server, new object[]
		{
			Network.player,
			new Vector3(-1f, -1f, -1f),
			true
		});
	}

	// Token: 0x06000C3A RID: 3130 RVA: 0x0000A755 File Offset: 0x00008955
	public void OnFailedToConnect(NetworkConnectionError error)
	{
		this.peerNames.Clear();
		this.readyToGo.Clear();
	}

	// Token: 0x06000C3B RID: 3131 RVA: 0x0000A76D File Offset: 0x0000896D
	[RPC]
	public void SetPeerName(NetworkPlayer player, string name, bool synchro)
	{
		if (this.peerNames.ContainsKey(player))
		{
			this.peerNames[player] = name;
		}
		else
		{
			this.peerNames.Add(player, name);
		}
		if (synchro)
		{
			this.waitForNamesSynchro = false;
		}
	}

	// Token: 0x06000C3C RID: 3132 RVA: 0x0000A7AC File Offset: 0x000089AC
	[RPC]
	public void SetReadyToGo(NetworkPlayer player, bool ready)
	{
		if (this.readyToGo.ContainsKey(player))
		{
			this.readyToGo[player] = ready;
		}
		else
		{
			this.readyToGo.Add(player, ready);
		}
	}

	// Token: 0x06000C3D RID: 3133 RVA: 0x00052B14 File Offset: 0x00050D14
	public void ResetReadyStates()
	{
		List<NetworkPlayer> list = new List<NetworkPlayer>();
		foreach (NetworkPlayer item in this.readyToGo.Keys)
		{
			list.Add(item);
		}
		foreach (NetworkPlayer key in list)
		{
			this.readyToGo[key] = false;
		}
		list.Clear();
	}

	// Token: 0x06000C3E RID: 3134 RVA: 0x0000A7DE File Offset: 0x000089DE
	[RPC]
	public void NotifySelectingTrack()
	{
		GameObject.Find("MENU_REJOINDRE2").GetComponent<MenuMultiWaitingRoom>().NotifySelectingTrack();
	}

	// Token: 0x06000C3F RID: 3135 RVA: 0x00052BCC File Offset: 0x00050DCC
	[RPC]
	public void SetPlayersColor(NetworkPlayer player, Vector3 vColor, bool synchro)
	{
		Color color;
		if (synchro)
		{
			color = this.selectFreeColor();
		}
		else
		{
			color = new Color(vColor.x, vColor.y, vColor.z, 1f);
		}
		this.m_SelectorColors[color] = true;
		if (this.playersColor.ContainsKey(player))
		{
			this.playersColor[player] = color;
		}
		else
		{
			this.playersColor.Add(player, color);
		}
		if (synchro)
		{
			this.waitForColorsSynchro = false;
		}
	}

	// Token: 0x06000C40 RID: 3136 RVA: 0x00052C58 File Offset: 0x00050E58
	[RPC]
	public void AssignPlayerColor()
	{
		if (this.playersColor.ContainsKey(Network.player))
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.PlayerColor = this.playersColor[Network.player];
		}
		else
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.PlayerColor = Color.yellow;
		}
	}

	// Token: 0x06000C41 RID: 3137 RVA: 0x0000A7F4 File Offset: 0x000089F4
	[RPC]
	public void SetNetID(NetworkViewID id)
	{
		base.networkView.viewID = id;
	}

	// Token: 0x06000C42 RID: 3138 RVA: 0x00052CB4 File Offset: 0x00050EB4
	[RPC]
	public void NotifyPlayerDisconnection(NetworkViewID oldID, NetworkViewID newID)
	{
		GameObject player = Singleton<GameManager>.Instance.GameMode.GetPlayer(oldID);
		player.networkView.viewID = newID;
		Kart componentInChildren = player.GetComponentInChildren<Kart>();
		RaceScoreData scoreData = Singleton<GameConfigurator>.Instance.RankingManager.GetScoreData(componentInChildren.Index);
		if (scoreData != null)
		{
			scoreData.IsAI = true;
		}
	}

	// Token: 0x06000C43 RID: 3139 RVA: 0x00052D08 File Offset: 0x00050F08
	[RPC]
	public void RemoveNetworkPlayer(NetworkPlayer player)
	{
		this.peerNames.Remove(player);
		this.readyToGo.Remove(player);
		if (this.playersColor.ContainsKey(player))
		{
			Color key = this.playersColor[player];
			this.playersColor.Remove(player);
			if (this.m_SelectorColors.ContainsKey(key))
			{
				this.m_SelectorColors[key] = false;
			}
		}
	}

	// Token: 0x06000C44 RID: 3140 RVA: 0x0000A802 File Offset: 0x00008A02
	[RPC]
	public void ShareTrackChoice(int gameModeType, int championshipIndex, int trackIndex, int difficulty)
	{
		Singleton<GameConfigurator>.Instance.CurrentTrackIndex = trackIndex;
		Singleton<GameConfigurator>.Instance.GameModeType = (E_GameModeType)gameModeType;
		Singleton<GameConfigurator>.Instance.Difficulty = (EDifficulty)difficulty;
		Singleton<GameConfigurator>.Instance.SetChampionshipData(false, championshipIndex);
		this.m_bTrackChoiceReceived = true;
	}

	// Token: 0x06000C45 RID: 3141 RVA: 0x0000A839 File Offset: 0x00008A39
	[RPC]
	public void Go(string sceneName)
	{
		this.m_bTrackChoiceReceived = false;
		Singleton<GameConfigurator>.Instance.StartScene = sceneName;
		LoadingManager.LoadLevel(sceneName);
	}

	// Token: 0x06000C46 RID: 3142 RVA: 0x0000A853 File Offset: 0x00008A53
	[RPC]
	public void SetGameModeID(NetworkViewID id)
	{
		this.gameModeId = id;
		if (Singleton<GameManager>.Instance.NetworkView)
		{
			Singleton<GameManager>.Instance.NetworkView.viewID = this.gameModeId;
		}
	}

	// Token: 0x06000C47 RID: 3143 RVA: 0x0000A885 File Offset: 0x00008A85
	[RPC]
	public void NextRace()
	{
		ChampionShipGameMode.NextRace();
	}

	// Token: 0x06000C48 RID: 3144 RVA: 0x00052D78 File Offset: 0x00050F78
	[RPC]
	public void ShowPodium()
	{
		Singleton<GameManager>.Instance.GameMode.State = E_GameState.Podium;
		HUDInGame hudinGame = UnityEngine.Object.FindObjectOfType(typeof(HUDInGame)) as HUDInGame;
		HUDPause hudpause = UnityEngine.Object.FindObjectOfType(typeof(HUDPause)) as HUDPause;
		if (Network.isServer)
		{
			hudpause.PanelPauseChampionship.SetActive(false);
		}
		else if (Network.isClient)
		{
			hudpause.ShowEndOfRace();
			hudinGame.HudEndChampionshipRace.SetActive(false);
			hudinGame.HudEndChampionshipRank.SetActive(false);
			hudpause.PanelPauseChampionship.SetActive(false);
		}
	}

	// Token: 0x06000C49 RID: 3145 RVA: 0x00052E10 File Offset: 0x00051010
	[RPC]
	public IEnumerator SetMenu(int menuId)
	{
		MenuEntryPoint pMenuEntryPoint = GameObject.Find("MenuEntryPoint").GetComponent<MenuEntryPoint>();
		yield return new WaitForFixedUpdate();
		pMenuEntryPoint.SetState((EMenus)menuId);
		yield break;
	}

	// Token: 0x06000C4A RID: 3146 RVA: 0x0000A88C File Offset: 0x00008A8C
	[RPC]
	public void SetNetworkID(int id, int nbPlayers)
	{
		this.networkID = id;
		this.initialNbPlayers = nbPlayers;
	}

	// Token: 0x06000C4B RID: 3147 RVA: 0x0000A89C File Offset: 0x00008A9C
	[RPC]
	public void Synchronize(int networkID, int synchronizeIndex)
	{
		if (Network.isServer)
		{
			if (synchronizeIndex == this.m_SynchronizeIndex)
			{
				this.m_SynchronizeCounter++;
			}
		}
	}

	// Token: 0x06000C4C RID: 3148 RVA: 0x0000A8C7 File Offset: 0x00008AC7
	[RPC]
	public void EndSynchronization(int synchronizeIndex)
	{
		if (synchronizeIndex != this.m_SynchronizeIndex + 1)
		{
			Debug.LogError("[NETWORK] received wrong synchronization ended index");
		}
		else
		{
			this.m_SynchronizeIndex = synchronizeIndex;
			this.m_WaitingSynchronization = false;
		}
	}

	// Token: 0x06000C4D RID: 3149 RVA: 0x00052E34 File Offset: 0x00051034
	public void StartSynchronization()
	{
		if (!this.m_WaitingSynchronization)
		{
			if (Network.isServer)
			{
				this.m_SynchronizeCounter++;
				this.m_WaitingSynchronization = true;
			}
			else if (Network.isClient)
			{
				this.m_WaitingSynchronization = true;
				base.networkView.RPC("Synchronize", RPCMode.Server, new object[]
				{
					this.networkID,
					this.m_SynchronizeIndex
				});
			}
		}
	}

	// Token: 0x06000C4E RID: 3150 RVA: 0x0000A8F4 File Offset: 0x00008AF4
	[RPC]
	public void QuitToMenu(int menu)
	{
		Singleton<GameConfigurator>.Instance.MenuToLaunch = (EMenus)menu;
		if (Singleton<GameConfigurator>.Instance.PlayerConfig)
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.ResetAdvantages();
		}
		LoadingManager.LoadLevel("MenuRoot");
	}

	// Token: 0x06000C4F RID: 3151 RVA: 0x0000A92E File Offset: 0x00008B2E
	[RPC]
	public void RetryRace()
	{
		Singleton<GameConfigurator>.Instance.RankingManager.RestartRace();
		if (Singleton<GameConfigurator>.Instance.PlayerConfig)
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.ResetAdvantages();
		}
		LoadingManager.LoadLevel(Application.loadedLevelName);
	}

	// Token: 0x06000C50 RID: 3152 RVA: 0x0000A96C File Offset: 0x00008B6C
	[RPC]
	public void SetLevelIndex(int iLevelIndex)
	{
		LoadingManager.LevelIndex = iLevelIndex;
	}

	// Token: 0x04000BEF RID: 3055
	public int port = 31069;

	// Token: 0x04000BF0 RID: 3056
	public int maxPlayers = 6;

	// Token: 0x04000BF1 RID: 3057
	public List<Color> SelectedColors;

	// Token: 0x04000BF2 RID: 3058
	private int m_SynchronizeIndex;

	// Token: 0x04000BF3 RID: 3059
	private int m_SynchronizeCounter;

	// Token: 0x04000BF4 RID: 3060
	private bool m_WaitingSynchronization;

	// Token: 0x04000BF5 RID: 3061
	private int networkID = -1;

	// Token: 0x04000BF6 RID: 3062
	private int initialNbPlayers = 1;

	// Token: 0x04000BF7 RID: 3063
	private NetworkViewID gameModeId;

	// Token: 0x04000BF8 RID: 3064
	private Dictionary<NetworkPlayer, string> peerNames;

	// Token: 0x04000BF9 RID: 3065
	private Dictionary<NetworkPlayer, bool> readyToGo;

	// Token: 0x04000BFA RID: 3066
	private Dictionary<Color, bool> m_SelectorColors;

	// Token: 0x04000BFB RID: 3067
	private Dictionary<NetworkPlayer, Color> playersColor;

	// Token: 0x04000BFC RID: 3068
	private bool m_bLanOnly;

	// Token: 0x04000BFD RID: 3069
	private string m_sPlayerName = "Player";

	// Token: 0x04000BFE RID: 3070
	private string m_sGameName = string.Empty;

	// Token: 0x04000BFF RID: 3071
	public string ServerName;

	// Token: 0x04000C00 RID: 3072
	private string m_sExternalIP;

	// Token: 0x04000C01 RID: 3073
	private bool waitForNamesSynchro = true;

	// Token: 0x04000C02 RID: 3074
	private bool waitForColorsSynchro = true;

	// Token: 0x04000C03 RID: 3075
	public float m_fTestingTimeout = 10f;

	// Token: 0x04000C04 RID: 3076
	private float m_fTimer;

	// Token: 0x04000C05 RID: 3077
	private float m_fTimerNAT;

	// Token: 0x04000C06 RID: 3078
	private bool m_bTestAsked = true;

	// Token: 0x04000C07 RID: 3079
	private bool m_bDoneTesting;

	// Token: 0x04000C08 RID: 3080
	private bool m_bProbingPublicIP;

	// Token: 0x04000C09 RID: 3081
	private bool m_bUseNat;

	// Token: 0x04000C0A RID: 3082
	private bool m_bCanConnect;

	// Token: 0x04000C0B RID: 3083
	private ConnectionTesterStatus m_eConnectionTestResult = ConnectionTesterStatus.Undetermined;

	// Token: 0x04000C0C RID: 3084
	private bool m_bTrackChoiceReceived;
}

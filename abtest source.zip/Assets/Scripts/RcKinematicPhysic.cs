﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000222 RID: 546
public class RcKinematicPhysic : RcVehiclePhysic
{
	// Token: 0x06000F57 RID: 3927 RVA: 0x000611F8 File Offset: 0x0005F3F8
	public RcKinematicPhysic()
	{
		this.m_vImpulse = Vector3.zero;
		this.mPreviousPosition = Vector3.zero;
		this.mLinearVelocity = Vector3.zero;
		this.mAngularVelocity = Vector3.zero;
		this.mPreviousOrientation = Quaternion.identity;
		this.m_vTransSum = Vector3.zero;
		this.mRotationQuaternion = Quaternion.identity;
		this.mCollisionDotProdInertia = 1f;
		this.m_flying = false;
		this.m_prevFlying = false;
		this.m_landing = false;
		this.m_fInertiaTimer = 0f;
		this.m_bInertiaMode = false;
		this.m_vCombineTrickMv = Vector3.zero;
		this.m_vCollisionMove = Vector3.zero;
		this.m_bAllowedAirControl = true;
		this.m_fDriftAngle = 0f;
		this.m_fAvgFriction = 1f;
		this.m_SphereCollidesWith.value = 0;
		this.m_WheelsCollideWith.value = 0;
		this.m_WheelsGripWith.value = 0;
		this.m_vSurfaceResponses = new List<RcKinematicPhysic.SurfaceResponse>();
		this.collData = default(CollisionData);
		this.m_iCountFixedUpdate = RcKinematicPhysic.gsInitCountFixedUpdate++;
	}

	// Token: 0x170001F9 RID: 505
	// (get) Token: 0x06000F59 RID: 3929 RVA: 0x0000C819 File Offset: 0x0000AA19
	public int DeathMaskValue
	{
		get
		{
			return this.m_DeathMask.value;
		}
	}

	// Token: 0x170001FA RID: 506
	// (get) Token: 0x06000F5A RID: 3930 RVA: 0x0000C826 File Offset: 0x0000AA26
	public bool Flying
	{
		get
		{
			return this.m_flying;
		}
	}

	// Token: 0x170001FB RID: 507
	// (get) Token: 0x06000F5B RID: 3931 RVA: 0x0000C82E File Offset: 0x0000AA2E
	public Vector3 LinearVelocity
	{
		get
		{
			return this.mLinearVelocity;
		}
	}

	// Token: 0x170001FC RID: 508
	// (get) Token: 0x06000F5C RID: 3932 RVA: 0x0000C836 File Offset: 0x0000AA36
	public Vector3 CombineTrickMv
	{
		get
		{
			return this.m_vCombineTrickMv;
		}
	}

	// Token: 0x06000F5D RID: 3933 RVA: 0x000613EC File Offset: 0x0005F5EC
	public void Awake()
	{
		this.sphere = base.transform.parent.GetComponentInChildren<SphereCollider>();
		foreach (RcKinematicPhysic.SurfaceResponse surfaceResponse in this.m_vSurfaceResponses)
		{
			if (surfaceResponse.collidesWithChassis)
			{
				this.m_SphereCollidesWith.value = (this.m_SphereCollidesWith.value | surfaceResponse.layers.value);
			}
			if (surfaceResponse.collidesWithWheels)
			{
				this.m_WheelsCollideWith.value = (this.m_WheelsCollideWith.value | surfaceResponse.layers.value);
			}
			if (surfaceResponse.gripsWithWheels)
			{
				this.m_WheelsGripWith.value = (this.m_WheelsGripWith.value | surfaceResponse.layers.value);
			}
			if (surfaceResponse.kills)
			{
				this.m_DeathMask.value = (this.m_DeathMask.value | surfaceResponse.layers.value);
			}
		}
		this.ConfigureWheels();
	}

	// Token: 0x06000F5E RID: 3934 RVA: 0x000614FC File Offset: 0x0005F6FC
	public override bool IsGoingTooFast()
	{
		foreach (RcKinematicPhysic.SurfaceResponse surfaceResponse in this.m_vSurfaceResponses)
		{
			float maxSpeedKph = surfaceResponse.maxSpeedKph;
			int i = 0;
			while (i < this.m_iNbWheels)
			{
				int surface = this.m_pWheels[i].OGroundCharac.surface;
				if (this.m_pWheels[i].BOnGround && (1 << surface & surfaceResponse.layers.value) != 0)
				{
					if (this.m_fWVelocity * 3.6f > maxSpeedKph)
					{
						return true;
					}
					return false;
				}
				else
				{
					i++;
				}
			}
		}
		return false;
	}

	// Token: 0x06000F5F RID: 3935 RVA: 0x0000C83E File Offset: 0x0000AA3E
	public bool IsLocked()
	{
		return this.m_pVehicle != null && this.m_pVehicle.IsLocked();
	}

	// Token: 0x170001FD RID: 509
	// (get) Token: 0x06000F60 RID: 3936 RVA: 0x0000C85F File Offset: 0x0000AA5F
	public bool BInertiaMode
	{
		get
		{
			return this.m_bInertiaMode;
		}
	}

	// Token: 0x06000F61 RID: 3937 RVA: 0x000615D8 File Offset: 0x0005F7D8
	public override void Start()
	{
		base.Start();
		for (int i = 0; i < this.m_iNbWheels; i++)
		{
			this.m_pWheels[i].SetMasks(this.m_WheelsCollideWith, this.m_WheelsGripWith, this.m_DeathMask);
		}
	}

	// Token: 0x06000F62 RID: 3938 RVA: 0x00061624 File Offset: 0x0005F824
	public void ConfigureWheels()
	{
		this.m_pWheels = base.transform.parent.GetComponentsInChildren<RcKinematicWheel>();
		this.m_iNbWheels = this.m_pWheels.Length;
		RcPhysicWheel rcPhysicWheel = null;
		RcPhysicWheel rcPhysicWheel2 = null;
		for (int i = 0; i < this.m_iNbWheels; i++)
		{
			this.m_pWheels[i].FMassRep = 1f / (float)this.m_iNbWheels;
			if (this.m_pWheels[i].EAxle == RcPhysicWheel.WheelAxle.Rear)
			{
				rcPhysicWheel2 = this.m_pWheels[i];
			}
			else if (this.m_pWheels[i].EAxle == RcPhysicWheel.WheelAxle.Front)
			{
				rcPhysicWheel = this.m_pWheels[i];
			}
			else
			{
				if (!rcPhysicWheel)
				{
					rcPhysicWheel = this.m_pWheels[i];
				}
				if (!rcPhysicWheel2)
				{
					rcPhysicWheel2 = this.m_pWheels[i];
				}
			}
		}
		if (rcPhysicWheel == null || rcPhysicWheel2 == null)
		{
			this.m_fFrontToRearWheel = 1f;
		}
		else
		{
			this.m_fFrontToRearWheel = Mathf.Abs(Vector3.Dot(rcPhysicWheel.VOffset - rcPhysicWheel2.VOffset, Vector3.forward));
		}
	}

	// Token: 0x06000F63 RID: 3939 RVA: 0x00061744 File Offset: 0x0005F944
	public void SwitchToInertiaMode(float duration, Vector3 impulse, bool allowAirControl, bool cumulative)
	{
		this.m_fCurrentInertiaModeDamping = this.m_fInertiaModeDamping;
		if (!cumulative)
		{
			this.m_vImpulse = impulse;
			if (this.m_fInertiaTimer < duration)
			{
				this.m_fInertiaTimer = duration;
			}
		}
		else
		{
			this.m_fInertiaTimer += duration;
			this.m_vImpulse += impulse;
		}
		this.m_bInertiaMode = true;
		this.m_landing = false;
		this.m_bAllowedAirControl = (this.m_bAllowedAirControl && allowAirControl);
	}

	// Token: 0x06000F64 RID: 3940 RVA: 0x0000C867 File Offset: 0x0000AA67
	public void SwitchToInertiaMode(float duration, Vector3 impulse, bool allowAirControl, bool cumulative, Vector3 CustomDamping)
	{
		this.SwitchToInertiaMode(duration, impulse, allowAirControl, cumulative);
		this.m_fCurrentInertiaModeDamping = CustomDamping;
	}

	// Token: 0x06000F65 RID: 3941 RVA: 0x0000C82E File Offset: 0x0000AA2E
	public override Vector3 GetLinearVelocity()
	{
		return this.mLinearVelocity;
	}

	// Token: 0x06000F66 RID: 3942 RVA: 0x0000C87C File Offset: 0x0000AA7C
	public override Vector3 ForecastPosition(float dtSec)
	{
		return this.m_pVehicleRigidBodyTransform.position + dtSec * this.mLinearVelocity;
	}

	// Token: 0x06000F67 RID: 3943 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void SetGripFactor(float _factor)
	{
	}

	// Token: 0x06000F68 RID: 3944 RVA: 0x0000BBAC File Offset: 0x00009DAC
	public override float GetGripFactor()
	{
		return 1f;
	}

	// Token: 0x06000F69 RID: 3945 RVA: 0x0000C89A File Offset: 0x0000AA9A
	public override float GetWheelSpeed()
	{
		return this.m_fWVelocity;
	}

	// Token: 0x06000F6A RID: 3946 RVA: 0x0000C8A2 File Offset: 0x0000AAA2
	public override float GetFrontToRearWheelLength()
	{
		return this.m_fFrontToRearWheel;
	}

	// Token: 0x06000F6B RID: 3947 RVA: 0x000617C0 File Offset: 0x0005F9C0
	public override void Teleport(Vector3 vTeleportPos, Quaternion qTeleportOrientation, Vector3 linearVelocity, Vector3 angularVelocity)
	{
		if (vTeleportPos != this.m_pVehicleRigidBodyTransform.position)
		{
			this.m_pVehicleRigidBodyTransform.position = vTeleportPos;
		}
		this.SetOrientation(qTeleportOrientation);
		this.Reset();
		this.mPreviousPosition = vTeleportPos - linearVelocity * Time.fixedDeltaTime;
		if (angularVelocity != Vector3.zero)
		{
			float angle = Time.fixedDeltaTime * angularVelocity.magnitude * 57.29578f;
			Quaternion lhs = Quaternion.AngleAxis(angle, -angularVelocity);
			this.mPreviousOrientation = lhs * qTeleportOrientation;
		}
		else
		{
			this.mPreviousOrientation = qTeleportOrientation;
		}
		this.m_fInertiaTimer = 0f;
		this.mLinearVelocity = linearVelocity;
		this.mAngularVelocity = angularVelocity;
		this.m_vTransSum = Vector3.zero;
		this.mRotationQuaternion = Quaternion.identity;
		this.m_vCombineTrickMv = Vector3.zero;
		this.m_vCollisionMove = Vector3.zero;
		for (int i = 0; i < this.m_iNbWheels; i++)
		{
			this.m_pWheels[i].ResetMotion();
		}
		this.RetroApplyWheelSpeed();
		this.UpdateWheelGroundState();
	}

	// Token: 0x06000F6C RID: 3948 RVA: 0x000618D8 File Offset: 0x0005FAD8
	public override void NetMove(Vector3 vTeleportPos, Quaternion qTeleportOrientation, Vector3 linearVelocity, Vector3 angularVelocity)
	{
		if (vTeleportPos != this.m_pVehicleRigidBodyTransform.position)
		{
			this.m_pVehicleRigidBodyTransform.position = vTeleportPos;
		}
		this.SetOrientation(qTeleportOrientation);
		this.mPreviousPosition = vTeleportPos - linearVelocity * Time.fixedDeltaTime;
		if (angularVelocity != Vector3.zero)
		{
			float angle = Time.fixedDeltaTime * angularVelocity.magnitude * 57.29578f;
			Quaternion lhs = Quaternion.AngleAxis(angle, -angularVelocity);
			this.mPreviousOrientation = lhs * qTeleportOrientation;
		}
		else
		{
			this.mPreviousOrientation = qTeleportOrientation;
		}
		this.m_fInertiaTimer = 0f;
		this.mLinearVelocity = linearVelocity;
		this.mAngularVelocity = angularVelocity;
		this.m_vTransSum = Vector3.zero;
		this.mRotationQuaternion = Quaternion.identity;
		this.m_vCombineTrickMv = Vector3.zero;
		this.m_vCollisionMove = Vector3.zero;
		this.RetroApplyWheelSpeed();
	}

	// Token: 0x06000F6D RID: 3949 RVA: 0x0000C8AA File Offset: 0x0000AAAA
	public override RcPhysicWheel[] GetWheels()
	{
		return this.m_pWheels;
	}

	// Token: 0x06000F6E RID: 3950 RVA: 0x000619C0 File Offset: 0x0005FBC0
	public override void Reset()
	{
		this.m_iGroundSurface = 0;
		this.m_fGroundNormal = Vector3.up;
		this.mPreviousPosition = Vector3.zero;
		this.mPreviousOrientation = Quaternion.identity;
		this.mLinearVelocity = Vector3.zero;
		this.mAngularVelocity = Vector3.zero;
		this.m_fInertiaTimer = 0f;
		this.m_vImpulse = Vector3.zero;
		this.m_bAllowedAirControl = true;
		this.mCollisionDotProdInertia = 1f;
		this.m_flying = false;
		this.m_prevFlying = false;
		this.m_landing = false;
		this.m_fWVelocity = 0f;
		this.m_fAvgFriction = 1f;
		for (int i = 0; i < this.m_iNbWheels; i++)
		{
			this.m_pWheels[i].Reset();
		}
	}

	// Token: 0x06000F6F RID: 3951 RVA: 0x00061A84 File Offset: 0x0005FC84
	public override void Update()
	{
		this.m_fWVelocity = this.m_pVehicle.GetWheelSpeedMS() * (1f - this.m_pVehicle.GetHandicap());
		for (int i = 0; i < this.m_iNbWheels; i++)
		{
			this.m_pWheels[i].UpdateNode();
		}
	}

	// Token: 0x06000F70 RID: 3952 RVA: 0x00061AD8 File Offset: 0x0005FCD8
	public void FixedUpdate()
	{
		if (!this.m_bEnabled)
		{
			return;
		}
		float arcadeDriftFactor = this.m_pVehicle.GetArcadeDriftFactor();
		float fixedDeltaTime = Time.fixedDeltaTime;
		float num = this.m_fMaxDriftAngle * 3.14159274f / 180f;
		float num2 = arcadeDriftFactor * num;
		float num3 = num2 - this.m_fDriftAngle;
		float num4 = num / this.m_fTimeToMaxDriftAngle;
		if (num3 > 0f)
		{
			this.m_fDriftAngle += num4 * fixedDeltaTime;
			if (this.m_fDriftAngle > num2)
			{
				this.m_fDriftAngle = num2;
			}
		}
		else if (num3 < 0f)
		{
			this.m_fDriftAngle -= num4 * fixedDeltaTime;
			if (this.m_fDriftAngle < num2)
			{
				this.m_fDriftAngle = num2;
			}
		}
		Vector3 position = this.m_pVehicleRigidBodyTransform.position;
		Quaternion rotation = this.m_pVehicleRigidBodyTransform.rotation;
		float num5;
		(Quaternion.Inverse(this.mPreviousOrientation) * rotation).ToAngleAxis(out num5, out this.mAngularVelocity);
		this.mAngularVelocity.Normalize();
		this.mAngularVelocity *= num5 * 3.14159274f / 180f / fixedDeltaTime;
		this.mPreviousPosition = position;
		this.mPreviousOrientation = rotation;
		if (!this.m_flying && (this.m_prevFlying || this.m_bInertiaMode))
		{
			Vector3 vector = rotation * Vector3.forward;
			Vector3 rhs = Vector3.Cross(vector, this.m_fGroundNormal);
			vector = Vector3.Cross(this.m_fGroundNormal, rhs);
			vector.Normalize();
			float fWVelocity = Vector3.Dot(this.mLinearVelocity, vector);
			this.m_fWVelocity = fWVelocity;
			this.m_pVehicle.SetWheelSpeedMS(this.m_fWVelocity / (1f - this.m_pVehicle.GetHandicap()));
		}
		if (this.m_flying && this.m_bAllowedAirControl)
		{
			Vector3 rhs2 = this.mLinearVelocity;
			rhs2.y = 0f;
			Vector3 lhs = rotation * Vector3.forward;
			lhs.y = 0f;
			lhs.Normalize();
			float num6 = Vector3.Dot(lhs, rhs2);
			float num7 = this.m_pVehicle.GetSteeringFactor();
			if (arcadeDriftFactor != 0f)
			{
				num7 = RcUtils.LinearInterpolation(1f, 0f, -1f, num7, num7 * arcadeDriftFactor, true);
			}
			if (num7 != 0f)
			{
				float num8 = -num7 * fixedDeltaTime;
				if (num6 < -0.1f)
				{
					num8 *= -1f;
				}
				Quaternion rotation2 = Quaternion.AngleAxis(num8 * 180f / 3.14159274f, Vector3.up);
				this.Rotate(rotation2);
				this.mLinearVelocity = rotation2 * this.mLinearVelocity;
			}
		}
		this.m_vTransSum = Vector3.zero;
		this.mRotationQuaternion = Quaternion.identity;
		if (!this.m_flying && !this.m_bInertiaMode && this.m_fAvgFriction != 0f)
		{
			if (this.m_fWVelocity != 0f)
			{
				float steeringAngle = this.m_pVehicle.GetSteeringAngle();
				Vector3 vector2 = rotation * Vector3.forward;
				Vector3 vector3 = (!this.m_landing) ? (rotation * Vector3.up) : this.m_fGroundNormal;
				Vector3 vector4 = Vector3.Cross(vector3, vector2);
				vector4.Normalize();
				vector2 = Vector3.Cross(vector4, vector3);
				vector2.Normalize();
				Vector3 vector5 = vector2;
				vector5 *= this.m_fWVelocity * fixedDeltaTime * this.m_fAvgFriction;
				if (Mathf.Abs(steeringAngle) > 0.0001f)
				{
					float num9 = Mathf.Tan(steeringAngle);
					float num10 = -1f * this.m_fFrontToRearWheel / num9;
					Vector3 vector6 = position;
					RcPhysicWheel rcPhysicWheel = null;
					for (int i = 0; i < this.m_iNbWheels; i++)
					{
						if (this.m_pWheels[i].EAxle == RcPhysicWheel.WheelAxle.Rear)
						{
							rcPhysicWheel = this.m_pWheels[i];
							break;
						}
					}
					Vector3 vector7 = vector6;
					if (rcPhysicWheel)
					{
						vector7 += vector2 * rcPhysicWheel.VOffset.z;
					}
					Vector3 b = vector7 + vector4 * num10;
					float num11 = this.m_fWVelocity * fixedDeltaTime / num10;
					Quaternion rotation3 = Quaternion.AngleAxis(num11 * 180f / 3.14159274f, vector3);
					vector6 -= b;
					vector6 = rotation3 * vector6;
					vector6 += b;
					this.m_vTransSum = vector6 - position;
					vector7 -= b;
					vector7 = rotation3 * vector7;
					vector7 += b;
					Vector3 vector8 = vector6 - vector7;
					vector8.Normalize();
					Vector3 vector9 = rotation * Vector3.up;
					Vector3 rhs3 = Vector3.Cross(vector9, vector8);
					rhs3.Normalize();
					vector9 = Vector3.Cross(vector8, rhs3);
					Quaternion rhs4 = Quaternion.LookRotation(vector8, vector9);
					this.mRotationQuaternion = Quaternion.Inverse(rotation) * rhs4;
				}
				else
				{
					this.m_vTransSum = vector5;
				}
			}
		}
		else
		{
			Vector3 a = Vector3.zero;
			if (!this.bounced)
			{
				a = this.mLinearVelocity;
				a.y -= this.m_vCollisionMove.y / fixedDeltaTime;
			}
			this.bounced = false;
			a += this.m_vImpulse;
			this.m_vCollisionMove = Vector3.zero;
			this.m_vImpulse = Vector3.zero;
			this.m_vTransSum = a * fixedDeltaTime;
		}
		if (this.m_bInertiaMode)
		{
			this.m_fInertiaTimer -= fixedDeltaTime;
			if (this.m_fInertiaTimer < 0f)
			{
				this.m_fInertiaTimer = 0f;
				this.m_bInertiaMode = false;
				this.m_bAllowedAirControl = true;
			}
		}
		if (this.m_fWVelocity != 0f && this.m_pVehicleMesh != null)
		{
			Quaternion quaternion = Quaternion.AngleAxis(this.m_fDriftAngle * 180f / 3.14159274f, Vector3.up);
			Quaternion quaternion2 = Quaternion.Inverse(this.m_pVehicleMesh.localRotation) * quaternion;
			this.m_pVehicleMesh.localRotation = quaternion;
			if (arcadeDriftFactor == 0f)
			{
				float num12;
				Vector3 axis;
				quaternion2.ToAngleAxis(out num12, out axis);
				num12 *= -this.m_fGripRecoveryPrc;
				this.mRotationQuaternion *= Quaternion.AngleAxis(num12, axis);
			}
		}
		Vector3 a2 = Vector3.zero;
		if (!this.m_bInertiaMode || this.m_flying)
		{
			a2 += Physics.gravity;
		}
		if (this.m_bInertiaMode || this.m_fAvgFriction == 0f)
		{
			if (this.m_fCurrentInertiaModeDamping != Vector3.zero)
			{
				Vector3 vector10 = rotation * Vector3.right;
				Vector3 vector11 = rotation * Vector3.up;
				Vector3 vector12 = rotation * Vector3.forward;
				float num13 = Vector3.Dot(this.mLinearVelocity, vector10);
				float num14 = Vector3.Dot(this.mLinearVelocity, vector11);
				float num15 = Vector3.Dot(this.mLinearVelocity, vector12);
				a2 -= num13 * this.m_fCurrentInertiaModeDamping.x * vector10;
				if (num14 < 0f)
				{
					a2 -= num14 * this.m_fCurrentInertiaModeDamping.y * vector11;
				}
				a2 -= num15 * this.m_fCurrentInertiaModeDamping.z * vector12;
			}
		}
		else if (this.m_flying && this.m_fAirDamping != Vector3.zero)
		{
			Vector3 vector13 = rotation * Vector3.right;
			Vector3 vector14 = rotation * Vector3.up;
			Vector3 vector15 = rotation * Vector3.forward;
			float num16 = Vector3.Dot(this.mLinearVelocity, vector13);
			float num17 = Vector3.Dot(this.mLinearVelocity, vector14);
			float num18 = Vector3.Dot(this.mLinearVelocity, vector15);
			a2 -= num16 * this.m_fAirDamping.x * vector13;
			a2 -= num17 * this.m_fAirDamping.y * vector14;
			a2 -= num18 * this.m_fAirDamping.z * vector15;
		}
		if (!this.m_flying)
		{
			a2 += this.m_fGroundAdditionnalGravity * Vector3.down;
		}
		else
		{
			a2 += this.m_fAirAdditionnalGravity * Vector3.down;
		}
		this.m_vTransSum += a2 * fixedDeltaTime * fixedDeltaTime;
		this.m_bSimplifiedWheels = (this.m_pVehicle.GetControlType() != RcVehicle.ControlType.Human);
		Quaternion rotation4 = rotation * this.mRotationQuaternion;
		Vector3 vector16 = rotation4 * Vector3.up;
		if (this.m_bSimplifiedWheels && this.m_iNbWheels > 1)
		{
			int num19 = 1;
			float massOnAnchor = 1f / (float)this.m_iNbWheels;
			Vector3 vector17 = Vector3.zero;
			for (int j = 0; j < this.m_iNbWheels; j++)
			{
				vector17 += this.m_pWheels[j].VOffset;
			}
			vector17 *= 1f / (float)this.m_iNbWheels;
			Vector3 anchorPoint = position + this.m_vTransSum + rotation4 * vector17;
			this.m_pWheels[num19].updateAnchor(anchorPoint, vector16, massOnAnchor);
			this.m_pWheels[num19].Manage(fixedDeltaTime);
			if (this.m_pWheels[num19].BOnGround)
			{
				Vector3 vector18 = rotation4 * Vector3.forward;
				Vector3 normal = this.m_pWheels[num19].OGroundCharac.normal;
				Vector3 rhs5 = Vector3.Cross(vector18, normal);
				rhs5.Normalize();
				vector18 = Vector3.Cross(normal, rhs5);
				rotation4 = Quaternion.LookRotation(vector18, normal);
				vector16 = rotation4 * Vector3.up;
			}
			for (int k = 0; k < this.m_iNbWheels; k++)
			{
				if (k != num19)
				{
					this.m_pWheels[k].AdaptWithOffset(this.m_pWheels[num19], rotation4 * (this.m_pWheels[k].VOffset - vector17), fixedDeltaTime);
				}
			}
			this.m_pWheels[num19].AdaptWithOffset(this.m_pWheels[num19], rotation4 * (this.m_pWheels[num19].VOffset - vector17), fixedDeltaTime);
			for (int l = 0; l < this.m_iNbWheels; l++)
			{
				if (this.m_pWheels[l].BSteeringOn)
				{
					this.m_pWheels[l].FSteeringAngle = this.m_pVehicle.GetSteeringAngle();
				}
				this.m_pWheels[l].UpdateMotion(this.m_fWVelocity, this.mLinearVelocity);
			}
		}
		else
		{
			float massOnAnchor2 = 1f / (float)this.m_iNbWheels;
			for (int m = 0; m < this.m_iNbWheels; m++)
			{
				Vector3 anchorPoint2 = position + this.m_vTransSum + rotation4 * this.m_pWheels[m].VOffset;
				this.m_pWheels[m].updateAnchor(anchorPoint2, vector16, massOnAnchor2);
				this.m_pWheels[m].Manage(fixedDeltaTime);
				if (this.m_pWheels[m].BSteeringOn)
				{
					this.m_pWheels[m].FSteeringAngle = this.m_pVehicle.GetSteeringAngle();
				}
				this.m_pWheels[m].UpdateMotion(this.m_fWVelocity, this.mLinearVelocity);
			}
		}
		this.UpdateWheelGroundState();
		if (!this.m_flying)
		{
			Vector3 a3 = Vector3.zero;
			Vector3 a4 = Vector3.zero;
			Vector3 vector19 = Vector3.zero;
			Vector3 a5 = Vector3.zero;
			Vector3 vector20 = Vector3.zero;
			int num20 = 0;
			int num21 = 0;
			int num22 = 0;
			int num23 = 0;
			for (int n = 0; n < this.m_iNbWheels; n++)
			{
				if (this.m_pWheels[n].EAxle == RcPhysicWheel.WheelAxle.Front)
				{
					num20++;
					a4 += this.m_pWheels[n].VRestContactPoint - vector16 * this.m_pWheels[n].VOffset.y;
				}
				else if (this.m_pWheels[n].EAxle == RcPhysicWheel.WheelAxle.Rear)
				{
					num21++;
					vector19 += this.m_pWheels[n].VRestContactPoint - vector16 * this.m_pWheels[n].VOffset.y;
				}
				if (this.m_pWheels[n].ESide == RcPhysicWheel.WheelSide.Left)
				{
					num23++;
					a5 += this.m_pWheels[n].VRestContactPoint - vector16 * this.m_pWheels[n].VOffset.y;
				}
				else if (this.m_pWheels[n].ESide == RcPhysicWheel.WheelSide.Right)
				{
					num22++;
					vector20 += this.m_pWheels[n].VRestContactPoint - vector16 * this.m_pWheels[n].VOffset.y;
				}
			}
			if (num20 > 0)
			{
				a4 /= (float)num20;
			}
			if (num21 > 0)
			{
				vector19 /= (float)num21;
			}
			if (num23 > 0)
			{
				a5 /= (float)num23;
			}
			if (num22 > 0)
			{
				vector20 /= (float)num22;
			}
			Vector3 vector21 = a4 - vector19;
			vector21.Normalize();
			Vector3 lhs2 = a5 - vector20;
			lhs2.Normalize();
			Vector3 vector22 = Vector3.Cross(lhs2, vector21);
			vector22.Normalize();
			Quaternion quaternion3 = Quaternion.LookRotation(vector21, vector22);
			this.SetOrientation(quaternion3);
			float num24 = 0f;
			for (int num25 = 0; num25 < this.m_iNbWheels; num25++)
			{
				a3 += this.m_pWheels[num25].VRestContactPoint - rotation4 * this.m_pWheels[num25].VOffset;
				num24 += 1f;
			}
			a3 /= num24;
			this.mRotationQuaternion = Quaternion.Inverse(rotation4) * quaternion3;
			Vector3 lhs3 = a3 - position - this.m_vTransSum;
			float num26 = Vector3.Dot(lhs3, vector22);
			if (!this.m_bInertiaMode || this.m_landing || num26 > 0f)
			{
				this.m_vCombineTrickMv = vector22 * num26;
				this.m_vTransSum += this.m_vCombineTrickMv;
			}
			else
			{
				this.m_vCombineTrickMv = Vector3.zero;
			}
		}
		else
		{
			this.m_vCombineTrickMv = Vector3.zero;
		}
		this.collData.Reset();
		Vector3 vector23 = Vector3.zero;
		float num27 = 0f;
		RcKinematicPhysic.eMoveCheckResult eMoveCheckResult = this.SolveKinematic(ref position, this.m_vTransSum, 0, ref vector23, ref num27);
		this.m_pVehicleRigidBodyTransform.position = position;
		if (eMoveCheckResult == RcKinematicPhysic.eMoveCheckResult.R_BOUNCE_COLL)
		{
			vector23 -= Vector3.Dot(vector23, Vector3.up) * Vector3.up;
			Vector3 lhs4 = Vector3.Cross(this.mLinearVelocity, vector23);
			Vector3 vector24 = Vector3.Cross(lhs4, vector23);
			vector24.Normalize();
			float num28 = Vector3.Dot(this.mLinearVelocity, vector24);
			Vector3 vector25 = -this.mLinearVelocity + 2f * vector24 * Vector3.Dot(vector24, this.mLinearVelocity) * ((num28 <= 0f) ? 1f : -1f);
			vector25.Normalize();
			float d = num27 * this.mLinearVelocity.magnitude;
			vector25 *= d;
			vector25 += Vector3.up * 2f;
			vector25.Normalize();
			vector25 *= d;
			this.SwitchToInertiaMode(0.3f, vector25, true, false);
			this.bounced = true;
		}
		if (eMoveCheckResult != RcKinematicPhysic.eMoveCheckResult.R_NO_COLL)
		{
			this.m_vCollisionMove = position - this.mPreviousPosition - this.m_vTransSum;
		}
		if (eMoveCheckResult != RcKinematicPhysic.eMoveCheckResult.R_NO_COLL)
		{
			Vector3 vector26 = this.m_pVehicleRigidBodyTransform.rotation * Vector3.forward;
			float f = Vector3.Dot(this.mLinearVelocity, vector26);
			this.RetroApplyWheelSpeed();
			if (Mathf.Abs(f) > 0.01f)
			{
				Vector3 vector27 = vector26;
				vector27.y = 0f;
				vector27.Normalize();
				Vector3 vector28 = this.mLinearVelocity;
				vector28.y = 0f;
				vector28.Normalize();
				if (vector28 != vector27 && vector28 != -vector27)
				{
					Vector3 axis2 = Vector3.Cross(vector27, vector28);
					float v = Vector3.Dot(vector27, vector28);
					RcUtils.COMPUTE_INERTIA(ref this.mCollisionDotProdInertia, v, this.m_fCollisionReorientationInertia, fixedDeltaTime);
					float num29 = Mathf.Acos(this.mCollisionDotProdInertia);
					float num30 = this.m_fWallReorientateSpeed * fixedDeltaTime;
					if (num29 > num30)
					{
						num29 = num30;
					}
					else if (num29 < -num30)
					{
						num29 = -num30;
					}
					Quaternion rotation5 = Quaternion.AngleAxis(num29 * 180f / 3.14159274f, axis2);
					this.Rotate(rotation5);
				}
			}
			this.FireOnCollision(this.collData);
		}
		else
		{
			this.mCollisionDotProdInertia = 1f;
		}
		this.mLinearVelocity = (position - this.mPreviousPosition) / fixedDeltaTime;
		if (this.m_landing)
		{
			float num31 = Vector3.Dot(this.mLinearVelocity, this.m_fGroundNormal);
			if (num31 > 0f)
			{
				this.mLinearVelocity -= num31 * this.m_fGroundNormal;
			}
		}
	}

	// Token: 0x06000F71 RID: 3953 RVA: 0x00062CE0 File Offset: 0x00060EE0
	protected void UpdateWheelGroundState()
	{
		int num = 0;
		this.m_prevFlying = this.m_flying;
		this.m_iGroundSurface = 0;
		this.m_fAvgFriction = 0f;
		this.m_fGroundNormal = Vector3.zero;
		for (int i = 0; i < this.m_iNbWheels; i++)
		{
			if (this.m_pWheels[i].BOnGround)
			{
				int surface = this.m_pWheels[i].OGroundCharac.surface;
				if ((1 << surface & this.m_DeathMask.value) != 0)
				{
					this.DieMotherFucker(surface);
				}
				if (surface > this.m_iGroundSurface)
				{
					this.m_iGroundSurface = surface;
				}
				this.m_fGroundNormal += this.m_pWheels[i].OGroundCharac.normal;
				num++;
			}
			this.m_fAvgFriction += this.m_pWheels[i].FForwardGrip;
		}
		this.m_fAvgFriction /= (float)this.m_iNbWheels;
		if (num > 0)
		{
			this.m_fGroundNormal.Normalize();
			this.m_flying = false;
		}
		else
		{
			this.m_fGroundNormal = Vector3.up;
			this.m_flying = true;
		}
		if (!this.m_flying)
		{
			if (this.m_prevFlying)
			{
				this.m_landing = true;
			}
			else if (num == this.m_iNbWheels && !this.m_bInertiaMode)
			{
				this.m_landing = false;
			}
		}
		else
		{
			this.m_landing = false;
		}
	}

	// Token: 0x06000F72 RID: 3954 RVA: 0x00062E60 File Offset: 0x00061060
	protected void SetOrientation(Quaternion newOrientation)
	{
		Quaternion rotation = Quaternion.Inverse(this.m_pVehicleRigidBodyTransform.rotation) * newOrientation;
		this.Rotate(rotation);
	}

	// Token: 0x06000F73 RID: 3955 RVA: 0x0000C8B2 File Offset: 0x0000AAB2
	protected Quaternion GetOrientation()
	{
		return this.m_pVehicleRigidBodyTransform.rotation;
	}

	// Token: 0x06000F74 RID: 3956 RVA: 0x0000C8BF File Offset: 0x0000AABF
	protected void Rotate(Quaternion rotation)
	{
		this.Rotate(rotation, false);
	}

	// Token: 0x06000F75 RID: 3957 RVA: 0x00062E8C File Offset: 0x0006108C
	protected void Rotate(Quaternion rotation, bool byPass)
	{
		Quaternion rotation2 = this.m_pVehicleRigidBodyTransform.rotation;
		Quaternion quaternion = rotation2 * rotation;
		Vector3 fromDirection = quaternion * Vector3.up;
		Vector3 rhs = quaternion * Vector3.forward;
		Vector3 rhs2 = quaternion * Vector3.left;
		float num;
		Vector3 lhs;
		Quaternion.FromToRotation(fromDirection, this.m_fGroundNormal).ToAngleAxis(out num, out lhs);
		float num2 = Vector3.Dot(lhs, rhs2) * num;
		if (Mathf.Abs(num2) > this.m_fMaxIncline && !byPass)
		{
			Quaternion rhs3;
			if (num2 > 0f)
			{
				rhs3 = Quaternion.AngleAxis(num2 - this.m_fMaxIncline, Vector3.left);
			}
			else
			{
				rhs3 = Quaternion.AngleAxis(-num2 - this.m_fMaxIncline, -Vector3.left);
			}
			quaternion *= rhs3;
		}
		fromDirection = quaternion * Vector3.up;
		rhs = quaternion * Vector3.forward;
		rhs2 = quaternion * Vector3.left;
		Quaternion.FromToRotation(fromDirection, this.m_fGroundNormal).ToAngleAxis(out num, out lhs);
		float num3 = Vector3.Dot(lhs, rhs) * num;
		if (Mathf.Abs(num3) > this.m_fMaxIncline && !byPass)
		{
			Quaternion rhs4;
			if (num3 > 0f)
			{
				rhs4 = Quaternion.AngleAxis(num3 - this.m_fMaxIncline, Vector3.forward);
			}
			else
			{
				rhs4 = Quaternion.AngleAxis(-num3 - this.m_fMaxIncline, -Vector3.forward);
			}
			quaternion *= rhs4;
		}
		if (rotation2 != quaternion)
		{
			this.m_pVehicleRigidBodyTransform.rotation = quaternion;
		}
	}

	// Token: 0x06000F76 RID: 3958 RVA: 0x00063020 File Offset: 0x00061220
	protected void RetroApplyWheelSpeed()
	{
		if (!this.m_pVehicle.IsLocked())
		{
			Quaternion rotation = this.m_pVehicleRigidBodyTransform.rotation;
			Vector3 rhs = rotation * Vector3.forward;
			float num = Vector3.Dot(this.mLinearVelocity, rhs);
			if (Mathf.Abs(num) > 5f)
			{
				RcUtils.COMPUTE_INERTIA(ref this.m_fWVelocity, num, 0.999f, Time.deltaTime * 1000f);
			}
			else if (this.m_pVehicle.GetMoveFactor() > 0f)
			{
				this.m_fWVelocity = 5f;
			}
			else if (this.m_pVehicle.GetMoveFactor() < 0f)
			{
				this.m_fWVelocity = -5f;
			}
			else
			{
				this.m_fWVelocity = 0f;
			}
			this.m_pVehicle.SetWheelSpeedMS(this.m_fWVelocity / (1f - this.m_pVehicle.GetHandicap()));
		}
	}

	// Token: 0x06000F77 RID: 3959 RVA: 0x0006310C File Offset: 0x0006130C
	protected RcKinematicPhysic.eMoveCheckResult SolveKinematic(ref Vector3 position, Vector3 displ, int recursiveCnt, ref Vector3 colNrm, ref float bounce)
	{
		if (displ == Vector3.zero)
		{
			return RcKinematicPhysic.eMoveCheckResult.R_NO_COLL;
		}
		float magnitude = displ.magnitude;
		Vector3 zero = Vector3.zero;
		RcKinematicPhysic.eMoveCheckResult eMoveCheckResult = this.MvTest(position, ref magnitude, ref zero, this.sphere.radius, displ, ref colNrm, ref bounce);
		if (magnitude > 0f)
		{
			Vector3 a = displ;
			a.Normalize();
			position += magnitude * a;
		}
		if (zero != Vector3.zero && recursiveCnt < 4)
		{
			RcKinematicPhysic.eMoveCheckResult eMoveCheckResult2 = this.SolveKinematic(ref position, zero, recursiveCnt + 1, ref colNrm, ref bounce);
			if (eMoveCheckResult2 > eMoveCheckResult)
			{
				eMoveCheckResult = eMoveCheckResult2;
			}
		}
		return eMoveCheckResult;
	}

	// Token: 0x06000F78 RID: 3960 RVA: 0x000631BC File Offset: 0x000613BC
	protected RcKinematicPhysic.eMoveCheckResult MvTest(Vector3 position, ref float minDst, ref Vector3 remainingMove, float radius, Vector3 translation, ref Vector3 colNrm, ref float bounce)
	{
		Vector3 direction = translation;
		direction.Normalize();
		float num = minDst;
		Ray ray = default(Ray);
		ray.direction = direction;
		ray.origin = position + this.sphere.center;
		float magnitude = translation.magnitude;
		int num2 = this.m_SphereCollidesWith.value;
		if (!this.m_bTouchedDeath)
		{
			num2 |= this.m_DeathMask.value;
		}
		RaycastHit raycastHit;
		bool flag = Physics.SphereCast(ray, radius, out raycastHit, magnitude + this.m_fSkinWidth + 1f, num2);
		RcKinematicPhysic.eMoveCheckResult eMoveCheckResult = RcKinematicPhysic.eMoveCheckResult.R_NO_COLL;
		bool flag2 = false;
		int layer = 0;
		if (flag)
		{
			Vector3 normal = raycastHit.normal;
			Vector3 vector = raycastHit.point + raycastHit.normal * radius;
			float magnitude2 = (vector - ray.origin).magnitude;
			if (magnitude2 < 0f)
			{
				Debug.DrawLine(raycastHit.point, raycastHit.point + raycastHit.normal, Color.green, Time.deltaTime, false);
			}
			if (magnitude2 - this.m_fSkinWidth < minDst)
			{
				float num3 = 0.1f;
				eMoveCheckResult = RcKinematicPhysic.eMoveCheckResult.R_SLIDE_COLL;
				int layer2 = raycastHit.collider.gameObject.layer;
				flag2 = ((1 << layer2 & this.m_DeathMask.value) != 0);
				if (flag2)
				{
					layer = layer2;
				}
				minDst = magnitude2 - this.m_fSkinWidth;
				if (minDst < 0f)
				{
					minDst = 0f;
				}
				if ((1 << layer2 & this.m_SphereCollidesWith.value) == 0)
				{
					eMoveCheckResult = RcKinematicPhysic.eMoveCheckResult.R_NO_COLL;
					remainingMove = translation;
				}
				else
				{
					if (raycastHit.collider != null && raycastHit.collider.gameObject != null)
					{
						float num4 = Mathf.Abs(Vector3.Dot(this.mLinearVelocity, raycastHit.normal));
						foreach (RcKinematicPhysic.SurfaceResponse surfaceResponse in this.m_vSurfaceResponses)
						{
							int layer3 = raycastHit.collider.gameObject.layer;
							if ((1 << layer3 & surfaceResponse.layers.value) != 0 && num4 * 3.6f > surfaceResponse.bounceMinSpeedKph && bounce < surfaceResponse.bounce)
							{
								num3 = surfaceResponse.bounce;
								eMoveCheckResult = RcKinematicPhysic.eMoveCheckResult.R_BOUNCE_COLL;
								if (colNrm == Vector3.zero)
								{
									colNrm = raycastHit.normal;
									bounce = num3;
								}
							}
						}
					}
					Vector3 vector2 = ray.origin + translation - vector;
					remainingMove = vector2 - (1f + num3) * Vector3.Dot(vector2, normal) * normal;
					if (this.collData.position == Vector3.zero)
					{
						this.collData.normal = raycastHit.normal;
						this.collData.solid = this.m_pVehicleRigidBody;
						this.collData.other = raycastHit.rigidbody;
						this.collData.surface = layer2;
						this.collData.position = raycastHit.point;
						this.collData.depth = RcUtils.FastSqrtApprox(vector2.sqrMagnitude);
					}
				}
			}
		}
		if (flag2)
		{
			this.DieMotherFucker(layer);
		}
		if (eMoveCheckResult == RcKinematicPhysic.eMoveCheckResult.R_NO_COLL)
		{
			minDst = num;
			remainingMove = Vector3.zero;
		}
		return eMoveCheckResult;
	}

	// Token: 0x06000F79 RID: 3961 RVA: 0x00063560 File Offset: 0x00061760
	public void DieMotherFucker(int layer)
	{
		if (!this.m_bTouchedDeath)
		{
			this.m_bTouchedDeath = true;
			foreach (RcKinematicPhysic.SurfaceResponse surfaceResponse in this.m_vSurfaceResponses)
			{
				if ((surfaceResponse.layers.value & 1 << layer) != 0)
				{
					this.m_fDeathDelay = surfaceResponse.deathDelay;
					break;
				}
			}
		}
	}

	// Token: 0x06000F7A RID: 3962 RVA: 0x0000C8C9 File Offset: 0x0000AAC9
	public override float GetDriftRatio()
	{
		return 0.5f * Mathf.Abs(this.m_pVehicle.GetArcadeDriftFactor());
	}

	// Token: 0x06000F7B RID: 3963 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
	public override Vector3 GetAngularVelocity()
	{
		return this.mAngularVelocity;
	}

	// Token: 0x06000F7C RID: 3964 RVA: 0x0000C8E9 File Offset: 0x0000AAE9
	public override void SetLinearVelocity(Vector3 velocity)
	{
		this.mLinearVelocity = velocity;
	}

	// Token: 0x06000F7D RID: 3965 RVA: 0x0000C8F2 File Offset: 0x0000AAF2
	public override void SetAngularVelocity(Vector3 velocity)
	{
		this.mAngularVelocity = velocity;
	}

	// Token: 0x04000EBE RID: 3774
	protected Vector3 m_vImpulse = Vector3.zero;

	// Token: 0x04000EBF RID: 3775
	public Vector3 m_fAirDamping = Vector3.one;

	// Token: 0x04000EC0 RID: 3776
	public Vector3 m_fInertiaModeDamping = Vector3.one;

	// Token: 0x04000EC1 RID: 3777
	protected Vector3 m_fCurrentInertiaModeDamping = Vector3.one;

	// Token: 0x04000EC2 RID: 3778
	public float m_fAirAdditionnalGravity = 10f;

	// Token: 0x04000EC3 RID: 3779
	public float m_fGroundAdditionnalGravity;

	// Token: 0x04000EC4 RID: 3780
	public float m_fCollisionReorientationInertia = 0.98f;

	// Token: 0x04000EC5 RID: 3781
	public bool m_bDebugInfo;

	// Token: 0x04000EC6 RID: 3782
	public float m_fMass = 1f;

	// Token: 0x04000EC7 RID: 3783
	protected LayerMask m_DeathMask;

	// Token: 0x04000EC8 RID: 3784
	protected LayerMask m_SphereCollidesWith;

	// Token: 0x04000EC9 RID: 3785
	protected LayerMask m_WheelsCollideWith;

	// Token: 0x04000ECA RID: 3786
	protected LayerMask m_WheelsGripWith;

	// Token: 0x04000ECB RID: 3787
	protected Vector3 m_vCombineTrickMv = Vector3.zero;

	// Token: 0x04000ECC RID: 3788
	protected Vector3 m_vCollisionMove = Vector3.zero;

	// Token: 0x04000ECD RID: 3789
	public float m_fSkinWidth = 0.02f;

	// Token: 0x04000ECE RID: 3790
	public Transform m_pVehicleMesh;

	// Token: 0x04000ECF RID: 3791
	protected bool m_bAllowedAirControl;

	// Token: 0x04000ED0 RID: 3792
	protected bool m_flying;

	// Token: 0x04000ED1 RID: 3793
	protected bool m_prevFlying;

	// Token: 0x04000ED2 RID: 3794
	protected bool m_landing;

	// Token: 0x04000ED3 RID: 3795
	protected float mCollisionDotProdInertia;

	// Token: 0x04000ED4 RID: 3796
	protected Vector3 mPreviousPosition;

	// Token: 0x04000ED5 RID: 3797
	protected Quaternion mPreviousOrientation;

	// Token: 0x04000ED6 RID: 3798
	protected Vector3 mLinearVelocity;

	// Token: 0x04000ED7 RID: 3799
	protected Vector3 mAngularVelocity;

	// Token: 0x04000ED8 RID: 3800
	protected Vector3 m_vTransSum;

	// Token: 0x04000ED9 RID: 3801
	protected Quaternion mRotationQuaternion;

	// Token: 0x04000EDA RID: 3802
	protected RcKinematicWheel[] m_pWheels;

	// Token: 0x04000EDB RID: 3803
	protected float m_fFrontToRearWheel;

	// Token: 0x04000EDC RID: 3804
	protected SphereCollider sphere;

	// Token: 0x04000EDD RID: 3805
	protected bool m_bInertiaMode;

	// Token: 0x04000EDE RID: 3806
	protected float m_fDriftAngle;

	// Token: 0x04000EDF RID: 3807
	public float m_fMaxDriftAngle = 35f;

	// Token: 0x04000EE0 RID: 3808
	public float m_fTimeToMaxDriftAngle = 0.3f;

	// Token: 0x04000EE1 RID: 3809
	public float m_fGripRecoveryPrc = 0.75f;

	// Token: 0x04000EE2 RID: 3810
	public float m_fMaxIncline = 40f;

	// Token: 0x04000EE3 RID: 3811
	protected float m_fAvgFriction;

	// Token: 0x04000EE4 RID: 3812
	protected bool bounced;

	// Token: 0x04000EE5 RID: 3813
	public float m_fVehicleCollSideImpulseIntensity = 6f;

	// Token: 0x04000EE6 RID: 3814
	public float m_fVehicleCollUpImpulseIntensity = 1.3f;

	// Token: 0x04000EE7 RID: 3815
	public float m_fVehicleCollBackPrc = 0.1f;

	// Token: 0x04000EE8 RID: 3816
	public float m_fVehicleCollInertiaDelay = 0.2f;

	// Token: 0x04000EE9 RID: 3817
	public Vector3 m_fVehicleCollInertiaDamping = Vector3.zero;

	// Token: 0x04000EEA RID: 3818
	public float m_fWallReorientateSpeed = 0.5f;

	// Token: 0x04000EEB RID: 3819
	protected float m_fInertiaTimer;

	// Token: 0x04000EEC RID: 3820
	public List<RcKinematicPhysic.SurfaceResponse> m_vSurfaceResponses;

	// Token: 0x04000EED RID: 3821
	protected CollisionData collData;

	// Token: 0x04000EEE RID: 3822
	public bool m_bSimplifiedWheels;

	// Token: 0x04000EEF RID: 3823
	public int m_iCountFixedUpdate;

	// Token: 0x04000EF0 RID: 3824
	private static int gsInitCountFixedUpdate;

	// Token: 0x02000223 RID: 547
	[Serializable]
	public class SurfaceResponse
	{
		// Token: 0x04000EF1 RID: 3825
		public LayerMask layers;

		// Token: 0x04000EF2 RID: 3826
		public float maxSpeedKph;

		// Token: 0x04000EF3 RID: 3827
		public float bounce;

		// Token: 0x04000EF4 RID: 3828
		public float bounceMinSpeedKph;

		// Token: 0x04000EF5 RID: 3829
		public bool collidesWithChassis;

		// Token: 0x04000EF6 RID: 3830
		public bool collidesWithWheels;

		// Token: 0x04000EF7 RID: 3831
		public bool gripsWithWheels;

		// Token: 0x04000EF8 RID: 3832
		public bool kills;

		// Token: 0x04000EF9 RID: 3833
		public float deathDelay;
	}

	// Token: 0x02000224 RID: 548
	public enum eMoveCheckResult
	{
		// Token: 0x04000EFB RID: 3835
		R_NO_COLL,
		// Token: 0x04000EFC RID: 3836
		R_SLIDE_COLL,
		// Token: 0x04000EFD RID: 3837
		R_BOUNCE_COLL,
		// Token: 0x04000EFE RID: 3838
		RESULT_COUNT
	}
}

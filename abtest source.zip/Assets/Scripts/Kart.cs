﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200013F RID: 319
public class Kart : RcVehicle
{
	// Token: 0x17000144 RID: 324
	// (get) Token: 0x060008C4 RID: 2244 RVA: 0x00008261 File Offset: 0x00006461
	// (set) Token: 0x060008C5 RID: 2245 RVA: 0x00008269 File Offset: 0x00006469
	public bool IsInShortCut { get; set; }

	// Token: 0x17000145 RID: 325
	// (get) Token: 0x060008C6 RID: 2246 RVA: 0x00008272 File Offset: 0x00006472
	// (set) Token: 0x060008C7 RID: 2247 RVA: 0x0000827A File Offset: 0x0000647A
	public bool HasDiamondAttached { get; set; }

	// Token: 0x17000146 RID: 326
	// (get) Token: 0x060008C8 RID: 2248 RVA: 0x00008283 File Offset: 0x00006483
	public KartSound KartSound
	{
		get
		{
			return this.m_pKartSound;
		}
	}

	// Token: 0x17000147 RID: 327
	// (get) Token: 0x060008C9 RID: 2249 RVA: 0x0003F588 File Offset: 0x0003D788
	public NetworkViewID networkViewID
	{
		get
		{
			if (this.m_oNetworkViewID.Equals(NetworkViewID.unassigned))
			{
				this.m_oNetworkViewID = this.Transform.parent.gameObject.networkView.viewID;
			}
			return this.m_oNetworkViewID;
		}
	}

	// Token: 0x17000148 RID: 328
	// (get) Token: 0x060008CA RID: 2250 RVA: 0x0000828B File Offset: 0x0000648B
	// (set) Token: 0x060008CB RID: 2251 RVA: 0x00008293 File Offset: 0x00006493
	public Transform Transform
	{
		get
		{
			return this.m_pTransform;
		}
		set
		{
			this.m_pTransform = value;
		}
	}

	// Token: 0x17000149 RID: 329
	// (get) Token: 0x060008CC RID: 2252 RVA: 0x0000829C File Offset: 0x0000649C
	public KartAnim Anim
	{
		get
		{
			return this.m_pKartAnim;
		}
	}

	// Token: 0x1700014A RID: 330
	// (get) Token: 0x060008CD RID: 2253 RVA: 0x000082A4 File Offset: 0x000064A4
	public KartBonusMgr BonusMgr
	{
		get
		{
			return this.m_pKartBonusMgr;
		}
	}

	// Token: 0x1700014B RID: 331
	// (get) Token: 0x060008CE RID: 2254 RVA: 0x000082AC File Offset: 0x000064AC
	// (set) Token: 0x060008CF RID: 2255 RVA: 0x000082B4 File Offset: 0x000064B4
	public HUDBonus HUDBonus
	{
		get
		{
			return this.m_pHudBonus;
		}
		set
		{
			this.m_pHudBonus = value;
			if (this.m_pKartBonusMgr != null)
			{
				this.m_pKartBonusMgr.HUDBonus = this.m_pHudBonus;
			}
		}
	}

	// Token: 0x1700014C RID: 332
	// (get) Token: 0x060008D0 RID: 2256 RVA: 0x000082DF File Offset: 0x000064DF
	// (set) Token: 0x060008D1 RID: 2257 RVA: 0x000082E7 File Offset: 0x000064E7
	public HUDPosition HUDPosition
	{
		get
		{
			return this.m_pHudPosition;
		}
		set
		{
			this.m_pHudPosition = value;
		}
	}

	// Token: 0x1700014D RID: 333
	// (get) Token: 0x060008D2 RID: 2258 RVA: 0x000082F0 File Offset: 0x000064F0
	public KartFxMgr FxMgr
	{
		get
		{
			return this.m_pKartFxMgr;
		}
	}

	// Token: 0x1700014E RID: 334
	// (get) Token: 0x060008D3 RID: 2259 RVA: 0x000082F8 File Offset: 0x000064F8
	// (set) Token: 0x060008D4 RID: 2260 RVA: 0x00008300 File Offset: 0x00006500
	public EAdvantage SelectedAdvantage
	{
		get
		{
			return this.m_eAdvantage;
		}
		set
		{
			this.m_eAdvantage = value;
		}
	}

	// Token: 0x1700014F RID: 335
	// (get) Token: 0x060008D5 RID: 2261 RVA: 0x00008309 File Offset: 0x00006509
	public float MiniBoost
	{
		get
		{
			return this.m_fMiniBoost;
		}
	}

	// Token: 0x060008D6 RID: 2262 RVA: 0x00008311 File Offset: 0x00006511
	public bool IsSleeping()
	{
		return this._napEffectTime > 0f;
	}

	// Token: 0x17000150 RID: 336
	// (get) Token: 0x060008D7 RID: 2263 RVA: 0x0003F5D8 File Offset: 0x0003D7D8
	public Vector3 LaunchDirection
	{
		get
		{
			Transform pVehicleMesh = (this.m_pVehiclePhysic as RcKinematicPhysic).m_pVehicleMesh;
			return Quaternion.Slerp(pVehicleMesh.rotation, this.m_pTransform.rotation, this.DriftRatio) * Vector3.forward;
		}
	}

	// Token: 0x17000151 RID: 337
	// (get) Token: 0x060008D8 RID: 2264 RVA: 0x0003F61C File Offset: 0x0003D81C
	public Vector3 LaunchHorizontalDirection
	{
		get
		{
			Transform pVehicleMesh = (this.m_pVehiclePhysic as RcKinematicPhysic).m_pVehicleMesh;
			Vector3 vector = Quaternion.Slerp(pVehicleMesh.rotation, this.m_pTransform.rotation, this.DriftRatio) * Vector3.forward;
			vector.y = 0f;
			return vector.normalized;
		}
	}

	// Token: 0x060008D9 RID: 2265 RVA: 0x0003F674 File Offset: 0x0003D874
	public override void Awake()
	{
		base.Awake();
		this.m_pTransform = base.gameObject.transform;
		this.m_pKartAnim = this.m_pTransform.parent.FindChild("Base").GetComponent<KartAnim>();
		this.m_pKartBonusMgr = this.m_pTransform.parent.FindChild("Base").GetComponent<KartBonusMgr>();
		this.m_pKartFxMgr = this.m_pTransform.parent.FindChild("Base").GetComponent<KartFxMgr>();
		this.m_pKartSound = this.m_pTransform.parent.FindChild("Sound").GetComponent<KartSound>();
	}

	// Token: 0x060008DA RID: 2266 RVA: 0x0003F718 File Offset: 0x0003D918
	public override void Start()
	{
		base.Start();
		this.SetDefaultValues();
		if (DebugMgr.Instance != null && DebugMgr.Instance.dbgData.DisplayCustom)
		{
			KartArcadeGearBox kartArcadeGearBox = (KartArcadeGearBox)this.m_pGearBox;
			string text = "Vehicule " + this.Index;
			for (int i = 0; i < Enum.GetValues(typeof(DrivingCaracteristics)).Length; i++)
			{
				string text2 = text;
				text = string.Concat(new object[]
				{
					text2,
					" : ",
					((DrivingCaracteristics)i).ToString(),
					" : ",
					kartArcadeGearBox.GetPercentAdvantages((DrivingCaracteristics)i)
				});
			}
		}
		this.m_fMiniBoost = 0f;
		this.m_eAdvantage = EAdvantage.None;
		this.m_bMiniboostThresholdOk = false;
		if (this.m_eControlType == RcVehicle.ControlType.Human && Singleton<GameManager>.Instance.GameMode.Hud != null && Singleton<GameManager>.Instance.GameMode.Hud.Position.WrongWay != null)
		{
			Singleton<GameManager>.Instance.GameMode.Hud.Position.WrongWay.SetActive(false);
		}
	}

	// Token: 0x060008DB RID: 2267 RVA: 0x0003F858 File Offset: 0x0003DA58
	public void CancelDrift()
	{
		this.SetArcadeDriftFactor(0f);
		this.m_pKartFxMgr.StopDriftFx();
		this.m_pKartFxMgr.KartFxs[0].ParticleSystem.Stop();
		this.m_pKartFxMgr.KartFxs[8].ParticleSystem.Stop();
		if (base.GetControlType() == RcVehicle.ControlType.Human)
		{
			Camera mainCamera = Camera.mainCamera;
			mainCamera.GetComponent<CamStateFollow>().bBoost = false;
			ParticleSystem componentInChildren = mainCamera.GetComponentInChildren<ParticleSystem>();
			if (componentInChildren)
			{
				componentInChildren.Stop();
			}
		}
	}

	// Token: 0x060008DC RID: 2268 RVA: 0x00008320 File Offset: 0x00006520
	public void Draft(float deltaTime)
	{
		this.m_fDeltaDraft = deltaTime;
	}

	// Token: 0x060008DD RID: 2269 RVA: 0x00008329 File Offset: 0x00006529
	public void ResetDraft()
	{
		this.m_fDraftTimer = 0f;
	}

	// Token: 0x060008DE RID: 2270 RVA: 0x0003F8E0 File Offset: 0x0003DAE0
	public override void Update()
	{
		base.Update();
		float deltaTime = Time.deltaTime;
		if (this._napEffectTime > 0f)
		{
			this._napEffectTime -= deltaTime;
			if (this._napEffectTime <= 0f)
			{
				this._napEffectTime = 0f;
				base.GetCarac().m_fDriftTimeToMaxSteering -= this._napEffectFactor;
				base.GetCarac().m_fResetSteeringNoInput -= this._napEffectFactor;
				base.GetCarac().m_fDriftResetSteeringNoInput -= this._napEffectFactor;
				base.GetCarac().m_fTimeToMaxSteering -= this._napEffectFactor;
				base.GetCarac().m_fResetSteeringOppositeInput -= this._napEffectFactor / 2f;
				this._napEffectFactor = 0f;
			}
			else
			{
				this.SetArcadeDriftFactor(0f);
			}
		}
		else
		{
			float num = this.ComputeMiniBoostFillRate();
			if (this.m_fMiniBoost < 100f)
			{
				this.m_fMiniBoost += deltaTime * num;
				Mathf.Clamp(this.m_fMiniBoost, 0f, 100f);
				if (this.m_fMiniBoost >= this.ThresholdMiniBoost)
				{
					this.m_pKartFxMgr.BoostDrift(this.m_fMiniBoost, this.ThresholdMiniBoost);
					if (this.m_pKartSound && !this.m_bMiniboostThresholdOk)
					{
						this.m_pKartSound.PlaySound(7);
						this.m_bMiniboostThresholdOk = true;
					}
				}
			}
		}
		if (base.RaceStats != null && this.m_pHudPosition != null)
		{
			this.m_pHudPosition.DisplayRaceStats(base.RaceStats);
		}
		if (this.m_eControlType == RcVehicle.ControlType.Human && Singleton<GameManager>.Instance.GameMode.State == E_GameState.Race)
		{
			if (this.m_pRaceStats.IsReverse())
			{
				this.m_fWrongWayTimer += Time.deltaTime;
				if (this.m_fWrongWayTimer > this.WrongWayTimer)
				{
					Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.WrongWay);
					Singleton<GameManager>.Instance.GameMode.Hud.Position.WrongWay.SetActive(true);
				}
			}
			else if (this.m_fWrongWayTimer > 0f)
			{
				Singleton<GameManager>.Instance.SoundManager.StopSound(ERaceSounds.WrongWay);
				Singleton<GameManager>.Instance.GameMode.Hud.Position.WrongWay.SetActive(false);
				this.m_fWrongWayTimer = 0f;
			}
		}
		if (this.hasSpringActivated && base.IsOnGround())
		{
			base.StartCoroutine(this.DoSpringJump());
			this.hasSpringActivated = false;
		}
	}

	// Token: 0x060008DF RID: 2271 RVA: 0x0003FB94 File Offset: 0x0003DD94
	public void LateUpdate()
	{
		if (this.m_fDeltaDraft > 0f)
		{
			this.m_fDraftTimer += this.m_fDeltaDraft;
			this.m_fDeltaDraft = 0f;
			if (this.m_fDraftTimer >= this.DraftTimer)
			{
				this.ResetDraft();
				this.LaunchMiniBoost();
			}
		}
		else
		{
			this.ResetDraft();
		}
	}

	// Token: 0x060008E0 RID: 2272 RVA: 0x0003FBF8 File Offset: 0x0003DDF8
	public IEnumerator DoSpringJump()
	{
		yield return new WaitForSeconds(0.05f);
		this.Jump(this.tmpJumpHeight, this.tmpJumpForward);
		yield break;
	}

	// Token: 0x060008E1 RID: 2273 RVA: 0x0003FC14 File Offset: 0x0003DE14
	public void OnGUI()
	{
		if (base.GetControlType() == RcVehicle.ControlType.Human && DebugMgr.Instance != null && DebugMgr.Instance.dbgData.DisplaySpeed)
		{
			GUI.contentColor = Color.red;
			GUI.Label(new Rect(400f, 20f, 200f, 50f), string.Concat(new object[]
			{
				"Speed : ",
				base.GetWheelSpeedMS() * 3.6f,
				"(",
				base.GetWheelSpeedMS() * 3.6f * (1f - base.GetHandicap()),
				")"
			}));
		}
	}

	// Token: 0x060008E2 RID: 2274 RVA: 0x0003FCCC File Offset: 0x0003DECC
	public void StartSleepMode(float pIntertiaFactor, float pDuration)
	{
		if (this._napEffectTime == 0f && this._napEffectFactor == 0f)
		{
			this._napEffectFactor = base.GetCarac().m_fDriftTimeToMaxSteering * pIntertiaFactor;
			base.GetCarac().m_fDriftTimeToMaxSteering += this._napEffectFactor;
			base.GetCarac().m_fResetSteeringNoInput += this._napEffectFactor;
			base.GetCarac().m_fDriftResetSteeringNoInput += this._napEffectFactor;
			base.GetCarac().m_fTimeToMaxSteering += this._napEffectFactor;
			base.GetCarac().m_fResetSteeringOppositeInput += this._napEffectFactor / 2f;
			this.m_fMiniBoost = 0f;
			this.m_bMiniboostThresholdOk = false;
			this.SetArcadeDriftFactor(0f);
			this.FxMgr.StopDriftFx();
		}
		this._napEffectTime = pDuration;
	}

	// Token: 0x060008E3 RID: 2275 RVA: 0x0003FDBC File Offset: 0x0003DFBC
	public void SetDefaultValues()
	{
		KartArcadeGearBox kartArcadeGearBox = (KartArcadeGearBox)this.m_pGearBox;
		kartArcadeGearBox.SetDefaultValues();
		this.m_fInvincibleTimer = 0f;
	}

	// Token: 0x060008E4 RID: 2276 RVA: 0x000082A4 File Offset: 0x000064A4
	public KartBonusMgr GetBonusMgr()
	{
		return this.m_pKartBonusMgr;
	}

	// Token: 0x060008E5 RID: 2277 RVA: 0x0003FDE8 File Offset: 0x0003DFE8
	public override void Respawn()
	{
		KartArcadeGearBox kartArcadeGearBox = (KartArcadeGearBox)this.m_pGearBox;
		kartArcadeGearBox.SetDefaultValues();
		this.m_pKartBonusMgr.Respawn();
		this.m_pKartAnim.ForceStopBonusAnimAll();
		base.Respawn();
		if (Singleton<ChallengeManager>.Instance.IsActive && base.GetControlType() == RcVehicle.ControlType.Human)
		{
			Singleton<ChallengeManager>.Instance.Notify(EChallengeSingleRaceObjective.NoFall);
		}
	}

	// Token: 0x060008E6 RID: 2278 RVA: 0x0003FE48 File Offset: 0x0003E048
	public override bool IsBoosting()
	{
		KartArcadeGearBox kartArcadeGearBox = (KartArcadeGearBox)this.m_pGearBox;
		return kartArcadeGearBox.IsBoosting();
	}

	// Token: 0x060008E7 RID: 2279 RVA: 0x0003FE68 File Offset: 0x0003E068
	public override void ManageRunState()
	{
		base.ManageRunState();
		float deltaTime = Time.deltaTime;
		if (this.m_fInvincibleTimer > 0f)
		{
			this.m_fInvincibleTimer -= deltaTime;
		}
		else if ((double)this.m_fInvincibleTimer != -1.0)
		{
			this.m_fInvincibleTimer = 0f;
		}
	}

	// Token: 0x060008E8 RID: 2280 RVA: 0x00008336 File Offset: 0x00006536
	public void ActivateInvincibility(float _invincibleDelay)
	{
		this.m_fInvincibleTimer = _invincibleDelay;
	}

	// Token: 0x060008E9 RID: 2281 RVA: 0x0000833F File Offset: 0x0000653F
	public void DeactivateInvincibility()
	{
		this.m_fInvincibleTimer = 0f;
	}

	// Token: 0x060008EA RID: 2282 RVA: 0x0000834C File Offset: 0x0000654C
	public bool IsInvincible()
	{
		return this.m_fInvincibleTimer > 0f || this.m_fInvincibleTimer == -1f;
	}

	// Token: 0x060008EB RID: 2283 RVA: 0x0003FEC4 File Offset: 0x0003E0C4
	public void Boost(float _speedUpMs, float _boostDelay, float _BoostAcceleration, bool bWithEffect)
	{
		KartArcadeGearBox kartArcadeGearBox = (KartArcadeGearBox)this.m_pGearBox;
		kartArcadeGearBox.Boost(_speedUpMs, _boostDelay, _BoostAcceleration, bWithEffect);
		this.KartSound.PlaySound(6);
	}

	// Token: 0x060008EC RID: 2284 RVA: 0x0003FEF4 File Offset: 0x0003E0F4
	public void ParfumeBoost(float _speedUpMs, float _boostDelay)
	{
		KartArcadeGearBox kartArcadeGearBox = (KartArcadeGearBox)this.m_pGearBox;
		kartArcadeGearBox.ParfumeBoost(_speedUpMs, _boostDelay);
	}

	// Token: 0x060008ED RID: 2285 RVA: 0x0003FF18 File Offset: 0x0003E118
	public void SlowDown(float _SlowedDownMaxSpeed, float _SlowedDownDelay, float _SlowedDownDownMs)
	{
		KartArcadeGearBox kartArcadeGearBox = (KartArcadeGearBox)this.m_pGearBox;
		kartArcadeGearBox.SlowDown(_SlowedDownMaxSpeed, _SlowedDownDelay, _SlowedDownDownMs);
	}

	// Token: 0x060008EE RID: 2286 RVA: 0x0000836E File Offset: 0x0000656E
	public bool SpringJump(float _JumpHeight, float _JumpForward, bool _Backward)
	{
		if (this.Jump(_JumpHeight, (!_Backward) ? _JumpForward : (-_JumpForward)))
		{
			if (this.OnSpringJump != null)
			{
				this.OnSpringJump();
			}
			return true;
		}
		return false;
	}

	// Token: 0x060008EF RID: 2287 RVA: 0x0003FF3C File Offset: 0x0003E13C
	public bool Jump(float _JumpHeight, float _JumpForward)
	{
		RcKinematicPhysic rcKinematicPhysic = (RcKinematicPhysic)this.m_pVehiclePhysic;
		if (_JumpForward < 0f || base.IsOnGround())
		{
			float num = (_JumpHeight != 0f) ? _JumpHeight : this.m_fJumpHeight;
			float num2 = rcKinematicPhysic.m_fAirAdditionnalGravity + Vector3.Dot(Physics.gravity, Vector3.down);
			float num3 = Mathf.Sqrt(2f * num * num2);
			float num4 = 2f * num3 / num2;
			Vector3 impulse = Vector3.up * num3 + this.Transform.forward * _JumpForward;
			rcKinematicPhysic.SwitchToInertiaMode(num4 * 0.5f, impulse, true, true);
			if (this.OnJump != null)
			{
				this.OnJump();
			}
			return true;
		}
		this.hasSpringActivated = true;
		this.tmpJumpHeight = _JumpHeight;
		this.tmpJumpForward = _JumpForward;
		return false;
	}

	// Token: 0x060008F0 RID: 2288 RVA: 0x00040020 File Offset: 0x0003E220
	public override void ComputeWheelSpeed()
	{
		KartArcadeGearBox kartArcadeGearBox = (KartArcadeGearBox)this.m_pGearBox;
		KartKinematicPhysic kartKinematicPhysic = (KartKinematicPhysic)this.m_pVehiclePhysic;
		kartKinematicPhysic.SetBoosting(kartArcadeGearBox.IsBoosting());
		kartKinematicPhysic.SetParfume(kartArcadeGearBox.IsParfume());
		base.ComputeWheelSpeed();
		if (kartArcadeGearBox.IsBoosting())
		{
			float deltaTime = Time.deltaTime;
			float maxSpeed = this.GetMaxSpeed();
			VehicleHandling vehicleHandling;
			this.m_pVehicleCarac.ComputeHandling(Mathf.Abs(this.m_fWheelSpeedMS * (1f - base.GetHandicap())), out vehicleHandling);
			this.m_fWheelSpeedMS += this.m_pGearBox.ComputeAcceleration(Mathf.Abs(this.m_fWheelSpeedMS)) * deltaTime;
			if (this.m_fWheelSpeedMS > maxSpeed)
			{
				this.m_fWheelSpeedMS = maxSpeed;
			}
		}
	}

	// Token: 0x060008F1 RID: 2289 RVA: 0x000400D8 File Offset: 0x0003E2D8
	public override void SetArcadeDriftFactor(float factor)
	{
		base.SetArcadeDriftFactor(factor);
		if (factor == 0f)
		{
			float action = Singleton<InputManager>.Instance.GetAction(EAction.Drift);
			if (action == 0f && this.m_fMiniBoost >= this.ThresholdMiniBoost)
			{
				this.LaunchMiniBoost();
			}
			this.m_fMiniBoost = 0f;
			this.m_bMiniboostThresholdOk = false;
			this.m_pKartFxMgr.BoostDrift(this.m_fMiniBoost, this.ThresholdMiniBoost);
		}
	}

	// Token: 0x060008F2 RID: 2290 RVA: 0x00040150 File Offset: 0x0003E350
	public float ComputeMiniBoostFillRate()
	{
		if (this.m_fArcadeDriftFactor == 0f || !base.IsOnGround())
		{
			this.FxMgr.StopDriftFx();
			return 0f;
		}
		if (Singleton<ChallengeManager>.Instance.IsActive && base.GetControlType() == RcVehicle.ControlType.Human && this.m_fArcadeDriftFactor != 0f)
		{
			Singleton<ChallengeManager>.Instance.Notify(EChallengeSingleRaceObjective.NoDrift);
		}
		if (this.m_fMiniBoost < this.ThresholdMiniBoost)
		{
			this.FxMgr.PlayKartFx(eKartFx.DriftLeft);
			this.FxMgr.PlayKartFx(eKartFx.DriftRight);
		}
		else
		{
			this.FxMgr.PlayKartFx(eKartFx.DriftLeft2);
			this.FxMgr.PlayKartFx(eKartFx.DriftRight2);
		}
		if (this.m_fArcadeDriftFactor * this.m_fSteeringFactor > 0f)
		{
			return RcUtils.LinearInterpolation(0f, this.m_fMiniBoostFillRateMed, 1f, this.m_fMiniBoostFillRateCounterSteer, Mathf.Abs(this.m_fArcadeDriftFactor * this.m_fSteeringFactor), true);
		}
		return RcUtils.LinearInterpolation(0f, this.m_fMiniBoostFillRateMed, 1f, this.m_fMiniBoostFillRateMaxDrift, Mathf.Abs(this.m_fArcadeDriftFactor * this.m_fSteeringFactor), true);
	}

	// Token: 0x060008F3 RID: 2291 RVA: 0x00040278 File Offset: 0x0003E478
	public void LaunchMiniBoost()
	{
		float num = this.SpeedUpMiniBoost;
		float num2 = this.DurationMiniBoost;
		float num3 = this.AccelerationMiniBoost;
		if (this.m_fMiniBoost < 100f)
		{
			float num4 = RcUtils.LinearInterpolation(this.ThresholdMiniBoost, this.PercentMiniBoostThreshold, 100f, 100f, this.m_fMiniBoost, true);
			num = num4 * num / 100f;
			num2 = num4 * num2 / 100f;
			num3 = num4 * num3 / 100f;
		}
		int num5 = Singleton<RandomManager>.Instance.Next(0, 4);
		if (num5 < 3)
		{
			this.KartSound.PlayVoice(KartSound.EVoices.Good);
		}
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
		{
			if (this.m_fMiniBoost < 100f)
			{
				(Singleton<GameManager>.Instance.GameMode as TutorialGameMode).BlueDrift();
			}
			else
			{
				(Singleton<GameManager>.Instance.GameMode as TutorialGameMode).RedDrift();
			}
		}
		this.Boost(num, num2, num3, true);
	}

	// Token: 0x060008F4 RID: 2292 RVA: 0x000083A3 File Offset: 0x000065A3
	public void StartRace()
	{
		if (this.m_pKartBonusMgr != null)
		{
			this.m_pKartBonusMgr.StartRace();
		}
	}

	// Token: 0x060008F5 RID: 2293 RVA: 0x000083C1 File Offset: 0x000065C1
	public void TakePuzzlePiece(int iIndex)
	{
		if (this.m_pHudPosition != null)
		{
			this.m_pHudPosition.TakePuzzlePiece(iIndex);
		}
	}

	// Token: 0x060008F6 RID: 2294 RVA: 0x000083E0 File Offset: 0x000065E0
	public bool HasNapEffect()
	{
		return this._napEffectTime > 0f;
	}

	// Token: 0x040008F8 RID: 2296
	public float DriftRatio = 0.5f;

	// Token: 0x040008F9 RID: 2297
	public float m_fJumpHeight = 0.5f;

	// Token: 0x040008FA RID: 2298
	private float m_fInvincibleTimer;

	// Token: 0x040008FB RID: 2299
	private KartAnim m_pKartAnim;

	// Token: 0x040008FC RID: 2300
	private KartBonusMgr m_pKartBonusMgr;

	// Token: 0x040008FD RID: 2301
	public int Index;

	// Token: 0x040008FE RID: 2302
	private HUDBonus m_pHudBonus;

	// Token: 0x040008FF RID: 2303
	private HUDPosition m_pHudPosition;

	// Token: 0x04000900 RID: 2304
	private float _napEffectTime;

	// Token: 0x04000901 RID: 2305
	private float _napEffectFactor;

	// Token: 0x04000902 RID: 2306
	private KartFxMgr m_pKartFxMgr;

	// Token: 0x04000903 RID: 2307
	private float m_fMiniBoost;

	// Token: 0x04000904 RID: 2308
	public float m_fMiniBoostFillRateCounterSteer = 20f;

	// Token: 0x04000905 RID: 2309
	public float m_fMiniBoostFillRateMed = 35f;

	// Token: 0x04000906 RID: 2310
	public float m_fMiniBoostFillRateMaxDrift = 50f;

	// Token: 0x04000907 RID: 2311
	public float ThresholdMiniBoost = 80f;

	// Token: 0x04000908 RID: 2312
	public float SpeedUpMiniBoost = 20f;

	// Token: 0x04000909 RID: 2313
	public float DurationMiniBoost = 1f;

	// Token: 0x0400090A RID: 2314
	public float AccelerationMiniBoost = 2f;

	// Token: 0x0400090B RID: 2315
	public float PercentMiniBoostThreshold = 60f;

	// Token: 0x0400090C RID: 2316
	private bool m_bMiniboostThresholdOk;

	// Token: 0x0400090D RID: 2317
	private KartSound m_pKartSound;

	// Token: 0x0400090E RID: 2318
	private EAdvantage m_eAdvantage;

	// Token: 0x0400090F RID: 2319
	private bool hasSpringActivated;

	// Token: 0x04000910 RID: 2320
	private float tmpJumpHeight;

	// Token: 0x04000911 RID: 2321
	private float tmpJumpForward;

	// Token: 0x04000912 RID: 2322
	public Action OnHit;

	// Token: 0x04000913 RID: 2323
	public Action<Kart> OnUfoCatchMe;

	// Token: 0x04000914 RID: 2324
	public float WrongWayTimer = 1.5f;

	// Token: 0x04000915 RID: 2325
	private float m_fWrongWayTimer;

	// Token: 0x04000916 RID: 2326
	private NetworkViewID m_oNetworkViewID = NetworkViewID.unassigned;

	// Token: 0x04000917 RID: 2327
	public float DraftMinimalSpeed = 30f;

	// Token: 0x04000918 RID: 2328
	public float DraftDistance = 5f;

	// Token: 0x04000919 RID: 2329
	public float DraftCapsuleRadius = 1f;

	// Token: 0x0400091A RID: 2330
	public float DraftTimer = 1.5f;

	// Token: 0x0400091B RID: 2331
	private float m_fDraftTimer;

	// Token: 0x0400091C RID: 2332
	private float m_fDeltaDraft;

	// Token: 0x0400091D RID: 2333
	private bool m_bIsFollowed;

	// Token: 0x0400091E RID: 2334
	private int m_iRaycastTurn;

	// Token: 0x0400091F RID: 2335
	private Kart m_oDraftingKart;

	// Token: 0x04000920 RID: 2336
	public Action<Kart> OnBeSwaped;

	// Token: 0x04000921 RID: 2337
	public Action OnBoost;

	// Token: 0x04000922 RID: 2338
	public Action OnJump;

	// Token: 0x04000923 RID: 2339
	public Action OnSpringJump;
}

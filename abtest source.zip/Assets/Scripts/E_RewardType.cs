﻿using System;

// Token: 0x02000155 RID: 341
public enum E_RewardType
{
	// Token: 0x040009B9 RID: 2489
	Kart,
	// Token: 0x040009BA RID: 2490
	Custom,
	// Token: 0x040009BB RID: 2491
	Hat
}

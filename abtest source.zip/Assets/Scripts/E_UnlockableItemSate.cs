﻿using System;

// Token: 0x0200012E RID: 302
public enum E_UnlockableItemSate
{
	// Token: 0x04000879 RID: 2169
	Hidden,
	// Token: 0x0400087A RID: 2170
	NewLocked,
	// Token: 0x0400087B RID: 2171
	Locked,
	// Token: 0x0400087C RID: 2172
	NewUnlocked,
	// Token: 0x0400087D RID: 2173
	Unlocked
}

﻿using System;

// Token: 0x020001F9 RID: 505
public class RcVirtualController : RcController
{
	// Token: 0x06000DA3 RID: 3491 RVA: 0x0000B586 File Offset: 0x00009786
	public RcVirtualController()
	{
		this.m_fSpeedBehaviour = 0f;
		this.m_fWantedSteer = 0f;
	}

	// Token: 0x06000DA4 RID: 3492 RVA: 0x0000B5A4 File Offset: 0x000097A4
	public override float GetSteer()
	{
		return this.m_fWantedSteer;
	}

	// Token: 0x06000DA5 RID: 3493 RVA: 0x0000B5AC File Offset: 0x000097AC
	public override float GetSpeedBehaviour()
	{
		return this.m_fSpeedBehaviour;
	}

	// Token: 0x06000DA6 RID: 3494 RVA: 0x0000B5B4 File Offset: 0x000097B4
	public void setDriveParameters(float _wantedSteer, float _speedBehaviour)
	{
		this.m_fSpeedBehaviour = _speedBehaviour;
		this.m_fWantedSteer = _wantedSteer;
	}

	// Token: 0x06000DA7 RID: 3495 RVA: 0x00058C6C File Offset: 0x00056E6C
	public void Update()
	{
		if (!base.GetVehicle().IsAutoPilot() || base.GetVehicle().GetControlType() == RcVehicle.ControlType.Net)
		{
			return;
		}
		if (this.m_bDrivingEnabled)
		{
			this.Turn();
			if (this.m_fSpeedBehaviour >= 1f)
			{
				base.GetVehicle().Accelerate();
			}
			else if (this.m_fSpeedBehaviour < 0f)
			{
				base.GetVehicle().Brake();
			}
			else
			{
				base.GetVehicle().Decelerate();
			}
			base.GetVehicle().SetDrift(0f);
		}
	}

	// Token: 0x06000DA8 RID: 3496 RVA: 0x0000B5C4 File Offset: 0x000097C4
	public virtual void Turn()
	{
		base.GetVehicle().Turn(this.m_fWantedSteer, false);
	}

	// Token: 0x06000DA9 RID: 3497 RVA: 0x0000B5D8 File Offset: 0x000097D8
	public override void Reset()
	{
		this.m_fSpeedBehaviour = 0f;
		this.m_fWantedSteer = 0f;
	}

	// Token: 0x06000DAA RID: 3498 RVA: 0x0000B5F0 File Offset: 0x000097F0
	public override void SetDrivingEnabled(bool _enabled)
	{
		base.SetDrivingEnabled(_enabled);
		if (base.GetVehicle())
		{
			base.GetVehicle().SetAutoPilot(_enabled);
		}
	}

	// Token: 0x04000D4E RID: 3406
	protected float m_fSpeedBehaviour;

	// Token: 0x04000D4F RID: 3407
	protected float m_fWantedSteer;

	// Token: 0x04000D50 RID: 3408
	public int AIIndex;
}

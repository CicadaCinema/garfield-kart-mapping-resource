﻿using System;
using UnityEngine;

// Token: 0x020001C3 RID: 451
public class TrackSelectionButton : MonoBehaviour
{
	// Token: 0x06000C10 RID: 3088 RVA: 0x0005201C File Offset: 0x0005021C
	private void OnClick()
	{
		if (this.TrackToLaunch.Equals("MenuRoot"))
		{
			LoadingManager.LoadLevel("MenuRoot");
		}
		else
		{
			Singleton<GameConfigurator>.Instance.StartScene = this.TrackToLaunch;
			Singleton<GameConfigurator>.Instance.GameModeType = this.GameModeType;
			UnityEngine.Object.Destroy(GameObject.Find("MenuEntryPoint"));
			LoadingManager.LoadLevel(Singleton<GameConfigurator>.Instance.StartScene);
		}
	}

	// Token: 0x04000BED RID: 3053
	public string TrackToLaunch;

	// Token: 0x04000BEE RID: 3054
	public E_GameModeType GameModeType;
}

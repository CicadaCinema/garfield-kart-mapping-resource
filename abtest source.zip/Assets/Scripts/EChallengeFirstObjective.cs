﻿using System;

// Token: 0x020000A9 RID: 169
public enum EChallengeFirstObjective
{
	// Token: 0x040003F2 RID: 1010
	FinishBeforeX,
	// Token: 0x040003F3 RID: 1011
	FinishAtPosX
}

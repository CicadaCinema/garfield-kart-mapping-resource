﻿using System;

// Token: 0x0200009F RID: 159
public enum E_FastValuePathMask
{
	// Token: 0x040003A2 RID: 930
	NO_RESPAWN = 1,
	// Token: 0x040003A3 RID: 931
	NO_UFO
}

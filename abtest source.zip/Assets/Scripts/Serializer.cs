﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

// Token: 0x02000242 RID: 578
public class Serializer
{
	// Token: 0x06001022 RID: 4130 RVA: 0x0000CDFB File Offset: 0x0000AFFB
	public static void Serialize<T>(string pPath, T pObject)
	{
		Serializer.BinarySerialize<T>(pPath, pObject);
	}

	// Token: 0x06001023 RID: 4131 RVA: 0x0000CE04 File Offset: 0x0000B004
	public static T Deserialize<T>(string pPath)
	{
		return Serializer.BinaryDeserialize<T>(pPath);
	}

	// Token: 0x06001024 RID: 4132 RVA: 0x00065D4C File Offset: 0x00063F4C
	public static void BinarySerialize<T>(string pPath, T pObject)
	{
		Stream stream = null;
		try
		{
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			stream = File.OpenWrite(pPath);
			binaryFormatter.Serialize(stream, pObject);
		}
		catch (Exception ex)
		{
		}
		finally
		{
			if (stream != null)
			{
				stream.Close();
			}
		}
	}

	// Token: 0x06001025 RID: 4133 RVA: 0x00065DAC File Offset: 0x00063FAC
	public static T BinaryDeserialize<T>(string pPath)
	{
		Stream stream = null;
		T result = default(T);
		try
		{
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			stream = File.OpenRead(pPath);
			result = (T)((object)binaryFormatter.Deserialize(stream));
		}
		catch (Exception ex)
		{
		}
		finally
		{
			if (stream != null)
			{
				stream.Close();
			}
		}
		return result;
	}

	// Token: 0x06001026 RID: 4134 RVA: 0x00065E18 File Offset: 0x00064018
	public static void XMLSerialize<T>(string pPath, T pObject, Type[] pIncludeTypes)
	{
		Stream stream = null;
		try
		{
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(T), pIncludeTypes);
			stream = File.Open(pPath, FileMode.Create);
			xmlSerializer.Serialize(stream, pObject);
		}
		catch (Exception ex)
		{
		}
		finally
		{
			if (stream != null)
			{
				stream.Close();
			}
		}
	}

	// Token: 0x06001027 RID: 4135 RVA: 0x00065E84 File Offset: 0x00064084
	public static T XMLDeserialize<T>(string pPath, Type[] pIncludeTypes)
	{
		Stream stream = null;
		T result = default(T);
		try
		{
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(T), pIncludeTypes);
			stream = File.OpenRead(pPath);
			result = (T)((object)xmlSerializer.Deserialize(stream));
		}
		catch (Exception ex)
		{
		}
		finally
		{
			if (stream != null)
			{
				stream.Close();
			}
		}
		return result;
	}
}

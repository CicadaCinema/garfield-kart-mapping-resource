﻿using System;

// Token: 0x0200017B RID: 379
public class ChampionShipScoreData : RaceScoreData
{
	// Token: 0x06000A1E RID: 2590 RVA: 0x00008E23 File Offset: 0x00007023
	public ChampionShipScoreData(int pKartIndex, bool pIsAI) : base(pKartIndex, pIsAI)
	{
		this._championshipScore = 0;
		this._previousChampionshipPosition = 0;
		this._championshipPosition = 0;
		this._previousChampionshipPositionForReset = 0;
	}

	// Token: 0x17000164 RID: 356
	// (get) Token: 0x06000A1F RID: 2591 RVA: 0x00008E49 File Offset: 0x00007049
	public int ChampionshipScore
	{
		get
		{
			return this._championshipScore;
		}
	}

	// Token: 0x17000165 RID: 357
	// (get) Token: 0x06000A20 RID: 2592 RVA: 0x00008E51 File Offset: 0x00007051
	// (set) Token: 0x06000A21 RID: 2593 RVA: 0x00008E59 File Offset: 0x00007059
	public int ChampionshipPosition
	{
		get
		{
			return this._championshipPosition;
		}
		set
		{
			this._championshipPosition = value;
		}
	}

	// Token: 0x17000166 RID: 358
	// (get) Token: 0x06000A23 RID: 2595 RVA: 0x00008E6B File Offset: 0x0000706B
	// (set) Token: 0x06000A22 RID: 2594 RVA: 0x00008E62 File Offset: 0x00007062
	public int PreviousChampionshipScore
	{
		get
		{
			return this._previousChampionshipScore;
		}
		set
		{
			this._previousChampionshipScore = value;
		}
	}

	// Token: 0x06000A24 RID: 2596 RVA: 0x00008E73 File Offset: 0x00007073
	public override void RestartRace()
	{
		base.RestartRace();
		this._championshipScore = this._previousChampionshipScore;
		this._championshipPosition = this._previousChampionshipPosition;
		this._previousChampionshipPosition = this._previousChampionshipPositionForReset;
	}

	// Token: 0x06000A25 RID: 2597 RVA: 0x00008E9F File Offset: 0x0000709F
	public override bool SetRaceScore(int iScore)
	{
		if (base.SetRaceScore(iScore))
		{
			this.PreviousChampionshipScore = this._championshipScore;
			this._championshipScore += iScore;
			return true;
		}
		return false;
	}

	// Token: 0x06000A26 RID: 2598 RVA: 0x00008ECA File Offset: 0x000070CA
	public void SetChampionShipPosition(int pPosition)
	{
		this._previousChampionshipPositionForReset = this._previousChampionshipPosition;
		this._previousChampionshipPosition = this._championshipPosition;
		this._championshipPosition = pPosition;
	}

	// Token: 0x04000A22 RID: 2594
	private int _championshipScore;

	// Token: 0x04000A23 RID: 2595
	private int _previousChampionshipPosition;

	// Token: 0x04000A24 RID: 2596
	private int _previousChampionshipPositionForReset;

	// Token: 0x04000A25 RID: 2597
	private int _championshipPosition;

	// Token: 0x04000A26 RID: 2598
	private int _previousChampionshipScore;
}

﻿using System;

// Token: 0x020001DA RID: 474
public class ForecastResult
{
	// Token: 0x06000CC0 RID: 3264 RVA: 0x0000AD09 File Offset: 0x00008F09
	public void Refresh()
	{
		this.Direction = 0f;
		this.Weight = 0f;
	}

	// Token: 0x04000C66 RID: 3174
	public float Direction;

	// Token: 0x04000C67 RID: 3175
	public float Weight;
}

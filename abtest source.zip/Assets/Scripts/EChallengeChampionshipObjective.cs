﻿using System;

// Token: 0x020000AB RID: 171
public enum EChallengeChampionshipObjective
{
	// Token: 0x040003FA RID: 1018
	EarnXCoins,
	// Token: 0x040003FB RID: 1019
	FinishAllAtPosX
}

﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020001A0 RID: 416
public class MenuMultiWaitingRoom : AbstractMenu
{
    
	// Token: 0x06000B3C RID: 2876 RVA: 0x00009CD8 File Offset: 0x00007ED8
	public override void Awake()
	{
		base.Awake();
		this.networkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
		this.m_bRefreshPanel = false;
	}

	// Token: 0x06000B3D RID: 2877 RVA: 0x0004BE54 File Offset: 0x0004A054
	public void Init(EMenus eFromMenu, int iSessionId, string sServerName, int iGameType)
	{
		this.m_bInitCalled = true;
		this.networkMgr.ServerName = sServerName;
		this.m_oPlayerList.Clear();
		this.m_oPlayerColor.Clear();
		this.m_eFromMenu = eFromMenu;
		if (this.m_oGameTypeIcon)
		{
			this.m_oGameTypeIcon.ChangeTexture(iGameType);
		}
		if (this.m_oNextButton)
		{
			this.m_oNextButton.SetActive(false);
		}
		if (this.ServerName)
		{
			this.ServerName.text = sServerName;
		}
		int num = 0;
		foreach (KeyValuePair<NetworkPlayer, Color> keyValuePair in this.networkMgr.PlayersColor)
		{
			this.m_oPlayerColor.Add(num, keyValuePair.Value);
			num++;
		}
		num = 0;
		foreach (KeyValuePair<NetworkPlayer, string> keyValuePair2 in this.networkMgr.PeerNames)
		{
			this.AddPlayer(num, keyValuePair2.Value);
			num++;
		}
		this.m_iLastNbPeers = num;
		if (Network.isServer)
		{
			this.IconType.ChangeTexture(1);
		}
		else
		{
			this.IconType.ChangeTexture(0);
		}
        
    }

	// Token: 0x06000B3E RID: 2878 RVA: 0x0004BFD8 File Offset: 0x0004A1D8
	public override void Update()
	{
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			this.OnBackButton();
		}
		if (this.networkMgr.PeerNames.Count != this.m_oPlayerList.Count)
		{
			this.UpdatePlayers();
		}
	}

	// Token: 0x06000B3F RID: 2879 RVA: 0x00009D01 File Offset: 0x00007F01
	public void AddPlayer(int iPlayerId, string sPlayerName)
	{
		this.m_oPlayerList.Add(iPlayerId, sPlayerName);
		this.UpdatePlayers();
	}

	// Token: 0x06000B40 RID: 2880 RVA: 0x00009D16 File Offset: 0x00007F16
	public void RemovePlayer(int iPlayerId)
	{
		this.m_oPlayerList.Remove(iPlayerId);
		this.UpdatePlayers();
	}

	// Token: 0x06000B41 RID: 2881 RVA: 0x00009D2B File Offset: 0x00007F2B
	public void OnPlayerConnected(NetworkPlayer player)
	{
		this.PlayerConnectedSound.Play();
	}

	// Token: 0x06000B42 RID: 2882 RVA: 0x00009D38 File Offset: 0x00007F38
	public void OnPlayerDisconnected(NetworkPlayer player)
	{
		this.PlayerDisconnectedSound.Play();
	}

	// Token: 0x06000B43 RID: 2883 RVA: 0x0004C02C File Offset: 0x0004A22C
	private void UpdatePlayers()
	{
		if (this.networkMgr.PlayersColor.Count != this.networkMgr.PeerNames.Count)
		{
			return;
		}
		int i = 0;
		this.m_oPlayerList.Clear();
		this.m_oPlayerColor.Clear();
		int num = 0;
		foreach (KeyValuePair<NetworkPlayer, Color> keyValuePair in this.networkMgr.PlayersColor)
		{
			this.m_oPlayerColor.Add(num, keyValuePair.Value);
			num++;
		}
		num = 0;
		foreach (KeyValuePair<NetworkPlayer, string> keyValuePair2 in this.networkMgr.PeerNames)
		{
			this.m_oPlayerList.Add(num, keyValuePair2.Value);
			num++;
		}
		if (this.m_iLastNbPeers != num)
		{
			this.m_iLastNbPeers = num;
			if (this.m_iLastNbPeers < 2)
			{
				this.m_oNextButton.SetActive(false);
			}
			else
			{
				this.m_oNextButton.SetActive(Network.isServer);
			}
		}
		foreach (KeyValuePair<int, string> keyValuePair3 in this.m_oPlayerList)
		{
			if (this.m_oPlayerLabel[i])
			{
				this.m_oPlayerLabel[i].text = keyValuePair3.Value;
			}
			if (this.PlayerBackground[i])
			{
				this.PlayerBackground[i].color = this.m_oPlayerColor[i];
				this.PlayerBackground[i].gameObject.SetActive(true);
			}
			i++;
		}
		while (i < 6)
		{
			if (this.m_oPlayerLabel[i])
			{
				this.m_oPlayerLabel[i].text = string.Empty;
			}
			if (this.PlayerBackground[i])
			{
				this.PlayerBackground[i].gameObject.SetActive(false);
			}
			i++;
		}
		if (this.m_oNbPlayersLabel)
		{
			this.m_oNbPlayersLabel.text = string.Format("{0} / 6 ", this.networkMgr.NbPeers) + Localization.instance.Get("MENU_PLAYERS");
		}
	}

	// Token: 0x06000B44 RID: 2884 RVA: 0x0004C2E4 File Offset: 0x0004A4E4
	public override void OnEnter()
	{
		base.OnEnter();
		if (this.SelectingTrackLabel != null)
		{
			this.SelectingTrackLabel.SetActive(false);
		}
		for (int i = 1; i < this.PlayerBackground.Count; i++)
		{
			this.PlayerBackground[i].gameObject.SetActive(false);
		}
		this.PlayerBackground[0].color = Singleton<GameConfigurator>.Instance.PlayerConfig.PlayerColor;
		this.PlayerBackground[0].gameObject.SetActive(true);
		if (!this.m_bInitCalled && !Network.isServer)
		{
			this.ServerName.text = this.networkMgr.ServerName;
			this.NotifySelectingTrack();
		}
	}

	// Token: 0x06000B45 RID: 2885 RVA: 0x00009D45 File Offset: 0x00007F45
	public override void OnExit()
	{
		base.OnExit();
		this.m_oPlayerList.Clear();
		this.m_bInitCalled = false;
	}

	// Token: 0x06000B46 RID: 2886 RVA: 0x00009D5F File Offset: 0x00007F5F
	public void OnBackButton()
	{
		this.ActSwapMenu(this.m_eFromMenu);
		Network.Disconnect();
	}

	// Token: 0x06000B47 RID: 2887 RVA: 0x0004C3B0 File Offset: 0x0004A5B0
	public void OnNextButton()
	{
		this.networkMgr.networkView.RPC("AssignPlayerColor", RPCMode.All, new object[0]);
		this.ActSwapMenu(EMenus.MENU_CHAMPIONSHIP);
		if (Network.isServer)
		{
			Network.maxConnections = 0;
			for (int i = this.networkMgr.maxPlayers; i < Network.connections.Length; i++)
			{
				Network.CloseConnection(Network.connections[i], true);
			}
		}
		this.networkMgr.networkView.RPC("NotifySelectingTrack", RPCMode.Others, new object[0]);
		MasterServer.RegisterHost("GK12", "GK12", string.Concat(new string[]
		{
			"Championship,",
			(!this.networkMgr.BLanOnly) ? "WAN," : "LAN,",
			this.networkMgr.SGameName,
			",",
			Network.player.externalIP,
			",startGame"
		}));
	}

	// Token: 0x06000B48 RID: 2888 RVA: 0x00009D72 File Offset: 0x00007F72
	public void NotifySelectingTrack()
	{
		if (this.SelectingTrackLabel != null)
		{
			this.SelectingTrackLabel.SetActive(true);
		}
	}

	// Token: 0x06000B49 RID: 2889 RVA: 0x00009D91 File Offset: 0x00007F91
	public void OnDisconnectedFromServer()
	{
		if (Network.isClient)
		{
			this.OnBackButton();
		}
	}

	// Token: 0x06000B4A RID: 2890 RVA: 0x0004B2B4 File Offset: 0x000494B4
	public void OnFailedToConnectToMasterServer(NetworkConnectionError Error)
	{
		this.ActSwapMenu(EMenus.MENU_SOLO);
		PopupDialog popupDialog = (PopupDialog)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG, false);
		if (popupDialog)
		{
			popupDialog.Show("MENU_POPUP_MASTER_CONNECTION_ERROR");
		}
		Network.Disconnect();
	}

	// Token: 0x04000B08 RID: 2824
	private EMenus m_eFromMenu;

	// Token: 0x04000B09 RID: 2825
	private Dictionary<int, string> m_oPlayerList = new Dictionary<int, string>();

	// Token: 0x04000B0A RID: 2826
	private Dictionary<int, Color> m_oPlayerColor = new Dictionary<int, Color>();

	// Token: 0x04000B0B RID: 2827
	public UILabel[] m_oPlayerLabel = new UILabel[6];

	// Token: 0x04000B0C RID: 2828
	public UITexturePattern m_oGameTypeIcon;

	// Token: 0x04000B0D RID: 2829
	public UILabel m_oNbPlayersLabel;

	// Token: 0x04000B0E RID: 2830
	public GameObject m_oNextButton;

	// Token: 0x04000B0F RID: 2831
	private NetworkMgr networkMgr;

	// Token: 0x04000B10 RID: 2832
	public UILabel ServerName;

	// Token: 0x04000B11 RID: 2833
	public AudioSource PlayerConnectedSound;

	// Token: 0x04000B12 RID: 2834
	public AudioSource PlayerDisconnectedSound;

	// Token: 0x04000B13 RID: 2835
	private int m_iLastNbPeers;

	// Token: 0x04000B14 RID: 2836
	public UITexturePattern IconType;

	// Token: 0x04000B15 RID: 2837
	public List<UISlicedSprite> PlayerBackground;

	// Token: 0x04000B16 RID: 2838
	public GameObject SelectingTrackLabel;

	// Token: 0x04000B17 RID: 2839
	private bool m_bRefreshPanel;

	// Token: 0x04000B18 RID: 2840
	private bool m_bInitCalled;
}

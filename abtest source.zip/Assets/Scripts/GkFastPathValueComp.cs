﻿using System;
using UnityEngine;

// Token: 0x020000A0 RID: 160
public class GkFastPathValueComp : RcFastValuePathComp
{
	// Token: 0x040003A4 RID: 932
	public GameObject Path;

	// Token: 0x040003A5 RID: 933
	public bool UseBonus;

	// Token: 0x040003A6 RID: 934
	public bool ChangePath;

	// Token: 0x040003A7 RID: 935
	public bool ChangePathIfNoCondition;

	// Token: 0x040003A8 RID: 936
	public bool Behind;
}

﻿using System;
using UnityEngine;

// Token: 0x020000C8 RID: 200
public class TrackList : MonoBehaviour
{
	// Token: 0x04000511 RID: 1297
	public string[] Tracks = new string[16];
}

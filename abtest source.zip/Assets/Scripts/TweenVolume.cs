﻿using System;
using UnityEngine;

// Token: 0x02000062 RID: 98
[AddComponentMenu("NGUI/Tween/Volume")]
public class TweenVolume : UITweener
{
	// Token: 0x1700005F RID: 95
	// (get) Token: 0x06000288 RID: 648 RVA: 0x00018990 File Offset: 0x00016B90
	public AudioSource audioSource
	{
		get
		{
			if (this.mSource == null)
			{
				this.mSource = base.audio;
				if (this.mSource == null)
				{
					this.mSource = base.GetComponentInChildren<AudioSource>();
					if (this.mSource == null)
					{
						Debug.LogError("TweenVolume needs an AudioSource to work with", this);
						base.enabled = false;
					}
				}
			}
			return this.mSource;
		}
	}

	// Token: 0x17000060 RID: 96
	// (get) Token: 0x06000289 RID: 649 RVA: 0x00003EE8 File Offset: 0x000020E8
	// (set) Token: 0x0600028A RID: 650 RVA: 0x00003EF5 File Offset: 0x000020F5
	public float volume
	{
		get
		{
			return this.audioSource.volume;
		}
		set
		{
			this.audioSource.volume = value;
		}
	}

	// Token: 0x0600028B RID: 651 RVA: 0x00003F03 File Offset: 0x00002103
	protected override void OnUpdate(float factor, bool isFinished)
	{
		this.volume = this.from * (1f - factor) + this.to * factor;
		this.mSource.enabled = (this.mSource.volume > 0.01f);
	}

	// Token: 0x0600028C RID: 652 RVA: 0x00018A00 File Offset: 0x00016C00
	public static TweenVolume Begin(GameObject go, float duration, float targetVolume)
	{
		TweenVolume tweenVolume = UITweener.Begin<TweenVolume>(go, duration);
		tweenVolume.from = tweenVolume.volume;
		tweenVolume.to = targetVolume;
		if (duration <= 0f)
		{
			tweenVolume.Sample(1f, true);
			tweenVolume.enabled = false;
		}
		return tweenVolume;
	}

	// Token: 0x04000207 RID: 519
	public float from;

	// Token: 0x04000208 RID: 520
	public float to = 1f;

	// Token: 0x04000209 RID: 521
	private AudioSource mSource;
}

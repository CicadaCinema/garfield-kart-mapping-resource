﻿using System;
using UnityEngine;

// Token: 0x020001DE RID: 478
public class ForecastedAttractive : Forecasted
{
	// Token: 0x06000CE2 RID: 3298 RVA: 0x0000AE23 File Offset: 0x00009023
	public ForecastedAttractive()
	{
	}

	// Token: 0x06000CE3 RID: 3299 RVA: 0x0000AE2B File Offset: 0x0000902B
	public ForecastedAttractive(MonoBehaviour pEntity) : base(pEntity)
	{
	}

	// Token: 0x06000CE4 RID: 3300 RVA: 0x00004C05 File Offset: 0x00002E05
	public override bool IsAttractiveFor(ForecastClient pClient)
	{
		return true;
	}
}

﻿using System;

// Token: 0x02000144 RID: 324
public enum eKartFx
{
	// Token: 0x04000947 RID: 2375
	BoostLeft,
	// Token: 0x04000948 RID: 2376
	DriftLeft,
	// Token: 0x04000949 RID: 2377
	DriftRight,
	// Token: 0x0400094A RID: 2378
	DriftLeft2,
	// Token: 0x0400094B RID: 2379
	DriftRight2,
	// Token: 0x0400094C RID: 2380
	Impact,
	// Token: 0x0400094D RID: 2381
	Jump,
	// Token: 0x0400094E RID: 2382
	Dive,
	// Token: 0x0400094F RID: 2383
	BoostRight,
	// Token: 0x04000950 RID: 2384
	BadParfume
}

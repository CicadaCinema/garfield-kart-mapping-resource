﻿using System;
using UnityEngine;

// Token: 0x02000005 RID: 5
[AddComponentMenu("NGUI/Interaction/Button Activate")]
public class UIButtonActivate : MonoBehaviour
{
	// Token: 0x06000010 RID: 16 RVA: 0x000021B7 File Offset: 0x000003B7
	private void OnClick()
	{
		if (this.target != null)
		{
			NGUITools.SetActive(this.target, this.state);
		}
	}

	// Token: 0x04000004 RID: 4
	public GameObject target;

	// Token: 0x04000005 RID: 5
	public bool state = true;
}

﻿using System;
using UnityEngine;

// Token: 0x020000EB RID: 235
public class SpinBonusEffect : BonusEffect
{
	// Token: 0x06000661 RID: 1633 RVA: 0x00006898 File Offset: 0x00004A98
	public SpinBonusEffect()
	{
		this.m_iAnimParameter = Animator.StringToHash("Slide");
		this.m_iAnimState = Animator.StringToHash("Base Layer.Slide");
	}

	// Token: 0x06000662 RID: 1634 RVA: 0x00006342 File Offset: 0x00004542
	public override void Start()
	{
		this.m_bStoppedByAnim = false;
		base.Start();
	}

	// Token: 0x06000663 RID: 1635 RVA: 0x0000600B File Offset: 0x0000420B
	public override void Update()
	{
		base.Update();
	}

	// Token: 0x06000664 RID: 1636 RVA: 0x00031E84 File Offset: 0x00030084
	public override bool Activate()
	{
		if (this.Activated || this.m_pBonusEffectMgr.GetBonusEffect(EBonusEffect.BONUSEFFECT_UPSIDE_DOWN).Activated || this.m_pBonusEffectMgr.GetBonusEffect(EBonusEffect.BONUSEFFECT_LEVITATE).Activated || this.m_pBonusEffectMgr.GetBonusEffect(EBonusEffect.BONUSEFFECT_JUMP).Activated)
		{
			return false;
		}
		base.Activate();
		Kart target = this.m_pBonusEffectMgr.Target;
		target.CancelDrift();
		target.KartSound.PlaySound(12);
		target.KartSound.PlayVoice(KartSound.EVoices.Bad);
		if (SpinBonusEffect.OnLaunch != null)
		{
			SpinBonusEffect.OnLaunch(target.Index);
		}
		return true;
	}

	// Token: 0x04000646 RID: 1606
	public static Action<int> OnLaunch;
}

﻿using System;

// Token: 0x0200024D RID: 589
public enum eOrientationMode
{
	// Token: 0x04000F9B RID: 3995
	NODE,
	// Token: 0x04000F9C RID: 3996
	TANGENT
}

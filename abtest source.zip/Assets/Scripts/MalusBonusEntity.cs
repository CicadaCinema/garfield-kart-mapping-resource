﻿using System;
using UnityEngine;

// Token: 0x020000DF RID: 223
public class MalusBonusEntity : BonusEntity
{
	// Token: 0x060005FC RID: 1532 RVA: 0x000063B7 File Offset: 0x000045B7
	public MalusBonusEntity()
	{
		this.ReactivationDelay = 0f;
		this.m_bBehind = false;
	}

	// Token: 0x060005FD RID: 1533 RVA: 0x000301C4 File Offset: 0x0002E3C4
	public override void Awake()
	{
		base.Awake();
		this.m_iLayerVehicle = 1 << LayerMask.NameToLayer("Vehicle");
		this.m_iLayerBonus = 1 << LayerMask.NameToLayer("Bonus");
		this.m_pLayerBonus = LayerMask.NameToLayer("Bonus");
		this.m_pLayerIgnoreRaycast = LayerMask.NameToLayer("Ignore Raycast");
		base.ActivateGameObject(false);
	}

	// Token: 0x060005FE RID: 1534 RVA: 0x00030234 File Offset: 0x0002E434
	public override void Update()
	{
		base.Update();
		if (this.m_eState == BonusEntity.BonusState.BONUS_LAUNCHREQUEST)
		{
			this.SetActive(true);
			this.m_eState = BonusEntity.BonusState.BONUS_LAUNCHED;
		}
		else if (this.m_eState == BonusEntity.BonusState.BONUS_LAUNCHED)
		{
			if (this.m_bBehind)
			{
				this.LaunchAnimFinished();
				this.m_eState = BonusEntity.BonusState.BONUS_ANIMLAUNCHED;
			}
		}
		else if (this.m_eState == BonusEntity.BonusState.BONUS_ANIMLAUNCHED && this.m_bBehind && this.IsOnGround())
		{
			this.m_eState = BonusEntity.BonusState.BONUS_ONGROUND;
		}
	}

	// Token: 0x060005FF RID: 1535 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void LaunchAnimFinished()
	{
	}

	// Token: 0x06000600 RID: 1536 RVA: 0x000063D1 File Offset: 0x000045D1
	public override void OnEnable()
	{
		base.OnEnable();
	}

	// Token: 0x06000601 RID: 1537 RVA: 0x000302B8 File Offset: 0x0002E4B8
	public virtual void OnCollisionEnter(Collision collision)
	{
		if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
		{
			int num = 1 << collision.gameObject.layer;
			if (((num & this.m_iLayerVehicle) != 0 || (num & this.m_iLayerBonus) != 0) && collision.gameObject != null)
			{
				this.OnTriggerEnter(collision.collider);
			}
		}
	}

	// Token: 0x06000602 RID: 1538 RVA: 0x000063D9 File Offset: 0x000045D9
	public override void DoOnTriggerEnter(GameObject other, int otherlayer)
	{
		base.DoOnTriggerEnter(other, otherlayer);
		this.PerformBonusReaction(other, otherlayer);
	}

	// Token: 0x06000603 RID: 1539 RVA: 0x00030324 File Offset: 0x0002E524
	public void PerformBonusReaction(GameObject other, int otherlayer)
	{
		int num = 1 << otherlayer;
		if ((num & this.m_iLayerVehicle) != 0)
		{
			if (other != null)
			{
				Kart componentInChildren = other.GetComponentInChildren<Kart>();
				if (this.m_eState >= BonusEntity.BonusState.BONUS_LAUNCHED)
				{
					if (componentInChildren != null)
					{
						this.m_eImpactDirection = this.CheckImpactDirection(other);
						this.m_eState = BonusEntity.BonusState.BONUS_TRIGGERED;
						ParfumeBonusEffect parfumeBonusEffect = (ParfumeBonusEffect)componentInChildren.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_ATTRACTED);
						if (!parfumeBonusEffect.Activated || parfumeBonusEffect.StinkParfume)
						{
							this.ActivateBonusEffect(componentInChildren);
						}
					}
					base.NetDestroy();
				}
			}
		}
		else if ((num & this.m_iLayerBonus) != 0 && other != null)
		{
			BonusEntity componentInChildren2 = other.GetComponentInChildren<BonusEntity>();
			if (this.m_eState >= BonusEntity.BonusState.BONUS_LAUNCHED)
			{
				this.PerformBonusCollision(componentInChildren2);
			}
		}
	}

	// Token: 0x06000604 RID: 1540 RVA: 0x000063EB File Offset: 0x000045EB
	public virtual void PerformBonusCollision(BonusEntity _Bonus)
	{
		if (_Bonus != null)
		{
			this.m_eState = BonusEntity.BonusState.BONUS_TRIGGERED;
			_Bonus.NetDestroy();
		}
		base.NetDestroy();
	}

	// Token: 0x06000605 RID: 1541 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void ActivateBonusEffect(Kart _Kart)
	{
	}

	// Token: 0x06000606 RID: 1542 RVA: 0x0000640C File Offset: 0x0000460C
	public override void SetActive(bool _Active)
	{
		base.SetActive(_Active);
	}

	// Token: 0x06000607 RID: 1543 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void OnDestroy()
	{
	}

	// Token: 0x06000608 RID: 1544 RVA: 0x00006415 File Offset: 0x00004615
	public override void DoDestroy()
	{
		base.DoDestroy();
		this.SetActive(false);
		base.ActivateGameObject(false);
	}

	// Token: 0x06000609 RID: 1545 RVA: 0x0000642B File Offset: 0x0000462B
	public override void Launch()
	{
		base.Launch();
		base.ActivateGameObject(true);
	}

	// Token: 0x0600060A RID: 1546 RVA: 0x00003B7D File Offset: 0x00001D7D
	public virtual bool IsOnGround()
	{
		return false;
	}

	// Token: 0x0600060B RID: 1547 RVA: 0x000303F8 File Offset: 0x0002E5F8
	public EBonusEffectDirection CheckImpactDirection(GameObject _object)
	{
		Vector3 vector = _object.transform.InverseTransformPoint(this.m_pTransform.position);
		if (vector.z > 0f)
		{
			if (vector.z > Mathf.Abs(vector.x))
			{
				return EBonusEffectDirection.FRONT;
			}
			if (vector.x > 0f)
			{
				return EBonusEffectDirection.RIGHT;
			}
			return EBonusEffectDirection.LEFT;
		}
		else
		{
			if (vector.z < Mathf.Abs(vector.x))
			{
				return EBonusEffectDirection.BACK;
			}
			if (vector.x > 0f)
			{
				return EBonusEffectDirection.RIGHT;
			}
			return EBonusEffectDirection.LEFT;
		}
	}

	// Token: 0x040005FD RID: 1533
	protected int m_iLayerVehicle;

	// Token: 0x040005FE RID: 1534
	protected int m_iLayerBonus;

	// Token: 0x040005FF RID: 1535
	public LayerMask LayerStick;

	// Token: 0x04000600 RID: 1536
	protected LayerMask m_pLayerBonus;

	// Token: 0x04000601 RID: 1537
	protected LayerMask m_pLayerIgnoreRaycast;

	// Token: 0x04000602 RID: 1538
	protected EBonusEffectDirection m_eImpactDirection;
}

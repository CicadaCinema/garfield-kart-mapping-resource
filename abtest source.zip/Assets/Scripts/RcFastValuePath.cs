﻿using System;
using UnityEngine;

// Token: 0x020001FE RID: 510
public class RcFastValuePath : RcFastPath
{
	// Token: 0x06000DD0 RID: 3536 RVA: 0x0005A17C File Offset: 0x0005837C
	public RcFastValuePath(int _arraySize) : base(_arraySize)
	{
		this.m_pPointValues = new RcFastValuePathComp[_arraySize];
		for (int i = 0; i < _arraySize; i++)
		{
			this.m_pPointValues[i] = null;
		}
	}

	// Token: 0x06000DD1 RID: 3537 RVA: 0x0005A1B8 File Offset: 0x000583B8
	public RcFastValuePath(GameObject slowPath) : base(slowPath)
	{
		this.m_pPointValues = new RcFastValuePathComp[this.m_iNbPoints];
		if (this.m_iNbPoints > 0)
		{
			for (int i = 0; i < this.m_iNbPoints; i++)
			{
				RcFastValuePathComp component = slowPath.transform.GetChild(i).gameObject.GetComponent<RcFastValuePathComp>();
				if (component)
				{
					this.m_pPointValues[i] = component;
				}
			}
		}
	}

	// Token: 0x170001D6 RID: 470
	// (get) Token: 0x06000DD2 RID: 3538 RVA: 0x0000B7B1 File Offset: 0x000099B1
	// (set) Token: 0x06000DD3 RID: 3539 RVA: 0x0000B7B9 File Offset: 0x000099B9
	public E_PathType PathType
	{
		get
		{
			return this._pathType;
		}
		set
		{
			this._pathType = value;
		}
	}

	// Token: 0x06000DD4 RID: 3540 RVA: 0x0000B7C2 File Offset: 0x000099C2
	public RcFastValuePathComp GetPoint(int pInd)
	{
		if (this.m_iNbPoints <= 0)
		{
			return null;
		}
		return this.m_pPointValues[pInd];
	}

	// Token: 0x06000DD5 RID: 3541 RVA: 0x0000B7DA File Offset: 0x000099DA
	public float GetPointValue(int pInd)
	{
		if (this.m_iNbPoints <= 0)
		{
			return 0f;
		}
		return this.m_pPointValues[pInd].GetValue();
	}

	// Token: 0x06000DD6 RID: 3542 RVA: 0x0000B7FB File Offset: 0x000099FB
	public int GetIntPointValue(int pInd)
	{
		if (this.m_iNbPoints <= 0)
		{
			return 0;
		}
		return this.m_pPointValues[pInd].GetIntValue();
	}

	// Token: 0x06000DD7 RID: 3543 RVA: 0x0005A22C File Offset: 0x0005842C
	public override void SetSize(int _newSize, bool _updateLengthsAndDistances)
	{
		for (int i = this.m_iNbPoints; i < _newSize; i++)
		{
			this.m_pPointValues[i] = null;
		}
		base.SetSize(_newSize, _updateLengthsAndDistances);
	}

	// Token: 0x04000D65 RID: 3429
	protected E_PathType _pathType;

	// Token: 0x04000D66 RID: 3430
	protected RcFastValuePathComp[] m_pPointValues;
}

﻿using System;

// Token: 0x020001A5 RID: 421
public class MenuRewardsChampionShipShown : MenuRewards
{
	// Token: 0x06000B64 RID: 2916 RVA: 0x0004CAC4 File Offset: 0x0004ACC4
	public override void OnEnter()
	{
		base.OnEnter();
		Tuple<string, EDifficulty> tuple = Singleton<RewardManager>.Instance.PopLockedChampionShip();
		this._championShip = tuple.Item1;
		this._difficulty = tuple.Item2;
		this.LbRewardName.text = Localization.instance.Get("CHAMPIONSHIP_NAME_" + this._championShip[this._championShip.Length - 1]);
		this.LbMessage.text = string.Format(Localization.instance.Get("MENU_REWARDS_NOUVEAU_CHAMPIONNAT_APPARUT"), Localization.instance.Get("MENU_DIFFICULTY_" + this._difficulty.ToString().ToUpper()));
	}

	// Token: 0x06000B65 RID: 2917 RVA: 0x00009ED4 File Offset: 0x000080D4
	public override void OnGoNext()
	{
		Singleton<GameSaveManager>.Instance.SetChampionShipState(this._championShip, this._difficulty, E_UnlockableItemSate.NewLocked, false);
		base.OnGoNext();
	}

	// Token: 0x04000B2A RID: 2858
	private string _championShip;

	// Token: 0x04000B2B RID: 2859
	private EDifficulty _difficulty;
}

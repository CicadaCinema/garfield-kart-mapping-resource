﻿using System;
using UnityEngine;

// Token: 0x02000198 RID: 408
public class MenuBestOfGarfield : AbstractMenu
{
	// Token: 0x06000AFC RID: 2812 RVA: 0x00009899 File Offset: 0x00007A99
	public override void Awake()
	{
		base.Awake();
	}

	// Token: 0x06000AFD RID: 2813 RVA: 0x000098A1 File Offset: 0x00007AA1
	public override void OnEnter()
	{
		base.OnEnter();
		this.UpdatePanel();
	}

	// Token: 0x06000AFE RID: 2814 RVA: 0x000098AF File Offset: 0x00007AAF
	public void OnButtonLeft()
	{
		this.m_iCurrentPuzzle = (this.m_iCurrentPuzzle + 15 & 15);
		this.UpdatePanel();
	}

	// Token: 0x06000AFF RID: 2815 RVA: 0x000098C9 File Offset: 0x00007AC9
	public void OnButtonRight()
	{
		this.m_iCurrentPuzzle = (this.m_iCurrentPuzzle + 1 & 15);
		this.UpdatePanel();
	}

	// Token: 0x06000B00 RID: 2816 RVA: 0x0004A150 File Offset: 0x00048350
	private void UpdatePanel()
	{
		int num = this.m_iCurrentPuzzle >> 2;
		int num2 = this.m_iCurrentPuzzle & 3;
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		for (int i = 0; i < 3; i++)
		{
			bool flag = instance.IsPuzzlePieceUnlocked(string.Format("E{0}C{1}_{2}", num2 + 1, num + 1, i));
			this.m_oPuzzles[i].SetActive(!flag);
		}
		if (this.m_oSpriteBg)
		{
			if (this.m_oSpriteBg.atlas != null)
			{
				Resources.UnloadAsset(this.m_oSpriteBg.atlas.spriteMaterial.mainTexture);
			}
			UIAtlas atlas = (UIAtlas)Resources.Load(this.Atlases[num], typeof(UIAtlas));
			this.m_oSpriteBg.atlas = atlas;
			this.m_oSpriteBg.atlas.spriteMaterial.mainTexture = (Resources.Load(this.m_oSpriteBg.atlas.spriteMaterial.mainTexture.name, typeof(Texture2D)) as Texture2D);
			this.m_oSpriteBg.spriteName = "Puzzle_" + ((this.m_iCurrentPuzzle + 1 >= 10) ? string.Empty : "0") + (this.m_iCurrentPuzzle + 1);
		}
		this.m_oTrackName.key = string.Format("TRACK_NAME_E{0}C{1}", num2 + 1, num + 1);
		this.m_oTrackName.Localize();
	}

	// Token: 0x06000B01 RID: 2817 RVA: 0x000098E2 File Offset: 0x00007AE2
	public override void OnExit()
	{
		Resources.UnloadAsset(this.m_oSpriteBg.atlas.spriteMaterial.mainTexture);
		base.OnExit();
	}

	// Token: 0x04000AC9 RID: 2761
	public UISprite m_oSpriteBg;

	// Token: 0x04000ACA RID: 2762
	public GameObject[] m_oPuzzles = new GameObject[3];

	// Token: 0x04000ACB RID: 2763
	public UILocalize m_oTrackName;

	// Token: 0x04000ACC RID: 2764
	public string[] Atlases = new string[4];

	// Token: 0x04000ACD RID: 2765
	private int m_iCurrentPuzzle;
}

﻿using System;
using UnityEngine;

// Token: 0x02000248 RID: 584
public class BezierWaypoint : MonoBehaviour, IBezierWaypoint
{
	// Token: 0x06001040 RID: 4160 RVA: 0x0000CF3E File Offset: 0x0000B13E
	public void Awake()
	{
		this.SetControlPoints();
	}

	// Token: 0x06001041 RID: 4161 RVA: 0x000664E8 File Offset: 0x000646E8
	public void SetControlPoints()
	{
		foreach (IBezierControlPoint bezierControlPoint in base.GetComponentsInChildren(typeof(IBezierControlPoint)))
		{
			if (bezierControlPoint.Side == BezierControlPointSide.Left)
			{
				this.LeftPoint = bezierControlPoint;
			}
			else if (bezierControlPoint.Side == BezierControlPointSide.Right)
			{
				this.RightPoint = bezierControlPoint;
			}
			else
			{
				Debug.LogError("Bezier Curve control points must be set either left or right in the Editor");
			}
		}
	}

	// Token: 0x1700020E RID: 526
	// (get) Token: 0x06001042 RID: 4162 RVA: 0x0000CF46 File Offset: 0x0000B146
	public bool IsValid
	{
		get
		{
			return this.LeftPoint != null && this.RightPoint != null;
		}
	}

	// Token: 0x06001043 RID: 4163 RVA: 0x00066560 File Offset: 0x00064760
	public void SetPositionOfOther(IBezierControlPoint controlPoint, Vector3 vectorToFootPoint)
	{
		if (this.RightPoint != null && this.LeftPoint != null)
		{
			vectorToFootPoint.Normalize();
			if (controlPoint.Side == BezierControlPointSide.Left)
			{
				float magnitude = (this.CurrentPosition - this.RightPoint.CurrentPosition).magnitude;
				this.RightPoint.CurrentPosition = this.CurrentPosition + vectorToFootPoint * magnitude;
			}
			else
			{
				float magnitude2 = (this.CurrentPosition - this.LeftPoint.CurrentPosition).magnitude;
				this.LeftPoint.CurrentPosition = this.CurrentPosition + vectorToFootPoint * magnitude2;
			}
		}
	}

	// Token: 0x1700020F RID: 527
	// (get) Token: 0x06001044 RID: 4164 RVA: 0x0000CF62 File Offset: 0x0000B162
	// (set) Token: 0x06001045 RID: 4165 RVA: 0x0000CF6A File Offset: 0x0000B16A
	public IBezierControlPoint LeftPoint
	{
		get
		{
			return this.leftPoint;
		}
		set
		{
			this.leftPoint = value;
		}
	}

	// Token: 0x17000210 RID: 528
	// (get) Token: 0x06001046 RID: 4166 RVA: 0x0000CF73 File Offset: 0x0000B173
	// (set) Token: 0x06001047 RID: 4167 RVA: 0x0000CF7B File Offset: 0x0000B17B
	public IBezierControlPoint RightPoint
	{
		get
		{
			return this.rightPoint;
		}
		set
		{
			this.rightPoint = value;
		}
	}

	// Token: 0x17000211 RID: 529
	// (get) Token: 0x06001048 RID: 4168 RVA: 0x0000AE06 File Offset: 0x00009006
	public Vector3 CurrentPosition
	{
		get
		{
			return base.transform.position;
		}
	}

	// Token: 0x06001049 RID: 4169 RVA: 0x00066614 File Offset: 0x00064814
	public void OnDrawGizmos()
	{
		BezierCurveManager bezierCurveManager = base.transform.parent.GetComponent(typeof(BezierCurveManager)) as BezierCurveManager;
		if (this.IsValid)
		{
			if (bezierCurveManager.DrawPoints)
			{
				Gizmos.DrawIcon(base.transform.position, "/BezierWaypoint.png");
			}
			if (bezierCurveManager.DrawControlPoints)
			{
				this.SetControlPoints();
				if (this.RightPoint != null && this.LeftPoint != null)
				{
					Gizmos.DrawLine(this.RightPoint.CurrentPosition, this.LeftPoint.CurrentPosition);
				}
			}
		}
	}

	// Token: 0x04000F98 RID: 3992
	private IBezierControlPoint leftPoint;

	// Token: 0x04000F99 RID: 3993
	private IBezierControlPoint rightPoint;
}

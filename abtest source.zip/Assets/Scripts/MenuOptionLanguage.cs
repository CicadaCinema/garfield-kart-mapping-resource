﻿using System;
using UnityEngine;

// Token: 0x02000122 RID: 290
public class MenuOptionLanguage : AbstractMenu
{
	// Token: 0x060007FB RID: 2043 RVA: 0x000079A1 File Offset: 0x00005BA1
	public override void OnEnter()
	{
		base.OnEnter();
		if (this.m_oIconLanguage)
		{
			this.m_oIconLanguage.ChangeTexture((int)Singleton<GameOptionManager>.Instance.GetCurrentLangId());
		}
	}

	// Token: 0x060007FC RID: 2044 RVA: 0x000079CE File Offset: 0x00005BCE
	public void OnSelectLanguage(int iLang)
	{
		Singleton<GameOptionManager>.Instance.SetLanguage((GameOptionManager.ELangID)iLang, true);
		if (this.m_oIconLanguage)
		{
			this.m_oIconLanguage.ChangeTexture(iLang);
		}
	}

	// Token: 0x060007FD RID: 2045 RVA: 0x000079F8 File Offset: 0x00005BF8
	public override void Update()
	{
		if (Application.platform == RuntimePlatform.Android && Input.GetKeyDown(KeyCode.Escape))
		{
			this.ActSwapMenu(EMenus.MENU_OPTIONS);
		}
	}

	// Token: 0x04000830 RID: 2096
	public UITexturePattern m_oIconLanguage;
}

﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000026 RID: 38
[AddComponentMenu("NGUI/Interaction/Popup List")]
[ExecuteInEditMode]
public class UIPopupList : MonoBehaviour
{
	// Token: 0x1700000D RID: 13
	// (get) Token: 0x060000BF RID: 191 RVA: 0x00002C79 File Offset: 0x00000E79
	public bool isOpen
	{
		get
		{
			return this.mChild != null;
		}
	}

	// Token: 0x1700000E RID: 14
	// (get) Token: 0x060000C0 RID: 192 RVA: 0x00002C87 File Offset: 0x00000E87
	// (set) Token: 0x060000C1 RID: 193 RVA: 0x00010FF8 File Offset: 0x0000F1F8
	public string selection
	{
		get
		{
			return this.mSelectedItem;
		}
		set
		{
			if (this.mSelectedItem != value)
			{
				this.mSelectedItem = value;
				if (this.textLabel != null)
				{
					this.textLabel.text = ((!this.isLocalized) ? value : Localization.Localize(value));
				}
				UIPopupList.current = this;
				if (this.onSelectionChange != null)
				{
					this.onSelectionChange(this.mSelectedItem);
				}
				if (this.eventReceiver != null && !string.IsNullOrEmpty(this.functionName) && Application.isPlaying)
				{
					this.eventReceiver.SendMessage(this.functionName, this.mSelectedItem, SendMessageOptions.DontRequireReceiver);
				}
				UIPopupList.current = null;
				if (this.textLabel == null)
				{
					this.mSelectedItem = null;
				}
			}
		}
	}

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x060000C2 RID: 194 RVA: 0x000110D4 File Offset: 0x0000F2D4
	// (set) Token: 0x060000C3 RID: 195 RVA: 0x00011100 File Offset: 0x0000F300
	private bool handleEvents
	{
		get
		{
			UIButtonKeys component = base.GetComponent<UIButtonKeys>();
			return component == null || !component.enabled;
		}
		set
		{
			UIButtonKeys component = base.GetComponent<UIButtonKeys>();
			if (component != null)
			{
				component.enabled = !value;
			}
		}
	}

	// Token: 0x060000C4 RID: 196 RVA: 0x0001112C File Offset: 0x0000F32C
	private void Start()
	{
		if (this.textLabel != null)
		{
			if (string.IsNullOrEmpty(this.mSelectedItem))
			{
				if (this.items.Count > 0)
				{
					this.selection = this.items[0];
				}
			}
			else
			{
				string selection = this.mSelectedItem;
				this.mSelectedItem = null;
				this.selection = selection;
			}
		}
	}

	// Token: 0x060000C5 RID: 197 RVA: 0x00002C8F File Offset: 0x00000E8F
	private void OnLocalize(Localization loc)
	{
		if (this.isLocalized && this.textLabel != null)
		{
			this.textLabel.text = loc.Get(this.mSelectedItem);
		}
	}

	// Token: 0x060000C6 RID: 198 RVA: 0x00011198 File Offset: 0x0000F398
	private void Highlight(UILabel lbl, bool instant)
	{
		if (this.mHighlight != null)
		{
			TweenPosition component = lbl.GetComponent<TweenPosition>();
			if (component != null && component.enabled)
			{
				return;
			}
			this.mHighlightedLabel = lbl;
			UIAtlas.Sprite atlasSprite = this.mHighlight.GetAtlasSprite();
			if (atlasSprite == null)
			{
				return;
			}
			float num = atlasSprite.inner.xMin - atlasSprite.outer.xMin;
			float y = atlasSprite.inner.yMin - atlasSprite.outer.yMin;
			Vector3 vector = lbl.cachedTransform.localPosition + new Vector3(-num, y, 1f);
			if (instant || !this.isAnimated)
			{
				this.mHighlight.cachedTransform.localPosition = vector;
			}
			else
			{
				TweenPosition.Begin(this.mHighlight.gameObject, 0.1f, vector).method = UITweener.Method.EaseOut;
			}
		}
	}

	// Token: 0x060000C7 RID: 199 RVA: 0x00011284 File Offset: 0x0000F484
	private void OnItemHover(GameObject go, bool isOver)
	{
		if (isOver)
		{
			UILabel component = go.GetComponent<UILabel>();
			this.Highlight(component, false);
		}
	}

	// Token: 0x060000C8 RID: 200 RVA: 0x000112A8 File Offset: 0x0000F4A8
	private void Select(UILabel lbl, bool instant)
	{
		this.Highlight(lbl, instant);
		UIEventListener component = lbl.gameObject.GetComponent<UIEventListener>();
		this.selection = (component.parameter as string);
		UIButtonSound[] components = base.GetComponents<UIButtonSound>();
		int i = 0;
		int num = components.Length;
		while (i < num)
		{
			UIButtonSound uibuttonSound = components[i];
			if (uibuttonSound.trigger == UIButtonSound.Trigger.OnClick)
			{
				NGUITools.PlaySound(uibuttonSound.audioClip, uibuttonSound.volume, 1f);
			}
			i++;
		}
	}

	// Token: 0x060000C9 RID: 201 RVA: 0x00002CC4 File Offset: 0x00000EC4
	private void OnItemPress(GameObject go, bool isPressed)
	{
		if (isPressed)
		{
			this.Select(go.GetComponent<UILabel>(), true);
		}
	}

	// Token: 0x060000CA RID: 202 RVA: 0x00011324 File Offset: 0x0000F524
	private void OnKey(KeyCode key)
	{
		if (base.enabled && NGUITools.GetActive(base.gameObject) && this.handleEvents)
		{
			int num = this.mLabelList.IndexOf(this.mHighlightedLabel);
			if (key == KeyCode.UpArrow)
			{
				if (num > 0)
				{
					this.Select(this.mLabelList[num - 1], false);
				}
			}
			else if (key == KeyCode.DownArrow)
			{
				if (num + 1 < this.mLabelList.Count)
				{
					this.Select(this.mLabelList[num + 1], false);
				}
			}
			else if (key == KeyCode.Escape)
			{
				this.OnSelect(false);
			}
		}
	}

	// Token: 0x060000CB RID: 203 RVA: 0x000113E0 File Offset: 0x0000F5E0
	private void OnSelect(bool isSelected)
	{
		if (!isSelected && this.mChild != null)
		{
			this.mLabelList.Clear();
			this.handleEvents = false;
			if (this.isAnimated)
			{
				UIWidget[] componentsInChildren = this.mChild.GetComponentsInChildren<UIWidget>();
				int i = 0;
				int num = componentsInChildren.Length;
				while (i < num)
				{
					UIWidget uiwidget = componentsInChildren[i];
					Color color = uiwidget.color;
					color.a = 0f;
					TweenColor.Begin(uiwidget.gameObject, 0.15f, color).method = UITweener.Method.EaseOut;
					i++;
				}
				Collider[] componentsInChildren2 = this.mChild.GetComponentsInChildren<Collider>();
				int j = 0;
				int num2 = componentsInChildren2.Length;
				while (j < num2)
				{
					componentsInChildren2[j].enabled = false;
					j++;
				}
				UnityEngine.Object.Destroy(this.mChild, 0.15f);
			}
			else
			{
				UnityEngine.Object.Destroy(this.mChild);
			}
			this.mBackground = null;
			this.mHighlight = null;
			this.mChild = null;
		}
	}

	// Token: 0x060000CC RID: 204 RVA: 0x000114E0 File Offset: 0x0000F6E0
	private void AnimateColor(UIWidget widget)
	{
		Color color = widget.color;
		widget.color = new Color(color.r, color.g, color.b, 0f);
		TweenColor.Begin(widget.gameObject, 0.15f, color).method = UITweener.Method.EaseOut;
	}

	// Token: 0x060000CD RID: 205 RVA: 0x00011530 File Offset: 0x0000F730
	private void AnimatePosition(UIWidget widget, bool placeAbove, float bottom)
	{
		Vector3 localPosition = widget.cachedTransform.localPosition;
		Vector3 localPosition2 = (!placeAbove) ? new Vector3(localPosition.x, 0f, localPosition.z) : new Vector3(localPosition.x, bottom, localPosition.z);
		widget.cachedTransform.localPosition = localPosition2;
		GameObject gameObject = widget.gameObject;
		TweenPosition.Begin(gameObject, 0.15f, localPosition).method = UITweener.Method.EaseOut;
	}

	// Token: 0x060000CE RID: 206 RVA: 0x000115A8 File Offset: 0x0000F7A8
	private void AnimateScale(UIWidget widget, bool placeAbove, float bottom)
	{
		GameObject gameObject = widget.gameObject;
		Transform cachedTransform = widget.cachedTransform;
		float num = (float)this.font.size * this.textScale + this.mBgBorder * 2f;
		Vector3 localScale = cachedTransform.localScale;
		cachedTransform.localScale = new Vector3(localScale.x, num, localScale.z);
		TweenScale.Begin(gameObject, 0.15f, localScale).method = UITweener.Method.EaseOut;
		if (placeAbove)
		{
			Vector3 localPosition = cachedTransform.localPosition;
			cachedTransform.localPosition = new Vector3(localPosition.x, localPosition.y - localScale.y + num, localPosition.z);
			TweenPosition.Begin(gameObject, 0.15f, localPosition).method = UITweener.Method.EaseOut;
		}
	}

	// Token: 0x060000CF RID: 207 RVA: 0x00002CD9 File Offset: 0x00000ED9
	private void Animate(UIWidget widget, bool placeAbove, float bottom)
	{
		this.AnimateColor(widget);
		this.AnimatePosition(widget, placeAbove, bottom);
	}

	// Token: 0x060000D0 RID: 208 RVA: 0x00011664 File Offset: 0x0000F864
	private void OnClick()
	{
		if (this.mChild == null && this.atlas != null && this.font != null && this.items.Count > 0)
		{
			this.mLabelList.Clear();
			this.handleEvents = true;
			if (this.mPanel == null)
			{
				this.mPanel = UIPanel.Find(base.transform, true);
			}
			Transform transform = base.transform;
			Bounds bounds = NGUIMath.CalculateRelativeWidgetBounds(transform.parent, transform);
			this.mChild = new GameObject("Drop-down List");
			this.mChild.layer = base.gameObject.layer;
			Transform transform2 = this.mChild.transform;
			transform2.parent = transform.parent;
			transform2.localPosition = bounds.min;
			transform2.localRotation = Quaternion.identity;
			transform2.localScale = Vector3.one;
			this.mBackground = NGUITools.AddSprite(this.mChild, this.atlas, this.backgroundSprite);
			this.mBackground.pivot = UIWidget.Pivot.TopLeft;
			this.mBackground.depth = NGUITools.CalculateNextDepth(this.mPanel.gameObject);
			this.mBackground.color = this.backgroundColor;
			Vector4 border = this.mBackground.border;
			this.mBgBorder = border.y;
			this.mBackground.cachedTransform.localPosition = new Vector3(0f, border.y, 0f);
			this.mHighlight = NGUITools.AddSprite(this.mChild, this.atlas, this.highlightSprite);
			this.mHighlight.pivot = UIWidget.Pivot.TopLeft;
			this.mHighlight.color = this.highlightColor;
			UIAtlas.Sprite atlasSprite = this.mHighlight.GetAtlasSprite();
			if (atlasSprite == null)
			{
				return;
			}
			float num = atlasSprite.inner.yMin - atlasSprite.outer.yMin;
			float num2 = (float)this.font.size * this.font.pixelSize * this.textScale;
			float num3 = 0f;
			float num4 = -this.padding.y;
			List<UILabel> list = new List<UILabel>();
			int i = 0;
			int count = this.items.Count;
			while (i < count)
			{
				string text = this.items[i];
				UILabel uilabel = NGUITools.AddWidget<UILabel>(this.mChild);
				uilabel.pivot = UIWidget.Pivot.TopLeft;
				uilabel.font = this.font;
				uilabel.text = ((!this.isLocalized || !(Localization.instance != null)) ? text : Localization.instance.Get(text));
				uilabel.color = this.textColor;
				uilabel.cachedTransform.localPosition = new Vector3(border.x + this.padding.x, num4, -1f);
				uilabel.MakePixelPerfect();
				if (this.textScale != 1f)
				{
					Vector3 localScale = uilabel.cachedTransform.localScale;
					uilabel.cachedTransform.localScale = localScale * this.textScale;
				}
				list.Add(uilabel);
				num4 -= num2;
				num4 -= this.padding.y;
				num3 = Mathf.Max(num3, uilabel.relativeSize.x * num2);
				UIEventListener uieventListener = UIEventListener.Get(uilabel.gameObject);
				uieventListener.onHover = new UIEventListener.BoolDelegate(this.OnItemHover);
				uieventListener.onPress = new UIEventListener.BoolDelegate(this.OnItemPress);
				uieventListener.parameter = text;
				if (this.mSelectedItem == text)
				{
					this.Highlight(uilabel, true);
				}
				this.mLabelList.Add(uilabel);
				i++;
			}
			num3 = Mathf.Max(num3, bounds.size.x - (border.x + this.padding.x) * 2f);
			Vector3 center = new Vector3(num3 * 0.5f / num2, -0.5f, 0f);
			Vector3 size = new Vector3(num3 / num2, (num2 + this.padding.y) / num2, 1f);
			int j = 0;
			int count2 = list.Count;
			while (j < count2)
			{
				UILabel uilabel2 = list[j];
				BoxCollider boxCollider = NGUITools.AddWidgetCollider(uilabel2.gameObject);
				center.z = boxCollider.center.z;
				boxCollider.center = center;
				boxCollider.size = size;
				j++;
			}
			num3 += (border.x + this.padding.x) * 2f;
			num4 -= border.y;
			this.mBackground.cachedTransform.localScale = new Vector3(num3, -num4 + border.y, 1f);
			this.mHighlight.cachedTransform.localScale = new Vector3(num3 - (border.x + this.padding.x) * 2f + (atlasSprite.inner.xMin - atlasSprite.outer.xMin) * 2f, num2 + num * 2f, 1f);
			bool flag = this.position == UIPopupList.Position.Above;
			if (this.position == UIPopupList.Position.Auto)
			{
				UICamera uicamera = UICamera.FindCameraForLayer(base.gameObject.layer);
				if (uicamera != null)
				{
					flag = (uicamera.cachedCamera.WorldToViewportPoint(transform.position).y < 0.5f);
				}
			}
			if (this.isAnimated)
			{
				float bottom = num4 + num2;
				this.Animate(this.mHighlight, flag, bottom);
				int k = 0;
				int count3 = list.Count;
				while (k < count3)
				{
					this.Animate(list[k], flag, bottom);
					k++;
				}
				this.AnimateColor(this.mBackground);
				this.AnimateScale(this.mBackground, flag, bottom);
			}
			if (flag)
			{
				transform2.localPosition = new Vector3(bounds.min.x, bounds.max.y - num4 - border.y, bounds.min.z);
			}
		}
		else
		{
			this.OnSelect(false);
		}
	}

	// Token: 0x040000DC RID: 220
	private const float animSpeed = 0.15f;

	// Token: 0x040000DD RID: 221
	public static UIPopupList current;

	// Token: 0x040000DE RID: 222
	public UIAtlas atlas;

	// Token: 0x040000DF RID: 223
	public UIFont font;

	// Token: 0x040000E0 RID: 224
	public UILabel textLabel;

	// Token: 0x040000E1 RID: 225
	public string backgroundSprite;

	// Token: 0x040000E2 RID: 226
	public string highlightSprite;

	// Token: 0x040000E3 RID: 227
	public UIPopupList.Position position;

	// Token: 0x040000E4 RID: 228
	public List<string> items = new List<string>();

	// Token: 0x040000E5 RID: 229
	public Vector2 padding = new Vector3(4f, 4f);

	// Token: 0x040000E6 RID: 230
	public float textScale = 1f;

	// Token: 0x040000E7 RID: 231
	public Color textColor = Color.white;

	// Token: 0x040000E8 RID: 232
	public Color backgroundColor = Color.white;

	// Token: 0x040000E9 RID: 233
	public Color highlightColor = new Color(0.596078455f, 1f, 0.2f, 1f);

	// Token: 0x040000EA RID: 234
	public bool isAnimated = true;

	// Token: 0x040000EB RID: 235
	public bool isLocalized;

	// Token: 0x040000EC RID: 236
	public GameObject eventReceiver;

	// Token: 0x040000ED RID: 237
	public string functionName = "OnSelectionChange";

	// Token: 0x040000EE RID: 238
	public UIPopupList.OnSelectionChange onSelectionChange;

	// Token: 0x040000EF RID: 239
	[SerializeField]
	[HideInInspector]
	private string mSelectedItem;

	// Token: 0x040000F0 RID: 240
	private UIPanel mPanel;

	// Token: 0x040000F1 RID: 241
	private GameObject mChild;

	// Token: 0x040000F2 RID: 242
	private UISprite mBackground;

	// Token: 0x040000F3 RID: 243
	private UISprite mHighlight;

	// Token: 0x040000F4 RID: 244
	private UILabel mHighlightedLabel;

	// Token: 0x040000F5 RID: 245
	private List<UILabel> mLabelList = new List<UILabel>();

	// Token: 0x040000F6 RID: 246
	private float mBgBorder;

	// Token: 0x02000027 RID: 39
	public enum Position
	{
		// Token: 0x040000F8 RID: 248
		Auto,
		// Token: 0x040000F9 RID: 249
		Above,
		// Token: 0x040000FA RID: 250
		Below
	}

	// Token: 0x02000028 RID: 40
	// (Invoke) Token: 0x060000D2 RID: 210
	public delegate void OnSelectionChange(string item);
}

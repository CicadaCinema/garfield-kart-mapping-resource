﻿using System;
using UnityEngine;

// Token: 0x020001EB RID: 491
public class CamStateFollow : CamState
{
	// Token: 0x170001CB RID: 459
	// (get) Token: 0x06000D52 RID: 3410 RVA: 0x00003B7D File Offset: 0x00001D7D
	public override ECamState state
	{
		get
		{
			return ECamState.Follow;
		}
	}

	// Token: 0x170001CC RID: 460
	// (get) Token: 0x06000D53 RID: 3411 RVA: 0x0000B196 File Offset: 0x00009396
	// (set) Token: 0x06000D54 RID: 3412 RVA: 0x0000B19E File Offset: 0x0000939E
	public bool bBoost { get; set; }

	// Token: 0x170001CD RID: 461
	// (get) Token: 0x06000D55 RID: 3413 RVA: 0x0000B1A7 File Offset: 0x000093A7
	// (set) Token: 0x06000D56 RID: 3414 RVA: 0x0000B1AF File Offset: 0x000093AF
	public bool bSlow { get; set; }

	// Token: 0x06000D57 RID: 3415 RVA: 0x0000B1B8 File Offset: 0x000093B8
	public override void Enter(Transform _Transform, Transform _Target)
	{
		base.Enter(_Transform, _Target);
		this.CurrDamping = this.DistanceDamping;
	}

	// Token: 0x06000D58 RID: 3416 RVA: 0x000572B4 File Offset: 0x000554B4
	public override ECamState Manage(float dt)
	{
		if (base.m_Target == null)
		{
			GameMode gameMode = Singleton<GameManager>.Instance.GameMode;
			if (gameMode != null)
			{
				GameObject humanPlayer = gameMode.GetHumanPlayer();
				if (humanPlayer != null)
				{
					base.m_Target = humanPlayer.transform.Find("cible_camera").transform;
				}
			}
			if (base.m_Target == null)
			{
				return this.state;
			}
		}
		float y = base.m_Target.eulerAngles.y;
		float num = base.m_Target.position.y + this.Height;
		float num2 = base.m_Transform.eulerAngles.y;
		float num3 = base.m_Transform.position.y;
		Vector3 vector = base.m_Target.position - base.m_Transform.position;
		vector.y = 0f;
		float magnitude = vector.magnitude;
		num2 = ((!this.m_bDamping) ? y : Mathf.LerpAngle(num2, y, this.RotationDamping * dt));
		num3 = ((!this.m_bDamping) ? num : Mathf.Lerp(num3, num, this.HeightDamping * dt));
		Quaternion rotation = Quaternion.Euler(0f, num2, 0f);
		base.m_Transform.position = base.m_Target.position;
		float to = this.DistanceDamping;
		float num4 = this.Distance;
		if (this.bBoost != this.bSlow)
		{
			if (this.bBoost)
			{
				to = this.BoostDamping;
			}
			else if (this.bSlow)
			{
				to = this.SlowDamping;
			}
		}
		this.CurrDamping = Mathf.Lerp(this.CurrDamping, to, this.DampDamping * dt);
		num4 = ((!this.m_bDamping) ? num4 : Mathf.Lerp(magnitude, num4, this.CurrDamping * dt));
		base.m_Transform.position -= rotation * Vector3.forward * num4;
		base.m_Transform.position = new Vector3(base.m_Transform.position.x, num3, base.m_Transform.position.z);
		base.m_Transform.LookAt(base.m_Target);
		return this.state;
	}

	// Token: 0x04000D01 RID: 3329
	public float Distance = 10f;

	// Token: 0x04000D02 RID: 3330
	public float Height = 5f;

	// Token: 0x04000D03 RID: 3331
	public float HeightDamping = 2f;

	// Token: 0x04000D04 RID: 3332
	public float RotationDamping = 3f;

	// Token: 0x04000D05 RID: 3333
	public float DistanceDamping = 10f;

	// Token: 0x04000D06 RID: 3334
	public float BoostDamping = 3f;

	// Token: 0x04000D07 RID: 3335
	public float SlowDamping = 30f;

	// Token: 0x04000D08 RID: 3336
	public float DampDamping = 10f;

	// Token: 0x04000D09 RID: 3337
	protected float CurrDamping;
}

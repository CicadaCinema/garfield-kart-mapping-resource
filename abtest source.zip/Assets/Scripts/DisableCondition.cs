﻿using System;

namespace AnimationOrTween
{
	// Token: 0x0200003B RID: 59
	public enum DisableCondition
	{
		// Token: 0x04000152 RID: 338
		DisableAfterReverse = -1,
		// Token: 0x04000153 RID: 339
		DoNotDisable,
		// Token: 0x04000154 RID: 340
		DisableAfterForward
	}
}

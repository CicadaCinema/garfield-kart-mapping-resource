﻿using System;
using UnityEngine;

// Token: 0x02000020 RID: 32
[AddComponentMenu("NGUI/Interaction/Forward Events")]
public class UIForwardEvents : MonoBehaviour
{
	// Token: 0x060000A4 RID: 164 RVA: 0x000029B3 File Offset: 0x00000BB3
	private void OnHover(bool isOver)
	{
		if (this.onHover && this.target != null)
		{
			this.target.SendMessage("OnHover", isOver, SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x060000A5 RID: 165 RVA: 0x000029E8 File Offset: 0x00000BE8
	private void OnPress(bool pressed)
	{
		if (this.onPress && this.target != null)
		{
			this.target.SendMessage("OnPress", pressed, SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x060000A6 RID: 166 RVA: 0x00002A1D File Offset: 0x00000C1D
	private void OnClick()
	{
		if (this.onClick && this.target != null)
		{
			this.target.SendMessage("OnClick", SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x060000A7 RID: 167 RVA: 0x00002A4C File Offset: 0x00000C4C
	private void OnDoubleClick()
	{
		if (this.onDoubleClick && this.target != null)
		{
			this.target.SendMessage("OnDoubleClick", SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x060000A8 RID: 168 RVA: 0x00002A7B File Offset: 0x00000C7B
	private void OnSelect(bool selected)
	{
		if (this.onSelect && this.target != null)
		{
			this.target.SendMessage("OnSelect", selected, SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x060000A9 RID: 169 RVA: 0x00002AB0 File Offset: 0x00000CB0
	private void OnDrag(Vector2 delta)
	{
		if (this.onDrag && this.target != null)
		{
			this.target.SendMessage("OnDrag", delta, SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x060000AA RID: 170 RVA: 0x00002AE5 File Offset: 0x00000CE5
	private void OnDrop(GameObject go)
	{
		if (this.onDrop && this.target != null)
		{
			this.target.SendMessage("OnDrop", go, SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x060000AB RID: 171 RVA: 0x00002B15 File Offset: 0x00000D15
	private void OnInput(string text)
	{
		if (this.onInput && this.target != null)
		{
			this.target.SendMessage("OnInput", text, SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x060000AC RID: 172 RVA: 0x00002B45 File Offset: 0x00000D45
	private void OnSubmit()
	{
		if (this.onSubmit && this.target != null)
		{
			this.target.SendMessage("OnSubmit", SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x060000AD RID: 173 RVA: 0x00002B74 File Offset: 0x00000D74
	private void OnScroll(float delta)
	{
		if (this.onScroll && this.target != null)
		{
			this.target.SendMessage("OnScroll", delta, SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x040000B9 RID: 185
	public GameObject target;

	// Token: 0x040000BA RID: 186
	public bool onHover;

	// Token: 0x040000BB RID: 187
	public bool onPress;

	// Token: 0x040000BC RID: 188
	public bool onClick;

	// Token: 0x040000BD RID: 189
	public bool onDoubleClick;

	// Token: 0x040000BE RID: 190
	public bool onSelect;

	// Token: 0x040000BF RID: 191
	public bool onDrag;

	// Token: 0x040000C0 RID: 192
	public bool onDrop;

	// Token: 0x040000C1 RID: 193
	public bool onInput;

	// Token: 0x040000C2 RID: 194
	public bool onSubmit;

	// Token: 0x040000C3 RID: 195
	public bool onScroll;
}

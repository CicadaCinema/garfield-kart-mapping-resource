﻿using System;
using UnityEngine;

// Token: 0x02000254 RID: 596
public class Tricks
{
	// Token: 0x06001074 RID: 4212 RVA: 0x000676FC File Offset: 0x000658FC
	public static double ComputeInertia(double v0, double v1, double Ine, double dt)
	{
		if (dt == 0.0)
		{
			return v1;
		}
		double num = Math.Max(Ine, 0.5 * dt) / dt;
		return (v0 * (num - 0.5) + v1) / (num + 0.5);
	}

	// Token: 0x06001075 RID: 4213 RVA: 0x0006774C File Offset: 0x0006594C
	public static float ComputeInertia(float v0, float v1, float Ine, float dt)
	{
		float num = Math.Max(Ine, 0.5f * dt) / dt;
		return (v0 * (num - 0.5f) + v1) / (num + 0.5f);
	}

	// Token: 0x06001076 RID: 4214 RVA: 0x0006777C File Offset: 0x0006597C
	public static int LogBase2(int iVal)
	{
		int num = -1;
		while (iVal > 0)
		{
			iVal >>= 1;
			num++;
		}
		return num;
	}

	// Token: 0x06001077 RID: 4215 RVA: 0x0000D150 File Offset: 0x0000B350
	public static bool isTablet()
	{
		return (float)Screen.width / Screen.dpi >= 6f;
	}
}

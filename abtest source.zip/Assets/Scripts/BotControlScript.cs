﻿using System;
using UnityEngine;

// Token: 0x0200026A RID: 618
[RequireComponent(typeof(CapsuleCollider))]
[RequireComponent(typeof(Animator))]
[RequireComponent(typeof(Rigidbody))]
public class BotControlScript : MonoBehaviour
{
	// Token: 0x060010F2 RID: 4338 RVA: 0x00067F18 File Offset: 0x00066118
	private void Start()
	{
		this.anim = base.GetComponent<Animator>();
		this.col = base.GetComponent<CapsuleCollider>();
		this.enemy = GameObject.Find("Enemy").transform;
		if (this.anim.layerCount == 2)
		{
			this.anim.SetLayerWeight(1, 1f);
		}
	}

	// Token: 0x060010F3 RID: 4339 RVA: 0x00067F74 File Offset: 0x00066174
	private void FixedUpdate()
	{
		float axis = Input.GetAxis("Horizontal");
		float axis2 = Input.GetAxis("Vertical");
		this.anim.SetFloat("Speed", axis2);
		this.anim.SetFloat("Direction", axis);
		this.anim.speed = this.animSpeed;
		this.anim.SetLookAtWeight(this.lookWeight);
		this.currentBaseState = this.anim.GetCurrentAnimatorStateInfo(0);
		if (this.anim.layerCount == 2)
		{
			this.layer2CurrentState = this.anim.GetCurrentAnimatorStateInfo(1);
		}
		if (Input.GetButton("Fire2"))
		{
			this.anim.SetLookAtPosition(this.enemy.position);
			this.lookWeight = Mathf.Lerp(this.lookWeight, 1f, Time.deltaTime * this.lookSmoother);
		}
		else
		{
			this.lookWeight = Mathf.Lerp(this.lookWeight, 0f, Time.deltaTime * this.lookSmoother);
		}
		if (this.currentBaseState.nameHash == BotControlScript.locoState)
		{
			if (Input.GetButtonDown("Jump"))
			{
				this.anim.SetBool("Jump", true);
			}
		}
		else if (this.currentBaseState.nameHash == BotControlScript.jumpState)
		{
			if (!this.anim.IsInTransition(0))
			{
				if (this.useCurves)
				{
					this.col.height = this.anim.GetFloat("ColliderHeight");
				}
				this.anim.SetBool("Jump", false);
			}
			Ray ray = new Ray(base.transform.position + Vector3.up, -Vector3.up);
			RaycastHit raycastHit = default(RaycastHit);
			if (Physics.Raycast(ray, out raycastHit) && raycastHit.distance > 1.75f)
			{
				this.anim.MatchTarget(raycastHit.point, Quaternion.identity, AvatarTarget.Root, new MatchTargetWeightMask(new Vector3(0f, 1f, 0f), 0f), 0.35f, 0.5f);
			}
		}
		else if (this.currentBaseState.nameHash == BotControlScript.jumpDownState)
		{
			this.col.center = new Vector3(0f, this.anim.GetFloat("ColliderY"), 0f);
		}
		else if (this.currentBaseState.nameHash == BotControlScript.fallState)
		{
			this.col.height = this.anim.GetFloat("ColliderHeight");
		}
		else if (this.currentBaseState.nameHash == BotControlScript.rollState)
		{
			if (!this.anim.IsInTransition(0))
			{
				if (this.useCurves)
				{
					this.col.height = this.anim.GetFloat("ColliderHeight");
				}
				this.col.center = new Vector3(0f, this.anim.GetFloat("ColliderY"), 0f);
			}
		}
		else if (this.currentBaseState.nameHash == BotControlScript.idleState && Input.GetButtonUp("Jump"))
		{
			this.anim.SetBool("Wave", true);
		}
		if (this.layer2CurrentState.nameHash == BotControlScript.waveState)
		{
			this.anim.SetBool("Wave", false);
		}
	}

	// Token: 0x04000FFA RID: 4090
	[NonSerialized]
	public float lookWeight;

	// Token: 0x04000FFB RID: 4091
	[NonSerialized]
	public Transform enemy;

	// Token: 0x04000FFC RID: 4092
	public float animSpeed = 1.5f;

	// Token: 0x04000FFD RID: 4093
	public float lookSmoother = 3f;

	// Token: 0x04000FFE RID: 4094
	public bool useCurves;

	// Token: 0x04000FFF RID: 4095
	private Animator anim;

	// Token: 0x04001000 RID: 4096
	private AnimatorStateInfo currentBaseState;

	// Token: 0x04001001 RID: 4097
	private AnimatorStateInfo layer2CurrentState;

	// Token: 0x04001002 RID: 4098
	private CapsuleCollider col;

	// Token: 0x04001003 RID: 4099
	private static int idleState = Animator.StringToHash("Base Layer.Idle");

	// Token: 0x04001004 RID: 4100
	private static int locoState = Animator.StringToHash("Base Layer.Locomotion");

	// Token: 0x04001005 RID: 4101
	private static int jumpState = Animator.StringToHash("Base Layer.Jump");

	// Token: 0x04001006 RID: 4102
	private static int jumpDownState = Animator.StringToHash("Base Layer.JumpDown");

	// Token: 0x04001007 RID: 4103
	private static int fallState = Animator.StringToHash("Base Layer.Fall");

	// Token: 0x04001008 RID: 4104
	private static int rollState = Animator.StringToHash("Base Layer.Roll");

	// Token: 0x04001009 RID: 4105
	private static int waveState = Animator.StringToHash("Layer2.Wave");
}

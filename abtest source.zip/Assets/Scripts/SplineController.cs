﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200024E RID: 590
[RequireComponent(typeof(SplineInterpolator))]
[AddComponentMenu("Splines/Spline Controller")]
public class SplineController : MonoBehaviour
{
	// Token: 0x0600105C RID: 4188 RVA: 0x00066B58 File Offset: 0x00064D58
	private void OnDrawGizmos()
	{
		Transform[] transforms = this.GetTransforms();
		if (transforms.Length < 2)
		{
			return;
		}
		SplineInterpolator splineInterpolator = base.GetComponent(typeof(SplineInterpolator)) as SplineInterpolator;
		this.SetupSplineInterpolator(splineInterpolator, transforms);
		splineInterpolator.StartInterpolation(null, false, this.WrapMode);
		Vector3 vector = transforms[0].position;
		for (int i = 1; i <= 100; i++)
		{
			float timeParam = (float)i * this.Duration / 100f;
			Vector3 hermiteAtTime = splineInterpolator.GetHermiteAtTime(timeParam);
			float r = (hermiteAtTime - vector).magnitude * 2f;
			Gizmos.color = new Color(r, 0f, 0f, 1f);
			Gizmos.DrawLine(vector, hermiteAtTime);
			vector = hermiteAtTime;
		}
	}

	// Token: 0x0600105D RID: 4189 RVA: 0x00066C18 File Offset: 0x00064E18
	public void Start()
	{
		this.mSplineInterp = (base.GetComponent(typeof(SplineInterpolator)) as SplineInterpolator);
		this.mTransforms = this.GetTransforms();
		if (this.HideOnExecute)
		{
			this.DisableTransforms();
		}
		if (this.AutoStart)
		{
			this.FollowSpline();
		}
	}

	// Token: 0x0600105E RID: 4190 RVA: 0x00066C70 File Offset: 0x00064E70
	private void SetupSplineInterpolator(SplineInterpolator interp, Transform[] trans)
	{
		interp.Reset();
		float num = (!this.AutoClose) ? (this.Duration / (float)(trans.Length - 1)) : (this.Duration / (float)trans.Length);
		int i;
		for (i = 0; i < trans.Length; i++)
		{
			if (this.OrientationMode == eOrientationMode.NODE)
			{
				interp.AddPoint(trans[i].position, trans[i].rotation, num * (float)i, new Vector2(0f, 1f));
			}
			else if (this.OrientationMode == eOrientationMode.TANGENT)
			{
				Quaternion quat;
				if (i != trans.Length - 1)
				{
					quat = Quaternion.LookRotation(trans[i + 1].position - trans[i].position, trans[i].up);
				}
				else if (this.AutoClose)
				{
					quat = Quaternion.LookRotation(trans[0].position - trans[i].position, trans[i].up);
				}
				else
				{
					quat = trans[i].rotation;
				}
				interp.AddPoint(trans[i].position, quat, num * (float)i, new Vector2(0f, 1f));
			}
		}
		if (this.AutoClose)
		{
			interp.SetAutoCloseMode(num * (float)i);
		}
	}

	// Token: 0x0600105F RID: 4191 RVA: 0x00066DB0 File Offset: 0x00064FB0
	private Transform[] GetTransforms()
	{
		if (this.SplineRoot != null)
		{
			List<Component> list = new List<Component>(this.SplineRoot.GetComponentsInChildren(typeof(Transform)));
			List<Transform> list2 = list.ConvertAll<Transform>((Component c) => (Transform)c);
			list2.Remove(this.SplineRoot.transform);
			list2.Sort((Transform a, Transform b) => a.name.CompareTo(b.name));
			return list2.ToArray();
		}
		return null;
	}

	// Token: 0x06001060 RID: 4192 RVA: 0x0000CFD2 File Offset: 0x0000B1D2
	private void DisableTransforms()
	{
		if (this.SplineRoot != null)
		{
			this.SplineRoot.SetActive(false);
		}
	}

	// Token: 0x06001061 RID: 4193 RVA: 0x0000CFF1 File Offset: 0x0000B1F1
	private void FollowSpline()
	{
		if (this.mTransforms.Length > 0)
		{
			this.SetupSplineInterpolator(this.mSplineInterp, this.mTransforms);
			this.mSplineInterp.StartInterpolation(null, true, this.WrapMode);
		}
	}

	// Token: 0x04000F9D RID: 3997
	public GameObject SplineRoot;

	// Token: 0x04000F9E RID: 3998
	public float Duration = 10f;

	// Token: 0x04000F9F RID: 3999
	public eOrientationMode OrientationMode;

	// Token: 0x04000FA0 RID: 4000
	public eWrapMode WrapMode;

	// Token: 0x04000FA1 RID: 4001
	public bool AutoStart = true;

	// Token: 0x04000FA2 RID: 4002
	public bool AutoClose = true;

	// Token: 0x04000FA3 RID: 4003
	public bool HideOnExecute = true;

	// Token: 0x04000FA4 RID: 4004
	private SplineInterpolator mSplineInterp;

	// Token: 0x04000FA5 RID: 4005
	private Transform[] mTransforms;
}

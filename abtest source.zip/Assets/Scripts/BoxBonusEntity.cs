﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000D4 RID: 212
public class BoxBonusEntity : BonusEntity
{
	// Token: 0x06000596 RID: 1430 RVA: 0x0002C5CC File Offset: 0x0002A7CC
	public BoxBonusEntity()
	{
		this.m_pRace = null;
	}

	// Token: 0x06000597 RID: 1431 RVA: 0x0002C664 File Offset: 0x0002A864
	public override void Awake()
	{
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
		{
			UnityEngine.Object.Destroy(base.gameObject.transform.parent.gameObject);
		}
		else
		{
			base.Awake();
			base.renderer.enabled = true;
			this.m_pCollider.enabled = true;
			this.m_bActive = true;
			this.m_pRace = (UnityEngine.Object.FindObjectOfType(typeof(RcRace)) as RcRace);
			this._particleEffect = (GameObject)UnityEngine.Object.Instantiate(this.ParticleEffect);
			this._particleEffect.transform.parent = base.transform;
			this._particleEffect.transform.localPosition = Vector3.zero;
		}
	}

	// Token: 0x06000598 RID: 1432 RVA: 0x00006013 File Offset: 0x00004213
	public override void Start()
	{
		base.animation["BoxBonusEntityStand"].normalizedTime = (float)Singleton<RandomManager>.Instance.NextDouble();
	}

	// Token: 0x06000599 RID: 1433 RVA: 0x00005D9A File Offset: 0x00003F9A
	public override void Update()
	{
		base.Update();
	}

	// Token: 0x0600059A RID: 1434 RVA: 0x0002C720 File Offset: 0x0002A920
	public override void OnTriggerEnter(Collider other)
	{
		int num = 1 << other.gameObject.layer;
		if ((num & this.layer) != 0)
		{
			Kart componentInChildren = other.gameObject.GetComponentInChildren<Kart>();
			if (componentInChildren)
			{
				this._particleEffect.particleSystem.Play();
				base.OnTriggerEnter(other);
			}
		}
	}

	// Token: 0x0600059B RID: 1435 RVA: 0x0002C780 File Offset: 0x0002A980
	public override void DoOnTriggerEnter(GameObject other, int otherlayer)
	{
		if (other != null)
		{
			Kart componentInChildren = other.GetComponentInChildren<Kart>();
			if (componentInChildren)
			{
				componentInChildren.KartSound.PlaySound(10);
				if (this.m_bActive && componentInChildren.GetBonusMgr().CanGetItem())
				{
					this.GiveItem(componentInChildren);
				}
			}
		}
		if (this.ReactivationDelay > 0f)
		{
			this.SetActive(false);
		}
	}

	// Token: 0x0600059C RID: 1436 RVA: 0x0002C7F4 File Offset: 0x0002A9F4
	public void GiveItem(Kart pKart)
	{
		if (pKart == null || pKart.GetBonusMgr() == null)
		{
			return;
		}
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
		{
			TutorialGameMode tutorialGameMode = (TutorialGameMode)Singleton<GameManager>.Instance.GameMode;
			if (tutorialGameMode.WannaItem)
			{
				pKart.GetBonusMgr().SetItem(tutorialGameMode.DesiredItem, 0);
				tutorialGameMode.GotItem(tutorialGameMode.DesiredItem);
			}
		}
		RcVehicleRaceStats raceStats = pKart.RaceStats;
		int rank = raceStats.GetRank();
		if (rank >= 6)
		{
		}
		bool flag = pKart.GetControlType() == RcVehicle.ControlType.AI;
		int iQuantity = 1;
		if (!flag)
		{
			int num = UnityEngine.Random.Range(0, 101);
			if (num < this.ThreeBonusChance[rank])
			{
				iQuantity = 3;
			}
			else if (num < this.ThreeBonusChance[rank] + this.TwoBonusChance[rank])
			{
				iQuantity = 2;
			}
		}
		EAdvantage selectedAdvantage = pKart.SelectedAdvantage;
		if (selectedAdvantage >= PlayerConfig.FirstAdvantageBonus && selectedAdvantage <= PlayerConfig.LastAdvantageBonus && UnityEngine.Random.Range(0, 3) == 0)
		{
			switch (selectedAdvantage)
			{
			case EAdvantage.LasagnaBonus:
				pKart.GetBonusMgr().SetItem(EITEM.ITEM_LASAGNA, iQuantity);
				break;
			case EAdvantage.SpringBonus:
				pKart.GetBonusMgr().SetItem(EITEM.ITEM_SPRING, 0);
				break;
			case EAdvantage.PieBonus:
				pKart.GetBonusMgr().SetItem(EITEM.ITEM_PIE, iQuantity);
				break;
			}
			return;
		}
		int[] array;
		if (flag)
		{
			array = this.BonusRatioAI;
		}
		else
		{
			array = this.BonusRatio;
		}
		int num2 = rank * Enum.GetValues(typeof(EBonusCategory)).Length;
		if (!flag && raceStats.GetDistToEndOfRace() - raceStats.GetPreceding().RaceStats.GetDistToEndOfRace() > this.LostDistance)
		{
			int[] array2 = new int[Enum.GetValues(typeof(EBonusCategory)).Length];
			int num3 = 0;
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i] = array[num2 + i];
			}
			foreach (EITEM eitem in this.DoNotGiveToLostPlayers)
			{
				num3 += array2[eitem - EITEM.ITEM_PIE];
				array2[eitem - EITEM.ITEM_PIE] = 0;
			}
			num3 = num3 / this.MoreToLostPlayers.Count + 1;
			foreach (EITEM eitem2 in this.MoreToLostPlayers)
			{
				array2[eitem2 - EITEM.ITEM_PIE] += num3;
			}
			array = array2;
			num2 = 0;
		}
		int num4 = UnityEngine.Random.Range(1, 101);
		int num5 = 0;
		for (int j = 0; j < Enum.GetValues(typeof(EBonusCategory)).Length; j++)
		{
			num5 += array[num2 + j];
			if (num4 <= num5)
			{
				switch (j)
				{
				case 0:
					pKart.GetBonusMgr().SetItem(EITEM.ITEM_PIE, iQuantity);
					return;
				case 1:
					pKart.GetBonusMgr().SetItem(EITEM.ITEM_AUTOLOCK_PIE, iQuantity);
					return;
				case 2:
					pKart.GetBonusMgr().SetItem(EITEM.ITEM_SPRING, 0);
					return;
				case 3:
					pKart.GetBonusMgr().SetItem(EITEM.ITEM_LASAGNA, iQuantity);
					return;
				case 4:
					pKart.GetBonusMgr().SetItem(EITEM.ITEM_DIAMOND, 0);
					return;
				case 5:
					if (!Singleton<BonusMgr>.Instance.UfoLaunched)
					{
						pKart.GetBonusMgr().SetItem(EITEM.ITEM_UFO, 0);
						return;
					}
					pKart.GetBonusMgr().SetItem(EITEM.ITEM_PARFUME, 0);
					return;
				case 6:
					pKart.GetBonusMgr().SetItem(EITEM.ITEM_NAP, 0);
					return;
				case 7:
					pKart.GetBonusMgr().SetItem(EITEM.ITEM_PARFUME, 0);
					return;
				case 8:
					pKart.GetBonusMgr().SetItem(EITEM.ITEM_MAGIC, iQuantity);
					return;
				}
			}
		}
	}

	// Token: 0x04000571 RID: 1393
	public float LostDistance = 200f;

	// Token: 0x04000572 RID: 1394
	public List<EITEM> DoNotGiveToLostPlayers = new List<EITEM>();

	// Token: 0x04000573 RID: 1395
	public List<EITEM> MoreToLostPlayers = new List<EITEM>();

	// Token: 0x04000574 RID: 1396
	[SerializeField]
	public int[] TwoBonusChance = new int[6];

	// Token: 0x04000575 RID: 1397
	[SerializeField]
	public int[] ThreeBonusChance = new int[6];

	// Token: 0x04000576 RID: 1398
	[SerializeField]
	public int[] BonusRatio = new int[6 * Enum.GetValues(typeof(EBonusCategory)).Length];

	// Token: 0x04000577 RID: 1399
	[SerializeField]
	public int[] BonusRatioAI = new int[6 * Enum.GetValues(typeof(EBonusCategory)).Length];

	// Token: 0x04000578 RID: 1400
	public LayerMask layer;

	// Token: 0x04000579 RID: 1401
	public GameObject ParticleEffect;

	// Token: 0x0400057A RID: 1402
	private GameObject _particleEffect;

	// Token: 0x0400057B RID: 1403
	protected RcRace m_pRace;
}

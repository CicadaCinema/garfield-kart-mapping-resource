﻿using System;
using UnityEngine;

// Token: 0x0200024A RID: 586
public interface IBezierCurveManager
{
	// Token: 0x0600104D RID: 4173
	Vector3 GetPositionAtTime(float time);

	// Token: 0x0600104E RID: 4174
	Vector3 GetPositionAtDistance(float distance, float time);
}

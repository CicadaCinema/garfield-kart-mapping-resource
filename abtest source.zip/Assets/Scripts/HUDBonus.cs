﻿using System;
using UnityEngine;

// Token: 0x02000102 RID: 258
public class HUDBonus : MonoBehaviour
{
	// Token: 0x1700010E RID: 270
	// (get) Token: 0x060006FA RID: 1786 RVA: 0x00006F7C File Offset: 0x0000517C
	public int LogBonus
	{
		get
		{
			return this.m_iLogBonus;
		}
	}

	// Token: 0x1700010F RID: 271
	// (get) Token: 0x060006FB RID: 1787 RVA: 0x00006F84 File Offset: 0x00005184
	public int LogUsed
	{
		get
		{
			return this.m_iLogUsed;
		}
	}

	// Token: 0x17000110 RID: 272
	// (get) Token: 0x060006FC RID: 1788 RVA: 0x00006F8C File Offset: 0x0000518C
	public int LogUsedBack
	{
		get
		{
			return this.m_iLogUsedBack;
		}
	}

	// Token: 0x060006FD RID: 1789 RVA: 0x00034A98 File Offset: 0x00032C98
	public void OnDestroy()
	{
		if (this.BonusSlots != null)
		{
			for (int i = 0; i < this.BonusSlots.Length; i++)
			{
				if (this.BonusSlots[i] != null)
				{
					BonusAnimation bonusAnimation = this.BonusSlots[i];
					bonusAnimation.OnAnimationFinished = (Action<int>)Delegate.Remove(bonusAnimation.OnAnimationFinished, new Action<int>(this.AnimationFinished));
					BonusAnimation bonusAnimation2 = this.BonusSlots[i];
					bonusAnimation2.InformSwapOk = (Action)Delegate.Remove(bonusAnimation2.InformSwapOk, new Action(this.OnSwapOk));
					BonusAnimation bonusAnimation3 = this.BonusSlots[i];
					bonusAnimation3.InformLaunchFinished = (Action)Delegate.Remove(bonusAnimation3.InformLaunchFinished, new Action(this.OnLaunchFinished));
				}
			}
		}
	}

	// Token: 0x060006FE RID: 1790 RVA: 0x00034B58 File Offset: 0x00032D58
	public void Awake()
	{
		for (int i = 0; i < this.BonusSlots.Length; i++)
		{
			this.BonusSlots[i] = null;
		}
		this.BonusSlots = base.gameObject.GetComponentsInChildren<BonusAnimation>();
		foreach (BonusAnimation bonusAnimation in this.BonusSlots)
		{
			BonusAnimation bonusAnimation2 = bonusAnimation;
			bonusAnimation2.OnAnimationFinished = (Action<int>)Delegate.Combine(bonusAnimation2.OnAnimationFinished, new Action<int>(this.AnimationFinished));
			BonusAnimation bonusAnimation3 = bonusAnimation;
			bonusAnimation3.InformSwapOk = (Action)Delegate.Combine(bonusAnimation3.InformSwapOk, new Action(this.OnSwapOk));
			BonusAnimation bonusAnimation4 = bonusAnimation;
			bonusAnimation4.InformLaunchFinished = (Action)Delegate.Combine(bonusAnimation4.InformLaunchFinished, new Action(this.OnLaunchFinished));
		}
		this.DropBonus = GameObject.Find("Drop");
		GameObject gameObject = GameObject.Find("DropBackground");
		if (gameObject)
		{
			this.ArrowAnim = gameObject.GetComponent<Animation>();
		}
		if (this.DropBonus != null)
		{
			this.DropBonus.SetActive(false);
		}
		this.Slot = GameObject.Find("MainSlotBackground");
		if (this.Slot)
		{
			this.Slot1BackAnim = this.Slot.GetComponent<Animation>();
			this.Slot1Sprite = this.Slot.GetComponent<UISprite>();
			this.Slot1TexturePattern = this.Slot.GetComponent<UITexturePattern>();
		}
		this.Quantity = GameObject.Find("Quantity");
		if (this.Quantity != null)
		{
			this.Quantity.SetActive(false);
			this.m_pQuantity = this.Quantity.GetComponent<UILabel>();
		}
		GameObject gameObject2 = GameObject.Find("Slot2Background");
		if (gameObject2)
		{
			this.Slot2BackAnim = gameObject2.GetComponent<Animation>();
			this.Slot2Sprite = gameObject2.GetComponent<UISprite>();
		}
		gameObject2 = GameObject.Find("BackgroundSlot2");
		if (gameObject2)
		{
			this.Slot2ItemAnim = gameObject2.GetComponent<Animation>();
			this.Slot2SpriteItem = gameObject2.GetComponent<UISprite>();
		}
		GameObject gameObject3 = GameObject.Find("BackgroundSlot1");
		if (gameObject3)
		{
			this.Slot1ItemAnim = gameObject3.GetComponent<Animation>();
			this.Slot1SpriteItem = gameObject3.GetComponent<UISprite>();
		}
		if (this.Slot1Sprite && this.Slot2Sprite && this.Slot1TexturePattern)
		{
			this.Slot1Sprite.alpha = 0.1f;
			this.Slot2Sprite.alpha = 0.1f;
			this.Slot1TexturePattern.ChangeTexture(0);
		}
		this.m_iIndexToAffectSlot1 = -1;
		this.m_iIndexToAffectSlot2 = -1;
	}

	// Token: 0x060006FF RID: 1791 RVA: 0x00034E00 File Offset: 0x00033000
	private void AnimationFinished(int _SlotIndex)
	{
		if (this.OnAnimationFinished != null)
		{
			this.OnAnimationFinished(_SlotIndex);
			Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.BonusEarned);
		}
		if (_SlotIndex == 0 && this.DropBonus != null && this.ShowBehind)
		{
			this.DropBonus.SetActive(true);
			this.ShowBehind = false;
		}
		if (_SlotIndex == 0 && this.Slot1TexturePattern)
		{
			this.Slot1TexturePattern.ChangeTexture(1);
		}
	}

	// Token: 0x06000700 RID: 1792 RVA: 0x00034E8C File Offset: 0x0003308C
	public void StartAnimation(int _Index, EITEM _Item)
	{
		if (_Index >= 0 && _Index < this.BonusSlots.Length && this.BonusSlots[_Index] != null)
		{
			if (_Index == 1)
			{
				if (this.Slot2ItemAnim.isPlaying && this.m_iIndexToAffectSlot1 == -1)
				{
					this.ResetSlot2();
				}
				if (this.Slot2ItemAnim.isPlaying && this.m_iIndexToAffectSlot1 != -1)
				{
					this.ForceSwap();
				}
			}
			else if (_Index == 0 && this.Slot1ItemAnim.isPlaying)
			{
				this.ResetSlot1();
			}
			UISprite uisprite;
			UISprite uisprite2;
			if (_Index == 0)
			{
				uisprite = this.Slot1Sprite;
				uisprite2 = this.Slot1SpriteItem;
			}
			else
			{
				uisprite = this.Slot2Sprite;
				uisprite2 = this.Slot2SpriteItem;
			}
			if (uisprite && uisprite2)
			{
				uisprite.alpha = 1f;
				uisprite2.alpha = 1f;
			}
			this.BonusSlots[_Index].Launch(_Item);
			this.ShowBehind = KartBonus.IsBehind(_Item);
			if (LogManager.Instance != null)
			{
				this.m_iLogBonus++;
			}
		}
	}

	// Token: 0x06000701 RID: 1793 RVA: 0x00006F94 File Offset: 0x00005194
	public void ResetSlot(int _Index)
	{
		if (_Index >= 0 && _Index < this.BonusSlots.Length && this.BonusSlots[_Index] != null)
		{
			this.BonusSlots[_Index].Reset();
		}
	}

	// Token: 0x06000702 RID: 1794 RVA: 0x00006FCB File Offset: 0x000051CB
	public void DeactivateSlot(int _Index)
	{
		if (_Index >= 0 && _Index < this.BonusSlots.Length && this.BonusSlots[_Index] != null)
		{
			this.BonusSlots[_Index].Deactivate();
		}
	}

	// Token: 0x06000703 RID: 1795 RVA: 0x00034FB8 File Offset: 0x000331B8
	public void Launch(int _Index, bool _Behind)
	{
		if (_Index >= 0 && _Index < this.BonusSlots.Length && this.BonusSlots[_Index] != null)
		{
			if (this.m_iIndexToAffectSlot1 != -1)
			{
				this.ForceSwap();
			}
			if (_Index == 0 && this.DropBonus != null)
			{
				this.DropBonus.SetActive(false);
				this.ShowBehind = false;
				this.Slot1TexturePattern.ChangeTexture(0);
				this.Slot1BackAnim.Play("Slot_Used");
				bool flag = KartBonus.IsBehind(this.BonusSlots[_Index].WantedBonus) && _Behind;
				this.Slot1ItemAnim.PlayQueued((!flag) ? "Bonus_Used_Front" : "Bonus_Used_Back", QueueMode.CompleteOthers, PlayMode.StopAll);
				if (LogManager.Instance != null)
				{
					this.m_iLogUsed++;
					if (flag)
					{
						this.m_iLogUsedBack++;
					}
				}
			}
		}
	}

	// Token: 0x06000704 RID: 1796 RVA: 0x000350B4 File Offset: 0x000332B4
	public void AffectSlot(int _Index, int _Index2, bool _Behind)
	{
		if (_Index >= 0 && _Index < this.BonusSlots.Length && this.BonusSlots[_Index] != null && _Index2 >= 0 && _Index2 < this.BonusSlots.Length && this.BonusSlots[_Index2] != null)
		{
			this.Slot2ItemAnim.Rewind();
			this.Slot2BackAnim.Rewind();
			this.Slot2ItemAnim.PlayQueued("Bonus2_Swap", QueueMode.PlayNow);
			this.Slot2BackAnim.PlayQueued("Slot2_Swap", QueueMode.PlayNow);
			this.Launch(_Index, _Behind);
			this.m_iIndexToAffectSlot1 = _Index;
			this.m_iIndexToAffectSlot2 = _Index2;
		}
	}

	// Token: 0x06000705 RID: 1797 RVA: 0x00035164 File Offset: 0x00033364
	public void SetQuantity(int _Quantity)
	{
		if (this.Quantity && this.m_pQuantity)
		{
			if (_Quantity <= 1 && this.Quantity.activeSelf)
			{
				this.Quantity.SetActive(false);
			}
			else if (_Quantity > 1)
			{
				if (!this.Quantity.activeSelf)
				{
					this.Quantity.SetActive(true);
				}
				this.m_pQuantity.text = "x " + _Quantity;
			}
		}
	}

	// Token: 0x06000706 RID: 1798 RVA: 0x00007002 File Offset: 0x00005202
	public void OnBonus()
	{
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			Singleton<InputManager>.Instance.NullSafeAct(new Action<EAction, float>(Singleton<InputManager>.Instance.SetAction), EAction.LaunchBonus, 1f);
		}
	}

	// Token: 0x06000707 RID: 1799 RVA: 0x0000703B File Offset: 0x0000523B
	public void OnDropBonus()
	{
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			Singleton<InputManager>.Instance.NullSafeAct(new Action<EAction, float>(Singleton<InputManager>.Instance.SetAction), EAction.DropBonus, 1f);
		}
	}

	// Token: 0x06000708 RID: 1800 RVA: 0x00007074 File Offset: 0x00005274
	public void OnLaunchFinished()
	{
		this.Slot1SpriteItem.alpha = 0f;
		if (this.m_iIndexToAffectSlot1 == -1)
		{
			this.Slot1Sprite.alpha = 0.1f;
		}
		this.ResetSlot1();
	}

	// Token: 0x06000709 RID: 1801 RVA: 0x000351F8 File Offset: 0x000333F8
	public void OnSwapOk()
	{
		this.Slot2Sprite.alpha = 0.1f;
		this.BonusSlots[this.m_iIndexToAffectSlot1].Affect(this.BonusSlots[this.m_iIndexToAffectSlot2]);
		this.ShowBehind = KartBonus.IsBehind(this.BonusSlots[this.m_iIndexToAffectSlot1].WantedBonus);
		this.ChangeArrowTexture();
		this.Slot2SpriteItem.alpha = 0f;
		this.Slot1SpriteItem.alpha = 1f;
		this.ResetSlot(this.m_iIndexToAffectSlot2);
		this.m_iIndexToAffectSlot1 = -1;
		this.m_iIndexToAffectSlot2 = -1;
		this.ArrowAnim.Play("DropArrow_Turn");
		this.Slot1ItemAnim.Play("Bonus_Swapped");
	}

	// Token: 0x0600070A RID: 1802 RVA: 0x000352B4 File Offset: 0x000334B4
	public void ForceSwap()
	{
		this.ResetSlot1();
		this.BonusSlots[this.m_iIndexToAffectSlot1].Affect(this.BonusSlots[this.m_iIndexToAffectSlot2]);
		this.ShowBehind = KartBonus.IsBehind(this.BonusSlots[this.m_iIndexToAffectSlot1].WantedBonus);
		this.ChangeArrowTexture();
		this.ResetSlot2();
		this.Slot1SpriteItem.alpha = 1f;
		this.m_iIndexToAffectSlot1 = -1;
		this.m_iIndexToAffectSlot2 = -1;
		this.ArrowAnim.Play("DropArrow_Turn");
		this.Slot1ItemAnim.Play("Bonus_Swapped");
	}

	// Token: 0x0600070B RID: 1803 RVA: 0x00035350 File Offset: 0x00033550
	public void ChangeArrowTexture()
	{
		if (this.BonusSlots[this.m_iIndexToAffectSlot1].State == BonusAnimation_State.STOPPED && this.m_iIndexToAffectSlot1 == 0 && this.DropBonus != null)
		{
			this.DropBonus.SetActive(KartBonus.IsBehind(this.BonusSlots[0].WantedBonus));
			this.ShowBehind = false;
			if (this.Slot1TexturePattern)
			{
				this.Slot1TexturePattern.ChangeTexture(1);
			}
		}
	}

	// Token: 0x0600070C RID: 1804 RVA: 0x000353D0 File Offset: 0x000335D0
	public void ResetSlot1()
	{
		this.ResetSlot(0);
		this.Slot1ItemAnim.Play("Bonus_Used_Front");
		this.Slot1ItemAnim.Rewind();
		this.Slot1ItemAnim.Play();
		this.Slot1ItemAnim.Sample();
		this.Slot1ItemAnim.Stop();
	}

	// Token: 0x0600070D RID: 1805 RVA: 0x00035424 File Offset: 0x00033624
	public void ResetSlot2()
	{
		this.Slot2Sprite.alpha = 0.1f;
		this.Slot2SpriteItem.alpha = 0f;
		this.ResetSlot(1);
		this.Slot2ItemAnim.Rewind();
		this.Slot2ItemAnim.Play();
		this.Slot2ItemAnim.Sample();
		this.Slot2ItemAnim.Stop();
		this.Slot2BackAnim.Rewind();
		this.Slot2BackAnim.Play();
		this.Slot2BackAnim.Sample();
		this.Slot2BackAnim.Stop();
	}

	// Token: 0x0600070E RID: 1806 RVA: 0x000354B4 File Offset: 0x000336B4
	public void ResetSlots()
	{
		this.ResetSlot1();
		this.ResetSlot2();
		this.DeactivateSlot(1);
		this.Slot1Sprite.alpha = 0.1f;
		this.Slot1SpriteItem.alpha = 0f;
		this.DropBonus.SetActive(false);
		this.ShowBehind = false;
		if (this.Slot1TexturePattern)
		{
			this.Slot1TexturePattern.ChangeTexture(0);
		}
		this.SetQuantity(0);
	}

	// Token: 0x040006E1 RID: 1761
	private BonusAnimation[] BonusSlots = new BonusAnimation[2];

	// Token: 0x040006E2 RID: 1762
	private GameObject DropBonus;

	// Token: 0x040006E3 RID: 1763
	private GameObject Slot;

	// Token: 0x040006E4 RID: 1764
	private GameObject Quantity;

	// Token: 0x040006E5 RID: 1765
	public Action<int> OnAnimationFinished;

	// Token: 0x040006E6 RID: 1766
	private bool ShowBehind;

	// Token: 0x040006E7 RID: 1767
	private UILabel m_pQuantity;

	// Token: 0x040006E8 RID: 1768
	private Animation Slot1BackAnim;

	// Token: 0x040006E9 RID: 1769
	private Animation Slot1ItemAnim;

	// Token: 0x040006EA RID: 1770
	private Animation Slot2BackAnim;

	// Token: 0x040006EB RID: 1771
	private Animation Slot2ItemAnim;

	// Token: 0x040006EC RID: 1772
	private Animation ArrowAnim;

	// Token: 0x040006ED RID: 1773
	private UITexturePattern Slot1TexturePattern;

	// Token: 0x040006EE RID: 1774
	private UISprite Slot1Sprite;

	// Token: 0x040006EF RID: 1775
	private UISprite Slot1SpriteItem;

	// Token: 0x040006F0 RID: 1776
	private UISprite Slot2Sprite;

	// Token: 0x040006F1 RID: 1777
	private UISprite Slot2SpriteItem;

	// Token: 0x040006F2 RID: 1778
	private int m_iIndexToAffectSlot1;

	// Token: 0x040006F3 RID: 1779
	private int m_iIndexToAffectSlot2;

	// Token: 0x040006F4 RID: 1780
	private int m_iLogBonus;

	// Token: 0x040006F5 RID: 1781
	private int m_iLogUsed;

	// Token: 0x040006F6 RID: 1782
	private int m_iLogUsedBack;
}

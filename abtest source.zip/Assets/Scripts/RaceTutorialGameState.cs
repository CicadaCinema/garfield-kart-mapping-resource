﻿using System;
using UnityEngine;

// Token: 0x02000170 RID: 368
public class RaceTutorialGameState : GameState
{
	// Token: 0x060009EB RID: 2539 RVA: 0x00045110 File Offset: 0x00043310
	public void Awake()
	{
		this.m_fStartTime = Time.time;
		GameEntryPoint.OnVehicleCreated = (Action)Delegate.Combine(GameEntryPoint.OnVehicleCreated, new Action(this.VehicleCreated));
		GameObject gameObject = GameObject.Find("Race");
		if (gameObject != null)
		{
			this.m_pRace = gameObject.GetComponent<RcRace>();
		}
	}

	// Token: 0x060009EC RID: 2540 RVA: 0x00008BE9 File Offset: 0x00006DE9
	public new void OnDestroy()
	{
		GameEntryPoint.OnVehicleCreated = (Action)Delegate.Remove(GameEntryPoint.OnVehicleCreated, new Action(this.VehicleCreated));
	}

	// Token: 0x060009ED RID: 2541 RVA: 0x00008C0B File Offset: 0x00006E0B
	private void VehicleCreated()
	{
		((InGameGameMode)this.m_pGameMode).VehicleCreated();
	}

	// Token: 0x060009EE RID: 2542 RVA: 0x0004516C File Offset: 0x0004336C
	public override void Enter()
	{
		Camera.main.GetComponent<CameraBase>().SwitchCamera(ECamState.Respawn, ECamState.TransCut);
		HUDInGame hud = Singleton<GameManager>.Instance.GameMode.Hud;
		if (hud != null)
		{
			hud.StartRace();
		}
		for (int i = 0; i < this.m_pGameMode.PlayerCount; i++)
		{
			Kart kart = this.m_pGameMode.GetKart(i);
			if (kart)
			{
				KartSound kartSound = kart.KartSound;
				if (kartSound != null)
				{
					kartSound.StartVoices();
				}
			}
		}
		for (int j = 0; j < this.m_pGameMode.PlayerCount; j++)
		{
			if (this.m_pGameMode.GetKart(j) != null)
			{
				Kart kart2 = this.m_pGameMode.GetKart(j);
				kart2.StartRace();
			}
		}
		if (this.m_pRace != null)
		{
			this.m_pRace.StartRace();
		}
		Singleton<GameManager>.Instance.GameMode.MainMusic.Play();
	}

	// Token: 0x060009EF RID: 2543 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void Exit()
	{
	}

	// Token: 0x060009F0 RID: 2544 RVA: 0x00045278 File Offset: 0x00043478
	public override void Update()
	{
		EVehiclePlacementState placeVehicles = ((InGameGameMode)this.m_pGameMode).PlaceVehicles;
		if (placeVehicles == EVehiclePlacementState.Init)
		{
			((InGameGameMode)this.m_pGameMode).ValidateAdvantage();
		}
		else if (placeVehicles == EVehiclePlacementState.ReadyToTeleport)
		{
			if (!this.m_bKeyPressed)
			{
				this.m_bKeyPressed = true;
			}
			if (this.m_bKeyPressed)
			{
				((InGameGameMode)this.m_pGameMode).TeleportVehiclesOnStartLine();
				this.m_bKeyPressed = false;
			}
		}
		else if (placeVehicles == EVehiclePlacementState.ReadyToStart && !this.m_bKeyPressed)
		{
			CameraBase component = Camera.main.GetComponent<CameraBase>();
			component.SwitchCamera(ECamState.Follow, ECamState.TransCut);
			this.m_bKeyPressed = true;
		}
		if (!((TutorialGameMode)this.m_pGameMode).Launched && this.Timer < Time.time - this.m_fStartTime)
		{
			((TutorialGameMode)this.m_pGameMode).FirstPanel();
		}
	}

	// Token: 0x04000A03 RID: 2563
	public float Timer = 1f;

	// Token: 0x04000A04 RID: 2564
	private bool m_bKeyPressed;

	// Token: 0x04000A05 RID: 2565
	private float m_fStartTime;

	// Token: 0x04000A06 RID: 2566
	private RcRace m_pRace;
}

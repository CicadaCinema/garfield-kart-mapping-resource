﻿using System;
using UnityEngine;

// Token: 0x020000DA RID: 218
public class KartBonusMgr : MonoBehaviour
{
	// Token: 0x170000F8 RID: 248
	// (get) Token: 0x060005C7 RID: 1479 RVA: 0x000061A5 File Offset: 0x000043A5
	// (set) Token: 0x060005C8 RID: 1480 RVA: 0x0002E7FC File Offset: 0x0002C9FC
	public HUDBonus HUDBonus
	{
		get
		{
			return this.m_pHudBonus;
		}
		set
		{
			if (this.m_pHudBonus != null)
			{
				HUDBonus pHudBonus = this.m_pHudBonus;
				pHudBonus.OnAnimationFinished = (Action<int>)Delegate.Remove(pHudBonus.OnAnimationFinished, new Action<int>(this.AnimationFinished));
			}
			this.m_pHudBonus = value;
			if (this.m_pHudBonus != null)
			{
				HUDBonus pHudBonus2 = this.m_pHudBonus;
				pHudBonus2.OnAnimationFinished = (Action<int>)Delegate.Combine(pHudBonus2.OnAnimationFinished, new Action<int>(this.AnimationFinished));
			}
		}
	}

	// Token: 0x170000F9 RID: 249
	// (get) Token: 0x060005C9 RID: 1481 RVA: 0x000061AD File Offset: 0x000043AD
	public PlayerCustom CustomMgr
	{
		get
		{
			return this.m_pCustomMgr;
		}
	}

	// Token: 0x060005CA RID: 1482 RVA: 0x0002E880 File Offset: 0x0002CA80
	public void Awake()
	{
		this.m_bActiveItem = false;
		for (int i = 0; i < 2; i++)
		{
			this.m_ItemTab[i] = new KartBonus();
		}
		if (this.m_pHudBonus != null)
		{
			this.m_pHudBonus.ResetSlots();
		}
	}

	// Token: 0x060005CB RID: 1483 RVA: 0x0002E8D0 File Offset: 0x0002CAD0
	public void OnDestroy()
	{
		if (this.m_pHudBonus != null)
		{
			HUDBonus pHudBonus = this.m_pHudBonus;
			pHudBonus.OnAnimationFinished = (Action<int>)Delegate.Remove(pHudBonus.OnAnimationFinished, new Action<int>(this.AnimationFinished));
		}
		if (this.m_pBonusEffectMgr != null)
		{
			this.m_pBonusEffectMgr.Dispose();
			this.m_pBonusEffectMgr = null;
		}
	}

	// Token: 0x060005CC RID: 1484 RVA: 0x0002E934 File Offset: 0x0002CB34
	public void Start()
	{
		this.m_pParent = base.gameObject.transform.parent.FindChild("Tunning").GetComponent<Kart>();
		this.m_pBonusEffectMgr = new BonusEffectMgr(this.m_pParent);
		this.m_pBonusEffectMgr.Start();
		this.m_pCustomMgr = base.transform.parent.FindChild("Base").GetComponent<PlayerCustom>();
		this.netView = base.networkView;
		this.m_bShowNapFadeIn = (base.transform.parent.GetComponentInChildren<Kart>().GetControlType() == RcVehicle.ControlType.Human);
	}

	// Token: 0x060005CD RID: 1485 RVA: 0x0002E9CC File Offset: 0x0002CBCC
	public void Update()
	{
		float deltaTime = Time.deltaTime;
		this.m_pBonusEffectMgr.Update();
		for (int i = 0; i < this.m_ItemTab.Length; i++)
		{
			if (this.m_ItemTab[i].m_bAnimated)
			{
				this.m_ItemTab[i].m_fSecureAnimationTimer += deltaTime;
				if (this.m_ItemTab[i].m_fSecureAnimationTimer > 5f)
				{
					this.m_ItemTab[i].m_bAnimated = false;
					this.m_ItemTab[i].m_fSecureAnimationTimer = 0f;
				}
			}
		}
	}

	// Token: 0x060005CE RID: 1486 RVA: 0x000061B5 File Offset: 0x000043B5
	public void ResetItems()
	{
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoResetItems();
		}
		else if (this.netView.isMine)
		{
			this.netView.RPC("DoResetItems", RPCMode.All, new object[0]);
		}
	}

	// Token: 0x060005CF RID: 1487 RVA: 0x0002EA64 File Offset: 0x0002CC64
	[RPC]
	public void DoResetItems()
	{
		for (int i = 0; i < 2; i++)
		{
			this.m_ItemTab[i].Reset();
		}
		this.m_bActiveItem = false;
		if (this.m_pHudBonus != null)
		{
			this.m_pHudBonus.ResetSlots();
		}
	}

	// Token: 0x060005D0 RID: 1488 RVA: 0x000061F3 File Offset: 0x000043F3
	public void Respawn()
	{
		this.ResetItems();
		if (this.m_pBonusEffectMgr != null)
		{
			this.m_pBonusEffectMgr.Reset();
		}
	}

	// Token: 0x060005D1 RID: 1489 RVA: 0x00006211 File Offset: 0x00004411
	public EITEM GetItem(int _Index)
	{
		if (_Index >= 0 && _Index < 2)
		{
			return this.m_ItemTab[_Index].m_eItem;
		}
		return EITEM.ITEM_NONE;
	}

	// Token: 0x060005D2 RID: 1490 RVA: 0x00006230 File Offset: 0x00004430
	public int GetItemQuantity(int _Index)
	{
		if (_Index >= 0 && _Index < 2)
		{
			return this.m_ItemTab[_Index].m_iQuantity;
		}
		return 0;
	}

	// Token: 0x060005D3 RID: 1491 RVA: 0x0002EAB4 File Offset: 0x0002CCB4
	public void SetItem(EITEM _item, int iQuantity)
	{
		if (Network.isServer)
		{
			this.netView.RPC("DoSetItem", RPCMode.All, new object[]
			{
				(int)_item,
				this.m_pHudBonus != null || this.m_pParent.GetControlType() == RcVehicle.ControlType.Net,
				iQuantity
			});
		}
		else if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoSetItem((int)_item, this.m_pHudBonus != null, iQuantity);
		}
	}

	// Token: 0x060005D4 RID: 1492 RVA: 0x0002EB44 File Offset: 0x0002CD44
	[RPC]
	public void DoSetItem(int item, bool needToWaitAnim, int iQuantity)
	{
		if (item >= 0 && item < 10)
		{
			bool flag = false;
			for (int i = 0; i < 2; i++)
			{
				if (this.m_ItemTab[i].m_eItem == EITEM.ITEM_NONE && !flag)
				{
					if (item == 6)
					{
						Singleton<BonusMgr>.Instance.UfoLaunched = true;
					}
					else if (this.m_ItemTab[i].m_eItem == EITEM.ITEM_UFO)
					{
						Singleton<BonusMgr>.Instance.UfoLaunched = false;
					}
					this.m_ItemTab[i].m_eItem = (EITEM)item;
					EITEM item2 = (EITEM)item;
					if (item == 2)
					{
						item2 = EITEM.ITEM_PIE;
					}
					this.m_ItemTab[i].m_iQuantity = Math.Max(iQuantity, (int)this.GetBonusValue(item2, EBonusCustomEffect.QUANTITY));
					this.m_ItemTab[i].m_bAnimated = true;
					this.m_ItemTab[i].m_fSecureAnimationTimer = 0f;
					if (this.m_pHudBonus != null)
					{
						this.m_pHudBonus.StartAnimation(i, (EITEM)item);
					}
					else if (!needToWaitAnim)
					{
						this.m_ItemTab[i].m_bAnimated = false;
						this.m_ItemTab[i].m_fSecureAnimationTimer = 0f;
						this.m_bActiveItem = true;
					}
					break;
				}
				if (this.m_ItemTab[i].m_bAnimated)
				{
					flag = true;
				}
			}
		}
	}

	// Token: 0x060005D5 RID: 1493 RVA: 0x0002EC84 File Offset: 0x0002CE84
	public void AnimationFinished(int _SlotIndex)
	{
		if (Network.peerType != NetworkPeerType.Disconnected)
		{
			this.netView.RPC("DoAnimationFinished", RPCMode.All, new object[]
			{
				_SlotIndex
			});
		}
		else if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoAnimationFinished(_SlotIndex);
		}
	}

	// Token: 0x060005D6 RID: 1494 RVA: 0x0002ECD4 File Offset: 0x0002CED4
	[RPC]
	public void DoAnimationFinished(int _SlotIndex)
	{
		for (int i = 0; i < 2; i++)
		{
			if (this.m_ItemTab[_SlotIndex].m_bAnimated)
			{
				this.m_ItemTab[_SlotIndex].m_bAnimated = false;
				this.m_ItemTab[_SlotIndex].m_fSecureAnimationTimer = 0f;
				this.m_bActiveItem = true;
				if (this.m_pHudBonus != null && _SlotIndex == 0)
				{
					this.m_pHudBonus.SetQuantity(this.GetItemQuantity(_SlotIndex));
				}
			}
		}
	}

	// Token: 0x060005D7 RID: 1495 RVA: 0x0000624F File Offset: 0x0000444F
	public BonusEffectMgr GetBonusEffectMgr()
	{
		return this.m_pBonusEffectMgr;
	}

	// Token: 0x060005D8 RID: 1496 RVA: 0x00006257 File Offset: 0x00004457
	public float GetBonusValue(EITEM _item, EBonusCustomEffect _effect)
	{
		if (this.m_pCustomMgr == null)
		{
			return 0f;
		}
		return this.m_pCustomMgr.GetBonusValue(_item, _effect);
	}

	// Token: 0x060005D9 RID: 1497 RVA: 0x0002ED58 File Offset: 0x0002CF58
	public void ActivateBonus(bool _Behind)
	{
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoActivateBonus(_Behind);
		}
		else if (this.netView.isMine)
		{
			this.netView.RPC("DoActivateBonus", RPCMode.All, new object[]
			{
				_Behind
			});
		}
	}

	// Token: 0x060005DA RID: 1498 RVA: 0x0002EDAC File Offset: 0x0002CFAC
	[RPC]
	public void DoActivateBonus(bool _Behind)
	{
		if (!this.m_pParent.IsOnGround() && !this.m_pParent.GetState(RcVehicle.eVehicleState.S_IS_RUNNING))
		{
			return;
		}
		if (!this.m_bActiveItem)
		{
			return;
		}
		EITEM l_Item = this.m_ItemTab[0].m_eItem;
		if (this.m_ItemTab[0].m_iQuantity < 2)
		{
			bool flag = false;
			for (int j = 1; j < 2; j++)
			{
				EITEM eItem = this.m_ItemTab[j].m_eItem;
				if (eItem != EITEM.ITEM_NONE)
				{
					this.m_ItemTab[j - 1].Affect(this.m_ItemTab[j]);
					if (this.m_pHudBonus != null)
					{
						this.m_pHudBonus.AffectSlot(j - 1, j, _Behind);
					}
					this.m_ItemTab[j].Reset();
					if (eItem == EITEM.ITEM_UFO)
					{
						Singleton<BonusMgr>.Instance.UfoLaunched = true;
					}
					else if (l_Item == EITEM.ITEM_NAP && this.m_bShowNapFadeIn && NapBonusEffect.OnLaunched != null)
					{
						NapBonusEffect.OnLaunched();
					}
					flag = true;
				}
			}
			if (!flag)
			{
				this.m_ItemTab[0].Reset();
				if (l_Item == EITEM.ITEM_UFO)
				{
					Singleton<BonusMgr>.Instance.UfoLaunched = true;
				}
				else if (l_Item == EITEM.ITEM_NAP && this.m_bShowNapFadeIn && NapBonusEffect.OnLaunched != null)
				{
					NapBonusEffect.OnLaunched();
				}
				if (this.m_pHudBonus != null)
				{
					this.m_pHudBonus.Launch(0, _Behind);
				}
				this.m_bActiveItem = false;
			}
			else if (!flag && this.m_ItemTab[0].m_bAnimated)
			{
				this.m_bActiveItem = false;
			}
		}
		else
		{
			this.m_ItemTab[0].m_iQuantity--;
		}
		if (Singleton<ChallengeManager>.Instance.IsActive && this.m_pParent.GetControlType() == RcVehicle.ControlType.Human)
		{
			Singleton<ChallengeManager>.Instance.Notify(EChallengeSingleRaceObjective.NoBonus);
		}
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
		{
			((TutorialGameMode)Singleton<GameManager>.Instance.GameMode).UsedBonus(l_Item, _Behind);
		}
		Singleton<BonusMgr>.Instance.NullSafe(delegate(BonusMgr i)
		{
			i.RequestBonus(l_Item, this.m_pParent, _Behind);
		});
		if (this.OnLaunchBonus != null)
		{
			this.OnLaunchBonus(l_Item, _Behind);
		}
		if (this.m_pHudBonus != null)
		{
			this.m_pHudBonus.SetQuantity(this.GetItemQuantity(0));
		}
	}

	// Token: 0x060005DB RID: 1499 RVA: 0x0002F050 File Offset: 0x0002D250
	public bool CanGetItem()
	{
		for (int i = 0; i < 2; i++)
		{
			if (this.m_ItemTab[i].m_eItem == EITEM.ITEM_NONE)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060005DC RID: 1500 RVA: 0x0000627D File Offset: 0x0000447D
	public void StartRace()
	{
		if (this.m_pParent.SelectedAdvantage == EAdvantage.BoostStart && this.m_pBonusEffectMgr != null)
		{
			this.m_pBonusEffectMgr.ActivateBonusEffect(EBonusEffect.BONUSEFFECT_BOOST);
		}
	}

	// Token: 0x060005DD RID: 1501 RVA: 0x0002F084 File Offset: 0x0002D284
	[RPC]
	public void OnStinkParfumeTriggerred(NetworkViewID vehicleId)
	{
		GameObject player = Singleton<GameManager>.Instance.GameMode.GetPlayer(vehicleId);
		if (player)
		{
			Kart componentInChildren = player.GetComponentInChildren<Kart>();
			this.DoStinkParfumeTriggerred(componentInChildren);
		}
	}

	// Token: 0x060005DE RID: 1502 RVA: 0x0002F0BC File Offset: 0x0002D2BC
	public void DoStinkParfumeTriggerred(Kart pKart)
	{
		if (pKart)
		{
			pKart.GetBonusMgr().GetBonusEffectMgr().ActivateBonusEffect(EBonusEffect.BONUSEFFECT_SPIN);
			pKart.FxMgr.PlayKartFx(eKartFx.BadParfume);
			((ParfumeBonusEffect)pKart.BonusMgr.GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_ATTRACTED)).BadParfumeCollisionSound.Play();
		}
	}

	// Token: 0x040005CE RID: 1486
	public const int MAX_NB_BONUS = 2;

	// Token: 0x040005CF RID: 1487
	private KartBonus[] m_ItemTab = new KartBonus[2];

	// Token: 0x040005D0 RID: 1488
	private bool m_bActiveItem;

	// Token: 0x040005D1 RID: 1489
	private BonusEffectMgr m_pBonusEffectMgr;

	// Token: 0x040005D2 RID: 1490
	private Kart m_pParent;

	// Token: 0x040005D3 RID: 1491
	private PlayerCustom m_pCustomMgr;

	// Token: 0x040005D4 RID: 1492
	private HUDBonus m_pHudBonus;

	// Token: 0x040005D5 RID: 1493
	public Action<EITEM, bool> OnLaunchBonus;

	// Token: 0x040005D6 RID: 1494
	protected NetworkView netView;

	// Token: 0x040005D7 RID: 1495
	private bool m_bShowNapFadeIn;
}

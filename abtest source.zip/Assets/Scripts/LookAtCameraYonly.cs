﻿using System;
using UnityEngine;

// Token: 0x02000092 RID: 146
public class LookAtCameraYonly : MonoBehaviour
{
	// Token: 0x060003FC RID: 1020 RVA: 0x000241F0 File Offset: 0x000223F0
	private void OnWillRenderObject()
	{
		Quaternion rhs = new Quaternion(0f, 1f, 0f, 0f);
		base.transform.rotation = Camera.main.transform.rotation * rhs;
	}
}

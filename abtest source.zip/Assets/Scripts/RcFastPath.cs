﻿using System;
using UnityEngine;

// Token: 0x020001FB RID: 507
public class RcFastPath
{
	// Token: 0x06000DAD RID: 3501 RVA: 0x00058D08 File Offset: 0x00056F08
	public RcFastPath(int _arraySize)
	{
		this.m_iNbPoints = 0;
		this.m_iMaxArraySize = _arraySize;
		this.m_fTotalLength = 0f;
		this.m_bFlagLoop = false;
		this.m_pVectorPoints = new Vector3[this.m_iMaxArraySize];
		this.m_pSegmentLengths = new float[this.m_iMaxArraySize];
		this.m_pDistToEndOfPath = new float[this.m_iMaxArraySize];
		for (int i = 0; i < this.m_iMaxArraySize; i++)
		{
			this.m_pVectorPoints[i] = Vector3.zero;
			this.m_pSegmentLengths[i] = 0f;
			this.m_pDistToEndOfPath[i] = 0f;
		}
	}

	// Token: 0x06000DAE RID: 3502 RVA: 0x00058DB8 File Offset: 0x00056FB8
	public RcFastPath(GameObject slowPath)
	{
		this.m_iNbPoints = 0;
		this.m_iMaxArraySize = 0;
		this.m_fTotalLength = 0f;
		this.m_bFlagLoop = false;
		this.m_bFlagLoop = slowPath.GetComponent<RcFastPathComp>().IsLooping();
		this.m_iNbPoints = slowPath.transform.GetChildCount();
		this.m_iMaxArraySize = this.m_iNbPoints;
		if (this.m_iNbPoints > 0)
		{
			this.m_pVectorPoints = new Vector3[this.m_iMaxArraySize];
			this.m_pSegmentLengths = new float[this.m_iMaxArraySize];
			this.m_pDistToEndOfPath = new float[this.m_iMaxArraySize];
			int num = this.m_iNbPoints - 1;
			for (int i = this.m_iNbPoints - 1; i >= 0; i--)
			{
				this.m_pVectorPoints[num] = slowPath.transform.GetChild(i).position;
				int num2 = num + 1;
				int num3 = i;
				if (num2 >= this.m_iNbPoints)
				{
					num3 = 0;
				}
				else
				{
					num3++;
				}
				Vector3 position = slowPath.transform.GetChild(num3).position;
				Vector3 vector = position - this.m_pVectorPoints[num];
				this.m_pSegmentLengths[num] = vector.magnitude;
				if (num < this.m_iNbPoints - 1)
				{
					this.m_fTotalLength += this.m_pSegmentLengths[num];
					this.m_pDistToEndOfPath[num] = this.m_pDistToEndOfPath[num + 1] + this.m_pSegmentLengths[num];
				}
				else if (this.m_bFlagLoop)
				{
					this.m_pDistToEndOfPath[num] = this.m_pSegmentLengths[num];
				}
				else
				{
					this.m_pDistToEndOfPath[num] = 0f;
				}
				num--;
			}
		}
	}

	// Token: 0x06000DAF RID: 3503 RVA: 0x0000B63E File Offset: 0x0000983E
	public float GetDistToEndOfPath(int pInd, float ratio)
	{
		if (this.m_iNbPoints == 0)
		{
			return 0f;
		}
		return this.m_pDistToEndOfPath[pInd] - this.m_pSegmentLengths[pInd] * ratio;
	}

	// Token: 0x06000DB0 RID: 3504 RVA: 0x00058F70 File Offset: 0x00057170
	public int GetSegmentForEndOfPathDist(float dist, out float ratio)
	{
		if (this.m_iNbPoints <= 1 || dist >= this.m_fTotalLength)
		{
			ratio = 0f;
			return (this.m_iNbPoints != 0) ? 0 : -1;
		}
		if (dist <= 0f)
		{
			ratio = 1f;
			return this.m_iNbPoints - 1;
		}
		int num = 0;
		int num2 = this.m_iNbPoints - 1;
		while (num + 1 < num2)
		{
			int num3 = (num + num2) / 2;
			if (dist <= this.m_pDistToEndOfPath[num3])
			{
				num = num3;
			}
			else
			{
				num2 = num3;
			}
		}
		ratio = (this.m_pDistToEndOfPath[num] - dist) / this.m_pSegmentLengths[num];
		return num;
	}

	// Token: 0x06000DB1 RID: 3505 RVA: 0x0000B664 File Offset: 0x00009864
	public Vector3 GetPositionPoint(int pInd)
	{
		return this.m_pVectorPoints[pInd];
	}

	// Token: 0x06000DB2 RID: 3506 RVA: 0x00059018 File Offset: 0x00057218
	public Vector3 GetSegment(int segInd)
	{
		if (this.m_iNbPoints <= 0)
		{
			return Vector3.zero;
		}
		int num = segInd + 1;
		if (num >= this.m_iNbPoints)
		{
			num -= this.m_iNbPoints;
		}
		return this.m_pVectorPoints[num] - this.m_pVectorPoints[segInd];
	}

	// Token: 0x06000DB3 RID: 3507 RVA: 0x00059078 File Offset: 0x00057278
	public bool IsOnRight(Vector3 pt, int index, Vector3 up)
	{
		Vector3 segment = this.GetSegment(index);
		Vector3 rhs = pt - this.m_pVectorPoints[index];
		Vector3 lhs = Vector3.Cross(segment, rhs);
		return -1f * Vector3.Dot(lhs, up) <= 0f;
	}

	// Token: 0x06000DB4 RID: 3508 RVA: 0x0000B677 File Offset: 0x00009877
	public bool IsOnRight(Vector3 pt, PathPosition _pathPosition, Vector3 up)
	{
		return this.IsOnRight(pt, _pathPosition.index, up);
	}

	// Token: 0x06000DB5 RID: 3509 RVA: 0x0000B688 File Offset: 0x00009888
	public void GetRawPos(PathPosition _pathPosition, out Vector3 outPos)
	{
		this.GetRawPos(_pathPosition.index, _pathPosition.ratio, out outPos);
	}

	// Token: 0x06000DB6 RID: 3510 RVA: 0x000590C4 File Offset: 0x000572C4
	public void GetRawPos(int segmentIndex, float prc, out Vector3 outPos)
	{
		if (this.m_pVectorPoints != null && this.m_iNbPoints != 0)
		{
			if (segmentIndex < this.m_iNbPoints)
			{
				if (this.m_iNbPoints < 2 || prc == 0f)
				{
					outPos = this.m_pVectorPoints[segmentIndex];
				}
				else
				{
					outPos = this.m_pVectorPoints[segmentIndex] + this.GetSegment(segmentIndex) * prc;
				}
			}
			else
			{
				outPos = Vector3.zero;
			}
		}
		else
		{
			outPos = Vector3.zero;
		}
	}

	// Token: 0x06000DB7 RID: 3511 RVA: 0x0000B664 File Offset: 0x00009864
	public Vector3 GetSegmentBegin(int segInd)
	{
		return this.m_pVectorPoints[segInd];
	}

	// Token: 0x06000DB8 RID: 3512 RVA: 0x0000B69F File Offset: 0x0000989F
	public Vector3 GetSegmentEnd(int segInd)
	{
		return this.m_pVectorPoints[(segInd + 1) % this.m_iNbPoints];
	}

	// Token: 0x06000DB9 RID: 3513 RVA: 0x00059170 File Offset: 0x00057370
	public virtual void SetSize(int _newSize, bool _updateLengthsAndDistances)
	{
		if (_newSize >= this.m_iMaxArraySize)
		{
			_newSize = this.m_iMaxArraySize;
		}
		for (int i = this.m_iNbPoints; i < _newSize; i++)
		{
			this.m_pVectorPoints[i] = Vector3.zero;
			this.m_pSegmentLengths[i] = 0f;
			this.m_pDistToEndOfPath[i] = 0f;
		}
		this.m_iNbPoints = _newSize;
		if (_updateLengthsAndDistances)
		{
			for (int j = this.m_iNbPoints - 1; j >= 0; j--)
			{
				if (j < this.m_iNbPoints - 1)
				{
					this.m_fTotalLength += this.m_pSegmentLengths[j];
					this.m_pDistToEndOfPath[j] = this.m_pDistToEndOfPath[j + 1] + this.m_pSegmentLengths[j];
				}
				else
				{
					this.m_pDistToEndOfPath[j] = 0f;
				}
			}
		}
	}

	// Token: 0x06000DBA RID: 3514 RVA: 0x00059250 File Offset: 0x00057450
	public void SetPointPos(int pointIndex, Vector3 _newPosition)
	{
		if (pointIndex >= 0 && pointIndex < this.m_iNbPoints)
		{
			this.m_pVectorPoints[pointIndex] = _newPosition;
			int num = pointIndex + 1;
			if (num >= this.m_iNbPoints)
			{
				num -= this.m_iNbPoints;
			}
			int num2 = pointIndex - 1;
			if (num2 < 0)
			{
				num2 += this.m_iNbPoints;
			}
			this.m_fTotalLength -= this.m_pSegmentLengths[num2];
			this.m_fTotalLength -= this.m_pSegmentLengths[pointIndex];
			this.m_pSegmentLengths[num2] = (this.m_pVectorPoints[pointIndex] - this.m_pVectorPoints[num2]).magnitude;
			this.m_pSegmentLengths[pointIndex] = (this.m_pVectorPoints[num] - this.m_pVectorPoints[pointIndex]).magnitude;
			this.m_fTotalLength += this.m_pSegmentLengths[num2];
			this.m_fTotalLength += this.m_pSegmentLengths[pointIndex];
			for (int i = pointIndex; i >= 0; i--)
			{
				if (i < this.m_iNbPoints - 1)
				{
					this.m_pDistToEndOfPath[i] = this.m_pDistToEndOfPath[i + 1] + this.m_pSegmentLengths[i];
				}
				else
				{
					this.m_pDistToEndOfPath[i] = 0f;
				}
			}
		}
	}

	// Token: 0x06000DBB RID: 3515 RVA: 0x000593C0 File Offset: 0x000575C0
	public void ResetSidedPosition(ref PathPosition _pathPosition, Vector3 position, bool _loopSearch, RcFastPath.PathSide _side, Vector3 _up)
	{
		if (this.m_iNbPoints <= 0)
		{
			_pathPosition = PathPosition.UNDEFINED_POSITION;
			return;
		}
		if (this.m_iNbPoints > 1)
		{
			float num = float.MaxValue;
			int index = -1;
			float ratio = 0f;
			int num2 = this.m_iNbPoints - 1;
			if (!_loopSearch)
			{
				num2 = this.m_iNbPoints - 2;
			}
			for (int i = 0; i <= num2; i++)
			{
				Vector3 vector = this.m_pVectorPoints[i];
				int num3 = (i >= this.m_iNbPoints - 1) ? (i - this.m_iNbPoints + 1) : (i + 1);
				Vector3 a = this.m_pVectorPoints[num3];
				float num5;
				if (this.m_pSegmentLengths[i] != 0f)
				{
					float num4 = Vector3.Dot(position - vector, a - vector);
					num5 = num4 / (this.m_pSegmentLengths[i] * this.m_pSegmentLengths[i]);
				}
				else
				{
					num5 = -1f;
				}
				float num6;
				if (num5 < 0f)
				{
					num6 = (vector - position).sqrMagnitude;
				}
				else if (num5 > 1f)
				{
					num6 = (a - position).sqrMagnitude;
				}
				else
				{
					float num7 = (1f - num5) * vector.x + num5 * a.x - position.x;
					float num8 = (1f - num5) * vector.y + num5 * a.y - position.y;
					float num9 = (1f - num5) * vector.z + num5 * a.z - position.z;
					num6 = num7 * num7 + num8 * num8 + num9 * num9;
				}
				if (i == 0 || num6 < num)
				{
					bool flag = _side == RcFastPath.PathSide.SIDE_ANY;
					if (!flag)
					{
						bool flag2 = this.IsOnRight(position, i, _up);
						flag = ((flag2 && _side == RcFastPath.PathSide.SIDE_RIGHT) || (!flag2 && _side == RcFastPath.PathSide.SIDE_LEFT));
					}
					if (flag)
					{
						num = num6;
						index = i;
						ratio = num5;
					}
				}
			}
			_pathPosition.index = index;
			_pathPosition.ratio = ratio;
			_pathPosition.sqrDist = num;
		}
		else
		{
			_pathPosition.index = 0;
			_pathPosition.ratio = 0f;
			_pathPosition.sqrDist = (this.m_pVectorPoints[0] - position).sqrMagnitude;
		}
	}

	// Token: 0x06000DBC RID: 3516 RVA: 0x0005964C File Offset: 0x0005784C
	public void UpdatePosition(ref PathPosition _pathPosition, Vector3 position, int startIndex, int endIndex, bool _loopSearch)
	{
		if (this.m_iNbPoints <= 0)
		{
			_pathPosition = PathPosition.UNDEFINED_POSITION;
			return;
		}
		if (this.m_iNbPoints > 1)
		{
			float num = 1E+38f;
			int index = -1;
			float ratio = 0f;
			bool flag = startIndex > endIndex;
			_loopSearch = (_loopSearch && this.m_bFlagLoop);
			if (!_loopSearch && endIndex >= this.m_iNbPoints - 1)
			{
				endIndex = this.m_iNbPoints - 2;
			}
			int num2 = startIndex;
			while (num2 <= endIndex || flag)
			{
				Vector3 vector = this.m_pVectorPoints[num2];
				int num3 = (num2 >= this.m_iNbPoints - 1) ? (num2 - this.m_iNbPoints + 1) : (num2 + 1);
				Vector3 a = this.m_pVectorPoints[num3];
				float num5;
				if (this.m_pSegmentLengths[num2] != 0f)
				{
					float num4 = Vector3.Dot(position - vector, a - vector);
					num5 = num4 / (this.m_pSegmentLengths[num2] * this.m_pSegmentLengths[num2]);
				}
				else
				{
					num5 = -1f;
				}
				float num6;
				if (num5 < 0f)
				{
					num6 = (vector - position).sqrMagnitude;
				}
				else if (num5 > 1f)
				{
					num6 = (a - position).sqrMagnitude;
				}
				else
				{
					float num7 = (1f - num5) * vector.x + num5 * a.x - position.x;
					float num8 = (1f - num5) * vector.y + num5 * a.y - position.y;
					float num9 = (1f - num5) * vector.z + num5 * a.z - position.z;
					num6 = num7 * num7 + num8 * num8 + num9 * num9;
				}
				if (num2 == startIndex || num6 < num)
				{
					num = num6;
					index = num2;
					ratio = num5;
				}
				if (flag && num2 == this.m_iNbPoints - 1)
				{
					num2 = -1;
					flag = false;
				}
				num2++;
			}
			_pathPosition.index = index;
			_pathPosition.ratio = ratio;
			_pathPosition.sqrDist = num;
		}
		else
		{
			_pathPosition.index = 0;
			_pathPosition.ratio = 0f;
			_pathPosition.sqrDist = (this.m_pVectorPoints[0] - position).sqrMagnitude;
		}
	}

	// Token: 0x06000DBD RID: 3517 RVA: 0x000598D8 File Offset: 0x00057AD8
	public void UpdatePosition2D(ref PathPosition _pathPosition, Vector3 position, int startIndex, int endIndex, bool _loopSearch)
	{
		if (this.m_iNbPoints <= 0)
		{
			_pathPosition = PathPosition.UNDEFINED_POSITION;
			return;
		}
		if (this.m_iNbPoints > 1)
		{
			if (!_loopSearch && endIndex >= this.m_iNbPoints - 1)
			{
				endIndex = this.m_iNbPoints - 2;
			}
			float num = 1E+38f;
			int index = -1;
			float ratio = 0f;
			bool flag = startIndex > endIndex;
			int num2 = startIndex;
			while (num2 <= endIndex || flag)
			{
				float x = this.m_pVectorPoints[num2].x;
				float z = this.m_pVectorPoints[num2].z;
				int num3 = num2 + 1;
				if (num3 >= this.m_iNbPoints)
				{
					num3 -= this.m_iNbPoints;
				}
				float x2 = this.m_pVectorPoints[num3].x;
				float z2 = this.m_pVectorPoints[num3].z;
				float num5;
				if (this.m_pSegmentLengths[num2] != 0f)
				{
					float num4 = (position.x - x) * (x2 - x) + (position.z - z) * (z2 - z);
					num5 = num4 / (this.m_pSegmentLengths[num2] * this.m_pSegmentLengths[num2]);
				}
				else
				{
					num5 = -1f;
				}
				float num6;
				float num7;
				if (num5 < 0f)
				{
					num6 = x - position.x;
					num7 = z - position.z;
				}
				else if (num5 > 1f)
				{
					num6 = x2 - position.x;
					num7 = z2 - position.z;
				}
				else
				{
					num6 = (1f - num5) * x + num5 * x2 - position.x;
					num7 = (1f - num5) * z + num5 * z2 - position.z;
				}
				float num8 = num6 * num6 + num7 * num7;
				if (num2 == startIndex || num8 < num)
				{
					num = num8;
					index = num2;
					ratio = num5;
				}
				if (flag && num2 == this.m_iNbPoints - 1)
				{
					num2 = -1;
					flag = false;
				}
				num2++;
			}
			_pathPosition.index = index;
			_pathPosition.ratio = ratio;
			_pathPosition.sqrDist = num;
		}
		else
		{
			float num6 = this.m_pVectorPoints[0].x - position.x;
			float num7 = this.m_pVectorPoints[0].z - position.z;
			_pathPosition.index = 0;
			_pathPosition.ratio = 0f;
			_pathPosition.sqrDist = num6 * num6 + num7 * num7;
		}
	}

	// Token: 0x06000DBE RID: 3518 RVA: 0x00059B60 File Offset: 0x00057D60
	public float GetSignedDistToSegment2D(Vector3 position, int index, Vector3 up)
	{
		if (this.m_iNbPoints <= 1)
		{
			return -1E+37f;
		}
		int num = (index >= this.m_iNbPoints) ? (index - this.m_iNbPoints) : index;
		int num2 = num + 1;
		if (num2 >= this.m_iNbPoints)
		{
			num2 -= this.m_iNbPoints;
		}
		Vector3 vector = position - Vector3.Dot(position, up) * up;
		Vector3 vector2 = this.m_pVectorPoints[num] - Vector3.Dot(this.m_pVectorPoints[num], up) * up;
		Vector3 vector3 = this.m_pVectorPoints[num2] - Vector3.Dot(this.m_pVectorPoints[num2], up) * up;
		float num3 = RcUtils.PointToSegmentDistance(vector, vector2, vector3);
		Vector3 lhs = Vector3.Cross(vector3 - vector2, vector - vector2);
		if (-1f * Vector3.Dot(lhs, up) <= 0f)
		{
			return -num3;
		}
		return num3;
	}

	// Token: 0x06000DBF RID: 3519 RVA: 0x0000B6BB File Offset: 0x000098BB
	public float GetSegmentLength(int segInd)
	{
		if (segInd < this.m_iNbPoints)
		{
			return this.m_pSegmentLengths[segInd];
		}
		return 0f;
	}

	// Token: 0x06000DC0 RID: 3520 RVA: 0x0000B6D7 File Offset: 0x000098D7
	public bool IsLooping()
	{
		return this.m_bFlagLoop;
	}

	// Token: 0x06000DC1 RID: 3521 RVA: 0x0000B6DF File Offset: 0x000098DF
	public void SetLoop(bool bLoop)
	{
		this.m_bFlagLoop = bLoop;
	}

	// Token: 0x06000DC2 RID: 3522 RVA: 0x0000B6E8 File Offset: 0x000098E8
	public void ResetPosition(ref PathPosition _pathPosition, Vector3 position, bool _loopSearch)
	{
		if (this.m_iNbPoints != 0)
		{
			this.UpdatePosition(ref _pathPosition, position, 0, this.m_iNbPoints - 1, _loopSearch);
		}
		else
		{
			_pathPosition = PathPosition.UNDEFINED_POSITION;
		}
	}

	// Token: 0x06000DC3 RID: 3523 RVA: 0x0000B717 File Offset: 0x00009917
	public int GetNbPoints()
	{
		return this.m_iNbPoints;
	}

	// Token: 0x06000DC4 RID: 3524 RVA: 0x00059C70 File Offset: 0x00057E70
	public void UpdatePathPosition(ref PathPosition _pathPosition, Vector3 _position3D, int segmentForward, int segmentBackward, bool _2D, bool _loopSearch)
	{
		if (this.m_iNbPoints <= 0)
		{
			_pathPosition = PathPosition.UNDEFINED_POSITION;
			return;
		}
		if (_pathPosition.index != -1)
		{
			int i = _pathPosition.index - segmentBackward;
			int j = _pathPosition.index + segmentForward;
			while (i < 0)
			{
				i += this.GetNbPoints();
			}
			while (j >= this.GetNbPoints())
			{
				j -= this.GetNbPoints();
			}
			if (_2D)
			{
				this.UpdatePosition2D(ref _pathPosition, _position3D, i, j, _loopSearch);
			}
			else
			{
				this.UpdatePosition(ref _pathPosition, _position3D, i, j, _loopSearch);
			}
		}
		else
		{
			this.ResetPosition(ref _pathPosition, _position3D, _loopSearch);
		}
	}

	// Token: 0x06000DC5 RID: 3525 RVA: 0x00059D18 File Offset: 0x00057F18
	public int GetPosAtDist(int startInd, ref float dist, out Vector3 position)
	{
		position = Vector3.zero;
		if (this.m_iNbPoints <= 0)
		{
			position = Vector3.zero;
			return -1;
		}
		if (this.m_iNbPoints == 1 || this.m_fTotalLength == 0f)
		{
			position = this.m_pVectorPoints[0];
			return 0;
		}
		bool flag = false;
		uint num = (uint)((startInd == -1) ? 0 : startInd);
		float num2 = this.m_pSegmentLengths[(int)((UIntPtr)num)];
		while (!flag && (this.m_bFlagLoop || (ulong)num <= (ulong)((long)(this.m_iNbPoints - 2))))
		{
			num2 = this.m_pSegmentLengths[(int)((UIntPtr)num)];
			if (dist < num2)
			{
				flag = true;
			}
			else
			{
				dist -= num2;
				num += 1u;
				if ((ulong)num >= (ulong)((long)this.m_iNbPoints))
				{
					num -= (uint)this.m_iNbPoints;
				}
			}
		}
		if (!flag)
		{
			position = this.m_pVectorPoints[this.m_iNbPoints - 1];
			return this.m_iNbPoints - 1;
		}
		bool flag2 = (ulong)num < (ulong)((long)this.m_iNbPoints);
		if (flag2)
		{
			float prc = 0f;
			if (this.m_pSegmentLengths[(int)((UIntPtr)num)] != 0f)
			{
				prc = dist / this.m_pSegmentLengths[(int)((UIntPtr)num)];
			}
			this.GetRawPos((int)num, prc, out position);
		}
		return (int)num;
	}

	// Token: 0x06000DC6 RID: 3526 RVA: 0x0000B71F File Offset: 0x0000991F
	public Vector3 GetFirstPoint()
	{
		return this.m_pVectorPoints[0];
	}

	// Token: 0x06000DC7 RID: 3527 RVA: 0x0000B732 File Offset: 0x00009932
	public Vector3 GetLastPoint()
	{
		return this.m_pVectorPoints[this.m_iNbPoints - 1];
	}

	// Token: 0x06000DC8 RID: 3528 RVA: 0x00059E6C File Offset: 0x0005806C
	public float GetClosestSqrDistToPoint(Vector3 position)
	{
		if (this.m_iNbPoints > 0)
		{
			float num = float.MaxValue;
			int num2 = 0;
			while ((num2 < this.m_iNbPoints && this.m_bFlagLoop) || num2 < this.m_iNbPoints - 1)
			{
				Vector3 segmentP = this.m_pVectorPoints[num2];
				int num3 = num2 + 1;
				if (num3 >= this.m_iNbPoints)
				{
					num3 = 0;
				}
				Vector3 segmentP2 = this.m_pVectorPoints[num3];
				float num4 = RcUtils.PointToSegmentSqrDistance(position, segmentP, segmentP2);
				if (num4 < num)
				{
					num = num4;
				}
				num2++;
			}
			return num;
		}
		return 0f;
	}

	// Token: 0x06000DC9 RID: 3529 RVA: 0x00059F14 File Offset: 0x00058114
	public Vector3 MoveOnPath(ref PathPosition _pathPosition, ref float _distance, bool _smooth)
	{
		if (this.m_iNbPoints == 0)
		{
			return Vector3.zero;
		}
		if (this.m_iNbPoints == 1)
		{
			return this.m_pVectorPoints[0];
		}
		float num = _distance;
		int num2;
		if (_pathPosition.index == -1)
		{
			num2 = 0;
		}
		else
		{
			num2 = _pathPosition.index;
			num += this.m_pSegmentLengths[num2] * _pathPosition.ratio;
		}
		Vector3 vector;
		int posAtDist = this.GetPosAtDist(num2, ref num, out vector);
		_pathPosition.index = posAtDist;
		_pathPosition.sqrDist = 0f;
		_pathPosition.ratio = RcUtils.PointToSegmentRatio(vector, this.GetSegmentBegin(posAtDist), this.GetSegmentEnd(posAtDist));
		if (!_smooth)
		{
			return vector;
		}
		if (!this.m_bFlagLoop && (posAtDist < 1 || posAtDist >= this.m_iNbPoints - 3))
		{
			return vector;
		}
		Vector3[] array = new Vector3[]
		{
			this.m_pVectorPoints[(posAtDist + this.m_iNbPoints - 1) % this.m_iNbPoints],
			this.m_pVectorPoints[posAtDist],
			this.m_pVectorPoints[(posAtDist + 1) % this.m_iNbPoints],
			this.m_pVectorPoints[(posAtDist + 2) % this.m_iNbPoints]
		};
		return RcUtils.GetSmoothPos(array[0], array[1], array[2], array[3], _pathPosition.ratio, 6f);
	}

	// Token: 0x06000DCA RID: 3530 RVA: 0x0000B74C File Offset: 0x0000994C
	public float GetTotalLength(bool _includeLoopSegment)
	{
		if (_includeLoopSegment)
		{
			return this.m_fTotalLength + this.m_pSegmentLengths[this.m_iNbPoints - 1];
		}
		return this.m_fTotalLength;
	}

	// Token: 0x04000D54 RID: 3412
	public const int INVALID_PATH_INDEX = -1;

	// Token: 0x04000D55 RID: 3413
	private const float FASTPATH_SPLINE_TENSION_INV = 0.166666f;

	// Token: 0x04000D56 RID: 3414
	protected int m_iNbPoints;

	// Token: 0x04000D57 RID: 3415
	protected int m_iMaxArraySize;

	// Token: 0x04000D58 RID: 3416
	protected Vector3[] m_pVectorPoints;

	// Token: 0x04000D59 RID: 3417
	protected float[] m_pSegmentLengths;

	// Token: 0x04000D5A RID: 3418
	protected float[] m_pDistToEndOfPath;

	// Token: 0x04000D5B RID: 3419
	protected float m_fTotalLength;

	// Token: 0x04000D5C RID: 3420
	protected bool m_bFlagLoop;

	// Token: 0x020001FC RID: 508
	public enum PathSide
	{
		// Token: 0x04000D5E RID: 3422
		SIDE_ANY,
		// Token: 0x04000D5F RID: 3423
		SIDE_LEFT,
		// Token: 0x04000D60 RID: 3424
		SIDE_RIGHT
	}
}

﻿using System;
using UnityEngine;

// Token: 0x02000226 RID: 550
public struct RcPhysStats
{
	// Token: 0x04000F06 RID: 3846
	public float fTime;

	// Token: 0x04000F07 RID: 3847
	public Vector3 vPos;

	// Token: 0x04000F08 RID: 3848
	public Vector3 vCombineMv;

	// Token: 0x04000F09 RID: 3849
	public Quaternion vOrient;

	// Token: 0x04000F0A RID: 3850
	public bool bFlying;

	// Token: 0x04000F0B RID: 3851
	public bool bInertiaMode;

	// Token: 0x04000F0C RID: 3852
	public RcWheelStats[] Wheel;

	// Token: 0x04000F0D RID: 3853
	public float fWheelSpeed;

	// Token: 0x04000F0E RID: 3854
	public float fWheelSpeedMs;

	// Token: 0x04000F0F RID: 3855
	public float fTurningRadius;
}

﻿using System;
using UnityEngine;

// Token: 0x020001D9 RID: 473
public class AIForecaster : MonoBehaviour
{
	// Token: 0x06000CB2 RID: 3250 RVA: 0x0000ACA5 File Offset: 0x00008EA5
	public void UnableForecast(int pVehicleId, bool pEnable)
	{
		if (this.ForecastClients[pVehicleId] != null)
		{
			this.ForecastClients[pVehicleId].ForecastEnabled = pEnable;
		}
	}

	// Token: 0x06000CB3 RID: 3251 RVA: 0x0000ACC8 File Offset: 0x00008EC8
	public void UnableObserver(int pVehicleId, bool pEnable)
	{
		if (this.ForecastClients[pVehicleId])
		{
			this.ForecastClients[pVehicleId].ObserverEnabled = pEnable;
		}
	}

	// Token: 0x06000CB4 RID: 3252 RVA: 0x0005467C File Offset: 0x0005287C
	public virtual void Update()
	{
		for (int i = 0; i < 8; i++)
		{
			if (this.ForecastClients[i])
			{
				this.ForecastClients[i].Refresh(this.ForecastTime);
			}
		}
		for (uint num = 0u; num < this._nbForecastedObjects; num += 1u)
		{
			if (this.ForecastedObjects[(int)((UIntPtr)num)].ForecastEnabled)
			{
				this.ForecastedObjects[(int)((UIntPtr)num)].Refresh(this.ForecastTime);
			}
		}
		this.ForecastObjects();
		this.ForecastBorders();
		this.ForecastPolygons();
	}

	// Token: 0x06000CB5 RID: 3253 RVA: 0x0000ACEA File Offset: 0x00008EEA
	public ForecastResult GetRepulsiveForecast(int pVehicleId)
	{
		return this.ForecastClients[pVehicleId].ForecastRepulsive;
	}

	// Token: 0x06000CB6 RID: 3254 RVA: 0x0000ACEA File Offset: 0x00008EEA
	public ForecastResult GetAttractiveForecast(int pVehicleId)
	{
		return this.ForecastClients[pVehicleId].ForecastRepulsive;
	}

	// Token: 0x06000CB7 RID: 3255 RVA: 0x00054710 File Offset: 0x00052910
	public void Reset()
	{
		for (int i = 0; i < 8; i++)
		{
			if (this.ForecastClients[i] != null)
			{
				this.ForecastClients[i].ResetBorderPositions();
			}
		}
	}

	// Token: 0x06000CB8 RID: 3256 RVA: 0x00054750 File Offset: 0x00052950
	public void RegisterClient(RcVehicle pVehicle, RcFastPath pLeftBorder, RcFastPath pRightBorder)
	{
		ForecastClient forecastClient = new ForecastClient(pVehicle);
		forecastClient.LeftBorder = pLeftBorder;
		forecastClient.RightBorder = pRightBorder;
		this.ForecastClients[pVehicle.GetVehicleId()] = forecastClient;
	}

	// Token: 0x06000CB9 RID: 3257 RVA: 0x0000ACF9 File Offset: 0x00008EF9
	public void UnRegisterClient(RcVehicle pVehicle)
	{
		this.ForecastClients[pVehicle.GetVehicleId()] = null;
	}

	// Token: 0x06000CBA RID: 3258 RVA: 0x00054780 File Offset: 0x00052980
	public virtual void RegisterEntity(MonoBehaviour pEntity, int pType)
	{
		Forecasted forecasted;
		if (pType != 3)
		{
			if (pType != 4)
			{
				return;
			}
			forecasted = new Forecasted(pEntity);
		}
		else
		{
			forecasted = new Forecasted(pEntity);
		}
		this.ForecastedObjects[(int)((UIntPtr)this._nbForecastedObjects)] = forecasted;
		this._nbForecastedObjects += 1u;
	}

	// Token: 0x06000CBB RID: 3259 RVA: 0x000547DC File Offset: 0x000529DC
	public void UnRegisterEntity(MonoBehaviour pEntity)
	{
		for (uint num = 0u; num < this._nbForecastedObjects; num += 1u)
		{
			if (this.ForecastedObjects[(int)((UIntPtr)num)].Entity == pEntity)
			{
				this.ForecastedObjects[(int)((UIntPtr)num)] = null;
				this.ForecastedObjects[(int)((UIntPtr)num)] = this.ForecastedObjects[(int)((UIntPtr)(this._nbForecastedObjects - 1u))];
				this.ForecastedObjects[(int)((UIntPtr)(this._nbForecastedObjects - 1u))] = null;
				this._nbForecastedObjects -= 1u;
				break;
			}
		}
	}

	// Token: 0x06000CBC RID: 3260 RVA: 0x00054860 File Offset: 0x00052A60
	protected virtual void ForecastObjects()
	{
		for (int i = 0; i < 8; i++)
		{
			ForecastClient forecastClient = this.ForecastClients[i];
			if (forecastClient != null && forecastClient.ObserverEnabled)
			{
				for (uint num = 0u; num < this._nbForecastedObjects; num += 1u)
				{
					if (this.ForecastedObjects[(int)((UIntPtr)num)].ForecastEnabled && this.ForecastedObjects[(int)((UIntPtr)num)].Entity != this.ForecastClients[i].Entity && forecastClient.IsObjectInFront(this.ForecastedObjects[(int)((UIntPtr)num)]))
					{
						this.ForecastedObjects[(int)((UIntPtr)num)].ForecastCollision(forecastClient, this.ForecastTime);
					}
				}
			}
		}
	}

	// Token: 0x06000CBD RID: 3261 RVA: 0x00054918 File Offset: 0x00052B18
	protected virtual void ForecastBorders()
	{
		if (this.BordersWeight > 0f)
		{
			for (int i = 0; i < 8; i++)
			{
				ForecastClient forecastClient = this.ForecastClients[i];
				if (forecastClient != null && forecastClient.ObserverEnabled)
				{
					Vector3 forecastPosition = forecastClient.ForecastPosition;
					Vector3 up = forecastClient.Entity.transform.rotation * Vector3.up;
					RcFastPath leftBorder = forecastClient.LeftBorder;
					RcFastPath rightBorder = forecastClient.RightBorder;
					if (leftBorder != null && rightBorder != null)
					{
						leftBorder.UpdatePathPosition(ref forecastClient.LeftBorderPosition, forecastPosition, 5, 1, false, true);
						rightBorder.UpdatePathPosition(ref forecastClient.RightBorderPosition, forecastPosition, 5, 1, false, true);
						float bordersRange = this.BordersRange;
						float num = bordersRange * bordersRange;
						float sqrDist = forecastClient.RightBorderPosition.sqrDist;
						if (rightBorder.IsOnRight(forecastPosition, forecastClient.RightBorderPosition, up))
						{
							float num2 = bordersRange + RcUtils.FastSqrtApprox(sqrDist);
							num2 = Mathf.Min(num2, 2f * bordersRange);
							forecastClient.ForecastRepulsive.Direction -= this.BordersWeight * num2;
							forecastClient.ForecastRepulsive.Weight += this.BordersWeight * num2;
						}
						else if (sqrDist < num)
						{
							float num3 = bordersRange - RcUtils.FastSqrtApprox(sqrDist);
							forecastClient.ForecastRepulsive.Direction -= this.BordersWeight * num3;
							forecastClient.ForecastRepulsive.Weight += this.BordersWeight * num3;
						}
						else
						{
							float sqrDist2 = forecastClient.LeftBorderPosition.sqrDist;
							if (!leftBorder.IsOnRight(forecastPosition, forecastClient.LeftBorderPosition, up))
							{
								float num4 = bordersRange + RcUtils.FastSqrtApprox(sqrDist2);
								num4 = Mathf.Min(num4, 2f * bordersRange);
								forecastClient.ForecastRepulsive.Direction += this.BordersWeight * num4;
								forecastClient.ForecastRepulsive.Weight += this.BordersWeight * num4;
							}
							else if (sqrDist2 < num)
							{
								float num5 = bordersRange - RcUtils.FastSqrtApprox(sqrDist2);
								forecastClient.ForecastRepulsive.Direction += this.BordersWeight * num5;
								forecastClient.ForecastRepulsive.Weight += this.BordersWeight * num5;
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x06000CBE RID: 3262 RVA: 0x00054B68 File Offset: 0x00052D68
	protected virtual void ForecastPolygons()
	{
		for (int i = 0; i < 8; i++)
		{
			ForecastClient forecastClient = this.ForecastClients[i];
			if (!(forecastClient != null) || forecastClient.ObserverEnabled)
			{
			}
		}
	}

	// Token: 0x04000C5D RID: 3165
	public const int MAX_NB_AI_FORECAST = 8;

	// Token: 0x04000C5E RID: 3166
	public const int MAX_FORECASTED_OBJECTS = 512;

	// Token: 0x04000C5F RID: 3167
	public const int MAX_FORECASTED_POLYGONS = 32;

	// Token: 0x04000C60 RID: 3168
	public float BordersRange;

	// Token: 0x04000C61 RID: 3169
	public float BordersWeight;

	// Token: 0x04000C62 RID: 3170
	public float ForecastTime;

	// Token: 0x04000C63 RID: 3171
	public Forecasted[] ForecastedObjects = new Forecasted[512];

	// Token: 0x04000C64 RID: 3172
	public ForecastClient[] ForecastClients = new ForecastClient[8];

	// Token: 0x04000C65 RID: 3173
	protected uint _nbForecastedObjects;
}

﻿using System;
using UnityEngine;

// Token: 0x02000002 RID: 2
public class LocalizationManager : MonoBehaviour
{
	// Token: 0x06000002 RID: 2 RVA: 0x000020EB File Offset: 0x000002EB
	private void Awake()
	{
		UnityEngine.Object.DontDestroyOnLoad(this);
	}

	// Token: 0x06000003 RID: 3 RVA: 0x0000D364 File Offset: 0x0000B564
	private void Start()
	{
		if (!Debug.isDebugBuild || this.LanguageOverride == null || this.LanguageOverride == string.Empty)
		{
			SystemLanguage systemLanguage = Application.systemLanguage;
			if (systemLanguage != SystemLanguage.French)
			{
				Localization.instance.currentLanguage = "Lang_DB_UK";
			}
			else
			{
				Localization.instance.currentLanguage = "Lang_DB_FR";
			}
		}
		else
		{
			Localization.instance.currentLanguage = this.LanguageOverride;
		}
	}

	// Token: 0x04000001 RID: 1
	public string LanguageOverride = string.Empty;
}

﻿using System;
using UnityEngine;

// Token: 0x020001FD RID: 509
[ExecuteInEditMode]
public class RcFastPathComp : MonoBehaviour
{
	// Token: 0x06000DCB RID: 3531 RVA: 0x0000B771 File Offset: 0x00009971
	public RcFastPathComp()
	{
		this.m_bLoop = true;
		this.m_bDebugDraw = false;
		this.m_cDebugColor = Color.green;
	}

	// Token: 0x06000DCC RID: 3532 RVA: 0x0000B792 File Offset: 0x00009992
	public bool IsLooping()
	{
		return this.m_bLoop;
	}

	// Token: 0x06000DCD RID: 3533 RVA: 0x0000B79A File Offset: 0x0000999A
	public void SetLoop(bool val)
	{
		this.m_bLoop = val;
	}

	// Token: 0x06000DCE RID: 3534 RVA: 0x0000B7A3 File Offset: 0x000099A3
	public void Start()
	{
		this.m_pTransform = base.transform;
	}

	// Token: 0x06000DCF RID: 3535 RVA: 0x0005A0CC File Offset: 0x000582CC
	public void OnDrawGizmos()
	{
		if (this.m_bDebugDraw && Application.isEditor)
		{
			int childCount = this.m_pTransform.GetChildCount();
			if (childCount > 1)
			{
				Vector3 start = this.m_pTransform.GetChild(0).position;
				for (int i = 1; i < childCount; i++)
				{
					Vector3 position = this.m_pTransform.GetChild(i).position;
					Debug.DrawLine(start, position, this.m_cDebugColor, 0f, false);
					start = position;
				}
				if (this.m_bLoop)
				{
					Debug.DrawLine(start, this.m_pTransform.GetChild(0).position, this.m_cDebugColor, 0f, false);
				}
			}
		}
	}

	// Token: 0x04000D61 RID: 3425
	public bool m_bLoop;

	// Token: 0x04000D62 RID: 3426
	public bool m_bDebugDraw;

	// Token: 0x04000D63 RID: 3427
	public Color m_cDebugColor;

	// Token: 0x04000D64 RID: 3428
	public Transform m_pTransform;
}

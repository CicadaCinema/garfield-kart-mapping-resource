﻿using System;

// Token: 0x020000A3 RID: 163
public enum E_PathType
{
	// Token: 0x040003C2 RID: 962
	NONE,
	// Token: 0x040003C3 RID: 963
	GOOD,
	// Token: 0x040003C4 RID: 964
	AVERAGE,
	// Token: 0x040003C5 RID: 965
	BAD,
	// Token: 0x040003C6 RID: 966
	SHORTCUT
}

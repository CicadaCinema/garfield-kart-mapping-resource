﻿using System;
using UnityEngine;

// Token: 0x02000003 RID: 3
[AddComponentMenu("NGUI/Interaction/Language Selection")]
[RequireComponent(typeof(UIPopupList))]
public class LanguageSelection : MonoBehaviour
{
	// Token: 0x06000005 RID: 5 RVA: 0x000020FB File Offset: 0x000002FB
	private void Start()
	{
		this.mList = base.GetComponent<UIPopupList>();
		this.UpdateList();
		this.mList.eventReceiver = base.gameObject;
		this.mList.functionName = "OnLanguageSelection";
	}

	// Token: 0x06000006 RID: 6 RVA: 0x0000D3EC File Offset: 0x0000B5EC
	private void UpdateList()
	{
		if (Localization.instance != null && Localization.instance.languages != null)
		{
			this.mList.items.Clear();
			int i = 0;
			int num = Localization.instance.languages.Length;
			while (i < num)
			{
				TextAsset textAsset = Localization.instance.languages[i];
				if (textAsset != null)
				{
					this.mList.items.Add(textAsset.name);
				}
				i++;
			}
			this.mList.selection = Localization.instance.currentLanguage;
		}
	}

	// Token: 0x06000007 RID: 7 RVA: 0x00002130 File Offset: 0x00000330
	private void OnLanguageSelection(string language)
	{
		if (Localization.instance != null)
		{
			Localization.instance.currentLanguage = language;
		}
	}

	// Token: 0x04000002 RID: 2
	private UIPopupList mList;
}

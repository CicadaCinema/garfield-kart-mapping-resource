﻿using System;

// Token: 0x02000163 RID: 355
[Serializable]
public class RewardKart : RewardUnlockableItem
{
	// Token: 0x0600099B RID: 2459 RVA: 0x0004370C File Offset: 0x0004190C
	protected override void GetReward()
	{
		E_UnlockableItemSate kartState = Singleton<GameSaveManager>.Instance.GetKartState(this.Kart);
		if (kartState == E_UnlockableItemSate.Locked)
		{
			Singleton<RewardManager>.Instance.UnlockKart(this.Kart);
		}
	}

	// Token: 0x040009D1 RID: 2513
	public ECharacter Kart;
}

﻿using System;

// Token: 0x0200015E RID: 350
public class RewardConditionCoins : RewardConditionBase
{
	// Token: 0x06000993 RID: 2451 RVA: 0x000434DC File Offset: 0x000416DC
	public override bool CanGiveReward()
	{
		int collectedCoins = Singleton<GameSaveManager>.Instance.GetCollectedCoins();
		int coins = Singleton<RewardManager>.Instance.Coins;
		return collectedCoins < this.CollectedCoins && collectedCoins + coins >= this.CollectedCoins;
	}

	// Token: 0x040009C8 RID: 2504
	public int CollectedCoins;
}

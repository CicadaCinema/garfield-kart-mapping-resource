﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020001B9 RID: 441
public class MenuWelcome : AbstractMenu
{
	// Token: 0x06000BD1 RID: 3025 RVA: 0x00050C48 File Offset: 0x0004EE48
	public override void Awake()
	{
		base.Awake();
		UnityEngine.Object[] array = Resources.LoadAll("InApp", typeof(InAppCarac));
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i] is InAppCarac)
			{
				InAppCarac item = (InAppCarac)array[i];
				this.pCoinsCarac.Add(item);
			}
		}
		this.m_bIntroMusic = false;
		if (this.ButtonQuit)
		{
			if (Application.platform == RuntimePlatform.WindowsPlayer || Application.platform == RuntimePlatform.OSXPlayer || Application.platform == RuntimePlatform.LinuxPlayer)
			{
				this.ButtonQuit.SetActive(true);
			}
			else
			{
				this.ButtonQuit.SetActive(false);
			}
		}
		this.MenuMusicDelay += this.m_pMenuEntryPoint.IntroMusic.clip.length - (float)(this.m_pMenuEntryPoint.IntroMusic.timeSamples / this.m_pMenuEntryPoint.IntroMusic.clip.frequency);
	}

	// Token: 0x06000BD2 RID: 3026 RVA: 0x00050D48 File Offset: 0x0004EF48
	public new void Start()
	{
		EntryPoint component = GameObject.Find("EntryPoint").GetComponent<EntryPoint>();
		if (component.DisplayHighlightTutorial)
		{
			this.HighlightTutorial(null);
		}
		else if (component.AskForRating)
		{
			this.OnAskForRating();
		}
		else if (component.ShowInterstitial)
		{
			this.ShowInterstitial();
		}
	}

	// Token: 0x06000BD3 RID: 3027 RVA: 0x00050DA4 File Offset: 0x0004EFA4
	public override void OnEnter()
	{
		this.m_bIntroMusic = false;
		base.OnEnter();
		if (Singleton<ChallengeManager>.Instance.AlreadyPlayed)
		{
			this.ChallengeState.gameObject.SetActive(true);
			this.ChallengeState.ChangeTexture((!Singleton<ChallengeManager>.Instance.Success) ? 1 : 0);
		}
		else
		{
			this.ChallengeState.gameObject.SetActive(false);
		}
		Singleton<ChallengeManager>.Instance.DeActivate();
		if (this.ChallengeType != null)
		{
			if (Singleton<ChallengeManager>.Instance.IsMonday)
			{
				this.ChallengeType.spriteName = "icon_chalenge_monday";
			}
			else
			{
				this.ChallengeType.spriteName = "icon_chalenge_day";
			}
		}
		int num = Singleton<GameConfigurator>.Instance.PlayerConfig.NbStars - 1;
		for (int i = 0; i < this.Stars.Length; i++)
		{
			if (this.Stars[i])
			{
				this.Stars[i].SetActive(i <= num);
			}
		}
		this.ButtonSharing.SetActive(false);
		this.ButtonMoreApps.SetActive(false);
	}

	// Token: 0x06000BD4 RID: 3028 RVA: 0x0000A39B File Offset: 0x0000859B
	public override void OnExit()
	{
		base.OnExit();
		this.m_bIntroMusic = false;
		if (!this.m_pMenuEntryPoint.MenuMusic.isPlaying)
		{
			this.m_pMenuEntryPoint.StartFadingInMenuMusic(this.MenuMusicFadeInDuration);
		}
	}

	// Token: 0x06000BD5 RID: 3029 RVA: 0x00050ED0 File Offset: 0x0004F0D0
	public override void Update()
	{
		if (Application.platform == RuntimePlatform.Android && Input.GetKeyDown(KeyCode.Escape))
		{
			this.OnQuit();
		}
		if (!this.m_pMenuEntryPoint.MenuMusic.isPlaying)
		{
			this.MenuMusicDelay -= Time.deltaTime;
			if (this.MenuMusicDelay <= 0f)
			{
				this.m_pMenuEntryPoint.StartFadingInMenuMusic(this.MenuMusicFadeInDuration);
			}
		}
		if (this.HighlightTutorialPanel && this.HighlightTutorialPanel.activeSelf && Input.anyKeyDown)
		{
			this.OnHighlightTutorialExit();
		}
		if (this.ButtonSharing.activeSelf && !Singleton<GameSaveManager>.Instance.GetAskSharing())
		{
			this.ButtonSharing.SetActive(false);
		}
	}

	// Token: 0x06000BD6 RID: 3030 RVA: 0x0000A3D0 File Offset: 0x000085D0
	public void OnShop()
	{
		if (ASE_Tools.Available)
		{
			ASE_Flurry.LogEvent("MP_DEMARRER_MAGASIN");
		}
		this.m_pMenuEntryPoint.SetState(EMenus.MENU_SELECT_KART, 1);
	}

	// Token: 0x06000BD7 RID: 3031 RVA: 0x0000A3F3 File Offset: 0x000085F3
	public override void PlayMusic()
	{
		if (!this.m_pMenuEntryPoint.MenuMusic.isPlaying)
		{
			this.m_pMenuEntryPoint.PlayIntroMusic();
		}
		this.m_bIntroMusic = true;
	}

	// Token: 0x06000BD8 RID: 3032 RVA: 0x0000A41C File Offset: 0x0000861C
	public void OnQuit()
	{
		if (Application.platform != RuntimePlatform.WindowsWebPlayer && Application.platform != RuntimePlatform.OSXWebPlayer)
		{
			Application.Quit();
		}
	}

	// Token: 0x06000BD9 RID: 3033 RVA: 0x00050FA0 File Offset: 0x0004F1A0
	public void OnPlay(object param = null)
	{
		if (ASE_Tools.Available)
		{
			ASE_Flurry.LogEvent("MP_DEMARRER_MODE_PRINCIPAL");
		}
		if (Singleton<GameSaveManager>.Instance.GetFirstTime())
		{
			Popup2Choices popup2Choices = (Popup2Choices)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG_2CHOICES, false);
			if (popup2Choices)
			{
				popup2Choices.Show("MENU_POPUP_FIRSTTIME", new Popup2Choices.Callback(this.HighlightTutorial), new Popup2Choices.Callback(this.LaunchIGTutorial), EMenus.MENU_SOLO, "MENU_POPUP_NO", "MENU_POPUP_YES");
			}
		}
		else
		{
			this.ActSwapMenu(EMenus.MENU_SOLO);
		}
	}

	// Token: 0x06000BDA RID: 3034 RVA: 0x00051030 File Offset: 0x0004F230
	public void OnChallenge(object param = null)
	{
		if (ASE_Tools.Available)
		{
			ASE_Flurry.LogEvent("MP_DEMARRER_CHALLENGE_DU_JOUR");
		}
		if (Singleton<GameSaveManager>.Instance.GetFirstTime())
		{
			Popup2Choices popup2Choices = (Popup2Choices)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG_2CHOICES, false);
			if (popup2Choices)
			{
				popup2Choices.Show("MENU_POPUP_FIRSTTIME", new Popup2Choices.Callback(this.HighlightTutorial), new Popup2Choices.Callback(this.LaunchIGTutorial), EMenus.MENU_CHALLENGE, "MENU_POPUP_NO", "MENU_POPUP_YES");
			}
		}
		else
		{
			this.ActSwapMenu(EMenus.MENU_CHALLENGE);
		}
	}

	// Token: 0x06000BDB RID: 3035 RVA: 0x000510C0 File Offset: 0x0004F2C0
	public void HighlightTutorial(object param = null)
	{
		if (!this.HighlightTutorialPanel)
		{
			if (param != null)
			{
				this.ActSwapMenu((EMenus)((int)param));
			}
			return;
		}
		this.HighlightTutorialPanel.SetActive(true);
		GameObject.Find("EntryPoint").GetComponent<EntryPoint>().DisplayHighlightTutorial = false;
		if (param != null)
		{
			this.m_eOnHighlightTutorialExit = (EMenus)((int)param);
		}
		else
		{
			this.m_eOnHighlightTutorialExit = EMenus.MENU_WELCOME;
		}
	}

	// Token: 0x06000BDC RID: 3036 RVA: 0x0000A439 File Offset: 0x00008639
	public void OnHighlightTutorialExit()
	{
		this.HighlightTutorialPanel.SetActive(false);
		if (this.m_eOnHighlightTutorialExit != EMenus.MENU_WELCOME)
		{
			this.m_eOnHighlightTutorialExit = EMenus.MENU_WELCOME;
		}
	}

	// Token: 0x06000BDD RID: 3037 RVA: 0x00051130 File Offset: 0x0004F330
	public void LaunchIGTutorial(object param = null)
	{
		Singleton<GameSaveManager>.Instance.SetShowTutorial(false, true);
		GameObject.Find("EntryPoint").GetComponent<EntryPoint>().DisplayHighlightTutorial = true;
		Singleton<GameConfigurator>.Instance.GameModeType = E_GameModeType.TUTORIAL;
		ChampionShipData data = (ChampionShipData)Resources.Load("ChampionShip/Champion_Ship_1", typeof(ChampionShipData));
		Singleton<GameConfigurator>.Instance.SetChampionshipData(data, false);
		Singleton<GameConfigurator>.Instance.StartScene = Singleton<GameConfigurator>.Instance.ChampionShipData.Tracks[0];
		Singleton<GameConfigurator>.Instance.CurrentTrackIndex = 0;
		LoadingManager.LoadLevel(Singleton<GameConfigurator>.Instance.StartScene);
	}

	// Token: 0x06000BDE RID: 3038 RVA: 0x000511C4 File Offset: 0x0004F3C4
	public void OnAskForRating()
	{
		Popup3Choices popup3Choices = (Popup3Choices)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG_3CHOICES, false);
		if (popup3Choices)
		{
			popup3Choices.Show("MENU_POPUP_RATING", new Popup3Choices.Callback(this.OnNeverRate), new Popup3Choices.Callback(this.OnRate), new Popup3Choices.Callback(this.OnRemindRatingLater), null, "MENU_POPUP_NEVER_RATE", "MENU_POPUP_RATE_LATER", "MENU_POPUP_RATE");
		}
		EntryPoint component = GameObject.Find("EntryPoint").GetComponent<EntryPoint>();
		component.AskForRating = false;
	}

	// Token: 0x06000BDF RID: 3039 RVA: 0x0000A45C File Offset: 0x0000865C
	public void OnNeverRate(object param)
	{
		Singleton<GameSaveManager>.Instance.SetAskRating(-1, true);
	}

	// Token: 0x06000BE0 RID: 3040 RVA: 0x00003B80 File Offset: 0x00001D80
	public void OnRemindRatingLater(object param)
	{
	}

	// Token: 0x06000BE1 RID: 3041 RVA: 0x0000A45C File Offset: 0x0000865C
	public void OnRate(object param)
	{
		Singleton<GameSaveManager>.Instance.SetAskRating(-1, true);
	}

	// Token: 0x06000BE2 RID: 3042 RVA: 0x00051248 File Offset: 0x0004F448
	public void OnAskForSharing()
	{
		if (ASE_Tools.Available)
		{
			ASE_Flurry.LogEvent("MP_PARTAGE_FACEBOOK");
		}
		Popup2Choices popup2Choices = (Popup2Choices)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_FACEBOOK, false);
		if (popup2Choices)
		{
			popup2Choices.Show(null, new Popup2Choices.Callback(this.NoShare), new Popup2Choices.Callback(this.YesShare), null, null, null);
		}
		EntryPoint component = GameObject.Find("EntryPoint").GetComponent<EntryPoint>();
		component.AskForSharing = false;
	}

	// Token: 0x06000BE3 RID: 3043 RVA: 0x00003B80 File Offset: 0x00001D80
	public void NoShare(object param)
	{
	}

	// Token: 0x06000BE4 RID: 3044 RVA: 0x000512C0 File Offset: 0x0004F4C0
	public void YesShare(object param)
	{
		EntryPoint component = GameObject.Find("EntryPoint").GetComponent<EntryPoint>();
		component.DoSharing();
	}

	// Token: 0x06000BE5 RID: 3045 RVA: 0x0000A46A File Offset: 0x0000866A
	public void ShowInterstitial()
	{
		if (ASE_Tools.Available)
		{
			ASE_ChartBoost.ShowInterstitial("Default");
		}
	}

	// Token: 0x06000BE6 RID: 3046 RVA: 0x0000A480 File Offset: 0x00008680
	public void OnMoreApps()
	{
		if (ASE_Tools.Available)
		{
			ASE_Flurry.LogEvent("MP_DEMARRER_MORE_APPS");
			ASE_ChartBoost.ShowMoreApps();
		}
	}

	// Token: 0x06000BE7 RID: 3047 RVA: 0x000512E4 File Offset: 0x0004F4E4
	public override void ActSwapMenu(EMenus NextMenu)
	{
		if (ASE_Tools.Available)
		{
			if (NextMenu == EMenus.MENU_CREDITS)
			{
				ASE_Flurry.LogEvent("MP_DEMARRER_CREDITS");
			}
			else if (NextMenu == EMenus.MENU_OPTIONS)
			{
				ASE_Flurry.LogEvent("MP_DEMARRER_REGLAGES");
			}
			else if (NextMenu == EMenus.MENU_BEST_OF_GARFIELD)
			{
				ASE_Flurry.LogEvent("MP_DEMARRER_PUZZLE");
			}
			else if (NextMenu == EMenus.MENU_TUTO_HUB)
			{
				ASE_Flurry.LogEvent("MP_DEMARRER_TUTO");
			}
		}
		base.ActSwapMenu(NextMenu);
	}

	// Token: 0x04000BB6 RID: 2998
	private List<InAppCarac> pCoinsCarac = new List<InAppCarac>();

	// Token: 0x04000BB7 RID: 2999
	public UISprite ChallengeType;

	// Token: 0x04000BB8 RID: 3000
	public UITexturePattern ChallengeState;

	// Token: 0x04000BB9 RID: 3001
	private bool m_bIntroMusic;

	// Token: 0x04000BBA RID: 3002
	public GameObject[] Stars = new GameObject[5];

	// Token: 0x04000BBB RID: 3003
	public float MenuMusicFadeInDuration = 0.2f;

	// Token: 0x04000BBC RID: 3004
	public float MenuMusicDelay = -0.2f;

	// Token: 0x04000BBD RID: 3005
	public GameObject ButtonQuit;

	// Token: 0x04000BBE RID: 3006
	public GameObject ButtonSharing;

	// Token: 0x04000BBF RID: 3007
	public GameObject ButtonMoreApps;

	// Token: 0x04000BC0 RID: 3008
	public GameObject HighlightTutorialPanel;

	// Token: 0x04000BC1 RID: 3009
	private EMenus m_eOnHighlightTutorialExit = EMenus.MENU_WELCOME;
}

﻿using System;
using UnityEngine;

// Token: 0x020000E9 RID: 233
public class ParfumeBonusEffect : BonusEffect
{
	// Token: 0x170000FC RID: 252
	// (get) Token: 0x0600063B RID: 1595 RVA: 0x000066D8 File Offset: 0x000048D8
	public bool StinkParfume
	{
		get
		{
			return this.m_bStinkParfume;
		}
	}

	// Token: 0x0600063C RID: 1596 RVA: 0x00030C04 File Offset: 0x0002EE04
	public override void Start()
	{
		base.Start();
		this.InertiaVehicle = false;
		this.m_bStoppedByAnim = false;
		this.m_pCollider = base.collider;
		this.m_pTransform = base.transform;
		this.m_pCollider.enabled = false;
		this._attackEffect = (GameObject)UnityEngine.Object.Instantiate(this.AttackEffect);
		this._badAttackEffect = (GameObject)UnityEngine.Object.Instantiate(this.BadAttackEffect);
		this._usedEffect = (GameObject)UnityEngine.Object.Instantiate(this.UsedEffect);
		this._badUsedEffect = (GameObject)UnityEngine.Object.Instantiate(this.BadUsedEffect);
		this._usedEffect.transform.position = this.m_pBonusEffectMgr.Target.Transform.position;
		this._badUsedEffect.transform.position = this.m_pBonusEffectMgr.Target.Transform.position;
		this._usedEffect.transform.parent = this.m_pBonusEffectMgr.Target.Transform;
		this._badUsedEffect.transform.parent = this.m_pBonusEffectMgr.Target.Transform;
	}

	// Token: 0x0600063D RID: 1597 RVA: 0x00030D2C File Offset: 0x0002EF2C
	public override void OnDestroy()
	{
		if (this._attackEffect != null)
		{
			UnityEngine.Object.Destroy(this._attackEffect);
		}
		if (this._badAttackEffect != null)
		{
			UnityEngine.Object.Destroy(this._badAttackEffect);
		}
		if (this._usedEffect != null)
		{
			UnityEngine.Object.Destroy(this._usedEffect);
		}
		if (this._badUsedEffect != null)
		{
			UnityEngine.Object.Destroy(this._badUsedEffect);
		}
	}

	// Token: 0x0600063E RID: 1598 RVA: 0x0000600B File Offset: 0x0000420B
	public override void Update()
	{
		base.Update();
	}

	// Token: 0x0600063F RID: 1599 RVA: 0x000066E0 File Offset: 0x000048E0
	public override void SetDuration()
	{
		this.m_fCurrentDuration = this.EffectDuration + this.m_pBonusEffectMgr.Target.GetBonusMgr().GetBonusValue(EITEM.ITEM_PARFUME, EBonusCustomEffect.ATTRACT) * this.EffectDuration / 100f;
	}

	// Token: 0x06000640 RID: 1600 RVA: 0x00030DAC File Offset: 0x0002EFAC
	public override bool Activate()
	{
		base.Activate();
		Kart target = this.m_pBonusEffectMgr.Target;
		this.m_pTransform.parent = target.Transform;
		this.m_pTransform.localPosition = Vector3.zero;
		this.m_pCollider.enabled = true;
		this.m_bStinkParfume = (this.m_pBonusEffectMgr.Target.GetBonusMgr().GetBonusValue(EITEM.ITEM_PARFUME, EBonusCustomEffect.REPULSE) != 0f);
		if (this.m_bStinkParfume)
		{
			this._badAttackEffect.transform.position = target.Transform.position;
			this._badAttackEffect.transform.parent = target.Transform;
			this._badAttackEffect.transform.localPosition = target.Transform.rotation * this.ParfumeOffset;
			this._badAttackEffect.particleSystem.Play();
			this._badUsedEffect.particleSystem.Play();
		}
		else
		{
			this._attackEffect.transform.position = target.Transform.position;
			this._attackEffect.transform.parent = target.Transform;
			this._attackEffect.transform.localPosition = target.Transform.rotation * this.ParfumeOffset;
			this._attackEffect.particleSystem.Play();
			this._usedEffect.particleSystem.Play();
			NapBonusEffect napBonusEffect = (NapBonusEffect)target.BonusMgr.GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_SLEPT);
			if (napBonusEffect && napBonusEffect.Activated)
			{
				napBonusEffect.Deactivate();
			}
		}
		if (target.GetControlType() == RcVehicle.ControlType.Human)
		{
			Camera.mainCamera.GetComponent<CamStateFollow>().bBoost = true;
			ParticleSystem componentInChildren = Camera.mainCamera.GetComponentInChildren<ParticleSystem>();
			if (componentInChildren)
			{
				componentInChildren.Play();
			}
		}
		float speedUpMs = this.SpeedUp + this.m_pBonusEffectMgr.Target.GetBonusMgr().GetBonusValue(EITEM.ITEM_PARFUME, EBonusCustomEffect.REPULSE) * this.SpeedUp / 100f;
		target.ParfumeBoost(speedUpMs, this.EffectDuration);
		target.KartSound.PlayVoice(KartSound.EVoices.Good);
		if (target.OnBoost != null)
		{
			target.OnBoost();
		}
		target.Anim.LaunchSuccessAnim(true);
		this.ActivateParfumeSound.Play();
		if (!this.m_bStinkParfume)
		{
			this.GoodParfumeSound.Play();
		}
		else
		{
			this.BadParfumeSound.Play();
		}
		RcKinematicPhysic rcKinematicPhysic = (RcKinematicPhysic)target.GetVehiclePhysic();
		rcKinematicPhysic.m_fMass = this.NewMass;
		return true;
	}

	// Token: 0x06000641 RID: 1601 RVA: 0x0003103C File Offset: 0x0002F23C
	public override void Deactivate()
	{
		base.Deactivate();
		this.m_pTransform.parent = null;
		this.m_pCollider.enabled = false;
		if (this.m_bStinkParfume)
		{
			this._badAttackEffect.particleSystem.Stop();
			this._badAttackEffect.particleSystem.Clear();
			this._badUsedEffect.particleSystem.Stop();
			this._badUsedEffect.particleSystem.Clear();
		}
		else
		{
			this._attackEffect.particleSystem.Stop();
			this._attackEffect.particleSystem.Clear();
			this._usedEffect.particleSystem.Stop();
			this._usedEffect.particleSystem.Clear();
		}
		this._badUsedEffect.particleSystem.Stop();
		if (!this.m_bStinkParfume)
		{
			this.GoodParfumeSound.Stop();
		}
		else
		{
			this.BadParfumeSound.Stop();
		}
		Kart target = this.m_pBonusEffectMgr.Target;
		if (target.GetControlType() == RcVehicle.ControlType.Human)
		{
			ParticleSystem componentInChildren = Camera.mainCamera.GetComponentInChildren<ParticleSystem>();
			if (componentInChildren)
			{
				componentInChildren.Stop();
			}
			Camera.mainCamera.GetComponent<CamStateFollow>().bBoost = false;
		}
		target.GetComponent<PlayerCarac>().ApplyWeight();
	}

	// Token: 0x06000642 RID: 1602 RVA: 0x0003117C File Offset: 0x0002F37C
	public void OnTriggerEnter(Collider other)
	{
		if (this.Activated && this.StinkParfume && ((Network.peerType != NetworkPeerType.Disconnected && Network.isServer) || Network.peerType == NetworkPeerType.Disconnected))
		{
			Kart componentInChildren = other.gameObject.GetComponentInChildren<Kart>();
			if (componentInChildren == null)
			{
				return;
			}
			if (Network.isServer)
			{
				NetworkViewID viewID = other.gameObject.networkView.viewID;
				this.m_pBonusEffectMgr.Target.BonusMgr.networkView.RPC("OnStinkParfumeTriggerred", RPCMode.All, new object[]
				{
					viewID
				});
			}
			else if (Network.peerType == NetworkPeerType.Disconnected)
			{
				this.m_pBonusEffectMgr.Target.BonusMgr.DoStinkParfumeTriggerred(componentInChildren);
			}
		}
	}

	// Token: 0x04000615 RID: 1557
	public float NewMass = 10000f;

	// Token: 0x04000616 RID: 1558
	[HideInInspector]
	public GameObject AttackEffect;

	// Token: 0x04000617 RID: 1559
	private GameObject _attackEffect;

	// Token: 0x04000618 RID: 1560
	public GameObject BadAttackEffect;

	// Token: 0x04000619 RID: 1561
	private GameObject _badAttackEffect;

	// Token: 0x0400061A RID: 1562
	public GameObject UsedEffect;

	// Token: 0x0400061B RID: 1563
	private GameObject _usedEffect;

	// Token: 0x0400061C RID: 1564
	public GameObject BadUsedEffect;

	// Token: 0x0400061D RID: 1565
	private GameObject _badUsedEffect;

	// Token: 0x0400061E RID: 1566
	private bool m_bStinkParfume;

	// Token: 0x0400061F RID: 1567
	private Transform m_pTransform;

	// Token: 0x04000620 RID: 1568
	public Vector3 ParfumeOffset;

	// Token: 0x04000621 RID: 1569
	[SerializeField]
	[HideInInspector]
	public float SpeedUp;

	// Token: 0x04000622 RID: 1570
	[HideInInspector]
	[SerializeField]
	public float Acceleration;

	// Token: 0x04000623 RID: 1571
	private Collider m_pCollider;

	// Token: 0x04000624 RID: 1572
	public AudioSource ActivateParfumeSound;

	// Token: 0x04000625 RID: 1573
	public AudioSource GoodParfumeSound;

	// Token: 0x04000626 RID: 1574
	public AudioSource BadParfumeSound;

	// Token: 0x04000627 RID: 1575
	public AudioSource BadParfumeCollisionSound;
}

﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000179 RID: 377
internal class RankComparer : IComparer<Tuple<int, GameObject>>
{
	// Token: 0x06000A18 RID: 2584 RVA: 0x00008DE2 File Offset: 0x00006FE2
	public RankComparer(RacingAIManager pAIManager)
	{
		this._aiManager = pAIManager;
	}

	// Token: 0x06000A19 RID: 2585 RVA: 0x00046088 File Offset: 0x00044288
	public int Compare(GameObject pFirstGO, GameObject pSecondGO)
	{
		int aiindex = pFirstGO.GetComponentInChildren<RcVirtualController>().AIIndex;
		int aiindex2 = pSecondGO.GetComponentInChildren<RcVirtualController>().AIIndex;
		RacingAI racingAI = this._aiManager.AIs[aiindex];
		RacingAI racingAI2 = this._aiManager.AIs[aiindex2];
		if (racingAI.Level == racingAI2.Level)
		{
			RcVehicleRaceStats componentInChildren = pFirstGO.GetComponentInChildren<RcVehicleRaceStats>();
			RcVehicleRaceStats componentInChildren2 = pSecondGO.GetComponentInChildren<RcVehicleRaceStats>();
			if (componentInChildren.GetRank() < componentInChildren2.GetRank())
			{
				return -1;
			}
			return 1;
		}
		else
		{
			RcVehicleRaceStats componentInChildren3 = pFirstGO.GetComponentInChildren<RcVehicleRaceStats>();
			RcVehicleRaceStats componentInChildren4 = pFirstGO.GetComponentInChildren<RcVehicleRaceStats>();
			if ((float)racingAI.Level * componentInChildren3.GetDistToEndOfRace() < (float)racingAI2.Level * componentInChildren4.GetDistToEndOfRace())
			{
				return -1;
			}
			return 1;
		}
	}

	// Token: 0x06000A1A RID: 2586 RVA: 0x00008DF1 File Offset: 0x00006FF1
	public int Compare(Tuple<int, GameObject> x, Tuple<int, GameObject> y)
	{
		return this.Compare(x.Item2, y.Item2);
	}

	// Token: 0x04000A21 RID: 2593
	private RacingAIManager _aiManager;
}

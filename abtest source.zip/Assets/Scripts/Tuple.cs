﻿using System;

// Token: 0x02000255 RID: 597
[Serializable]
public class Tuple<T1>
{
	// Token: 0x06001078 RID: 4216 RVA: 0x000677A4 File Offset: 0x000659A4
	public Tuple() : this(default(T1))
	{
	}

	// Token: 0x06001079 RID: 4217 RVA: 0x0000D168 File Offset: 0x0000B368
	public Tuple(T1 pItem1)
	{
		this.Item1 = pItem1;
	}

	// Token: 0x04000FBA RID: 4026
	public T1 Item1;
}

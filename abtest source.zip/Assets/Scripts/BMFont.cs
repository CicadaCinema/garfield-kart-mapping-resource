﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200003C RID: 60
[Serializable]
public class BMFont
{
	// Token: 0x1700001E RID: 30
	// (get) Token: 0x06000131 RID: 305 RVA: 0x0000308C File Offset: 0x0000128C
	public bool isValid
	{
		get
		{
			return this.mSaved.Count > 0;
		}
	}

	// Token: 0x1700001F RID: 31
	// (get) Token: 0x06000132 RID: 306 RVA: 0x0000309C File Offset: 0x0000129C
	// (set) Token: 0x06000133 RID: 307 RVA: 0x000030A4 File Offset: 0x000012A4
	public int charSize
	{
		get
		{
			return this.mSize;
		}
		set
		{
			this.mSize = value;
		}
	}

	// Token: 0x17000020 RID: 32
	// (get) Token: 0x06000134 RID: 308 RVA: 0x000030AD File Offset: 0x000012AD
	// (set) Token: 0x06000135 RID: 309 RVA: 0x000030B5 File Offset: 0x000012B5
	public int baseOffset
	{
		get
		{
			return this.mBase;
		}
		set
		{
			this.mBase = value;
		}
	}

	// Token: 0x17000021 RID: 33
	// (get) Token: 0x06000136 RID: 310 RVA: 0x000030BE File Offset: 0x000012BE
	// (set) Token: 0x06000137 RID: 311 RVA: 0x000030C6 File Offset: 0x000012C6
	public int texWidth
	{
		get
		{
			return this.mWidth;
		}
		set
		{
			this.mWidth = value;
		}
	}

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x06000138 RID: 312 RVA: 0x000030CF File Offset: 0x000012CF
	// (set) Token: 0x06000139 RID: 313 RVA: 0x000030D7 File Offset: 0x000012D7
	public int texHeight
	{
		get
		{
			return this.mHeight;
		}
		set
		{
			this.mHeight = value;
		}
	}

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x0600013A RID: 314 RVA: 0x000030E0 File Offset: 0x000012E0
	public int glyphCount
	{
		get
		{
			return (!this.isValid) ? 0 : this.mSaved.Count;
		}
	}

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x0600013B RID: 315 RVA: 0x000030FE File Offset: 0x000012FE
	// (set) Token: 0x0600013C RID: 316 RVA: 0x00003106 File Offset: 0x00001306
	public string spriteName
	{
		get
		{
			return this.mSpriteName;
		}
		set
		{
			this.mSpriteName = value;
		}
	}

	// Token: 0x0600013D RID: 317 RVA: 0x00013ABC File Offset: 0x00011CBC
	public BMGlyph GetGlyph(int index, bool createIfMissing)
	{
		BMGlyph bmglyph = null;
		if (this.mDict.Count == 0)
		{
			int i = 0;
			int count = this.mSaved.Count;
			while (i < count)
			{
				BMGlyph bmglyph2 = this.mSaved[i];
				this.mDict.Add(bmglyph2.index, bmglyph2);
				i++;
			}
		}
		if (!this.mDict.TryGetValue(index, out bmglyph) && createIfMissing)
		{
			bmglyph = new BMGlyph();
			bmglyph.index = index;
			this.mSaved.Add(bmglyph);
			this.mDict.Add(index, bmglyph);
		}
		return bmglyph;
	}

	// Token: 0x0600013E RID: 318 RVA: 0x0000310F File Offset: 0x0000130F
	public BMGlyph GetGlyph(int index)
	{
		return this.GetGlyph(index, false);
	}

	// Token: 0x0600013F RID: 319 RVA: 0x00003119 File Offset: 0x00001319
	public void Clear()
	{
		this.mDict.Clear();
		this.mSaved.Clear();
	}

	// Token: 0x06000140 RID: 320 RVA: 0x00013B58 File Offset: 0x00011D58
	public void Trim(int xMin, int yMin, int xMax, int yMax)
	{
		if (this.isValid)
		{
			int i = 0;
			int count = this.mSaved.Count;
			while (i < count)
			{
				BMGlyph bmglyph = this.mSaved[i];
				if (bmglyph != null)
				{
					bmglyph.Trim(xMin, yMin, xMax, yMax);
				}
				i++;
			}
		}
	}

	// Token: 0x04000155 RID: 341
	[HideInInspector]
	[SerializeField]
	private int mSize;

	// Token: 0x04000156 RID: 342
	[HideInInspector]
	[SerializeField]
	private int mBase;

	// Token: 0x04000157 RID: 343
	[SerializeField]
	[HideInInspector]
	private int mWidth;

	// Token: 0x04000158 RID: 344
	[SerializeField]
	[HideInInspector]
	private int mHeight;

	// Token: 0x04000159 RID: 345
	[SerializeField]
	[HideInInspector]
	private string mSpriteName;

	// Token: 0x0400015A RID: 346
	[SerializeField]
	[HideInInspector]
	private List<BMGlyph> mSaved = new List<BMGlyph>();

	// Token: 0x0400015B RID: 347
	private Dictionary<int, BMGlyph> mDict = new Dictionary<int, BMGlyph>();
}

﻿using System;
using UnityEngine;

// Token: 0x02000079 RID: 121
[AddComponentMenu("NGUI/UI/Input (Saved)")]
public class UIInputSaved : UIInput
{
	// Token: 0x1700008E RID: 142
	// (get) Token: 0x06000333 RID: 819 RVA: 0x0000471E File Offset: 0x0000291E
	// (set) Token: 0x06000334 RID: 820 RVA: 0x00004726 File Offset: 0x00002926
	public override string text
	{
		get
		{
			return base.text;
		}
		set
		{
			base.text = value;
			this.SaveToPlayerPrefs(value);
		}
	}

	// Token: 0x06000335 RID: 821 RVA: 0x0001E418 File Offset: 0x0001C618
	private void Awake()
	{
		this.onSubmit = new UIInput.OnSubmit(this.SaveToPlayerPrefs);
		if (!string.IsNullOrEmpty(this.playerPrefsField) && PlayerPrefs.HasKey(this.playerPrefsField))
		{
			this.text = PlayerPrefs.GetString(this.playerPrefsField);
		}
	}

	// Token: 0x06000336 RID: 822 RVA: 0x00004736 File Offset: 0x00002936
	private void SaveToPlayerPrefs(string val)
	{
		if (!string.IsNullOrEmpty(this.playerPrefsField))
		{
			PlayerPrefs.SetString(this.playerPrefsField, val);
		}
	}

	// Token: 0x06000337 RID: 823 RVA: 0x00004754 File Offset: 0x00002954
	private void OnApplicationQuit()
	{
		this.SaveToPlayerPrefs(this.text);
	}

	// Token: 0x040002C8 RID: 712
	public string playerPrefsField;
}

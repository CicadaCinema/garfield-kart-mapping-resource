﻿using System;
using AnimationOrTween;
using UnityEngine;

// Token: 0x02000013 RID: 19
[AddComponentMenu("NGUI/Interaction/Checkbox")]
public class UICheckbox : MonoBehaviour
{
	// Token: 0x17000004 RID: 4
	// (get) Token: 0x06000059 RID: 89 RVA: 0x00002661 File Offset: 0x00000861
	// (set) Token: 0x0600005A RID: 90 RVA: 0x00002669 File Offset: 0x00000869
	public bool isChecked
	{
		get
		{
			return this.mChecked;
		}
		set
		{
			if (this.radioButtonRoot == null || value || this.optionCanBeNone || !this.mStarted)
			{
				this.Set(value);
			}
		}
	}

	// Token: 0x0600005B RID: 91 RVA: 0x0000E95C File Offset: 0x0000CB5C
	private void Awake()
	{
		this.mTrans = base.transform;
		if (this.checkSprite != null)
		{
			this.checkSprite.alpha = ((!this.startsChecked) ? 0f : 1f);
		}
		if (this.option)
		{
			this.option = false;
			if (this.radioButtonRoot == null)
			{
				this.radioButtonRoot = this.mTrans.parent;
			}
		}
	}

	// Token: 0x0600005C RID: 92 RVA: 0x0000E9E0 File Offset: 0x0000CBE0
	private void Start()
	{
		if (this.eventReceiver == null)
		{
			this.eventReceiver = base.gameObject;
		}
		this.mChecked = !this.startsChecked;
		this.mStarted = true;
		this.Set(this.startsChecked);
	}

	// Token: 0x0600005D RID: 93 RVA: 0x0000269F File Offset: 0x0000089F
	private void OnClick()
	{
		if (base.enabled)
		{
			this.isChecked = !this.isChecked;
		}
	}

	// Token: 0x0600005E RID: 94 RVA: 0x0000EA2C File Offset: 0x0000CC2C
	private void Set(bool state)
	{
		if (!this.mStarted)
		{
			this.mChecked = state;
			this.startsChecked = state;
			if (this.checkSprite != null)
			{
				this.checkSprite.alpha = ((!state) ? 0f : 1f);
			}
		}
		else if (this.mChecked != state)
		{
			if (this.radioButtonRoot != null && state)
			{
				UICheckbox[] componentsInChildren = this.radioButtonRoot.GetComponentsInChildren<UICheckbox>(true);
				int i = 0;
				int num = componentsInChildren.Length;
				while (i < num)
				{
					UICheckbox uicheckbox = componentsInChildren[i];
					if (uicheckbox != this && uicheckbox.radioButtonRoot == this.radioButtonRoot)
					{
						uicheckbox.Set(false);
					}
					i++;
				}
			}
			this.mChecked = state;
			if (this.checkSprite != null)
			{
				if (this.instantTween)
				{
					this.checkSprite.alpha = ((!this.mChecked) ? 0f : 1f);
				}
				else
				{
					TweenAlpha.Begin(this.checkSprite.gameObject, 0.15f, (!this.mChecked) ? 0f : 1f);
				}
			}
			UICheckbox.current = this;
			if (this.onStateChange != null)
			{
				this.onStateChange(this.mChecked);
			}
			if (this.eventReceiver != null && !string.IsNullOrEmpty(this.functionName))
			{
				this.eventReceiver.SendMessage(this.functionName, this.mChecked, SendMessageOptions.DontRequireReceiver);
			}
			UICheckbox.current = null;
			if (this.checkAnimation != null)
			{
				ActiveAnimation.Play(this.checkAnimation, (!state) ? Direction.Reverse : Direction.Forward);
			}
		}
	}

	// Token: 0x0400005F RID: 95
	public static UICheckbox current;

	// Token: 0x04000060 RID: 96
	public UISprite checkSprite;

	// Token: 0x04000061 RID: 97
	public Animation checkAnimation;

	// Token: 0x04000062 RID: 98
	public bool instantTween;

	// Token: 0x04000063 RID: 99
	public bool startsChecked = true;

	// Token: 0x04000064 RID: 100
	public Transform radioButtonRoot;

	// Token: 0x04000065 RID: 101
	public bool optionCanBeNone;

	// Token: 0x04000066 RID: 102
	public GameObject eventReceiver;

	// Token: 0x04000067 RID: 103
	public string functionName = "OnActivate";

	// Token: 0x04000068 RID: 104
	public UICheckbox.OnStateChange onStateChange;

	// Token: 0x04000069 RID: 105
	[SerializeField]
	[HideInInspector]
	private bool option;

	// Token: 0x0400006A RID: 106
	private bool mChecked = true;

	// Token: 0x0400006B RID: 107
	private bool mStarted;

	// Token: 0x0400006C RID: 108
	private Transform mTrans;

	// Token: 0x02000014 RID: 20
	// (Invoke) Token: 0x06000060 RID: 96
	public delegate void OnStateChange(bool state);
}

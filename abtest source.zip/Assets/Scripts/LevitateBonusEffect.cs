﻿using System;
using UnityEngine;

// Token: 0x020000DC RID: 220
public class LevitateBonusEffect : BonusEffect
{
	// Token: 0x060005E1 RID: 1505 RVA: 0x000062C7 File Offset: 0x000044C7
	public LevitateBonusEffect()
	{
		this.m_pOwner = null;
	}

	// Token: 0x170000FA RID: 250
	// (set) Token: 0x060005E2 RID: 1506 RVA: 0x000062D6 File Offset: 0x000044D6
	public UFO Owner
	{
		set
		{
			this.m_pOwner = value;
		}
	}

	// Token: 0x060005E3 RID: 1507 RVA: 0x000062DF File Offset: 0x000044DF
	public override void Start()
	{
		this.m_iAnimParameter = Animator.StringToHash("Ufo");
		this.m_iAnimState = Animator.StringToHash("Base Layer.Ufo");
		this.m_bStoppedByAnim = false;
		base.Start();
	}

	// Token: 0x060005E4 RID: 1508 RVA: 0x0002F114 File Offset: 0x0002D314
	public override void Update()
	{
		base.Update();
		if (this.Activated && !this.m_bStopLevitate && this.m_pBonusEffectMgr.Target.Transform.position.y > this.m_pOwner.Transform.position.y - this.m_pOwner.LevitateOffset && this.m_pOwner.Parent.GetState() == BonusEntity.BonusState.BONUS_ONGROUND)
		{
			Kart target = this.m_pBonusEffectMgr.Target;
			RcKinematicPhysic rcKinematicPhysic = (RcKinematicPhysic)target.GetVehiclePhysic();
			rcKinematicPhysic.SetLinearVelocity(new Vector3(0f, 0f, 0f));
			this.m_bStopLevitate = true;
		}
	}

	// Token: 0x060005E5 RID: 1509 RVA: 0x0000630E File Offset: 0x0000450E
	public override void SetDuration()
	{
		this.m_fCurrentDuration = this.EffectDuration + this.m_pOwner.Parent.BonusDuration * this.EffectDuration / 100f;
	}

	// Token: 0x060005E6 RID: 1510 RVA: 0x0002F1D4 File Offset: 0x0002D3D4
	public override bool Activate()
	{
		Kart target = this.m_pBonusEffectMgr.Target;
		RcKinematicPhysic rcKinematicPhysic = (RcKinematicPhysic)target.GetVehiclePhysic();
		float num = this.m_pOwner.Parent.UfoHeight - this.m_pOwner.LevitateOffset;
		Vector3 impulseForce = new Vector3(0f, num / 1f, 0f);
		this.ImpulseForce = impulseForce;
		rcKinematicPhysic.SetLinearVelocity(new Vector3(0f, 0f, 0f));
		base.Activate();
		this.m_bStopLevitate = false;
		target.CancelDrift();
		if (rcKinematicPhysic != null)
		{
			this.m_fPreviousAirGravity = rcKinematicPhysic.m_fAirAdditionnalGravity;
			this.m_fPreviousGroundGravity = rcKinematicPhysic.m_fGroundAdditionnalGravity;
			rcKinematicPhysic.m_fAirAdditionnalGravity = Physics.gravity.y;
			rcKinematicPhysic.m_fGroundAdditionnalGravity = Physics.gravity.y;
		}
		target.KartSound.PlaySound(15);
		return true;
	}

	// Token: 0x060005E7 RID: 1511 RVA: 0x0002F2C0 File Offset: 0x0002D4C0
	public override void Deactivate()
	{
		base.Deactivate();
		Kart target = this.m_pBonusEffectMgr.Target;
		RcKinematicPhysic rcKinematicPhysic = (RcKinematicPhysic)target.GetVehiclePhysic();
		if (rcKinematicPhysic != null)
		{
			rcKinematicPhysic.m_fAirAdditionnalGravity = this.m_fPreviousAirGravity;
			rcKinematicPhysic.m_fGroundAdditionnalGravity = this.m_fPreviousGroundGravity;
		}
		if (this.m_pOwner != null && (Network.peerType == NetworkPeerType.Disconnected || Network.isServer))
		{
			this.m_pOwner.RemoveUFO(false);
		}
		target.KartSound.StopSound(15);
	}

	// Token: 0x040005DB RID: 1499
	private UFO m_pOwner;

	// Token: 0x040005DC RID: 1500
	private float m_fPreviousGroundGravity;

	// Token: 0x040005DD RID: 1501
	private float m_fPreviousAirGravity;

	// Token: 0x040005DE RID: 1502
	private bool m_bStopLevitate;
}

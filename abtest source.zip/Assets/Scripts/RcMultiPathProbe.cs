﻿using System;
using UnityEngine;

// Token: 0x02000202 RID: 514
public class RcMultiPathProbe : MonoBehaviour
{
	// Token: 0x04000D71 RID: 3441
	public RcMultiPath Path;

	// Token: 0x04000D72 RID: 3442
	public int SegmentForward = 2;

	// Token: 0x04000D73 RID: 3443
	public int SegmentBackward = 1;

	// Token: 0x04000D74 RID: 3444
	public bool Project2D;

	// Token: 0x04000D75 RID: 3445
	public bool ForceHeight = true;

	// Token: 0x04000D76 RID: 3446
	public float Height = 2f;

	// Token: 0x04000D77 RID: 3447
	public bool DebugDraw = true;

	// Token: 0x04000D78 RID: 3448
	public float DebugScale = 1f;

	// Token: 0x04000D79 RID: 3449
	public bool DebugReset;

	// Token: 0x04000D7A RID: 3450
	public GUIStyle DebugGuiStyle;

	// Token: 0x04000D7B RID: 3451
	public bool DrawProgress;

	// Token: 0x04000D7C RID: 3452
	public float ProgressStep = 25f;
}

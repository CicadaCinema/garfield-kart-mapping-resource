﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200010F RID: 271
public class HUDInGame : MonoBehaviour
{
	// Token: 0x17000117 RID: 279
	// (get) Token: 0x06000756 RID: 1878 RVA: 0x0000738E File Offset: 0x0000558E
	public HUDPause HUDPause
	{
		get
		{
			return this.m_pHudPauseComp;
		}
	}

	// Token: 0x17000118 RID: 280
	// (get) Token: 0x06000757 RID: 1879 RVA: 0x00007396 File Offset: 0x00005596
	public HUDRadar HudRadarComp
	{
		get
		{
			return this._hudRadarComp;
		}
	}

	// Token: 0x17000119 RID: 281
	// (get) Token: 0x06000758 RID: 1880 RVA: 0x0000739E File Offset: 0x0000559E
	public HUDCountdown Countdown
	{
		get
		{
			return this.m_pHudCountdownComp;
		}
	}

	// Token: 0x1700011A RID: 282
	// (get) Token: 0x06000759 RID: 1881 RVA: 0x000073A6 File Offset: 0x000055A6
	public HUDBonus Bonus
	{
		get
		{
			return this.m_pHudBonusComp;
		}
	}

	// Token: 0x1700011B RID: 283
	// (get) Token: 0x0600075A RID: 1882 RVA: 0x000073AE File Offset: 0x000055AE
	public HUDPosition Position
	{
		get
		{
			return this.m_pHudPositionComp;
		}
	}

	// Token: 0x1700011C RID: 284
	// (get) Token: 0x0600075B RID: 1883 RVA: 0x000073B6 File Offset: 0x000055B6
	public HUDTrackPresentation TrackPresentation
	{
		get
		{
			return this.m_pHudTrackPresentationComp;
		}
	}

	// Token: 0x1700011D RID: 285
	// (get) Token: 0x0600075C RID: 1884 RVA: 0x000073BE File Offset: 0x000055BE
	public HUDTutorial HUDTutorial
	{
		get
		{
			return this.m_pHudTutorialComp;
		}
	}

	// Token: 0x1700011E RID: 286
	// (get) Token: 0x0600075D RID: 1885 RVA: 0x000073C6 File Offset: 0x000055C6
	public HUDEndChampionsShipRace EndChampionshipRace
	{
		get
		{
			return this.m_pHudEndChampionshipRaceComp;
		}
	}

	// Token: 0x1700011F RID: 287
	// (get) Token: 0x0600075E RID: 1886 RVA: 0x000073CE File Offset: 0x000055CE
	public HUDEndSingleRace HUDEndSingleRace
	{
		get
		{
			return this.m_pHudEndSingleRaceComp;
		}
	}

	// Token: 0x17000120 RID: 288
	// (get) Token: 0x0600075F RID: 1887 RVA: 0x000073D6 File Offset: 0x000055D6
	public HUDEndTimeTrial HUDEndTimeTrial
	{
		get
		{
			return this.m_pHudEndTimeTrialComp;
		}
	}

	// Token: 0x17000121 RID: 289
	// (get) Token: 0x06000760 RID: 1888 RVA: 0x000073DE File Offset: 0x000055DE
	public HUDResultsTimeTrial HUDTimeTrialResults
	{
		get
		{
			return this.m_pHudTimeTrialResultsComp;
		}
	}

	// Token: 0x17000122 RID: 290
	// (get) Token: 0x06000761 RID: 1889 RVA: 0x000073E6 File Offset: 0x000055E6
	public HUDEndTimeTrialMedal HUDEndTimeTrial2
	{
		get
		{
			return this.m_pHudEndTimeTrialMedalComp;
		}
	}

	// Token: 0x17000123 RID: 291
	// (get) Token: 0x06000762 RID: 1890 RVA: 0x000073EE File Offset: 0x000055EE
	public HUDFinish HUDFinish
	{
		get
		{
			return this.m_pHudFinishComp;
		}
	}

	// Token: 0x17000124 RID: 292
	// (get) Token: 0x06000763 RID: 1891 RVA: 0x000073F6 File Offset: 0x000055F6
	public HUDFade HUDFade
	{
		get
		{
			return this.m_pHudFadeComp;
		}
	}

	// Token: 0x17000125 RID: 293
	// (get) Token: 0x06000764 RID: 1892 RVA: 0x000073FE File Offset: 0x000055FE
	public GameObject HudEndChampionshipRace
	{
		get
		{
			return this._hudEndChampionShipRace;
		}
	}

	// Token: 0x17000126 RID: 294
	// (get) Token: 0x06000765 RID: 1893 RVA: 0x00007406 File Offset: 0x00005606
	public GameObject HudEndChampionshipRank
	{
		get
		{
			return this._hudEndChampionShipRank;
		}
	}

	// Token: 0x17000127 RID: 295
	// (get) Token: 0x06000766 RID: 1894 RVA: 0x0000740E File Offset: 0x0000560E
	public GameObject NextButton
	{
		get
		{
			return this._nextButton;
		}
	}

	// Token: 0x17000128 RID: 296
	// (get) Token: 0x06000767 RID: 1895 RVA: 0x00007416 File Offset: 0x00005616
	public bool FinishLineCrossed
	{
		get
		{
			return this.m_bFinishLineCrossed;
		}
	}

	// Token: 0x17000129 RID: 297
	// (get) Token: 0x06000768 RID: 1896 RVA: 0x0000741E File Offset: 0x0000561E
	public bool EndHUDDisplayed
	{
		get
		{
			return this.m_bEndHUDDisplayed;
		}
	}

	// Token: 0x06000769 RID: 1897 RVA: 0x00036F98 File Offset: 0x00035198
	public void Awake()
	{
		this.m_pHudBonus = null;
		this.m_pHudControls = null;
		this.m_pHudPosition = null;
		this.m_pHudCountdown = null;
		this.m_pHudControlsComp = null;
		this._hudEndChampionShipRace = null;
		this._hudEndChampionShipRank = null;
		this._hudEndTimeTrialRace1 = null;
		this._hudEndTimeTrialRace2 = null;
		this._hudTimeTrialResults = null;
		this.m_bEndChampionshipSecond = false;
		this.m_pHudTrackPresentation = null;
		this.m_pHudCountdownComp = null;
		this.m_pHudBonusComp = null;
		this.m_pHudPositionComp = null;
		this.m_pHudFinish = null;
		this.m_pHudChallenge = null;
		this.m_pHudFadeComp = null;
		this.m_pHudFade = null;
		HUDNextButton.OnNextClick = (Action)Delegate.Combine(HUDNextButton.OnNextClick, new Action(this.DoNext));
		this.m_pHudBonus = GameObject.Find("PanelBonus");
		GameObject gameObject = GameObject.Find("PanelControles");
		if (gameObject)
		{
			gameObject.SetActive(false);
		}
		GameObject gameObject2 = GameObject.Find("PanelControles43");
		if (gameObject2)
		{
			gameObject2.SetActive(false);
		}
		if (!Tricks.isTablet())
		{
			this.m_pHudControls = gameObject;
		}
		else
		{
			this.m_pHudControls = gameObject2;
		}
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			this.m_pHudControls.SetActive(true);
		}
		this.m_pHudPosition = GameObject.Find("PanelPosition");
		this.m_pHudCountdown = GameObject.Find("PanelCountdown");
		this.m_pHudTrackPresentation = GameObject.Find("PanelTrackPresentation");
		this.m_pHudTutorial = GameObject.Find("PanelTutorial");
		if (this.m_pHudTutorial != null)
		{
			this.m_pHudTutorial.SetActive(false);
		}
		GameObject gameObject3 = GameObject.Find("PanelTutorial43");
		gameObject3.SetActive(false);
		if (Tricks.isTablet())
		{
			this.m_pHudTutorial = gameObject3;
		}
		this.m_pHudFinish = GameObject.Find("PanelFinish");
		this.m_pHudChallenge = GameObject.Find("PanelResultatsChallenge");
		this.m_pHudPauseComp = base.gameObject.GetComponent<HUDPause>();
		this.m_pHudControlsComp = this.m_pHudControls.GetComponent<HUDControls>();
		this.m_pHudCountdownComp = this.m_pHudCountdown.GetComponent<HUDCountdown>();
		this.m_pHudBonusComp = base.GetComponent<HUDBonus>();
		this.m_pHudPositionComp = this.m_pHudPosition.GetComponent<HUDPosition>();
		this.m_pHudTrackPresentationComp = this.m_pHudTrackPresentation.GetComponent<HUDTrackPresentation>();
		if (this.m_pHudTutorial != null)
		{
			this.m_pHudTutorialComp = this.m_pHudTutorial.GetComponent<HUDTutorial>();
		}
		this.m_pHudFinishComp = this.m_pHudFinish.GetComponent<HUDFinish>();
		this._hudEndChampionShipRace = GameObject.Find("PanelEndChampionship1");
		this.m_pHudEndChampionshipRaceComp = this._hudEndChampionShipRace.GetComponent<HUDEndChampionsShipRace>();
		this.m_pHudEndChampionshipRaceComp.Init();
		this._hudEndChampionShipRank = GameObject.Find("PanelEndChampionship2");
		this._hudEndChampionShipRank.GetComponent<HUDChampionsShipRanking>().Init();
		this._hudEndSingleRace = GameObject.Find("PanelEndRace");
		this.m_pHudEndSingleRaceComp = this._hudEndSingleRace.GetComponent<HUDEndSingleRace>();
		this.m_pHudEndSingleRaceComp.Init();
		this._hudEndTimeTrialRace1 = GameObject.Find("PanelEndTimeTrial1");
		this._hudEndTimeTrialRace2 = GameObject.Find("PanelEndTimeTrial2");
		this._hudTimeTrialResults = GameObject.Find("PanelResultatsTimeTrial");
		this.m_pHudEndTimeTrialComp = this._hudEndTimeTrialRace1.GetComponent<HUDEndTimeTrial>();
		this.m_pHudTimeTrialResultsComp = this._hudTimeTrialResults.GetComponent<HUDResultsTimeTrial>();
		this.m_pHudEndTimeTrialMedalComp = this._hudEndTimeTrialRace2.GetComponent<HUDEndTimeTrialMedal>();
		this._hudChampionShipResult = GameObject.Find("PanelResultatsChampionnat");
		this._nextButton = GameObject.Find("PanelButtonNext");
		this._hudRadar = GameObject.Find("PanelRadar");
		this._hudRadarComp = this._hudRadar.GetComponent<HUDRadar>();
		this.m_pHudFade = GameObject.Find("PanelFade");
		this.m_pHudFadeComp = this.m_pHudFade.GetComponentInChildren<HUDFade>();
		this.m_bNeedToEnterFinishRace = false;
		this.m_oNetworkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
	}

	// Token: 0x1700012A RID: 298
	// (get) Token: 0x0600076A RID: 1898 RVA: 0x00007426 File Offset: 0x00005626
	public HUDControls HUDControls
	{
		get
		{
			return this.m_pHudControlsComp;
		}
	}

	// Token: 0x0600076B RID: 1899 RVA: 0x00037368 File Offset: 0x00035568
	public void Start()
	{
		this._hudEndChampionShipRace.SetActive(false);
		this._hudEndChampionShipRank.SetActive(false);
		this._hudEndSingleRace.SetActive(false);
		this._hudEndTimeTrialRace1.SetActive(false);
		this._hudEndTimeTrialRace2.SetActive(false);
		this._hudTimeTrialResults.SetActive(false);
		this._hudChampionShipResult.SetActive(false);
		this._nextButton.SetActive(false);
		this.m_pHudBonus.SetActive(false);
		this.m_pHudPosition.SetActive(false);
		this.m_pHudCountdown.SetActive(false);
		this.m_pHudTrackPresentation.SetActive(false);
		this.m_pHudChallenge.SetActive(false);
		this._hudRadar.SetActive(false);
	}

	// Token: 0x0600076C RID: 1900 RVA: 0x0000742E File Offset: 0x0000562E
	public void OnDestroy()
	{
		HUDNextButton.OnNextClick = (Action)Delegate.Remove(HUDNextButton.OnNextClick, new Action(this.DoNext));
	}

	// Token: 0x0600076D RID: 1901 RVA: 0x00037420 File Offset: 0x00035620
	public void EnterTutorial(Action<bool> _OnNext)
	{
		if (this.m_pHudTutorial != null && this.m_pHudTutorialComp != null)
		{
			this.m_pHudTutorialComp.Next = _OnNext;
			this.m_pHudTutorial.SetActive(true);
		}
		else
		{
			_OnNext(false);
		}
	}

	// Token: 0x0600076E RID: 1902 RVA: 0x00007450 File Offset: 0x00005650
	public void ExitTutorial()
	{
		if (this.m_pHudTutorial != null && this.m_pHudTutorialComp != null)
		{
			this.m_pHudTutorial.SetActive(false);
			this.m_pHudTutorialComp.Next = null;
		}
	}

	// Token: 0x0600076F RID: 1903 RVA: 0x0000748C File Offset: 0x0000568C
	public void EnterTrackPresentation()
	{
		this.m_bDelayTrackPresentation = true;
	}

	// Token: 0x06000770 RID: 1904 RVA: 0x00007495 File Offset: 0x00005695
	public void ExitTrackPresentation()
	{
		this.m_pHudTrackPresentation.SetActive(false);
	}

	// Token: 0x06000771 RID: 1905 RVA: 0x000074A3 File Offset: 0x000056A3
	public void EnterFinishRace()
	{
		this.m_bNeedToEnterFinishRace = true;
		this.m_bFinishLineCrossed = true;
	}

	// Token: 0x06000772 RID: 1906 RVA: 0x000074B3 File Offset: 0x000056B3
	public void ExitFinishRace()
	{
		this.m_pHudFinish.SetActive(false);
	}

	// Token: 0x06000773 RID: 1907 RVA: 0x00037474 File Offset: 0x00035674
	public void StartRace()
	{
		bool flag = Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TIME_TRIAL && Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TUTORIAL;
		if (flag)
		{
			this._hudRadarComp.StartRace();
		}
		if (Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TUTORIAL)
		{
			this.m_pHudPosition.SetActive(true);
		}
		this.m_pHudBonus.SetActive(flag);
		this._hudRadar.SetActive(flag);
		if (Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TUTORIAL)
		{
			this.m_pHudCountdown.SetActive(true);
		}
		if (this.m_pHudControls.activeSelf)
		{
			this.m_pHudControlsComp.StartRace();
		}
	}

	// Token: 0x06000774 RID: 1908 RVA: 0x000074C1 File Offset: 0x000056C1
	public void ActivateHUDBonus(bool Active)
	{
		this.m_pHudBonus.SetActive(Active);
	}

	// Token: 0x06000775 RID: 1909 RVA: 0x00037524 File Offset: 0x00035724
	public void ShowEndTutorialHUD()
	{
		if (Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TUTORIAL || ((TutorialGameMode)Singleton<GameManager>.Instance.GameMode).State != ETutorialState.End)
		{
			return;
		}
		this._hudRadarComp.StartRace();
		this._hudRadar.SetActive(true);
		this.m_pHudPosition.SetActive(true);
	}

	// Token: 0x06000776 RID: 1910 RVA: 0x00037580 File Offset: 0x00035780
	public void Pause(bool _Pause)
	{
		if (Singleton<GameManager>.Instance.GameMode.State == E_GameState.Result)
		{
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
			{
				if (!this.m_bEndChampionshipSecond)
				{
					this._hudEndChampionShipRace.SetActive(!_Pause);
				}
				else
				{
					this._hudEndChampionShipRank.SetActive(!_Pause);
				}
			}
			else if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.SINGLE)
			{
				this._hudEndSingleRace.SetActive(!_Pause);
			}
			this._nextButton.SetActive(!_Pause);
		}
		else if (Singleton<GameManager>.Instance.GameMode.State == E_GameState.TrackPresentation)
		{
			this.m_pHudTrackPresentation.SetActive(!_Pause);
		}
		else if (!this.FinishLineCrossed)
		{
			this.m_pHudBonus.SetActive(Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TIME_TRIAL && (Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TUTORIAL || ((TutorialGameMode)Singleton<GameManager>.Instance.GameMode).ShowHUDBonus) && !_Pause);
			this._hudRadar.SetActive(Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TIME_TRIAL && (Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TUTORIAL || ((TutorialGameMode)Singleton<GameManager>.Instance.GameMode).Ended) && !_Pause);
			this.m_pHudPosition.SetActive((Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TUTORIAL || ((TutorialGameMode)Singleton<GameManager>.Instance.GameMode).Ended) && !_Pause);
			if (this.m_pHudControls.activeSelf)
			{
				this.m_pHudControlsComp.Pause(_Pause);
			}
			if (Singleton<GameManager>.Instance.GameMode.State == E_GameState.Start && Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TUTORIAL)
			{
				this.m_pHudCountdown.SetActive(!_Pause);
			}
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
			{
				TutorialGameMode tutorialGameMode = (TutorialGameMode)Singleton<GameManager>.Instance.GameMode;
				tutorialGameMode.Pause(_Pause);
			}
		}
		this.m_pHudFinish.SetActive(!_Pause);
	}

	// Token: 0x06000777 RID: 1911 RVA: 0x000377A4 File Offset: 0x000359A4
	public void EndRace()
	{
		this.m_bEndHUDDisplayed = true;
		this._hudRadar.SetActive(false);
		switch (Singleton<GameConfigurator>.Instance.GameModeType)
		{
		case E_GameModeType.SINGLE:
			this._hudEndSingleRace.SetActive(true);
			break;
		case E_GameModeType.CHAMPIONSHIP:
			this._hudEndChampionShipRace.SetActive(true);
			break;
		case E_GameModeType.TIME_TRIAL:
			this._hudEndTimeTrialRace1.SetActive(true);
			break;
		}
	}

	// Token: 0x06000778 RID: 1912 RVA: 0x000074CF File Offset: 0x000056CF
	public void DoNext()
	{
		base.StartCoroutine(this.Next());
	}

	// Token: 0x06000779 RID: 1913 RVA: 0x00037820 File Offset: 0x00035A20
	private IEnumerator Next()
	{
		if (this.m_pHudChallenge.activeSelf)
		{
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP && Singleton<ChallengeManager>.Instance.Success)
			{
				Singleton<GameManager>.Instance.GameMode.State = E_GameState.Podium;
				this.m_pHudChallenge.SetActive(false);
				this._nextButton.SetActive(false);
			}
			else
			{
				LoadingManager.LoadLevel("MenuRoot");
			}
		}
		else if (this.m_pHudFinish.activeSelf)
		{
			this.m_pHudFinishComp.Next();
		}
		else if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
		{
			if (this._hudEndChampionShipRank.activeSelf)
			{
				this._hudEndChampionShipRank.SetActive(false);
				this._nextButton.SetActive(false);
				yield return new WaitForSeconds(this.m_fDelayNext);
				if (Singleton<GameManager>.Instance.GameMode.State != E_GameState.Podium)
				{
					this.ShowEndOfRace();
				}
			}
			else if (this._hudEndChampionShipRace.activeSelf)
			{
				this.m_bEndChampionshipSecond = true;
				this._hudEndChampionShipRace.SetActive(false);
				yield return new WaitForSeconds(this.m_fDelayNext);
				if (Singleton<GameManager>.Instance.GameMode.State != E_GameState.Podium)
				{
					this._hudEndChampionShipRank.SetActive(true);
					this._hudEndChampionShipRank.GetComponent<HUDChampionsShipRanking>().FillPositions();
				}
			}
			else if (Network.isServer)
			{
				this.m_oNetworkMgr.networkView.RPC("NextRace", RPCMode.All, new object[0]);
			}
			else if (Network.peerType == NetworkPeerType.Disconnected)
			{
				ChampionShipGameMode.NextRace();
			}
			else if (Network.isClient)
			{
				this.m_pHudPauseComp.OnQuit();
			}
		}
		else if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
		{
			if (this._hudTimeTrialResults.activeSelf)
			{
				this._hudTimeTrialResults.SetActive(false);
				this._nextButton.SetActive(false);
				yield return new WaitForSeconds(this.m_fDelayNext);
				this.ShowEndOfRace();
			}
			else if (this._hudEndTimeTrialRace2.activeSelf)
			{
				this._hudEndTimeTrialRace2.SetActive(false);
				yield return new WaitForSeconds(this.m_fDelayNext);
				this._hudTimeTrialResults.SetActive(true);
			}
			else if (this._hudEndTimeTrialRace1.activeSelf)
			{
				this.m_bEndChampionshipSecond = true;
				this._hudEndTimeTrialRace1.SetActive(false);
				yield return new WaitForSeconds(this.m_fDelayNext);
				this._hudEndTimeTrialRace2.SetActive(true);
			}
		}
		else if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.SINGLE)
		{
			this._hudEndSingleRace.SetActive(false);
			this._nextButton.SetActive(false);
			yield return new WaitForSeconds(this.m_fDelayNext);
			if (Singleton<GameManager>.Instance.GameMode.State != E_GameState.Podium)
			{
				this.ShowEndOfRace();
			}
		}
		yield return null;
		yield break;
	}

	// Token: 0x0600077A RID: 1914 RVA: 0x0003783C File Offset: 0x00035A3C
	public void ShowEndOfRace()
	{
		if (Singleton<ChallengeManager>.Instance.IsActive)
		{
			if (Singleton<ChallengeManager>.Instance.GameMode == E_GameModeType.CHAMPIONSHIP && Singleton<GameConfigurator>.Instance.CurrentTrackIndex < Singleton<GameConfigurator>.Instance.ChampionShipData.Tracks.Length && Singleton<ChallengeManager>.Instance.CurrentSuccess)
			{
				this.m_pHudPauseComp.ShowEndOfRace();
			}
			else
			{
				this.m_pHudChallenge.SetActive(true);
				this._nextButton.SetActive(true);
			}
		}
		else
		{
			this.m_pHudPauseComp.ShowEndOfRace();
		}
	}

	// Token: 0x0600077B RID: 1915 RVA: 0x000378D0 File Offset: 0x00035AD0
	public void ShowFailedChallenge()
	{
		this.m_pHudChallenge.SetActive(true);
		this._nextButton.SetActive(true);
		this.m_pHudPosition.SetActive(false);
		this.m_pHudBonus.SetActive(false);
		this._hudRadar.SetActive(false);
		if (this.m_pHudControls.activeSelf)
		{
			this.m_pHudControlsComp.ShowExceptPause(false);
		}
	}

	// Token: 0x0600077C RID: 1916 RVA: 0x00037938 File Offset: 0x00035B38
	public void Update()
	{
		if (this.m_bNeedToEnterFinishRace)
		{
			this.m_bNeedToEnterFinishRace = false;
			this._hudRadar.SetActive(false);
			this.HideRaceHud();
			this._nextButton.SetActive(true);
			this.m_pHudFinish.GetComponent<HUDFinish>().Show();
		}
		if (this.m_bDelayTrackPresentation)
		{
			this.m_pHudTrackPresentation.SetActive(true);
			this.m_bDelayTrackPresentation = false;
		}
		if (this._deferNextDisplay)
		{
			this._deferNextDisplayTimer -= Time.deltaTime;
			if (this._deferNextDisplayTimer <= 0f)
			{
				this._nextButton.SetActive(true);
				this._deferNextDisplayTimer = 0f;
				this._deferNextDisplay = false;
			}
		}
	}

	// Token: 0x1700012B RID: 299
	// (get) Token: 0x0600077D RID: 1917 RVA: 0x000074DE File Offset: 0x000056DE
	public GameObject HUDPodium
	{
		get
		{
			return this._hudChampionShipResult;
		}
	}

	// Token: 0x0600077E RID: 1918 RVA: 0x000074E6 File Offset: 0x000056E6
	public void ShowHudPodium()
	{
		this.DeferedNextButtonDisplay(this.ChampResultNextButtonDelay);
		this._hudChampionShipResult.SetActive(true);
	}

	// Token: 0x0600077F RID: 1919 RVA: 0x00007500 File Offset: 0x00005700
	private void DeferedNextButtonDisplay(float Duration)
	{
		this._deferNextDisplay = true;
		this._deferNextDisplayTimer = Duration;
	}

	// Token: 0x06000780 RID: 1920 RVA: 0x000379F0 File Offset: 0x00035BF0
	public void HideRaceHud()
	{
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
		{
			this.m_pHudPositionComp.Lap.SetActive(false);
		}
		else
		{
			this.m_pHudPosition.SetActive(false);
		}
		this.m_pHudBonus.SetActive(false);
		if (this.m_pHudControls.activeSelf)
		{
			this.m_pHudControlsComp.ShowExceptPause(false);
		}
	}

	// Token: 0x04000738 RID: 1848
	public float ChampResultNextButtonDelay = 5f;

	// Token: 0x04000739 RID: 1849
	private GameObject m_pHudBonus;

	// Token: 0x0400073A RID: 1850
	private float m_fDelayNext = 0.3f;

	// Token: 0x0400073B RID: 1851
	private GameObject m_pHudControls;

	// Token: 0x0400073C RID: 1852
	private GameObject m_pHudPosition;

	// Token: 0x0400073D RID: 1853
	private GameObject m_pHudCountdown;

	// Token: 0x0400073E RID: 1854
	private GameObject m_pHudFinish;

	// Token: 0x0400073F RID: 1855
	private GameObject m_pHudTrackPresentation;

	// Token: 0x04000740 RID: 1856
	private GameObject m_pHudTutorial;

	// Token: 0x04000741 RID: 1857
	private GameObject m_pHudChallenge;

	// Token: 0x04000742 RID: 1858
	private GameObject _hudEndChampionShipRace;

	// Token: 0x04000743 RID: 1859
	private GameObject _hudEndChampionShipRank;

	// Token: 0x04000744 RID: 1860
	private GameObject _nextButton;

	// Token: 0x04000745 RID: 1861
	private GameObject _hudEndSingleRace;

	// Token: 0x04000746 RID: 1862
	private GameObject _hudEndTimeTrialRace1;

	// Token: 0x04000747 RID: 1863
	private GameObject _hudEndTimeTrialRace2;

	// Token: 0x04000748 RID: 1864
	private GameObject _hudTimeTrialResults;

	// Token: 0x04000749 RID: 1865
	private GameObject _hudRadar;

	// Token: 0x0400074A RID: 1866
	private GameObject m_pHudFade;

	// Token: 0x0400074B RID: 1867
	private GameObject _hudChampionShipResult;

	// Token: 0x0400074C RID: 1868
	private HUDControls m_pHudControlsComp;

	// Token: 0x0400074D RID: 1869
	private HUDCountdown m_pHudCountdownComp;

	// Token: 0x0400074E RID: 1870
	private HUDBonus m_pHudBonusComp;

	// Token: 0x0400074F RID: 1871
	private HUDPosition m_pHudPositionComp;

	// Token: 0x04000750 RID: 1872
	private HUDTrackPresentation m_pHudTrackPresentationComp;

	// Token: 0x04000751 RID: 1873
	private HUDTutorial m_pHudTutorialComp;

	// Token: 0x04000752 RID: 1874
	private HUDEndChampionsShipRace m_pHudEndChampionshipRaceComp;

	// Token: 0x04000753 RID: 1875
	private HUDEndSingleRace m_pHudEndSingleRaceComp;

	// Token: 0x04000754 RID: 1876
	private HUDEndTimeTrial m_pHudEndTimeTrialComp;

	// Token: 0x04000755 RID: 1877
	private HUDEndTimeTrialMedal m_pHudEndTimeTrialMedalComp;

	// Token: 0x04000756 RID: 1878
	private HUDResultsTimeTrial m_pHudTimeTrialResultsComp;

	// Token: 0x04000757 RID: 1879
	private HUDFinish m_pHudFinishComp;

	// Token: 0x04000758 RID: 1880
	private HUDPause m_pHudPauseComp;

	// Token: 0x04000759 RID: 1881
	private HUDFade m_pHudFadeComp;

	// Token: 0x0400075A RID: 1882
	private bool m_bEndChampionshipSecond;

	// Token: 0x0400075B RID: 1883
	private bool m_bNeedToEnterFinishRace;

	// Token: 0x0400075C RID: 1884
	private bool m_bEndHUDDisplayed;

	// Token: 0x0400075D RID: 1885
	private bool m_bFinishLineCrossed;

	// Token: 0x0400075E RID: 1886
	private HUDRadar _hudRadarComp;

	// Token: 0x0400075F RID: 1887
	private NetworkMgr m_oNetworkMgr;

	// Token: 0x04000760 RID: 1888
	private bool m_bDelayTrackPresentation;

	// Token: 0x04000761 RID: 1889
	private float _deferNextDisplayTimer;

	// Token: 0x04000762 RID: 1890
	private bool _deferNextDisplay;
}

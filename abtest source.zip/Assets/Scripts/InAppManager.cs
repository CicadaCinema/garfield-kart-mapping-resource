﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020001CC RID: 460
public class InAppManager : Singleton<InAppManager>
{
	// Token: 0x17000198 RID: 408
	// (get) Token: 0x06000C74 RID: 3188 RVA: 0x0000A9F9 File Offset: 0x00008BF9
	public bool InAppAvaible
	{
		get
		{
			return this._inAppService.CanMakePurchase && Application.internetReachability != NetworkReachability.NotReachable;
		}
	}

	// Token: 0x06000C75 RID: 3189 RVA: 0x00053014 File Offset: 0x00051214
	~InAppManager()
	{
		try
		{
			AInAppService inAppService = this._inAppService;
			inAppService.OnProductListReceived = (Action<List<InAppProductData>>)Delegate.Remove(inAppService.OnProductListReceived, new Action<List<InAppProductData>>(this.ProductListReceived));
			AInAppService inAppService2 = this._inAppService;
			inAppService2.OnPurchaseSucceed = (AInAppService.PurchaseDelegate)Delegate.Remove(inAppService2.OnPurchaseSucceed, new AInAppService.PurchaseDelegate(this.PurchaseSucceed));
			AInAppService inAppService3 = this._inAppService;
			inAppService3.OnPurchaseFailed = (AInAppService.PurchaseDelegate)Delegate.Remove(inAppService3.OnPurchaseFailed, new AInAppService.PurchaseDelegate(this.PurchaseFailed));
			AInAppService inAppService4 = this._inAppService;
			inAppService4.OnPurchaseCancelled = (AInAppService.PurchaseDelegate)Delegate.Remove(inAppService4.OnPurchaseCancelled, new AInAppService.PurchaseDelegate(this.PurchaseCancelled));
			AInAppService inAppService5 = this._inAppService;
			inAppService5.OnRestoreSucceed = (AInAppService.RestoreSucceedDelegate)Delegate.Remove(inAppService5.OnRestoreSucceed, new AInAppService.RestoreSucceedDelegate(this.RestoreSucceed));
			AInAppService inAppService6 = this._inAppService;
			inAppService6.OnRestoreFailed = (AInAppService.RestoreFailedDelegate)Delegate.Remove(inAppService6.OnRestoreFailed, new AInAppService.RestoreFailedDelegate(this.RestoreFailed));
		}
		finally
		{
			//base.Finalize();
		}
	}

	// Token: 0x06000C76 RID: 3190 RVA: 0x00053128 File Offset: 0x00051328
	public void CollectStoreInfo(string[] productIds)
	{
		if (this.pendingRequest)
		{
			return;
		}
		this.pendingRequest = true;
		if (this._inAppService != null)
		{
			this._inAppService.Dispose();
		}
		this._inAppService = null;
		this._productIds = productIds;
		this._inAppService = new DummyInApp(this._productIds);
		AInAppService inAppService = this._inAppService;
		inAppService.OnProductListReceived = (Action<List<InAppProductData>>)Delegate.Combine(inAppService.OnProductListReceived, new Action<List<InAppProductData>>(this.ProductListReceived));
		AInAppService inAppService2 = this._inAppService;
		inAppService2.OnPurchaseSucceed = (AInAppService.PurchaseDelegate)Delegate.Combine(inAppService2.OnPurchaseSucceed, new AInAppService.PurchaseDelegate(this.PurchaseSucceed));
		AInAppService inAppService3 = this._inAppService;
		inAppService3.OnPurchaseFailed = (AInAppService.PurchaseDelegate)Delegate.Combine(inAppService3.OnPurchaseFailed, new AInAppService.PurchaseDelegate(this.PurchaseFailed));
		AInAppService inAppService4 = this._inAppService;
		inAppService4.OnPurchaseCancelled = (AInAppService.PurchaseDelegate)Delegate.Combine(inAppService4.OnPurchaseCancelled, new AInAppService.PurchaseDelegate(this.PurchaseCancelled));
		AInAppService inAppService5 = this._inAppService;
		inAppService5.OnRestoreSucceed = (AInAppService.RestoreSucceedDelegate)Delegate.Combine(inAppService5.OnRestoreSucceed, new AInAppService.RestoreSucceedDelegate(this.RestoreSucceed));
		AInAppService inAppService6 = this._inAppService;
		inAppService6.OnRestoreFailed = (AInAppService.RestoreFailedDelegate)Delegate.Combine(inAppService6.OnRestoreFailed, new AInAppService.RestoreFailedDelegate(this.RestoreFailed));
		this.GetData();
	}

	// Token: 0x06000C77 RID: 3191 RVA: 0x0000AA19 File Offset: 0x00008C19
	public void GetData()
	{
		this._inAppService.GetData();
	}

	// Token: 0x06000C78 RID: 3192 RVA: 0x0000AA26 File Offset: 0x00008C26
	public void ProductListReceived(List<InAppProductData> pProductData)
	{
		this.pendingRequest = false;
		if (pProductData.Count == 0)
		{
			return;
		}
		if (this.OnProductDataReceived != null)
		{
			this.OnProductDataReceived(pProductData);
		}
	}

	// Token: 0x06000C79 RID: 3193 RVA: 0x0000AA52 File Offset: 0x00008C52
	public void PurchaseProduct(string pProductId)
	{
		this._inAppService.PurchaseProduct(pProductId);
		if (this.OnGotFocus != null)
		{
			this.OnGotFocus();
		}
	}

	// Token: 0x06000C7A RID: 3194 RVA: 0x0000AA76 File Offset: 0x00008C76
	private void PurchaseSucceed(string pProductId)
	{
		if (this.OnPurchaseSucceed != null)
		{
			this.OnPurchaseSucceed(pProductId);
		}
		if (this.OnLostFocus != null)
		{
			this.OnLostFocus();
		}
	}

	// Token: 0x06000C7B RID: 3195 RVA: 0x0000AAA5 File Offset: 0x00008CA5
	private void PurchaseFailed(string pError)
	{
		if (this.OnPurchaseFailed != null)
		{
			this.OnPurchaseFailed(pError);
		}
		if (this.OnLostFocus != null)
		{
			this.OnLostFocus();
		}
	}

	// Token: 0x06000C7C RID: 3196 RVA: 0x0000AAD4 File Offset: 0x00008CD4
	private void PurchaseCancelled(string pError)
	{
		if (this.OnPurchaseCancelled != null)
		{
			this.OnPurchaseCancelled(pError);
		}
		if (this.OnLostFocus != null)
		{
			this.OnLostFocus();
		}
	}

	// Token: 0x06000C7D RID: 3197 RVA: 0x00003B80 File Offset: 0x00001D80
	private void RestoreSucceed()
	{
	}

	// Token: 0x06000C7E RID: 3198 RVA: 0x00003B80 File Offset: 0x00001D80
	private void RestoreFailed(string pError)
	{
	}

	// Token: 0x04000C20 RID: 3104
	private AInAppService _inAppService;

	// Token: 0x04000C21 RID: 3105
	private bool pendingRequest;

	// Token: 0x04000C22 RID: 3106
	private string[] _productIds;

	// Token: 0x04000C23 RID: 3107
	public Action<List<InAppProductData>> OnProductDataReceived;

	// Token: 0x04000C24 RID: 3108
	public Action OnGotFocus;

	// Token: 0x04000C25 RID: 3109
	public Action OnLostFocus;

	// Token: 0x04000C26 RID: 3110
	public AInAppService.PurchaseDelegate OnPurchaseSucceed;

	// Token: 0x04000C27 RID: 3111
	public AInAppService.PurchaseDelegate OnPurchaseFailed;

	// Token: 0x04000C28 RID: 3112
	public AInAppService.PurchaseDelegate OnPurchaseCancelled;
}

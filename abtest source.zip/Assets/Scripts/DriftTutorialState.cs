﻿using System;

// Token: 0x02000182 RID: 386
public class DriftTutorialState : IGTutorialState
{
	// Token: 0x1700016A RID: 362
	// (get) Token: 0x06000A3A RID: 2618 RVA: 0x00046254 File Offset: 0x00044454
	public override ETutorialState NextState
	{
		get
		{
			switch (this.GameMode.DriftSuccessLevel)
			{
			case 1:
				return this.OnAttempt;
			case 2:
				return this.OnBlue;
			case 3:
				return this.OnRed;
			default:
				return this.NextState;
			}
		}
	}

	// Token: 0x04000A32 RID: 2610
	public ETutorialState OnAttempt = ETutorialState.Drift_TryAgain;

	// Token: 0x04000A33 RID: 2611
	public ETutorialState OnBlue = ETutorialState.Drift_NotBad;

	// Token: 0x04000A34 RID: 2612
	public ETutorialState OnRed = ETutorialState.Drift_Perfect;
}

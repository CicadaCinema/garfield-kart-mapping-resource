﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000BD RID: 189
public class MenuEntryPoint : MonoBehaviour
{
	// Token: 0x060004BC RID: 1212 RVA: 0x00028AF4 File Offset: 0x00026CF4
	public void Awake()
	{
		string path;
		string path2;
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			path = "Camera/CameraCustomMobile";
			path2 = "Camera/CameraShopMobile";
		}
		else
		{
			path = "Camera/CameraCustom";
			path2 = "Camera/CameraShop";
		}
		GameObject gameObject = UnityEngine.Object.Instantiate(Resources.Load(path) as GameObject) as GameObject;
		GameObject gameObject2 = UnityEngine.Object.Instantiate(Resources.Load(path2) as GameObject) as GameObject;
		this.m_oCurrentCamera = gameObject2.GetComponent<Camera>();
		this.m_oDefaultCamera = gameObject2.GetComponent<Camera>();
		this.MenuRefList[4].m_oCamera = gameObject.GetComponent<Camera>();
		this.mainMenuBackGround = GameObject.Find("GARFIELD");
		this.menuBackGroundUFO = GameObject.Find("UFO");
		this.menuBackGroundPIE = GameObject.Find("PIE");
		this.menuBackGroundChars.Add(GameObject.Find("ARLENE"));
		this.menuBackGroundChars.Add(GameObject.Find("HARRY"));
		this.menuBackGroundChars.Add(GameObject.Find("JON"));
		this.menuBackGroundChars.Add(GameObject.Find("LIZE"));
		this.menuBackGroundChars.Add(GameObject.Find("NERMAL"));
		this.menuBackGroundChars.Add(GameObject.Find("ODIE"));
		this.menuBackGroundChars.Add(GameObject.Find("SQUEAK"));
		this.menuBackGroundAnims.Add("Menu_Kart_Anim_CATCHED");
		this.menuBackGroundAnims.Add("Menu_Kart_Anim_JUMP");
		this.menuBackGroundAnims.Add("Menu_Kart_Anim_OVERTAKE");
		this.menuBackGroundAnims.Add("Menu_Kart_Anim_SLIDE");
		if (this.mainMenuBackGround != null)
		{
			this.mainMenuBackGround.GetComponent<Animation>().Play();
		}
		else
		{
			Debug.Log("Menu Background Anim problem");
		}
		this.menuBackGroundUFO.SetActive(false);
		this.menuBackGroundPIE.SetActive(false);
		foreach (GameObject gameObject3 in this.menuBackGroundChars)
		{
			gameObject3.SetActive(false);
		}
	}

	// Token: 0x060004BD RID: 1213 RVA: 0x00028D30 File Offset: 0x00026F30
	public void SelectRandomMenuAnim()
	{
		if (this.lastCharChosen >= 0 && this.lastAnimPlayed >= 0)
		{
			if (this.menuBackGroundChars[this.lastCharChosen] != null)
			{
				this.stopAnim(this.menuBackGroundChars[this.lastCharChosen]);
			}
			else
			{
				Debug.Log("Menu Background Anim problem");
			}
		}
		if (UnityEngine.Random.value >= 0.33f)
		{
			int num;
			do
			{
				num = UnityEngine.Random.Range(0, this.menuBackGroundChars.Count);
			}
			while (num == this.lastCharChosen && this.menuBackGroundChars.Count > 1);
			this.lastCharChosen = num;
			if (this.menuBackGroundChars[this.lastCharChosen] != null)
			{
				this.startAnim(this.menuBackGroundChars[this.lastCharChosen]);
			}
			else
			{
				Debug.Log("Menu Background Anim problem");
			}
		}
		else
		{
			this.lastCharChosen = -1;
		}
	}

	// Token: 0x060004BE RID: 1214 RVA: 0x00028E2C File Offset: 0x0002702C
	public void startAnim(GameObject character)
	{
		character.SetActive(true);
		Animation component = character.GetComponent<Animation>();
		int num;
		do
		{
			num = UnityEngine.Random.Range(0, this.menuBackGroundAnims.Count);
		}
		while (num == this.lastAnimPlayed && this.menuBackGroundAnims.Count > 1);
		this.lastAnimPlayed = num;
		component.Play(this.menuBackGroundAnims[this.lastAnimPlayed]);
		if (this.menuBackGroundAnims[this.lastAnimPlayed].Equals("Menu_Kart_Anim_CATCHED") && this.menuBackGroundUFO != null)
		{
			this.menuBackGroundUFO.SetActive(true);
			this.menuBackGroundUFO.GetComponent<Animation>().Play("Menu_Kart_Anim_UFO");
		}
		if (this.menuBackGroundAnims[this.lastAnimPlayed].Equals("Menu_Kart_Anim_SLIDE") && this.menuBackGroundPIE != null)
		{
			this.menuBackGroundPIE.SetActive(true);
			this.menuBackGroundPIE.GetComponent<Animation>().Play("Menu_Kart_Anim_PIE");
		}
	}

	// Token: 0x060004BF RID: 1215 RVA: 0x00028F40 File Offset: 0x00027140
	public void stopAnim(GameObject character)
	{
		Animation component = character.GetComponent<Animation>();
		component.Stop(this.menuBackGroundAnims[this.lastAnimPlayed]);
		if (this.menuBackGroundAnims[this.lastAnimPlayed].Equals("Menu_Kart_Anim_CATCHED") && this.menuBackGroundUFO != null)
		{
			this.menuBackGroundUFO.GetComponent<Animation>().Stop("Menu_Kart_Anim_UFO");
			this.menuBackGroundUFO.SetActive(false);
		}
		if (this.menuBackGroundAnims[this.lastAnimPlayed].Equals("Menu_Kart_Anim_SLIDE") && this.menuBackGroundPIE != null)
		{
			this.menuBackGroundPIE.GetComponent<Animation>().Stop("Menu_Kart_Anim_UPIE");
			this.menuBackGroundPIE.SetActive(false);
		}
		character.SetActive(false);
	}

	// Token: 0x060004C0 RID: 1216 RVA: 0x00029018 File Offset: 0x00027218
	public void Start()
	{
		Singleton<GameConfigurator>.Instance.ResetChampionShip();
		if (Singleton<ChallengeManager>.Instance.IsActive)
		{
			Singleton<ChallengeManager>.Instance.DeActivate();
		}
		if (Singleton<GameConfigurator>.Instance.PlayerConfig)
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantages().Clear();
			Singleton<GameConfigurator>.Instance.PlayerConfig.ResetAdvantages();
		}
		this.m_oCurrentCamera.enabled = true;
		if (Singleton<RewardManager>.Instance._comicStrips != null)
		{
			this.SetState(Singleton<RewardManager>.Instance.GetState());
		}
		else
		{
			this.SetState(Singleton<GameConfigurator>.Instance.MenuToLaunch);
		}
		if (Singleton<GameConfigurator>.Instance.ChampionshipPass != null)
		{
			Singleton<GameConfigurator>.Instance.ChampionshipPass = null;
		}
	}

	// Token: 0x060004C1 RID: 1217 RVA: 0x000290DC File Offset: 0x000272DC
	public void Update()
	{
		if (this.soundToPlay.Count > 0 && LoadingManager.loadingFinished)
		{
			switch (this.soundToPlay[0])
			{
			case ESounds.INTRO_MUSIC:
				if (this.IntroMusic != null && !this.IntroMusic.isPlaying)
				{
					if (this.MenuMusic != null && this.MenuMusic.isPlaying)
					{
						this.MenuMusic.Stop();
					}
					this.IntroMusic.Play();
				}
				break;
			case ESounds.MENU_MUSIC:
				if (this.MenuMusic != null && !this.MenuMusic.isPlaying)
				{
					if (!(this.IntroMusic != null) || !this.IntroMusic.isPlaying)
					{
						this.MenuMusic.Play();
					}
				}
				break;
			case ESounds.HOVER_SOUND:
				if (this.HoverSound)
				{
					this.HoverSound.Play();
				}
				break;
			case ESounds.VALID_SOUND:
				if (this.ValidSound)
				{
					this.ValidSound.Play();
				}
				break;
			case ESounds.BACK_SOUND:
				if (this.BackSound)
				{
					this.BackSound.Play();
				}
				break;
			case ESounds.GO_SOUND:
				if (this.GoSound)
				{
					this.GoSound.Play();
				}
				break;
			case ESounds.SWITCH_PAGE_SOUND:
				if (this.SwitchPageSound)
				{
					this.SwitchPageSound.Play();
				}
				break;
			case ESounds.NOT_ENOUGH_COINS_SOUND:
				if (this.BuyCoinsSound)
				{
					this.BuyCoinsSound.Play();
				}
				break;
			case ESounds.BUY_COINS_SOUND:
				if (this.NotEnoughCoinsSound)
				{
					this.NotEnoughCoinsSound.Play();
				}
				break;
			case ESounds.POPUP_SOUND:
				if (this.PopupSound)
				{
					this.PopupSound.Play();
				}
				break;
			default:
				Debug.Log(this.soundToPlay[0]);
				break;
			}
			this.soundToPlay.RemoveAt(0);
		}
		if (this.m_bMenuMusicFadingIn)
		{
			this.m_fMenuMusicFadeIn += Time.deltaTime;
			if (this.m_fMenuMusicFadeIn < this.m_fMenuMusicFadeInDuration)
			{
				this.MenuMusic.volume = this.m_fMenuMusicFadeIn / this.m_fMenuMusicFadeInDuration;
			}
			else
			{
				this.MenuMusic.volume = 1f;
				this.m_bMenuMusicFadingIn = false;
			}
		}
	}

	// Token: 0x060004C2 RID: 1218 RVA: 0x00005688 File Offset: 0x00003888
	public void StartFadingInMenuMusic(float FadeInDuration)
	{
		this.m_bMenuMusicFadingIn = true;
		this.MenuMusic.volume = 0f;
		this.MenuMusic.Play();
		this.m_fMenuMusicFadeInDuration = FadeInDuration;
	}

	// Token: 0x060004C3 RID: 1219 RVA: 0x00029384 File Offset: 0x00027584
	public void SetState(EMenus eState)
	{
		this.MenuRefList[(int)this.m_eState].OnExit();
		this.m_ePreviousState = this.m_eState;
		this.m_eState = eState;
		this.MenuRefList[(int)this.m_eState].OnEnter();
	}

	// Token: 0x060004C4 RID: 1220 RVA: 0x000056B3 File Offset: 0x000038B3
	public void SetStateDelay(EMenus eState, float Delay)
	{
		base.StartCoroutine(this.SetStateDelayCoroutine(eState, 0.2f));
	}

	// Token: 0x060004C5 RID: 1221 RVA: 0x000293D0 File Offset: 0x000275D0
	private IEnumerator SetStateDelayCoroutine(EMenus eState, float Delay)
	{
		this.MenuRefList[(int)this.m_eState].OnExit();
		this.m_ePreviousState = this.m_eState;
		yield return new WaitForSeconds(Delay);
		this.m_eState = eState;
		this.MenuRefList[(int)this.m_eState].OnEnter();
		yield break;
	}

	// Token: 0x060004C6 RID: 1222 RVA: 0x00029408 File Offset: 0x00027608
	public void SetState(EMenus eState, int iSubEntryPoint)
	{
		this.MenuRefList[(int)this.m_eState].OnExit();
		this.m_ePreviousState = this.m_eState;
		this.m_eState = eState;
		this.MenuRefList[(int)this.m_eState].OnEnter(iSubEntryPoint);
	}

	// Token: 0x060004C7 RID: 1223 RVA: 0x000056C8 File Offset: 0x000038C8
	public void SetPreviousState()
	{
		this.SetState(this.m_ePreviousState);
	}

	// Token: 0x060004C8 RID: 1224 RVA: 0x00029458 File Offset: 0x00027658
	public void SetCamera(Camera oCamera)
	{
		if (oCamera)
		{
			this.m_oCurrentCamera.enabled = false;
			this.m_oCurrentCamera = oCamera;
			this.m_oCurrentCamera.enabled = true;
		}
		else
		{
			this.m_oCurrentCamera.enabled = false;
			this.m_oCurrentCamera = this.m_oDefaultCamera;
			this.m_oCurrentCamera.enabled = true;
		}
	}

	// Token: 0x060004C9 RID: 1225 RVA: 0x000056D6 File Offset: 0x000038D6
	private void DoShowPopup(EPopUps Popup, bool bSound)
	{
		this.MenuRefList[(int)this.m_eState].OnPopupShow();
		this.m_ePopupState = Popup;
		if (bSound)
		{
			this.soundToPlay.Add(ESounds.POPUP_SOUND);
		}
	}

	// Token: 0x060004CA RID: 1226 RVA: 0x00005708 File Offset: 0x00003908
	public void ShowPopup(EPopUps Popup, string _TextId, bool bSound)
	{
		this.DoShowPopup(Popup, bSound);
		this.PopupRefList[(int)this.m_ePopupState].Show(_TextId);
	}

	// Token: 0x060004CB RID: 1227 RVA: 0x00005729 File Offset: 0x00003929
	public AbstractPopup ShowPopup(EPopUps Popup, bool bSound)
	{
		this.DoShowPopup(Popup, bSound);
		return this.PopupRefList[(int)this.m_ePopupState];
	}

	// Token: 0x060004CC RID: 1228 RVA: 0x00005744 File Offset: 0x00003944
	public void QuitPopup()
	{
		this.MenuRefList[(int)this.m_eState].OnPopupQuit();
		this.PopupRefList[(int)this.m_ePopupState].Hide();
	}

	// Token: 0x060004CD RID: 1229 RVA: 0x000294B8 File Offset: 0x000276B8
	public void ShowPurchasePopup(string sText, int iPrice, MenuEntryPoint.Callback oCbSucceed, MenuEntryPoint.Callback oCbNoMoney = null, object oParamCb = null)
	{
		if (Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer && Singleton<GameSaveManager>.Instance.GetCoins() < iPrice)
		{
			PopupDialog popupDialog = (PopupDialog)this.ShowPopup(EPopUps.POPUP_DIALOG, false);
			this.soundToPlay.Add(ESounds.NOT_ENOUGH_COINS_SOUND);
			popupDialog.Show(string.Format(Localization.instance.Get("MENU_POUP_NOT_ENOUGH_MONEY_PC"), iPrice - Singleton<GameSaveManager>.Instance.GetCoins()));
		}
		else
		{
			Popup2Choices popup2Choices = (Popup2Choices)this.ShowPopup(EPopUps.POPUP_DIALOG_2CHOICES, false);
			if (popup2Choices)
			{
				MenuEntryPoint.PurchasePopupData purchasePopupData = new MenuEntryPoint.PurchasePopupData();
				purchasePopupData.m_oCbSucceed = oCbSucceed;
				purchasePopupData.m_oCbNoMoney = oCbNoMoney;
				purchasePopupData.m_iPrice = iPrice;
				purchasePopupData.m_oParamCb = oParamCb;
				if (Singleton<GameSaveManager>.Instance.GetCoins() >= iPrice)
				{
					Popup2Choices popup2Choices2 = popup2Choices;
					Popup2Choices.Callback oCbRight = new Popup2Choices.Callback(this.PurchaseOk);
					popup2Choices2.ShowText(sText, null, oCbRight, purchasePopupData, "MENU_POPUP_NO", "MENU_POPUP_YES");
					this.soundToPlay.Add(ESounds.BUY_COINS_SOUND);
				}
				else
				{
					this.soundToPlay.Add(ESounds.NOT_ENOUGH_COINS_SOUND);
					Popup2Choices popup2Choices3 = popup2Choices;
					Popup2Choices.Callback oCbRight = new Popup2Choices.Callback(this.PurchaseNoMoney);
					popup2Choices3.ShowText(string.Format(Localization.instance.Get("MENU_POUP_NOT_ENOUGH_MONEY"), iPrice - Singleton<GameSaveManager>.Instance.GetCoins()), null, oCbRight, purchasePopupData, "MENU_POPUP_NO", "MENU_POPUP_YES");
				}
			}
		}
	}

	// Token: 0x060004CE RID: 1230 RVA: 0x00029608 File Offset: 0x00027808
	private void PurchaseOk(object oParam)
	{
		MenuEntryPoint.PurchasePopupData purchasePopupData = (MenuEntryPoint.PurchasePopupData)oParam;
		Singleton<GameSaveManager>.Instance.SpendCoins(purchasePopupData.m_iPrice, true);
		purchasePopupData.m_oCbSucceed(purchasePopupData.m_oParamCb);
	}

	// Token: 0x060004CF RID: 1231 RVA: 0x00029640 File Offset: 0x00027840
	private void PurchaseNoMoney(object oParam)
	{
		MenuEntryPoint.PurchasePopupData purchasePopupData = (MenuEntryPoint.PurchasePopupData)oParam;
		if (purchasePopupData.m_oCbNoMoney == null)
		{
			this.SetState(EMenus.MENU_SELECT_KART, 1);
		}
		else
		{
			purchasePopupData.m_oCbNoMoney(purchasePopupData.m_oParamCb);
		}
	}

	// Token: 0x060004D0 RID: 1232 RVA: 0x00029680 File Offset: 0x00027880
	public void PlayIntroMusic()
	{
		int num = this.soundToPlay.Count - 1;
		if (num < 0 || (num >= 0 && this.soundToPlay[num] != ESounds.INTRO_MUSIC))
		{
			this.soundToPlay.Add(ESounds.INTRO_MUSIC);
		}
	}

	// Token: 0x060004D1 RID: 1233 RVA: 0x000296C8 File Offset: 0x000278C8
	public void PlayMenuMusic()
	{
		int num = this.soundToPlay.Count - 1;
		if (num < 0 || (num >= 0 && this.soundToPlay[num] != ESounds.MENU_MUSIC))
		{
			this.soundToPlay.Add(ESounds.MENU_MUSIC);
		}
	}

	// Token: 0x060004D2 RID: 1234 RVA: 0x00005772 File Offset: 0x00003972
	public void PlayHoverSound()
	{
		this.soundToPlay.Add(ESounds.HOVER_SOUND);
	}

	// Token: 0x060004D3 RID: 1235 RVA: 0x00005780 File Offset: 0x00003980
	public void PlayValidSound()
	{
		this.soundToPlay.Add(ESounds.VALID_SOUND);
	}

	// Token: 0x060004D4 RID: 1236 RVA: 0x0000578E File Offset: 0x0000398E
	public void PlayBackSound()
	{
		this.soundToPlay.Add(ESounds.BACK_SOUND);
	}

	// Token: 0x060004D5 RID: 1237 RVA: 0x0000579C File Offset: 0x0000399C
	public void PlayGoSound()
	{
		this.soundToPlay.Add(ESounds.GO_SOUND);
	}

	// Token: 0x060004D6 RID: 1238 RVA: 0x000057AA File Offset: 0x000039AA
	public void PlaySwitchPageSound()
	{
		this.soundToPlay.Add(ESounds.SWITCH_PAGE_SOUND);
	}

	// Token: 0x040004AF RID: 1199
	private List<ESounds> soundToPlay = new List<ESounds>();

	// Token: 0x040004B0 RID: 1200
	private EMenus m_eState;

	// Token: 0x040004B1 RID: 1201
	private EMenus m_ePreviousState;

	// Token: 0x040004B2 RID: 1202
	private EPopUps m_ePopupState;

	// Token: 0x040004B3 RID: 1203
	public Camera m_oCurrentCamera;

	// Token: 0x040004B4 RID: 1204
	public Camera m_oDefaultCamera;

	// Token: 0x040004B5 RID: 1205
	[SerializeField]
	[HideInInspector]
	public List<AbstractMenu> MenuRefList = new List<AbstractMenu>();

	// Token: 0x040004B6 RID: 1206
	public List<AbstractPopup> PopupRefList = new List<AbstractPopup>();

	// Token: 0x040004B7 RID: 1207
	public AudioSource IntroMusic;

	// Token: 0x040004B8 RID: 1208
	public AudioSource MenuMusic;

	// Token: 0x040004B9 RID: 1209
	public AudioSource HoverSound;

	// Token: 0x040004BA RID: 1210
	public AudioSource ValidSound;

	// Token: 0x040004BB RID: 1211
	public AudioSource BackSound;

	// Token: 0x040004BC RID: 1212
	public AudioSource GoSound;

	// Token: 0x040004BD RID: 1213
	public AudioSource SwitchPageSound;

	// Token: 0x040004BE RID: 1214
	public AudioSource NotEnoughCoinsSound;

	// Token: 0x040004BF RID: 1215
	public AudioSource BuyCoinsSound;

	// Token: 0x040004C0 RID: 1216
	public AudioSource PopupSound;

	// Token: 0x040004C1 RID: 1217
	private float m_fMenuMusicFadeInDuration = 0.2f;

	// Token: 0x040004C2 RID: 1218
	private bool m_bMenuMusicFadingIn;

	// Token: 0x040004C3 RID: 1219
	private float m_fMenuMusicFadeIn;

	// Token: 0x040004C4 RID: 1220
	private GameObject mainMenuBackGround;

	// Token: 0x040004C5 RID: 1221
	private GameObject menuBackGroundUFO;

	// Token: 0x040004C6 RID: 1222
	private GameObject menuBackGroundPIE;

	// Token: 0x040004C7 RID: 1223
	private List<string> menuBackGroundAnims = new List<string>();

	// Token: 0x040004C8 RID: 1224
	private List<GameObject> menuBackGroundChars = new List<GameObject>();

	// Token: 0x040004C9 RID: 1225
	private int lastAnimPlayed = -1;

	// Token: 0x040004CA RID: 1226
	private int lastCharChosen = -1;

	// Token: 0x020000BE RID: 190
	private class PurchasePopupData
	{
		// Token: 0x040004CB RID: 1227
		public int m_iPrice;

		// Token: 0x040004CC RID: 1228
		public MenuEntryPoint.Callback m_oCbSucceed;

		// Token: 0x040004CD RID: 1229
		public MenuEntryPoint.Callback m_oCbNoMoney;

		// Token: 0x040004CE RID: 1230
		public object m_oParamCb;
	}

	// Token: 0x020000BF RID: 191
	// (Invoke) Token: 0x060004D9 RID: 1241
	public delegate void Callback(object param);
}

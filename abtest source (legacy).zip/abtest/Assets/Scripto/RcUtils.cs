﻿using System;
using UnityEngine;

// Token: 0x02000220 RID: 544
public static class RcUtils
{
	// Token: 0x06000F36 RID: 3894 RVA: 0x0000C791 File Offset: 0x0000A991
	public static void COMPUTE_INERTIA(ref float v0, float v1, float Ine, float dt)
	{
		v0 += (1f - Ine) * (v1 - v0) * dt;
	}

	// Token: 0x06000F37 RID: 3895 RVA: 0x0000C7A6 File Offset: 0x0000A9A6
	public static void COMPUTE_INERTIA(ref Vector3 v0, Vector3 v1, float Ine, float dt)
	{
		v0 += (1f - Ine) * (v1 - v0) * dt;
	}

	// Token: 0x06000F38 RID: 3896 RVA: 0x0000C7D7 File Offset: 0x0000A9D7
	public static float LinearInterpolation(float x1, float y1, float x2, float y2, float x)
	{
		return RcUtils.LinearInterpolation(x1, y1, x2, y2, x, false);
	}

	// Token: 0x06000F39 RID: 3897 RVA: 0x0005FEE4 File Offset: 0x0005E0E4
	public static float LinearInterpolation(float x1, float y1, float x2, float y2, float x, bool clamp)
	{
		float num = (x - x1) / (x2 - x1);
		float num2 = y1 + num * (y2 - y1);
		if (clamp)
		{
			if (y1 < y2)
			{
				num2 = Mathf.Clamp(num2, y1, y2);
			}
			else
			{
				num2 = Mathf.Clamp(num2, y2, y1);
			}
		}
		return num2;
	}

	// Token: 0x06000F3A RID: 3898 RVA: 0x0005FF28 File Offset: 0x0005E128
	public static bool IsOnRight(Vector3 pSegBegin, Vector3 pSegEnd, Vector3 pPt, Vector3 pUp)
	{
		Vector3 lhs = pSegEnd - pSegBegin;
		Vector3 rhs = pPt - pSegBegin;
		Vector3 lhs2 = Vector3.Cross(lhs, rhs);
		return Vector3.Dot(lhs2, pUp) <= 0f;
	}

	// Token: 0x06000F3B RID: 3899 RVA: 0x0005FF60 File Offset: 0x0005E160
	public static bool IsOnRight(Vector2 pSegBegin, Vector2 pSegEnd, Vector2 pPt)
	{
		return (pSegEnd.x - pSegBegin.x) * (pPt.y - pSegBegin.y) - (pSegEnd.y - pSegBegin.y) * (pPt.x - pSegBegin.x) >= 0f;
	}

	// Token: 0x06000F3C RID: 3900 RVA: 0x0005FFB8 File Offset: 0x0005E1B8
	public static bool Inside(Vector2 pP, Vector2 pSP0, Vector2 pSP1)
	{
		if (pSP0.x != pSP1.x)
		{
			if (pSP0.x <= pP.x && pP.x <= pSP1.x)
			{
				return true;
			}
			if (pSP0.x >= pP.x && pP.x >= pSP1.x)
			{
				return true;
			}
		}
		else
		{
			if (pSP0.y <= pP.y && pP.y <= pSP1.y)
			{
				return true;
			}
			if (pSP0.y >= pP.y && pP.y >= pSP1.y)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000F3D RID: 3901 RVA: 0x00060080 File Offset: 0x0005E280
	public static int SegmentsIntersection(Vector2 pS1P0, Vector2 pS1P1, Vector2 pS2P0, Vector2 pS2P1, ref Vector2 rpOut1, ref Vector2 rpOut2)
	{
		Vector2 vector = pS1P1 - pS1P0;
		Vector2 vector2 = pS2P1 - pS2P0;
		Vector2 to = pS1P0 - pS2P0;
		float num = Vector2.Angle(vector, vector2);
		if (Mathf.Abs(num) < 1E-08f)
		{
			if (Vector2.Angle(vector, to) != 0f || Vector2.Angle(vector2, to) != 0f)
			{
				return 0;
			}
			float num2 = Vector2.Angle(vector, vector);
			float num3 = Vector2.Angle(vector2, vector2);
			if (num2 == 0f && num3 == 0f)
			{
				if (pS1P0 == pS2P0)
				{
					return 0;
				}
				rpOut1 = pS1P0;
				return 1;
			}
			else if (num2 == 0f)
			{
				if (!RcUtils.Inside(pS1P0, pS2P0, pS2P1))
				{
					return 0;
				}
				rpOut1 = pS1P0;
				return 1;
			}
			else if (num3 == 0f)
			{
				if (!RcUtils.Inside(pS2P0, pS1P0, pS1P1))
				{
					return 0;
				}
				rpOut1 = pS2P0;
				return 1;
			}
			else
			{
				Vector2 vector3 = pS1P1 - pS2P0;
				float num4;
				float num5;
				if (vector2.x != 0f)
				{
					num4 = to.x / vector2.x;
					num5 = vector3.x / vector2.x;
				}
				else
				{
					num4 = to.y / vector2.y;
					num5 = vector3.y / vector2.y;
				}
				if (num4 > num5)
				{
					float num6 = num4;
					num4 = num5;
					num5 = num6;
				}
				if (num4 > 1f || num5 < 0f)
				{
					return 0;
				}
				num4 = ((num4 >= 0f) ? num4 : 0f);
				num5 = ((num5 <= 1f) ? num5 : 1f);
				if (num4 == num5)
				{
					rpOut1 = pS2P0 + num4 * vector2;
					return 1;
				}
				rpOut1 = pS2P0 + num4 * vector2;
				rpOut2 = pS2P0 + num5 * vector2;
				return 2;
			}
		}
		else
		{
			float num7 = Vector2.Angle(vector2, to) / num;
			if (num7 < 0f || num7 > 1f)
			{
				return 0;
			}
			float num8 = Vector2.Angle(vector, to) / num;
			if (num8 < 0f || num8 > 1f)
			{
				return 0;
			}
			rpOut1 = pS1P0 + num7 * vector;
			return 1;
		}
	}

	// Token: 0x06000F3E RID: 3902 RVA: 0x000602E0 File Offset: 0x0005E4E0
	public static float FastSqrtApprox(float pValue)
	{
		int num = (int)pValue;
		num -= 8388608;
		num >>= 1;
		num += 536870912;
		return (float)num;
	}

	// Token: 0x06000F3F RID: 3903 RVA: 0x0000C7E5 File Offset: 0x0000A9E5
	public static float PointToSegmentDistance(Vector3 point, Vector3 segmentP1, Vector3 segmentP2)
	{
		return Mathf.Sqrt(RcUtils.PointToSegmentSqrDistance(point, segmentP1, segmentP2));
	}

	// Token: 0x06000F40 RID: 3904 RVA: 0x00060308 File Offset: 0x0005E508
	public static float PointToSegmentRatio(Vector2 point, Vector2 segmentP1, Vector2 segmentP2)
	{
		if (segmentP1 == segmentP2)
		{
			return 0f;
		}
		Vector2 v = segmentP2 - segmentP1;
		return Vector3.Dot(point - segmentP1, v) / v.SqrMagnitude();
	}

	// Token: 0x06000F41 RID: 3905 RVA: 0x00060350 File Offset: 0x0005E550
	public static float PointToSegmentRatio(Vector3 point, Vector3 segmentP1, Vector3 segmentP2)
	{
		if (segmentP1 == segmentP2)
		{
			return 0f;
		}
		Vector3 rhs = segmentP2 - segmentP1;
		return Vector3.Dot(point - segmentP1, rhs) / rhs.sqrMagnitude;
	}

	// Token: 0x06000F42 RID: 3906 RVA: 0x00060390 File Offset: 0x0005E590
	public static float PointToSegmentSqrDistance(Vector2 point, Vector2 segmentP1, Vector2 segmentP2)
	{
		float num;
		float num2;
		if (segmentP1 == segmentP2)
		{
			num = segmentP1.x - point.x;
			num2 = segmentP1.y - point.y;
		}
		else
		{
			float num3 = RcUtils.PointToSegmentRatio(point, segmentP1, segmentP2);
			if (num3 < 0f)
			{
				num = segmentP1.x - point.x;
				num2 = segmentP1.y - point.y;
			}
			else if (num3 > 1f)
			{
				num = segmentP2.x - point.x;
				num2 = segmentP2.y - point.y;
			}
			else
			{
				num = (1f - num3) * segmentP1.x + num3 * segmentP2.x - point.x;
				num2 = (1f - num3) * segmentP1.y + num3 * segmentP2.y - point.y;
			}
		}
		return num * num + num2 * num2;
	}

	// Token: 0x06000F43 RID: 3907 RVA: 0x00060484 File Offset: 0x0005E684
	public static float PointToSegmentSqrDistance(Vector3 point, Vector3 segmentP1, Vector3 segmentP2)
	{
		float num;
		float num2;
		float num3;
		if (segmentP1 == segmentP2)
		{
			num = segmentP1.x - point.x;
			num2 = segmentP1.y - point.y;
			num3 = segmentP1.z - point.z;
		}
		else
		{
			float num4 = RcUtils.PointToSegmentRatio(point, segmentP1, segmentP2);
			if (num4 < 0f)
			{
				num = segmentP1.x - point.x;
				num2 = segmentP1.y - point.y;
				num3 = segmentP1.z - point.z;
			}
			else if (num4 > 1f)
			{
				num = segmentP2.x - point.x;
				num2 = segmentP2.y - point.y;
				num3 = segmentP2.z - point.z;
			}
			else
			{
				num = (1f - num4) * segmentP1.x + num4 * segmentP2.x - point.x;
				num2 = (1f - num4) * segmentP1.y + num4 * segmentP2.y - point.y;
				num3 = (1f - num4) * segmentP1.z + num4 * segmentP2.z - point.z;
			}
		}
		return num * num + num2 * num2 + num3 * num3;
	}

	// Token: 0x06000F44 RID: 3908 RVA: 0x000605CC File Offset: 0x0005E7CC
	public static Vector3 GetSmoothPos(Vector3 _Point1, Vector3 _Point2, Vector3 _Point3, Vector3 _Point4, float _Percentage, float _SplineTension)
	{
		if (_Percentage == 0f)
		{
			return _Point2;
		}
		Vector3[] array = new Vector3[]
		{
			_Point2,
			_Point2 + (_Point3 - _Point1) / _SplineTension,
			_Point3 + (_Point2 - _Point4) / _SplineTension,
			_Point3
		};
		float num = 1f - _Percentage;
		float num2 = _Percentage * _Percentage;
		float num3 = num * num;
		Vector3 result;
		result.x = array[0].x * num * num3 + array[1].x * 3f * _Percentage * num3 + array[2].x * 3f * num2 * num + array[3].x * _Percentage * num2;
		result.y = array[0].y * num * num3 + array[1].y * 3f * _Percentage * num3 + array[2].y * 3f * num2 * num + array[3].y * _Percentage * num2;
		result.z = array[0].z * num * num3 + array[1].z * 3f * _Percentage * num3 + array[2].z * 3f * num2 * num + array[3].z * _Percentage * num2;
		return result;
	}

	// Token: 0x06000F45 RID: 3909 RVA: 0x0000C7F4 File Offset: 0x0000A9F4
	public static float MsToKph(float pValue)
	{
		return pValue * 3.6f;
	}

	// Token: 0x06000F46 RID: 3910 RVA: 0x0006076C File Offset: 0x0005E96C
	public static float FastNormaliseApprox(ref Vector3 rpVector)
	{
		float num = RcUtils.FastSqrtApprox(rpVector.x * rpVector.x + rpVector.y * rpVector.y + rpVector.z * rpVector.z);
		if ((double)num > 1E-08)
		{
			float num2 = 1f / num;
			rpVector.x *= num2;
			rpVector.y *= num2;
			rpVector.z *= num2;
		}
		return num;
	}

	// Token: 0x06000F47 RID: 3911 RVA: 0x000607EC File Offset: 0x0005E9EC
	public static float Perlin(float pX, float pY, float pPersistence, int pOctaves)
	{
		float num = 0f;
		float num2 = 1f;
		for (int i = 0; i < pOctaves; i++)
		{
			float num3 = (float)(1 << i);
			num += RcUtils.InterpolatedNoise(pX * num3, pY * num3) * num2;
			num2 *= pPersistence;
		}
		return num;
	}

	// Token: 0x06000F48 RID: 3912 RVA: 0x00060834 File Offset: 0x0005EA34
	public static float InterpolateLine(float pA, float pB, float pX)
	{
		float f = pX * 3.14159274f;
		float num = (1f - Mathf.Cos(f)) * 0.5f;
		return pA * (1f - num) + pB * num;
	}

	// Token: 0x06000F49 RID: 3913 RVA: 0x0006086C File Offset: 0x0005EA6C
	public static float Noise(int pX, int pY)
	{
		int num = pX + pY * 57;
		num = (num << 13 ^ num);
		return 1f - (float)(num * (num * num * 15731 + 789221) + 1376312589 & int.MaxValue) / 1.07374182E+09f;
	}

	// Token: 0x06000F4A RID: 3914 RVA: 0x000608B4 File Offset: 0x0005EAB4
	public static float SmoothNoise(int pX, int pY)
	{
		float num = (RcUtils.Noise(pX - 1, pY - 1) + RcUtils.Noise(pX + 1, pY - 1) + RcUtils.Noise(pX - 1, pY + 1) + RcUtils.Noise(pX + 1, pY + 1)) / 16f;
		float num2 = (RcUtils.Noise(pX - 1, pY) + RcUtils.Noise(pX + 1, pY) + RcUtils.Noise(pX, pY - 1) + RcUtils.Noise(pX, pY + 1)) / 8f;
		float num3 = RcUtils.Noise(pX, pY) / 4f;
		return num + num2 + num3;
	}

	// Token: 0x06000F4B RID: 3915 RVA: 0x00060938 File Offset: 0x0005EB38
	public static float InterpolatedNoise(float pX, float pY)
	{
		int num = (int)pX;
		float pX2 = pX - (float)num;
		int num2 = (int)pY;
		float pX3 = pY - (float)num2;
		float pA = RcUtils.SmoothNoise(num, num2);
		float pB = RcUtils.SmoothNoise(num + 1, num2);
		float pA2 = RcUtils.SmoothNoise(num, num2 + 1);
		float pB2 = RcUtils.SmoothNoise(num + 1, num2 + 1);
		float pA3 = RcUtils.InterpolateLine(pA, pB, pX2);
		float pB3 = RcUtils.InterpolateLine(pA2, pB2, pX2);
		return RcUtils.InterpolateLine(pA3, pB3, pX3);
	}

	// Token: 0x06000F4C RID: 3916 RVA: 0x000609A4 File Offset: 0x0005EBA4
	public static bool IsOnRight(Vector3 pSegBegin, Vector3 pSegEnd, Vector3 pPt)
	{
		Vector3 lhs = pSegEnd - pSegBegin;
		Vector3 rhs = pPt - pSegBegin;
		Vector3 lhs2 = Vector3.Cross(lhs, rhs);
		return -1f * Vector3.Dot(lhs2, Vector3.up) <= 0f;
	}

	// Token: 0x06000F4D RID: 3917 RVA: 0x000609E4 File Offset: 0x0005EBE4
	public static void SerializeAndCompressVector(BitStream stream, Vector3 vec, Vector3 amplitude)
	{
		short num = RcUtils.CompressFloat(vec.x, -amplitude.x, amplitude.x);
		short num2 = RcUtils.CompressFloat(vec.y, -amplitude.y, amplitude.y);
		short num3 = RcUtils.CompressFloat(vec.z, -amplitude.z, amplitude.z);
		stream.Serialize(ref num);
		stream.Serialize(ref num2);
		stream.Serialize(ref num3);
	}

	// Token: 0x06000F4E RID: 3918 RVA: 0x00060A60 File Offset: 0x0005EC60
	public static Vector3 UnserializeCompressedVector(BitStream stream, Vector3 amplitude)
	{
		short value_in = 0;
		short value_in2 = 0;
		short value_in3 = 0;
		stream.Serialize(ref value_in);
		stream.Serialize(ref value_in2);
		stream.Serialize(ref value_in3);
		float x = RcUtils.DecompressFloat(value_in, -amplitude.x, amplitude.x);
		float y = RcUtils.DecompressFloat(value_in2, -amplitude.y, amplitude.y);
		float z = RcUtils.DecompressFloat(value_in3, -amplitude.z, amplitude.z);
		return new Vector3(x, y, z);
	}

	// Token: 0x06000F4F RID: 3919 RVA: 0x00060ADC File Offset: 0x0005ECDC
	public static void SerializeAndCompressQuaternion(BitStream stream, Quaternion quat)
	{
		float f = quat.w * quat.w + quat.x * quat.x + quat.y * quat.y + quat.z * quat.z;
		float num = 1f / Mathf.Sqrt(f);
		short num2 = RcUtils.CompressFloat(quat.w * num, -1f, 1f);
		short num3 = RcUtils.CompressFloat(quat.x * num, -1f, 1f);
		short num4 = RcUtils.CompressFloat(quat.y * num, -1f, 1f);
		short num5 = RcUtils.CompressFloat(quat.z * num, -1f, 1f);
		stream.Serialize(ref num2);
		stream.Serialize(ref num3);
		stream.Serialize(ref num4);
		stream.Serialize(ref num5);
	}

	// Token: 0x06000F50 RID: 3920 RVA: 0x00060BBC File Offset: 0x0005EDBC
	public static Quaternion UnserializeCompressedQuaternion(BitStream stream)
	{
		short value_in = 0;
		short value_in2 = 0;
		short value_in3 = 0;
		short value_in4 = 0;
		stream.Serialize(ref value_in);
		stream.Serialize(ref value_in2);
		stream.Serialize(ref value_in3);
		stream.Serialize(ref value_in4);
		float x = RcUtils.DecompressFloat(value_in, -1f, 1f);
		float y = RcUtils.DecompressFloat(value_in2, -1f, 1f);
		float z = RcUtils.DecompressFloat(value_in3, -1f, 1f);
		float w = RcUtils.DecompressFloat(value_in4, -1f, 1f);
		return new Quaternion(x, y, z, w);
	}

	// Token: 0x06000F51 RID: 3921 RVA: 0x00060C48 File Offset: 0x0005EE48
	public static short CompressFloat(float value_in, float minValue, float maxValue)
	{
		float num = value_in;
		if (num > maxValue)
		{
			num = maxValue;
		}
		if (num < minValue)
		{
			num = minValue;
		}
		float num2 = 65535f * (num - minValue) / (maxValue - minValue) - 32768f;
		if (num2 < -32768f)
		{
			num2 = -32768f;
		}
		if (num2 > 32767f)
		{
			num2 = 32767f;
		}
		return (short)num2;
	}

	// Token: 0x06000F52 RID: 3922 RVA: 0x00060CA4 File Offset: 0x0005EEA4
	public static float DecompressFloat(short value_in, float minValue, float maxValue)
	{
		float num = minValue + ((float)value_in + 32768f) / 65535f * (maxValue - minValue);
		if (num < minValue)
		{
			num = minValue;
		}
		else if (num > maxValue)
		{
			num = maxValue;
		}
		return num;
	}

	// Token: 0x04000EBC RID: 3772
	public const float RIGHT_HANDED = -1f;
}

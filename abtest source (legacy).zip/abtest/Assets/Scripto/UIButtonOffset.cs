﻿using System;
using UnityEngine;

// Token: 0x0200000B RID: 11
[AddComponentMenu("NGUI/Interaction/Button Offset")]
public class UIButtonOffset : MonoBehaviour
{
	// Token: 0x06000029 RID: 41 RVA: 0x0000DAAC File Offset: 0x0000BCAC
	private void Start()
	{
		if (!this.mStarted)
		{
			this.mStarted = true;
			if (this.tweenTarget == null)
			{
				this.tweenTarget = base.transform;
			}
			this.mPos = this.tweenTarget.localPosition;
		}
	}

	// Token: 0x0600002A RID: 42 RVA: 0x000023F9 File Offset: 0x000005F9
	private void OnEnable()
	{
		if (this.mStarted && this.mHighlighted)
		{
			this.OnHover(UICamera.IsHighlighted(base.gameObject));
		}
	}

	// Token: 0x0600002B RID: 43 RVA: 0x0000DAFC File Offset: 0x0000BCFC
	private void OnDisable()
	{
		if (this.mStarted && this.tweenTarget != null)
		{
			TweenPosition component = this.tweenTarget.GetComponent<TweenPosition>();
			if (component != null)
			{
				component.position = this.mPos;
				component.enabled = false;
			}
		}
	}

	// Token: 0x0600002C RID: 44 RVA: 0x0000DB50 File Offset: 0x0000BD50
	private void OnPress(bool isPressed)
	{
		if (base.enabled)
		{
			if (!this.mStarted)
			{
				this.Start();
			}
			TweenPosition.Begin(this.tweenTarget.gameObject, this.duration, (!isPressed) ? ((!UICamera.IsHighlighted(base.gameObject)) ? this.mPos : (this.mPos + this.hover)) : (this.mPos + this.pressed)).method = UITweener.Method.EaseInOut;
		}
	}

	// Token: 0x0600002D RID: 45 RVA: 0x0000DBE0 File Offset: 0x0000BDE0
	private void OnHover(bool isOver)
	{
		if (base.enabled)
		{
			if (!this.mStarted)
			{
				this.Start();
			}
			TweenPosition.Begin(this.tweenTarget.gameObject, this.duration, (!isOver) ? this.mPos : (this.mPos + this.hover)).method = UITweener.Method.EaseInOut;
			this.mHighlighted = isOver;
		}
	}

	// Token: 0x04000021 RID: 33
	public Transform tweenTarget;

	// Token: 0x04000022 RID: 34
	public Vector3 hover = Vector3.zero;

	// Token: 0x04000023 RID: 35
	public Vector3 pressed = new Vector3(2f, -2f);

	// Token: 0x04000024 RID: 36
	public float duration = 0.2f;

	// Token: 0x04000025 RID: 37
	private Vector3 mPos;

	// Token: 0x04000026 RID: 38
	private bool mStarted;

	// Token: 0x04000027 RID: 39
	private bool mHighlighted;
}

﻿//#define RELEASE
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GKML
{
    public class Patches
    {
#if RELEASE
        public static object RLPatch(object __result, string path)
        {
            var overriddenResource = ResourceLoader.getInjectedResource_Load(path);
            if(overriddenResource == null)
            {
                return __result;
            }
            return overriddenResource;
        }
#endif
    }
}

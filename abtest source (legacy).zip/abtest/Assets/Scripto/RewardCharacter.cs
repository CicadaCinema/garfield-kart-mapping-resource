﻿using System;

// Token: 0x02000158 RID: 344
[Serializable]
public class RewardCharacter : RewardBase
{
	// Token: 0x06000989 RID: 2441 RVA: 0x0004341C File Offset: 0x0004161C
	protected override void GetReward()
	{
		if (Singleton<GameSaveManager>.Instance.GetCharacterState(this.Character) == E_UnlockableItemSate.Hidden)
		{
			Singleton<RewardManager>.Instance.UnlockCharacter(this.Character);
		}
	}

	// Token: 0x040009BF RID: 2495
	public ECharacter Character;
}

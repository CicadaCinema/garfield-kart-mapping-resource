﻿using System;
using UnityEngine;

// Token: 0x020000C9 RID: 201
public class AutolockPieBonusEntity : PieBonusEntity
{
	// Token: 0x06000539 RID: 1337 RVA: 0x0002A840 File Offset: 0x00028A40
	public AutolockPieBonusEntity()
	{
		this.m_pTarget = null;
		this.QuitRailDist = 50f;
		this.m_NextPathPosition = MultiPathPosition.UNDEFINED_MP_POS;
		this.m_bOffRail = false;
		this.m_pTargetGearBox = null;
		this.m_eItem = EITEM.ITEM_AUTOLOCK_PIE;
	}

	// Token: 0x0600053A RID: 1338 RVA: 0x00005C0B File Offset: 0x00003E0B
	public override void Awake()
	{
		base.Awake();
		this.m_pTransform = base.transform;
	}

	// Token: 0x0600053B RID: 1339 RVA: 0x00005C1F File Offset: 0x00003E1F
	public override void Update()
	{
		base.Update();
	}

	// Token: 0x0600053C RID: 1340 RVA: 0x0002A890 File Offset: 0x00028A90
	public void Launch(Kart _Launcher, bool _Behind)
	{
		base.Launch(_Behind);
		if (!_Behind)
		{
			if (_Launcher != null)
			{
				RcVehicleRaceStats raceStats = _Launcher.RaceStats;
				if (raceStats != null)
				{
					if (raceStats.GetRank() == 0)
					{
						this.m_pTarget = null;
					}
					else
					{
						this.m_pTarget = raceStats.GetPreceding();
						Kart kart = (Kart)this.m_pTarget;
						if (kart != null)
						{
							KartBonusMgr bonusMgr = kart.GetBonusMgr();
							bonusMgr.OnLaunchBonus = (Action<EITEM, bool>)Delegate.Combine(bonusMgr.OnLaunchBonus, new Action<EITEM, bool>(this.TargetLaunchBonus));
							Kart kart2 = kart;
							kart2.OnBeSwaped = (Action<Kart>)Delegate.Combine(kart2.OnBeSwaped, new Action<Kart>(this.ChangeTarget));
							this.m_pTargetGearBox = this.m_pTarget.gameObject.transform.parent.GetComponentInChildren<KartArcadeGearBox>();
						}
					}
				}
			}
			this.m_bOffRail = false;
		}
	}

	// Token: 0x0600053D RID: 1341 RVA: 0x0002A974 File Offset: 0x00028B74
	protected override void DisableHudRadar()
	{
		if (Singleton<GameManager>.Instance.GameMode != null && Singleton<GameManager>.Instance.GameMode.Hud && Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp)
		{
			Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp.AutolockPies[this._index].enabled = false;
		}
	}

	// Token: 0x0600053E RID: 1342 RVA: 0x00005C27 File Offset: 0x00003E27
	protected override void UpdateHudRadar(float pHorizontalDist, float pDistance)
	{
		if (Singleton<GameManager>.Instance.GameMode != null)
		{
			Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp.UpdateAutolockPie(this._index, pHorizontalDist, pDistance);
		}
	}

	// Token: 0x0600053F RID: 1343 RVA: 0x0002A9F8 File Offset: 0x00028BF8
	protected override bool CheckHUDRadar()
	{
		bool flag = base.CheckHUDRadar();
		bool flag2 = !(this.m_pTarget == null) && this.m_pTarget == this.m_pHumanPlayer;
		return flag && flag2;
	}

	// Token: 0x06000540 RID: 1344 RVA: 0x0002AA40 File Offset: 0x00028C40
	public void ChangeTarget(Kart pKart)
	{
		Kart kart = (Kart)this.m_pTarget;
		if (kart != null)
		{
			Kart kart2 = kart;
			kart2.OnBeSwaped = (Action<Kart>)Delegate.Remove(kart2.OnBeSwaped, new Action<Kart>(this.ChangeTarget));
			KartBonusMgr bonusMgr = kart.GetBonusMgr();
			bonusMgr.OnLaunchBonus = (Action<EITEM, bool>)Delegate.Remove(bonusMgr.OnLaunchBonus, new Action<EITEM, bool>(this.TargetLaunchBonus));
		}
		this.m_pTarget = pKart;
		pKart.OnBeSwaped = (Action<Kart>)Delegate.Combine(pKart.OnBeSwaped, new Action<Kart>(this.ChangeTarget));
		KartBonusMgr bonusMgr2 = pKart.GetBonusMgr();
		bonusMgr2.OnLaunchBonus = (Action<EITEM, bool>)Delegate.Combine(bonusMgr2.OnLaunchBonus, new Action<EITEM, bool>(this.TargetLaunchBonus));
	}

	// Token: 0x06000541 RID: 1345 RVA: 0x0002AB00 File Offset: 0x00028D00
	public override void SetActive(bool _Active)
	{
		base.SetActive(_Active);
		if (_Active)
		{
			if (!this.m_bBehind && this.IdealPath != null)
			{
				this.IdealPath.UpdateMPPosition(ref this.m_PathPosition, this.m_pLauncher.Transform.position, 0, 0, false);
			}
		}
		else
		{
			this.SetDefaultValues();
			this.DisableHudRadar();
		}
	}

	// Token: 0x06000542 RID: 1346 RVA: 0x0002AB6C File Offset: 0x00028D6C
	public override void FixedUpdate()
	{
		base.FixedUpdate();
		if ((Network.peerType == NetworkPeerType.Disconnected || Network.isServer) && this.m_bActive && this.m_pTarget != null)
		{
			Vector3 a = this.m_pTarget.GetPosition();
			if (!this.m_bOffRail && this.IdealPath != null)
			{
				float distToEndLine = this.IdealPath.GetDistToEndLine(this.m_PathPosition);
				float distToEndLine2 = this.IdealPath.GetDistToEndLine(this.m_pTarget.RaceStats.GetGuidePosition());
				if (Mathf.Abs(distToEndLine2 - distToEndLine) > this.QuitRailDist || distToEndLine2 > distToEndLine)
				{
					this.IdealPath.UpdateMPPosition(ref this.m_PathPosition, this.m_pTransform.position, 3, 1, false);
					this.m_NextPathPosition = this.m_PathPosition;
					if (this.FirstDistanceToPath == 0f)
					{
						this.FirstDistanceToPath = 5f + Mathf.Clamp(Mathf.Abs(this.m_PathPosition.section.GetSimplePath().GetSignedDistToSegment2D(this.m_pTransform.position, this.m_PathPosition.pathPosition.index, Vector3.up)), 0f, 50f);
					}
					else if (this.FirstDistanceToPath > 5f && Mathf.Abs(this.m_PathPosition.section.GetSimplePath().GetSignedDistToSegment2D(this.m_pTransform.position, this.m_PathPosition.pathPosition.index, Vector3.up)) < 1f)
					{
						this.FirstDistanceToPath = 5f;
					}
					float firstDistanceToPath = this.FirstDistanceToPath;
					a = this.m_PathPosition.section.GetSimplePath().MoveOnPath(ref this.m_NextPathPosition.pathPosition, ref firstDistanceToPath, true);
					if (this.m_NextPathPosition.pathPosition.index == this.m_PathPosition.section.GetSimplePath().GetNbPoints() - 1 && firstDistanceToPath > 0f)
					{
						RcMultiPathSection rcMultiPathSection = null;
						float num = 1E+38f;
						foreach (RcMultiPathSection rcMultiPathSection2 in this.m_PathPosition.section.m_pAfterBranches)
						{
							if (this.m_pTarget.RaceStats.GetGuidePosition().section == rcMultiPathSection2)
							{
								rcMultiPathSection = rcMultiPathSection2;
								break;
							}
							if (rcMultiPathSection2 && rcMultiPathSection2.GetDistToEndLine() < num)
							{
								rcMultiPathSection = rcMultiPathSection2;
								num = rcMultiPathSection2.GetDistToEndLine();
							}
						}
						if (rcMultiPathSection != null)
						{
							this.m_NextPathPosition.pathPosition = PathPosition.UNDEFINED_POSITION;
							a = rcMultiPathSection.GetSimplePath().MoveOnPath(ref this.m_NextPathPosition.pathPosition, ref firstDistanceToPath, true);
						}
					}
				}
				else
				{
					this.SynchronizeOffRail();
					if (this.m_pTargetGearBox != null)
					{
						this.m_fCurrentSpeed = this.m_pTargetGearBox.GetBaseMaxSpeed() + this.AddedSpeed;
						this.m_fCurrentSpeed += this.m_pLauncher.GetBonusMgr().GetBonusValue(EITEM.ITEM_PIE, EBonusCustomEffect.SPEED) * this.m_fCurrentSpeed / 100f;
					}
				}
			}
			this.m_Direction = (a - this.m_pTransform.position).normalized;
			if (this.m_Direction != Vector3.zero && !this.m_bBehind && this.m_pRigidBody.gameObject.activeInHierarchy)
			{
				Quaternion quaternion = default(Quaternion);
				quaternion = Quaternion.LookRotation(this.m_Direction);
				if (this.m_pTransform.rotation != quaternion)
				{
					this.m_pTransform.rotation = quaternion;
				}
				if (this.m_pTarget.IsBoosting())
				{
					this.m_pRigidBody.velocity = this.m_Direction * (this.m_fCurrentSpeed * (1f - this.m_fCatchUpOnBoost) + this.m_pTargetGearBox.GetMaxSpeed() * this.m_fCatchUpOnBoost);
				}
				else
				{
					this.m_pRigidBody.velocity = this.m_Direction * this.m_fCurrentSpeed;
				}
				this.m_pRigidBody.angularVelocity = this.m_Direction * 3f;
			}
		}
	}

	// Token: 0x06000543 RID: 1347 RVA: 0x00005C5F File Offset: 0x00003E5F
	public override void DoDestroy()
	{
		base.DoDestroy();
		if (this.SoundLocked)
		{
			this.SoundLocked.Stop();
		}
		this.SetDefaultValues();
	}

	// Token: 0x06000544 RID: 1348 RVA: 0x0002AFB4 File Offset: 0x000291B4
	public void SetDefaultValues()
	{
		this.m_PathPosition = MultiPathPosition.UNDEFINED_MP_POS;
		this.m_NextPathPosition = MultiPathPosition.UNDEFINED_MP_POS;
		this.m_bOffRail = false;
		if (this.m_pTarget != null)
		{
			KartBonusMgr bonusMgr = ((Kart)this.m_pTarget).GetBonusMgr();
			bonusMgr.OnLaunchBonus = (Action<EITEM, bool>)Delegate.Remove(bonusMgr.OnLaunchBonus, new Action<EITEM, bool>(this.TargetLaunchBonus));
			Kart kart = (Kart)this.m_pTarget;
			kart.OnBeSwaped = (Action<Kart>)Delegate.Remove(kart.OnBeSwaped, new Action<Kart>(this.ChangeTarget));
			this.m_pTarget = null;
		}
		this.FirstDistanceToPath = 0f;
		this.m_pTargetGearBox = null;
	}

	// Token: 0x06000545 RID: 1349 RVA: 0x0002B068 File Offset: 0x00029268
	private void TargetLaunchBonus(EITEM _Item, bool _Behind)
	{
		if (_Item == EITEM.ITEM_SPRING && !_Behind && this.m_bOffRail)
		{
			Kart kart = (Kart)this.m_pTarget;
			if (kart != null)
			{
				KartBonusMgr bonusMgr = kart.GetBonusMgr();
				bonusMgr.OnLaunchBonus = (Action<EITEM, bool>)Delegate.Remove(bonusMgr.OnLaunchBonus, new Action<EITEM, bool>(this.TargetLaunchBonus));
				Kart kart2 = kart;
				kart2.OnBeSwaped = (Action<Kart>)Delegate.Remove(kart2.OnBeSwaped, new Action<Kart>(this.ChangeTarget));
			}
			this.m_pTarget = this.m_pTarget.RaceStats.GetPreceding();
			if (this.m_pTarget.RaceStats.GetRank() == 5)
			{
				this.m_pTarget = null;
			}
			else
			{
				base.ComputeBaseSpeed();
				this.m_bOffRail = false;
				if (this.SoundLocked && this.SoundTravel)
				{
					this.SoundTravel.Play();
					this.SoundLocked.Stop();
				}
			}
		}
	}

	// Token: 0x06000546 RID: 1350 RVA: 0x00005C88 File Offset: 0x00003E88
	public override void DoStickOnGround(Vector3 normal)
	{
		base.DoStickOnGround(normal);
		if (this.SoundLocked)
		{
			this.SoundLocked.Stop();
		}
	}

	// Token: 0x06000547 RID: 1351 RVA: 0x0002B16C File Offset: 0x0002936C
	public void SynchronizeOffRail()
	{
		if (this.m_bActive)
		{
			if (Network.peerType != NetworkPeerType.Disconnected && this.m_pNetworkView != null)
			{
				this.m_pNetworkView.RPC("OnSynchronizeOffRail", RPCMode.All, new object[0]);
			}
			else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
			{
				this.DoSynchronizeOffRail();
			}
		}
	}

	// Token: 0x06000548 RID: 1352 RVA: 0x00005CAC File Offset: 0x00003EAC
	public void DoSynchronizeOffRail()
	{
		this.m_bOffRail = true;
		if (this.SoundLocked && this.SoundTravel)
		{
			this.SoundTravel.Stop();
			this.SoundLocked.Play();
		}
	}

	// Token: 0x04000512 RID: 1298
	public float QuitRailDist;

	// Token: 0x04000513 RID: 1299
	private RcVehicle m_pTarget;

	// Token: 0x04000514 RID: 1300
	private bool m_bOffRail;

	// Token: 0x04000515 RID: 1301
	private MultiPathPosition m_NextPathPosition;

	// Token: 0x04000516 RID: 1302
	private float FirstDistanceToPath;

	// Token: 0x04000517 RID: 1303
	private KartArcadeGearBox m_pTargetGearBox;

	// Token: 0x04000518 RID: 1304
	public float AddedSpeed;

	// Token: 0x04000519 RID: 1305
	public float m_fCatchUpOnBoost = 0.25f;

	// Token: 0x0400051A RID: 1306
	public AudioSource SoundLocked;
}

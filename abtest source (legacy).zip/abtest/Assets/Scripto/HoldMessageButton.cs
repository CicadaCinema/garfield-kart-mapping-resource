﻿using System;
using UnityEngine;

// Token: 0x0200011E RID: 286
public class HoldMessageButton : MonoBehaviour
{
	// Token: 0x060007E8 RID: 2024 RVA: 0x00007931 File Offset: 0x00005B31
	public void Start()
	{
		this.m_pHudControls = this.Target.GetComponent<HUDControls>();
	}

	// Token: 0x060007E9 RID: 2025 RVA: 0x0003B68C File Offset: 0x0003988C
	public void Update()
	{
		UICamera.current = this.CurrentCamera;
		foreach (Touch touch in Input.touches)
		{
			if (this.CurrentCamera != null && UICamera.Raycast(touch.position, ref this.m_pRaycastHit) && this.m_pRaycastHit.collider.gameObject == base.gameObject)
			{
				this._Input = true;
				this.m_pHudControls.OnAction(this.Action);
				break;
			}
		}
		if (Input.touches.Length == 0)
		{
			this._Input = false;
		}
	}

	// Token: 0x060007EA RID: 2026 RVA: 0x00003B80 File Offset: 0x00001D80
	public void OnEnter()
	{
	}

	// Token: 0x060007EB RID: 2027 RVA: 0x00007944 File Offset: 0x00005B44
	public bool HasInput()
	{
		return this._Input;
	}

	// Token: 0x04000805 RID: 2053
	public GameObject Target;

	// Token: 0x04000806 RID: 2054
	private HUDControls m_pHudControls;

	// Token: 0x04000807 RID: 2055
	public EInputAction Action;

	// Token: 0x04000808 RID: 2056
	public UICamera CurrentCamera;

	// Token: 0x04000809 RID: 2057
	private RaycastHit m_pRaycastHit;

	// Token: 0x0400080A RID: 2058
	private bool _Input;
}

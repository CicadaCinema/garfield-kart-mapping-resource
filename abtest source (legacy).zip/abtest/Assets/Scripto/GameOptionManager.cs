﻿using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEngine;

// Token: 0x020000B6 RID: 182
public class GameOptionManager : Singleton<GameOptionManager>
{
	// Token: 0x06000496 RID: 1174 RVA: 0x000282D4 File Offset: 0x000264D4
	public void Init()
	{
		string text = string.Empty;
		if (Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
		{
			string text2 = Application.dataPath + "/../External/Language.csv";
			if (!File.Exists(text2))
			{
				Debug.LogWarning(text2 + " not exist");
			}
			string[] array = File.ReadAllText(text2).Split(new char[]
			{
				';'
			});
			if ((array.Length == 1 && array[0] != string.Empty) || (array.Length == 2 && array[1] == string.Empty && array[0] != string.Empty))
			{
				string[] array2 = GameOptionManager.SplitCsvLine(array[0]);
				text = array2[0];
			}
		}
		if (text == string.Empty)
		{
			this.m_oLanguageList = Array.ConvertAll<UnityEngine.Object, TextAsset>(Resources.LoadAll("Localization", typeof(TextAsset)), (UnityEngine.Object o) => (TextAsset)o);
		}
		else
		{
			this.m_oLanguageList = new TextAsset[1];
			TextAsset textAsset = Resources.Load("Localization/" + text, typeof(TextAsset)) as TextAsset;
			if (textAsset != null)
			{
				this.m_oLanguageList[0] = textAsset;
			}
			else
			{
				this.m_oLanguageList[0] = (Resources.Load("Localization/Lang_DB_UK", typeof(TextAsset)) as TextAsset);
			}
		}
		Localization.instance.languages = this.m_oLanguageList;
		this.Load(out this._language, out this._sfxVolume, out this._musicVolume, out this._gyroSensibility, out this._inputType, out this._gameSave);
		this.Save();
	}

	// Token: 0x06000497 RID: 1175 RVA: 0x00028490 File Offset: 0x00026690
	public void Load(out GameOptionManager.ELangID opLanguage, out float opSfxVolume, out float opMusicVolume, out float opGyroSensibility, out E_InputType opInputType, out GameSave opGameSave)
	{
		opGameSave = GameSave.Load("options");
		opLanguage = GameOptionManager.ELangID.English;
		opSfxVolume = 0.5f;
		opMusicVolume = 0.5f;
		opGyroSensibility = 0f;
		opInputType = E_InputType.Keyboard;
		E_InputType pDefaultValue = E_InputType.Keyboard;
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			pDefaultValue = E_InputType.Gyroscopic;
		}
		int @int = opGameSave.GetInt("inp_", (int)pDefaultValue);
		opInputType = (E_InputType)@int;
		SystemLanguage systemLanguage = Application.systemLanguage;
		GameOptionManager.ELangID eLangId;
		if (systemLanguage != SystemLanguage.French)
		{
			if (systemLanguage != SystemLanguage.German)
			{
				if (systemLanguage != SystemLanguage.Italian)
				{
					if (systemLanguage != SystemLanguage.Spanish)
					{
						eLangId = GameOptionManager.ELangID.English;
					}
					else
					{
						eLangId = GameOptionManager.ELangID.Spanish;
					}
				}
				else
				{
					eLangId = GameOptionManager.ELangID.Italian;
				}
			}
			else
			{
				eLangId = GameOptionManager.ELangID.German;
			}
		}
		else
		{
			eLangId = GameOptionManager.ELangID.French;
		}
		string gameLanguage = this.GetGameLanguage(eLangId);
		string @string = opGameSave.GetString("lang_", gameLanguage);
		this.SetLanguage(@string, false);
		opLanguage = this.GetCurrentLangId();
		opSfxVolume = opGameSave.GetFloat("sfx_", 0.5f);
		this.SetSfxVolume(opSfxVolume, false);
		opMusicVolume = opGameSave.GetFloat("mus_", 0.5f);
		this.SetMusicVolume(opMusicVolume, false);
		opGyroSensibility = opGameSave.GetFloat("gyro_", 0.7f);
	}

	// Token: 0x06000498 RID: 1176 RVA: 0x000054F7 File Offset: 0x000036F7
	public float GetSfxVolume()
	{
		return this._sfxVolume;
	}

	// Token: 0x06000499 RID: 1177 RVA: 0x000054FF File Offset: 0x000036FF
	public float GetMusicVolume()
	{
		return this._musicVolume;
	}

	// Token: 0x0600049A RID: 1178 RVA: 0x00005507 File Offset: 0x00003707
	public float GetGyroSensibility()
	{
		return this._gyroSensibility;
	}

	// Token: 0x0600049B RID: 1179 RVA: 0x0000550F File Offset: 0x0000370F
	public E_InputType GetInputType()
	{
		return this._inputType;
	}

	// Token: 0x0600049C RID: 1180 RVA: 0x00005517 File Offset: 0x00003717
	public void SetSfxVolume(float pVolume, bool pSave)
	{
		this._sfxVolume = pVolume;
		AudioListener.volume = this._sfxVolume;
		this._gameSave.SetFloat("sfx_", this._sfxVolume);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x0600049D RID: 1181 RVA: 0x0000554D File Offset: 0x0000374D
	public void SetMusicVolume(float pVolume, bool pSave)
	{
		this._musicVolume = pVolume;
		AudioListener.volume = this._musicVolume;
		this._gameSave.SetFloat("mus_", this._musicVolume);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x0600049E RID: 1182 RVA: 0x00005583 File Offset: 0x00003783
	public void SetGyroSensibility(float fSensibility, bool pSave)
	{
		this._gyroSensibility = fSensibility;
		this._gameSave.SetFloat("gyro_", this._gyroSensibility);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x0600049F RID: 1183 RVA: 0x000055AE File Offset: 0x000037AE
	public void SetInputType(E_InputType pInputType, bool pSave)
	{
		this._inputType = pInputType;
		this._gameSave.SetInt("inp_", (int)this._inputType);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x060004A0 RID: 1184 RVA: 0x000055D9 File Offset: 0x000037D9
	public void SetLanguage(string pLanguage, bool pSave)
	{
		this.SetLanguage(this.ConvertLangStringToId(pLanguage), pSave);
	}

	// Token: 0x060004A1 RID: 1185 RVA: 0x000285C0 File Offset: 0x000267C0
	public void SetLanguage(GameOptionManager.ELangID eLanguage, bool pSave)
	{
		string gameLanguage = this.GetGameLanguage(eLanguage);
		this._language = this.ConvertLangStringToId(gameLanguage);
		Localization.instance.currentLanguage = gameLanguage;
		this._gameSave.SetString("lang_", gameLanguage);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x060004A2 RID: 1186 RVA: 0x000055E9 File Offset: 0x000037E9
	public GameOptionManager.ELangID GetCurrentLangId()
	{
		return this._language;
	}

	// Token: 0x060004A3 RID: 1187 RVA: 0x000055F1 File Offset: 0x000037F1
	public void Save()
	{
		this._gameSave.Save();
	}

	// Token: 0x060004A4 RID: 1188 RVA: 0x0002860C File Offset: 0x0002680C
	public string ConvertLangIdToString(GameOptionManager.ELangID eLangId)
	{
		uint num = (uint)eLangId;
		if ((ulong)num >= (ulong)((long)GameOptionManager.m_oLanguageCodeList.Length))
		{
			num = 1u;
		}
		return GameOptionManager.m_oLanguageCodeList[(int)((UIntPtr)num)];
	}

	// Token: 0x060004A5 RID: 1189 RVA: 0x00028634 File Offset: 0x00026834
	public GameOptionManager.ELangID ConvertLangStringToId(string sLang)
	{
		int num = 0;
		foreach (string a in GameOptionManager.m_oLanguageCodeList)
		{
			if (a == sLang)
			{
				return (GameOptionManager.ELangID)num;
			}
			num++;
		}
		return GameOptionManager.ELangID.English;
	}

	// Token: 0x060004A6 RID: 1190 RVA: 0x000055FE File Offset: 0x000037FE
	public int GetLanguagesNumber()
	{
		return this.m_oLanguageList.Length;
	}

	// Token: 0x060004A7 RID: 1191 RVA: 0x00028674 File Offset: 0x00026874
	public string GetGameLanguage(GameOptionManager.ELangID eLangId)
	{
		string text = this.ConvertLangIdToString(eLangId);
		for (int i = 0; i < this.m_oLanguageList.Length; i++)
		{
			if (text == this.m_oLanguageList[i].name)
			{
				return text;
			}
		}
		if (this.m_oLanguageList.Length > 0)
		{
			return this.m_oLanguageList[0].name;
		}
		return string.Empty;
	}

	// Token: 0x060004A8 RID: 1192 RVA: 0x00005608 File Offset: 0x00003808
	public static string[] SplitCsvLine(string line)
	{
		return (from Match m in Regex.Matches(line, "(((?<x>(?=[,\\r\\n]+))|\"(?<x>([^\"]|\"\")+)\"|(?<x>[^,\\r\\n]+)),?)", RegexOptions.ExplicitCapture)
		select m.Groups[1].Value).ToArray<string>();
	}

	// Token: 0x04000459 RID: 1113
	private const string _LANGUAGE = "lang_";

	// Token: 0x0400045A RID: 1114
	private const string _SFXVOL = "sfx_";

	// Token: 0x0400045B RID: 1115
	private const string _MUSICVOL = "mus_";

	// Token: 0x0400045C RID: 1116
	private const string _GYRO = "gyro_";

	// Token: 0x0400045D RID: 1117
	private const string _INPUT = "inp_";

	// Token: 0x0400045E RID: 1118
	private const string _SAVE = "options";

	// Token: 0x0400045F RID: 1119
	private GameSave _gameSave;

	// Token: 0x04000460 RID: 1120
	private GameOptionManager.ELangID _language;

	// Token: 0x04000461 RID: 1121
	private float _sfxVolume;

	// Token: 0x04000462 RID: 1122
	private float _musicVolume;

	// Token: 0x04000463 RID: 1123
	private float _gyroSensibility;

	// Token: 0x04000464 RID: 1124
	private E_InputType _inputType;

	// Token: 0x04000465 RID: 1125
	private TextAsset[] m_oLanguageList;

	// Token: 0x04000466 RID: 1126
	private static string[] m_oLanguageCodeList = new string[]
	{
		"Lang_DB_FR",
		"Lang_DB_UK",
		"Lang_DB_GE",
		"Lang_DB_SP",
		"Lang_DB_IT"
	};

	// Token: 0x020000B7 RID: 183
	public enum ELangID
	{
		// Token: 0x0400046A RID: 1130
		French,
		// Token: 0x0400046B RID: 1131
		English,
		// Token: 0x0400046C RID: 1132
		German,
		// Token: 0x0400046D RID: 1133
		Spanish,
		// Token: 0x0400046E RID: 1134
		Italian
	}
}

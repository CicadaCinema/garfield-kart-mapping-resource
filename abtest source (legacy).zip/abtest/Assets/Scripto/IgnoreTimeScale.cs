﻿using System;
using UnityEngine;

// Token: 0x02000042 RID: 66
[AddComponentMenu("NGUI/Internal/Ignore TimeScale Behaviour")]
public class IgnoreTimeScale : MonoBehaviour
{
	// Token: 0x17000030 RID: 48
	// (get) Token: 0x0600016C RID: 364 RVA: 0x00003251 File Offset: 0x00001451
	public float realTime
	{
		get
		{
			return this.mRt;
		}
	}

	// Token: 0x17000031 RID: 49
	// (get) Token: 0x0600016D RID: 365 RVA: 0x00003259 File Offset: 0x00001459
	public float realTimeDelta
	{
		get
		{
			return this.mTimeDelta;
		}
	}

	// Token: 0x0600016E RID: 366 RVA: 0x00003261 File Offset: 0x00001461
	protected virtual void OnEnable()
	{
		this.mTimeStarted = true;
		this.mTimeDelta = 0f;
		this.mTimeStart = Time.realtimeSinceStartup;
	}

	// Token: 0x0600016F RID: 367 RVA: 0x00014528 File Offset: 0x00012728
	protected float UpdateRealTimeDelta()
	{
		this.mRt = Time.realtimeSinceStartup;
		if (this.mTimeStarted)
		{
			float b = this.mRt - this.mTimeStart;
			this.mActual += Mathf.Max(0f, b);
			this.mTimeDelta = 0.001f * Mathf.Round(this.mActual * 1000f);
			this.mActual -= this.mTimeDelta;
			if (this.mTimeDelta > 1f)
			{
				this.mTimeDelta = 1f;
			}
			this.mTimeStart = this.mRt;
		}
		else
		{
			this.mTimeStarted = true;
			this.mTimeStart = this.mRt;
			this.mTimeDelta = 0f;
		}
		return this.mTimeDelta;
	}

	// Token: 0x04000179 RID: 377
	private float mRt;

	// Token: 0x0400017A RID: 378
	private float mTimeStart;

	// Token: 0x0400017B RID: 379
	private float mTimeDelta;

	// Token: 0x0400017C RID: 380
	private float mActual;

	// Token: 0x0400017D RID: 381
	private bool mTimeStarted;
}

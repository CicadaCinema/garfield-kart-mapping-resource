﻿using System;
using UnityEngine;

// Token: 0x020001F5 RID: 501
public class RcController : MonoBehaviour
{
	// Token: 0x06000D81 RID: 3457 RVA: 0x0000B3B7 File Offset: 0x000095B7
	public RcController()
	{
		this.m_pVehicle = null;
		this.m_bDrivingEnabled = true;
	}

	// Token: 0x06000D82 RID: 3458 RVA: 0x0000B3CD File Offset: 0x000095CD
	public virtual void SetVehicle(RcVehicle _pVehicle)
	{
		this.m_pVehicle = _pVehicle;
	}

	// Token: 0x06000D83 RID: 3459 RVA: 0x0000B3D6 File Offset: 0x000095D6
	public virtual float GetSteer()
	{
		return 0f;
	}

	// Token: 0x06000D84 RID: 3460 RVA: 0x0000B3D6 File Offset: 0x000095D6
	public virtual float GetSpeedBehaviour()
	{
		return 0f;
	}

	// Token: 0x06000D85 RID: 3461 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void StartRace()
	{
	}

	// Token: 0x06000D86 RID: 3462 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void Reset()
	{
	}

	// Token: 0x06000D87 RID: 3463 RVA: 0x0000B3DD File Offset: 0x000095DD
	public virtual void SetDrivingEnabled(bool _enabled)
	{
		this.m_bDrivingEnabled = _enabled;
	}

	// Token: 0x06000D88 RID: 3464 RVA: 0x0000B3E6 File Offset: 0x000095E6
	public bool IsDrivingEnabled()
	{
		return this.m_bDrivingEnabled;
	}

	// Token: 0x06000D89 RID: 3465 RVA: 0x0000B3EE File Offset: 0x000095EE
	public RcVehicle GetVehicle()
	{
		return this.m_pVehicle;
	}

	// Token: 0x06000D8A RID: 3466 RVA: 0x0000B3F6 File Offset: 0x000095F6
	public virtual void Awake()
	{
		this.m_pVehicle = base.transform.parent.GetComponentInChildren<RcVehicle>();
	}

	// Token: 0x04000D2C RID: 3372
	protected RcVehicle m_pVehicle;

	// Token: 0x04000D2D RID: 3373
	protected bool m_bDrivingEnabled;
}

﻿using System;

// Token: 0x02000258 RID: 600
[Serializable]
public class Tuple<T1, T2, T3, T4> : Tuple<T1, T2, T3>
{
	// Token: 0x0600107E RID: 4222 RVA: 0x00067818 File Offset: 0x00065A18
	public Tuple() : this(default(T1), default(T2), default(T3), default(T4))
	{
	}

	// Token: 0x0600107F RID: 4223 RVA: 0x0000D198 File Offset: 0x0000B398
	public Tuple(T1 pItem1, T2 pItem2, T3 pItem3, T4 pItem4) : base(pItem1, pItem2, pItem3)
	{
		this.Item4 = pItem4;
	}

	// Token: 0x04000FBD RID: 4029
	public T4 Item4;
}

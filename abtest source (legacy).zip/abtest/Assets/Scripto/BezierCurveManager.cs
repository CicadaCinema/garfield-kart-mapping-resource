﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000247 RID: 583
public class BezierCurveManager : MonoBehaviour, IBezierCurveManager
{
	// Token: 0x0600103A RID: 4154 RVA: 0x00066344 File Offset: 0x00064544
	public void Awake()
	{
		foreach (IBezierWaypoint item in base.gameObject.GetComponentsInChildren(typeof(IBezierWaypoint)))
		{
			this.waypointList.Add(item);
		}
		this.bezier = new Bezier(this.waypointList.ToArray());
	}

	// Token: 0x0600103B RID: 4155 RVA: 0x0000CEE5 File Offset: 0x0000B0E5
	public void Start()
	{
		if (this.EnableDistanceCalculations)
		{
			this.bezier.SetUpDistanceLists(this.IsFullLoop);
			this.SecondsForFullLoop = 100f - this.bezier.MaxDistance / 10f;
		}
	}

	// Token: 0x0600103C RID: 4156 RVA: 0x0000CF20 File Offset: 0x0000B120
	public Vector3 GetPositionAtTime(float time)
	{
		time /= this.SecondsForFullLoop;
		return this.bezier.GetPointAtTime(time, this.IsFullLoop);
	}

	// Token: 0x0600103D RID: 4157 RVA: 0x000663A8 File Offset: 0x000645A8
	public Vector3 GetPositionAtDistance(float distance, float time)
	{
		if (this.EnableDistanceCalculations)
		{
			time /= this.SecondsForFullLoop;
			float num = this.bezier.LookupDistanceOfExistingTime(time);
			float t = this.bezier.FindTimePointAlongeSplineAtDistance(distance + num);
			return this.bezier.GetPointAtTime(t, this.IsFullLoop);
		}
		throw new Exception("In order to use GetPositionAtDistance the EnableDistanceCalculation variable must be set to true at start up so the distance points can be pre-calculated");
	}

	// Token: 0x0600103E RID: 4158 RVA: 0x00066404 File Offset: 0x00064604
	public void OnDrawGizmos()
	{
		List<BezierWaypoint> list = new List<BezierWaypoint>();
		foreach (BezierWaypoint bezierWaypoint in base.gameObject.GetComponentsInChildren(typeof(BezierWaypoint)))
		{
			bezierWaypoint.SetControlPoints();
			if (bezierWaypoint.IsValid)
			{
				list.Add(bezierWaypoint);
			}
		}
		if (this.DrawCurve && list.Count != 0)
		{
			Bezier bezier = new Bezier(list.ToArray());
			for (float num = 0f; num < 1f; num += 0.001f)
			{
				if (num < 0.999f)
				{
					Gizmos.color = this.DebugColor;
					Gizmos.DrawLine(bezier.GetPointAtTime(num, this.IsFullLoop), bezier.GetPointAtTime(num + 0.001f, this.IsFullLoop));
				}
			}
		}
	}

	// Token: 0x04000F8F RID: 3983
	private List<IBezierWaypoint> waypointList = new List<IBezierWaypoint>();

	// Token: 0x04000F90 RID: 3984
	private Bezier bezier;

	// Token: 0x04000F91 RID: 3985
	public bool EnableDistanceCalculations;

	// Token: 0x04000F92 RID: 3986
	public bool DrawPoints;

	// Token: 0x04000F93 RID: 3987
	public bool DrawCurve = true;

	// Token: 0x04000F94 RID: 3988
	public bool DrawControlPoints;

	// Token: 0x04000F95 RID: 3989
	public bool IsFullLoop;

	// Token: 0x04000F96 RID: 3990
	public float SecondsForFullLoop = 1f;

	// Token: 0x04000F97 RID: 3991
	public Color DebugColor = Color.white;
}

﻿using System;
using UnityEngine;

// Token: 0x0200022B RID: 555
public class AtfFacebookEventListener : MonoBehaviour
{
}

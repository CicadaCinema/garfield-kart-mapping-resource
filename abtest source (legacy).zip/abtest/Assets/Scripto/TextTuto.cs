﻿using System;
using UnityEngine;

// Token: 0x0200026C RID: 620
public class TextTuto : MonoBehaviour
{
	// Token: 0x060010F8 RID: 4344 RVA: 0x0000D350 File Offset: 0x0000B550
	private void Update()
	{
		this.toto.text = this.TutoText;
	}

	// Token: 0x0400101E RID: 4126
	public string TutoText = string.Empty;

	// Token: 0x0400101F RID: 4127
	public GUIText toto;
}

﻿using System;
using UnityEngine;

// Token: 0x02000130 RID: 304
public class GameSettings : MonoBehaviour
{
	// Token: 0x040008AE RID: 2222
	public int[] ChampionShipScores = new int[]
	{
		9,
		6,
		4,
		3,
		2,
		1
	};

	// Token: 0x040008AF RID: 2223
	public float MinDistToEndLine = 500f;
}

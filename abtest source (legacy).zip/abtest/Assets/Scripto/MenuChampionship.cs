﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200019B RID: 411
public class MenuChampionship : AbstractMenu
{
	// Token: 0x06000B0B RID: 2827 RVA: 0x0004A81C File Offset: 0x00048A1C
	public override void OnEnter()
	{
		base.OnEnter();
		this.m_bNeedToInit = true;
		this.ChampionshipDataComp.Clear();
		foreach (GameObject gameObject in this.ChampionshipData)
		{
			this.ChampionshipDataComp.Add(gameObject.GetComponent<ChampionShipData>());
		}
	}

	// Token: 0x06000B0C RID: 2828 RVA: 0x0004A898 File Offset: 0x00048A98
	public void LateUpdate()
	{
		if (this.m_bNeedToInit)
		{
			this.m_bNeedToInit = false;
			foreach (ChampionshipButton championshipButton in this.Championship)
			{
				championshipButton.Reward.gameObject.SetActive(false);
			}
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
			{
				if (this.DifficultyButton50)
				{
					this.DifficultyButton50.SetActive(false);
				}
				if (this.DifficultyButton100)
				{
					this.DifficultyButton100.SetActive(false);
				}
				if (this.DifficultyButton150)
				{
					this.DifficultyButton150.GetComponentInChildren<UICheckbox>().isChecked = true;
				}
				Singleton<GameConfigurator>.Instance.Difficulty = EDifficulty.HARD;
			}
			else
			{
				if (this.DifficultyButton50)
				{
					this.DifficultyButton50.SetActive(true);
				}
				if (this.DifficultyButton100)
				{
					this.DifficultyButton100.SetActive(true);
				}
				if (Singleton<GameConfigurator>.Instance != null)
				{
					switch (Singleton<GameConfigurator>.Instance.Difficulty)
					{
					case EDifficulty.NORMAL:
						if (this.DifficultyButton100)
						{
							this.DifficultyButton100.GetComponentInChildren<UICheckbox>().isChecked = true;
						}
						break;
					case EDifficulty.HARD:
						if (this.DifficultyButton150)
						{
							this.DifficultyButton150.GetComponentInChildren<UICheckbox>().isChecked = true;
						}
						break;
					case EDifficulty.EASY:
						if (this.DifficultyButton50)
						{
							this.DifficultyButton50.GetComponentInChildren<UICheckbox>().isChecked = true;
						}
						break;
					}
				}
				else
				{
					if (this.DifficultyButton100)
					{
						this.DifficultyButton100.GetComponentInChildren<UICheckbox>().isChecked = true;
					}
					Singleton<GameConfigurator>.Instance.Difficulty = EDifficulty.NORMAL;
				}
			}
			this.RefreshChampionship();
		}
	}

	// Token: 0x06000B0D RID: 2829 RVA: 0x00009968 File Offset: 0x00007B68
	public override void Update()
	{
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			this.ActSwapMenu(EMenus.MENU_SOLO);
		}
	}

	// Token: 0x06000B0E RID: 2830 RVA: 0x0004AA94 File Offset: 0x00048C94
	public void RefreshChampionship()
	{
		int num = 0;
		foreach (ChampionshipButton championshipButton in this.Championship)
		{
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
			{
				int rank = Singleton<GameSaveManager>.Instance.GetRank(this.ChampionshipData[num].name, Singleton<GameConfigurator>.Instance.Difficulty);
				if (rank >= 0 && rank < 3)
				{
					championshipButton.Reward.gameObject.SetActive(true);
					championshipButton.Reward.ChangeTexture(rank);
				}
				else
				{
					championshipButton.Reward.gameObject.SetActive(false);
				}
			}
			E_UnlockableItemSate e_UnlockableItemSate;
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
			{
				bool flag = Singleton<GameConfigurator>.Instance.ChampionshipPass != null && Singleton<GameConfigurator>.Instance.ChampionshipPass.ChampionshipSelectionned == this.ChampionshipDataComp[num] && Singleton<GameConfigurator>.Instance.ChampionshipPass.State != EChampionshipPassState.None;
				if (flag)
				{
					e_UnlockableItemSate = E_UnlockableItemSate.Unlocked;
				}
				else
				{
					E_UnlockableItemSate championShipState = Singleton<GameSaveManager>.Instance.GetChampionShipState(this.ChampionshipData[num].name, EDifficulty.EASY);
					E_UnlockableItemSate championShipState2 = Singleton<GameSaveManager>.Instance.GetChampionShipState(this.ChampionshipData[num].name, EDifficulty.NORMAL);
					E_UnlockableItemSate championShipState3 = Singleton<GameSaveManager>.Instance.GetChampionShipState(this.ChampionshipData[num].name, EDifficulty.HARD);
					e_UnlockableItemSate = ((championShipState2 <= championShipState3) ? championShipState3 : championShipState2);
					e_UnlockableItemSate = ((championShipState <= e_UnlockableItemSate) ? e_UnlockableItemSate : championShipState);
				}
			}
			else
			{
				bool flag = Singleton<GameConfigurator>.Instance.ChampionshipPass != null && Singleton<GameConfigurator>.Instance.ChampionshipPass.ChampionshipSelectionned == this.ChampionshipDataComp[num] && Singleton<GameConfigurator>.Instance.ChampionshipPass.State != EChampionshipPassState.None && Singleton<GameConfigurator>.Instance.ChampionshipPass.Difficulty == Singleton<GameConfigurator>.Instance.Difficulty;
				if (flag)
				{
					e_UnlockableItemSate = E_UnlockableItemSate.Unlocked;
				}
				else
				{
					e_UnlockableItemSate = Singleton<GameSaveManager>.Instance.GetChampionShipState(this.ChampionshipData[num].name, Singleton<GameConfigurator>.Instance.Difficulty);
				}
			}
			switch (e_UnlockableItemSate)
			{
			case E_UnlockableItemSate.Hidden:
				goto IL_310;
			case E_UnlockableItemSate.NewLocked:
			case E_UnlockableItemSate.Locked:
				championshipButton.ButtonChampionship.gameObject.SetActive(true);
				championshipButton.ButtonPass.gameObject.SetActive(true);
				championshipButton.ButtonPassLabel.text = string.Format(Localization.instance.Get("MENU_BT_PASS"), this.Price);
				championshipButton.Collider.enabled = false;
				if (championshipButton.Hidden)
				{
					championshipButton.Hidden.SetActive(false);
				}
				break;
			case E_UnlockableItemSate.NewUnlocked:
			case E_UnlockableItemSate.Unlocked:
				championshipButton.ButtonChampionship.gameObject.SetActive(true);
				championshipButton.ButtonPass.gameObject.SetActive(false);
				championshipButton.Collider.enabled = true;
				if (championshipButton.Hidden)
				{
					championshipButton.Hidden.SetActive(false);
				}
				break;
			default:
				goto IL_310;
			}
			IL_353:
			num++;
			continue;
			IL_310:
			championshipButton.ButtonChampionship.gameObject.SetActive(false);
			championshipButton.ButtonPass.gameObject.SetActive(false);
			if (championshipButton.Hidden)
			{
				championshipButton.Hidden.SetActive(true);
			}
			goto IL_353;
		}
	}

	// Token: 0x06000B0F RID: 2831 RVA: 0x00009989 File Offset: 0x00007B89
	public void OnSelectChampionship(int iId)
	{
		Singleton<GameConfigurator>.Instance.SetChampionshipData(this.ChampionshipDataComp[iId], false);
		Singleton<GameConfigurator>.Instance.CurrentTrackIndex = 0;
		this.ActSwapMenu(EMenus.MENU_SELECT_TRACK);
	}

	// Token: 0x06000B10 RID: 2832 RVA: 0x000099B4 File Offset: 0x00007BB4
	public void OnSelectRandomChampionship()
	{
		this.OnSelectChampionship(UnityEngine.Random.Range(0, this.AvailableChampionships()));
		if (Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.CHAMPIONSHIP)
		{
			Singleton<GameConfigurator>.Instance.CurrentTrackIndex = UnityEngine.Random.Range(0, 4);
		}
	}

	// Token: 0x06000B11 RID: 2833 RVA: 0x0004AE34 File Offset: 0x00049034
	public void OnSelectDifficulty(int iDifficulty)
	{
		switch (iDifficulty)
		{
		case 0:
			Singleton<GameConfigurator>.Instance.Difficulty = EDifficulty.EASY;
			break;
		case 1:
			Singleton<GameConfigurator>.Instance.Difficulty = EDifficulty.NORMAL;
			break;
		case 2:
			Singleton<GameConfigurator>.Instance.Difficulty = EDifficulty.HARD;
			break;
		}
		this.RefreshChampionship();
	}

	// Token: 0x06000B12 RID: 2834 RVA: 0x0004AE90 File Offset: 0x00049090
	public int AvailableChampionships()
	{
		int num = 0;
		foreach (ChampionShipData championShipData in this.ChampionshipDataComp)
		{
			if (Singleton<GameSaveManager>.Instance.GetChampionShipState(championShipData.name, Singleton<GameConfigurator>.Instance.Difficulty) == E_UnlockableItemSate.NewUnlocked || Singleton<GameSaveManager>.Instance.GetChampionShipState(championShipData.name, Singleton<GameConfigurator>.Instance.Difficulty) == E_UnlockableItemSate.Unlocked)
			{
				num++;
			}
		}
		return num;
	}

	// Token: 0x06000B13 RID: 2835 RVA: 0x0004AF2C File Offset: 0x0004912C
	public void OnPass(int iId)
	{
		this.m_pMenuEntryPoint.ShowPurchasePopup(string.Format(Localization.instance.Get("MENU_POPUP_BUY_ITEM_CONFIRMATION_CHAMPIONSHIP"), this.Price), this.Price, new MenuEntryPoint.Callback(this.PurchaseItem), null, iId);
	}

	// Token: 0x06000B14 RID: 2836 RVA: 0x000099E9 File Offset: 0x00007BE9
	public void PurchaseItem(object oParam)
	{
		Singleton<GameConfigurator>.Instance.SetChampionshipData(this.ChampionshipDataComp[(int)oParam], true);
		this.ActSwapMenu(EMenus.MENU_SELECT_TRACK);
	}

	// Token: 0x06000B15 RID: 2837 RVA: 0x00009A0E File Offset: 0x00007C0E
	public void OnShop()
	{
		this.m_pMenuEntryPoint.SetState(EMenus.MENU_SELECT_KART, 1);
	}

	// Token: 0x06000B16 RID: 2838 RVA: 0x00009A1D File Offset: 0x00007C1D
	public void OnUnlock()
	{
		GkUtils.UnlockAll();
		this.RefreshChampionship();
	}

	// Token: 0x04000AE8 RID: 2792
	public List<GameObject> ChampionshipData = new List<GameObject>();

	// Token: 0x04000AE9 RID: 2793
	public GameObject DifficultyButton50;

	// Token: 0x04000AEA RID: 2794
	public GameObject DifficultyButton100;

	// Token: 0x04000AEB RID: 2795
	public GameObject DifficultyButton150;

	// Token: 0x04000AEC RID: 2796
	private List<ChampionShipData> ChampionshipDataComp = new List<ChampionShipData>();

	// Token: 0x04000AED RID: 2797
	private bool m_bNeedToInit;

	// Token: 0x04000AEE RID: 2798
	public List<ChampionshipButton> Championship = new List<ChampionshipButton>();

	// Token: 0x04000AEF RID: 2799
	public int Price;
}

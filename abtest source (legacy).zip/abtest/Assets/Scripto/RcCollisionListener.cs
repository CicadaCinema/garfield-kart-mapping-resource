﻿using System;

// Token: 0x02000229 RID: 553
public interface RcCollisionListener
{
	// Token: 0x06000F8C RID: 3980
	void OnCollision(CollisionData collisionInfo);
}

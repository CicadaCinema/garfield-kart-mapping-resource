﻿using System;
using UnityEngine;

// Token: 0x0200002A RID: 42
[AddComponentMenu("NGUI/Interaction/Scroll Bar")]
[ExecuteInEditMode]
public class UIScrollBar : MonoBehaviour
{
	// Token: 0x17000011 RID: 17
	// (get) Token: 0x060000DE RID: 222 RVA: 0x00002D5E File Offset: 0x00000F5E
	public Transform cachedTransform
	{
		get
		{
			if (this.mTrans == null)
			{
				this.mTrans = base.transform;
			}
			return this.mTrans;
		}
	}

	// Token: 0x17000012 RID: 18
	// (get) Token: 0x060000DF RID: 223 RVA: 0x00002D83 File Offset: 0x00000F83
	public Camera cachedCamera
	{
		get
		{
			if (this.mCam == null)
			{
				this.mCam = NGUITools.FindCameraForLayer(base.gameObject.layer);
			}
			return this.mCam;
		}
	}

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x060000E0 RID: 224 RVA: 0x00002DB2 File Offset: 0x00000FB2
	// (set) Token: 0x060000E1 RID: 225 RVA: 0x00002DBA File Offset: 0x00000FBA
	public UISprite background
	{
		get
		{
			return this.mBG;
		}
		set
		{
			if (this.mBG != value)
			{
				this.mBG = value;
				this.mIsDirty = true;
			}
		}
	}

	// Token: 0x17000014 RID: 20
	// (get) Token: 0x060000E2 RID: 226 RVA: 0x00002DDB File Offset: 0x00000FDB
	// (set) Token: 0x060000E3 RID: 227 RVA: 0x00002DE3 File Offset: 0x00000FE3
	public UISprite foreground
	{
		get
		{
			return this.mFG;
		}
		set
		{
			if (this.mFG != value)
			{
				this.mFG = value;
				this.mIsDirty = true;
			}
		}
	}

	// Token: 0x17000015 RID: 21
	// (get) Token: 0x060000E4 RID: 228 RVA: 0x00002E04 File Offset: 0x00001004
	// (set) Token: 0x060000E5 RID: 229 RVA: 0x00011F28 File Offset: 0x00010128
	public UIScrollBar.Direction direction
	{
		get
		{
			return this.mDir;
		}
		set
		{
			if (this.mDir != value)
			{
				this.mDir = value;
				this.mIsDirty = true;
				if (this.mBG != null)
				{
					Transform cachedTransform = this.mBG.cachedTransform;
					Vector3 localScale = cachedTransform.localScale;
					if ((this.mDir == UIScrollBar.Direction.Vertical && localScale.x > localScale.y) || (this.mDir == UIScrollBar.Direction.Horizontal && localScale.x < localScale.y))
					{
						float x = localScale.x;
						localScale.x = localScale.y;
						localScale.y = x;
						cachedTransform.localScale = localScale;
						this.ForceUpdate();
						if (this.mBG.collider != null)
						{
							NGUITools.AddWidgetCollider(this.mBG.gameObject);
						}
						if (this.mFG.collider != null)
						{
							NGUITools.AddWidgetCollider(this.mFG.gameObject);
						}
					}
				}
			}
		}
	}

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x060000E6 RID: 230 RVA: 0x00002E0C File Offset: 0x0000100C
	// (set) Token: 0x060000E7 RID: 231 RVA: 0x00002E14 File Offset: 0x00001014
	public bool inverted
	{
		get
		{
			return this.mInverted;
		}
		set
		{
			if (this.mInverted != value)
			{
				this.mInverted = value;
				this.mIsDirty = true;
			}
		}
	}

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x060000E8 RID: 232 RVA: 0x00002E30 File Offset: 0x00001030
	// (set) Token: 0x060000E9 RID: 233 RVA: 0x0001202C File Offset: 0x0001022C
	public float scrollValue
	{
		get
		{
			return this.mScroll;
		}
		set
		{
			float num = Mathf.Clamp01(value);
			if (this.mScroll != num)
			{
				this.mScroll = num;
				this.mIsDirty = true;
				if (this.onChange != null)
				{
					this.onChange(this);
				}
			}
		}
	}

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x060000EA RID: 234 RVA: 0x00002E38 File Offset: 0x00001038
	// (set) Token: 0x060000EB RID: 235 RVA: 0x00012074 File Offset: 0x00010274
	public float barSize
	{
		get
		{
			return this.mSize;
		}
		set
		{
			float num = Mathf.Clamp01(value);
			if (this.mSize != num)
			{
				this.mSize = num;
				this.mIsDirty = true;
				if (this.onChange != null)
				{
					this.onChange(this);
				}
			}
		}
	}

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x060000EC RID: 236 RVA: 0x000120BC File Offset: 0x000102BC
	// (set) Token: 0x060000ED RID: 237 RVA: 0x00012108 File Offset: 0x00010308
	public float alpha
	{
		get
		{
			if (this.mFG != null)
			{
				return this.mFG.alpha;
			}
			if (this.mBG != null)
			{
				return this.mBG.alpha;
			}
			return 0f;
		}
		set
		{
			if (this.mFG != null)
			{
				this.mFG.alpha = value;
				NGUITools.SetActiveSelf(this.mFG.gameObject, this.mFG.alpha > 0.001f);
			}
			if (this.mBG != null)
			{
				this.mBG.alpha = value;
				NGUITools.SetActiveSelf(this.mBG.gameObject, this.mBG.alpha > 0.001f);
			}
		}
	}

	// Token: 0x060000EE RID: 238 RVA: 0x00012194 File Offset: 0x00010394
	private void CenterOnPos(Vector2 localPos)
	{
		if (this.mBG == null || this.mFG == null)
		{
			return;
		}
		Bounds bounds = NGUIMath.CalculateRelativeInnerBounds(this.cachedTransform, this.mBG);
		Bounds bounds2 = NGUIMath.CalculateRelativeInnerBounds(this.cachedTransform, this.mFG);
		if (this.mDir == UIScrollBar.Direction.Horizontal)
		{
			float num = bounds.size.x - bounds2.size.x;
			float num2 = num * 0.5f;
			float num3 = bounds.center.x - num2;
			float num4 = (num <= 0f) ? 0f : ((localPos.x - num3) / num);
			this.scrollValue = ((!this.mInverted) ? num4 : (1f - num4));
		}
		else
		{
			float num5 = bounds.size.y - bounds2.size.y;
			float num6 = num5 * 0.5f;
			float num7 = bounds.center.y - num6;
			float num8 = (num5 <= 0f) ? 0f : (1f - (localPos.y - num7) / num5);
			this.scrollValue = ((!this.mInverted) ? num8 : (1f - num8));
		}
	}

	// Token: 0x060000EF RID: 239 RVA: 0x00012308 File Offset: 0x00010508
	private void Reposition(Vector2 screenPos)
	{
		Transform cachedTransform = this.cachedTransform;
		Plane plane = new Plane(cachedTransform.rotation * Vector3.back, cachedTransform.position);
		Ray ray = this.cachedCamera.ScreenPointToRay(screenPos);
		float distance;
		if (!plane.Raycast(ray, out distance))
		{
			return;
		}
		this.CenterOnPos(cachedTransform.InverseTransformPoint(ray.GetPoint(distance)));
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x00002E40 File Offset: 0x00001040
	private void OnPressBackground(GameObject go, bool isPressed)
	{
		this.mCam = UICamera.currentCamera;
		this.Reposition(UICamera.lastTouchPosition);
		if (!isPressed && this.onDragFinished != null)
		{
			this.onDragFinished();
		}
	}

	// Token: 0x060000F1 RID: 241 RVA: 0x00002E74 File Offset: 0x00001074
	private void OnDragBackground(GameObject go, Vector2 delta)
	{
		this.mCam = UICamera.currentCamera;
		this.Reposition(UICamera.lastTouchPosition);
	}

	// Token: 0x060000F2 RID: 242 RVA: 0x00012374 File Offset: 0x00010574
	private void OnPressForeground(GameObject go, bool isPressed)
	{
		if (isPressed)
		{
			this.mCam = UICamera.currentCamera;
			Bounds bounds = NGUIMath.CalculateAbsoluteWidgetBounds(this.mFG.cachedTransform);
			this.mScreenPos = this.mCam.WorldToScreenPoint(bounds.center);
		}
		else if (this.onDragFinished != null)
		{
			this.onDragFinished();
		}
	}

	// Token: 0x060000F3 RID: 243 RVA: 0x00002E8C File Offset: 0x0000108C
	private void OnDragForeground(GameObject go, Vector2 delta)
	{
		this.mCam = UICamera.currentCamera;
		this.Reposition(this.mScreenPos + UICamera.currentTouch.totalDelta);
	}

	// Token: 0x060000F4 RID: 244 RVA: 0x000123DC File Offset: 0x000105DC
	private void Start()
	{
		if (this.background != null && this.background.collider != null)
		{
			UIEventListener uieventListener = UIEventListener.Get(this.background.gameObject);
			UIEventListener uieventListener2 = uieventListener;
			uieventListener2.onPress = (UIEventListener.BoolDelegate)Delegate.Combine(uieventListener2.onPress, new UIEventListener.BoolDelegate(this.OnPressBackground));
			UIEventListener uieventListener3 = uieventListener;
			uieventListener3.onDrag = (UIEventListener.VectorDelegate)Delegate.Combine(uieventListener3.onDrag, new UIEventListener.VectorDelegate(this.OnDragBackground));
		}
		if (this.foreground != null && this.foreground.collider != null)
		{
			UIEventListener uieventListener4 = UIEventListener.Get(this.foreground.gameObject);
			UIEventListener uieventListener5 = uieventListener4;
			uieventListener5.onPress = (UIEventListener.BoolDelegate)Delegate.Combine(uieventListener5.onPress, new UIEventListener.BoolDelegate(this.OnPressForeground));
			UIEventListener uieventListener6 = uieventListener4;
			uieventListener6.onDrag = (UIEventListener.VectorDelegate)Delegate.Combine(uieventListener6.onDrag, new UIEventListener.VectorDelegate(this.OnDragForeground));
		}
		this.ForceUpdate();
	}

	// Token: 0x060000F5 RID: 245 RVA: 0x00002EB4 File Offset: 0x000010B4
	private void Update()
	{
		if (this.mIsDirty)
		{
			this.ForceUpdate();
		}
	}

	// Token: 0x060000F6 RID: 246 RVA: 0x000124E8 File Offset: 0x000106E8
	public void ForceUpdate()
	{
		this.mIsDirty = false;
		if (this.mBG != null && this.mFG != null)
		{
			this.mSize = Mathf.Clamp01(this.mSize);
			this.mScroll = Mathf.Clamp01(this.mScroll);
			Vector4 border = this.mBG.border;
			Vector4 border2 = this.mFG.border;
			Vector2 vector = new Vector2(Mathf.Max(0f, this.mBG.cachedTransform.localScale.x - border.x - border.z), Mathf.Max(0f, this.mBG.cachedTransform.localScale.y - border.y - border.w));
			float num = (!this.mInverted) ? this.mScroll : (1f - this.mScroll);
			if (this.mDir == UIScrollBar.Direction.Horizontal)
			{
				Vector2 vector2 = new Vector2(vector.x * this.mSize, vector.y);
				this.mFG.pivot = UIWidget.Pivot.Left;
				this.mBG.pivot = UIWidget.Pivot.Left;
				this.mBG.cachedTransform.localPosition = Vector3.zero;
				this.mFG.cachedTransform.localPosition = new Vector3(border.x - border2.x + (vector.x - vector2.x) * num, 0f, 0f);
				this.mFG.cachedTransform.localScale = new Vector3(vector2.x + border2.x + border2.z, vector2.y + border2.y + border2.w, 1f);
				if (num < 0.999f && num > 0.001f)
				{
					this.mFG.MakePixelPerfect();
				}
			}
			else
			{
				Vector2 vector3 = new Vector2(vector.x, vector.y * this.mSize);
				this.mFG.pivot = UIWidget.Pivot.Top;
				this.mBG.pivot = UIWidget.Pivot.Top;
				this.mBG.cachedTransform.localPosition = Vector3.zero;
				this.mFG.cachedTransform.localPosition = new Vector3(0f, -border.y + border2.y - (vector.y - vector3.y) * num, 0f);
				this.mFG.cachedTransform.localScale = new Vector3(vector3.x + border2.x + border2.z, vector3.y + border2.y + border2.w, 1f);
				if (num < 0.999f && num > 0.001f)
				{
					this.mFG.MakePixelPerfect();
				}
			}
		}
	}

	// Token: 0x040000FE RID: 254
	[HideInInspector]
	[SerializeField]
	private UISprite mBG;

	// Token: 0x040000FF RID: 255
	[SerializeField]
	[HideInInspector]
	private UISprite mFG;

	// Token: 0x04000100 RID: 256
	[HideInInspector]
	[SerializeField]
	private UIScrollBar.Direction mDir;

	// Token: 0x04000101 RID: 257
	[SerializeField]
	[HideInInspector]
	private bool mInverted;

	// Token: 0x04000102 RID: 258
	[SerializeField]
	[HideInInspector]
	private float mScroll;

	// Token: 0x04000103 RID: 259
	[HideInInspector]
	[SerializeField]
	private float mSize = 1f;

	// Token: 0x04000104 RID: 260
	private Transform mTrans;

	// Token: 0x04000105 RID: 261
	private bool mIsDirty;

	// Token: 0x04000106 RID: 262
	private Camera mCam;

	// Token: 0x04000107 RID: 263
	private Vector2 mScreenPos = Vector2.zero;

	// Token: 0x04000108 RID: 264
	public UIScrollBar.OnScrollBarChange onChange;

	// Token: 0x04000109 RID: 265
	public UIScrollBar.OnDragFinished onDragFinished;

	// Token: 0x0200002B RID: 43
	public enum Direction
	{
		// Token: 0x0400010B RID: 267
		Horizontal,
		// Token: 0x0400010C RID: 268
		Vertical
	}

	// Token: 0x0200002C RID: 44
	// (Invoke) Token: 0x060000F8 RID: 248
	public delegate void OnScrollBarChange(UIScrollBar sb);

	// Token: 0x0200002D RID: 45
	// (Invoke) Token: 0x060000FC RID: 252
	public delegate void OnDragFinished();
}

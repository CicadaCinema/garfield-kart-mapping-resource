﻿using System;
using UnityEngine;

// Token: 0x0200016B RID: 363
public abstract class GameState : MonoBehaviour
{
	// Token: 0x060009CC RID: 2508 RVA: 0x000020F3 File Offset: 0x000002F3
	public GameState()
	{
	}

	// Token: 0x17000161 RID: 353
	// (get) Token: 0x060009CD RID: 2509 RVA: 0x00008AFE File Offset: 0x00006CFE
	// (set) Token: 0x060009CE RID: 2510 RVA: 0x00008B06 File Offset: 0x00006D06
	public GameMode gameMode
	{
		get
		{
			return this.m_pGameMode;
		}
		set
		{
			this.m_pGameMode = value;
		}
	}

	// Token: 0x060009CF RID: 2511 RVA: 0x00008B0F File Offset: 0x00006D0F
	public void OnDestroy()
	{
		this.OnStateChanged = null;
	}

	// Token: 0x060009D0 RID: 2512
	public abstract void Enter();

	// Token: 0x060009D1 RID: 2513
	public abstract void Exit();

	// Token: 0x060009D2 RID: 2514
	public abstract void Update();

	// Token: 0x040009F9 RID: 2553
	public Action<E_GameState> OnStateChanged;

	// Token: 0x040009FA RID: 2554
	protected GameMode m_pGameMode;
}

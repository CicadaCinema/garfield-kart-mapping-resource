﻿using System;
using UnityEngine;

// Token: 0x02000172 RID: 370
public class StartGameState : GameState
{
	// Token: 0x060009F6 RID: 2550 RVA: 0x000453B8 File Offset: 0x000435B8
	public override void Enter()
	{
		this.Reset();
		CameraBase component = Camera.main.GetComponent<CameraBase>();
		if (component != null && component.CurrentState != ECamState.Follow)
		{
			component.SwitchCamera(ECamState.Follow, ECamState.TransCut);
		}
		HUDInGame hud = Singleton<GameManager>.Instance.GameMode.Hud;
		if (hud != null)
		{
			hud.StartRace();
			this._hudCD = hud.Countdown;
		}
		for (int i = 0; i < ((Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.TIME_TRIAL) ? this.m_pGameMode.PlayerCount : 1); i++)
		{
			Kart kart = this.m_pGameMode.GetKart(i);
			if (kart)
			{
				KartSound kartSound = kart.KartSound;
				if (kartSound != null)
				{
					kartSound.StartVoices();
				}
			}
		}
	}

	// Token: 0x060009F7 RID: 2551 RVA: 0x00008C59 File Offset: 0x00006E59
	public override void Exit()
	{
		this.Reset();
	}

	// Token: 0x060009F8 RID: 2552 RVA: 0x00008C61 File Offset: 0x00006E61
	public void Reset()
	{
		this._startTimer = 1f;
		this._startCounter = 4;
	}

	// Token: 0x060009F9 RID: 2553 RVA: 0x0004548C File Offset: 0x0004368C
	public override void Update()
	{
		float deltaTime = Time.deltaTime;
		if (this._startCounter > 0)
		{
			this._startTimer -= deltaTime;
			if (this._startTimer <= 0f)
			{
				this._startTimer += 1f;
				this._startCounter--;
				if (Singleton<GameManager>.Instance.SoundManager)
				{
					Singleton<GameManager>.Instance.SoundManager.StopSound(ERaceSounds.JingleCountdown);
					if (this._startCounter == 0)
					{
						Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.CountdownGo);
					}
					else
					{
						Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.Countdown);
					}
				}
				if (this._hudCD != null)
				{
					this._hudCD.SetCountdown(this._startCounter);
				}
				if (this._startCounter == 0)
				{
					this.OnStateChanged(E_GameState.Race);
				}
			}
		}
	}

	// Token: 0x04000A07 RID: 2567
	private float _startTimer = 1f;

	// Token: 0x04000A08 RID: 2568
	private int _startCounter = 4;

	// Token: 0x04000A09 RID: 2569
	private HUDCountdown _hudCD;
}

﻿using System;

// Token: 0x020001AE RID: 430
public class MenuRewardsHatUnlocked : MenuRewards
{
	// Token: 0x06000B82 RID: 2946 RVA: 0x0004D114 File Offset: 0x0004B314
	public override void OnEnter()
	{
		base.OnEnter();
		Tuple<string, ERarity> tuple = Singleton<RewardManager>.Instance.PopUnlockedHat();
		this._hat = tuple.Item1;
		this._rarity = tuple.Item2;
		Tuple<string, UIAtlas, string, ERarity> infos = base.GetInfos(this._hat, E_RewardType.Hat);
		this.LbRewardName.text = infos.Item1;
		if (this.Sprite != null)
		{
			this.Sprite.spriteName = infos.Item3;
		}
		if (this.SpriteRarity != null)
		{
			this.SpriteRarity.ChangeTexture(Tricks.LogBase2((int)infos.Item4));
		}
		this.LTradePrice.text = this.TradePrice.ToString();
	}

	// Token: 0x06000B83 RID: 2947 RVA: 0x0004D1C8 File Offset: 0x0004B3C8
	public void OnTrade()
	{
		this._keepHat = false;
		if (Singleton<GameSaveManager>.Instance.GetCoins() > this.TradePrice)
		{
			Singleton<GameSaveManager>.Instance.SpendCoins(this.TradePrice, false);
			Singleton<RewardManager>.Instance.TradeReward(this._rarity);
		}
		this.OnGoNext();
	}

	// Token: 0x06000B84 RID: 2948 RVA: 0x0000A078 File Offset: 0x00008278
	public override void OnGoNext()
	{
		if (this._keepHat)
		{
			Singleton<GameSaveManager>.Instance.SetHatState(this._hat, E_UnlockableItemSate.NewUnlocked, false);
		}
		base.OnGoNext();
	}

	// Token: 0x04000B43 RID: 2883
	private string _hat;

	// Token: 0x04000B44 RID: 2884
	private ERarity _rarity;

	// Token: 0x04000B45 RID: 2885
	private bool _keepHat = true;

	// Token: 0x04000B46 RID: 2886
	public int TradePrice;

	// Token: 0x04000B47 RID: 2887
	public UILabel LTradePrice;
}

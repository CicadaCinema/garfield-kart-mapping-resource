﻿using System;
using UnityEngine;

// Token: 0x02000109 RID: 265
public class HUDEndSingleRace : HUDEndRace
{
	// Token: 0x06000731 RID: 1841 RVA: 0x000071B1 File Offset: 0x000053B1
	public override void Init()
	{
		base.Init();
		this.m_cEntryPoint = GameObject.Find("EntryPoint").GetComponent<EntryPoint>();
		this.FacebookButton.SetActive(false);
	}

	// Token: 0x06000732 RID: 1842 RVA: 0x00035AD8 File Offset: 0x00033CD8
	public override void FillPositions()
	{
		base.FillPositions();
		if (Singleton<GameConfigurator>.Instance.ChampionShipData != null)
		{
			string arg = Singleton<GameConfigurator>.Instance.ChampionShipData.TracksName[Singleton<GameConfigurator>.Instance.CurrentTrackIndex];
			this.LabelTitle.text = string.Format(Localization.instance.Get("HUD_DYN_SINGLE_RACE_RESULTS"), arg);
		}
	}

	// Token: 0x06000733 RID: 1843 RVA: 0x00035B3C File Offset: 0x00033D3C
	public override void GetScoreInfos(int iIndex, out int iKartIndex, out int iScore, out int iTotalScore, out bool bEquality)
	{
		RaceScoreData racePos = Singleton<GameConfigurator>.Instance.RankingManager.GetRacePos(iIndex);
		if (iIndex > 0)
		{
			bEquality = (racePos.RaceScore == Singleton<GameConfigurator>.Instance.RankingManager.GetRacePos(iIndex - 1).RaceScore);
		}
		else
		{
			bEquality = false;
		}
		iKartIndex = racePos.KartIndex;
		iScore = racePos.RaceScore;
		iTotalScore = 0;
	}

	// Token: 0x06000734 RID: 1844 RVA: 0x00035BA0 File Offset: 0x00033DA0
	public void OnFacebook()
	{
		if (this.m_cEntryPoint)
		{
			RaceScoreData scoreData = Singleton<GameConfigurator>.Instance.RankingManager.GetScoreData(Singleton<GameManager>.Instance.GameMode.GetHumanPlayerVehicleId());
			int num = scoreData.RacePosition + 1;
			string sTitle = string.Empty;
			if (num > 3)
			{
				num = 4;
			}
			sTitle = string.Format(Localization.instance.Get("FB_SINGLERACE_TITLE_" + num), Singleton<GameConfigurator>.Instance.ChampionShipData.TracksName[Singleton<GameConfigurator>.Instance.CurrentTrackIndex]);
			string sDescription = string.Format(Localization.instance.Get("FB_SINGLERACE_DESCRIPTION"), Localization.instance.Get("FB_PLAYER_PLACE_" + (scoreData.RacePosition + 1)));
			this.m_cEntryPoint.OnFacebook(sTitle, sDescription);
		}
	}

	// Token: 0x04000709 RID: 1801
	public GameObject FacebookButton;

	// Token: 0x0400070A RID: 1802
	private EntryPoint m_cEntryPoint;
}

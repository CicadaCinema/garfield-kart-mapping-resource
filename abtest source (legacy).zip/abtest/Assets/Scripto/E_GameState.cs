﻿using System;

// Token: 0x0200016A RID: 362
public enum E_GameState
{
	// Token: 0x040009F0 RID: 2544
	TrackPresentation,
	// Token: 0x040009F1 RID: 2545
	CarPresentation,
	// Token: 0x040009F2 RID: 2546
	Start,
	// Token: 0x040009F3 RID: 2547
	Race,
	// Token: 0x040009F4 RID: 2548
	End,
	// Token: 0x040009F5 RID: 2549
	Result,
	// Token: 0x040009F6 RID: 2550
	Podium,
	// Token: 0x040009F7 RID: 2551
	Tutorial,
	// Token: 0x040009F8 RID: 2552
	RaceTutorial
}

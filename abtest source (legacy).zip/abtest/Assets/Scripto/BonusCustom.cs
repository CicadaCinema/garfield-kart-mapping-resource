﻿using System;
using System.Collections.Generic;

// Token: 0x020000F6 RID: 246
public class BonusCustom : IconCarac
{
	// Token: 0x060006AE RID: 1710 RVA: 0x000341C0 File Offset: 0x000323C0
	public Template GetTemplate(ECharacter pCharacter)
	{
		foreach (Template template in this.Transforms)
		{
			if (template.Character == pCharacter)
			{
				return template;
			}
		}
		return null;
	}

	// Token: 0x060006AF RID: 1711 RVA: 0x0003422C File Offset: 0x0003242C
	public static int Compare(BonusCustom oItem1, BonusCustom oItem2)
	{
		int num = IconCarac.CompareNameDefault(oItem1, oItem2);
		if (num == 0)
		{
			num = BonusCustom.CompareStateHidden(oItem1, oItem2);
			if (num == 0)
			{
				num = BonusCustom.CompareRarity(oItem1, oItem2);
				if (num == 0)
				{
					num = BonusCustom.CompareState(oItem1, oItem2);
					if (num == 0)
					{
						num = BonusCustom.CompareUnique(oItem1, oItem2);
						if (num == 0)
						{
							num = IconCarac.CompareName(oItem1, oItem2);
						}
					}
				}
			}
		}
		return num;
	}

	// Token: 0x060006B0 RID: 1712 RVA: 0x00006B81 File Offset: 0x00004D81
	private static int CompareRarity(BonusCustom oItem1, BonusCustom oItem2)
	{
		return oItem1.Rarity - oItem2.Rarity;
	}

	// Token: 0x060006B1 RID: 1713 RVA: 0x00034288 File Offset: 0x00032488
	private static int CompareUnique(BonusCustom oItem1, BonusCustom oItem2)
	{
		bool flag = oItem2.Owner != ECharacter.NONE;
		if (oItem1.Owner != ECharacter.NONE)
		{
			if (flag)
			{
				return 0;
			}
			return -1;
		}
		else
		{
			if (flag)
			{
				return 1;
			}
			return 0;
		}
	}

	// Token: 0x060006B2 RID: 1714 RVA: 0x000342C8 File Offset: 0x000324C8
	private static int CompareState(BonusCustom oItem1, BonusCustom oItem2)
	{
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		return IconCarac.SuppressNewState(instance.GetHatState(oItem2.name)) - IconCarac.SuppressNewState(instance.GetHatState(oItem1.name));
	}

	// Token: 0x060006B3 RID: 1715 RVA: 0x00034300 File Offset: 0x00032500
	private static int CompareStateHidden(BonusCustom oItem1, BonusCustom oItem2)
	{
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		bool flag = instance.GetHatState(oItem2.name) == E_UnlockableItemSate.Hidden;
		if (instance.GetHatState(oItem1.name) == E_UnlockableItemSate.Hidden)
		{
			if (flag)
			{
				return 0;
			}
			return 1;
		}
		else
		{
			if (flag)
			{
				return -1;
			}
			return 0;
		}
	}

	// Token: 0x0400069F RID: 1695
	public EITEM Category;

	// Token: 0x040006A0 RID: 1696
	public EBonusCustomEffect Effect;

	// Token: 0x040006A1 RID: 1697
	public float Value;

	// Token: 0x040006A2 RID: 1698
	public ECharacter Character;

	// Token: 0x040006A3 RID: 1699
	public float MegaValue;

	// Token: 0x040006A4 RID: 1700
	public ERarity Rarity;

	// Token: 0x040006A5 RID: 1701
	public ECharacter Owner;

	// Token: 0x040006A6 RID: 1702
	public List<Template> Transforms = new List<Template>();

	// Token: 0x040006A7 RID: 1703
	public E_UnlockableItemSate State;

	// Token: 0x040006A8 RID: 1704
	public int NbSlots;
}

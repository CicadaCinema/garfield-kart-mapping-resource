﻿using System;
using UnityEngine;

// Token: 0x020001E0 RID: 480
public class ForecastedObstacle : Forecasted
{
	// Token: 0x06000CE8 RID: 3304 RVA: 0x0000AE23 File Offset: 0x00009023
	public ForecastedObstacle()
	{
	}

	// Token: 0x06000CE9 RID: 3305 RVA: 0x0000AE2B File Offset: 0x0000902B
	public ForecastedObstacle(MonoBehaviour pEntity) : base(pEntity)
	{
	}
}

﻿using System;
using UnityEngine;

// Token: 0x020001D7 RID: 471
public class DebugPathRecorder : MonoBehaviour
{
	// Token: 0x06000CB0 RID: 3248 RVA: 0x00054520 File Offset: 0x00052720
	public void OnDrawGizmos()
	{
		if (this.DebugDrawOn)
		{
			int childCount = base.transform.childCount;
			Material material = null;
			if (childCount > 0)
			{
				GameObject gameObject = base.transform.GetChild(0).gameObject;
				if (gameObject.GetComponent<MeshRenderer>().renderer.sharedMaterial != null)
				{
					material = new Material(gameObject.GetComponent<MeshRenderer>().renderer.sharedMaterial);
					material.color = this.Color;
				}
			}
			for (int i = 0; i < childCount; i++)
			{
				Vector3 position = base.transform.GetChild(i).position;
				GameObject gameObject2 = base.transform.GetChild(i).gameObject;
				gameObject2.GetComponent<MeshRenderer>().enabled = true;
				if (material != null)
				{
					gameObject2.GetComponent<MeshRenderer>().renderer.sharedMaterial = material;
				}
				if (i < childCount - 1)
				{
					Vector3 position2 = base.transform.GetChild(i + 1).position;
					Debug.DrawLine(position, position2, this.Color);
				}
			}
		}
		else
		{
			int childCount2 = base.transform.childCount;
			for (int j = 0; j < childCount2; j++)
			{
				GameObject gameObject3 = base.transform.GetChild(j).gameObject;
				gameObject3.GetComponent<MeshRenderer>().enabled = false;
			}
		}
	}

	// Token: 0x04000C52 RID: 3154
	public Color Color = Color.red;

	// Token: 0x04000C53 RID: 3155
	private Vector3 _previousPosition;

	// Token: 0x04000C54 RID: 3156
	public bool DebugDrawOn;
}

﻿using System;
using UnityEngine;

// Token: 0x0200005B RID: 91
[AddComponentMenu("NGUI/Tween/Color")]
public class TweenColor : UITweener
{
	// Token: 0x17000054 RID: 84
	// (get) Token: 0x06000260 RID: 608 RVA: 0x000183F4 File Offset: 0x000165F4
	// (set) Token: 0x06000261 RID: 609 RVA: 0x00018460 File Offset: 0x00016660
	public Color color
	{
		get
		{
			if (this.mWidget != null)
			{
				return this.mWidget.color;
			}
			if (this.mLight != null)
			{
				return this.mLight.color;
			}
			if (this.mMat != null)
			{
				return this.mMat.color;
			}
			return Color.black;
		}
		set
		{
			if (this.mWidget != null)
			{
				this.mWidget.color = value;
			}
			if (this.mMat != null)
			{
				this.mMat.color = value;
			}
			if (this.mLight != null)
			{
				this.mLight.color = value;
				this.mLight.enabled = (value.r + value.g + value.b > 0.01f);
			}
		}
	}

	// Token: 0x06000262 RID: 610 RVA: 0x000184F0 File Offset: 0x000166F0
	private void Awake()
	{
		this.mWidget = base.GetComponentInChildren<UIWidget>();
		Renderer renderer = base.renderer;
		if (renderer != null)
		{
			this.mMat = renderer.material;
		}
		this.mLight = base.light;
	}

	// Token: 0x06000263 RID: 611 RVA: 0x00003CA9 File Offset: 0x00001EA9
	protected override void OnUpdate(float factor, bool isFinished)
	{
		this.color = Color.Lerp(this.from, this.to, factor);
	}

	// Token: 0x06000264 RID: 612 RVA: 0x00018534 File Offset: 0x00016734
	public static TweenColor Begin(GameObject go, float duration, Color color)
	{
		TweenColor tweenColor = UITweener.Begin<TweenColor>(go, duration);
		tweenColor.from = tweenColor.color;
		tweenColor.to = color;
		if (duration <= 0f)
		{
			tweenColor.Sample(1f, true);
			tweenColor.enabled = false;
		}
		return tweenColor;
	}

	// Token: 0x040001E9 RID: 489
	public Color from = Color.white;

	// Token: 0x040001EA RID: 490
	public Color to = Color.white;

	// Token: 0x040001EB RID: 491
	private Transform mTrans;

	// Token: 0x040001EC RID: 492
	private UIWidget mWidget;

	// Token: 0x040001ED RID: 493
	private Material mMat;

	// Token: 0x040001EE RID: 494
	private Light mLight;
}

﻿using System;
using UnityEngine;

// Token: 0x0200005C RID: 92
[RequireComponent(typeof(Camera))]
[AddComponentMenu("NGUI/Tween/Field of View")]
public class TweenFOV : UITweener
{
	// Token: 0x17000055 RID: 85
	// (get) Token: 0x06000266 RID: 614 RVA: 0x00003CCB File Offset: 0x00001ECB
	public Camera cachedCamera
	{
		get
		{
			if (this.mCam == null)
			{
				this.mCam = base.camera;
			}
			return this.mCam;
		}
	}

	// Token: 0x17000056 RID: 86
	// (get) Token: 0x06000267 RID: 615 RVA: 0x00003CF0 File Offset: 0x00001EF0
	// (set) Token: 0x06000268 RID: 616 RVA: 0x00003CFD File Offset: 0x00001EFD
	public float fov
	{
		get
		{
			return this.cachedCamera.fieldOfView;
		}
		set
		{
			this.cachedCamera.fieldOfView = value;
		}
	}

	// Token: 0x06000269 RID: 617 RVA: 0x00003D0B File Offset: 0x00001F0B
	protected override void OnUpdate(float factor, bool isFinished)
	{
		this.cachedCamera.fieldOfView = this.from * (1f - factor) + this.to * factor;
	}

	// Token: 0x0600026A RID: 618 RVA: 0x0001857C File Offset: 0x0001677C
	public static TweenFOV Begin(GameObject go, float duration, float to)
	{
		TweenFOV tweenFOV = UITweener.Begin<TweenFOV>(go, duration);
		tweenFOV.from = tweenFOV.fov;
		tweenFOV.to = to;
		if (duration <= 0f)
		{
			tweenFOV.Sample(1f, true);
			tweenFOV.enabled = false;
		}
		return tweenFOV;
	}

	// Token: 0x040001EF RID: 495
	public float from;

	// Token: 0x040001F0 RID: 496
	public float to;

	// Token: 0x040001F1 RID: 497
	private Camera mCam;
}

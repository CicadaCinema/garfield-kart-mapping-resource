﻿using System;
using UnityEngine;

// Token: 0x02000207 RID: 519
public class RcVehicle : MonoBehaviour, RcCollisionListener
{
	// Token: 0x06000E13 RID: 3603 RVA: 0x0005AF70 File Offset: 0x00059170
	public RcVehicle()
	{
		this.m_fDriftMinSpeedKph = 10f;
		this.m_bArcadeDriftLock = false;
		this.m_fArcadeDriftFactor = 0f;
		this.m_vCameraOffset = Vector3.zero;
		this.m_bFearsVehicleCollisions = true;
		this.m_iPlayerNumber = -1;
		this.m_pVehicleCarac = null;
		this.m_pGearBox = null;
		this.m_pRaceStats = null;
		this.m_eControlType = RcVehicle.ControlType.AI;
		this.m_eDriftStyle = RcVehicle.DriftStyle.Handbrake;
		this.m_iVehicleId = 0;
		this.m_fFallStartTimeMs = 0f;
		this.m_ePrevState = RcVehicle.eVehicleState.STATE_COUNT;
		for (int i = 0; i < 6; i++)
		{
			this.m_vehicleState[i] = false;
		}
		this.m_vehicleState[1] = true;
		this.m_bRaceEnded = false;
		this.m_fSteeringFactor = 0f;
		this.m_bNoSteeringInput = false;
		this.m_qRespawnOrientation = Quaternion.identity;
		this.m_vRespawnPosition = Vector3.zero;
		this.m_iInvulnerableStartTimeMs = 0;
		this.m_fUsualHandicap = 0f;
		this.m_fTempHandicap = 0f;
		this.m_fMoveFactor = 0f;
		this.m_fWheelAccelMSS = 0f;
		this.m_fWheelSpeedMS = 0f;
		this.m_fSteeringAngleRad = 0f;
		this.m_pVehiclePhysic = null;
		this.m_vehicleState[2] = false;
		this.m_vPreviousPosition = Vector3.zero;
		this.m_fDriftFactor = 0f;
		this.m_iSecureTeleport = 0;
	}

	// Token: 0x170001DB RID: 475
	// (get) Token: 0x06000E14 RID: 3604 RVA: 0x0000BA93 File Offset: 0x00009C93
	// (set) Token: 0x06000E15 RID: 3605 RVA: 0x0000BA9B File Offset: 0x00009C9B
	public bool BArcadeDriftLock
	{
		get
		{
			return this.m_bArcadeDriftLock;
		}
		set
		{
			this.m_bArcadeDriftLock = value;
		}
	}

	// Token: 0x170001DC RID: 476
	// (get) Token: 0x06000E16 RID: 3606 RVA: 0x0000BAA4 File Offset: 0x00009CA4
	public AudioListener AudioListener
	{
		get
		{
			return this.m_pAudioListener;
		}
	}

	// Token: 0x06000E17 RID: 3607 RVA: 0x0000BAAC File Offset: 0x00009CAC
	public virtual void SetArcadeDriftFactor(float factor)
	{
		this.m_fArcadeDriftFactor = factor;
	}

	// Token: 0x06000E18 RID: 3608 RVA: 0x0000BAB5 File Offset: 0x00009CB5
	public void Turn(float _steering, bool _noInput)
	{
		this.m_fSteeringFactor = Mathf.Clamp(_steering, -1f, 1f);
		this.m_bNoSteeringInput = _noInput;
	}

	// Token: 0x06000E19 RID: 3609 RVA: 0x0000BAD4 File Offset: 0x00009CD4
	public bool IsLocked()
	{
		return this.m_vehicleState[0];
	}

	// Token: 0x06000E1A RID: 3610 RVA: 0x0000BADE File Offset: 0x00009CDE
	public bool IsAutoPilot()
	{
		return this.m_vehicleState[1];
	}

	// Token: 0x06000E1B RID: 3611 RVA: 0x0000BAE8 File Offset: 0x00009CE8
	public Vector3 GetLastFramePos()
	{
		return this.m_vPreviousPosition;
	}

	// Token: 0x06000E1C RID: 3612 RVA: 0x0000BAF0 File Offset: 0x00009CF0
	public float GetWheelSpeedMS()
	{
		return this.m_fWheelSpeedMS;
	}

	// Token: 0x06000E1D RID: 3613 RVA: 0x0000BAF8 File Offset: 0x00009CF8
	public float GetWheelAccelMSS()
	{
		return this.m_fWheelAccelMSS;
	}

	// Token: 0x06000E1E RID: 3614 RVA: 0x0000BB00 File Offset: 0x00009D00
	public float GetSpeedKPH()
	{
		return 3.6f * this.m_fWheelSpeedMS;
	}

	// Token: 0x06000E1F RID: 3615 RVA: 0x0000BB0E File Offset: 0x00009D0E
	public float GetMotorSpeedMS()
	{
		return this.GetWheelSpeedMS();
	}

	// Token: 0x06000E20 RID: 3616 RVA: 0x0000BB16 File Offset: 0x00009D16
	public float GetTempHandicap()
	{
		return this.m_fTempHandicap;
	}

	// Token: 0x06000E21 RID: 3617 RVA: 0x0000BB1E File Offset: 0x00009D1E
	public float GetHandicap()
	{
		return Mathf.Min(0.99f, this.m_fUsualHandicap + this.m_fTempHandicap);
	}

	// Token: 0x06000E22 RID: 3618 RVA: 0x0000BB37 File Offset: 0x00009D37
	public float GetSteeringFactor()
	{
		return this.m_fSteeringFactor;
	}

	// Token: 0x06000E23 RID: 3619 RVA: 0x0000BB3F File Offset: 0x00009D3F
	public float GetSteeringAngle()
	{
		return this.m_fSteeringAngleRad;
	}

	// Token: 0x06000E24 RID: 3620 RVA: 0x0000BB47 File Offset: 0x00009D47
	public float GetMoveFactor()
	{
		return this.m_fMoveFactor;
	}

	// Token: 0x06000E25 RID: 3621 RVA: 0x0000BB4F File Offset: 0x00009D4F
	public int GetVehicleId()
	{
		return this.m_iVehicleId;
	}

	// Token: 0x06000E26 RID: 3622 RVA: 0x0000BB57 File Offset: 0x00009D57
	public float GetArcadeDriftFactor()
	{
		return this.m_fArcadeDriftFactor;
	}

	// Token: 0x06000E27 RID: 3623 RVA: 0x0000BB5F File Offset: 0x00009D5F
	public bool IsRaceEnded()
	{
		return this.m_bRaceEnded;
	}

	// Token: 0x06000E28 RID: 3624 RVA: 0x0000BB67 File Offset: 0x00009D67
	public float GetUsualHandicap()
	{
		return this.m_fUsualHandicap;
	}

	// Token: 0x06000E29 RID: 3625 RVA: 0x0000BB6F File Offset: 0x00009D6F
	public Vector3 GetRespawnPos()
	{
		return this.m_vRespawnPosition;
	}

	// Token: 0x06000E2A RID: 3626 RVA: 0x0000BB77 File Offset: 0x00009D77
	public RcVehiclePhysic GetVehiclePhysic()
	{
		return this.m_pVehiclePhysic;
	}

	// Token: 0x06000E2B RID: 3627 RVA: 0x0000BB7F File Offset: 0x00009D7F
	public Vector3 GetPosition()
	{
		return this.m_pTransform.position;
	}

	// Token: 0x06000E2C RID: 3628 RVA: 0x0000BB8C File Offset: 0x00009D8C
	public float GetDrift()
	{
		return this.m_fDriftFactor;
	}

	// Token: 0x06000E2D RID: 3629 RVA: 0x0000BB94 File Offset: 0x00009D94
	public bool IsFearingVehicleCollisions()
	{
		return this.m_bFearsVehicleCollisions;
	}

	// Token: 0x06000E2E RID: 3630 RVA: 0x0000BB9C File Offset: 0x00009D9C
	public Vector3 GetCameraOffset()
	{
		return this.m_vCameraOffset;
	}

	// Token: 0x06000E2F RID: 3631 RVA: 0x0000BBA4 File Offset: 0x00009DA4
	public int GetPlayerNumber()
	{
		return this.m_iPlayerNumber;
	}

	// Token: 0x06000E30 RID: 3632 RVA: 0x00003B7D File Offset: 0x00001D7D
	public virtual bool IsBoosting()
	{
		return false;
	}

	// Token: 0x06000E31 RID: 3633 RVA: 0x0000BBAC File Offset: 0x00009DAC
	public virtual float GetSkidMarksDetail()
	{
		return 1f;
	}

	// Token: 0x06000E32 RID: 3634 RVA: 0x0000BBB3 File Offset: 0x00009DB3
	public RcVehicle.ControlType GetControlType()
	{
		return this.m_eControlType;
	}

	// Token: 0x06000E33 RID: 3635 RVA: 0x0000BBBB File Offset: 0x00009DBB
	public RcVehicle.DriftStyle GetDriftStyle()
	{
		return this.m_eDriftStyle;
	}

	// Token: 0x06000E34 RID: 3636 RVA: 0x0000BBC3 File Offset: 0x00009DC3
	public RcVehicleCarac GetCarac()
	{
		return this.m_pVehicleCarac;
	}

	// Token: 0x06000E35 RID: 3637 RVA: 0x0000BBCB File Offset: 0x00009DCB
	public RcGearBox GetGearBox()
	{
		return this.m_pGearBox;
	}

	// Token: 0x06000E36 RID: 3638 RVA: 0x0000BBD3 File Offset: 0x00009DD3
	public void SetLocked(bool _locked)
	{
		this.m_vehicleState[0] = _locked;
	}

	// Token: 0x06000E37 RID: 3639 RVA: 0x0000BBDE File Offset: 0x00009DDE
	public void SetTeleport(bool _bTeleport)
	{
		this.m_vehicleState[2] = _bTeleport;
		if (!_bTeleport)
		{
			this.m_iSecureTeleport = 0;
		}
	}

	// Token: 0x06000E38 RID: 3640 RVA: 0x0000BBF6 File Offset: 0x00009DF6
	public void SetRespawnOrientation(Quaternion _orient)
	{
		this.m_qRespawnOrientation = _orient;
	}

	// Token: 0x06000E39 RID: 3641 RVA: 0x0000BBFF File Offset: 0x00009DFF
	public void SetRespawnPos(Vector3 pos)
	{
		this.m_vRespawnPosition = pos;
	}

	// Token: 0x06000E3A RID: 3642 RVA: 0x0000BC08 File Offset: 0x00009E08
	public void SetUsualHandicap(float _handicap)
	{
		this.m_fUsualHandicap = _handicap;
	}

	// Token: 0x06000E3B RID: 3643 RVA: 0x0000BC11 File Offset: 0x00009E11
	public void SetTempHandicap(float _handicap)
	{
		this.m_fTempHandicap = _handicap;
	}

	// Token: 0x06000E3C RID: 3644 RVA: 0x0000BC1A File Offset: 0x00009E1A
	public void SetWheelSpeedMS(float _speed)
	{
		this.m_fWheelSpeedMS = _speed;
	}

	// Token: 0x06000E3D RID: 3645 RVA: 0x0000BC23 File Offset: 0x00009E23
	public void SetWheelAccelMSS(float _accel)
	{
		this.m_fWheelAccelMSS = _accel;
	}

	// Token: 0x06000E3E RID: 3646 RVA: 0x0000BC2C File Offset: 0x00009E2C
	public void SetVehicleId(int _Num)
	{
		this.m_iVehicleId = _Num;
	}

	// Token: 0x06000E3F RID: 3647 RVA: 0x0000BC35 File Offset: 0x00009E35
	public void SetFearsVehicleCollisions(bool fears)
	{
		this.m_bFearsVehicleCollisions = fears;
	}

	// Token: 0x06000E40 RID: 3648 RVA: 0x0000BC3E File Offset: 0x00009E3E
	public void SetDriftStyle(RcVehicle.DriftStyle eStyle)
	{
		this.m_eDriftStyle = eStyle;
	}

	// Token: 0x170001DD RID: 477
	// (get) Token: 0x06000E41 RID: 3649 RVA: 0x0000BC47 File Offset: 0x00009E47
	// (set) Token: 0x06000E42 RID: 3650 RVA: 0x0000BC4F File Offset: 0x00009E4F
	public RcVehicleRaceStats RaceStats
	{
		get
		{
			return this.m_pRaceStats;
		}
		set
		{
			this.m_pRaceStats = value;
		}
	}

	// Token: 0x06000E43 RID: 3651 RVA: 0x0005B0D8 File Offset: 0x000592D8
	public virtual void Awake()
	{
		this.m_pVehicleCarac = base.transform.parent.GetComponentInChildren<RcVehicleCarac>();
		this.m_pGearBox = base.transform.parent.GetComponentInChildren<RcGearBox>();
		this.m_pVehiclePhysic = base.transform.parent.GetComponentInChildren<RcVehiclePhysic>();
		this.m_pAudioListener = base.transform.parent.GetComponentInChildren<AudioListener>();
		if (this.m_pVehiclePhysic)
		{
			this.m_pVehiclePhysic.AddCollisionListener(this);
		}
		this.m_pTransform = base.transform;
	}

	// Token: 0x06000E44 RID: 3652 RVA: 0x0005B168 File Offset: 0x00059368
	public virtual void Start()
	{
		this.RegisterInputs();
		this.SetState(RcVehicle.eVehicleState.S_IS_RUNNING, true);
		this.m_vPreviousPosition = this.m_pTransform.position;
		int deathMaskValue = ((RcKinematicPhysic)this.m_pVehiclePhysic).DeathMaskValue;
		this.m_IgnoreCollision = (LayerMask.NameToLayer("Everything") & ~LayerMask.NameToLayer("Vehicle") & ~deathMaskValue);
	}

	// Token: 0x06000E45 RID: 3653 RVA: 0x0000BC58 File Offset: 0x00009E58
	public void OnDestroy()
	{
		if (this.m_pVehiclePhysic)
		{
			this.m_pVehiclePhysic.RemoveCollisionListener(this);
		}
	}

	// Token: 0x06000E46 RID: 3654 RVA: 0x0005B1CC File Offset: 0x000593CC
	public virtual void Update()
	{
		if (!this.m_vehicleState[5])
		{
			float deltaTime = Time.deltaTime;
			if (deltaTime <= 0f)
			{
				return;
			}
			if (this.m_vehicleState[4])
			{
				this.ManageRunState();
			}
			if (this.m_vehicleState[3])
			{
				this.ManageFallState();
			}
			this.m_vPreviousPosition = this.m_pTransform.position;
			if (this.GetState(RcVehicle.eVehicleState.S_IS_TELEPORTING))
			{
				this.m_iSecureTeleport++;
				if (this.m_iSecureTeleport > 2)
				{
					this.m_vehicleState[2] = false;
					this.m_iSecureTeleport = 0;
				}
			}
		}
	}

	// Token: 0x06000E47 RID: 3655 RVA: 0x0000BC76 File Offset: 0x00009E76
	public void Disable()
	{
		if (this.m_pVehiclePhysic)
		{
			this.m_pVehiclePhysic.Enable = false;
		}
		this.SetState(RcVehicle.eVehicleState.S_IS_DISABLED, true);
	}

	// Token: 0x06000E48 RID: 3656 RVA: 0x0000BC9C File Offset: 0x00009E9C
	public void Enable()
	{
		if (this.m_pVehiclePhysic)
		{
			this.m_pVehiclePhysic.Enable = true;
		}
		this.SetState(RcVehicle.eVehicleState.S_IS_DISABLED, false);
	}

	// Token: 0x06000E49 RID: 3657 RVA: 0x0005B268 File Offset: 0x00059468
	public void InitPosition()
	{
		Vector3 position = new Vector3(0f, 0f, 1000f);
		Quaternion teleportOrientation = Quaternion.identity;
		position = this.m_pTransform.position;
		teleportOrientation = this.m_pTransform.rotation;
		position.y += 2f;
		this.m_pTransform.position = position;
		this.Teleport(position, teleportOrientation);
		this.m_vPreviousPosition = position;
	}

	// Token: 0x06000E4A RID: 3658 RVA: 0x0005B2D8 File Offset: 0x000594D8
	public void Reset()
	{
		if (this.m_pVehiclePhysic != null)
		{
			this.m_pVehiclePhysic.Reset();
		}
		this.m_fFallStartTimeMs = 0f;
		this.m_ePrevState = RcVehicle.eVehicleState.STATE_COUNT;
		for (int i = 0; i < 1; i++)
		{
			this.m_vehicleState[i] = false;
		}
		for (int j = 2; j < 6; j++)
		{
			this.m_vehicleState[j] = false;
		}
		this.m_bRaceEnded = false;
		this.m_fSteeringFactor = 0f;
		this.m_bNoSteeringInput = false;
		this.m_fWheelSpeedMS = 0f;
		this.m_fWheelAccelMSS = 0f;
		this.m_fSteeringAngleRad = 0f;
		this.m_qRespawnOrientation = Quaternion.identity;
		this.m_vRespawnPosition = Vector3.zero;
	}

	// Token: 0x06000E4B RID: 3659 RVA: 0x0000BCC2 File Offset: 0x00009EC2
	public virtual float GetMaxSpeed()
	{
		return this.m_pGearBox.GetMaxSpeed();
	}

	// Token: 0x06000E4C RID: 3660 RVA: 0x0005B39C File Offset: 0x0005959C
	public virtual void ComputeWheelSpeed()
	{
		if (this.m_vehicleState[0])
		{
			this.m_fWheelSpeedMS = 0f;
		}
		else
		{
			float deltaTime = Time.deltaTime;
			bool flag = this.m_pVehiclePhysic.IsGoingTooFast() || this.m_pGearBox.IsGoingTooFast();
			float num = this.GetMaxSpeed();
			VehicleHandling vehicleHandling;
			this.m_pVehicleCarac.ComputeHandling(Mathf.Abs(this.m_fWheelSpeedMS * (1f - this.GetHandicap())), out vehicleHandling);
			if (this.m_fArcadeDriftFactor == 0f)
			{
				num = RcUtils.LinearInterpolation(0f, num, 1f, num * (1f - vehicleHandling.steeringTopSpeedMalus), Mathf.Abs(this.m_fSteeringFactor), true);
			}
			float num2 = (!this.m_pVehiclePhysic.IsGoingTooFast()) ? vehicleHandling.brakingMSS : vehicleHandling.toofastBrakingMSS;
			if (flag)
			{
				if (this.m_fWheelSpeedMS >= 0f)
				{
					this.m_fWheelSpeedMS -= num2 * deltaTime;
				}
				else
				{
					this.m_fWheelSpeedMS += num2 * deltaTime;
				}
			}
			else if (this.m_fMoveFactor > 0f)
			{
				if (this.m_fWheelSpeedMS >= 0f)
				{
					if (this.m_fWheelSpeedMS < num)
					{
						this.m_fWheelSpeedMS += this.m_pGearBox.ComputeAcceleration(Mathf.Abs(this.m_fWheelSpeedMS)) * deltaTime * this.m_fMoveFactor;
					}
				}
				else
				{
					this.m_fWheelSpeedMS += num2 * deltaTime * this.m_fMoveFactor;
				}
			}
			else if (this.m_fMoveFactor < 0f)
			{
				if (this.m_fWheelSpeedMS >= 0f)
				{
					this.m_fWheelSpeedMS += num2 * deltaTime * this.m_fMoveFactor;
				}
				else
				{
					this.m_fWheelSpeedMS += this.m_pGearBox.ComputeAcceleration(Mathf.Abs(this.m_fWheelSpeedMS)) * deltaTime * this.m_fMoveFactor;
				}
			}
			else if (this.m_fWheelSpeedMS >= 0f)
			{
				this.m_fWheelSpeedMS -= vehicleHandling.decelerationMSS * deltaTime;
				if (this.m_fWheelSpeedMS < 0f)
				{
					this.m_fWheelSpeedMS = 0f;
				}
			}
			else
			{
				this.m_fWheelSpeedMS += vehicleHandling.decelerationMSS * deltaTime;
				if (this.m_fWheelSpeedMS > 0f)
				{
					this.m_fWheelSpeedMS = 0f;
				}
			}
			if (this.m_fWheelSpeedMS > num)
			{
				this.m_fWheelSpeedMS -= 5f * vehicleHandling.decelerationMSS * deltaTime;
				if (this.m_fWheelSpeedMS < num)
				{
					this.m_fWheelSpeedMS = num;
				}
			}
			else if (this.m_fWheelSpeedMS < this.GetMinSpeed())
			{
				this.m_fWheelSpeedMS = this.GetMinSpeed();
			}
		}
	}

	// Token: 0x06000E4D RID: 3661 RVA: 0x0000BCCF File Offset: 0x00009ECF
	public float SteeringRadiusToAngle(float _radius)
	{
		return Mathf.Atan(this.m_pVehiclePhysic.GetFrontToRearWheelLength() / _radius);
	}

	// Token: 0x06000E4E RID: 3662 RVA: 0x0005B678 File Offset: 0x00059878
	public void ComputeArcadeDriftSteeringAngle()
	{
		VehicleHandling vehicleHandling;
		this.m_pVehicleCarac.ComputeHandling(Mathf.Abs(this.m_fWheelSpeedMS * (1f - this.GetHandicap())), out vehicleHandling);
		float driftTurningRadius = vehicleHandling.driftTurningRadius;
		float num = this.SteeringRadiusToAngle(driftTurningRadius);
		float y = this.SteeringRadiusToAngle(vehicleHandling.counterSteeringTurningRadius);
		float y2 = this.SteeringRadiusToAngle(vehicleHandling.driftNoInputTurningRadius);
		float num2 = 0f;
		if (this.IsOnGround())
		{
			if (-this.m_fSteeringFactor * this.m_fArcadeDriftFactor > 0f)
			{
				num2 = RcUtils.LinearInterpolation(0f, y2, 1f, num, Mathf.Abs(this.m_fSteeringFactor), true);
			}
			else
			{
				num2 = RcUtils.LinearInterpolation(0f, y2, 1f, y, Mathf.Abs(this.m_fSteeringFactor), true);
			}
			if (this.m_fArcadeDriftFactor > 0f)
			{
				num2 = -num2;
			}
		}
		float num3;
		if (this.m_bNoSteeringInput)
		{
			num3 = num / vehicleHandling.driftResetSteeringNoInput;
		}
		else if (this.m_fSteeringAngleRad * num2 < 0f)
		{
			if (vehicleHandling.resetSteeringOppositeInput == 0f)
			{
				num3 = 1000f;
			}
			else
			{
				num3 = num / vehicleHandling.resetSteeringOppositeInput;
			}
		}
		else
		{
			num3 = num / vehicleHandling.driftTimeToMaxSteering;
		}
		float num4 = num2 - this.m_fSteeringAngleRad;
		if (num4 > 0f)
		{
			this.m_fSteeringAngleRad += num3 * Time.deltaTime;
			if (this.m_fSteeringAngleRad > num2)
			{
				this.m_fSteeringAngleRad = num2;
			}
		}
		else if (num4 < 0f)
		{
			this.m_fSteeringAngleRad -= num3 * Time.deltaTime;
			if (this.m_fSteeringAngleRad < num2)
			{
				this.m_fSteeringAngleRad = num2;
			}
		}
	}

	// Token: 0x06000E4F RID: 3663 RVA: 0x0005B840 File Offset: 0x00059A40
	public void ComputeSteeringAngle()
	{
		if (this.m_vehicleState[0])
		{
			this.m_fSteeringAngleRad = 0f;
		}
		else if (this.m_fArcadeDriftFactor != 0f)
		{
			this.ComputeArcadeDriftSteeringAngle();
		}
		else
		{
			float deltaTime = Time.deltaTime;
			VehicleHandling vehicleHandling;
			this.m_pVehicleCarac.ComputeHandling(Mathf.Abs(this.m_fWheelSpeedMS * (1f - this.GetHandicap())), out vehicleHandling);
			float minTurningRadius = vehicleHandling.minTurningRadius;
			float num = this.SteeringRadiusToAngle(minTurningRadius);
			Vector3 linearVelocity = this.m_pVehiclePhysic.GetLinearVelocity();
			Vector3 rhs = this.m_pTransform.rotation * Vector3.forward;
			Vector3 vector = this.m_pTransform.rotation * Vector3.up;
			float d = Vector3.Dot(vector, linearVelocity);
			Vector3 lhs = linearVelocity - d * vector;
			float driftRatio = this.GetDriftRatio();
			if (Mathf.Abs(driftRatio) > 0f && driftRatio * this.m_fSteeringFactor > 0f)
			{
				lhs.Normalize();
				float num2 = Vector3.Dot(lhs, rhs);
				num2 = Mathf.Clamp(num2, -1f, 1f);
				float num3 = Mathf.Acos(num2);
				num3 = Mathf.Clamp(num3, 0f, 0.7853982f);
				if (num3 > num)
				{
					num = num3;
				}
			}
			float num4 = 0f;
			if (this.IsOnGround())
			{
				num4 = this.m_fSteeringFactor * num;
			}
			float num5;
			if (this.m_bNoSteeringInput)
			{
				num5 = num / vehicleHandling.resetSteeringNoInput;
			}
			else if (this.m_fSteeringAngleRad * num4 < 0f)
			{
				if (vehicleHandling.resetSteeringOppositeInput == 0f)
				{
					num5 = 1000f;
				}
				else
				{
					num5 = num / vehicleHandling.resetSteeringOppositeInput;
				}
			}
			else
			{
				num5 = num / vehicleHandling.timeToMaxSteering;
			}
			float num6 = num4 - this.m_fSteeringAngleRad;
			if (num6 > 0f)
			{
				this.m_fSteeringAngleRad += num5 * deltaTime;
				if (this.m_fSteeringAngleRad > num4)
				{
					this.m_fSteeringAngleRad = num4;
				}
			}
			else if (num6 < 0f)
			{
				this.m_fSteeringAngleRad -= num5 * deltaTime;
				if (this.m_fSteeringAngleRad < num4)
				{
					this.m_fSteeringAngleRad = num4;
				}
			}
		}
	}

	// Token: 0x06000E50 RID: 3664 RVA: 0x0005BA90 File Offset: 0x00059C90
	public virtual void Respawn()
	{
		if (this.OnRespawn != null)
		{
			this.OnRespawn();
		}
		int vehicleId = this.GetVehicleId();
		int num = vehicleId % 3;
		int num2 = vehicleId / 3;
		if (num == 2)
		{
			num = -1;
		}
		Vector3 b = this.m_qRespawnOrientation * Vector3.up * 2f;
		Vector3 b2 = this.m_qRespawnOrientation * Vector3.left * ((float)num * 1.5f);
		Vector3 b3 = this.m_qRespawnOrientation * Vector3.forward * -2f * (float)num2;
		Vector3 vector = this.m_vRespawnPosition + b2 + b + b3;
		Quaternion quaternion = this.m_qRespawnOrientation;
		if (this.m_qRespawnOrientation == Quaternion.identity)
		{
			quaternion = this.m_pTransform.rotation;
		}
		this.Teleport(vector, quaternion);
		this.m_vPreviousPosition = vector;
		this.m_fWheelAccelMSS = 0f;
		this.m_fWheelSpeedMS = 0f;
		if (this.m_eControlType == RcVehicle.ControlType.Human)
		{
			Camera.main.GetComponent<CamStateRespawn>().Setup(vector, quaternion);
			Camera.main.GetComponent<CameraBase>().SwitchCamera(ECamState.Respawn, ECamState.TransCut);
		}
	}

	// Token: 0x06000E51 RID: 3665 RVA: 0x0000BCE3 File Offset: 0x00009EE3
	public void Accelerate()
	{
		this.Accelerate(1f);
	}

	// Token: 0x06000E52 RID: 3666 RVA: 0x0000BCF0 File Offset: 0x00009EF0
	public void Accelerate(float _accelerationPrc)
	{
		this.m_fMoveFactor = _accelerationPrc;
	}

	// Token: 0x06000E53 RID: 3667 RVA: 0x0000BCF9 File Offset: 0x00009EF9
	public void Decelerate()
	{
		this.m_fMoveFactor = 0f;
	}

	// Token: 0x06000E54 RID: 3668 RVA: 0x0000BD06 File Offset: 0x00009F06
	public void Brake()
	{
		this.Brake(1f);
	}

	// Token: 0x06000E55 RID: 3669 RVA: 0x0000BD13 File Offset: 0x00009F13
	public void Brake(float _brakingPrc)
	{
		this.m_fMoveFactor = -_brakingPrc;
	}

	// Token: 0x06000E56 RID: 3670 RVA: 0x0000BD1D File Offset: 0x00009F1D
	public void ForceRespawn()
	{
		if (this.GetState(RcVehicle.eVehicleState.S_IS_FALLING) || this.GetState(RcVehicle.eVehicleState.S_IS_LOCKED))
		{
			return;
		}
		this.m_ePrevState = RcVehicle.eVehicleState.S_IS_FALLING;
		this.SetState(RcVehicle.eVehicleState.S_IS_RUNNING, true);
	}

	// Token: 0x06000E57 RID: 3671 RVA: 0x0000BD47 File Offset: 0x00009F47
	public void Teleport(Vector3 _TeleportPos, Quaternion _TeleportOrientation)
	{
		this.Teleport(_TeleportPos, _TeleportOrientation, Vector3.zero);
	}

	// Token: 0x06000E58 RID: 3672 RVA: 0x0005BBC8 File Offset: 0x00059DC8
	public void Teleport(Vector3 _TeleportPos, Quaternion _TeleportOrientation, Vector3 linearVelocity)
	{
		this.SetTeleport(true);
		this.m_fSteeringAngleRad = 0f;
		if (this.m_pVehiclePhysic)
		{
			this.m_pVehiclePhysic.Teleport(_TeleportPos, _TeleportOrientation, linearVelocity);
		}
		if (this.OnTeleported != null)
		{
			this.OnTeleported();
		}
	}

	// Token: 0x06000E59 RID: 3673 RVA: 0x0000BD56 File Offset: 0x00009F56
	public void SetAutoPilot(bool _bIsAutoPilot)
	{
		this.m_vehicleState[1] = _bIsAutoPilot;
		if (this.OnAutoPilotChanged != null)
		{
			this.OnAutoPilotChanged();
		}
	}

	// Token: 0x06000E5A RID: 3674 RVA: 0x0005BC1C File Offset: 0x00059E1C
	public void SetState(RcVehicle.eVehicleState _State, bool _Active)
	{
		this.m_vehicleState[(int)_State] = _Active;
		if (this.OnStateChanged != null)
		{
			this.OnStateChanged();
		}
		switch (_State)
		{
		case RcVehicle.eVehicleState.S_IS_FALLING:
			if (_Active)
			{
				this.OnStartFallState();
				if (this.m_ePrevState < RcVehicle.eVehicleState.STATE_COUNT)
				{
					this.SetState(this.m_ePrevState, false);
				}
				this.m_ePrevState = _State;
			}
			else
			{
				this.OnEndFallState();
			}
			break;
		case RcVehicle.eVehicleState.S_IS_RUNNING:
			if (_Active)
			{
				this.OnStartRunState();
				if (this.m_ePrevState < RcVehicle.eVehicleState.STATE_COUNT)
				{
					this.SetState(this.m_ePrevState, false);
				}
				this.m_ePrevState = _State;
			}
			else
			{
				this.OnEndRunState();
			}
			break;
		}
	}

	// Token: 0x06000E5B RID: 3675 RVA: 0x0000BD77 File Offset: 0x00009F77
	public bool GetState(RcVehicle.eVehicleState _State)
	{
		return this.m_vehicleState[(int)_State];
	}

	// Token: 0x06000E5C RID: 3676 RVA: 0x0000BD81 File Offset: 0x00009F81
	public void OnStartFallState()
	{
		this.m_fFallStartTimeMs = this.m_fRespawnDelay;
	}

	// Token: 0x06000E5D RID: 3677 RVA: 0x0000BD8F File Offset: 0x00009F8F
	public bool IsFallFinished()
	{
		return this.m_fFallStartTimeMs == 0f;
	}

	// Token: 0x06000E5E RID: 3678 RVA: 0x0005BCE8 File Offset: 0x00059EE8
	public void ManageFallState()
	{
		this.m_fFallStartTimeMs -= Time.deltaTime;
		this.m_fFallStartTimeMs = Mathf.Clamp(this.m_fFallStartTimeMs, 0f, this.m_fRespawnDelay);
		if (this.IsFallFinished())
		{
			this.EndOfRespawn();
		}
	}

	// Token: 0x06000E5F RID: 3679 RVA: 0x0000BD9E File Offset: 0x00009F9E
	public void EndOfRespawn()
	{
		this.SetState(RcVehicle.eVehicleState.S_IS_RUNNING, true);
		if (this.m_pVehiclePhysic)
		{
			this.m_pVehiclePhysic.ResetTouchedDeath();
		}
	}

	// Token: 0x06000E60 RID: 3680 RVA: 0x0000BDC3 File Offset: 0x00009FC3
	public void OnEndFallState()
	{
		this.m_fFallStartTimeMs = 0f;
		this.Respawn();
	}

	// Token: 0x06000E61 RID: 3681 RVA: 0x00003B80 File Offset: 0x00001D80
	public void OnStartRunState()
	{
	}

	// Token: 0x06000E62 RID: 3682 RVA: 0x0005BD34 File Offset: 0x00059F34
	public virtual void ManageRunState()
	{
		float num = Time.deltaTime * 1000f;
		float num2 = num * 0.001f;
		float fWheelSpeedMS = this.m_fWheelSpeedMS;
		this.ComputeWheelSpeed();
		this.m_fWheelAccelMSS = (this.m_fWheelSpeedMS - fWheelSpeedMS) / num2;
		this.ComputeSteeringAngle();
	}

	// Token: 0x06000E63 RID: 3683 RVA: 0x00003B80 File Offset: 0x00001D80
	public void OnEndRunState()
	{
	}

	// Token: 0x06000E64 RID: 3684 RVA: 0x0000BDD6 File Offset: 0x00009FD6
	public int GetGroundSurface()
	{
		return this.m_pVehiclePhysic.GetGroundSurface();
	}

	// Token: 0x06000E65 RID: 3685 RVA: 0x0000BDE3 File Offset: 0x00009FE3
	public Vector3 ForecastPosition(float dtSec)
	{
		if (this.m_pVehiclePhysic)
		{
			return this.m_pVehiclePhysic.ForecastPosition(dtSec);
		}
		return this.m_pTransform.position;
	}

	// Token: 0x06000E66 RID: 3686 RVA: 0x0005BD78 File Offset: 0x00059F78
	public float GetRealSpeedMs()
	{
		return (!(this.m_pVehiclePhysic != null)) ? 0f : this.m_pVehiclePhysic.GetLinearVelocity().magnitude;
	}

	// Token: 0x06000E67 RID: 3687 RVA: 0x0000BE0D File Offset: 0x0000A00D
	public float GetMinSpeed()
	{
		return this.m_pGearBox.GetBackwardMaxSpeed();
	}

	// Token: 0x06000E68 RID: 3688 RVA: 0x0005BDB4 File Offset: 0x00059FB4
	public Vector3 GetCameraTargetPoint()
	{
		Vector3 a = Vector3.zero;
		int nbWheels = this.m_pVehiclePhysic.GetNbWheels();
		RcPhysicWheel[] wheels = this.m_pVehiclePhysic.GetWheels();
		for (int i = 0; i < nbWheels; i++)
		{
			a += wheels[i].GetWorldPos();
		}
		return a / (float)nbWheels;
	}

	// Token: 0x06000E69 RID: 3689 RVA: 0x0000BE1A File Offset: 0x0000A01A
	public int GetNbWheels()
	{
		if (this.m_pVehiclePhysic)
		{
			return this.m_pVehiclePhysic.GetNbWheels();
		}
		return 0;
	}

	// Token: 0x06000E6A RID: 3690 RVA: 0x0005BE0C File Offset: 0x0005A00C
	public GroundCharac GetGroundCharac(int _wheelIndex)
	{
		RcPhysicWheel[] wheels = this.m_pVehiclePhysic.GetWheels();
		return wheels[_wheelIndex].OGroundCharac;
	}

	// Token: 0x06000E6B RID: 3691 RVA: 0x0005BE30 File Offset: 0x0005A030
	public bool IsOnGround(int _wheelIndex)
	{
		RcPhysicWheel[] wheels = this.m_pVehiclePhysic.GetWheels();
		return wheels[_wheelIndex].BOnGround;
	}

	// Token: 0x06000E6C RID: 3692 RVA: 0x0005BE54 File Offset: 0x0005A054
	public bool IsLeftWheel(int _wheelIndex)
	{
		RcPhysicWheel[] wheels = this.m_pVehiclePhysic.GetWheels();
		return wheels[_wheelIndex].ESide == RcPhysicWheel.WheelSide.Left;
	}

	// Token: 0x06000E6D RID: 3693 RVA: 0x0005BE78 File Offset: 0x0005A078
	public bool IsOnGround()
	{
		for (int i = 0; i < this.GetNbWheels(); i++)
		{
			if (this.IsOnGround(i))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000E6E RID: 3694 RVA: 0x0000BE39 File Offset: 0x0000A039
	public Vector3 GetCameraAt()
	{
		return this.GetVehiclePhysic().GetVehicleBodyTransform().rotation * Vector3.forward;
	}

	// Token: 0x06000E6F RID: 3695 RVA: 0x0000BE55 File Offset: 0x0000A055
	public Vector3 GetCameraUp()
	{
		return this.GetVehiclePhysic().GetVehicleBodyTransform().rotation * Vector3.up;
	}

	// Token: 0x06000E70 RID: 3696 RVA: 0x0000BE71 File Offset: 0x0000A071
	public float GetDriftRatio()
	{
		if (this.m_pVehiclePhysic && this.IsOnGround())
		{
			return this.m_pVehiclePhysic.GetDriftRatio();
		}
		return 0f;
	}

	// Token: 0x06000E71 RID: 3697 RVA: 0x0000BE9F File Offset: 0x0000A09F
	public void SetDrift(float _brake)
	{
		this.m_fDriftFactor = _brake;
	}

	// Token: 0x06000E72 RID: 3698 RVA: 0x0000BEA8 File Offset: 0x0000A0A8
	public void AddCollisionListener(RcCollisionListener pListener)
	{
		if (this.GetVehiclePhysic())
		{
			this.GetVehiclePhysic().AddCollisionListener(pListener);
		}
	}

	// Token: 0x06000E73 RID: 3699 RVA: 0x0000BEC6 File Offset: 0x0000A0C6
	public void RemoveCollisionListener(RcCollisionListener pListener)
	{
		if (this.GetVehiclePhysic())
		{
			this.GetVehiclePhysic().RemoveCollisionListener(pListener);
		}
	}

	// Token: 0x06000E74 RID: 3700 RVA: 0x00003B80 File Offset: 0x00001D80
	public void RegisterInputs()
	{
	}

	// Token: 0x06000E75 RID: 3701 RVA: 0x0000BEE4 File Offset: 0x0000A0E4
	public Quaternion GetOrientation()
	{
		return this.m_pTransform.rotation;
	}

	// Token: 0x06000E76 RID: 3702 RVA: 0x0005BEAC File Offset: 0x0005A0AC
	public void SetControlType(RcVehicle.ControlType eType)
	{
		if (this.m_eControlType != eType)
		{
			if (eType == RcVehicle.ControlType.Human)
			{
				this.SetAutoPilot(false);
			}
			this.m_eControlType = eType;
		}
		if (this.m_pAudioListener)
		{
			this.m_pAudioListener.enabled = (this.m_eControlType == RcVehicle.ControlType.Human);
		}
	}

	// Token: 0x06000E77 RID: 3703 RVA: 0x0000BEF1 File Offset: 0x0000A0F1
	public float GetTimeToStop()
	{
		if (this.m_pVehicleCarac)
		{
			return this.m_pVehicleCarac.GetTimeToStop(this.GetWheelSpeedMS());
		}
		return 0f;
	}

	// Token: 0x06000E78 RID: 3704 RVA: 0x0000BF1A File Offset: 0x0000A11A
	public void SetRaceEnded(bool _raceEnded)
	{
		this.m_bRaceEnded = _raceEnded;
	}

	// Token: 0x06000E79 RID: 3705 RVA: 0x0000BF23 File Offset: 0x0000A123
	public void Kill(float respawnDelay)
	{
		this.m_fRespawnDelay = respawnDelay;
		this.SetState(RcVehicle.eVehicleState.S_IS_FALLING, true);
		if (this.OnKilled != null)
		{
			this.OnKilled();
		}
	}

	// Token: 0x06000E7A RID: 3706 RVA: 0x0000BF4A File Offset: 0x0000A14A
	public void Kill()
	{
		this.Kill(1.5f);
	}

	// Token: 0x06000E7B RID: 3707 RVA: 0x0000BF57 File Offset: 0x0000A157
	public void OnCollision(CollisionData collisionInfo)
	{
		if (collisionInfo.other == null || collisionInfo.other.GetComponent<RcVehicle>() != null)
		{
			this.m_bArcadeDriftLock = true;
		}
	}

	// Token: 0x04000D8C RID: 3468
	private const float DEFAULT_RESPAWN_DELAY = 1.5f;

	// Token: 0x04000D8D RID: 3469
	public Action OnTeleported;

	// Token: 0x04000D8E RID: 3470
	public Action OnStateChanged;

	// Token: 0x04000D8F RID: 3471
	public Action OnAutoPilotChanged;

	// Token: 0x04000D90 RID: 3472
	public Action OnRaceStated;

	// Token: 0x04000D91 RID: 3473
	public Action<RcVehicle> OnRaceEnded;

	// Token: 0x04000D92 RID: 3474
	public Action OnLapEnded;

	// Token: 0x04000D93 RID: 3475
	public Action OnLapEndedAfterRace;

	// Token: 0x04000D94 RID: 3476
	public Action OnCheckpointValidated;

	// Token: 0x04000D95 RID: 3477
	public Action OnCheckpointsReseted;

	// Token: 0x04000D96 RID: 3478
	public Action OnFirstLapStarted;

	// Token: 0x04000D97 RID: 3479
	public Action OnCount;

	// Token: 0x04000D98 RID: 3480
	public float m_fUsualHandicap;

	// Token: 0x04000D99 RID: 3481
	public float m_fDriftMinSpeedKph;

	// Token: 0x04000D9A RID: 3482
	public Vector3 m_vCameraOffset;

	// Token: 0x04000D9B RID: 3483
	public RcVehicle.ControlType m_eControlType;

	// Token: 0x04000D9C RID: 3484
	public RcVehicle.DriftStyle m_eDriftStyle;

	// Token: 0x04000D9D RID: 3485
	protected Vector3 m_vRespawnPosition;

	// Token: 0x04000D9E RID: 3486
	protected Vector3 m_vPreviousPosition;

	// Token: 0x04000D9F RID: 3487
	protected Quaternion m_qRespawnOrientation;

	// Token: 0x04000DA0 RID: 3488
	protected bool m_bRaceEnded;

	// Token: 0x04000DA1 RID: 3489
	protected bool[] m_vehicleState = new bool[6];

	// Token: 0x04000DA2 RID: 3490
	protected float m_fTempHandicap;

	// Token: 0x04000DA3 RID: 3491
	protected int m_iInvulnerableStartTimeMs;

	// Token: 0x04000DA4 RID: 3492
	protected float m_fFallStartTimeMs;

	// Token: 0x04000DA5 RID: 3493
	protected float m_fArcadeDriftFactor;

	// Token: 0x04000DA6 RID: 3494
	protected bool m_bArcadeDriftLock;

	// Token: 0x04000DA7 RID: 3495
	protected float m_fMoveFactor;

	// Token: 0x04000DA8 RID: 3496
	protected float m_fSteeringFactor;

	// Token: 0x04000DA9 RID: 3497
	protected bool m_bNoSteeringInput;

	// Token: 0x04000DAA RID: 3498
	protected float m_fWheelAccelMSS;

	// Token: 0x04000DAB RID: 3499
	protected float m_fWheelSpeedMS;

	// Token: 0x04000DAC RID: 3500
	protected float m_fSteeringAngleRad;

	// Token: 0x04000DAD RID: 3501
	protected RcVehicle.eVehicleState m_ePrevState;

	// Token: 0x04000DAE RID: 3502
	protected RcVehiclePhysic m_pVehiclePhysic;

	// Token: 0x04000DAF RID: 3503
	protected int m_iVehicleId;

	// Token: 0x04000DB0 RID: 3504
	protected float m_fDriftFactor;

	// Token: 0x04000DB1 RID: 3505
	protected bool m_bFearsVehicleCollisions;

	// Token: 0x04000DB2 RID: 3506
	protected RcVehicleCarac m_pVehicleCarac;

	// Token: 0x04000DB3 RID: 3507
	protected RcGearBox m_pGearBox;

	// Token: 0x04000DB4 RID: 3508
	protected int m_iPlayerNumber;

	// Token: 0x04000DB5 RID: 3509
	protected RcVehicleRaceStats m_pRaceStats;

	// Token: 0x04000DB6 RID: 3510
	protected Transform m_pTransform;

	// Token: 0x04000DB7 RID: 3511
	protected float m_fRespawnDelay = 1.5f;

	// Token: 0x04000DB8 RID: 3512
	protected AudioListener m_pAudioListener;

	// Token: 0x04000DB9 RID: 3513
	private LayerMask m_IgnoreCollision;

	// Token: 0x04000DBA RID: 3514
	protected int m_iSecureTeleport;

	// Token: 0x04000DBB RID: 3515
	public Action OnKilled;

	// Token: 0x04000DBC RID: 3516
	public Action OnRespawn;

	// Token: 0x02000208 RID: 520
	public enum eVehicleState
	{
		// Token: 0x04000DBE RID: 3518
		S_IS_LOCKED,
		// Token: 0x04000DBF RID: 3519
		S_IS_AUTOPILOT,
		// Token: 0x04000DC0 RID: 3520
		S_IS_TELEPORTING,
		// Token: 0x04000DC1 RID: 3521
		S_IS_FALLING,
		// Token: 0x04000DC2 RID: 3522
		S_IS_RUNNING,
		// Token: 0x04000DC3 RID: 3523
		S_IS_DISABLED,
		// Token: 0x04000DC4 RID: 3524
		STATE_COUNT
	}

	// Token: 0x02000209 RID: 521
	public enum RcInputs
	{
		// Token: 0x04000DC6 RID: 3526
		ACTION_RACE_ACCELERATE = 100,
		// Token: 0x04000DC7 RID: 3527
		ACTION_RACE_BREAK,
		// Token: 0x04000DC8 RID: 3528
		ACTION_RACE_LEAN_LEFT,
		// Token: 0x04000DC9 RID: 3529
		ACTION_RACE_LEAN_RIGHT,
		// Token: 0x04000DCA RID: 3530
		ACTION_RACE_LEAN,
		// Token: 0x04000DCB RID: 3531
		ACTION_RACE_TOGGLE_VIEW,
		// Token: 0x04000DCC RID: 3532
		ACTION_RACE_REAR_VIEW,
		// Token: 0x04000DCD RID: 3533
		ACTION_RACE_RESPAWN,
		// Token: 0x04000DCE RID: 3534
		ACTION_RACE_BOOST,
		// Token: 0x04000DCF RID: 3535
		ACTION_RACE_SKID,
		// Token: 0x04000DD0 RID: 3536
		ACTION_RACE_LOOK_BACK,
		// Token: 0x04000DD1 RID: 3537
		ACTION_RACE_HAND_BRAKE,
		// Token: 0x04000DD2 RID: 3538
		ACTION_RACE_GEAR_SHIFT_UP,
		// Token: 0x04000DD3 RID: 3539
		ACTION_RACE_GEAR_SHIFT_DOWN,
		// Token: 0x04000DD4 RID: 3540
		ACTION_RACE_TOGGLE_AUTOPILOT
	}

	// Token: 0x0200020A RID: 522
	public enum ControlType
	{
		// Token: 0x04000DD6 RID: 3542
		Human,
		// Token: 0x04000DD7 RID: 3543
		AI,
		// Token: 0x04000DD8 RID: 3544
		Net
	}

	// Token: 0x0200020B RID: 523
	public enum DriftStyle
	{
		// Token: 0x04000DDA RID: 3546
		Handbrake,
		// Token: 0x04000DDB RID: 3547
		Ridge_Racer
	}
}

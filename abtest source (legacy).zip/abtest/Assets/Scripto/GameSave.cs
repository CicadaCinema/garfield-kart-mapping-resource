﻿using System;
using System.IO;
using System.Text;
using System.Xml.Serialization;
using UnityEngine;

// Token: 0x0200012D RID: 301
[XmlType("Ge")]
public class GameSave
{
	// Token: 0x06000835 RID: 2101 RVA: 0x00007C9C File Offset: 0x00005E9C
	public GameSave()
	{
		this.SaveData = new EncodedDictionary<byte[]>();
	}

	// Token: 0x1700013D RID: 317
	// (get) Token: 0x06000837 RID: 2103 RVA: 0x00007CBB File Offset: 0x00005EBB
	// (set) Token: 0x06000838 RID: 2104 RVA: 0x00007CC3 File Offset: 0x00005EC3
	[XmlElement("A")]
	public EncodedDictionary<byte[]> SaveData { get; set; }

	// Token: 0x06000839 RID: 2105 RVA: 0x0003D2E0 File Offset: 0x0003B4E0
	private static string GetFilePath(string pGameSaveName)
	{
		string deviceUniqueIdentifier = SystemInfo.deviceUniqueIdentifier;
		byte[] bytes = GameSave._encoder.GetBytes(pGameSaveName);
		byte[] bytes2 = GameSave._encoder.GetBytes(deviceUniqueIdentifier);
		string path = Convert.ToBase64String(bytes2) + Convert.ToBase64String(bytes);
		return Path.Combine(Application.persistentDataPath, path);
	}

	// Token: 0x0600083A RID: 2106 RVA: 0x0003D328 File Offset: 0x0003B528
	public static bool Exists(string pGameSaveName)
	{
		string filePath = GameSave.GetFilePath(pGameSaveName);
		return File.Exists(filePath);
	}

	// Token: 0x0600083B RID: 2107 RVA: 0x0003D344 File Offset: 0x0003B544
	public static GameSave Load(string pGameSaveName)
	{
		string filePath = GameSave.GetFilePath(pGameSaveName);
		GameSave gameSave = null;
		if (File.Exists(filePath))
		{
			try
			{
				gameSave = GameSave.Deserialize(filePath);
			}
			catch (Exception)
			{
				File.Delete(filePath);
			}
		}
		if (gameSave == null)
		{
			gameSave = new GameSave();
		}
		gameSave.FilePath = filePath;
		return gameSave;
	}

	// Token: 0x0600083C RID: 2108 RVA: 0x0003D3A4 File Offset: 0x0003B5A4
	private static GameSave Deserialize(string pFilePath)
	{
		GameSave gameSave = new GameSave();
		FileStream fileStream = File.Open(pFilePath, FileMode.Open);
		StreamReader streamReader = new StreamReader(fileStream);
		string text;
		while ((text = streamReader.ReadLine()) != null)
		{
			string[] array = text.Split(new char[]
			{
				';'
			});
			byte[] pKey = Convert.FromBase64String(array[0]);
			byte[] pValue = Convert.FromBase64String(array[1]);
			gameSave.SaveData.Add(pKey, pValue);
		}
		streamReader.Close();
		fileStream.Close();
		return gameSave;
	}

	// Token: 0x0600083D RID: 2109 RVA: 0x0003D420 File Offset: 0x0003B620
	private void Serialize(string pFilePath)
	{
		FileStream fileStream = File.Open(pFilePath, FileMode.Create);
		StreamWriter streamWriter = new StreamWriter(fileStream);
		foreach (SerializablePair<byte[], byte[]> serializablePair in this.SaveData)
		{
			string str = Convert.ToBase64String(serializablePair.Key);
			string str2 = Convert.ToBase64String(serializablePair.Value);
			streamWriter.WriteLine(str + ";" + str2);
		}
		streamWriter.Close();
		fileStream.Close();
	}

	// Token: 0x0600083E RID: 2110 RVA: 0x00007CCC File Offset: 0x00005ECC
	public void Save()
	{
		this.Serialize(this.FilePath);
	}

	// Token: 0x0600083F RID: 2111 RVA: 0x0003D4BC File Offset: 0x0003B6BC
	private void SetValue(string pKey, byte[] pValue)
	{
		byte[] bytes = GameSave._encoder.GetBytes(pKey);
		if (this.SaveData.ContainsKey(bytes))
		{
			this.SaveData[bytes] = pValue;
		}
		else
		{
			this.SaveData.Add(bytes, pValue);
		}
	}

	// Token: 0x06000840 RID: 2112 RVA: 0x0003D508 File Offset: 0x0003B708
	public void SetString(string pKey, string pValue)
	{
		byte[] bytes = GameSave._encoder.GetBytes(pValue);
		this.SetValue(pKey, bytes);
	}

	// Token: 0x06000841 RID: 2113 RVA: 0x0003D52C File Offset: 0x0003B72C
	public void SetInt(string pKey, int pValue)
	{
		string pValue2 = Convert.ToString(pValue);
		this.SetString(pKey, pValue2);
	}

	// Token: 0x06000842 RID: 2114 RVA: 0x0003D548 File Offset: 0x0003B748
	public void SetFloat(string pKey, float pValue)
	{
		string pValue2 = Convert.ToString(pValue);
		this.SetString(pKey, pValue2);
	}

	// Token: 0x06000843 RID: 2115 RVA: 0x0003D564 File Offset: 0x0003B764
	public void SetBool(string pKey, bool pValue)
	{
		string pValue2 = Convert.ToString(pValue);
		this.SetString(pKey, pValue2);
	}

	// Token: 0x06000844 RID: 2116 RVA: 0x0003D580 File Offset: 0x0003B780
	public string GetString(string pKey)
	{
		byte[] bytes = GameSave._encoder.GetBytes(pKey);
		if (this.SaveData.ContainsKey(bytes))
		{
			byte[] bytes2 = this.SaveData[bytes];
			return GameSave._encoder.GetString(bytes2);
		}
		return null;
	}

	// Token: 0x06000845 RID: 2117 RVA: 0x0003D5C4 File Offset: 0x0003B7C4
	public float GetFloat(string pKey)
	{
		string @string = this.GetString(pKey);
		if (@string != null)
		{
			return (float)Convert.ToDouble(@string);
		}
		return float.MinValue;
	}

	// Token: 0x06000846 RID: 2118 RVA: 0x0003D5EC File Offset: 0x0003B7EC
	public int GetInt(string pKey)
	{
		string @string = this.GetString(pKey);
		if (@string != null)
		{
			return Convert.ToInt32(@string);
		}
		return int.MinValue;
	}

	// Token: 0x06000847 RID: 2119 RVA: 0x0003D614 File Offset: 0x0003B814
	public bool GetBool(string pKey)
	{
		string @string = this.GetString(pKey);
		return @string != null && Convert.ToBoolean(@string);
	}

	// Token: 0x06000848 RID: 2120 RVA: 0x0003D638 File Offset: 0x0003B838
	public string GetString(string pKey, string pDefaultValue)
	{
		byte[] bytes = GameSave._encoder.GetBytes(pKey);
		if (this.SaveData.ContainsKey(bytes))
		{
			byte[] bytes2 = this.SaveData[bytes];
			return GameSave._encoder.GetString(bytes2);
		}
		this.SetString(pKey, pDefaultValue);
		return pDefaultValue;
	}

	// Token: 0x06000849 RID: 2121 RVA: 0x0003D684 File Offset: 0x0003B884
	public float GetFloat(string pKey, float pDefaultValue)
	{
		string @string = this.GetString(pKey);
		if (@string != null)
		{
			return (float)Convert.ToDouble(@string);
		}
		this.SetFloat(pKey, pDefaultValue);
		return pDefaultValue;
	}

	// Token: 0x0600084A RID: 2122 RVA: 0x0003D6B0 File Offset: 0x0003B8B0
	public int GetInt(string pKey, int pDefaultValue)
	{
		string @string = this.GetString(pKey);
		if (@string != null)
		{
			return Convert.ToInt32(@string);
		}
		this.SetInt(pKey, pDefaultValue);
		return pDefaultValue;
	}

	// Token: 0x0600084B RID: 2123 RVA: 0x0003D6DC File Offset: 0x0003B8DC
	public bool GetBool(string pKey, bool pDefaultValue)
	{
		string @string = this.GetString(pKey);
		if (@string != null)
		{
			return Convert.ToBoolean(@string);
		}
		this.SetBool(pKey, pDefaultValue);
		return pDefaultValue;
	}

	// Token: 0x04000875 RID: 2165
	[XmlIgnore]
	public string FilePath;

	// Token: 0x04000876 RID: 2166
	private static UTF8Encoding _encoder = new UTF8Encoding();
}

﻿using System;
using UnityEngine;

// Token: 0x02000058 RID: 88
[AddComponentMenu("NGUI/Tween/Spring Position")]
public class SpringPosition : IgnoreTimeScale
{
	// Token: 0x06000252 RID: 594 RVA: 0x00003C1A File Offset: 0x00001E1A
	private void Start()
	{
		this.mTrans = base.transform;
	}

	// Token: 0x06000253 RID: 595 RVA: 0x000180A0 File Offset: 0x000162A0
	private void Update()
	{
		float deltaTime = (!this.ignoreTimeScale) ? Time.deltaTime : base.UpdateRealTimeDelta();
		if (this.worldSpace)
		{
			if (this.mThreshold == 0f)
			{
				this.mThreshold = (this.target - this.mTrans.position).magnitude * 0.001f;
			}
			this.mTrans.position = NGUIMath.SpringLerp(this.mTrans.position, this.target, this.strength, deltaTime);
			if (this.mThreshold >= (this.target - this.mTrans.position).magnitude)
			{
				this.mTrans.position = this.target;
				if (this.onFinished != null)
				{
					this.onFinished(this);
				}
				if (this.eventReceiver != null && !string.IsNullOrEmpty(this.callWhenFinished))
				{
					this.eventReceiver.SendMessage(this.callWhenFinished, this, SendMessageOptions.DontRequireReceiver);
				}
				base.enabled = false;
			}
		}
		else
		{
			if (this.mThreshold == 0f)
			{
				this.mThreshold = (this.target - this.mTrans.localPosition).magnitude * 0.001f;
			}
			this.mTrans.localPosition = NGUIMath.SpringLerp(this.mTrans.localPosition, this.target, this.strength, deltaTime);
			if (this.mThreshold >= (this.target - this.mTrans.localPosition).magnitude)
			{
				this.mTrans.localPosition = this.target;
				if (this.onFinished != null)
				{
					this.onFinished(this);
				}
				if (this.eventReceiver != null && !string.IsNullOrEmpty(this.callWhenFinished))
				{
					this.eventReceiver.SendMessage(this.callWhenFinished, this, SendMessageOptions.DontRequireReceiver);
				}
				base.enabled = false;
			}
		}
	}

	// Token: 0x06000254 RID: 596 RVA: 0x000182B8 File Offset: 0x000164B8
	public static SpringPosition Begin(GameObject go, Vector3 pos, float strength)
	{
		SpringPosition springPosition = go.GetComponent<SpringPosition>();
		if (springPosition == null)
		{
			springPosition = go.AddComponent<SpringPosition>();
		}
		springPosition.target = pos;
		springPosition.strength = strength;
		springPosition.onFinished = null;
		if (!springPosition.enabled)
		{
			springPosition.mThreshold = 0f;
			springPosition.enabled = true;
		}
		return springPosition;
	}

	// Token: 0x040001DB RID: 475
	public Vector3 target = Vector3.zero;

	// Token: 0x040001DC RID: 476
	public float strength = 10f;

	// Token: 0x040001DD RID: 477
	public bool worldSpace;

	// Token: 0x040001DE RID: 478
	public bool ignoreTimeScale;

	// Token: 0x040001DF RID: 479
	public GameObject eventReceiver;

	// Token: 0x040001E0 RID: 480
	public string callWhenFinished;

	// Token: 0x040001E1 RID: 481
	public SpringPosition.OnFinished onFinished;

	// Token: 0x040001E2 RID: 482
	private Transform mTrans;

	// Token: 0x040001E3 RID: 483
	private float mThreshold;

	// Token: 0x02000059 RID: 89
	// (Invoke) Token: 0x06000256 RID: 598
	public delegate void OnFinished(SpringPosition spring);
}

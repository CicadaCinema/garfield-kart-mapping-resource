﻿using System;
using UnityEngine;

// Token: 0x02000119 RID: 281
public class HUDResultsChampionship : MonoBehaviour
{
	// Token: 0x060007C6 RID: 1990 RVA: 0x0003A68C File Offset: 0x0003888C
	public void Start()
	{
		int humanPlayerVehicleId = Singleton<GameManager>.Instance.GameMode.GetHumanPlayerVehicleId();
		int num = 0;
		for (int i = 0; i < Singleton<GameConfigurator>.Instance.RankingManager.RaceScoreCount(); i++)
		{
			ChampionShipScoreData championshipPos = Singleton<GameConfigurator>.Instance.RankingManager.GetChampionshipPos(i);
			if (humanPlayerVehicleId == championshipPos.KartIndex)
			{
				num = championshipPos.ChampionshipPosition;
				break;
			}
		}
		if (Singleton<GameConfigurator>.Instance.ChampionShipData != null)
		{
			this.ChampionshipName.text = Singleton<GameConfigurator>.Instance.ChampionShipData.ChampionShipName;
		}
		this.ChampionshipIcon.ChangeTexture(Singleton<GameConfigurator>.Instance.ChampionShipData.Index);
		this.DifficultyIcon.ChangeTexture((int)Singleton<GameConfigurator>.Instance.Difficulty);
		this.Position.ChangeTexture(num);
		if (num < 3)
		{
			this.Cup.ChangeTexture(Singleton<GameConfigurator>.Instance.ChampionShipData.Index * 3 + num);
			this.Halo.SetActive(true);
		}
		else
		{
			this.Cup.gameObject.SetActive(false);
			this.Halo.SetActive(false);
		}
		this.Summary.text = Localization.instance.Get((num >= 3) ? "HUD_RESULTS_FAILED" : ((num != 0) ? "HUD_RESULTS_CONGRATS" : "HUD_FINISHRACE_FINISHFIRST"));
		this.m_cEntryPoint = GameObject.Find("EntryPoint").GetComponent<EntryPoint>();
		this.FacebookButton.SetActive(false);
	}

	// Token: 0x060007C7 RID: 1991 RVA: 0x0003A810 File Offset: 0x00038A10
	public void OnFacebook()
	{
		if (this.m_cEntryPoint)
		{
			RaceScoreData scoreData = Singleton<GameConfigurator>.Instance.RankingManager.GetScoreData(Singleton<GameManager>.Instance.GameMode.GetHumanPlayerVehicleId());
			int num = ((ChampionShipScoreData)scoreData).ChampionshipPosition + 1;
			int num2 = num;
			string sTitle = string.Empty;
			if (num2 > 3)
			{
				num2 = 4;
			}
			sTitle = string.Format(Localization.instance.Get("FB_CHAMPIONSHIP_TITLE_" + num2), Singleton<GameConfigurator>.Instance.ChampionShipData.ChampionShipName);
			string sDescription = string.Format(Localization.instance.Get("FB_CHAMPIONSHIP_DESCRIPTION"), Localization.instance.Get("FB_PLAYER_PLACE_" + num));
			this.m_cEntryPoint.OnFacebook(sTitle, sDescription);
		}
	}

	// Token: 0x040007C9 RID: 1993
	public UILabel ChampionshipName;

	// Token: 0x040007CA RID: 1994
	public UILabel Summary;

	// Token: 0x040007CB RID: 1995
	public UITexturePattern Cup;

	// Token: 0x040007CC RID: 1996
	public GameObject Halo;

	// Token: 0x040007CD RID: 1997
	public UITexturePattern DifficultyIcon;

	// Token: 0x040007CE RID: 1998
	public UITexturePattern ChampionshipIcon;

	// Token: 0x040007CF RID: 1999
	public UITexturePattern Position;

	// Token: 0x040007D0 RID: 2000
	public GameObject FacebookButton;

	// Token: 0x040007D1 RID: 2001
	private EntryPoint m_cEntryPoint;
}

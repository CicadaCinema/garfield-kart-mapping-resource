﻿using System;

// Token: 0x02000143 RID: 323
public class KartCarac : DrivingCarac
{
	// Token: 0x06000926 RID: 2342 RVA: 0x00006BC4 File Offset: 0x00004DC4
	public override void Start()
	{
		base.Start();
	}

	// Token: 0x06000927 RID: 2343 RVA: 0x00040FF8 File Offset: 0x0003F1F8
	public static int Compare(KartCarac oItem1, KartCarac oItem2)
	{
		int num = KartCarac.CompareState(oItem1, oItem2);
		if (num == 0)
		{
			num = IconCarac.CompareName(oItem1, oItem2);
		}
		return num;
	}

	// Token: 0x06000928 RID: 2344 RVA: 0x0004101C File Offset: 0x0003F21C
	private static int CompareState(KartCarac oItem1, KartCarac oItem2)
	{
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		return IconCarac.SuppressNewState(instance.GetKartState(oItem2.Owner)) - IconCarac.SuppressNewState(instance.GetKartState(oItem1.Owner));
	}

	// Token: 0x04000945 RID: 2373
	public E_UnlockableItemSate State;
}

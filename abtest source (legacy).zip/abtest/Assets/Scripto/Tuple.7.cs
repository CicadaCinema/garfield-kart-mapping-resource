﻿using System;

// Token: 0x0200025B RID: 603
[Serializable]
public class Tuple<T1, T2, T3, T4, T5, T6, T7> : Tuple<T1, T2, T3, T4, T5, T6>
{
	// Token: 0x06001084 RID: 4228 RVA: 0x000678E0 File Offset: 0x00065AE0
	public Tuple() : this(default(T1), default(T2), default(T3), default(T4), default(T5), default(T6), default(T7))
	{
	}

	// Token: 0x06001085 RID: 4229 RVA: 0x0000D1D7 File Offset: 0x0000B3D7
	public Tuple(T1 pItem1, T2 pItem2, T3 pItem3, T4 pItem4, T5 pItem5, T6 pItem6, T7 pItem7) : base(pItem1, pItem2, pItem3, pItem4, pItem5, pItem6)
	{
		this.Item7 = pItem7;
	}

	// Token: 0x04000FC0 RID: 4032
	public T7 Item7;
}

﻿using System;

// Token: 0x02000099 RID: 153
[Serializable]
public class Chance
{
	// Token: 0x06000412 RID: 1042 RVA: 0x000050E2 File Offset: 0x000032E2
	public Chance(int pGood, int pAverage, int pBad)
	{
		this.Good = pGood;
		this.Average = pAverage;
		this.Bad = pBad;
	}

	// Token: 0x06000413 RID: 1043 RVA: 0x000050FF File Offset: 0x000032FF
	protected int SetValue(int pValue)
	{
		if (pValue < 0)
		{
			return 0;
		}
		if (pValue > 100)
		{
			return 100;
		}
		return pValue;
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x00024618 File Offset: 0x00022818
	public int GetChance(E_AILevel pLevel)
	{
		switch (pLevel)
		{
		case E_AILevel.GOOD:
			return this.Good;
		case E_AILevel.AVERAGE:
			return this.Average;
		case E_AILevel.BAD:
			return this.Bad;
		default:
			return 0;
		}
	}

	// Token: 0x0400038A RID: 906
	public int Good;

	// Token: 0x0400038B RID: 907
	public int Average;

	// Token: 0x0400038C RID: 908
	public int Bad;
}

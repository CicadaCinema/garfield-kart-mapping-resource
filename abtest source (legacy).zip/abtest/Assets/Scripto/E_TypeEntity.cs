﻿using System;

// Token: 0x020001DC RID: 476
public enum E_TypeEntity
{
	// Token: 0x04000C75 RID: 3189
	NONE,
	// Token: 0x04000C76 RID: 3190
	ATTRACTIVE,
	// Token: 0x04000C77 RID: 3191
	REPULSIVE,
	// Token: 0x04000C78 RID: 3192
	OBSTACLE,
	// Token: 0x04000C79 RID: 3193
	CAR,
	// Token: 0x04000C7A RID: 3194
	COUNT
}

﻿using System;
using UnityEngine;

// Token: 0x0200005A RID: 90
[AddComponentMenu("NGUI/Tween/Alpha")]
public class TweenAlpha : UITweener
{
	// Token: 0x17000053 RID: 83
	// (get) Token: 0x0600025A RID: 602 RVA: 0x00018314 File Offset: 0x00016514
	// (set) Token: 0x0600025B RID: 603 RVA: 0x00018360 File Offset: 0x00016560
	public float alpha
	{
		get
		{
			if (this.mWidget != null)
			{
				return this.mWidget.alpha;
			}
			if (this.mPanel != null)
			{
				return this.mPanel.alpha;
			}
			return 0f;
		}
		set
		{
			if (this.mWidget != null)
			{
				this.mWidget.alpha = value;
			}
			else if (this.mPanel != null)
			{
				this.mPanel.alpha = value;
			}
		}
	}

	// Token: 0x0600025C RID: 604 RVA: 0x00003C46 File Offset: 0x00001E46
	private void Awake()
	{
		this.mPanel = base.GetComponent<UIPanel>();
		if (this.mPanel == null)
		{
			this.mWidget = base.GetComponentInChildren<UIWidget>();
		}
	}

	// Token: 0x0600025D RID: 605 RVA: 0x00003C71 File Offset: 0x00001E71
	protected override void OnUpdate(float factor, bool isFinished)
	{
		this.alpha = Mathf.Lerp(this.from, this.to, factor);
	}

	// Token: 0x0600025E RID: 606 RVA: 0x000183AC File Offset: 0x000165AC
	public static TweenAlpha Begin(GameObject go, float duration, float alpha)
	{
		TweenAlpha tweenAlpha = UITweener.Begin<TweenAlpha>(go, duration);
		tweenAlpha.from = tweenAlpha.alpha;
		tweenAlpha.to = alpha;
		if (duration <= 0f)
		{
			tweenAlpha.Sample(1f, true);
			tweenAlpha.enabled = false;
		}
		return tweenAlpha;
	}

	// Token: 0x040001E4 RID: 484
	public float from = 1f;

	// Token: 0x040001E5 RID: 485
	public float to = 1f;

	// Token: 0x040001E6 RID: 486
	private Transform mTrans;

	// Token: 0x040001E7 RID: 487
	private UIWidget mWidget;

	// Token: 0x040001E8 RID: 488
	private UIPanel mPanel;
}

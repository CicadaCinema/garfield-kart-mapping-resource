﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

// Token: 0x02000185 RID: 389
public class InGameGameMode : GameMode
{
	// Token: 0x1700016C RID: 364
	// (get) Token: 0x06000A43 RID: 2627 RVA: 0x000090DA File Offset: 0x000072DA
	public GkAIManager AIManager
	{
		get
		{
			return this._aiManager;
		}
	}

	// Token: 0x06000A44 RID: 2628 RVA: 0x000090E2 File Offset: 0x000072E2
	public virtual void Start()
	{
		base.State = this._state;
	}

	// Token: 0x06000A45 RID: 2629 RVA: 0x00046398 File Offset: 0x00044598
	public override void Awake()
	{
		base.Awake();
		this._aiManager = new GkAIManager();
		this.PlaceVehicles = EVehiclePlacementState.Init;
		this.StartPositions = new Transform[6];
		this._hasStart = false;
		this._chanceDispatcher = new ChanceDispatcher();
		GameObject gameObject = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("HUD"));
		gameObject.transform.localPosition = Vector3.zero;
		this._hud = gameObject.GetComponent<HUDInGame>();
		this._gameStates[0] = base.gameObject.AddComponent<TrackPresentationGameState>();
		GameState gameState = this._gameStates[0];
		gameState.OnStateChanged = (Action<E_GameState>)Delegate.Combine(gameState.OnStateChanged, new Action<E_GameState>(this.StateChange));
		this._gameStates[0].gameMode = this;
		this._gameStates[0].enabled = false;
		this._gameStates[1] = base.gameObject.AddComponent<CarPresentationGameState>();
		GameState gameState2 = this._gameStates[1];
		gameState2.OnStateChanged = (Action<E_GameState>)Delegate.Combine(gameState2.OnStateChanged, new Action<E_GameState>(this.StateChange));
		this._gameStates[1].gameMode = this;
		this._gameStates[1].enabled = false;
		this._gameStates[2] = base.gameObject.AddComponent<StartGameState>();
		GameState gameState3 = this._gameStates[2];
		gameState3.OnStateChanged = (Action<E_GameState>)Delegate.Combine(gameState3.OnStateChanged, new Action<E_GameState>(this.StateChange));
		this._gameStates[2].gameMode = this;
		this._gameStates[2].enabled = false;
		this._gameStates[3] = base.gameObject.AddComponent<RaceGameState>();
		GameState gameState4 = this._gameStates[3];
		gameState4.OnStateChanged = (Action<E_GameState>)Delegate.Combine(gameState4.OnStateChanged, new Action<E_GameState>(this.StateChange));
		this._gameStates[3].gameMode = this;
		this._gameStates[3].enabled = false;
		this._gameStates[4] = base.gameObject.AddComponent<EndRaceGameState>();
		GameState gameState5 = this._gameStates[4];
		gameState5.OnStateChanged = (Action<E_GameState>)Delegate.Combine(gameState5.OnStateChanged, new Action<E_GameState>(this.StateChange));
		this._gameStates[4].gameMode = this;
		this._gameStates[4].enabled = false;
		this._gameStates[5] = base.gameObject.AddComponent<ResultGameState>();
		GameState gameState6 = this._gameStates[5];
		gameState6.OnStateChanged = (Action<E_GameState>)Delegate.Combine(gameState6.OnStateChanged, new Action<E_GameState>(this.StateChange));
		this._gameStates[5].gameMode = this;
		this._gameStates[5].enabled = false;
		this._gameStates[7] = base.gameObject.AddComponent<TutorialGameState>();
		GameState gameState7 = this._gameStates[7];
		gameState7.OnStateChanged = (Action<E_GameState>)Delegate.Combine(gameState7.OnStateChanged, new Action<E_GameState>(this.StateChange));
		this._gameStates[7].gameMode = this;
		this._gameStates[7].enabled = false;
		this._gameStates[8] = base.gameObject.AddComponent<RaceTutorialGameState>();
		GameState gameState8 = this._gameStates[8];
		gameState8.OnStateChanged = (Action<E_GameState>)Delegate.Combine(gameState8.OnStateChanged, new Action<E_GameState>(this.StateChange));
		this._gameStates[8].gameMode = this;
		this._gameStates[8].enabled = false;
		this.m_bVehicleCreated = false;
		this.m_bInitialPlacementConfigured = false;
	}

	// Token: 0x06000A46 RID: 2630 RVA: 0x000090F0 File Offset: 0x000072F0
	protected override void StateChange(E_GameState pNewState)
	{
		base.StateChange(pNewState);
		if (pNewState == E_GameState.Race)
		{
			this._hasStart = true;
		}
	}

	// Token: 0x06000A47 RID: 2631 RVA: 0x00009107 File Offset: 0x00007307
	public override void Dispose()
	{
		UnityEngine.Object.Destroy(this._pathResource);
		base.Dispose();
	}

	// Token: 0x06000A48 RID: 2632 RVA: 0x000466E4 File Offset: 0x000448E4
	public void Update()
	{
		if (this._hasStart)
		{
			this._aiManager.Update();
		}
		if (this.PlaceVehicles == EVehiclePlacementState.ValidateAdvantage && this.m_bVehicleCreated)
		{
			Kart humanKart = base.GetHumanKart();
			if (humanKart)
			{
				base.SetAdvantage(humanKart.GetVehicleId(), Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantage());
			}
			this._aiManager.SetBoostStart(this);
			this.PlaceVehicles = EVehiclePlacementState.ComputeInitialPlacement;
			this.ConfigurePlaceVehiclesOnStartLine();
		}
		else if (this.PlaceVehicles == EVehiclePlacementState.ComputeInitialPlacement && this.m_bInitialPlacementConfigured)
		{
			this.PlaceVehicles = EVehiclePlacementState.ReadyToTeleport;
			this.PlaceVehiclesOnStartLine();
		}
		else if (this.PlaceVehicles == EVehiclePlacementState.NeedToTeleport)
		{
			this.PlaceVehicles = EVehiclePlacementState.Teleported;
			for (int i = 0; i < this.StartPositions.Length; i++)
			{
				for (int j = 0; j < this.m_pPlayers.Length; j++)
				{
					if (this.m_pPlayers[j] != null && this.m_pPlayers[j].Item2 != null)
					{
						Kart item = this.m_pPlayers[j].Item2;
						if (item && item.GetVehicleId() == i)
						{
							RcKinematicPhysic rcKinematicPhysic = (RcKinematicPhysic)item.GetVehiclePhysic();
							rcKinematicPhysic.Teleport(this.StartPositions[i].position, this.StartPositions[i].rotation);
							item.Enable();
						}
					}
				}
			}
		}
		else if (this.PlaceVehicles == EVehiclePlacementState.Teleported)
		{
			this.PlaceVehicles = EVehiclePlacementState.ReadyToStart;
			this.m_bReadyToStart = true;
			foreach (RcPortalTrigger rcPortalTrigger in UnityEngine.Object.FindSceneObjectsOfType(typeof(RcPortalTrigger)))
			{
				rcPortalTrigger.enabled = true;
			}
		}
	}

	// Token: 0x06000A49 RID: 2633 RVA: 0x0000911A File Offset: 0x0000731A
	public void TeleportVehiclesOnStartLine()
	{
		this.PlaceVehicles = EVehiclePlacementState.NeedToTeleport;
	}

	// Token: 0x06000A4A RID: 2634 RVA: 0x000468B4 File Offset: 0x00044AB4
	public override void StartScene()
	{
		base.ComputePlayerAdvantages();
		new GameObject
		{
			name = "Vehicles Collision Manager"
		}.AddComponent(typeof(RcKinematicCollisionManager));
		new GameObject
		{
			name = "Respawn Checker"
		}.AddComponent(typeof(RcRespawnChecker));
		GameObject gameObject = GameObject.Find("Race");
		RcCatchUp rcCatchUp = gameObject.GetComponent<RcCatchUp>();
		if (!rcCatchUp)
		{
			rcCatchUp = (RcCatchUp)gameObject.AddComponent(typeof(RcCatchUp));
			if (Network.peerType == NetworkPeerType.Disconnected)
			{
				if (Singleton<GameConfigurator>.Instance.Difficulty == EDifficulty.EASY)
				{
					rcCatchUp.AddFactor(-200f, 0f, 0.05f);
					rcCatchUp.AddFactor(0f, 0f, -0.15f);
					rcCatchUp.AddFactor(50f, 0f, -0.25f);
					rcCatchUp.AddFactor(200f, 0f, -0.5f);
				}
				else if (Singleton<GameConfigurator>.Instance.Difficulty == EDifficulty.NORMAL)
				{
					rcCatchUp.AddFactor(-100f, 0f, 0.1f);
					rcCatchUp.AddFactor(0f, 0f, 0.05f);
					rcCatchUp.AddFactor(100f, 0f, -0.1f);
					rcCatchUp.AddFactor(500f, 0f, -0.5f);
				}
				else
				{
					rcCatchUp.AddFactor(-50f, 0f, 0.1f);
					rcCatchUp.AddFactor(0f, 0f, 0.1f);
					rcCatchUp.AddFactor(200f, 0f, -0.05f);
				}
			}
			else if (Singleton<GameConfigurator>.Instance.Difficulty == EDifficulty.EASY)
			{
				rcCatchUp.AddFactor(-200f, 0.1f, 0.05f);
				rcCatchUp.AddFactor(0f, 0f, -0.05f);
				rcCatchUp.AddFactor(50f, 0f, -0.25f);
				rcCatchUp.AddFactor(200f, 0f, -0.5f);
			}
			else if (Singleton<GameConfigurator>.Instance.Difficulty == EDifficulty.NORMAL)
			{
				rcCatchUp.AddFactor(-100f, 0.05f, 0.1f);
				rcCatchUp.AddFactor(0f, 0f, 0.05f);
				rcCatchUp.AddFactor(100f, 0f, -0.1f);
				rcCatchUp.AddFactor(500f, 0f, -0.5f);
			}
			else
			{
				rcCatchUp.AddFactor(-50f, 0.05f, 0.1f);
				rcCatchUp.AddFactor(0f, 0f, 0.1f);
				rcCatchUp.AddFactor(200f, 0f, -0.05f);
			}
			gameObject.GetComponent<RcRace>().Start();
		}
		if (Singleton<ChallengeManager>.Instance.IsActive)
		{
			Singleton<ChallengeManager>.Instance.SetTried();
		}
	}

	// Token: 0x06000A4B RID: 2635 RVA: 0x00046B94 File Offset: 0x00044D94
	public override void CreatePlayers()
	{
		NetworkMgr networkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
		int num = 6;
		if (Network.peerType != NetworkPeerType.Disconnected)
		{
			num -= networkMgr.InitialNbPlayers - 1;
		}
		bool flag = Singleton<GameConfigurator>.Instance.PlayerDataList == null;
		for (int i = 0; i < num; i++)
		{
			if (!Network.isClient || i == 0)
			{
				int num2 = i;
				if (Network.peerType != NetworkPeerType.Disconnected)
				{
					num2 = ((i != 0) ? (i + (networkMgr.InitialNbPlayers - 1)) : networkMgr.GetNetworkID());
				}
				if (!flag)
				{
					PlayerData playerData = Singleton<GameConfigurator>.Instance.PlayerDataList[num2];
					base.CreatePlayer(playerData.Character, playerData.Kart, playerData.Custom, playerData.Hat, playerData.NbStars, num2, true, i > 0);
				}
				else
				{
					GameObject gameObject = null;
					GameObject gameObject2 = null;
					int iNbStars = 0;
					if (i == 0 && DebugMgr.Instance != null && !DebugMgr.Instance.dbgData.RandomPlayer)
					{
						DebugMgr.Instance.LoadDefaultPlayer(num2, this, true, i > 0);
					}
					else
					{
						ECharacter character;
						ECharacter kart;
						if (i > 0)
						{
							this._chanceDispatcher.DispatchAI(num2, true, out character, out kart, out gameObject, out gameObject2);
						}
						else
						{
							character = Singleton<GameConfigurator>.Instance.PlayerConfig.Character;
							kart = Singleton<GameConfigurator>.Instance.PlayerConfig.Kart;
							iNbStars = Singleton<GameConfigurator>.Instance.PlayerConfig.NbStars;
							gameObject = (GameObject)Resources.Load("Hat/" + Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat.name);
							gameObject2 = (GameObject)Resources.Load("Kart/" + Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom.name);
							this._chanceDispatcher.AddPlayerData(character, kart, gameObject2, gameObject, iNbStars, num2);
						}
						base.CreatePlayer(character, kart, gameObject2.name, gameObject.name, iNbStars, num2, true, i > 0);
					}
				}
			}
		}
		this.CreateAIPaths();
	}

	// Token: 0x06000A4C RID: 2636 RVA: 0x00046D9C File Offset: 0x00044F9C
	protected void CreateAIPaths()
	{
		string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(Singleton<GameConfigurator>.Instance.StartScene);
		GameObject gameObject = (GameObject)Resources.Load("AI/Paths" + fileNameWithoutExtension);
		if (gameObject != null)
		{
			this._pathResource = (GameObject)UnityEngine.Object.Instantiate(gameObject);
		}
	}

	// Token: 0x06000A4D RID: 2637 RVA: 0x00043CD8 File Offset: 0x00041ED8
	private int GetRandomStartPos(List<int> pAvailableStartPos)
	{
		int num = pAvailableStartPos[UnityEngine.Random.Range(0, pAvailableStartPos.Count)];
		pAvailableStartPos.Remove(num);
		return num;
	}

	// Token: 0x06000A4E RID: 2638 RVA: 0x00009123 File Offset: 0x00007323
	public virtual void ConfigurePlaceVehiclesOnStartLine()
	{
		this.m_bInitialPlacementConfigured = true;
	}

	// Token: 0x06000A4F RID: 2639 RVA: 0x00046DEC File Offset: 0x00044FEC
	public virtual void PlaceVehiclesOnStartLine()
	{
		GameObject gameObject = GameObject.Find("Start");
		if (gameObject != null)
		{
			if (Network.peerType != NetworkPeerType.Disconnected)
			{
				for (int i = 0; i < this.m_pPlayers.Length; i++)
				{
					Kart kart = base.GetKart(i);
					int vehicleId = kart.GetVehicleId();
					Transform child = gameObject.transform.GetChild(vehicleId);
					this.StartPositions[i] = child;
				}
			}
			else
			{
				List<int> list = new List<int>
				{
					0,
					1,
					2,
					3,
					4,
					5
				};
				int num = 0;
				GameObject humanPlayer = base.GetHumanPlayer(ref num);
				if (humanPlayer != null)
				{
					if (Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantage() == EAdvantage.FirstPlaceOnStart)
					{
						int num2 = gameObject.transform.GetChildCount() - 1;
						this.StartPositions[num] = gameObject.transform.GetChild(num2);
						list.Remove(num2);
					}
					else
					{
						this.StartPositions[num] = gameObject.transform.GetChild(0);
						list.Remove(0);
					}
				}
				for (int j = 0; j < this.m_pPlayers.Length; j++)
				{
					if (base.GetPlayer(j) != humanPlayer)
					{
						Transform child2 = gameObject.transform.GetChild(this.GetRandomStartPos(list));
						this.StartPositions[j] = child2;
					}
				}
			}
		}
	}

	// Token: 0x06000A50 RID: 2640 RVA: 0x00046F74 File Offset: 0x00045174
	public void SubscribeRaceEnd()
	{
		for (int i = 0; i < base.PlayerCount; i++)
		{
			Kart kart = base.GetKart(i);
			if (kart)
			{
				if (kart.GetControlType() == RcVehicle.ControlType.Human)
				{
					Kart kart2 = kart;
					kart2.OnRaceEnded = (Action<RcVehicle>)Delegate.Combine(kart2.OnRaceEnded, new Action<RcVehicle>(this.RaceEnd));
				}
				else
				{
					Kart kart3 = kart;
					kart3.OnRaceEnded = (Action<RcVehicle>)Delegate.Combine(kart3.OnRaceEnded, new Action<RcVehicle>(this.IANetRaceEnded));
				}
			}
		}
	}

	// Token: 0x06000A51 RID: 2641 RVA: 0x00047004 File Offset: 0x00045204
	protected virtual void IANetRaceEnded(RcVehicle pVehicle)
	{
		int rank = pVehicle.RaceStats.GetRank();
		Kart kart = (Kart)pVehicle;
		if (rank == 0)
		{
			kart.KartSound.PlayVoice(KartSound.EVoices.Selection);
			kart.Anim.LaunchVictoryAnim(true);
		}
		else if (rank > 2)
		{
			kart.KartSound.PlayVoice(KartSound.EVoices.Bad);
			kart.Anim.LaunchDefeatAnim(true);
		}
		else
		{
			kart.KartSound.PlayVoice(KartSound.EVoices.Good);
			kart.Anim.LaunchSuccessAnim(true);
		}
		int num = Singleton<GameConfigurator>.Instance.GameSettings.ChampionShipScores[rank];
		if (num < 4 && kart.SelectedAdvantage == EAdvantage.FourPoints)
		{
			num = 4;
		}
		else if (num < 2 && kart.SelectedAdvantage == EAdvantage.TwoPoints)
		{
			num = 2;
		}
		this.PlayerFinish(pVehicle.GetVehicleId(), num);
	}

	// Token: 0x06000A52 RID: 2642 RVA: 0x000470D4 File Offset: 0x000452D4
	protected virtual void RaceEnd(RcVehicle pVehicle)
	{
		int rank = pVehicle.RaceStats.GetRank();
		Kart kart = (Kart)pVehicle;
		int num = Singleton<GameConfigurator>.Instance.GameSettings.ChampionShipScores[rank];
		if (num < 4 && kart.SelectedAdvantage == EAdvantage.FourPoints)
		{
			num = 4;
		}
		else if (num < 2 && kart.SelectedAdvantage == EAdvantage.TwoPoints)
		{
			num = 2;
		}
		this.PlayerFinish(pVehicle.GetVehicleId(), num);
		if (Singleton<ChallengeManager>.Instance.IsActive)
		{
			Singleton<ChallengeManager>.Instance.CheckSuccess();
		}
	}

	// Token: 0x06000A53 RID: 2643 RVA: 0x0000912C File Offset: 0x0000732C
	public virtual void AddPlayerData(PlayerData pPlayerData, int pKartIndex)
	{
		if (Singleton<GameConfigurator>.Instance.PlayerDataList == null)
		{
			Singleton<GameConfigurator>.Instance.PlayerDataList = new PlayerData[6];
		}
		pPlayerData.KartIndex = pKartIndex;
		Singleton<GameConfigurator>.Instance.PlayerDataList[pKartIndex] = pPlayerData;
	}

	// Token: 0x06000A54 RID: 2644 RVA: 0x00009161 File Offset: 0x00007361
	public void PlayEndOfRaceSound(bool bSuccess)
	{
		if (Singleton<GameManager>.Instance.SoundManager)
		{
			Singleton<GameManager>.Instance.SoundManager.PlaySound((!bSuccess) ? ERaceSounds.FinishBad : ERaceSounds.FinishGood);
		}
	}

	// Token: 0x06000A55 RID: 2645 RVA: 0x00009193 File Offset: 0x00007393
	public void ValidateAdvantage()
	{
		this.PlaceVehicles = EVehiclePlacementState.ValidateAdvantage;
	}

	// Token: 0x06000A56 RID: 2646 RVA: 0x0000919C File Offset: 0x0000739C
	public void VehicleCreated()
	{
		this.m_bVehicleCreated = true;
	}

	// Token: 0x06000A57 RID: 2647 RVA: 0x0004715C File Offset: 0x0004535C
	public void SetInitialPlayerRank(int iKartIndex, int iRank)
	{
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoSetInitialPlayerRank(iKartIndex, iRank);
		}
		else
		{
			base.networkView.RPC("DoSetInitialPlayerRank", RPCMode.All, new object[]
			{
				iKartIndex,
				iRank
			});
		}
	}

	// Token: 0x06000A58 RID: 2648 RVA: 0x000091A5 File Offset: 0x000073A5
	[RPC]
	public void DoSetInitialPlayerRank(int iKartIndex, int iRank)
	{
		Singleton<GameConfigurator>.Instance.RankingManager.SetInitialRank(iKartIndex, iRank);
	}

	// Token: 0x06000A59 RID: 2649 RVA: 0x000471AC File Offset: 0x000453AC
	public void ComputePlayersRank(bool bChampionship, bool bScore, bool bInitialPlacement)
	{
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoComputePlayersRank(bChampionship, bScore, bInitialPlacement);
		}
		else
		{
			base.networkView.RPC("DoComputePlayersRank", RPCMode.All, new object[]
			{
				bChampionship,
				bScore,
				bInitialPlacement
			});
		}
	}

	// Token: 0x06000A5A RID: 2650 RVA: 0x000091B8 File Offset: 0x000073B8
	[RPC]
	public void DoComputePlayersRank(bool bChampionship, bool bScore, bool bInitialPlacement)
	{
		Singleton<GameConfigurator>.Instance.RankingManager.ComputePositions(bChampionship, bScore);
		if (bInitialPlacement)
		{
			this.m_bInitialPlacementConfigured = true;
		}
	}

	// Token: 0x06000A5B RID: 2651 RVA: 0x000091D8 File Offset: 0x000073D8
	public void RestartRanking()
	{
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoRestartRanking();
		}
		else
		{
			base.networkView.RPC("DoRestartRanking", RPCMode.All, new object[0]);
		}
	}

	// Token: 0x06000A5C RID: 2652 RVA: 0x00009206 File Offset: 0x00007406
	[RPC]
	public void DoRestartRanking()
	{
		Singleton<GameConfigurator>.Instance.RankingManager.RestartRace();
	}

	// Token: 0x06000A5D RID: 2653 RVA: 0x00047204 File Offset: 0x00045404
	public void PlayerFinish(int iKartIndex, int iScore)
	{
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoPlayerFinish(iKartIndex, iScore);
		}
		else
		{
			base.networkView.RPC("DoPlayerFinish", RPCMode.All, new object[]
			{
				iKartIndex,
				iScore
			});
		}
	}

	// Token: 0x06000A5E RID: 2654 RVA: 0x00009217 File Offset: 0x00007417
	[RPC]
	public void DoPlayerFinish(int iKartIndex, int iScore)
	{
		Singleton<GameConfigurator>.Instance.RankingManager.PlayerFinish(iKartIndex, iScore);
	}

	// Token: 0x06000A5F RID: 2655 RVA: 0x0000922A File Offset: 0x0000742A
	public void ResetRace()
	{
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoResetRace();
		}
		else
		{
			base.networkView.RPC("DoResetRace", RPCMode.All, new object[0]);
		}
	}

	// Token: 0x06000A60 RID: 2656 RVA: 0x00009258 File Offset: 0x00007458
	[RPC]
	public void DoResetRace()
	{
		Singleton<GameConfigurator>.Instance.RankingManager.ResetRace();
	}

	// Token: 0x06000A61 RID: 2657 RVA: 0x00009269 File Offset: 0x00007469
	public virtual void FillResults()
	{
		base.Hud.EndRace();
	}

	// Token: 0x06000A62 RID: 2658 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void UpdateScores()
	{
	}

	// Token: 0x06000A63 RID: 2659 RVA: 0x00047254 File Offset: 0x00045454
	protected Kart GetHumanKart(ref int rpRankOffset, ref int rpHumanIndex)
	{
		Kart humanKart = base.GetHumanKart();
		if (humanKart)
		{
			rpRankOffset = Singleton<GameConfigurator>.Instance.RankingManager.GetScoreData(humanKart.GetVehicleId()).RacePosition;
			rpHumanIndex = humanKart.GetVehicleId();
			return humanKart;
		}
		return null;
	}

	// Token: 0x06000A64 RID: 2660 RVA: 0x00009276 File Offset: 0x00007476
	public void PlayerDisconnected(Kart _Kart)
	{
		if (_Kart)
		{
			_Kart.OnRaceEnded = (Action<RcVehicle>)Delegate.Combine(_Kart.OnRaceEnded, new Action<RcVehicle>(this.IANetRaceEnded));
		}
	}

	// Token: 0x04000A47 RID: 2631
	protected GkAIManager _aiManager;

	// Token: 0x04000A48 RID: 2632
	public EVehiclePlacementState PlaceVehicles;

	// Token: 0x04000A49 RID: 2633
	protected Transform[] StartPositions;

	// Token: 0x04000A4A RID: 2634
	private GameObject _start;

	// Token: 0x04000A4B RID: 2635
	private GameObject _pathResource;

	// Token: 0x04000A4C RID: 2636
	protected bool _hasStart;

	// Token: 0x04000A4D RID: 2637
	protected ChanceDispatcher _chanceDispatcher;

	// Token: 0x04000A4E RID: 2638
	protected bool m_bVehicleCreated;

	// Token: 0x04000A4F RID: 2639
	protected bool m_bInitialPlacementConfigured;
}

﻿using System;
using UnityEngine;

// Token: 0x02000211 RID: 529
public class RcKinematicWheel : RcPhysicWheel
{
	// Token: 0x06000E9E RID: 3742 RVA: 0x0000C121 File Offset: 0x0000A321
	public RcKinematicWheel()
	{
		this.m_massOnAnchor = 1f;
		this.m_fStretchSpeed = 0f;
		this.Reset();
	}

	// Token: 0x170001DE RID: 478
	// (get) Token: 0x06000E9F RID: 3743 RVA: 0x0000C150 File Offset: 0x0000A350
	public float AnchorSpeed
	{
		get
		{
			return this.m_fAnchorSpeed;
		}
	}

	// Token: 0x06000EA0 RID: 3744 RVA: 0x0005CD08 File Offset: 0x0005AF08
	public void updateAnchor(Vector3 _anchorPoint, Vector3 _axis, float _massOnAnchor)
	{
		Vector3 vector = _anchorPoint - this.m_vAnchorPoint;
		vector -= Vector3.Dot(vector, _axis) * _axis;
		this.m_fStretchTolerance = this.m_fNaturalSlope * vector.magnitude;
		this.m_vAnchorPoint = _anchorPoint;
		this.mAxis = _axis;
		this.m_massOnAnchor = _massOnAnchor;
	}

	// Token: 0x06000EA1 RID: 3745 RVA: 0x0000C158 File Offset: 0x0000A358
	public void SetMasks(LayerMask collideWith, LayerMask gripWith, LayerMask deathMask)
	{
		this.m_WheelsCollideWith = collideWith;
		this.m_WheelsGripWith = gripWith;
		this.m_WheelsDeathMask = deathMask;
	}

	// Token: 0x06000EA2 RID: 3746 RVA: 0x0005CD60 File Offset: 0x0005AF60
	public override void Start()
	{
		base.Start();
		this.m_pRay = default(Ray);
	}

	// Token: 0x06000EA3 RID: 3747 RVA: 0x0005CD84 File Offset: 0x0005AF84
	public void Reset()
	{
		this.mAxis = Vector3.up;
		this.m_vRestContactPoint = Vector3.zero;
		this.m_vAnchorPoint = Vector3.zero;
		this.m_fAnchorSpeed = 0f;
		this.m_fOldStretch = 0f;
		this.m_fStretch = 0f;
		this.m_bOnGround = false;
		this.m_oGroundCharac.normal = Vector3.up;
		this.m_oGroundCharac.surface = 0;
	}

	// Token: 0x06000EA4 RID: 3748 RVA: 0x0005CDF8 File Offset: 0x0005AFF8
	private bool TestCollision(Vector3 src, float maxStep)
	{
		int layerMask = this.m_WheelsCollideWith.value | this.m_WheelsDeathMask.value;
		src += (this.m_fMaxCompression + maxStep) * this.mAxis;
		this.m_pRay.origin = src;
		this.m_pRay.direction = -this.mAxis;
		RaycastHit raycastHit;
		bool result;
		if (this.m_bSphereCast)
		{
			result = Physics.SphereCast(this.m_pRay, this.m_fRadius, out raycastHit, maxStep + this.m_fMaxCompression + this.m_fRadius, layerMask);
		}
		else
		{
			result = Physics.Raycast(this.m_pRay, out raycastHit, maxStep + this.m_fMaxCompression + this.m_fRadius, layerMask);
		}
		if (Mathf.Abs(Vector3.Dot(raycastHit.normal, this.mAxis)) < 0.5f)
		{
			result = false;
		}
		this.m_oGroundCharac.point = raycastHit.point;
		this.m_oGroundCharac.normal = raycastHit.normal;
		this.m_oGroundCharac.surface = 0;
		if (raycastHit.collider != null && raycastHit.collider.gameObject != null)
		{
			this.m_oGroundCharac.surface = raycastHit.collider.gameObject.layer;
		}
		return result;
	}

	// Token: 0x06000EA5 RID: 3749 RVA: 0x0005CF48 File Offset: 0x0005B148
	public void Manage(float _deltaTime)
	{
		bool hit = this.TestCollision(this.m_vAnchorPoint, _deltaTime * 60f);
		if (this.m_oGroundCharac.surface != 0)
		{
			if ((1 << this.m_oGroundCharac.surface & this.m_WheelsCollideWith.value) == 0)
			{
				hit = false;
			}
			if ((1 << this.m_oGroundCharac.surface & this.m_WheelsGripWith.value) != 0)
			{
				this.m_fForwardGrip = 1f;
				this.m_fSideGrip = 1f;
			}
			else
			{
				this.m_fForwardGrip = 0f;
				this.m_fSideGrip = 0f;
			}
		}
		float num = 0f;
		if (this.m_bOnGround)
		{
			float num2 = Vector3.Dot(Physics.gravity, this.mAxis);
			num2 += (this.m_fDamping * this.m_fStretchSpeed + this.m_fSpring * this.m_fStretch) / this.m_massOnAnchor;
			num = num2 * _deltaTime;
		}
		else if (this.m_fAnchorSpeed > -3f)
		{
			num = -10f * _deltaTime;
		}
		this.m_fAnchorSpeed = Mathf.Clamp(this.m_fAnchorSpeed + num, -3f, 3f);
		this.m_vRestContactPoint = this.m_vAnchorPoint + this.mAxis * this.m_fAnchorSpeed * _deltaTime;
		this.m_fOldStretch = this.m_fStretch;
		this.UpdateStretch(hit, _deltaTime);
	}

	// Token: 0x06000EA6 RID: 3750 RVA: 0x0005D0B0 File Offset: 0x0005B2B0
	public void AdaptWithOffset(RcKinematicWheel wheel, Vector3 offset, float _deltaTime)
	{
		this.m_vAnchorPoint = wheel.m_vAnchorPoint + offset;
		this.m_vRestContactPoint = wheel.m_vRestContactPoint + offset;
		this.m_oGroundCharac = wheel.m_oGroundCharac;
		this.m_oGroundCharac.point = this.m_oGroundCharac.point + offset;
		this.m_fAnchorSpeed = wheel.m_fAnchorSpeed;
		this.m_bOnGround = wheel.m_bOnGround;
		this.mAxis = wheel.mAxis;
		this.m_massOnAnchor = wheel.m_massOnAnchor;
		this.m_fForwardGrip = wheel.m_fForwardGrip;
		this.m_fSideGrip = wheel.m_fSideGrip;
		if (wheel != this)
		{
			this.m_fOldStretch = this.m_fStretch;
		}
		this.UpdateStretch(wheel.m_bOnGround, _deltaTime);
	}

	// Token: 0x06000EA7 RID: 3751 RVA: 0x0005D174 File Offset: 0x0005B374
	protected void UpdateStretch(bool _hit, float _deltaTime)
	{
		float num = this.m_fRadius - Vector3.Dot(this.m_vRestContactPoint - this.m_oGroundCharac.point, this.mAxis);
		if (_hit && num >= 0f)
		{
			float num2 = num - this.m_fStretch;
			if (num2 > 0f)
			{
				if (num2 > this.m_fStretchTolerance)
				{
					num2 = this.m_fStretchTolerance;
				}
				this.m_vRestContactPoint += this.mAxis * num2;
				num -= num2;
			}
			if (num > this.m_fMaxCompression)
			{
				this.m_vRestContactPoint = this.m_oGroundCharac.point + (this.m_fRadius - this.m_fMaxCompression) * this.mAxis;
				num = this.m_fMaxCompression;
			}
			this.m_fStretch = num;
			this.m_bOnGround = true;
		}
		else
		{
			this.m_fStretch = 0f;
			this.m_bOnGround = false;
		}
		this.m_fStretchSpeed = Mathf.Clamp((this.m_fStretch - this.m_fOldStretch) / _deltaTime, -10f, 10f);
	}

	// Token: 0x04000E10 RID: 3600
	private const float m_fLandAnchor = 3f;

	// Token: 0x04000E11 RID: 3601
	private const float m_fLandAnchorSpeed = 10f;

	// Token: 0x04000E12 RID: 3602
	public bool m_bSphereCast;

	// Token: 0x04000E13 RID: 3603
	public float m_fNaturalSlope = 0.05f;

	// Token: 0x04000E14 RID: 3604
	private Vector3 mAxis;

	// Token: 0x04000E15 RID: 3605
	private float m_fAnchorSpeed;

	// Token: 0x04000E16 RID: 3606
	private Vector3 m_vAnchorPoint;

	// Token: 0x04000E17 RID: 3607
	private float m_massOnAnchor;

	// Token: 0x04000E18 RID: 3608
	private float m_fOldStretch;

	// Token: 0x04000E19 RID: 3609
	private float m_fStretchSpeed;

	// Token: 0x04000E1A RID: 3610
	private float m_fStretchTolerance;

	// Token: 0x04000E1B RID: 3611
	private LayerMask m_WheelsCollideWith;

	// Token: 0x04000E1C RID: 3612
	private LayerMask m_WheelsGripWith;

	// Token: 0x04000E1D RID: 3613
	private LayerMask m_WheelsDeathMask;

	// Token: 0x04000E1E RID: 3614
	private Ray m_pRay;

	// Token: 0x04000E1F RID: 3615
	private float m_fLastHeight;

	// Token: 0x04000E20 RID: 3616
	private bool m_bLastHeightValid;
}

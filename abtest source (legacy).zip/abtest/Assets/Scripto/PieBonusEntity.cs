﻿using System;
using UnityEngine;

// Token: 0x020000EA RID: 234
public class PieBonusEntity : MalusBonusEntity
{
	// Token: 0x06000643 RID: 1603 RVA: 0x00031248 File Offset: 0x0002F448
	public PieBonusEntity()
	{
		this.m_bIsOnGround = false;
		this.m_fTimerNoPhysic = 0f;
		this.m_fTimerSecure = 0f;
		this.m_fCurrentSpeed = 0f;
		this.m_Direction = Vector3.zero;
		this.DestructionParticle = null;
		this.m_pDestructionParticle = null;
		this.m_eItem = EITEM.ITEM_PIE;
		this.IdealPath = null;
		this.m_PathPosition = MultiPathPosition.UNDEFINED_MP_POS;
	}

	// Token: 0x170000FD RID: 253
	// (get) Token: 0x06000644 RID: 1604 RVA: 0x00006713 File Offset: 0x00004913
	// (set) Token: 0x06000645 RID: 1605 RVA: 0x0000671B File Offset: 0x0000491B
	public int Index
	{
		get
		{
			return this._index;
		}
		set
		{
			this._index = value;
		}
	}

	// Token: 0x06000646 RID: 1606 RVA: 0x00006724 File Offset: 0x00004924
	public Vector2 GetFlatVelocity()
	{
		return new Vector2(this.m_vVelocity.x, this.m_vVelocity.z);
	}

	// Token: 0x06000647 RID: 1607 RVA: 0x000312B8 File Offset: 0x0002F4B8
	public override void Awake()
	{
		base.Awake();
		this.m_pRigidBody = base.GetComponent<Rigidbody>();
		this.m_pDestructionParticle = (GameObject)UnityEngine.Object.Instantiate(this.DestructionParticle);
		this.m_pDestructionParticle.transform.parent = this.m_pTransform.transform.parent;
		this.m_bSynchronizePosition = true;
	}

	// Token: 0x06000648 RID: 1608 RVA: 0x00006741 File Offset: 0x00004941
	public override void Start()
	{
		this.SoundSplatch = this.m_pDestructionParticle.GetComponent<AudioSource>();
		this.m_pHumanPlayer = Singleton<GameManager>.Instance.GameMode.GetHumanKart();
	}

	// Token: 0x06000649 RID: 1609 RVA: 0x00031314 File Offset: 0x0002F514
	public override void Update()
	{
		base.Update();
		float deltaTime = Time.deltaTime;
		if (this.m_eState > BonusEntity.BonusState.BONUS_LAUNCHED && this.m_fTimerNoPhysic < this.TimeNoPhysic)
		{
			this.m_fTimerNoPhysic += deltaTime;
			if (this.m_fTimerNoPhysic > this.TimeNoPhysic)
			{
				Physics.IgnoreCollision(this.m_pCollider, this.m_pLauncher.Transform.parent.collider, false);
			}
		}
		if (this.m_eState == BonusEntity.BonusState.BONUS_ANIMLAUNCHED && this.m_bBehind)
		{
			this.m_fTimerSecure += deltaTime;
			if (this.m_fTimerSecure > 5f)
			{
				base.NetDestroy();
			}
		}
		if (this.TrailParticle && !this.TrailParticle.isPlaying && this.m_eState == BonusEntity.BonusState.BONUS_LAUNCHED && !this.m_bBehind)
		{
			this.m_TrailTimer += deltaTime;
			if (this.m_TrailTimer > 0.05f)
			{
				this.m_TrailTimer = 0f;
				this.TrailParticle.Clear();
				this.TrailParticle.Play();
			}
		}
		if (this.CheckHUDRadar())
		{
			this.IdealPath.UpdateMPPosition(ref this.m_PathPosition, this.m_pTransform.position, 0, 0, false);
			MultiPathPosition undefined_MP_POS = MultiPathPosition.UNDEFINED_MP_POS;
			this.IdealPath.UpdateMPPosition(ref undefined_MP_POS, this.m_pHumanPlayer.Transform.position, 0, 0, false);
			float distToEndLine = this.IdealPath.GetDistToEndLine(this.m_PathPosition);
			float distToEndLine2 = this.IdealPath.GetDistToEndLine(undefined_MP_POS);
			Vector3 vector = this.m_pTransform.position - this.m_pHumanPlayer.Transform.position;
			float num = distToEndLine - distToEndLine2;
			if (num >= 0f && num <= 50f)
			{
				float d = Vector3.Dot(vector, this.m_pHumanPlayer.Transform.forward);
				Vector3 b = this.m_pHumanPlayer.Transform.position + this.m_pHumanPlayer.Transform.forward * d;
				float num2 = (this.m_pTransform.position - b).magnitude;
				num2 *= this.AngleDir(this.m_pHumanPlayer.Transform.forward, vector, this.m_pHumanPlayer.Transform.up);
				this.UpdateHudRadar(num2, num);
			}
			else
			{
				this.DisableHudRadar();
			}
		}
		else
		{
			this.DisableHudRadar();
		}
	}

	// Token: 0x0600064A RID: 1610 RVA: 0x0003159C File Offset: 0x0002F79C
	protected virtual void DisableHudRadar()
	{
		if (Singleton<GameManager>.Instance.GameMode != null && Singleton<GameManager>.Instance.GameMode.Hud && Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp)
		{
			Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp.Pies[this._index].enabled = false;
		}
	}

	// Token: 0x0600064B RID: 1611 RVA: 0x00006769 File Offset: 0x00004969
	protected virtual void UpdateHudRadar(float pHorizontalDist, float pDistance)
	{
		if (Singleton<GameManager>.Instance.GameMode != null)
		{
			Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp.UpdatePie(this._index, pHorizontalDist, pDistance);
		}
	}

	// Token: 0x0600064C RID: 1612 RVA: 0x000067A1 File Offset: 0x000049A1
	protected virtual bool CheckHUDRadar()
	{
		return this.m_bActive && !this.m_bBehind && this.IdealPath != null && !this.cMeshRenderer.isVisible;
	}

	// Token: 0x0600064D RID: 1613 RVA: 0x00031620 File Offset: 0x0002F820
	public override void OnCollisionEnter(Collision collision)
	{
		base.OnCollisionEnter(collision);
		if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
		{
			if (!this.m_bBehind)
			{
				this.PerformCollision(collision);
			}
			else
			{
				int num = 1 << collision.gameObject.layer;
				if (this.m_eState < BonusEntity.BonusState.BONUS_ONGROUND && (num & this.LayerStick) != 0)
				{
					this.StickOnGround(collision.contacts[0].normal);
				}
			}
		}
	}

	// Token: 0x0600064E RID: 1614 RVA: 0x000067DB File Offset: 0x000049DB
	public void OnCollisionStay(Collision collision)
	{
		if ((Network.peerType == NetworkPeerType.Disconnected || Network.isServer) && !this.m_bBehind)
		{
			this.PerformCollision(collision);
		}
	}

	// Token: 0x0600064F RID: 1615 RVA: 0x000316A8 File Offset: 0x0002F8A8
	public void PerformCollision(Collision collision)
	{
		if (collision.collider != null && collision.collider.isTrigger)
		{
			return;
		}
		for (int i = 0; i < collision.contacts.Length; i++)
		{
			ContactPoint contactPoint = collision.contacts[i];
			if (contactPoint.normal.y < 0.5f)
			{
				this.DestroyByCollision();
				break;
			}
		}
	}

	// Token: 0x06000650 RID: 1616 RVA: 0x00006803 File Offset: 0x00004A03
	public void DestroyByCollision()
	{
		if (this.m_bActive)
		{
			base.NetDestroy();
		}
	}

	// Token: 0x06000651 RID: 1617 RVA: 0x00006816 File Offset: 0x00004A16
	public override void DoOnTriggerEnter(GameObject other, int otherlayer)
	{
		base.DoOnTriggerEnter(other, otherlayer);
	}

	// Token: 0x06000652 RID: 1618 RVA: 0x00031728 File Offset: 0x0002F928
	public virtual void FixedUpdate()
	{
		if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
		{
			if (!this.m_bBehind)
			{
				if (this.m_pRigidBody.velocity.z != 0f)
				{
					Vector3 vVelocity = this.m_vVelocity;
					vVelocity.y = this.m_pRigidBody.velocity.y;
					this.m_pRigidBody.velocity = vVelocity;
					this.m_pRigidBody.velocity = this.m_fCurrentSpeed * this.m_pRigidBody.velocity.normalized;
					this.m_pRigidBody.AddForce(new Vector3(0f, -this.GravityForward, 0f), ForceMode.Impulse);
				}
			}
			else
			{
				this.m_pRigidBody.AddForce(new Vector3(0f, -this.GravityBackward, 0f), ForceMode.Impulse);
			}
		}
	}

	// Token: 0x06000653 RID: 1619 RVA: 0x00031810 File Offset: 0x0002FA10
	private float AngleDir(Vector3 pForward, Vector3 pTargetDir, Vector3 pUp)
	{
		Vector3 lhs = Vector3.Cross(pForward, pTargetDir);
		float num = Vector3.Dot(lhs, pUp);
		if ((double)num > 0.0)
		{
			return 1f;
		}
		if ((double)num < 0.0)
		{
			return -1f;
		}
		return 0f;
	}

	// Token: 0x06000654 RID: 1620 RVA: 0x00031860 File Offset: 0x0002FA60
	public override void SetActive(bool _Active)
	{
		if (_Active)
		{
			if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
			{
				if (!this.m_bBehind)
				{
					this.ComputeBaseSpeed();
					this.m_vVelocity = base.LaunchHorizontalDirection * this.m_fCurrentSpeed;
					this.m_pRigidBody.velocity = this.m_vVelocity;
				}
				else
				{
					float d = this.SpeedBackward / 3.6f;
					this.m_pRigidBody.AddForce((-this.m_pLauncher.Transform.parent.forward + this.m_pLauncher.Transform.parent.up).normalized * d, ForceMode.VelocityChange);
				}
			}
		}
		else
		{
			this.DisableHudRadar();
		}
		base.SetActive(_Active);
		if (_Active)
		{
			Physics.IgnoreCollision(this.m_pCollider, this.m_pLauncher.Transform.parent.collider, true);
		}
	}

	// Token: 0x06000655 RID: 1621 RVA: 0x0003195C File Offset: 0x0002FB5C
	public override void DoDestroy()
	{
		base.DoDestroy();
		this.m_pDestructionParticle.transform.position = this.m_pTransform.position;
		this.m_pDestructionParticle.particleSystem.Play();
		if (this.SoundTravel && this.SoundSplatch)
		{
			this.SoundTravel.Stop();
			this.SoundSplatch.Play();
		}
		if (this.TrailParticle)
		{
			this.TrailParticle.Stop();
		}
		this.SetActive(false);
	}

	// Token: 0x06000656 RID: 1622 RVA: 0x000319F4 File Offset: 0x0002FBF4
	public override void ActivateBonusEffect(Kart _Kart)
	{
		base.ActivateBonusEffect(_Kart);
		if (!this.m_bBehind)
		{
			_Kart.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_UPSIDE_DOWN).BonusEffectDirection = this.m_eImpactDirection;
			_Kart.GetBonusMgr().GetBonusEffectMgr().ActivateBonusEffect(EBonusEffect.BONUSEFFECT_UPSIDE_DOWN);
		}
		else
		{
			_Kart.GetBonusMgr().GetBonusEffectMgr().ActivateBonusEffect(EBonusEffect.BONUSEFFECT_SPIN);
		}
		if (_Kart != this.m_pLauncher)
		{
			this.m_pLauncher.KartSound.PlayVoice(KartSound.EVoices.Good);
			this.m_pLauncher.Anim.LaunchSuccessAnim(true);
		}
	}

	// Token: 0x06000657 RID: 1623 RVA: 0x00006820 File Offset: 0x00004A20
	public override void Launch()
	{
		base.Launch();
	}

	// Token: 0x06000658 RID: 1624 RVA: 0x00006828 File Offset: 0x00004A28
	public void Launch(bool _Behind)
	{
		this.Launch(this.m_pLauncher.Transform.position, this.m_pLauncher.Transform.parent.rotation, _Behind);
	}

	// Token: 0x06000659 RID: 1625 RVA: 0x00006053 File Offset: 0x00004253
	public void NetLaunch(NetworkViewID launcherViewID, bool _Behind)
	{
		this.m_pNetworkView.RPC("Launch", RPCMode.All, new object[]
		{
			launcherViewID,
			_Behind
		});
	}

	// Token: 0x0600065A RID: 1626 RVA: 0x00031A8C File Offset: 0x0002FC8C
	public void Launch(Vector3 position, Quaternion rotation, bool _Behind)
	{
		this.m_bBehind = _Behind;
		this.m_bIsOnGround = false;
		this.cMeshFilter.mesh = this.State0;
		this.cMeshRenderer.material = this.MatState0;
		this.m_pCollider.isTrigger = false;
		base.gameObject.layer = this.m_pLayerBonus;
		this.m_fTimerNoPhysic = 0f;
		this.m_fTimerSecure = 0f;
		this.Launch();
		this.m_pTransform.parent.rotation = Quaternion.identity;
		this.m_pTransform.rotation = Quaternion.identity;
		this.m_pRigidBody.isKinematic = false;
		this.m_pRigidBody.velocity = Vector3.zero;
		Vector3 position2 = Vector3.zero;
		if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
		{
			if (this.m_bBehind)
			{
				position2 = position + rotation * new Vector3(0f, 1f, -0.5f);
			}
			else
			{
				this.m_Direction = position + rotation * new Vector3(0f, 0.5f, 3f);
				position2 = this.m_Direction;
				this.m_vVelocity = Vector3.zero;
			}
			this.m_pTransform.parent.position = position2;
			this.m_pRigidBody.position = position2;
		}
		if (this.SoundLaunch && this.SoundTravel)
		{
			this.SoundLaunch.Play();
			this.SoundTravel.Play();
		}
		if (this.Anim && !_Behind)
		{
			this.Anim.Play("PieRun");
		}
		else if (this.Anim)
		{
			this.Anim.Stop();
		}
		if (this.TrailParticle)
		{
			this.TrailParticle.Stop();
			this.TrailParticle.Clear();
		}
	}

	// Token: 0x0600065B RID: 1627 RVA: 0x00006856 File Offset: 0x00004A56
	public override bool IsOnGround()
	{
		return this.m_bIsOnGround;
	}

	// Token: 0x0600065C RID: 1628 RVA: 0x0000685E File Offset: 0x00004A5E
	public override void LaunchAnimFinished()
	{
		base.LaunchAnimFinished();
	}

	// Token: 0x0600065D RID: 1629 RVA: 0x00031C8C File Offset: 0x0002FE8C
	public virtual void StickOnGround(Vector3 normal)
	{
		if (this.m_bActive)
		{
			if (Network.peerType != NetworkPeerType.Disconnected && this.m_pNetworkView != null)
			{
				this.m_pNetworkView.RPC("OnStickOnGround", RPCMode.All, new object[]
				{
					normal
				});
			}
			else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
			{
				this.DoStickOnGround(normal);
			}
		}
	}

	// Token: 0x0600065E RID: 1630 RVA: 0x00031D08 File Offset: 0x0002FF08
	public virtual void DoStickOnGround(Vector3 normal)
	{
		this.m_pTransform.rotation = Quaternion.identity;
		Vector3 vector = this.m_pTransform.right;
		Vector3 up = this.m_pTransform.up;
		Vector3 vector2 = this.m_pTransform.forward;
		vector = Vector3.Cross(normal, vector2);
		vector.Normalize();
		vector2 = Vector3.Cross(vector, normal);
		vector2.Normalize();
		this.m_pTransform.right = vector;
		this.m_pTransform.up = normal;
		this.m_pTransform.forward = vector2;
		this.cMeshFilter.mesh = this.State1;
		this.cMeshRenderer.material = this.MatState1;
		this.m_bIsOnGround = true;
		this.m_pRigidBody.isKinematic = true;
		base.collider.isTrigger = true;
		base.gameObject.layer = this.m_pLayerBonus;
		this.m_pDestructionParticle.transform.position = this.m_pTransform.position;
		this.m_pDestructionParticle.particleSystem.Play();
		if (this.SoundTravel && this.SoundSplatch)
		{
			this.SoundTravel.Stop();
			this.SoundSplatch.Play();
		}
	}

	// Token: 0x0600065F RID: 1631 RVA: 0x00031E48 File Offset: 0x00030048
	public void ComputeBaseSpeed()
	{
		float num = this.SpeedForward / 3.6f;
		this.m_fCurrentSpeed = num + this.m_pLauncher.GetBonusMgr().GetBonusValue(EITEM.ITEM_PIE, EBonusCustomEffect.SPEED) * num / 100f;
	}

	// Token: 0x06000660 RID: 1632 RVA: 0x00006866 File Offset: 0x00004A66
	public override void PerformBonusCollision(BonusEntity _Bonus)
	{
		if (_Bonus != null && _Bonus is SpringBonusEntity)
		{
			this.m_eState = BonusEntity.BonusState.BONUS_TRIGGERED;
			_Bonus.NetDestroy();
		}
		else
		{
			base.PerformBonusCollision(_Bonus);
		}
	}

	// Token: 0x04000628 RID: 1576
	public float SpeedForward;

	// Token: 0x04000629 RID: 1577
	public float SpeedBackward;

	// Token: 0x0400062A RID: 1578
	public Mesh State0;

	// Token: 0x0400062B RID: 1579
	public Mesh State1;

	// Token: 0x0400062C RID: 1580
	public Material MatState0;

	// Token: 0x0400062D RID: 1581
	public Material MatState1;

	// Token: 0x0400062E RID: 1582
	public float GravityForward;

	// Token: 0x0400062F RID: 1583
	public float GravityBackward;

	// Token: 0x04000630 RID: 1584
	public float TimeNoPhysic;

	// Token: 0x04000631 RID: 1585
	protected Rigidbody m_pRigidBody;

	// Token: 0x04000632 RID: 1586
	private bool m_bIsOnGround;

	// Token: 0x04000633 RID: 1587
	public MeshFilter cMeshFilter;

	// Token: 0x04000634 RID: 1588
	public MeshRenderer cMeshRenderer;

	// Token: 0x04000635 RID: 1589
	private float m_fTimerNoPhysic;

	// Token: 0x04000636 RID: 1590
	private float m_fTimerSecure;

	// Token: 0x04000637 RID: 1591
	private Vector3 m_vVelocity;

	// Token: 0x04000638 RID: 1592
	protected float m_fCurrentSpeed;

	// Token: 0x04000639 RID: 1593
	protected Vector3 m_Direction;

	// Token: 0x0400063A RID: 1594
	public GameObject DestructionParticle;

	// Token: 0x0400063B RID: 1595
	protected GameObject m_pDestructionParticle;

	// Token: 0x0400063C RID: 1596
	protected Kart m_pHumanPlayer;

	// Token: 0x0400063D RID: 1597
	public RcMultiPath IdealPath;

	// Token: 0x0400063E RID: 1598
	protected MultiPathPosition m_PathPosition;

	// Token: 0x0400063F RID: 1599
	protected int _index;

	// Token: 0x04000640 RID: 1600
	public Animation Anim;

	// Token: 0x04000641 RID: 1601
	public ParticleSystem TrailParticle;

	// Token: 0x04000642 RID: 1602
	protected float m_TrailTimer;

	// Token: 0x04000643 RID: 1603
	public AudioSource SoundLaunch;

	// Token: 0x04000644 RID: 1604
	public AudioSource SoundTravel;

	// Token: 0x04000645 RID: 1605
	protected AudioSource SoundSplatch;
}

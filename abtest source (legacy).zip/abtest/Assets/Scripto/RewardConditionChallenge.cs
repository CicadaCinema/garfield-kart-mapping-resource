﻿using System;

// Token: 0x0200015C RID: 348
public class RewardConditionChallenge : RewardConditionBase
{
	// Token: 0x0600098F RID: 2447 RVA: 0x00003B7D File Offset: 0x00001D7D
	public override bool CanGiveReward()
	{
		return false;
	}

	// Token: 0x040009C4 RID: 2500
	public EDifficulty Difficulty;
}

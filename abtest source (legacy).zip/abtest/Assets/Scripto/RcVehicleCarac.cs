﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200020D RID: 525
public class RcVehicleCarac : MonoBehaviour
{
	// Token: 0x06000E7C RID: 3708 RVA: 0x0005BF00 File Offset: 0x0005A100
	public RcVehicleCarac()
	{
		this.m_fBrakingTime = 5f;
		this.m_fHardTerrainBrakingTime = 1f;
		this.m_fDecelerationTime = 10f;
		this.m_fTimeToMaxSteering = 0.3f;
		this.m_fDriftTimeToMaxSteering = 0.5f;
		this.m_fDriftResetSteeringNoInput = 1f;
		this.m_fResetSteeringNoInput = 1f;
		this.m_fResetSteeringOppositeInput = 0f;
		this.m_fSteeringTopSpeedMalusPrc = 0.1f;
		this.m_vSpeedRef = new List<float>();
		this.m_vTurningRadius = new List<float>();
		this.m_vDriftTurningRadius = new List<float>();
		this.m_vDriftNoInputTurningRadius = new List<float>();
		this.m_vCounterSteeringTurningRadius = new List<float>();
	}

	// Token: 0x06000E7D RID: 3709 RVA: 0x0005BFB0 File Offset: 0x0005A1B0
	public virtual void Start()
	{
		RcVehicle componentInChildren = base.transform.parent.GetComponentInChildren<RcVehicle>();
		if (componentInChildren != null)
		{
			this.m_fBrakingMSS = componentInChildren.GetMaxSpeed() / this.m_fBrakingTime;
			this.m_fHardTerrainBrakingMSS = componentInChildren.GetMaxSpeed() / this.m_fHardTerrainBrakingTime;
			this.m_fDecelerationMSS = componentInChildren.GetMaxSpeed() / this.m_fDecelerationTime;
		}
		if (this.m_vDriftTurningRadius.Count == 0)
		{
			foreach (float num in this.m_vTurningRadius)
			{
				float item = num;
				this.m_vDriftTurningRadius.Add(item);
			}
		}
		if (this.m_vDriftNoInputTurningRadius.Count == 0)
		{
			foreach (float num2 in this.m_vTurningRadius)
			{
				float item2 = num2;
				this.m_vDriftNoInputTurningRadius.Add(item2);
			}
		}
		if (this.m_vCounterSteeringTurningRadius.Count == 0)
		{
			foreach (float num3 in this.m_vTurningRadius)
			{
				float item3 = num3;
				this.m_vCounterSteeringTurningRadius.Add(item3);
			}
		}
	}

	// Token: 0x06000E7E RID: 3710 RVA: 0x0000BF89 File Offset: 0x0000A189
	public float GetTimeToStop(float fromSpeed)
	{
		if (this.GetBrakingMSS() != 0f)
		{
			return Mathf.Abs(fromSpeed) / this.GetBrakingMSS();
		}
		return 0f;
	}

	// Token: 0x06000E7F RID: 3711 RVA: 0x0005C13C File Offset: 0x0005A33C
	public void ComputeHandling(float _speedMS, out VehicleHandling _handlingOut)
	{
		_handlingOut.speedMS = _speedMS;
		int i = 0;
		int count = this.m_vSpeedRef.Count;
		while (i < count)
		{
			if (_speedMS < this.GetSpeedRef(i) / 3.6f)
			{
				break;
			}
			i++;
		}
		if (i != 0)
		{
			i--;
		}
		float num = this.GetSpeedRef(i) / 3.6f;
		if (i < count - 1)
		{
			_handlingOut.minTurningRadius = RcUtils.LinearInterpolation(num, this.m_vTurningRadius[i], this.GetSpeedRef(i + 1) / 3.6f, this.m_vTurningRadius[i + 1], _speedMS);
			_handlingOut.driftTurningRadius = RcUtils.LinearInterpolation(num, this.m_vDriftTurningRadius[i], this.GetSpeedRef(i + 1) / 3.6f, this.m_vDriftTurningRadius[i + 1], _speedMS);
			_handlingOut.driftNoInputTurningRadius = RcUtils.LinearInterpolation(num, this.m_vDriftNoInputTurningRadius[i], this.GetSpeedRef(i + 1) / 3.6f, this.m_vDriftNoInputTurningRadius[i + 1], _speedMS);
			_handlingOut.counterSteeringTurningRadius = RcUtils.LinearInterpolation(num, this.m_vCounterSteeringTurningRadius[i], this.GetSpeedRef(i + 1) / 3.6f, this.m_vCounterSteeringTurningRadius[i + 1], _speedMS);
		}
		else if (i > 0)
		{
			_handlingOut.minTurningRadius = RcUtils.LinearInterpolation(this.GetSpeedRef(i - 1) / 3.6f, this.m_vTurningRadius[i - 1], num, this.m_vTurningRadius[i], _speedMS);
			_handlingOut.driftTurningRadius = RcUtils.LinearInterpolation(this.GetSpeedRef(i - 1) / 3.6f, this.m_vDriftTurningRadius[i - 1], num, this.m_vDriftTurningRadius[i], _speedMS);
			_handlingOut.driftNoInputTurningRadius = RcUtils.LinearInterpolation(this.GetSpeedRef(i - 1) / 3.6f, this.m_vDriftNoInputTurningRadius[i - 1], num, this.m_vDriftNoInputTurningRadius[i], _speedMS);
			_handlingOut.counterSteeringTurningRadius = RcUtils.LinearInterpolation(this.GetSpeedRef(i - 1) / 3.6f, this.m_vCounterSteeringTurningRadius[i - 1], num, this.m_vCounterSteeringTurningRadius[i], _speedMS);
		}
		else
		{
			_handlingOut.minTurningRadius = this.m_vTurningRadius[i];
			_handlingOut.driftTurningRadius = this.m_vDriftTurningRadius[i];
			_handlingOut.driftNoInputTurningRadius = this.m_vDriftNoInputTurningRadius[i];
			_handlingOut.counterSteeringTurningRadius = this.m_vCounterSteeringTurningRadius[i];
		}
		_handlingOut.timeToMaxSteering = this.GetTimeToMaxSteering();
		_handlingOut.driftTimeToMaxSteering = this.GetTimeToMaxSteering();
		_handlingOut.resetSteeringNoInput = this.GetResetSteeringNoInput();
		_handlingOut.driftResetSteeringNoInput = this.GetDriftResetSteeringNoInput();
		_handlingOut.resetSteeringOppositeInput = this.GetResetSteeringOppositeInput();
		_handlingOut.brakingMSS = this.GetBrakingMSS();
		_handlingOut.toofastBrakingMSS = this.GetHardTerrainBrakingMSS();
		_handlingOut.decelerationMSS = this.GetDecelerationMSS();
		_handlingOut.steeringTopSpeedMalus = this.GetSteeringTopSpeedMalusPrc();
	}

	// Token: 0x06000E80 RID: 3712 RVA: 0x0005C424 File Offset: 0x0005A624
	public float ComputeMinRadius(float _speedMS)
	{
		int i = 0;
		int count = this.m_vSpeedRef.Count;
		while (i < count)
		{
			if (_speedMS < this.GetSpeedRef(i) / 3.6f)
			{
				break;
			}
			i++;
		}
		i--;
		if (i < 0)
		{
			i = 0;
		}
		float num = this.GetSpeedRef(i) / 3.6f;
		if (i < count - 1)
		{
			return RcUtils.LinearInterpolation(num, this.m_vTurningRadius[i], this.GetSpeedRef(i + 1) / 3.6f, this.m_vTurningRadius[i + 1], _speedMS);
		}
		if (i > 0)
		{
			return RcUtils.LinearInterpolation(this.GetSpeedRef(i - 1) / 3.6f, this.m_vTurningRadius[i - 1], num, this.m_vTurningRadius[i], _speedMS);
		}
		return this.m_vTurningRadius[i];
	}

	// Token: 0x06000E81 RID: 3713 RVA: 0x0005C508 File Offset: 0x0005A708
	public float ComputeMaxSpeedForRadius(float _radius)
	{
		int i = 0;
		int count = this.m_vTurningRadius.Count;
		while (i < count)
		{
			if (_radius < this.m_vTurningRadius[i])
			{
				break;
			}
			i++;
		}
		i--;
		if (i < 0)
		{
			return this.GetSpeedRef(0) / 3.6f;
		}
		if (i < count - 1)
		{
			return RcUtils.LinearInterpolation(this.m_vTurningRadius[i], this.GetSpeedRef(i) / 3.6f, this.m_vTurningRadius[i + 1], this.GetSpeedRef(i + 1) / 3.6f, _radius);
		}
		if (i > 0)
		{
			return RcUtils.LinearInterpolation(this.m_vTurningRadius[i - 1], this.GetSpeedRef(i - 1) / 3.6f, this.m_vTurningRadius[i], this.GetSpeedRef(i) / 3.6f, _radius);
		}
		return this.GetSpeedRef(i) / 3.6f;
	}

	// Token: 0x06000E82 RID: 3714 RVA: 0x0000BFAE File Offset: 0x0000A1AE
	public virtual float GetSpeedRef(int _Index)
	{
		return this.m_vSpeedRef[_Index];
	}

	// Token: 0x06000E83 RID: 3715 RVA: 0x0000BFBC File Offset: 0x0000A1BC
	public float GetSteeringTopSpeedMalusPrc()
	{
		return this.m_fSteeringTopSpeedMalusPrc;
	}

	// Token: 0x06000E84 RID: 3716 RVA: 0x0000BFC4 File Offset: 0x0000A1C4
	public virtual float GetDecelerationMSS()
	{
		return this.m_fDecelerationMSS;
	}

	// Token: 0x06000E85 RID: 3717 RVA: 0x0000BFCC File Offset: 0x0000A1CC
	public virtual float GetBrakingMSS()
	{
		return this.m_fBrakingMSS;
	}

	// Token: 0x06000E86 RID: 3718 RVA: 0x0000BFD4 File Offset: 0x0000A1D4
	public virtual float GetHardTerrainBrakingMSS()
	{
		return this.m_fHardTerrainBrakingMSS;
	}

	// Token: 0x06000E87 RID: 3719 RVA: 0x0000BFDC File Offset: 0x0000A1DC
	public virtual float GetTimeToMaxSteering()
	{
		return this.m_fTimeToMaxSteering;
	}

	// Token: 0x06000E88 RID: 3720 RVA: 0x0000BFE4 File Offset: 0x0000A1E4
	public virtual float GetDriftTimeToMaxSteering()
	{
		return this.m_fDriftTimeToMaxSteering;
	}

	// Token: 0x06000E89 RID: 3721 RVA: 0x0000BFEC File Offset: 0x0000A1EC
	public virtual float GetResetSteeringNoInput()
	{
		return this.m_fResetSteeringNoInput;
	}

	// Token: 0x06000E8A RID: 3722 RVA: 0x0000BFF4 File Offset: 0x0000A1F4
	public virtual float GetDriftResetSteeringNoInput()
	{
		return this.m_fDriftResetSteeringNoInput;
	}

	// Token: 0x06000E8B RID: 3723 RVA: 0x0000BFFC File Offset: 0x0000A1FC
	public virtual float GetResetSteeringOppositeInput()
	{
		return this.m_fResetSteeringOppositeInput;
	}

	// Token: 0x04000DEA RID: 3562
	public float m_fHardTerrainBrakingTime;

	// Token: 0x04000DEB RID: 3563
	public float m_fBrakingTime;

	// Token: 0x04000DEC RID: 3564
	public float m_fDecelerationTime;

	// Token: 0x04000DED RID: 3565
	public float m_fTimeToMaxSteering;

	// Token: 0x04000DEE RID: 3566
	public float m_fDriftTimeToMaxSteering;

	// Token: 0x04000DEF RID: 3567
	public float m_fResetSteeringNoInput;

	// Token: 0x04000DF0 RID: 3568
	public float m_fDriftResetSteeringNoInput;

	// Token: 0x04000DF1 RID: 3569
	public float m_fResetSteeringOppositeInput;

	// Token: 0x04000DF2 RID: 3570
	public float m_fSteeringTopSpeedMalusPrc;

	// Token: 0x04000DF3 RID: 3571
	protected float m_fBrakingMSS;

	// Token: 0x04000DF4 RID: 3572
	protected float m_fHardTerrainBrakingMSS;

	// Token: 0x04000DF5 RID: 3573
	protected float m_fDecelerationMSS;

	// Token: 0x04000DF6 RID: 3574
	public List<float> m_vSpeedRef;

	// Token: 0x04000DF7 RID: 3575
	public List<float> m_vTurningRadius;

	// Token: 0x04000DF8 RID: 3576
	public List<float> m_vDriftTurningRadius;

	// Token: 0x04000DF9 RID: 3577
	public List<float> m_vDriftNoInputTurningRadius;

	// Token: 0x04000DFA RID: 3578
	public List<float> m_vCounterSteeringTurningRadius;
}

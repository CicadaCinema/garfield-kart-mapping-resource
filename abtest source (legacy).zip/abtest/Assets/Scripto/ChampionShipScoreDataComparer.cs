﻿using System;
using System.Collections.Generic;

// Token: 0x0200017C RID: 380
internal class ChampionShipScoreDataComparer : IComparer<int>
{
	// Token: 0x06000A27 RID: 2599 RVA: 0x00008EEB File Offset: 0x000070EB
	public ChampionShipScoreDataComparer(RaceScoreData[] pData)
	{
		this.m_pData = pData;
	}

	// Token: 0x06000A28 RID: 2600 RVA: 0x00046138 File Offset: 0x00044338
	public int Compare(int a, int b)
	{
		ChampionShipScoreData championShipScoreData = (ChampionShipScoreData)this.m_pData[a];
		ChampionShipScoreData championShipScoreData2 = (ChampionShipScoreData)this.m_pData[b];
		if (championShipScoreData.KartIndex == championShipScoreData2.KartIndex)
		{
			return 0;
		}
		if (championShipScoreData.ChampionshipScore != championShipScoreData2.ChampionshipScore)
		{
			return championShipScoreData2.ChampionshipScore.CompareTo(championShipScoreData.ChampionshipScore);
		}
		if (championShipScoreData2.IsAI == championShipScoreData.IsAI)
		{
			return championShipScoreData.PreviousChampionshipScore.CompareTo(championShipScoreData2.PreviousChampionshipScore);
		}
		if (championShipScoreData2.IsAI)
		{
			return championShipScoreData2.ChampionshipScore.CompareTo(championShipScoreData.ChampionshipScore + 1);
		}
		return championShipScoreData2.ChampionshipScore.CompareTo(championShipScoreData.ChampionshipScore - 1);
	}

	// Token: 0x04000A27 RID: 2599
	private RaceScoreData[] m_pData;
}

﻿using System;
using System.Collections.Generic;

// Token: 0x02000164 RID: 356
public abstract class RewardRandomBase : RewardUnlockableItem
{
	// Token: 0x0600099C RID: 2460 RVA: 0x000089CD File Offset: 0x00006BCD
	public RewardRandomBase()
	{
	}

	// Token: 0x040009D2 RID: 2514
	public List<string> Items = new List<string>();

	// Token: 0x040009D3 RID: 2515
	public List<ERarity> Rarities = new List<ERarity>();
}

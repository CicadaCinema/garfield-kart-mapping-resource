﻿using System;

// Token: 0x020001AA RID: 426
public class MenuRewardsCustomShown : MenuRewards
{
	// Token: 0x06000B74 RID: 2932 RVA: 0x0004CDD8 File Offset: 0x0004AFD8
	public override void OnEnter()
	{
		base.OnEnter();
		this._customs = Singleton<RewardManager>.Instance.PopLockedCustoms();
		this.LbMessage.text = string.Format(Localization.instance.Get("MENU_REWARDS_CUSTOMISATION_GROUPE"), Singleton<GameSaveManager>.Instance.GetCollectedCoins());
	}

	// Token: 0x06000B75 RID: 2933 RVA: 0x0004CE2C File Offset: 0x0004B02C
	public override void OnGoNext()
	{
		foreach (string text in this._customs)
		{
			if (text != null)
			{
				Singleton<GameSaveManager>.Instance.SetCustomState(text, E_UnlockableItemSate.NewLocked, false);
			}
		}
		base.OnGoNext();
	}

	// Token: 0x04000B36 RID: 2870
	private string[] _customs;
}

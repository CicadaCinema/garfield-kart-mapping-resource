﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020001F3 RID: 499
public class RcCatchUp : MonoBehaviour
{
	// Token: 0x06000D7D RID: 3453 RVA: 0x0000B36B File Offset: 0x0000956B
	public RcCatchUp()
	{
		this.m_oTabCatchUp = new List<RcCatchUp.CatchUpPair>();
	}

	// Token: 0x06000D7E RID: 3454 RVA: 0x0000B385 File Offset: 0x00009585
	public void AddFactor(float dist, float factor, float aiFactor)
	{
		this.m_oTabCatchUp.Add(new RcCatchUp.CatchUpPair(dist, factor, aiFactor));
	}

	// Token: 0x06000D7F RID: 3455 RVA: 0x00057C24 File Offset: 0x00055E24
	public void ComputeCatchUp(RcVehicle _pVehicle, float _distToEndOfRace, float _refDistToEndOfRace)
	{
		float num = 0f;
		if (this.m_bIsActivate && this.m_oTabCatchUp.Count > 0)
		{
			float num2 = _refDistToEndOfRace - _distToEndOfRace;
			RcCatchUp.CatchUpPair catchUpPair = this.m_oTabCatchUp[0];
			int i;
			for (i = 0; i < this.m_oTabCatchUp.Count; i++)
			{
				catchUpPair = this.m_oTabCatchUp[i];
				if (num2 < catchUpPair.distance)
				{
					break;
				}
			}
			if (i == 0 || i == this.m_oTabCatchUp.Count)
			{
				num = ((!_pVehicle.IsAutoPilot()) ? catchUpPair.factor : catchUpPair.aiFactor);
			}
			else
			{
				RcCatchUp.CatchUpPair catchUpPair2 = this.m_oTabCatchUp[i - 1];
				if (_pVehicle.IsAutoPilot())
				{
					num = RcUtils.LinearInterpolation(catchUpPair2.distance, catchUpPair2.aiFactor, catchUpPair.distance, catchUpPair.aiFactor, num2);
				}
				else
				{
					num = RcUtils.LinearInterpolation(catchUpPair2.distance, catchUpPair2.factor, catchUpPair.distance, catchUpPair.factor, num2);
				}
			}
		}
		_pVehicle.SetTempHandicap(-num);
	}

	// Token: 0x04000D27 RID: 3367
	public bool m_bIsActivate = true;

	// Token: 0x04000D28 RID: 3368
	public List<RcCatchUp.CatchUpPair> m_oTabCatchUp;

	// Token: 0x020001F4 RID: 500
	[Serializable]
	public class CatchUpPair
	{
		// Token: 0x06000D80 RID: 3456 RVA: 0x0000B39A File Offset: 0x0000959A
		public CatchUpPair(float dist, float factor, float aiFactor)
		{
			this.distance = dist;
			this.factor = factor;
			this.aiFactor = aiFactor;
		}

		// Token: 0x04000D29 RID: 3369
		public float distance;

		// Token: 0x04000D2A RID: 3370
		public float factor;

		// Token: 0x04000D2B RID: 3371
		public float aiFactor;
	}
}

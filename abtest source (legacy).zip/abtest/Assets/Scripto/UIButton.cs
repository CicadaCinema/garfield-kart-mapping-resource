﻿using System;
using UnityEngine;

// Token: 0x02000004 RID: 4
[AddComponentMenu("NGUI/Interaction/Button")]
public class UIButton : UIButtonColor
{
	// Token: 0x06000009 RID: 9 RVA: 0x00002160 File Offset: 0x00000360
	protected override void OnEnable()
	{
		if (this.isEnabled)
		{
			base.OnEnable();
		}
		else
		{
			this.UpdateColor(false, true);
		}
	}

	// Token: 0x0600000A RID: 10 RVA: 0x00002180 File Offset: 0x00000380
	public override void OnHover(bool isOver)
	{
		if (this.isEnabled)
		{
			base.OnHover(isOver);
		}
	}

	// Token: 0x0600000B RID: 11 RVA: 0x00002194 File Offset: 0x00000394
	public override void OnPress(bool isPressed)
	{
		if (this.isEnabled)
		{
			base.OnPress(isPressed);
		}
	}

	// Token: 0x17000001 RID: 1
	// (get) Token: 0x0600000C RID: 12 RVA: 0x0000D48C File Offset: 0x0000B68C
	// (set) Token: 0x0600000D RID: 13 RVA: 0x0000D4B4 File Offset: 0x0000B6B4
	public bool isEnabled
	{
		get
		{
			Collider collider = base.collider;
			return collider && collider.enabled;
		}
		set
		{
			Collider collider = base.collider;
			if (!collider)
			{
				return;
			}
			if (collider.enabled != value)
			{
				collider.enabled = value;
				this.UpdateColor(value, false);
			}
		}
	}

	// Token: 0x0600000E RID: 14 RVA: 0x0000D4F0 File Offset: 0x0000B6F0
	public void UpdateColor(bool shouldBeEnabled, bool immediate)
	{
		if (this.tweenTarget)
		{
			if (!this.mStarted)
			{
				this.mStarted = true;
				base.Init();
			}
			Color color = (!shouldBeEnabled) ? this.disabledColor : base.defaultColor;
			TweenColor tweenColor = TweenColor.Begin(this.tweenTarget, 0.15f, color);
			if (immediate)
			{
				tweenColor.color = color;
				tweenColor.enabled = false;
			}
		}
	}

	// Token: 0x04000003 RID: 3
	public Color disabledColor = Color.grey;
}

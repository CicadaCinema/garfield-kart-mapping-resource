﻿using System;
using UnityEngine;

// Token: 0x020000D5 RID: 213
public class DiamondBonusEntity : BonusEntity
{
	// Token: 0x0600059D RID: 1437 RVA: 0x0002CBE0 File Offset: 0x0002ADE0
	public DiamondBonusEntity()
	{
		this.m_eItem = EITEM.ITEM_DIAMOND;
	}

	// Token: 0x0600059E RID: 1438 RVA: 0x0002CC70 File Offset: 0x0002AE70
	public override void Awake()
	{
		this._rigidBody = base.GetComponent<Rigidbody>();
		this._attackEffect = (GameObject)UnityEngine.Object.Instantiate(this.AttackEffect);
		this._attackEffect.transform.parent = base.transform;
		this._attackEffect.transform.position = Vector3.zero;
		this._explosionEffect = (GameObject)UnityEngine.Object.Instantiate(this.ExplosionEffect);
		this._explosionEffect.transform.parent = base.transform;
		this._explosionEffect.transform.position = Vector3.zero;
		this._explosionCollider = this.ExplosionAnimationGO.collider;
		this._explosionAnimation = this.ExplosionAnimationGO.animation;
		this._diamond = this.DiamondGO.transform;
		this.m_bSynchronizePosition = true;
		this.m_fColliderDiameter = ((SphereCollider)base.collider).radius * 2f;
		base.Awake();
	}

	// Token: 0x0600059F RID: 1439 RVA: 0x00006035 File Offset: 0x00004235
	public override void Start()
	{
		base.Start();
		this._parent = base.transform.parent.parent;
	}

	// Token: 0x060005A0 RID: 1440 RVA: 0x00006053 File Offset: 0x00004253
	public void NetLaunch(NetworkViewID launcherViewID, bool pBehind)
	{
		this.m_pNetworkView.RPC("Launch", RPCMode.All, new object[]
		{
			launcherViewID,
			pBehind
		});
	}

	// Token: 0x060005A1 RID: 1441 RVA: 0x0000607E File Offset: 0x0000427E
	public void Launch(bool pBehind)
	{
		this.m_bBehind = pBehind;
		this._lifeTimeTimer = 0f;
		base.ActivateGameObject(true);
		this.SetActive(true);
		this.Launch();
	}

	// Token: 0x060005A2 RID: 1442 RVA: 0x0002CD68 File Offset: 0x0002AF68
	public override void Launch()
	{
		base.Launch();
		this.m_bSynchronizePosition = true;
		this.ParticleTrail.gameObject.SetActive(false);
		this.ParticleTrail.particleSystem.Stop();
		this.ParticleTrail.particleSystem.Clear();
		this._explosionEffect.particleSystem.Stop();
		this._explosionEffect.particleSystem.Clear();
		this._diamond.renderer.enabled = true;
		if (!this._attackEffect.particleSystem.isPlaying)
		{
			this._attackEffect.particleSystem.Play();
		}
		if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
		{
			this.m_pTransform.position = base.Launcher.Transform.position + base.Launcher.Transform.up * 0.2f;
			this.m_pTransform.position = new Vector3(this.m_pTransform.position.x, this.m_pTransform.position.y + 0.54f, this.m_pTransform.position.z);
		}
		this._launcherCollider = base.Launcher.Transform.parent.collider;
		this.m_pCollider.enabled = true;
		this._launcherCollider.enabled = true;
		this._explosionCollider.enabled = false;
		if (this.m_pCollider.gameObject.activeSelf && this._launcherCollider.gameObject.activeSelf)
		{
			Physics.IgnoreCollision(this.m_pCollider, this._launcherCollider, true);
		}
		this._jumpCounter = 0;
		this._isAttached = false;
		this._currentDir = Vector3.zero;
		this._currentSpeedFactor = this.ProjectileSpeedFactor;
		if (this._target != null)
		{
			this.UnregisterEvents();
			this._target = null;
		}
		this._state = DiamondBonusEntity.E_STATE.LAUNCH;
		if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
		{
			if (this.m_bBehind)
			{
				Vector3 pDir = -base.LaunchHorizontalDirection + base.Launcher.transform.up;
				this.CalculateInitialSpeed(pDir, 7.5f, 0.08f);
			}
			else
			{
				Vector3 pDir2 = base.LaunchHorizontalDirection + base.Launcher.transform.up;
				this.CalculateInitialSpeed(pDir2, this.Angle, this.Range);
			}
		}
		Vector3 a = new Vector3(base.Launcher.transform.forward.x, 0f, base.Launcher.transform.forward.z);
		this._rigidBody.angularVelocity = a * this.AngularVelocity;
		this._rigidBody.velocity = Vector3.zero;
		if (this.SoundLaunch && this.SoundCountdown)
		{
			this.SoundLaunch.Play();
			this.SoundCountdown.Play();
		}
		this.m_bVictorySound = false;
		this.LifeTimeWithHat = this.LifeTime + this.m_pLauncher.GetBonusMgr().GetBonusValue(EITEM.ITEM_DIAMOND, EBonusCustomEffect.EXPLOSION_RADIUS) * this.LifeTime / 100f;
	}

	// Token: 0x060005A3 RID: 1443 RVA: 0x0002D0C0 File Offset: 0x0002B2C0
	public void CalculateInitialSpeed(Vector3 pDir, float pAngle, float pRange)
	{
		this._currentAngle = pAngle;
		this._currentRange = pRange;
		this._initialTime = Time.time;
		pDir.Normalize();
		float num = -this._currentRange * Physics.gravity.y;
		float num2 = Mathf.Abs(2f * Mathf.Cos(pAngle * 0.0174532924f) * Mathf.Sin(pAngle * 0.0174532924f));
		this._initialSpeed = Mathf.Sqrt(num / num2) * pDir;
	}

	// Token: 0x060005A4 RID: 1444 RVA: 0x0002D13C File Offset: 0x0002B33C
	private void PerformLaunch(float pSpeedFactor, float vDeltaTime)
	{
		float num = Time.time - this._initialTime;
		float x = this._initialSpeed.x * Mathf.Cos(this._currentAngle * 0.0174532924f);
		float y = this._initialSpeed.y * Mathf.Sin(this._currentAngle * 0.0174532924f) + Physics.gravity.y * num * num / 2f;
		float z = this._initialSpeed.z * Mathf.Cos(this._currentAngle * 0.0174532924f);
		this._currentDir = new Vector3(x, y, z) * vDeltaTime * pSpeedFactor;
		float magnitude = this._currentDir.magnitude;
		if (magnitude > this.m_fColliderDiameter)
		{
			Vector3 position = base.transform.position;
			RaycastHit raycastHit;
			if (Physics.Raycast(position, this._currentDir, out raycastHit, magnitude, ~this.LayerRoad))
			{
				this._currentDir = this._currentDir.normalized * raycastHit.distance;
			}
		}
		base.transform.position += this._currentDir;
	}

	// Token: 0x060005A5 RID: 1445 RVA: 0x0002D268 File Offset: 0x0002B468
	public void FixedUpdate()
	{
		if (this.m_bActive)
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			if (this._state == DiamondBonusEntity.E_STATE.LAUNCH && (Network.peerType == NetworkPeerType.Disconnected || Network.isServer))
			{
				if (this.m_bBehind)
				{
					this.PerformLaunch(5f, fixedDeltaTime);
				}
				else
				{
					this.PerformLaunch(this._currentSpeedFactor, fixedDeltaTime);
				}
			}
		}
	}

	// Token: 0x060005A6 RID: 1446 RVA: 0x0002D2D0 File Offset: 0x0002B4D0
	public override void Update()
	{
		base.Update();
		if (this.m_bActive)
		{
			float deltaTime = Time.deltaTime;
			if (this._state == DiamondBonusEntity.E_STATE.LAUNCH)
			{
				if (!this.m_bBehind && this.ParticleTrail && !this.ParticleTrail.particleSystem.isPlaying)
				{
					this.m_fTrailTimer += deltaTime;
					if (this.m_fTrailTimer > 0.1f)
					{
						this.m_fTrailTimer = 0f;
						this.ParticleTrail.gameObject.SetActive(true);
						this.ParticleTrail.particleSystem.Play();
					}
				}
			}
			else if (this._state == DiamondBonusEntity.E_STATE.EXPLODE && !this._explosionAnimation.isPlaying)
			{
				this._explosionCollider.enabled = false;
				this._state = DiamondBonusEntity.E_STATE.END;
			}
			else if (this._state == DiamondBonusEntity.E_STATE.END)
			{
				if (!this._explosionEffect.particleSystem.isPlaying)
				{
					this.SetActive(false);
				}
			}
			else if (this._state == DiamondBonusEntity.E_STATE.IDLE && this.m_fTimerNoPhysic < this.TimerNoPhysic)
			{
				this.m_fTimerNoPhysic += deltaTime;
				if (this.m_fTimerNoPhysic > this.TimerNoPhysic && this._explosionCollider.gameObject.activeSelf && this._launcherCollider.gameObject.activeSelf)
				{
					Physics.IgnoreCollision(this._explosionCollider, this._launcherCollider, false);
				}
			}
			if ((Network.peerType == NetworkPeerType.Disconnected || Network.isServer) && this._state != DiamondBonusEntity.E_STATE.EXPLODE && this._state != DiamondBonusEntity.E_STATE.END)
			{
				this._lifeTimeTimer += deltaTime;
				if (this._lifeTimeTimer > this.LifeTimeWithHat && !this._explosionAnimation.isPlaying)
				{
					if (Network.isServer)
					{
						this.m_pNetworkView.RPC("Explode", RPCMode.All, new object[0]);
					}
					else
					{
						this.Explode();
					}
				}
			}
			if (this._target == null)
			{
				this._diamond.localScale += Vector3.one * this.ScaleFactor * deltaTime;
				if (this._diamond.localScale.x > this.MaxScale)
				{
					this._diamond.localScale = Vector3.one * this.MaxScale;
				}
			}
			if (!this._isAttached && this._target != null)
			{
				if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
				{
					this._direction = this._target.transform.position + Vector3.up * 0.25f - this.m_pTransform.position;
					if (this._direction != Vector3.zero)
					{
						if (this._direction.sqrMagnitude < this.MinDistance)
						{
							this.AttachToTarget();
						}
						else if (this._rigidBody.gameObject.activeInHierarchy)
						{
							this._direction.Normalize();
							this._rigidBody.velocity = this._direction * this._currentSpeed;
							this._diamond.localScale -= Vector3.one * this.ScaleFactor * deltaTime;
							if (this._diamond.localScale.x < 1f)
							{
								this._diamond.localScale = Vector3.one;
							}
						}
					}
				}
			}
			else if (this._target != null && this._jumpCounter >= this.m_iKartJumpNumber)
			{
				this.LoseTargetByJump();
			}
		}
	}

	// Token: 0x060005A7 RID: 1447 RVA: 0x0002D6B8 File Offset: 0x0002B8B8
	public void AttachToTarget()
	{
		if (this.m_bActive)
		{
			if (Network.peerType != NetworkPeerType.Disconnected && this.m_pNetworkView != null)
			{
				this.m_pNetworkView.RPC("OnAttachToTarget", RPCMode.All, new object[0]);
			}
			else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
			{
				this.DoAttachToTarget();
			}
		}
	}

	// Token: 0x060005A8 RID: 1448 RVA: 0x0002D728 File Offset: 0x0002B928
	public void DoAttachToTarget()
	{
		this.m_bSynchronizePosition = false;
		GameObject gameObject = this._target.transform.parent.gameObject;
		KartCustom componentInChildren = gameObject.GetComponentInChildren<KartCustom>();
		if (componentInChildren != null)
		{
			Transform transform = componentInChildren.transform.GetChild(0).GetChild(0).transform;
			if (this._parent != null)
			{
				this._parent.parent = transform;
				base.transform.localPosition = Vector3.zero;
				this._parent.localPosition = new Vector3(-0.2f, 0.25f, 0f);
				this._rigidBody.velocity = Vector3.zero;
			}
			this._isAttached = true;
			this.m_iKartJumpNumber = (int)((float)this.JumpNumber + this._target.GetBonusMgr().GetBonusValue(EITEM.ITEM_DIAMOND, EBonusCustomEffect.STICK));
			this._diamond.localScale = Vector3.one;
			this._rigidBody.transform.rotation = Quaternion.identity;
			base.transform.rotation = Quaternion.identity;
			base.transform.Rotate(Vector3.left * 90f);
			this._rigidBody.angularVelocity = Vector3.up * this.AngularVelocity;
			this._jumpCounter = 0;
		}
	}

	// Token: 0x060005A9 RID: 1449 RVA: 0x0002D874 File Offset: 0x0002BA74
	private void RegisterEvents()
	{
		Kart target = this._target;
		target.OnJump = (Action)Delegate.Combine(target.OnJump, new Action(this.KartJumped));
		Kart target2 = this._target;
		target2.OnBeSwaped = (Action<Kart>)Delegate.Combine(target2.OnBeSwaped, new Action<Kart>(this.KartBeSwaped));
		Kart target3 = this._target;
		target3.OnTeleported = (Action)Delegate.Combine(target3.OnTeleported, new Action(this.LoseTarget));
		Kart target4 = this._target;
		target4.OnSpringJump = (Action)Delegate.Combine(target4.OnSpringJump, new Action(this.LoseTarget));
		KartBonusMgr bonusMgr = this._target.GetBonusMgr();
		bonusMgr.OnLaunchBonus = (Action<EITEM, bool>)Delegate.Combine(bonusMgr.OnLaunchBonus, new Action<EITEM, bool>(this.KartLaunchBonus));
		Kart target5 = this._target;
		target5.OnBoost = (Action)Delegate.Combine(target5.OnBoost, new Action(this.LoseTarget));
		Kart target6 = this._target;
		target6.OnRespawn = (Action)Delegate.Combine(target6.OnRespawn, new Action(this.LoseTarget));
	}

	// Token: 0x060005AA RID: 1450 RVA: 0x0002D998 File Offset: 0x0002BB98
	private void UnregisterEvents()
	{
		Kart target = this._target;
		target.OnJump = (Action)Delegate.Remove(target.OnJump, new Action(this.KartJumped));
		Kart target2 = this._target;
		target2.OnBeSwaped = (Action<Kart>)Delegate.Remove(target2.OnBeSwaped, new Action<Kart>(this.KartBeSwaped));
		Kart target3 = this._target;
		target3.OnTeleported = (Action)Delegate.Remove(target3.OnTeleported, new Action(this.LoseTarget));
		Kart target4 = this._target;
		target4.OnSpringJump = (Action)Delegate.Remove(target4.OnSpringJump, new Action(this.LoseTarget));
		KartBonusMgr bonusMgr = this._target.GetBonusMgr();
		bonusMgr.OnLaunchBonus = (Action<EITEM, bool>)Delegate.Remove(bonusMgr.OnLaunchBonus, new Action<EITEM, bool>(this.KartLaunchBonus));
		Kart target5 = this._target;
		target5.OnBoost = (Action)Delegate.Remove(target5.OnBoost, new Action(this.LoseTarget));
		Kart target6 = this._target;
		target6.OnRespawn = (Action)Delegate.Remove(target6.OnRespawn, new Action(this.LoseTarget));
	}

	// Token: 0x060005AB RID: 1451 RVA: 0x0002DABC File Offset: 0x0002BCBC
	private void KartLaunchBonus(EITEM pItem, bool pBehind)
	{
		if (pItem == EITEM.ITEM_LASAGNA || (pItem == EITEM.ITEM_SPRING && !pBehind) || (pItem == EITEM.ITEM_PARFUME && !((ParfumeBonusEffect)this._target.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_ATTRACTED)).StinkParfume))
		{
			this.LoseTarget();
		}
	}

	// Token: 0x060005AC RID: 1452 RVA: 0x000060A6 File Offset: 0x000042A6
	private void KartBeSwaped(Kart pOtherKart)
	{
		this.LoseTarget();
	}

	// Token: 0x060005AD RID: 1453 RVA: 0x0002DB10 File Offset: 0x0002BD10
	public void DoLoseTarget()
	{
		if (this.m_bActive && this._target != null)
		{
			this.m_bBehind = true;
			base.transform.Rotate(new Vector3(-354f, 0f, 0f));
			this._target.HasDiamondAttached = false;
			base.Launcher = this._target;
			this.m_bSynchronizePosition = true;
			if (this._parent != null)
			{
				this._parent.parent = null;
			}
			this.Launch();
			if (this.SoundUnglued)
			{
				this.SoundUnglued.Play();
			}
		}
	}

	// Token: 0x060005AE RID: 1454 RVA: 0x0002DBBC File Offset: 0x0002BDBC
	public void LoseTargetByJump()
	{
		if (this.m_bActive && this._target != null)
		{
			if (Network.peerType != NetworkPeerType.Disconnected && this.m_pNetworkView != null)
			{
				this.m_pNetworkView.RPC("OnLoseTarget", RPCMode.All, new object[0]);
			}
			else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
			{
				this.DoLoseTarget();
			}
		}
	}

	// Token: 0x060005AF RID: 1455 RVA: 0x0002DC40 File Offset: 0x0002BE40
	public void LoseTarget()
	{
		if (this.m_bActive && this._target != null)
		{
			if (Network.isServer && this.m_pNetworkView != null)
			{
				this.m_pNetworkView.RPC("OnLoseTarget", RPCMode.All, new object[0]);
			}
			else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
			{
				this.DoLoseTarget();
			}
		}
	}

	// Token: 0x060005B0 RID: 1456 RVA: 0x0002DCC4 File Offset: 0x0002BEC4
	public void Explode()
	{
		if (this._state != DiamondBonusEntity.E_STATE.EXPLODE)
		{
			this.ParticleTrail.particleSystem.Stop();
			this.ParticleTrail.gameObject.SetActive(false);
			this._diamond.renderer.enabled = false;
			this._attackEffect.particleSystem.Stop();
			this._explosionEffect.particleSystem.Play();
			this.m_pCollider.enabled = false;
			this._explosionCollider.enabled = true;
			this._explosionAnimation.Play();
			if (this._explosionCollider.gameObject.activeSelf && this._launcherCollider && this._launcherCollider.gameObject.activeSelf)
			{
				Physics.IgnoreCollision(this._explosionCollider, this._launcherCollider, false);
			}
			this._state = DiamondBonusEntity.E_STATE.EXPLODE;
			if (this._target != null)
			{
				if (!this._target.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_UPSIDE_DOWN).Activated)
				{
					this._target.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_UPSIDE_DOWN).BonusEffectDirection = EBonusEffectDirection.BACK;
					this._target.GetBonusMgr().GetBonusEffectMgr().ActivateBonusEffect(EBonusEffect.BONUSEFFECT_UPSIDE_DOWN);
					this.PlayVictorySound(this._target);
				}
				this._target.HasDiamondAttached = false;
				this.UnregisterEvents();
				this._target = null;
			}
			if (this.SoundExplode && this.SoundCountdown)
			{
				this.SoundExplode.Play();
				this.SoundCountdown.Stop();
			}
		}
	}

	// Token: 0x060005B1 RID: 1457 RVA: 0x0002DE68 File Offset: 0x0002C068
	public void PlayVictorySound(Kart pKart)
	{
		if (pKart != this.m_pLauncher && !this.m_bVictorySound)
		{
			this.m_bVictorySound = true;
			this.m_pLauncher.KartSound.PlayVoice(KartSound.EVoices.Good);
			this.m_pLauncher.Anim.LaunchSuccessAnim(true);
		}
	}

	// Token: 0x060005B2 RID: 1458 RVA: 0x000060AE File Offset: 0x000042AE
	private void KartJumped()
	{
		this._jumpCounter++;
	}

	// Token: 0x060005B3 RID: 1459 RVA: 0x0002DEBC File Offset: 0x0002C0BC
	public override void SetActive(bool pActive)
	{
		if (!pActive)
		{
			if (this._parent != null)
			{
				this._parent.parent = null;
			}
			base.transform.localPosition = Vector3.zero;
		}
		base.SetActive(pActive);
		base.ActivateGameObject(pActive);
	}

	// Token: 0x060005B4 RID: 1460 RVA: 0x0002DF0C File Offset: 0x0002C10C
	public override void DoOnTriggerEnter(GameObject pOther, int otherlayer)
	{
		int num = 1 << otherlayer;
		if (pOther != null && (num & this.LayerBonus) != 0)
		{
			BonusEntity componentInChildren = pOther.GetComponentInChildren<BonusEntity>();
			if (componentInChildren is DiamondBonusEntity && this._state != DiamondBonusEntity.E_STATE.END)
			{
				((DiamondBonusEntity)componentInChildren).Explode();
				this.Explode();
			}
		}
		if (this._state != DiamondBonusEntity.E_STATE.EXPLODE && this._state != DiamondBonusEntity.E_STATE.END)
		{
			if ((num & this.LayerVehicle) != 0 && this._state != DiamondBonusEntity.E_STATE.ATTACHED)
			{
				if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
				{
					Kart componentInChildren2 = pOther.GetComponentInChildren<Kart>();
					if (componentInChildren2)
					{
						ParfumeBonusEffect parfumeBonusEffect = (ParfumeBonusEffect)componentInChildren2.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_ATTRACTED);
						if (!parfumeBonusEffect.Activated || parfumeBonusEffect.StinkParfume)
						{
							this.AcquireTarget(pOther);
						}
					}
				}
			}
			else if (this._state != DiamondBonusEntity.E_STATE.IDLE && this._state != DiamondBonusEntity.E_STATE.ATTACHED)
			{
				if ((num & this.LayerWall) != 0)
				{
					if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
					{
						Ray ray = new Ray(base.transform.position, this._currentDir);
						RaycastHit raycastHit;
						if (Physics.Raycast(ray, out raycastHit, 5f, this.LayerWall))
						{
							Vector3 normal = raycastHit.normal;
							normal.Normalize();
							float num2 = Vector3.Dot(this._currentDir, normal);
							Vector3 pDir = this._currentDir - 2f * (num2 * normal);
							this._currentAngle = num2 * 57.29578f;
							if (this._currentAngle < 0f)
							{
								this._currentAngle += 360f;
							}
							this.CalculateNewRange();
							this.CalculateInitialSpeed(pDir, this._currentAngle, this._currentRange);
							this.CollideWall();
						}
					}
				}
				else if ((num & this.LayerRoad) != 0 && (Network.peerType == NetworkPeerType.Disconnected || Network.isServer))
				{
					Ray ray2 = new Ray(base.transform.position, Vector3.down);
					RaycastHit raycastHit2;
					if (Physics.Raycast(ray2, out raycastHit2, 5f, this.LayerRoad))
					{
						this.CollideRoad(raycastHit2.point);
					}
				}
			}
		}
		else if (this._state == DiamondBonusEntity.E_STATE.EXPLODE && this._explosionAnimation.isPlaying && (num & this.LayerVehicle) != 0)
		{
			Kart componentInChildren3 = pOther.GetComponentInChildren<Kart>();
			if (componentInChildren3 && !componentInChildren3.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_UPSIDE_DOWN).Activated)
			{
				ParfumeBonusEffect parfumeBonusEffect2 = (ParfumeBonusEffect)componentInChildren3.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_ATTRACTED);
				if (!parfumeBonusEffect2.Activated || parfumeBonusEffect2.StinkParfume)
				{
					componentInChildren3.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_UPSIDE_DOWN).BonusEffectDirection = EBonusEffectDirection.BACK;
					componentInChildren3.GetBonusMgr().GetBonusEffectMgr().ActivateBonusEffect(EBonusEffect.BONUSEFFECT_UPSIDE_DOWN);
					this.PlayVictorySound(componentInChildren3);
				}
			}
		}
	}

	// Token: 0x060005B5 RID: 1461 RVA: 0x0002E244 File Offset: 0x0002C444
	public void CollideWall()
	{
		if (this.m_bActive)
		{
			if (Network.peerType != NetworkPeerType.Disconnected && this.m_pNetworkView != null)
			{
				this.m_pNetworkView.RPC("OnCollideWall", RPCMode.All, new object[0]);
			}
			else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
			{
				this.DoCollideWall();
			}
		}
	}

	// Token: 0x060005B6 RID: 1462 RVA: 0x000060BE File Offset: 0x000042BE
	public void DoCollideWall()
	{
		if (this.SoundLand)
		{
			this.SoundLand.Play();
		}
	}

	// Token: 0x060005B7 RID: 1463 RVA: 0x0002E2B4 File Offset: 0x0002C4B4
	public void CollideRoad(Vector3 hit)
	{
		if (this.m_bActive)
		{
			if (Network.peerType != NetworkPeerType.Disconnected && this.m_pNetworkView != null)
			{
				this.m_pNetworkView.RPC("OnCollideRoad", RPCMode.All, new object[]
				{
					hit
				});
			}
			else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
			{
				this.DoCollideRoad(hit);
			}
		}
	}

	// Token: 0x060005B8 RID: 1464 RVA: 0x0002E330 File Offset: 0x0002C530
	public void DoCollideRoad(Vector3 hit)
	{
		this._state = DiamondBonusEntity.E_STATE.IDLE;
		this._explosionCollider.enabled = true;
		if (this._explosionCollider.gameObject.activeSelf && this._launcherCollider && this._launcherCollider.gameObject && this._launcherCollider.gameObject.activeSelf)
		{
			Physics.IgnoreCollision(this._explosionCollider, this._launcherCollider, true);
		}
		this.m_fTimerNoPhysic = 0f;
		this._rigidBody.angularVelocity = Vector3.zero;
		base.transform.position = new Vector3(hit.x, hit.y + 0.5f, hit.z);
		if (this.SoundLand)
		{
			this.SoundLand.Play();
		}
	}

	// Token: 0x060005B9 RID: 1465 RVA: 0x0002E414 File Offset: 0x0002C614
	private void CalculateNewRange()
	{
		float num = Time.time - this._initialTime;
		float num2 = num * this._initialSpeed.magnitude * Mathf.Cos(this._currentAngle * 0.0174532924f);
		this._currentRange -= num2;
		if (this._currentRange < 0f)
		{
			this._currentRange = 0f;
		}
	}

	// Token: 0x060005BA RID: 1466 RVA: 0x0002E478 File Offset: 0x0002C678
	public void DoAcquireTarget(GameObject pParent)
	{
		this._target = pParent.GetComponentInChildren<Kart>();
		if (this._target == null)
		{
			return;
		}
		this._target.KartSound.PlayVoice(KartSound.EVoices.Bad);
		this._target.HasDiamondAttached = true;
		this.RegisterEvents();
		base.transform.Rotate(new Vector3(354f, 0f, 0f));
		this._currentSpeed = ((KartArcadeGearBox)this._target.GetGearBox()).GetBaseMaxSpeed() + this.SpeedFactor / 3.6f;
		this._state = DiamondBonusEntity.E_STATE.ATTACHED;
		if (this.SoundGlued)
		{
			this.SoundGlued.Play();
		}
	}

	// Token: 0x060005BB RID: 1467 RVA: 0x0002E530 File Offset: 0x0002C730
	public void AcquireTarget(GameObject pParent)
	{
		if (this.m_bActive)
		{
			if (Network.peerType != NetworkPeerType.Disconnected && this.m_pNetworkView != null)
			{
				NetworkViewID networkViewID = default(NetworkViewID);
				if (pParent.GetComponent<NetworkView>())
				{
					networkViewID = pParent.GetComponent<NetworkView>().viewID;
				}
				this.m_pNetworkView.RPC("OnAcquireTarget", RPCMode.All, new object[]
				{
					networkViewID
				});
			}
			else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
			{
				this.DoAcquireTarget(pParent);
			}
		}
	}

	// Token: 0x0400057C RID: 1404
	public float AngularVelocity = 2f;

	// Token: 0x0400057D RID: 1405
	public float MaxScale = 2f;

	// Token: 0x0400057E RID: 1406
	public float ScaleFactor = 1f;

	// Token: 0x0400057F RID: 1407
	public float Angle = 15f;

	// Token: 0x04000580 RID: 1408
	public float Range = 30f;

	// Token: 0x04000581 RID: 1409
	private Vector3 _initialSpeed = Vector3.zero;

	// Token: 0x04000582 RID: 1410
	private float _initialTime;

	// Token: 0x04000583 RID: 1411
	public float ProjectileSpeedFactor = 4f;

	// Token: 0x04000584 RID: 1412
	private float _currentAngle;

	// Token: 0x04000585 RID: 1413
	private Vector3 _currentDir;

	// Token: 0x04000586 RID: 1414
	private float _currentRange;

	// Token: 0x04000587 RID: 1415
	private float _currentSpeedFactor;

	// Token: 0x04000588 RID: 1416
	private float m_fTrailTimer;

	// Token: 0x04000589 RID: 1417
	public float MinDistance;

	// Token: 0x0400058A RID: 1418
	public float SpeedFactor = 1f;

	// Token: 0x0400058B RID: 1419
	private float m_fTimerNoPhysic;

	// Token: 0x0400058C RID: 1420
	public float TimerNoPhysic;

	// Token: 0x0400058D RID: 1421
	private float _currentSpeed;

	// Token: 0x0400058E RID: 1422
	private Vector3 _direction = Vector3.zero;

	// Token: 0x0400058F RID: 1423
	private Kart _target;

	// Token: 0x04000590 RID: 1424
	private bool _isAttached;

	// Token: 0x04000591 RID: 1425
	private DiamondBonusEntity.E_STATE _state;

	// Token: 0x04000592 RID: 1426
	public LayerMask LayerVehicle;

	// Token: 0x04000593 RID: 1427
	public LayerMask LayerRoad;

	// Token: 0x04000594 RID: 1428
	public LayerMask LayerBonus;

	// Token: 0x04000595 RID: 1429
	public LayerMask LayerWall;

	// Token: 0x04000596 RID: 1430
	public int JumpNumber = 4;

	// Token: 0x04000597 RID: 1431
	private int m_iKartJumpNumber;

	// Token: 0x04000598 RID: 1432
	private int _jumpCounter;

	// Token: 0x04000599 RID: 1433
	private Collider _launcherCollider;

	// Token: 0x0400059A RID: 1434
	public float LifeTime = 10f;

	// Token: 0x0400059B RID: 1435
	private float LifeTimeWithHat;

	// Token: 0x0400059C RID: 1436
	private float _lifeTimeTimer;

	// Token: 0x0400059D RID: 1437
	private Rigidbody _rigidBody;

	// Token: 0x0400059E RID: 1438
	private GameObject _explosionEffect;

	// Token: 0x0400059F RID: 1439
	private GameObject _attackEffect;

	// Token: 0x040005A0 RID: 1440
	private Transform _parent;

	// Token: 0x040005A1 RID: 1441
	public GameObject DiamondGO;

	// Token: 0x040005A2 RID: 1442
	private Transform _diamond;

	// Token: 0x040005A3 RID: 1443
	private Collider _explosionCollider;

	// Token: 0x040005A4 RID: 1444
	public GameObject AttackEffect;

	// Token: 0x040005A5 RID: 1445
	public GameObject ExplosionEffect;

	// Token: 0x040005A6 RID: 1446
	public GameObject ExplosionAnimationGO;

	// Token: 0x040005A7 RID: 1447
	private Animation _explosionAnimation;

	// Token: 0x040005A8 RID: 1448
	public GameObject ParticleTrail;

	// Token: 0x040005A9 RID: 1449
	private bool m_bVictorySound;

	// Token: 0x040005AA RID: 1450
	private float m_fColliderDiameter;

	// Token: 0x040005AB RID: 1451
	public AudioSource SoundLaunch;

	// Token: 0x040005AC RID: 1452
	public AudioSource SoundExplode;

	// Token: 0x040005AD RID: 1453
	public AudioSource SoundGlued;

	// Token: 0x040005AE RID: 1454
	public AudioSource SoundUnglued;

	// Token: 0x040005AF RID: 1455
	public AudioSource SoundLand;

	// Token: 0x040005B0 RID: 1456
	public AudioSource SoundCountdown;

	// Token: 0x020000D6 RID: 214
	public enum E_STATE
	{
		// Token: 0x040005B2 RID: 1458
		NONE,
		// Token: 0x040005B3 RID: 1459
		LAUNCH,
		// Token: 0x040005B4 RID: 1460
		ATTACHED,
		// Token: 0x040005B5 RID: 1461
		IDLE,
		// Token: 0x040005B6 RID: 1462
		EXPLODE,
		// Token: 0x040005B7 RID: 1463
		END
	}
}

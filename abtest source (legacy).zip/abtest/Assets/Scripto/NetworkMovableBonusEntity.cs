﻿using System;
using UnityEngine;

// Token: 0x020000E5 RID: 229
public class NetworkMovableBonusEntity : NetworkBonusEntity
{
	// Token: 0x0600062C RID: 1580 RVA: 0x000065EB File Offset: 0x000047EB
	public NetworkMovableBonusEntity()
	{
		this.m_dInterpBkTime = 0.12;
		this.m_dMaxExtrap = 0.55;
		this.m_iTimestampCount = -1;
	}

	// Token: 0x0600062D RID: 1581 RVA: 0x00030898 File Offset: 0x0002EA98
	public virtual void OnSerializeNetworkView(BitStream stream, NetworkMessageInfo info)
	{
		this.m_pBonusEntity.OnSerializeNetworkView(stream, info);
		if (this.m_pBonusEntity.BSynchronizePosition && this.m_pBonusEntity.Activate)
		{
			if (stream.isWriting)
			{
				Vector3 position = this.m_pBonusEntity.rigidbody.position;
				Vector3 velocity = this.m_pBonusEntity.rigidbody.velocity;
				stream.Serialize(ref position);
				stream.Serialize(ref velocity);
				if (this.m_pBonusEntity.BSynchronizeRotation)
				{
					Quaternion rotation = this.m_pBonusEntity.rigidbody.rotation;
					stream.Serialize(ref rotation);
				}
			}
			else if (!base.networkView.isMine)
			{
				Vector3 zero = Vector3.zero;
				Vector3 zero2 = Vector3.zero;
				Quaternion identity = Quaternion.identity;
				stream.Serialize(ref zero);
				stream.Serialize(ref zero2);
				if (this.m_pBonusEntity.BSynchronizeRotation)
				{
					stream.Serialize(ref identity);
				}
				for (int i = this.m_BufferedState.Length - 1; i >= 1; i--)
				{
					this.m_BufferedState[i] = this.m_BufferedState[i - 1];
				}
				NetworkMovableBonusEntity.Packet packet;
				packet.time = info.timestamp;
				packet.pos = zero;
				packet.vel = zero2;
				packet.rot = identity;
				this.m_BufferedState[0] = packet;
				this.m_iTimestampCount = Mathf.Min(this.m_iTimestampCount + 1, this.m_BufferedState.Length);
			}
		}
	}

	// Token: 0x0600062E RID: 1582 RVA: 0x00030A24 File Offset: 0x0002EC24
	public void FixedUpdate()
	{
		if (!base.networkView.isMine && this.m_pBonusEntity.BSynchronizePosition && this.m_pBonusEntity.Activate)
		{
			double num = Network.time - this.m_dInterpBkTime;
			if (this.m_BufferedState[0].time > num)
			{
				for (int i = 0; i < this.m_iTimestampCount; i++)
				{
					if (this.m_BufferedState[i].time <= num || i == this.m_iTimestampCount - 1)
					{
						NetworkMovableBonusEntity.Packet packet = this.m_BufferedState[Mathf.Max(i - 1, 0)];
						NetworkMovableBonusEntity.Packet packet2 = this.m_BufferedState[i];
						double num2 = packet.time - packet2.time;
						float t = 0f;
						if (num2 > 0.0001)
						{
							t = (float)((num - packet2.time) / num2);
						}
						this.m_pBonusEntity.rigidbody.position = Vector3.Lerp(packet2.pos, packet.pos, t);
						if (this.m_pBonusEntity.BSynchronizeRotation)
						{
							this.m_pBonusEntity.rigidbody.rotation = Quaternion.Lerp(packet2.rot, packet.rot, t);
						}
						return;
					}
				}
			}
			else
			{
				NetworkMovableBonusEntity.Packet packet3 = this.m_BufferedState[0];
				float num3 = (float)(num - packet3.time);
				if ((double)num3 < this.m_dMaxExtrap)
				{
					this.m_pBonusEntity.rigidbody.position = packet3.pos + packet3.vel * num3;
					if (this.m_pBonusEntity.BSynchronizeRotation)
					{
						this.m_pBonusEntity.rigidbody.rotation = packet3.rot;
					}
				}
			}
		}
	}

	// Token: 0x0600062F RID: 1583 RVA: 0x00006625 File Offset: 0x00004825
	[RPC]
	public virtual void Launch(NetworkViewID launcherViewID)
	{
		this.NetworkInitialize(launcherViewID);
		this.m_pBonusEntity.Launch();
	}

	// Token: 0x0400060D RID: 1549
	public double m_dInterpBkTime;

	// Token: 0x0400060E RID: 1550
	public double m_dMaxExtrap;

	// Token: 0x0400060F RID: 1551
	protected int m_iTimestampCount;

	// Token: 0x04000610 RID: 1552
	protected NetworkMovableBonusEntity.Packet[] m_BufferedState = new NetworkMovableBonusEntity.Packet[20];

	// Token: 0x020000E6 RID: 230
	public struct Packet
	{
		// Token: 0x04000611 RID: 1553
		public double time;

		// Token: 0x04000612 RID: 1554
		public Vector3 pos;

		// Token: 0x04000613 RID: 1555
		public Vector3 vel;

		// Token: 0x04000614 RID: 1556
		public Quaternion rot;
	}
}

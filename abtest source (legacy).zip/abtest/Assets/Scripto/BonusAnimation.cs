﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000101 RID: 257
public class BonusAnimation : MonoBehaviour
{
	// Token: 0x1700010C RID: 268
	// (get) Token: 0x060006ED RID: 1773 RVA: 0x00006EBF File Offset: 0x000050BF
	// (set) Token: 0x060006EC RID: 1772 RVA: 0x00006EB6 File Offset: 0x000050B6
	public EITEM WantedBonus
	{
		get
		{
			return (EITEM)this.m_WantedBonus;
		}
		set
		{
			this.m_WantedBonus = (int)value;
		}
	}

	// Token: 0x1700010D RID: 269
	// (get) Token: 0x060006EE RID: 1774 RVA: 0x00006EC7 File Offset: 0x000050C7
	public BonusAnimation_State State
	{
		get
		{
			return this.m_eState;
		}
	}

	// Token: 0x060006EF RID: 1775 RVA: 0x00034634 File Offset: 0x00032834
	public void Start()
	{
		this.m_eState = BonusAnimation_State.STOPPED;
		this.CurrentTimer = this.TimerBeforeDeceleration;
		this.m_WantedBonus = 0;
		if (this.mSprite == null)
		{
			this.mSprite = base.GetComponent<UISprite>();
		}
		this.mSpriteNames.Clear();
		if (this.mSprite != null && this.mSprite.atlas != null)
		{
			List<UIAtlas.Sprite> spriteList = this.mSprite.atlas.spriteList;
			int i = 0;
			int count = spriteList.Count;
			while (i < count)
			{
				UIAtlas.Sprite sprite = spriteList[i];
				if (string.IsNullOrEmpty("Bonus") || sprite.name.StartsWith("Bonus"))
				{
					this.mSpriteNames.Add(sprite.name);
				}
				i++;
			}
		}
		base.gameObject.SetActive(false);
	}

	// Token: 0x060006F0 RID: 1776 RVA: 0x00034720 File Offset: 0x00032920
	public void Update()
	{
		if (Singleton<InputManager>.Instance.GetAction(EAction.LaunchBonus) == 1f)
		{
			this.OnTouch();
		}
		if (this.mSpriteNames.Count > 1 && Application.isPlaying && this.m_CustomFPS > 0f && this.m_eState > BonusAnimation_State.STOPPED)
		{
			this.m_BonusIndex += this.m_CustomFPS * Time.deltaTime * 0.5f;
			this.m_BonusIndex %= (float)this.mSpriteNames.Count;
			if (this.m_LastBonusIndex != (int)this.m_BonusIndex)
			{
				this.m_LastBonusIndex = (int)this.m_BonusIndex;
				this.mSprite.spriteName = this.mSpriteNames[(int)this.m_BonusIndex];
				this.mSprite.MakePixelPerfect();
				Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.BonusRoulette);
			}
			if (this.m_eState == BonusAnimation_State.DECELERATED)
			{
				if (this.m_CustomFPS > 0f)
				{
					this.m_CustomFPS -= Time.deltaTime * this.m_BaseFps / this.SlowDownTimer;
				}
				if (this.m_CustomFPS <= 0f)
				{
					if ((int)this.m_BonusIndex != this.m_WantedBonus - 1 && this.m_WantedBonus > 0)
					{
						this.mSprite.spriteName = this.mSpriteNames[this.m_WantedBonus - 1];
						this.mSprite.MakePixelPerfect();
					}
					this.m_eState = BonusAnimation_State.STOPPED;
					if (this.OnAnimationFinished != null)
					{
						this.OnAnimationFinished(this.SlotIndex);
					}
				}
			}
			if (this.m_CustomFPS > 0f)
			{
				this.m_BonusIndex += this.m_CustomFPS * Time.deltaTime * 0.5f;
			}
			if (this.CurrentTimer >= 0f && this.m_eState == BonusAnimation_State.STARTED)
			{
				this.CurrentTimer -= Time.deltaTime;
				if (this.CurrentTimer < 0f)
				{
					this.DoStopAnim();
				}
			}
		}
	}

	// Token: 0x060006F1 RID: 1777 RVA: 0x0003493C File Offset: 0x00032B3C
	public void Affect(BonusAnimation _ba)
	{
		this.m_CustomFPS = _ba.m_CustomFPS;
		this.m_BaseFps = _ba.m_BaseFps;
		this.SlowDownTimer = _ba.SlowDownTimer;
		this.m_eState = _ba.m_eState;
		this.m_BonusIndex = _ba.m_BonusIndex;
		this.CurrentTimer = _ba.CurrentTimer;
		this.m_WantedBonus = _ba.m_WantedBonus;
		if (this.m_eState == BonusAnimation_State.STOPPED && this.m_WantedBonus > 0)
		{
			this.mSprite.spriteName = this.mSpriteNames[this.m_WantedBonus - 1];
			this.mSprite.MakePixelPerfect();
			base.gameObject.SetActive(true);
		}
		else if (this.m_eState == BonusAnimation_State.DECELERATED && this.m_WantedBonus > 0)
		{
			base.gameObject.SetActive(true);
		}
		else if (this.m_WantedBonus == 0)
		{
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x060006F2 RID: 1778 RVA: 0x00006ECF File Offset: 0x000050CF
	public void OnTouch()
	{
		if (this.m_eState == BonusAnimation_State.STARTED)
		{
			this.DoStopAnim();
		}
	}

	// Token: 0x060006F3 RID: 1779 RVA: 0x00034A30 File Offset: 0x00032C30
	public void DoStopAnim()
	{
		this.m_eState = BonusAnimation_State.DECELERATED;
		this.m_BonusIndex = ((float)(this.m_WantedBonus - 1) - 0.5f * this.m_BaseFps * this.SlowDownTimer + this.m_BaseFps * this.SlowDownTimer * (float)this.mSpriteNames.Count) % (float)this.mSpriteNames.Count + 0.5f;
	}

	// Token: 0x060006F4 RID: 1780 RVA: 0x00006EE3 File Offset: 0x000050E3
	public void Reset()
	{
		this.m_CustomFPS = this.m_BaseFps;
		this.m_eState = BonusAnimation_State.STOPPED;
		this.m_BonusIndex = 0f;
		this.CurrentTimer = this.TimerBeforeDeceleration;
		this.m_WantedBonus = 0;
	}

	// Token: 0x060006F5 RID: 1781 RVA: 0x00006D1D File Offset: 0x00004F1D
	public void Deactivate()
	{
		base.gameObject.SetActive(false);
	}

	// Token: 0x060006F6 RID: 1782 RVA: 0x00006F16 File Offset: 0x00005116
	public void Launch(EITEM _WantedBonus)
	{
		this.Reset();
		base.gameObject.SetActive(true);
		this.WantedBonus = _WantedBonus;
		this.m_eState = BonusAnimation_State.STARTED;
	}

	// Token: 0x060006F7 RID: 1783 RVA: 0x00006F38 File Offset: 0x00005138
	public void OnSwapOk()
	{
		if (this.InformSwapOk != null)
		{
			this.InformSwapOk();
		}
	}

	// Token: 0x060006F8 RID: 1784 RVA: 0x00006F50 File Offset: 0x00005150
	public void OnLaunchFinished()
	{
		if (this.InformLaunchFinished != null)
		{
			this.InformLaunchFinished();
		}
	}

	// Token: 0x040006D2 RID: 1746
	public Action<int> OnAnimationFinished;

	// Token: 0x040006D3 RID: 1747
	public Action InformSwapOk;

	// Token: 0x040006D4 RID: 1748
	public Action InformLaunchFinished;

	// Token: 0x040006D5 RID: 1749
	public float TimerBeforeDeceleration = 1f;

	// Token: 0x040006D6 RID: 1750
	private BonusAnimation_State m_eState;

	// Token: 0x040006D7 RID: 1751
	private float CurrentTimer;

	// Token: 0x040006D8 RID: 1752
	public float SlowDownTimer = 1.5f;

	// Token: 0x040006D9 RID: 1753
	public float m_BaseFps;

	// Token: 0x040006DA RID: 1754
	private int m_WantedBonus;

	// Token: 0x040006DB RID: 1755
	protected float m_BonusIndex;

	// Token: 0x040006DC RID: 1756
	private int m_LastBonusIndex = -1;

	// Token: 0x040006DD RID: 1757
	protected float m_CustomFPS = 30f;

	// Token: 0x040006DE RID: 1758
	protected UISprite mSprite;

	// Token: 0x040006DF RID: 1759
	protected List<string> mSpriteNames = new List<string>();

	// Token: 0x040006E0 RID: 1760
	public int SlotIndex;
}

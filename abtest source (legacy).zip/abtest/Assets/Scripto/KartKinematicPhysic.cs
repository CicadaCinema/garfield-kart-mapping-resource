﻿using System;

// Token: 0x02000148 RID: 328
public class KartKinematicPhysic : RcKinematicPhysic
{
	// Token: 0x0600093F RID: 2367 RVA: 0x00008699 File Offset: 0x00006899
	public void SetBoosting(bool bBoosting)
	{
		this.m_bBoosting = bBoosting;
	}

	// Token: 0x06000940 RID: 2368 RVA: 0x000086A2 File Offset: 0x000068A2
	public void SetParfume(bool bParfume)
	{
		this.m_bParfume = bParfume;
	}

	// Token: 0x06000941 RID: 2369 RVA: 0x000086AB File Offset: 0x000068AB
	public override bool IsGoingTooFast()
	{
		return (!this.m_bNoSurfaceResponseInBoost || (!this.m_bBoosting && !this.m_bParfume)) && base.IsGoingTooFast();
	}

	// Token: 0x04000961 RID: 2401
	public bool m_bNoSurfaceResponseInBoost = true;

	// Token: 0x04000962 RID: 2402
	private bool m_bBoosting;

	// Token: 0x04000963 RID: 2403
	private bool m_bParfume;
}

﻿using System;
using UnityEngine;

// Token: 0x0200016E RID: 366
public class PodiumGameState : GameState
{
	// Token: 0x060009DE RID: 2526 RVA: 0x00044AE4 File Offset: 0x00042CE4
	public override void Enter()
	{
		GameObject gameObject = GameObject.Find("Podium");
		this.m_pGameMode.Hud.HUDFade.ForceIn();
		this.m_fFadeTimer = 0f;
		this.m_pPodium = gameObject.transform.GetChild(0).gameObject;
		if (this.m_pGameMode.MainMusic != null && this.m_pGameMode.MainMusic.isPlaying)
		{
			this.m_pGameMode.MainMusic.Stop();
		}
		Singleton<GameManager>.Instance.SoundManager.StopMusic();
		this.m_pPodium.SetActive(true);
		this.m_pCameraAnimation = this.m_pPodium.GetComponentInChildren<Animation>();
		this.DesactivatePhysic();
		if (this.m_Camera == null)
		{
			this.m_Camera = this.m_pPodium.transform.Find("CameraPodium").camera;
		}
		foreach (GameObject gameObject2 in Singleton<GameManager>.Instance.GameMode.Hud.HUDPause.NamePlates)
		{
			gameObject2.GetComponent<Billboard>().SetCamera(this.m_Camera);
		}
		BonusEntity[] array = (BonusEntity[])UnityEngine.Object.FindObjectsOfType(typeof(BonusEntity));
		foreach (BonusEntity bonusEntity in array)
		{
			bonusEntity.gameObject.SetActive(false);
		}
	}

	// Token: 0x060009DF RID: 2527 RVA: 0x00044C80 File Offset: 0x00042E80
	private void DesactivatePhysic()
	{
		for (int i = 0; i < Singleton<GameConfigurator>.Instance.RankingManager.RaceScoreCount(); i++)
		{
			ChampionShipScoreData championshipPos = Singleton<GameConfigurator>.Instance.RankingManager.GetChampionshipPos(i);
			GameObject playerWithVehicleId = this.m_pGameMode.GetPlayerWithVehicleId(championshipPos.KartIndex);
			Kart kartWithVehicleId = this.m_pGameMode.GetKartWithVehicleId(championshipPos.KartIndex);
			kartWithVehicleId.FxMgr.Stop();
			kartWithVehicleId.GetBonusMgr().GetBonusEffectMgr().Reset();
			kartWithVehicleId.GetBonusMgr().GetBonusEffectMgr().Dispose();
			kartWithVehicleId.SetArcadeDriftFactor(0f);
			playerWithVehicleId.GetComponentInChildren<RcNetworkController>().enabled = false;
			kartWithVehicleId.GetVehiclePhysic().Enable = false;
			kartWithVehicleId.SetLocked(true);
			playerWithVehicleId.GetComponentInChildren<RcVirtualController>().SetDrivingEnabled(false);
			playerWithVehicleId.SetActive(i < 3 || kartWithVehicleId.GetControlType() == RcVehicle.ControlType.Human);
			if (i < 3)
			{
				GameObject gameObject = GameObject.Find(this.m_pPodium.name + "/Kart" + (i + 1).ToString());
				playerWithVehicleId.transform.position = gameObject.transform.position;
				playerWithVehicleId.transform.rotation = gameObject.transform.rotation;
				KartAnim componentInChildren = playerWithVehicleId.GetComponentInChildren<KartAnim>();
				componentInChildren.LaunchDefeatAnim(false);
				componentInChildren.LaunchVictoryAnim(true);
				if (kartWithVehicleId.GetControlType() == RcVehicle.ControlType.Human)
				{
					this.PlayMusic(true);
				}
			}
			else if (kartWithVehicleId.GetControlType() == RcVehicle.ControlType.Human)
			{
				GameObject gameObject2 = GameObject.Find(this.m_pPodium.name + "/Kart4");
				playerWithVehicleId.transform.position = gameObject2.transform.position;
				playerWithVehicleId.transform.rotation = gameObject2.transform.rotation;
				KartAnim anim = kartWithVehicleId.Anim;
				anim.LaunchVictoryAnim(false);
				anim.LaunchDefeatAnim(true);
				this.PlayMusic(false);
			}
		}
	}

	// Token: 0x060009E0 RID: 2528 RVA: 0x00008B8E File Offset: 0x00006D8E
	public override void Exit()
	{
		this.m_fFadeTimer = -1f;
	}

	// Token: 0x060009E1 RID: 2529 RVA: 0x00008B9B File Offset: 0x00006D9B
	public void Next()
	{
		this.OnStateChanged(E_GameState.Result);
	}

	// Token: 0x060009E2 RID: 2530 RVA: 0x00044E5C File Offset: 0x0004305C
	public override void Update()
	{
		if (this.m_fFadeTimer >= 0f)
		{
			this.m_fFadeTimer += Time.deltaTime;
			if (this.m_fFadeTimer > 0.5f)
			{
				this.m_pGameMode.Hud.HUDFade.DoFadeOut(2.5f);
				this.m_fFadeTimer = -1f;
			}
		}
		if (this.m_pCameraAnimation && !this.m_pCameraAnimation.isPlaying && this.m_pGameMode.Hud && !this.m_pGameMode.Hud.HUDPodium.activeSelf)
		{
			this.m_pGameMode.Hud.ShowHudPodium();
		}
	}

	// Token: 0x060009E3 RID: 2531 RVA: 0x00008BA9 File Offset: 0x00006DA9
	public void PlayMusic(bool _Victory)
	{
		if (_Victory)
		{
			Singleton<GameManager>.Instance.SoundManager.PlayMusic(ERaceMusicLoops.PodiumVictory);
		}
		else
		{
			Singleton<GameManager>.Instance.SoundManager.PlayMusic(ERaceMusicLoops.PodiumDefeat);
		}
	}

	// Token: 0x040009FC RID: 2556
	public Camera m_Camera;

	// Token: 0x040009FD RID: 2557
	private GameObject m_pPodium;

	// Token: 0x040009FE RID: 2558
	private float m_fFadeTimer = -1f;

	// Token: 0x040009FF RID: 2559
	private Animation m_pCameraAnimation;
}

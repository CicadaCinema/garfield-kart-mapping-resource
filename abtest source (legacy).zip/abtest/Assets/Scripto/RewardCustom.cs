﻿using System;

// Token: 0x02000161 RID: 353
public class RewardCustom : RewardRandomBase
{
	// Token: 0x06000997 RID: 2455 RVA: 0x00043564 File Offset: 0x00041764
	protected override void GetReward()
	{
		if (this.State == E_UnlockableItemSate.NewLocked && Singleton<GameSaveManager>.Instance.GetCustomState(this.Items[0]) == E_UnlockableItemSate.Hidden)
		{
			foreach (string pCustom in this.Items)
			{
				Singleton<RewardManager>.Instance.ShowCustom(pCustom);
			}
		}
		else if (this.State == E_UnlockableItemSate.NewUnlocked)
		{
			for (int i = 0; i < this.Items.Count; i++)
			{
				Singleton<RewardManager>.Instance.UnlockCustom(this.Items[i], this.Rarities[i]);
			}
		}
	}
}

﻿using System;

// Token: 0x020001B5 RID: 437
public class MenuShop : AbstractMenu
{
}

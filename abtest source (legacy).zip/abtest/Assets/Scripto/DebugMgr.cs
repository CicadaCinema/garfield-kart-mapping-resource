﻿using System;
using System.Diagnostics;
using System.IO;
using UnityEngine;

// Token: 0x0200022E RID: 558
public class DebugMgr
{
	// Token: 0x17000201 RID: 513
	// (get) Token: 0x06000FBD RID: 4029 RVA: 0x0000CA89 File Offset: 0x0000AC89
	public static DebugMgr Instance
	{
		get
		{
			return DebugMgr._instance;
		}
	}

	// Token: 0x17000202 RID: 514
	// (get) Token: 0x06000FBE RID: 4030 RVA: 0x00064388 File Offset: 0x00062588
	// (set) Token: 0x06000FBF RID: 4031 RVA: 0x00003B80 File Offset: 0x00001D80
	public DebugSettingsData dbgData
	{
		get
		{
			if (this._dbgData == null && this.DEBUG_THAT_SHIT_HOMEY)
			{
				this._dbgData = new DebugSettingsData();
			}
			if (this._dbgData == null)
			{
				UnityEngine.Debug.LogWarning("Resources.Load('DebugSettings.asset') returns null");
			}
			return this._dbgData;
		}
		protected set
		{
		}
	}

	// Token: 0x06000FC0 RID: 4032 RVA: 0x0000CA90 File Offset: 0x0000AC90
	public void Start()
	{
		if (this.dbgData.DisplayFPS)
		{
			UnityEngine.Object.DontDestroyOnLoad(UnityEngine.Object.Instantiate(Resources.Load("HudFpsDisplay 1")));
		}
	}

	// Token: 0x06000FC1 RID: 4033 RVA: 0x000643D4 File Offset: 0x000625D4
	protected static string GetHeader(int frame, EDbgCategory cat)
	{
		StackTrace stackTrace = new StackTrace(true);
		string str = Time.time.ToString("0.00");
		string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(stackTrace.GetFrame(frame).GetFileName());
		string text = stackTrace.GetFrame(frame).GetFileLineNumber().ToString();
		string name = stackTrace.GetFrame(frame).GetMethod().Name;
		string text2 = string.Concat(new string[]
		{
			fileNameWithoutExtension,
			":",
			name,
			"(",
			text,
			")\n"
		});
		if (DebugMgr.Instance.dbgData.LogCategory)
		{
			text2 = "[" + cat.ToString() + "] " + text2;
		}
		if (DebugMgr.Instance.dbgData.LogTimeStamp)
		{
			text2 = "[" + str + "] " + text2;
		}
		return text2;
	}

	// Token: 0x06000FC2 RID: 4034 RVA: 0x00003B80 File Offset: 0x00001D80
	public static void Log(object message)
	{
	}

	// Token: 0x06000FC3 RID: 4035 RVA: 0x00003B80 File Offset: 0x00001D80
	public static void Log(object message, EDbgCategory cat)
	{
	}

	// Token: 0x06000FC4 RID: 4036 RVA: 0x0000CAB3 File Offset: 0x0000ACB3
	private static void Log(object message, EDbgCategory cat, int frame)
	{
		if (DebugMgr.Instance.dbgData.Categories[(int)cat])
		{
			UnityEngine.Debug.Log(DebugMgr.GetHeader(frame, cat) + message + "\n\n--------------------\n");
		}
	}

	// Token: 0x06000FC5 RID: 4037 RVA: 0x00003B80 File Offset: 0x00001D80
	public static void LogWarning(object message)
	{
	}

	// Token: 0x06000FC6 RID: 4038 RVA: 0x00003B80 File Offset: 0x00001D80
	public static void LogWarning(object message, EDbgCategory cat)
	{
	}

	// Token: 0x06000FC7 RID: 4039 RVA: 0x0000CADF File Offset: 0x0000ACDF
	public static void LogWarning(object message, EDbgCategory cat, int frame)
	{
		if (DebugMgr.Instance.dbgData.Categories[(int)cat])
		{
			UnityEngine.Debug.LogWarning(DebugMgr.GetHeader(frame, cat) + message + "\n\n--------------------\n");
		}
	}

	// Token: 0x06000FC8 RID: 4040 RVA: 0x0000CB0B File Offset: 0x0000AD0B
	public static void LogError(object message)
	{
		UnityEngine.Debug.LogError(DebugMgr.GetHeader(2, EDbgCategory.ERROR) + message + "\n\n--------------------\n");
	}

	// Token: 0x06000FC9 RID: 4041 RVA: 0x0000CB24 File Offset: 0x0000AD24
	public static void LogError(Exception pException)
	{
		while (pException.InnerException != null)
		{
			pException = pException.InnerException;
		}
	}

	// Token: 0x06000FCA RID: 4042 RVA: 0x0000CB38 File Offset: 0x0000AD38
	public void Update()
	{
		if (Input.GetKeyDown(KeyCode.A))
		{
			this.dbgData.DisplayAnnotation = !this.dbgData.DisplayAnnotation;
		}
	}

	// Token: 0x06000FCB RID: 4043 RVA: 0x0000CB5C File Offset: 0x0000AD5C
	public bool IsAnnotationDisplayed()
	{
		return this.dbgData.DisplayAnnotation;
	}

	// Token: 0x06000FCC RID: 4044 RVA: 0x0000CB69 File Offset: 0x0000AD69
	public bool IsLoadingScreenShortcut()
	{
		return this.dbgData.ShortcutLoadingScreen;
	}

	// Token: 0x06000FCD RID: 4045 RVA: 0x0000CB76 File Offset: 0x0000AD76
	public void LoadDefaultPlayer(int pIndex, GameMode pGameMode)
	{
		this.LoadDefaultPlayer(pIndex, pGameMode, false, false);
	}

	// Token: 0x06000FCE RID: 4046 RVA: 0x000644C0 File Offset: 0x000626C0
	public void LoadDefaultPlayer(int pIndex, GameMode pGameMode, bool pLock, bool isAI)
	{
		if (pGameMode != null)
		{
			pGameMode.CreatePlayer(this.dbgData.DefaultCharacter, this.dbgData.DefaultKart, this.dbgData.DefaultKartCustom.name, this.dbgData.DefaultHat.name, 0, pIndex, pLock, isAI);
		}
	}

	// Token: 0x06000FCF RID: 4047 RVA: 0x00064518 File Offset: 0x00062718
	public void ApplyAdvantages()
	{
		if (this.dbgData.DefaultAdvOne != EAdvantage.None)
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.AddAdvantage(this.dbgData.DefaultAdvOne);
		}
		if (this.dbgData.DefaultAdvTwo != EAdvantage.None)
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.AddAdvantage(this.dbgData.DefaultAdvTwo);
		}
		if (this.dbgData.DefaultAdvThree != EAdvantage.None)
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.AddAdvantage(this.dbgData.DefaultAdvThree);
		}
		if (this.dbgData.DefaultAdvFour != EAdvantage.None)
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.AddAdvantage(this.dbgData.DefaultAdvFour);
		}
	}

	// Token: 0x04000F2E RID: 3886
	private static DebugMgr _instance;

	// Token: 0x04000F2F RID: 3887
	private DebugSettingsData _dbgData;

	// Token: 0x04000F30 RID: 3888
	public bool DEBUG_THAT_SHIT_HOMEY = false;
}

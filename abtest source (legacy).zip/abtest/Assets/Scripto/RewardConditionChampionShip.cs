﻿using System;

// Token: 0x0200015D RID: 349
public class RewardConditionChampionShip : RewardConditionBase
{
	// Token: 0x06000991 RID: 2449 RVA: 0x00043450 File Offset: 0x00041650
	public override bool CanGiveReward()
	{
		int num = Singleton<GameSaveManager>.Instance.GetRank(this.ChampionShip, this.Difficulty);
		if (this.ChampionShip.Equals(Singleton<GameConfigurator>.Instance.ChampionShipData.name) && this.Difficulty == Singleton<GameConfigurator>.Instance.Difficulty)
		{
			int playerRank = Singleton<RewardManager>.Instance.PlayerRank;
			if (num == -1 || playerRank < num)
			{
				num = playerRank;
			}
		}
		return num >= 0 && num <= this.Rank;
	}

	// Token: 0x040009C5 RID: 2501
	public string ChampionShip;

	// Token: 0x040009C6 RID: 2502
	public EDifficulty Difficulty;

	// Token: 0x040009C7 RID: 2503
	public int Rank;
}

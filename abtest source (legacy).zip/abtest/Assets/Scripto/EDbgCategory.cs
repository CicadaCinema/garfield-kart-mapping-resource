﻿using System;

// Token: 0x02000230 RID: 560
public enum EDbgCategory
{
	// Token: 0x04000F32 RID: 3890
	GENERAL,
	// Token: 0x04000F33 RID: 3891
	GAMESTATE,
	// Token: 0x04000F34 RID: 3892
	DATA,
	// Token: 0x04000F35 RID: 3893
	PROFILE,
	// Token: 0x04000F36 RID: 3894
	CAMERA,
	// Token: 0x04000F37 RID: 3895
	INAPP,
	// Token: 0x04000F38 RID: 3896
	GUI,
	// Token: 0x04000F39 RID: 3897
	ERROR
}

﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000129 RID: 297
public class UITexturePattern : MonoBehaviour
{
	// Token: 0x06000818 RID: 2072 RVA: 0x0003D180 File Offset: 0x0003B380
	public void ChangeTexture(int iNum)
	{
		iNum %= this.m_sTextureName.Count;
		UISprite component = base.GetComponent<UISprite>();
		if (component)
		{
			component.spriteName = this.m_sTextureName[iNum];
		}
	}

	// Token: 0x04000857 RID: 2135
	public List<string> m_sTextureName = new List<string>();
}

﻿using System;
using UnityEngine;

// Token: 0x0200011A RID: 282
public class HUDResultsTimeTrial : MonoBehaviour
{
	// Token: 0x060007C9 RID: 1993 RVA: 0x0000781E File Offset: 0x00005A1E
	public void SetPreviousMedal(E_TimeTrialMedal Medal)
	{
		this.m_ePreviousMedal = Medal;
	}

	// Token: 0x060007CA RID: 1994 RVA: 0x0003A8D8 File Offset: 0x00038AD8
	public void Start()
	{
		for (int i = 0; i < this.Medals.Length; i++)
		{
			this.Medals[i].SetActive(i <= this.m_ePreviousMedal - E_TimeTrialMedal.Bronze);
		}
		string startScene = Singleton<GameConfigurator>.Instance.StartScene;
		this.CurrMedal = Singleton<GameSaveManager>.Instance.GetMedal(startScene, false);
		if (this.m_ePreviousMedal < this.CurrMedal)
		{
			this.m_bDeferedDisplay = true;
			this.m_ePreviousMedal++;
			this.MedalEarned.text = string.Format(Localization.instance.Get("MENU_REWARDS_TIME_TRIAL_MEDAL"), Localization.instance.Get("MENU_REWARDS_MEDAL" + (int)this.CurrMedal));
			this.Summary.text = Localization.instance.Get("HUD_FINISHRACE_FINISHFIRST");
		}
		else
		{
			Singleton<GameManager>.Instance.GameMode.Hud.DoNext();
		}
		this.ChampionshipIcon.ChangeTexture(Singleton<GameConfigurator>.Instance.ChampionShipData.Index);
		this.DifficultyIcon.ChangeTexture((int)Singleton<GameConfigurator>.Instance.Difficulty);
		if (Singleton<GameConfigurator>.Instance.ChampionShipData != null)
		{
			this.TrackName.text = Singleton<GameConfigurator>.Instance.ChampionShipData.TracksName[Singleton<GameConfigurator>.Instance.CurrentTrackIndex];
		}
		this.m_cEntryPoint = GameObject.Find("EntryPoint").GetComponent<EntryPoint>();
		this.FacebookButton.SetActive(false);
	}

	// Token: 0x060007CB RID: 1995 RVA: 0x0003AA58 File Offset: 0x00038C58
	public void Update()
	{
		if (this.m_bDeferedDisplay)
		{
			if (!this.Medals[this.m_ePreviousMedal - E_TimeTrialMedal.Bronze].activeSelf)
			{
				this.Medals[this.m_ePreviousMedal - E_TimeTrialMedal.Bronze].SetActive(true);
				this.Medals[this.m_ePreviousMedal - E_TimeTrialMedal.Bronze].animation.Play();
			}
			if (this.m_ePreviousMedal >= this.CurrMedal)
			{
				this.m_bDeferedDisplay = false;
			}
			if (!this.Medals[this.m_ePreviousMedal - E_TimeTrialMedal.Bronze].animation.isPlaying)
			{
				this.m_ePreviousMedal++;
			}
		}
	}

	// Token: 0x060007CC RID: 1996 RVA: 0x0003AAFC File Offset: 0x00038CFC
	public void OnFacebook()
	{
		if (this.m_cEntryPoint)
		{
			string sTitle = string.Empty;
			int currMedal = (int)this.CurrMedal;
			string startScene = Singleton<GameConfigurator>.Instance.StartScene;
			string empty = string.Empty;
			Singleton<GameSaveManager>.Instance.GetTimeTrialRecord(startScene, ref empty);
			sTitle = string.Format(Localization.instance.Get("FB_TIMETRIAL_TITLE_" + currMedal), Localization.instance.Get("MENU_REWARDS_MEDAL" + (int)this.CurrMedal), Singleton<GameConfigurator>.Instance.ChampionShipData.TracksName[Singleton<GameConfigurator>.Instance.CurrentTrackIndex]);
			string sDescription = string.Format(Localization.instance.Get("FB_TIMETRIAL_DESCRIPTION"), empty);
			this.m_cEntryPoint.OnFacebook(sTitle, sDescription);
		}
	}

	// Token: 0x040007D2 RID: 2002
	public GameObject[] Medals;

	// Token: 0x040007D3 RID: 2003
	public UILabel TrackName;

	// Token: 0x040007D4 RID: 2004
	public UILabel Summary;

	// Token: 0x040007D5 RID: 2005
	public UILabel MedalEarned;

	// Token: 0x040007D6 RID: 2006
	public UITexturePattern DifficultyIcon;

	// Token: 0x040007D7 RID: 2007
	public UITexturePattern ChampionshipIcon;

	// Token: 0x040007D8 RID: 2008
	public GameObject GUIMedalEarned;

	// Token: 0x040007D9 RID: 2009
	public GameObject FacebookButton;

	// Token: 0x040007DA RID: 2010
	private EntryPoint m_cEntryPoint;

	// Token: 0x040007DB RID: 2011
	private E_TimeTrialMedal m_ePreviousMedal;

	// Token: 0x040007DC RID: 2012
	private bool m_bDeferedDisplay;

	// Token: 0x040007DD RID: 2013
	private E_TimeTrialMedal CurrMedal;
}

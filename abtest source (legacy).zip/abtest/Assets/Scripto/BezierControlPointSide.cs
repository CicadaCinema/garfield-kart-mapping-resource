﻿using System;

// Token: 0x02000246 RID: 582
public enum BezierControlPointSide
{
	// Token: 0x04000F8C RID: 3980
	None,
	// Token: 0x04000F8D RID: 3981
	Left,
	// Token: 0x04000F8E RID: 3982
	Right
}

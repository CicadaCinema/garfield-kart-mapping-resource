﻿using System;

// Token: 0x020001A7 RID: 423
public class MenuRewardsCharacters : MenuRewards
{
	// Token: 0x06000B6A RID: 2922 RVA: 0x0004CC74 File Offset: 0x0004AE74
	public override void OnEnter()
	{
		base.OnEnter();
		this._character = Singleton<RewardManager>.Instance.PopCharacter();
		this.LbRewardName.text = this._character.ToString();
		if (this.Sprite != null)
		{
			this.Sprite.GetComponent<UITexturePattern>().ChangeTexture((int)this._character);
		}
		this.LbMessage.text = Localization.instance.Get("MENU_REWARDS_PERSONNAGE");
	}

	// Token: 0x06000B6B RID: 2923 RVA: 0x00009F14 File Offset: 0x00008114
	public override void OnGoNext()
	{
		Singleton<GameSaveManager>.Instance.SetCharacterState(this._character, E_UnlockableItemSate.NewUnlocked, false);
		base.OnGoNext();
	}

	// Token: 0x04000B2E RID: 2862
	private ECharacter _character;
}

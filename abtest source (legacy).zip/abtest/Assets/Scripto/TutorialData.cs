﻿using System;
using System.Collections.Generic;

// Token: 0x020000FC RID: 252
public class TutorialData : IconCarac
{
	// Token: 0x040006BE RID: 1726
	public UIAtlas atlas;

	// Token: 0x040006BF RID: 1727
	public MenuTutorial.ETutoMode m_eTutoType;

	// Token: 0x040006C0 RID: 1728
	public bool bShownOnPc;

	// Token: 0x040006C1 RID: 1729
	public bool bShownOnMac;

	// Token: 0x040006C2 RID: 1730
	public bool bShownOnIPhone;

	// Token: 0x040006C3 RID: 1731
	public bool bShownOnAndroid;

	// Token: 0x040006C4 RID: 1732
	public List<string> m_LabelId;
}

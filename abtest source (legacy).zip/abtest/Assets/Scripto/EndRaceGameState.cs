﻿using System;
using UnityEngine;

// Token: 0x0200016D RID: 365
public class EndRaceGameState : GameState
{
	// Token: 0x060009D9 RID: 2521 RVA: 0x00008B41 File Offset: 0x00006D41
	public override void Enter()
	{
		this.m_pGameMode.Hud.HUDFinish.EndState = this;
		this.m_pGameMode.Hud.EnterFinishRace();
	}

	// Token: 0x060009DA RID: 2522 RVA: 0x00008B69 File Offset: 0x00006D69
	public override void Exit()
	{
		this.m_pGameMode.Hud.ExitFinishRace();
	}

	// Token: 0x060009DB RID: 2523 RVA: 0x00044A30 File Offset: 0x00042C30
	public void Next()
	{
		this.OnStateChanged(E_GameState.Result);
		EntryPoint component = GameObject.Find("EntryPoint").GetComponent<EntryPoint>();
		component.AskForRating = true;
		component.AskForSharing = true;
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			component.ShowInterstitial = true;
		}
	}

	// Token: 0x060009DC RID: 2524 RVA: 0x00044A78 File Offset: 0x00042C78
	public override void Update()
	{
		if (!Singleton<GameManager>.Instance.SoundManager.SoundsList[3].isPlaying && !Singleton<GameManager>.Instance.SoundManager.SoundsList[4].isPlaying)
		{
			Singleton<GameManager>.Instance.SoundManager.SetMusic(ERaceMusicLoops.InterRace);
			Singleton<GameManager>.Instance.SoundManager.PlayMusic();
		}
	}
}

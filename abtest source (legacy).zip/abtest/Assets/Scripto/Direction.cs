﻿using System;

namespace AnimationOrTween
{
	// Token: 0x02000039 RID: 57
	public enum Direction
	{
		// Token: 0x0400014B RID: 331
		Reverse = -1,
		// Token: 0x0400014C RID: 332
		Toggle,
		// Token: 0x0400014D RID: 333
		Forward
	}
}

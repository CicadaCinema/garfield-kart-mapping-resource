﻿using System;
using UnityEngine;

// Token: 0x0200020E RID: 526
[Serializable]
public class SurfaceSounds
{
	// Token: 0x04000DFB RID: 3579
	public LayerMask Mask;

	// Token: 0x04000DFC RID: 3580
	public AudioSource Sound;
}

﻿using System;

// Token: 0x02000233 RID: 563
[AttributeUsage(AttributeTargets.Property)]
public class ExposePropertyAttribute : Attribute
{
}

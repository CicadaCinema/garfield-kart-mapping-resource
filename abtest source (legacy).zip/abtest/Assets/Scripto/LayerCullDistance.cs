﻿using System;
using UnityEngine;

// Token: 0x020001CE RID: 462
public class LayerCullDistance : MonoBehaviour
{
	// Token: 0x06000C87 RID: 3207 RVA: 0x000532C0 File Offset: 0x000514C0
	public void ChangeDistancePopMesh()
	{
		float[] array = new float[32];
		array[24] = (float)this.distanceToCullNear;
		array[25] = (float)this.distanceToCullMed;
		array[26] = (float)this.distanceToCullFar;
		base.camera.layerCullDistances = array;
	}

	// Token: 0x04000C2E RID: 3118
	[HideInInspector]
	public int distanceToCullNear;

	// Token: 0x04000C2F RID: 3119
	[HideInInspector]
	public int distanceToCullMed;

	// Token: 0x04000C30 RID: 3120
	[HideInInspector]
	public int distanceToCullFar;
}

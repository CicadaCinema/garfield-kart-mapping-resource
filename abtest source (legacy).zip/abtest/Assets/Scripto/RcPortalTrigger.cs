﻿using System;
using UnityEngine;

// Token: 0x02000216 RID: 534
public class RcPortalTrigger : MonoBehaviour
{
	// Token: 0x06000EDA RID: 3802 RVA: 0x0000C366 File Offset: 0x0000A566
	public RcPortalTrigger()
	{
		this.m_eTriggerType = RcPortalTrigger.PortalType.Vertical;
		this.m_eTriggerSide = RcPortalTrigger.PortalSide.None;
		this.m_eSideTriggered = RcPortalTrigger.PortalSide.None;
		this.m_iId = 0;
		this.m_eActionType = RcPortalTrigger.PortalAction.StartLine;
		this.m_pRace = null;
	}

	// Token: 0x06000EDB RID: 3803 RVA: 0x0000C398 File Offset: 0x0000A598
	public void Awake()
	{
		if (base.networkView == null)
		{
		}
		base.networkView.stateSynchronization = NetworkStateSynchronization.ReliableDeltaCompressed;
		base.networkView.observed = null;
	}

	// Token: 0x06000EDC RID: 3804 RVA: 0x0005D8D8 File Offset: 0x0005BAD8
	public void Start()
	{
		this.m_pRace = (RcRace)UnityEngine.Object.FindObjectOfType(typeof(RcRace));
		BoxCollider boxCollider = (BoxCollider)base.collider;
		Vector3 size = boxCollider.size;
		this.m_vTR = base.transform.position + base.transform.rotation * new Vector3(size.x, size.y, 0f);
		this.m_vBL = base.transform.position + base.transform.rotation * new Vector3(-size.x, -size.y, 0f);
		this.m_vBLtoTL = (this.m_vBLtoBR = this.m_vTR - this.m_vBL);
		if (this.m_eTriggerType == RcPortalTrigger.PortalType.Vertical)
		{
			this.m_vBLtoBR.y = 0f;
			this.m_vBLtoTL.x = 0f;
			this.m_vBLtoTL.z = 0f;
		}
		else if (this.m_eTriggerType == RcPortalTrigger.PortalType.Horizontal)
		{
			this.m_vBLtoBR.z = 0f;
			this.m_vBLtoTL.x = 0f;
			this.m_vBLtoTL.y = 0f;
		}
		this.m_vNormal = Vector3.Cross(this.m_vBLtoBR, this.m_vBLtoTL);
		this.m_vNormal.Normalize();
	}

	// Token: 0x06000EDD RID: 3805 RVA: 0x0005DA50 File Offset: 0x0005BC50
	public virtual void OnTriggerEnter(Collider other)
	{
		if (!base.enabled)
		{
			return;
		}
		if (!this.IsTriggeredBy(other))
		{
			return;
		}
		RcVehicleRaceStats componentInChildren = other.gameObject.GetComponentInChildren<RcVehicleRaceStats>();
		if (componentInChildren && this.m_pRace)
		{
			if (Network.isServer)
			{
				NetworkViewID viewID = other.gameObject.networkView.viewID;
				base.networkView.RPC("VehicleTriggerred", RPCMode.All, new object[]
				{
					viewID,
					(int)this.m_eSideTriggered
				});
			}
			else if (Network.peerType == NetworkPeerType.Disconnected)
			{
				this.DoVehicleTriggerred(componentInChildren, (int)this.m_eSideTriggered);
			}
		}
	}

	// Token: 0x06000EDE RID: 3806 RVA: 0x0005DB04 File Offset: 0x0005BD04
	public void DoVehicleTriggerred(RcVehicleRaceStats pStats, int side)
	{
		if (pStats)
		{
			if (side == 1)
			{
				if (this.m_eActionType == RcPortalTrigger.PortalAction.StartLine)
				{
					this.m_pRace.CrossStartLine(pStats, false);
				}
				else if (this.m_eActionType == RcPortalTrigger.PortalAction.EndLine)
				{
					this.m_pRace.CrossEndLine(pStats);
				}
				else if (this.m_eActionType == RcPortalTrigger.PortalAction.CheckPoint)
				{
					this.m_pRace.CrossCheckPoint(pStats, this.m_iId);
				}
				else if (this.m_eActionType == RcPortalTrigger.PortalAction.RefreshRespawn)
				{
					this.m_pRace.ForceRefreshRespawn(pStats);
				}
			}
			else if (side == 2)
			{
				if (this.m_eActionType == RcPortalTrigger.PortalAction.StartLine)
				{
					this.m_pRace.CrossStartLine(pStats, true);
				}
				else if (this.m_eActionType == RcPortalTrigger.PortalAction.CheckPoint)
				{
					this.m_pRace.CrossCheckPoint(pStats, this.m_iId);
				}
				else if (this.m_eActionType == RcPortalTrigger.PortalAction.RefreshRespawn)
				{
					this.m_pRace.ForceRefreshRespawn(pStats);
				}
			}
		}
	}

	// Token: 0x06000EDF RID: 3807 RVA: 0x0005DC00 File Offset: 0x0005BE00
	[RPC]
	public void VehicleTriggerred(NetworkViewID vehicleId, int side)
	{
		if (this.m_pRace)
		{
			RcVehicleRaceStats vehicleStats = this.m_pRace.GetVehicleStats(vehicleId);
			this.DoVehicleTriggerred(vehicleStats, side);
		}
	}

	// Token: 0x06000EE0 RID: 3808 RVA: 0x0005DC34 File Offset: 0x0005BE34
	public bool IsTriggeredBy(Collider other)
	{
		if (this.m_eTriggerSide == RcPortalTrigger.PortalSide.None)
		{
			return false;
		}
		RcVehicle componentInChildren = other.gameObject.GetComponentInChildren<RcVehicle>();
		if (componentInChildren == null)
		{
			return false;
		}
		Vector3 position = componentInChildren.GetPosition();
		Vector3 lastFramePos = componentInChildren.GetLastFramePos();
		if ((this.m_eTriggerSide == RcPortalTrigger.PortalSide.Normal || this.m_eTriggerSide == RcPortalTrigger.PortalSide.Both) && this.IsCrossingPortal(lastFramePos, position))
		{
			this.m_eSideTriggered = RcPortalTrigger.PortalSide.Normal;
			return true;
		}
		if ((this.m_eTriggerSide == RcPortalTrigger.PortalSide.Reverse || this.m_eTriggerSide == RcPortalTrigger.PortalSide.Both) && this.IsCrossingPortal(position, lastFramePos))
		{
			this.m_eSideTriggered = RcPortalTrigger.PortalSide.Reverse;
			return true;
		}
		return false;
	}

	// Token: 0x06000EE1 RID: 3809 RVA: 0x0005DCD4 File Offset: 0x0005BED4
	public bool IsCrossingPortal(Vector3 _Start, Vector3 _End)
	{
		Vector3 lhs = _End - _Start;
		float num = Vector3.Dot(lhs, this.m_vNormal);
		return num >= 0f;
	}

	// Token: 0x04000E5B RID: 3675
	public RcPortalTrigger.PortalType m_eTriggerType;

	// Token: 0x04000E5C RID: 3676
	public RcPortalTrigger.PortalSide m_eTriggerSide;

	// Token: 0x04000E5D RID: 3677
	public RcPortalTrigger.PortalAction m_eActionType;

	// Token: 0x04000E5E RID: 3678
	public int m_iId;

	// Token: 0x04000E5F RID: 3679
	private RcPortalTrigger.PortalSide m_eSideTriggered;

	// Token: 0x04000E60 RID: 3680
	private Vector3 m_vBL;

	// Token: 0x04000E61 RID: 3681
	private Vector3 m_vTR;

	// Token: 0x04000E62 RID: 3682
	private Vector3 m_vBLtoTL;

	// Token: 0x04000E63 RID: 3683
	private Vector3 m_vBLtoBR;

	// Token: 0x04000E64 RID: 3684
	private Vector3 m_vNormal;

	// Token: 0x04000E65 RID: 3685
	private RcRace m_pRace;

	// Token: 0x02000217 RID: 535
	public enum PortalType
	{
		// Token: 0x04000E67 RID: 3687
		Vertical,
		// Token: 0x04000E68 RID: 3688
		Horizontal
	}

	// Token: 0x02000218 RID: 536
	public enum PortalSide
	{
		// Token: 0x04000E6A RID: 3690
		None,
		// Token: 0x04000E6B RID: 3691
		Normal,
		// Token: 0x04000E6C RID: 3692
		Reverse,
		// Token: 0x04000E6D RID: 3693
		Both
	}

	// Token: 0x02000219 RID: 537
	public enum PortalAction
	{
		// Token: 0x04000E6F RID: 3695
		StartLine,
		// Token: 0x04000E70 RID: 3696
		EndLine,
		// Token: 0x04000E71 RID: 3697
		CheckPoint,
		// Token: 0x04000E72 RID: 3698
		RefreshRespawn
	}
}

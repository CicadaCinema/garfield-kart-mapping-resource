﻿using System;
using UnityEngine;

// Token: 0x02000197 RID: 407
public class GarfieldMenuBackGround : MonoBehaviour
{
	// Token: 0x06000AFA RID: 2810 RVA: 0x0000986C File Offset: 0x00007A6C
	public void selectBackgroundAnim()
	{
		this.menu.SelectRandomMenuAnim();
	}

	// Token: 0x04000AC8 RID: 2760
	public MenuEntryPoint menu;
}

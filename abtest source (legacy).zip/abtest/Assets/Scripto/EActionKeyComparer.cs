﻿using System;
using System.Collections.Generic;

// Token: 0x02000238 RID: 568
public class EActionKeyComparer : IEqualityComparer<EAction>
{
	// Token: 0x06000FF2 RID: 4082 RVA: 0x0000CCA8 File Offset: 0x0000AEA8
	public bool Equals(EAction x, EAction y)
	{
		return x == y;
	}

	// Token: 0x06000FF3 RID: 4083 RVA: 0x0000CCAE File Offset: 0x0000AEAE
	public int GetHashCode(EAction x)
	{
		return (int)x;
	}
}

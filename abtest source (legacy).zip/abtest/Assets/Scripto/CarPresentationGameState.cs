﻿using System;
using UnityEngine;

// Token: 0x0200016C RID: 364
public class CarPresentationGameState : GameState
{
	// Token: 0x060009D4 RID: 2516 RVA: 0x000448A4 File Offset: 0x00042AA4
	public override void Enter()
	{
		Singleton<GameManager>.Instance.GameMode.Hud.HUDPause.CreateNamePlates();
		Singleton<GameManager>.Instance.SoundManager.StopMusic();
		Camera.main.GetComponent<CameraBase>().SwitchCamera(ECamState.CarPres, ECamState.TransCut);
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
		{
			Kart kart = this.m_pGameMode.GetKart(0);
			KartSound kartSound = kart.KartSound;
			if (kartSound != null)
			{
				kartSound.StartSound();
			}
			this._presentationTimer = 0f;
		}
		else
		{
			for (int i = 0; i < this.m_pGameMode.PlayerCount; i++)
			{
				Kart kart2 = this.m_pGameMode.GetKart(i);
				if (kart2)
				{
					KartSound kartSound2 = kart2.KartSound;
					if (kartSound2 != null)
					{
						kartSound2.StartSound();
					}
				}
			}
		}
		Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.JingleCountdown);
	}

	// Token: 0x060009D5 RID: 2517 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void Exit()
	{
	}

	// Token: 0x060009D6 RID: 2518 RVA: 0x00044994 File Offset: 0x00042B94
	public override void Update()
	{
		this._presentationTimer -= Time.deltaTime;
		if (this._presentationTimer < 0f || Input.anyKeyDown)
		{
			if (Network.peerType == NetworkPeerType.Disconnected && Singleton<GameSaveManager>.Instance.GetShowTutorial())
			{
				this.OnStateChanged(E_GameState.Tutorial);
			}
			else if (Network.isServer)
			{
				base.networkView.RPC("CountDown", RPCMode.All, new object[0]);
			}
			else if (!Network.isClient)
			{
				this.CountDown();
			}
		}
	}

	// Token: 0x060009D7 RID: 2519 RVA: 0x00008B2B File Offset: 0x00006D2B
	[RPC]
	public void CountDown()
	{
		this.OnStateChanged(E_GameState.Start);
	}

	// Token: 0x040009FB RID: 2555
	private float _presentationTimer = 3f;
}

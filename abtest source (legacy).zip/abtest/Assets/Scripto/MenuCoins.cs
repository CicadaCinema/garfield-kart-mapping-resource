﻿using System;

// Token: 0x0200019C RID: 412
public class MenuCoins : AbstractMenu
{
}

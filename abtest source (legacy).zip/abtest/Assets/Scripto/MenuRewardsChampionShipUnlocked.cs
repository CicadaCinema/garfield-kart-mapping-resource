﻿using System;

// Token: 0x020001A6 RID: 422
public class MenuRewardsChampionShipUnlocked : MenuRewards
{
	// Token: 0x06000B67 RID: 2919 RVA: 0x0004CB80 File Offset: 0x0004AD80
	public override void OnEnter()
	{
		base.OnEnter();
		Tuple<string, EDifficulty> tuple = Singleton<RewardManager>.Instance.PopUnlockedChampionShip();
		this._championShip = tuple.Item1;
		this._difficulty = tuple.Item2;
		this.LbRewardName.text = Localization.instance.Get("CHAMPIONSHIP_NAME_" + this._championShip[this._championShip.Length - 1]);
		this.LbMessage.text = string.Format(Localization.instance.Get("MENU_REWARDS_NOUVEAU_CHAMPIONNAT_DEBLOQUE"), Localization.instance.Get("MENU_DIFFICULTY_" + this._difficulty.ToString().ToUpper()));
		this.Sprite.GetComponent<UITexturePattern>().ChangeTexture(int.Parse(this._championShip[this._championShip.Length - 1].ToString()) - 1);
	}

	// Token: 0x06000B68 RID: 2920 RVA: 0x00009EF4 File Offset: 0x000080F4
	public override void OnGoNext()
	{
		Singleton<GameSaveManager>.Instance.SetChampionShipState(this._championShip, this._difficulty, E_UnlockableItemSate.NewUnlocked, false);
		base.OnGoNext();
	}

	// Token: 0x04000B2C RID: 2860
	private string _championShip;

	// Token: 0x04000B2D RID: 2861
	private EDifficulty _difficulty;
}

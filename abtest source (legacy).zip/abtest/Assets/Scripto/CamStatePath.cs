﻿using System;
using UnityEngine;

// Token: 0x020001ED RID: 493
public class CamStatePath : CamState
{
	// Token: 0x170001CF RID: 463
	// (get) Token: 0x06000D5F RID: 3423 RVA: 0x0000B1F1 File Offset: 0x000093F1
	public override ECamState state
	{
		get
		{
			return ECamState.Path;
		}
	}

	// Token: 0x06000D60 RID: 3424 RVA: 0x0000B1F4 File Offset: 0x000093F4
	public void Setup(RcMultiPath _pathToFollow)
	{
		this.m_Path = _pathToFollow;
	}

	// Token: 0x06000D61 RID: 3425 RVA: 0x00057598 File Offset: 0x00055798
	public override void Enter(Transform _Transform, Transform _Target)
	{
		base.Enter(_Transform, _Target);
		GameObject gameObject = GameObject.Find("Start");
		base.m_Target = new GameObject().transform;
		Transform transform = base.m_Target.transform;
		Vector3 position = gameObject.transform.position;
		base.m_Transform.position = position;
		transform.position = position;
		Transform transform2 = base.m_Target.transform;
		Quaternion rotation = gameObject.transform.rotation;
		base.m_Transform.rotation = rotation;
		transform2.rotation = rotation;
		this.m_PathPosition = MultiPathPosition.UNDEFINED_MP_POS;
		this.m_NextPathPosition = MultiPathPosition.UNDEFINED_MP_POS;
		this.m_Path.UpdateMPPosition(ref this.m_PathPosition, base.m_Target.position, 0, 0, false);
	}

	// Token: 0x06000D62 RID: 3426 RVA: 0x00057650 File Offset: 0x00055850
	public override ECamState Manage(float dt)
	{
		this.m_Path.UpdateMPPosition(ref this.m_PathPosition, base.m_Target.position, 3, 1, false);
		this.m_NextPathPosition = this.m_PathPosition;
		Vector3 a = Vector3.zero;
		RcMultiPathSection rcMultiPathSection = this.m_PathPosition.section;
		a = rcMultiPathSection.GetSimplePath().MoveOnPath(ref this.m_NextPathPosition.pathPosition, ref this.LookDistance, false);
		if (this.m_NextPathPosition.pathPosition.index == this.m_PathPosition.section.GetSimplePath().GetNbPoints() - 1)
		{
			float num = 1E+38f;
			foreach (RcMultiPathSection rcMultiPathSection2 in this.m_PathPosition.section.m_pAfterBranches)
			{
				if (rcMultiPathSection2 && rcMultiPathSection2.GetDistToEndLine() < num)
				{
					rcMultiPathSection = rcMultiPathSection2;
					num = rcMultiPathSection2.GetDistToEndLine();
				}
			}
			if (rcMultiPathSection != null)
			{
				this.m_NextPathPosition.pathPosition = PathPosition.UNDEFINED_POSITION;
			}
			a = rcMultiPathSection.GetSimplePath().MoveOnPath(ref this.m_NextPathPosition.pathPosition, ref this.LookDistance, false);
		}
		a += Vector3.up * this.TargetHeight;
		Vector3 normalized = (a - base.m_Target.position).normalized;
		Quaternion rotation = default(Quaternion);
		if (normalized != Vector3.zero)
		{
			base.m_Target.position += dt * (normalized * this.Speed);
			rotation = Quaternion.Lerp(base.m_Target.rotation, Quaternion.LookRotation(normalized), dt * this.TargetDamping);
			base.m_Target.rotation = rotation;
		}
		base.m_Transform.position = Vector3.Lerp(base.m_Transform.position, base.m_Target.position + rotation * this.Offset, dt * this.PosDamping);
		base.m_Transform.LookAt(base.m_Target);
		return this.state;
	}

	// Token: 0x06000D63 RID: 3427 RVA: 0x0000B1FD File Offset: 0x000093FD
	public override void Exit()
	{
		UnityEngine.Object.DestroyImmediate(base.m_Target.gameObject);
		base.m_Target = null;
	}

	// Token: 0x04000D0C RID: 3340
	private RcMultiPath m_Path;

	// Token: 0x04000D0D RID: 3341
	private MultiPathPosition m_PathPosition;

	// Token: 0x04000D0E RID: 3342
	private MultiPathPosition m_NextPathPosition;

	// Token: 0x04000D0F RID: 3343
	public float LookDistance = 5f;

	// Token: 0x04000D10 RID: 3344
	public float Speed = 10f;

	// Token: 0x04000D11 RID: 3345
	public float TargetHeight = 2f;

	// Token: 0x04000D12 RID: 3346
	public Vector3 Offset = new Vector3(0f, 0.5f, -3f);

	// Token: 0x04000D13 RID: 3347
	public float TargetDamping = 1f;

	// Token: 0x04000D14 RID: 3348
	public float PosDamping = 1f;
}

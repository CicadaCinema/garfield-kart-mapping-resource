﻿using System;
using UnityEngine;

// Token: 0x02000056 RID: 86
public class AnimatedAlpha : MonoBehaviour
{
	// Token: 0x0600024C RID: 588 RVA: 0x00003BA8 File Offset: 0x00001DA8
	private void Awake()
	{
		this.mWidget = base.GetComponent<UIWidget>();
		this.mPanel = base.GetComponent<UIPanel>();
		this.Update();
	}

	// Token: 0x0600024D RID: 589 RVA: 0x0001804C File Offset: 0x0001624C
	private void Update()
	{
		if (this.mWidget != null)
		{
			this.mWidget.alpha = this.alpha;
		}
		if (this.mPanel != null)
		{
			this.mPanel.alpha = this.alpha;
		}
	}

	// Token: 0x040001D6 RID: 470
	public float alpha = 1f;

	// Token: 0x040001D7 RID: 471
	private UIWidget mWidget;

	// Token: 0x040001D8 RID: 472
	private UIPanel mPanel;
}

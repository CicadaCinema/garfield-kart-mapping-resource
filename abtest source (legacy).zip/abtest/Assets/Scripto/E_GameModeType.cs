﻿using System;

// Token: 0x020000B4 RID: 180
public enum E_GameModeType
{
	// Token: 0x0400044D RID: 1101
	DEBUG,
	// Token: 0x0400044E RID: 1102
	DEBUG_AI,
	// Token: 0x0400044F RID: 1103
	SINGLE,
	// Token: 0x04000450 RID: 1104
	CHAMPIONSHIP,
	// Token: 0x04000451 RID: 1105
	TIME_TRIAL,
	// Token: 0x04000452 RID: 1106
	TUTORIAL
}

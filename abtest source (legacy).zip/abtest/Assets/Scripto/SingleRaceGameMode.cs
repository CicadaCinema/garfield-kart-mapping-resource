﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000188 RID: 392
public class SingleRaceGameMode : InGameGameMode
{
	// Token: 0x06000A75 RID: 2677 RVA: 0x00008DA4 File Offset: 0x00006FA4
	public override void Dispose()
	{
		base.Dispose();
		ChanceDispatcher chanceDispatcher = this._chanceDispatcher;
		chanceDispatcher.OnCreatePlayer = (Action<PlayerData, int>)Delegate.Remove(chanceDispatcher.OnCreatePlayer, new Action<PlayerData, int>(this.AddPlayerData));
	}

	// Token: 0x06000A76 RID: 2678 RVA: 0x000093B9 File Offset: 0x000075B9
	public override void Awake()
	{
		base.Awake();
		ChanceDispatcher chanceDispatcher = this._chanceDispatcher;
		chanceDispatcher.OnCreatePlayer = (Action<PlayerData, int>)Delegate.Combine(chanceDispatcher.OnCreatePlayer, new Action<PlayerData, int>(this.AddPlayerData));
	}

	// Token: 0x06000A77 RID: 2679 RVA: 0x00008DD4 File Offset: 0x00006FD4
	public override void CreatePlayers()
	{
		base.CreatePlayers();
		base.SubscribeRaceEnd();
	}

	// Token: 0x06000A78 RID: 2680 RVA: 0x000473C4 File Offset: 0x000455C4
	protected override void RaceEnd(RcVehicle pVehicle)
	{
		base.RaceEnd(pVehicle);
		int rank = pVehicle.RaceStats.GetRank();
		Kart kart = (Kart)pVehicle;
		if (kart.GetControlType() == RcVehicle.ControlType.Human)
		{
			base.Hud.HUDFinish.FillRank(rank);
		}
		if (rank == 0)
		{
			kart.KartSound.PlayVoice(KartSound.EVoices.Selection);
			kart.Anim.LaunchVictoryAnim(true);
		}
		else if (rank > 2)
		{
			kart.KartSound.PlayVoice(KartSound.EVoices.Bad);
			kart.Anim.LaunchDefeatAnim(true);
		}
		else
		{
			kart.KartSound.PlayVoice(KartSound.EVoices.Good);
			kart.Anim.LaunchSuccessAnim(true);
		}
		Singleton<RewardManager>.Instance.EndSingleRace(rank, true);
		base.PlayEndOfRaceSound(rank == 0);
		Singleton<RewardManager>.Instance.CanUnlockPuzzlePieces(true);
	}

	// Token: 0x06000A79 RID: 2681 RVA: 0x00045A90 File Offset: 0x00043C90
	public override void UpdateScores()
	{
		List<Tuple<int, GameObject>> list = new List<Tuple<int, GameObject>>();
		int num = 0;
		for (int i = 0; i < 6; i++)
		{
			Kart kart = base.GetKart(i);
			GameObject player = base.GetPlayer(i);
			RcVehicleRaceStats raceStats = kart.RaceStats;
			if (raceStats.IsRaceEnded() || (raceStats.GetLogicNbLap() == raceStats.GetRaceNbLap() - 1 && raceStats.GetDistToEndOfRace() < Singleton<GameConfigurator>.Instance.GameSettings.MinDistToEndLine))
			{
				int rank = raceStats.GetRank();
				if (rank > num)
				{
					num = rank;
				}
			}
			else
			{
				list.Add(new Tuple<int, GameObject>(i, player));
			}
		}
		num++;
		Tuple<int, GameObject>[] array = list.ToArray();
		Array.Sort<Tuple<int, GameObject>>(array, new RankComparer(this._aiManager));
		for (int j = 0; j < array.Length; j++)
		{
			int num2 = j + num;
			Tuple<int, GameObject> tuple = array[j];
			Kart kart2 = base.GetKart(tuple.Item1);
			if (kart2)
			{
				base.PlayerFinish(kart2.GetVehicleId(), Singleton<GameConfigurator>.Instance.GameSettings.ChampionShipScores[num2]);
			}
		}
	}

	// Token: 0x06000A7A RID: 2682 RVA: 0x00047488 File Offset: 0x00045688
	public override void ConfigurePlaceVehiclesOnStartLine()
	{
		if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
		{
			int num = 1;
			if (Network.peerType != NetworkPeerType.Disconnected)
			{
				NetworkMgr networkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
				num = networkMgr.InitialNbPlayers;
			}
			int num2 = 6 - num;
			List<int> list = new List<int>();
			for (int i = 0; i < num2; i++)
			{
				list.Add(i);
			}
			int num3 = 5;
			for (int j = 0; j < base.PlayerCount; j++)
			{
				Kart kart = base.GetKart(j);
				if (kart)
				{
					if (kart.GetControlType() != RcVehicle.ControlType.AI)
					{
						base.SetInitialPlayerRank(kart.GetVehicleId(), num3);
						num3--;
					}
					else
					{
						int num4 = list[Singleton<RandomManager>.Instance.Next(list.Count - 1)];
						base.SetInitialPlayerRank(kart.GetVehicleId(), num4);
						list.Remove(num4);
					}
				}
			}
			base.ComputePlayersRank(false, false, true);
		}
	}

	// Token: 0x06000A7B RID: 2683 RVA: 0x00047590 File Offset: 0x00045790
	public override void PlaceVehiclesOnStartLine()
	{
		GameObject gameObject = GameObject.Find("Start");
		if (gameObject != null)
		{
			if (Network.peerType != NetworkPeerType.Disconnected)
			{
				for (int i = 0; i < this.m_pPlayers.Length; i++)
				{
					Kart kart = base.GetKart(i);
					if (kart)
					{
						int vehicleId = kart.GetVehicleId();
						RaceScoreData scoreData = Singleton<GameConfigurator>.Instance.RankingManager.GetScoreData(vehicleId);
						if (scoreData != null)
						{
							this.StartPositions[scoreData.KartIndex] = gameObject.transform.GetChild(gameObject.transform.GetChildCount() - scoreData.RacePosition - 1);
						}
					}
				}
			}
			else
			{
				int num = 0;
				int num2 = 0;
				Kart humanKart = base.GetHumanKart(ref num, ref num2);
				if (humanKart != null)
				{
					if (Singleton<GameConfigurator>.Instance.PlayerConfig.GetAdvantage() == EAdvantage.FirstPlaceOnStart)
					{
						this.StartPositions[num2] = gameObject.transform.GetChild(this.m_pPlayers.Length - 1);
					}
					else
					{
						this.StartPositions[num2] = gameObject.transform.GetChild(gameObject.transform.GetChildCount() - num - 1);
						num = 0;
					}
				}
				for (int j = 0; j < Singleton<GameConfigurator>.Instance.RankingManager.RaceScoreCount(); j++)
				{
					RaceScoreData racePos = Singleton<GameConfigurator>.Instance.RankingManager.GetRacePos(j);
					if (racePos != null && racePos.KartIndex != num2)
					{
						int num3 = 0;
						if (j < num)
						{
							num3++;
						}
						this.StartPositions[racePos.KartIndex] = gameObject.transform.GetChild(gameObject.transform.GetChildCount() - j - num3 - 1);
					}
				}
			}
		}
	}

	// Token: 0x06000A7C RID: 2684 RVA: 0x00047748 File Offset: 0x00045948
	public override void FillResults()
	{
		base.ComputePlayersRank(false, true, false);
		base.Hud.HUDEndSingleRace.FillPositions();
		int num = 0;
		int num2 = 0;
		base.GetHumanKart(ref num, ref num2);
		base.FillResults();
	}
}

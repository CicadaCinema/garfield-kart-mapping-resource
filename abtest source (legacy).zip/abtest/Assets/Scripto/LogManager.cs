﻿using System;
using System.Diagnostics;
using System.IO;
using UnityEngine;

// Token: 0x0200023C RID: 572
public class LogManager
{
	// Token: 0x0600100A RID: 4106 RVA: 0x00065938 File Offset: 0x00063B38
	public LogManager()
	{
		LogManager._logFile = new StreamWriter(Application.persistentDataPath + string.Format("/{0:d-M-yyyy_HH-mm-ss}.txt", DateTime.Now));
		LogManager._logFile.AutoFlush = true;
		UnityEngine.Object.Instantiate(Resources.Load("LumosPrefab"));
	}

	// Token: 0x17000208 RID: 520
	// (get) Token: 0x0600100C RID: 4108 RVA: 0x0000CD61 File Offset: 0x0000AF61
	public static LogManager Instance
	{
		get
		{
			return LogManager._instance;
		}
	}

	// Token: 0x0600100D RID: 4109 RVA: 0x000659B0 File Offset: 0x00063BB0
	[Conditional("LOGMANAGER")]
	public void Log(string Key, string Value, bool Safe = false)
	{
		if (Safe)
		{
			Key = this.SafeParam(Key);
			Value = this.SafeParam(Value);
		}
		else
		{
			this.CheckParam(Key, "Key");
			this.CheckParam(Value, "Value");
		}
		string text = Key + this._keyValueSeparator + Value + this._separator;
		LogManager._logFile.Write(text);
		//Lumos.Event(text);
	}

	// Token: 0x0600100E RID: 4110 RVA: 0x00065A18 File Offset: 0x00063C18
	[Conditional("LOGMANAGER")]
	public void Log(string Key, int Value, bool Safe = false)
	{
		string str;
		if (Safe)
		{
			Key = this.SafeParam(Key);
			str = this.SafeParam(Value.ToString());
		}
		else
		{
			this.CheckParam(Key, "Key");
			this.CheckParam(Value.ToString(), "Value");
			str = Value.ToString();
		}
		string value = Key + this._keyValueSeparator + str + this._separator;
		LogManager._logFile.Write(value);
		//Lumos.Event(Key, Value);
	}

	// Token: 0x0600100F RID: 4111 RVA: 0x00065A94 File Offset: 0x00063C94
	[Conditional("LOGMANAGER")]
	public void Log(string Key, string Value1, int Value2, bool Safe = false)
	{
		string text;
		if (Safe)
		{
			Key = this.SafeParam(Key);
			Value1 = this.SafeParam(Value1);
			text = this.SafeParam(Value2.ToString());
		}
		else
		{
			this.CheckParam(Key, "Key");
			this.CheckParam(Value1, "Value1");
			this.CheckParam(Value2.ToString(), "Value2");
			text = Value2.ToString();
		}
		string value = string.Concat(new string[]
		{
			Key,
			this._keyValueSeparator,
			Value1,
			this._keyValueSeparator,
			text,
			this._separator
		});
		LogManager._logFile.Write(value);
		//Lumos.Event(Key + this._keyValueSeparator + Value1, Value2);
	}

	// Token: 0x06001010 RID: 4112 RVA: 0x00065B50 File Offset: 0x00063D50
	private void CheckParam(string Param, string ParamName)
	{
		if ((this._keyValueSeparator != string.Empty && Param.IndexOf(this._keyValueSeparator) != -1) || (this._separator != string.Empty && Param.IndexOf(this._separator) != -1))
		{
			throw new ArgumentException(string.Concat(new string[]
			{
				"Parameters shouldn't contain the separators (",
				this._keyValueSeparator,
				" or ",
				this._separator,
				"), ",
				Param,
				" does."
			}), ParamName);
		}
	}

	// Token: 0x06001011 RID: 4113 RVA: 0x00065BF4 File Offset: 0x00063DF4
	private string SafeParam(string Param)
	{
		string text = Param;
		if (this._keyValueSeparator != string.Empty)
		{
			text = text.Replace(this._keyValueSeparator, this._safeStr);
		}
		if (this._separator != string.Empty)
		{
			text = text.Replace(this._separator, this._safeStr);
		}
		return text;
	}

	// Token: 0x04000F75 RID: 3957
	public string _keyValueSeparator = " : ";

	// Token: 0x04000F76 RID: 3958
	public string _separator = "\n";

	// Token: 0x04000F77 RID: 3959
	public string _safeStr = "_";

	// Token: 0x04000F78 RID: 3960
	private static StreamWriter _logFile;

	// Token: 0x04000F79 RID: 3961
	private static LogManager _instance;
}

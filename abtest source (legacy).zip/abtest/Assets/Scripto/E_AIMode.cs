﻿using System;

// Token: 0x020001E4 RID: 484
public enum E_AIMode
{
	// Token: 0x04000C9A RID: 3226
	IDLE_MODE,
	// Token: 0x04000C9B RID: 3227
	START_MODE,
	// Token: 0x04000C9C RID: 3228
	RAIL_MODE,
	// Token: 0x04000C9D RID: 3229
	DRIVEN_MODE,
	// Token: 0x04000C9E RID: 3230
	GO_BACK_MODE,
	// Token: 0x04000C9F RID: 3231
	HALF_TURN_MODE
}

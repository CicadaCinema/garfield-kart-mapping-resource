﻿using System;
using System.Collections.Generic;

// Token: 0x02000154 RID: 340
public class RewardAdvantage : RewardBase
{
	// Token: 0x06000982 RID: 2434 RVA: 0x00043270 File Offset: 0x00041470
	protected override void GetReward()
	{
		if (Singleton<GameSaveManager>.Instance.GetAdvantageState(this.Advantages[0]) == E_UnlockableItemSate.Hidden)
		{
			foreach (EAdvantage pAdvantage in this.Advantages)
			{
				Singleton<RewardManager>.Instance.ShowAdvantage(pAdvantage);
			}
		}
	}

	// Token: 0x040009B7 RID: 2487
	public List<EAdvantage> Advantages = new List<EAdvantage>();
}

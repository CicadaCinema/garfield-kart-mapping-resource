﻿using System;
using UnityEngine;

// Token: 0x0200018F RID: 399
public class BtnServer : AbstractMenu
{
	// Token: 0x06000AC5 RID: 2757 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void Awake()
	{
	}

	// Token: 0x06000AC6 RID: 2758 RVA: 0x00049534 File Offset: 0x00047734
	public void Init(int iId, string sServerName, int iNbPlayers, int iGameType, GameObject oMenuParent, GameObject oDragPanel)
	{
		this.m_iId = iId;
		this.m_oMenuParent = oMenuParent;
		this.m_iGameType = iGameType;
		this.m_sServerName = sServerName;
		this.m_iNbPlayers = iNbPlayers;
		this.m_oButton = base.transform.FindChild("Button");
		if (this.m_oButton)
		{
			UIDragPanelContents component = this.m_oButton.gameObject.GetComponent<UIDragPanelContents>();
			if (component)
			{
				component.draggablePanel = oDragPanel.GetComponent<UIDraggablePanel>();
			}
			Transform transform = this.m_oButton.Find("LabelServerName");
			if (transform)
			{
				UILabel component2 = transform.gameObject.GetComponent<UILabel>();
				if (component2)
				{
					component2.text = sServerName;
				}
			}
			this.SetPlayerCount(iNbPlayers);
			transform = this.m_oButton.Find("SpriteTypeGame");
			if (transform)
			{
				UITexturePattern component3 = transform.gameObject.GetComponent<UITexturePattern>();
				if (component3)
				{
					component3.ChangeTexture(iGameType);
				}
			}
		}
		this.OnEnter();
	}

	// Token: 0x06000AC7 RID: 2759 RVA: 0x00009659 File Offset: 0x00007859
	public string GetServerName()
	{
		return this.m_sServerName;
	}

	// Token: 0x06000AC8 RID: 2760 RVA: 0x00009661 File Offset: 0x00007861
	public int GetGameType()
	{
		return this.m_iGameType;
	}

	// Token: 0x06000AC9 RID: 2761 RVA: 0x00009669 File Offset: 0x00007869
	public int GetPlayerCount()
	{
		return this.m_iNbPlayers;
	}

	// Token: 0x06000ACA RID: 2762 RVA: 0x00049638 File Offset: 0x00047838
	public void SetPlayerCount(int nb)
	{
		this.m_iNbPlayers = nb;
		if (this.m_oLabelNbPlayers == null)
		{
			Transform transform = this.m_oButton.Find("LabelNbPlayers");
			if (transform)
			{
				this.m_oLabelNbPlayers = transform.gameObject.GetComponent<UILabel>();
			}
		}
		if (this.m_oLabelNbPlayers)
		{
			this.m_oLabelNbPlayers.text = string.Format("{0}/6 " + Localization.instance.Get("MENU_PLAYERS"), this.m_iNbPlayers);
		}
	}

	// Token: 0x06000ACB RID: 2763 RVA: 0x00009671 File Offset: 0x00007871
	public void OnClick()
	{
		if (this.m_oMenuParent)
		{
			this.m_oMenuParent.SendMessage("OnServer", this.m_iId, SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x04000A99 RID: 2713
	private int m_iId;

	// Token: 0x04000A9A RID: 2714
	private GameObject m_oMenuParent;

	// Token: 0x04000A9B RID: 2715
	private string m_sServerName;

	// Token: 0x04000A9C RID: 2716
	private int m_iGameType;

	// Token: 0x04000A9D RID: 2717
	private int m_iNbPlayers;

	// Token: 0x04000A9E RID: 2718
	private Transform m_oButton;

	// Token: 0x04000A9F RID: 2719
	private UILabel m_oLabelNbPlayers;
}

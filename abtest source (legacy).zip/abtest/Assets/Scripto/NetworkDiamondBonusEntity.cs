﻿using System;
using UnityEngine;

// Token: 0x020000E3 RID: 227
public class NetworkDiamondBonusEntity : NetworkMovableBonusEntity
{
	// Token: 0x06000621 RID: 1569 RVA: 0x0000654B File Offset: 0x0000474B
	[RPC]
	public void OnLoseTarget()
	{
		((DiamondBonusEntity)this.m_pBonusEntity).DoLoseTarget();
	}

	// Token: 0x06000622 RID: 1570 RVA: 0x0000655D File Offset: 0x0000475D
	[RPC]
	public void OnCollideWall()
	{
		((DiamondBonusEntity)this.m_pBonusEntity).DoCollideWall();
	}

	// Token: 0x06000623 RID: 1571 RVA: 0x0000656F File Offset: 0x0000476F
	[RPC]
	public void OnCollideRoad(Vector3 hit)
	{
		((DiamondBonusEntity)this.m_pBonusEntity).DoCollideRoad(hit);
	}

	// Token: 0x06000624 RID: 1572 RVA: 0x00006582 File Offset: 0x00004782
	[RPC]
	public void OnAttachToTarget()
	{
		((DiamondBonusEntity)this.m_pBonusEntity).DoAttachToTarget();
	}

	// Token: 0x06000625 RID: 1573 RVA: 0x00030860 File Offset: 0x0002EA60
	[RPC]
	public void OnAcquireTarget(NetworkViewID id)
	{
		NetworkView networkView = NetworkView.Find(id);
		if (networkView != null)
		{
			((DiamondBonusEntity)this.m_pBonusEntity).DoAcquireTarget(networkView.gameObject);
		}
	}

	// Token: 0x06000626 RID: 1574 RVA: 0x00006594 File Offset: 0x00004794
	[RPC]
	public void Explode()
	{
		((DiamondBonusEntity)this.m_pBonusEntity).Explode();
	}

	// Token: 0x06000627 RID: 1575 RVA: 0x00006594 File Offset: 0x00004794
	[RPC]
	public override void OnNetworkDestroy()
	{
		((DiamondBonusEntity)this.m_pBonusEntity).Explode();
	}

	// Token: 0x06000628 RID: 1576 RVA: 0x000065A6 File Offset: 0x000047A6
	[RPC]
	public void Launch(NetworkViewID launcherViewID, bool pBehind)
	{
		this.NetworkInitialize(launcherViewID);
		((DiamondBonusEntity)this.m_pBonusEntity).Launch(pBehind);
	}
}

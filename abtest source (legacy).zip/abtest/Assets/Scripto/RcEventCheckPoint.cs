﻿using System;

// Token: 0x0200021D RID: 541
public struct RcEventCheckPoint
{
	// Token: 0x04000E84 RID: 3716
	public RcVehicle m_pVehicle;

	// Token: 0x04000E85 RID: 3717
	public int m_iCheckpointIdx;

	// Token: 0x04000E86 RID: 3718
	public int m_iCheckpointTime;
}

﻿using System;

// Token: 0x02000157 RID: 343
public class RewardChampionShip : RewardUnlockableItem
{
	// Token: 0x06000987 RID: 2439 RVA: 0x00043380 File Offset: 0x00041580
	protected override void GetReward()
	{
		E_UnlockableItemSate championShipState = Singleton<GameSaveManager>.Instance.GetChampionShipState(this.ChampionShip, this.Difficulty);
		if (championShipState == E_UnlockableItemSate.Hidden && this.State == E_UnlockableItemSate.NewLocked)
		{
			Singleton<RewardManager>.Instance.ShowChampionShip(this.ChampionShip, this.Difficulty);
		}
		else if (this.State == E_UnlockableItemSate.NewUnlocked && (championShipState == E_UnlockableItemSate.NewLocked || championShipState == E_UnlockableItemSate.Locked || Singleton<RewardManager>.Instance.ContainsShownChampionShip(this.ChampionShip, this.Difficulty)))
		{
			Singleton<RewardManager>.Instance.UnlockChampionShip(this.ChampionShip, this.Difficulty);
		}
	}

	// Token: 0x040009BD RID: 2493
	public EDifficulty Difficulty;

	// Token: 0x040009BE RID: 2494
	public string ChampionShip;
}

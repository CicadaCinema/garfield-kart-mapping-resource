﻿using System;
using UnityEngine;

// Token: 0x02000114 RID: 276
public class HUDOptions : MonoBehaviour
{
	// Token: 0x06000793 RID: 1939 RVA: 0x00037F58 File Offset: 0x00036158
	public void Start()
	{
		this.m_fGyroSensibility = Singleton<GameOptionManager>.Instance.GetGyroSensibility();
		E_InputType inputType = Singleton<GameOptionManager>.Instance.GetInputType();
		if (inputType == E_InputType.Gyroscopic)
		{
			this.BtnGyro.isChecked = true;
			this.BtnTouched.isChecked = false;
		}
		else
		{
			this.BtnTouched.isChecked = true;
			this.BtnGyro.isChecked = false;
		}
		if (this.GyroSlider)
		{
			this.GyroSlider.sliderValue = this.m_fGyroSensibility;
		}
	}

	// Token: 0x06000794 RID: 1940 RVA: 0x00007661 File Offset: 0x00005861
	public void OnSelectGyro()
	{
		this.SelectInput(E_InputType.Gyroscopic);
	}

	// Token: 0x06000795 RID: 1941 RVA: 0x0000766A File Offset: 0x0000586A
	public void OnSelectArrow()
	{
		this.SelectInput(E_InputType.Touched);
	}

	// Token: 0x06000796 RID: 1942 RVA: 0x00007673 File Offset: 0x00005873
	public void SelectInput(E_InputType eInput)
	{
		Singleton<GameOptionManager>.Instance.SetInputType(eInput, true);
		if (eInput == E_InputType.Gyroscopic)
		{
			this.BtnGyro.isChecked = true;
		}
		else
		{
			this.BtnTouched.isChecked = true;
		}
	}

	// Token: 0x06000797 RID: 1943 RVA: 0x000076A5 File Offset: 0x000058A5
	public void OnChangeSensibility(float fValue)
	{
		this.m_fGyroSensibility = fValue;
		Singleton<GameOptionManager>.Instance.SetGyroSensibility(this.m_fGyroSensibility, false);
	}

	// Token: 0x06000798 RID: 1944 RVA: 0x000076BF File Offset: 0x000058BF
	public void SaveSensibility()
	{
		Singleton<GameOptionManager>.Instance.SetGyroSensibility(this.m_fGyroSensibility, true);
	}

	// Token: 0x04000772 RID: 1906
	public UICheckbox BtnGyro;

	// Token: 0x04000773 RID: 1907
	public UICheckbox BtnTouched;

	// Token: 0x04000774 RID: 1908
	public UISlider GyroSlider;

	// Token: 0x04000775 RID: 1909
	private float m_fGyroSensibility;
}

﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000196 RID: 406
public class CreditsScrollingPanel : MonoBehaviour
{
	// Token: 0x06000AF0 RID: 2800 RVA: 0x00049C50 File Offset: 0x00047E50
	public void Awake()
	{
		if (!this.CreditsMenu)
		{
			this.CreditsMenu = GameObject.Find("MENU_CREDITS").GetComponent<AbstractMenu>();
		}
		this.CreditsItemDataBase = new Dictionary<string, CreditsItemDesc>
		{
			{
				"[TI1]",
				new CreditsItemDesc
				{
					FontName = "Chinacat",
					FontSize = 64f,
					Offset = 145f,
					FontColor = this._colorTI1
				}
			},
			{
				"[TI2]",
				new CreditsItemDesc
				{
					FontName = "Chinacat",
					FontSize = 64f,
					Offset = 100f,
					FontColor = this._colorTI2
				}
			},
			{
				"[ITM]",
				new CreditsItemDesc
				{
					FontName = "Chinacat",
					FontSize = 56f,
					Offset = 55f,
					FontColor = this._colorITM
				}
			}
		};
		this._endOffset = this.CreditsPanel.transform.localScale.y / 2f + 50f;
		this._startingOffset = -this._endOffset;
		for (int i = 0; i < this.ItemCount; i++)
		{
			GameObject gameObject = new GameObject();
			gameObject.AddComponent<UILabel>();
			gameObject.GetComponent<UILabel>().text = "Bob";
			gameObject.transform.parent = base.transform.GetChild(0);
			gameObject.transform.localPosition = new Vector3(465.5f, this._startingOffset - (float)i * 45f, -72f);
			gameObject.transform.localScale = new Vector3(64f, 64f, 1f);
			gameObject.AddComponent<CreditsScrollingLabel>();
			gameObject.GetComponent<CreditsScrollingLabel>().Speed = this.ScrollingSpeed;
			gameObject.GetComponent<CreditsScrollingLabel>().EndOffset = this._endOffset;
			gameObject.GetComponent<CreditsScrollingLabel>().OnLabelEnd += this.ScrollingLabelEndHandler;
			this.ScrollingLabels.Add(gameObject.GetComponent<CreditsScrollingLabel>());
		}
		GameObject gameObject2 = GameObject.Find("PanelAnimation");
		if (gameObject2 != null)
		{
			this.m_pAnimSprite = gameObject2.GetComponentInChildren<UISprite>();
		}
		if (this.m_pAnimSprite != null)
		{
			this.m_pAnimSprite.atlas.spriteMaterial.mainTexture = (Resources.Load("ANIM", typeof(Texture2D)) as Texture2D);
		}
	}

	// Token: 0x06000AF1 RID: 2801 RVA: 0x00009805 File Offset: 0x00007A05
	public void OnEnable()
	{
		this.Reset();
		this.Load();
	}

	// Token: 0x06000AF2 RID: 2802 RVA: 0x00049EE4 File Offset: 0x000480E4
	private void Load()
	{
		if (this.CreditsFile)
		{
			this.Reader = new ByteReader(this.CreditsFile);
			for (int i = 0; i < this.ScrollingLabels.Count; i++)
			{
				this.UpdateLabel(this.ScrollingLabels[i]);
			}
		}
	}

	// Token: 0x06000AF3 RID: 2803 RVA: 0x00049F40 File Offset: 0x00048140
	private void UpdateLabelsSpeed()
	{
		if (this.ScrollingLabels == null)
		{
			return;
		}
		for (int i = 0; i < this.ScrollingLabels.Count; i++)
		{
			this.ScrollingLabels[i].Speed = this.ScrollingSpeed;
		}
	}

	// Token: 0x06000AF4 RID: 2804 RVA: 0x00009813 File Offset: 0x00007A13
	private void ScrollingLabelEndHandler(CreditsScrollingLabel Label)
	{
		this.m_iEndedLabels++;
		if (this.m_iEndedLabels == this.ScrollingLabels.Count)
		{
			this.Reset();
			this.CreditsMenu.ActSwapMenu(this.BackMenu);
		}
	}

	// Token: 0x06000AF5 RID: 2805 RVA: 0x00049F8C File Offset: 0x0004818C
	private void UpdateLabel(CreditsScrollingLabel Label)
	{
		string text = string.Empty;
		CreditsScrollingLabel x = this.FindPreviousLabel(Label);
		float num = this._startingOffset;
		if (x != null)
		{
			num = this.FindPreviousLabel(Label).gameObject.transform.localPosition.y;
		}
		text = this.Reader.ReadLine();
		while (text == null)
		{
			this.Reader = new ByteReader(this.CreditsFile);
			text = this.Reader.ReadLine();
			num -= 450f;
		}
		string key = text.Substring(0, 5);
		if (this.CreditsItemDataBase.ContainsKey(key))
		{
			num -= this.CreditsItemDataBase[key].Offset;
			Label.transform.localPosition = new Vector3(465.5f, num, -72f);
			Label.SetItem(text.Substring(5), this.CreditsItemDataBase[key], this.CreditsFont);
		}
	}

	// Token: 0x06000AF6 RID: 2806 RVA: 0x0004A084 File Offset: 0x00048284
	private CreditsScrollingLabel FindPreviousLabel(CreditsScrollingLabel Label)
	{
		int num = -1;
		for (int i = 0; i < this.ScrollingLabels.Count; i++)
		{
			if (this.ScrollingLabels[i] == Label)
			{
				num = i;
				break;
			}
		}
		int num2 = num - 1;
		if (num2 < 0)
		{
			num2 = this.ScrollingLabels.Count - 1;
		}
		if (this.ScrollingLabels[num2].Updating)
		{
			return this.ScrollingLabels[num2];
		}
		return null;
	}

	// Token: 0x06000AF7 RID: 2807 RVA: 0x0004A10C File Offset: 0x0004830C
	public void Reset()
	{
		this.m_iEndedLabels = 0;
		for (int i = 0; i < this.ScrollingLabels.Count; i++)
		{
			this.ScrollingLabels[i].Reset();
		}
	}

	// Token: 0x06000AF8 RID: 2808 RVA: 0x00009850 File Offset: 0x00007A50
	public void OnDestroy()
	{
		Resources.UnloadAsset(this.m_pAnimSprite.atlas.spriteMaterial.mainTexture);
	}

	// Token: 0x04000AB7 RID: 2743
	public Color _colorTI1 = Color.white;

	// Token: 0x04000AB8 RID: 2744
	public Color _colorTI2 = Color.white;

	// Token: 0x04000AB9 RID: 2745
	public Color _colorITM = Color.white;

	// Token: 0x04000ABA RID: 2746
	public GameObject CreditsPanel;

	// Token: 0x04000ABB RID: 2747
	public GameObject CreditsFont;

	// Token: 0x04000ABC RID: 2748
	public float ScrollingSpeed = 5f;

	// Token: 0x04000ABD RID: 2749
	public TextAsset CreditsFile;

	// Token: 0x04000ABE RID: 2750
	public int ItemCount = 10;

	// Token: 0x04000ABF RID: 2751
	public AbstractMenu CreditsMenu;

	// Token: 0x04000AC0 RID: 2752
	public EMenus BackMenu = EMenus.MENU_WELCOME;

	// Token: 0x04000AC1 RID: 2753
	private float _startingOffset = -200f;

	// Token: 0x04000AC2 RID: 2754
	private float _endOffset = 200f;

	// Token: 0x04000AC3 RID: 2755
	private ByteReader Reader;

	// Token: 0x04000AC4 RID: 2756
	private List<CreditsScrollingLabel> ScrollingLabels = new List<CreditsScrollingLabel>();

	// Token: 0x04000AC5 RID: 2757
	private Dictionary<string, CreditsItemDesc> CreditsItemDataBase;

	// Token: 0x04000AC6 RID: 2758
	private UISprite m_pAnimSprite;

	// Token: 0x04000AC7 RID: 2759
	private int m_iEndedLabels;
}

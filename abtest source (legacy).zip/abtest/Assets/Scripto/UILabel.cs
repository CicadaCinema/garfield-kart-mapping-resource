﻿using System;
using UnityEngine;

// Token: 0x0200007A RID: 122
[AddComponentMenu("NGUI/UI/Label")]
[ExecuteInEditMode]
public class UILabel : UIWidget
{
	// Token: 0x1700008F RID: 143
	// (get) Token: 0x06000339 RID: 825 RVA: 0x0001E4E0 File Offset: 0x0001C6E0
	// (set) Token: 0x0600033A RID: 826 RVA: 0x0001E578 File Offset: 0x0001C778
	private bool hasChanged
	{
		get
		{
			return this.mShouldBeProcessed || this.mLastText != this.text || this.mLastWidth != this.mMaxLineWidth || this.mLastEncoding != this.mEncoding || this.mLastCount != this.mMaxLineCount || this.mLastPass != this.mPassword || this.mLastShow != this.mShowLastChar || this.mLastEffect != this.mEffectStyle;
		}
		set
		{
			if (value)
			{
				this.mChanged = true;
				this.mShouldBeProcessed = true;
			}
			else
			{
				this.mShouldBeProcessed = false;
				this.mLastText = this.text;
				this.mLastWidth = this.mMaxLineWidth;
				this.mLastEncoding = this.mEncoding;
				this.mLastCount = this.mMaxLineCount;
				this.mLastPass = this.mPassword;
				this.mLastShow = this.mShowLastChar;
				this.mLastEffect = this.mEffectStyle;
			}
		}
	}

	// Token: 0x17000090 RID: 144
	// (get) Token: 0x0600033B RID: 827 RVA: 0x00004762 File Offset: 0x00002962
	// (set) Token: 0x0600033C RID: 828 RVA: 0x0001E5FC File Offset: 0x0001C7FC
	public UIFont font
	{
		get
		{
			return this.mFont;
		}
		set
		{
			if (this.mFont != value)
			{
				this.mFont = value;
				this.material = ((!(this.mFont != null)) ? null : this.mFont.material);
				this.mChanged = true;
				this.hasChanged = true;
				this.MarkAsChanged();
			}
		}
	}

	// Token: 0x17000091 RID: 145
	// (get) Token: 0x0600033D RID: 829 RVA: 0x0000476A File Offset: 0x0000296A
	// (set) Token: 0x0600033E RID: 830 RVA: 0x0001E660 File Offset: 0x0001C860
	public string text
	{
		get
		{
			return this.mText;
		}
		set
		{
			if (string.IsNullOrEmpty(value))
			{
				if (!string.IsNullOrEmpty(this.mText))
				{
					this.mText = string.Empty;
				}
				this.hasChanged = true;
			}
			else if (this.mText != value)
			{
				this.mText = value;
				this.hasChanged = true;
				if (this.shrinkToFit)
				{
					this.MakePixelPerfect();
				}
			}
		}
	}

	// Token: 0x17000092 RID: 146
	// (get) Token: 0x0600033F RID: 831 RVA: 0x00004772 File Offset: 0x00002972
	// (set) Token: 0x06000340 RID: 832 RVA: 0x0000477A File Offset: 0x0000297A
	public bool supportEncoding
	{
		get
		{
			return this.mEncoding;
		}
		set
		{
			if (this.mEncoding != value)
			{
				this.mEncoding = value;
				this.hasChanged = true;
				if (value)
				{
					this.mPassword = false;
				}
			}
		}
	}

	// Token: 0x17000093 RID: 147
	// (get) Token: 0x06000341 RID: 833 RVA: 0x000047A3 File Offset: 0x000029A3
	// (set) Token: 0x06000342 RID: 834 RVA: 0x000047AB File Offset: 0x000029AB
	public UIFont.SymbolStyle symbolStyle
	{
		get
		{
			return this.mSymbols;
		}
		set
		{
			if (this.mSymbols != value)
			{
				this.mSymbols = value;
				this.hasChanged = true;
			}
		}
	}

	// Token: 0x17000094 RID: 148
	// (get) Token: 0x06000343 RID: 835 RVA: 0x000047C7 File Offset: 0x000029C7
	// (set) Token: 0x06000344 RID: 836 RVA: 0x000047CF File Offset: 0x000029CF
	public int lineWidth
	{
		get
		{
			return this.mMaxLineWidth;
		}
		set
		{
			if (this.mMaxLineWidth != value)
			{
				this.mMaxLineWidth = value;
				this.hasChanged = true;
				if (this.shrinkToFit)
				{
					this.MakePixelPerfect();
				}
			}
		}
	}

	// Token: 0x17000095 RID: 149
	// (get) Token: 0x06000345 RID: 837 RVA: 0x000047FC File Offset: 0x000029FC
	// (set) Token: 0x06000346 RID: 838 RVA: 0x0000480A File Offset: 0x00002A0A
	public bool multiLine
	{
		get
		{
			return this.mMaxLineCount != 1;
		}
		set
		{
			if (this.mMaxLineCount != 1 != value)
			{
				this.mMaxLineCount = ((!value) ? 1 : 0);
				this.hasChanged = true;
				if (value)
				{
					this.mPassword = false;
				}
			}
		}
	}

	// Token: 0x17000096 RID: 150
	// (get) Token: 0x06000347 RID: 839 RVA: 0x00004845 File Offset: 0x00002A45
	// (set) Token: 0x06000348 RID: 840 RVA: 0x0000484D File Offset: 0x00002A4D
	public int maxLineCount
	{
		get
		{
			return this.mMaxLineCount;
		}
		set
		{
			if (this.mMaxLineCount != value)
			{
				this.mMaxLineCount = Mathf.Max(value, 0);
				this.hasChanged = true;
				if (value == 1)
				{
					this.mPassword = false;
				}
			}
		}
	}

	// Token: 0x17000097 RID: 151
	// (get) Token: 0x06000349 RID: 841 RVA: 0x0000487D File Offset: 0x00002A7D
	// (set) Token: 0x0600034A RID: 842 RVA: 0x00004885 File Offset: 0x00002A85
	public bool password
	{
		get
		{
			return this.mPassword;
		}
		set
		{
			if (this.mPassword != value)
			{
				if (value)
				{
					this.mMaxLineCount = 1;
					this.mEncoding = false;
				}
				this.mPassword = value;
				this.hasChanged = true;
			}
		}
	}

	// Token: 0x17000098 RID: 152
	// (get) Token: 0x0600034B RID: 843 RVA: 0x000048B5 File Offset: 0x00002AB5
	// (set) Token: 0x0600034C RID: 844 RVA: 0x000048BD File Offset: 0x00002ABD
	public bool showLastPasswordChar
	{
		get
		{
			return this.mShowLastChar;
		}
		set
		{
			if (this.mShowLastChar != value)
			{
				this.mShowLastChar = value;
				this.hasChanged = true;
			}
		}
	}

	// Token: 0x17000099 RID: 153
	// (get) Token: 0x0600034D RID: 845 RVA: 0x000048D9 File Offset: 0x00002AD9
	// (set) Token: 0x0600034E RID: 846 RVA: 0x000048E1 File Offset: 0x00002AE1
	public UILabel.Effect effectStyle
	{
		get
		{
			return this.mEffectStyle;
		}
		set
		{
			if (this.mEffectStyle != value)
			{
				this.mEffectStyle = value;
				this.hasChanged = true;
			}
		}
	}

	// Token: 0x1700009A RID: 154
	// (get) Token: 0x0600034F RID: 847 RVA: 0x000048FD File Offset: 0x00002AFD
	// (set) Token: 0x06000350 RID: 848 RVA: 0x00004905 File Offset: 0x00002B05
	public Color effectColor
	{
		get
		{
			return this.mEffectColor;
		}
		set
		{
			if (!this.mEffectColor.Equals(value))
			{
				this.mEffectColor = value;
				if (this.mEffectStyle != UILabel.Effect.None)
				{
					this.hasChanged = true;
				}
			}
		}
	}

	// Token: 0x1700009B RID: 155
	// (get) Token: 0x06000351 RID: 849 RVA: 0x00004936 File Offset: 0x00002B36
	// (set) Token: 0x06000352 RID: 850 RVA: 0x0000493E File Offset: 0x00002B3E
	public Vector2 effectDistance
	{
		get
		{
			return this.mEffectDistance;
		}
		set
		{
			if (this.mEffectDistance != value)
			{
				this.mEffectDistance = value;
				this.hasChanged = true;
			}
		}
	}

	// Token: 0x1700009C RID: 156
	// (get) Token: 0x06000353 RID: 851 RVA: 0x0000495F File Offset: 0x00002B5F
	// (set) Token: 0x06000354 RID: 852 RVA: 0x00004967 File Offset: 0x00002B67
	public bool shrinkToFit
	{
		get
		{
			return this.mShrinkToFit;
		}
		set
		{
			if (this.mShrinkToFit != value)
			{
				this.mShrinkToFit = value;
				this.hasChanged = true;
			}
		}
	}

	// Token: 0x1700009D RID: 157
	// (get) Token: 0x06000355 RID: 853 RVA: 0x0001E6D0 File Offset: 0x0001C8D0
	public string processedText
	{
		get
		{
			if (this.mLastScale != base.cachedTransform.localScale)
			{
				this.mLastScale = base.cachedTransform.localScale;
				this.mShouldBeProcessed = true;
			}
			if (this.hasChanged)
			{
				this.ProcessText();
			}
			return this.mProcessedText;
		}
	}

	// Token: 0x1700009E RID: 158
	// (get) Token: 0x06000356 RID: 854 RVA: 0x0001E728 File Offset: 0x0001C928
	public override Material material
	{
		get
		{
			Material material = base.material;
			if (material == null)
			{
				material = ((!(this.mFont != null)) ? null : this.mFont.material);
				this.material = material;
			}
			return material;
		}
	}

	// Token: 0x1700009F RID: 159
	// (get) Token: 0x06000357 RID: 855 RVA: 0x00004983 File Offset: 0x00002B83
	public override Vector2 relativeSize
	{
		get
		{
			if (this.mFont == null)
			{
				return Vector3.one;
			}
			if (this.hasChanged)
			{
				this.ProcessText();
			}
			return this.mSize;
		}
	}

	// Token: 0x06000358 RID: 856 RVA: 0x0001E774 File Offset: 0x0001C974
	protected override void OnStart()
	{
		if (this.mLineWidth > 0f)
		{
			this.mMaxLineWidth = Mathf.RoundToInt(this.mLineWidth);
			this.mLineWidth = 0f;
		}
		if (!this.mMultiline)
		{
			this.mMaxLineCount = 1;
			this.mMultiline = true;
		}
		this.mPremultiply = (this.font != null && this.font.material != null && this.font.material.shader.name.Contains("Premultiplied"));
	}

	// Token: 0x06000359 RID: 857 RVA: 0x000049B8 File Offset: 0x00002BB8
	public override void MarkAsChanged()
	{
		this.hasChanged = true;
		base.MarkAsChanged();
	}

	// Token: 0x0600035A RID: 858 RVA: 0x0001E818 File Offset: 0x0001CA18
	private void ProcessText()
	{
		this.mChanged = true;
		this.hasChanged = false;
		this.mLastText = this.mText;
		float num = Mathf.Abs(base.cachedTransform.localScale.x);
		float num2 = (float)(this.mFont.size * this.mMaxLineCount);
		if (num > 0f)
		{
			do
			{
				if (this.mPassword)
				{
					this.mProcessedText = string.Empty;
					if (this.mShowLastChar)
					{
						int i = 0;
						int num3 = this.mText.Length - 1;
						while (i < num3)
						{
							this.mProcessedText += "*";
							i++;
						}
						if (this.mText.Length > 0)
						{
							this.mProcessedText += this.mText[this.mText.Length - 1];
						}
					}
					else
					{
						int j = 0;
						int length = this.mText.Length;
						while (j < length)
						{
							this.mProcessedText += "*";
							j++;
						}
					}
					this.mProcessedText = this.mFont.WrapText(this.mProcessedText, (float)this.mMaxLineWidth / num, this.mMaxLineCount, false, UIFont.SymbolStyle.None);
				}
				else if (this.mMaxLineWidth > 0)
				{
					this.mProcessedText = this.mFont.WrapText(this.mText, (float)this.mMaxLineWidth / num, (!this.mShrinkToFit) ? this.mMaxLineCount : 0, this.mEncoding, this.mSymbols);
				}
				else if (!this.mShrinkToFit && this.mMaxLineCount > 0)
				{
					this.mProcessedText = this.mFont.WrapText(this.mText, 100000f, this.mMaxLineCount, this.mEncoding, this.mSymbols);
				}
				else
				{
					this.mProcessedText = this.mText;
				}
				this.mSize = (string.IsNullOrEmpty(this.mProcessedText) ? Vector2.one : this.mFont.CalculatePrintedSize(this.mProcessedText, this.mEncoding, this.mSymbols));
				if (!this.mShrinkToFit)
				{
					goto IL_2F2;
				}
				if (this.mMaxLineCount <= 0 || this.mSize.y * num <= num2)
				{
					break;
				}
				num = Mathf.Round(num - 1f);
			}
			while (num > 1f);
			if (this.mMaxLineWidth > 0)
			{
				float num4 = (float)this.mMaxLineWidth / num;
				float a = (this.mSize.x * num <= num4) ? num : (num4 / this.mSize.x * num);
				num = Mathf.Min(a, num);
			}
			num = Mathf.Round(num);
			base.cachedTransform.localScale = new Vector3(num, num, 1f);
			IL_2F2:
			this.mSize.x = Mathf.Max(this.mSize.x, (num <= 0f) ? 1f : ((float)this.lineWidth / num));
		}
		else
		{
			this.mSize.x = 1f;
			num = (float)this.mFont.size;
			base.cachedTransform.localScale = new Vector3(0.01f, 0.01f, 1f);
			this.mProcessedText = string.Empty;
		}
		this.mSize.y = Mathf.Max(this.mSize.y, 1f);
	}

	// Token: 0x0600035B RID: 859 RVA: 0x0001EBC8 File Offset: 0x0001CDC8
	public override void MakePixelPerfect()
	{
		if (this.mFont != null)
		{
			float pixelSize = this.font.pixelSize;
			Vector3 localScale = base.cachedTransform.localScale;
			localScale.x = (float)this.mFont.size * pixelSize;
			localScale.y = localScale.x;
			localScale.z = 1f;
			Vector3 localPosition = base.cachedTransform.localPosition;
			localPosition.x = (float)(Mathf.CeilToInt(localPosition.x / pixelSize * 4f) >> 2);
			localPosition.y = (float)(Mathf.CeilToInt(localPosition.y / pixelSize * 4f) >> 2);
			localPosition.z = (float)Mathf.RoundToInt(localPosition.z);
			localPosition.x *= pixelSize;
			localPosition.y *= pixelSize;
			base.cachedTransform.localPosition = localPosition;
			base.cachedTransform.localScale = localScale;
			if (this.shrinkToFit)
			{
				this.ProcessText();
			}
		}
		else
		{
			base.MakePixelPerfect();
		}
	}

	// Token: 0x0600035C RID: 860 RVA: 0x0001ECDC File Offset: 0x0001CEDC
	private void ApplyShadow(BetterList<Vector3> verts, BetterList<Vector2> uvs, BetterList<Color32> cols, int start, int end, float x, float y)
	{
		Color color = this.mEffectColor;
		color.a *= base.alpha * this.mPanel.alpha;
		Color32 color2 = (!this.font.premultipliedAlpha) ? color : NGUITools.ApplyPMA(color);
		for (int i = start; i < end; i++)
		{
			verts.Add(verts.buffer[i]);
			uvs.Add(uvs.buffer[i]);
			cols.Add(cols.buffer[i]);
			Vector3 vector = verts.buffer[i];
			vector.x += x;
			vector.y += y;
			verts.buffer[i] = vector;
			cols.buffer[i] = color2;
		}
	}

	// Token: 0x0600035D RID: 861 RVA: 0x0001EDE4 File Offset: 0x0001CFE4
	public override void OnFill(BetterList<Vector3> verts, BetterList<Vector2> uvs, BetterList<Color32> cols)
	{
		if (this.mFont == null)
		{
			return;
		}
		UIWidget.Pivot pivot = base.pivot;
		int start = verts.size;
		Color c = base.color;
		c.a *= this.mPanel.alpha;
		if (this.font.premultipliedAlpha)
		{
			c = NGUITools.ApplyPMA(c);
		}
		if (pivot == UIWidget.Pivot.Left || pivot == UIWidget.Pivot.TopLeft || pivot == UIWidget.Pivot.BottomLeft)
		{
			this.mFont.Print(this.processedText, c, verts, uvs, cols, this.mEncoding, this.mSymbols, UIFont.Alignment.Left, 0, this.mPremultiply);
		}
		else if (pivot == UIWidget.Pivot.Right || pivot == UIWidget.Pivot.TopRight || pivot == UIWidget.Pivot.BottomRight)
		{
			this.mFont.Print(this.processedText, c, verts, uvs, cols, this.mEncoding, this.mSymbols, UIFont.Alignment.Right, Mathf.RoundToInt(this.relativeSize.x * (float)this.mFont.size), this.mPremultiply);
		}
		else
		{
			this.mFont.Print(this.processedText, c, verts, uvs, cols, this.mEncoding, this.mSymbols, UIFont.Alignment.Center, Mathf.RoundToInt(this.relativeSize.x * (float)this.mFont.size), this.mPremultiply);
		}
		if (this.effectStyle != UILabel.Effect.None)
		{
			int size = verts.size;
			float num = 1f / (float)this.mFont.size;
			float num2 = num * this.mEffectDistance.x;
			float num3 = num * this.mEffectDistance.y;
			this.ApplyShadow(verts, uvs, cols, start, size, num2, -num3);
			if (this.effectStyle == UILabel.Effect.Outline)
			{
				start = size;
				size = verts.size;
				this.ApplyShadow(verts, uvs, cols, start, size, -num2, num3);
				start = size;
				size = verts.size;
				this.ApplyShadow(verts, uvs, cols, start, size, num2, num3);
				start = size;
				size = verts.size;
				this.ApplyShadow(verts, uvs, cols, start, size, -num2, -num3);
			}
		}
	}

	// Token: 0x040002C9 RID: 713
	[SerializeField]
	[HideInInspector]
	private UIFont mFont;

	// Token: 0x040002CA RID: 714
	[SerializeField]
	[HideInInspector]
	private string mText = string.Empty;

	// Token: 0x040002CB RID: 715
	[HideInInspector]
	[SerializeField]
	private int mMaxLineWidth;

	// Token: 0x040002CC RID: 716
	[HideInInspector]
	[SerializeField]
	private bool mEncoding = true;

	// Token: 0x040002CD RID: 717
	[HideInInspector]
	[SerializeField]
	private int mMaxLineCount;

	// Token: 0x040002CE RID: 718
	[SerializeField]
	[HideInInspector]
	private bool mPassword;

	// Token: 0x040002CF RID: 719
	[SerializeField]
	[HideInInspector]
	private bool mShowLastChar;

	// Token: 0x040002D0 RID: 720
	[HideInInspector]
	[SerializeField]
	private UILabel.Effect mEffectStyle;

	// Token: 0x040002D1 RID: 721
	[HideInInspector]
	[SerializeField]
	private Color mEffectColor = Color.black;

	// Token: 0x040002D2 RID: 722
	[SerializeField]
	[HideInInspector]
	private UIFont.SymbolStyle mSymbols = UIFont.SymbolStyle.Uncolored;

	// Token: 0x040002D3 RID: 723
	[SerializeField]
	[HideInInspector]
	private Vector2 mEffectDistance = Vector2.one;

	// Token: 0x040002D4 RID: 724
	[SerializeField]
	[HideInInspector]
	private bool mShrinkToFit;

	// Token: 0x040002D5 RID: 725
	[SerializeField]
	[HideInInspector]
	private float mLineWidth;

	// Token: 0x040002D6 RID: 726
	[HideInInspector]
	[SerializeField]
	private bool mMultiline = true;

	// Token: 0x040002D7 RID: 727
	private bool mShouldBeProcessed = true;

	// Token: 0x040002D8 RID: 728
	private string mProcessedText;

	// Token: 0x040002D9 RID: 729
	private Vector3 mLastScale = Vector3.one;

	// Token: 0x040002DA RID: 730
	private string mLastText = string.Empty;

	// Token: 0x040002DB RID: 731
	private int mLastWidth;

	// Token: 0x040002DC RID: 732
	private bool mLastEncoding = true;

	// Token: 0x040002DD RID: 733
	private int mLastCount;

	// Token: 0x040002DE RID: 734
	private bool mLastPass;

	// Token: 0x040002DF RID: 735
	private bool mLastShow;

	// Token: 0x040002E0 RID: 736
	private UILabel.Effect mLastEffect;

	// Token: 0x040002E1 RID: 737
	private Vector2 mSize = Vector2.zero;

	// Token: 0x040002E2 RID: 738
	private bool mPremultiply;

	// Token: 0x0200007B RID: 123
	public enum Effect
	{
		// Token: 0x040002E4 RID: 740
		None,
		// Token: 0x040002E5 RID: 741
		Shadow,
		// Token: 0x040002E6 RID: 742
		Outline
	}
}

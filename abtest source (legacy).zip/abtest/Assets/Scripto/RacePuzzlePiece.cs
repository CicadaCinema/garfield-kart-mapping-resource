﻿using System;
using UnityEngine;

// Token: 0x02000153 RID: 339
public class RacePuzzlePiece : RaceItem
{
	// Token: 0x0600097F RID: 2431 RVA: 0x000430A8 File Offset: 0x000412A8
	public override void Awake()
	{
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL || Network.peerType != NetworkPeerType.Disconnected)
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}
		else
		{
			base.Awake();
			string startScene = Singleton<GameConfigurator>.Instance.StartScene;
			string pPiece = startScene + "_" + this.Index.ToString();
			this.m_bAlreadyTaken = Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(pPiece);
			if (this.m_bAlreadyTaken)
			{
				Material[] materials = base.renderer.materials;
				Material[] array = new Material[1];
				if (materials.Length == 2)
				{
					materials[0] = this.TransparentMaterial;
					materials[1] = this.TransparentMaterial;
					Array.Copy(materials, array, 1);
				}
				base.renderer.materials = array;
			}
		}
	}

	// Token: 0x06000980 RID: 2432 RVA: 0x00043168 File Offset: 0x00041368
	protected override void DoTrigger(RcVehicle pVehicle)
	{
		if (this.m_bAlreadyTaken)
		{
			return;
		}
		base.DoTrigger(pVehicle);
		if (pVehicle && pVehicle.GetControlType() == RcVehicle.ControlType.Human)
		{
			Kart kart = (Kart)pVehicle;
			kart.TakePuzzlePiece(this.Index);
		}
		bool flag = true;
		for (int i = 0; i < 2; i++)
		{
			if (i != this.Index)
			{
				string pPiece = Singleton<GameConfigurator>.Instance.StartScene + "_" + i.ToString();
				if (!Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(pPiece))
				{
					flag = false;
					break;
				}
			}
		}
		if (flag)
		{
			Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.FullPuzzle);
		}
		else
		{
			Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.TakePuzzle);
		}
		string pPiece2 = Singleton<GameConfigurator>.Instance.StartScene + "_" + this.Index.ToString();
		Singleton<RewardManager>.Instance.UnlockPuzzlePiece(this.Index);
		Singleton<GameSaveManager>.Instance.UnlockPuzzlePiece(pPiece2, false);
	}

	// Token: 0x040009B4 RID: 2484
	public int Index;

	// Token: 0x040009B5 RID: 2485
	public bool m_bAlreadyTaken;

	// Token: 0x040009B6 RID: 2486
	public Material TransparentMaterial;
}

﻿using System;
using UnityEngine;

// Token: 0x020001E8 RID: 488
public abstract class CamState : MonoBehaviour
{
	// Token: 0x170001C6 RID: 454
	// (get) Token: 0x06000D3F RID: 3391
	public abstract ECamState state { get; }

	// Token: 0x170001C7 RID: 455
	// (get) Token: 0x06000D40 RID: 3392 RVA: 0x0000B0C2 File Offset: 0x000092C2
	// (set) Token: 0x06000D41 RID: 3393 RVA: 0x0000B0CA File Offset: 0x000092CA
	public Transform m_Transform { get; protected set; }

	// Token: 0x170001C8 RID: 456
	// (get) Token: 0x06000D42 RID: 3394 RVA: 0x0000B0D3 File Offset: 0x000092D3
	// (set) Token: 0x06000D43 RID: 3395 RVA: 0x0000B0DB File Offset: 0x000092DB
	public Transform m_Target { get; set; }

	// Token: 0x06000D44 RID: 3396 RVA: 0x00056FC0 File Offset: 0x000551C0
	public virtual void Enter(Transform _Transform, Transform _Target)
	{
		if (this.m_Dummy != null)
		{
			UnityEngine.Object.Destroy(this.m_Dummy);
		}
		this.m_Dummy = new GameObject("DummyCam_" + this.state.ToString());
		this.m_Transform = this.m_Dummy.transform;
		if (_Transform != null)
		{
			this.m_Transform.position = _Transform.position;
			this.m_Transform.rotation = _Transform.rotation;
		}
		if (_Target != null)
		{
			this.m_Target = _Target;
		}
	}

	// Token: 0x06000D45 RID: 3397 RVA: 0x0000B0E4 File Offset: 0x000092E4
	public virtual ECamState Manage(float dt)
	{
		return this.state;
	}

	// Token: 0x06000D46 RID: 3398 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void Exit()
	{
	}

	// Token: 0x04000CF7 RID: 3319
	protected GameObject m_Dummy;

	// Token: 0x04000CF8 RID: 3320
	[HideInInspector]
	public bool m_bDamping = true;
}

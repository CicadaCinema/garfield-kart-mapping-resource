﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200023B RID: 571
[RequireComponent(typeof(GUITexture))]
public class Joystick : MonoBehaviour
{
	// Token: 0x17000205 RID: 517
	// (get) Token: 0x06001000 RID: 4096 RVA: 0x0000CD1C File Offset: 0x0000AF1C
	public bool isFingerDown
	{
		get
		{
			return this.lastFingerId != -1;
		}
	}

	// Token: 0x17000206 RID: 518
	// (set) Token: 0x06001001 RID: 4097 RVA: 0x0000CD2A File Offset: 0x0000AF2A
	public int latchedFinger
	{
		set
		{
			if (this.lastFingerId == value)
			{
				this.Restart();
			}
		}
	}

	// Token: 0x17000207 RID: 519
	// (get) Token: 0x06001002 RID: 4098 RVA: 0x0000CD3E File Offset: 0x0000AF3E
	// (set) Token: 0x06001003 RID: 4099 RVA: 0x0000CD46 File Offset: 0x0000AF46
	public Vector2 position { get; private set; }

	// Token: 0x06001004 RID: 4100 RVA: 0x00065004 File Offset: 0x00063204
	public void Reset()
	{
		try
		{
			base.gameObject.tag = Joystick.joysticksTag;
		}
		catch (Exception)
		{
			Debug.LogError("The \"" + Joystick.joysticksTag + "\" tag has not yet been defined in the Tag Manager.");
			throw;
		}
	}

	// Token: 0x06001005 RID: 4101 RVA: 0x00065058 File Offset: 0x00063258
	public void Awake()
	{
		this.gui = base.GetComponent<GUITexture>();
		if (this.gui.texture == null)
		{
			Debug.LogError("Joystick object requires a valid texture!");
			base.gameObject.SetActive(false);
			return;
		}
		if (Application.platform != RuntimePlatform.Android && Application.platform == RuntimePlatform.IPhonePlayer)
		{
			base.gameObject.SetActive(false);
			return;
		}
		if (!Joystick.enumeratedJoysticks)
		{
			try
			{
				GameObject[] array = GameObject.FindGameObjectsWithTag(Joystick.joysticksTag);
				Joystick.joysticks = new List<Joystick>(array.Length);
				foreach (GameObject gameObject in array)
				{
					Joystick component = gameObject.GetComponent<Joystick>();
					if (component == null)
					{
						throw new NullReferenceException("Joystick gameObject found without a suitable Joystick component.");
					}
					Joystick.joysticks.Add(component);
				}
				Joystick.enumeratedJoysticks = true;
			}
			catch (Exception ex)
			{
				Debug.LogError("Error collecting Joystick objects: " + ex.Message);
				throw;
			}
		}
		this.defaultRect = this.gui.pixelInset;
		this.defaultRect.x = this.defaultRect.x + base.transform.position.x * (float)Screen.width;
		this.defaultRect.y = this.defaultRect.y + base.transform.position.y * (float)Screen.height;
		base.transform.position = new Vector3(0f, 0f, base.transform.position.z);
		if (this.touchPad)
		{
			this.touchZone = this.defaultRect;
		}
		else
		{
			this.guiTouchOffset.x = this.defaultRect.width * 0.5f;
			this.guiTouchOffset.y = this.defaultRect.height * 0.5f;
			this.guiCenter.x = this.defaultRect.x + this.guiTouchOffset.x;
			this.guiCenter.y = this.defaultRect.y + this.guiTouchOffset.y;
			this.guiBoundary.min.x = this.defaultRect.x - this.guiTouchOffset.x;
			this.guiBoundary.max.x = this.defaultRect.x + this.guiTouchOffset.x;
			this.guiBoundary.min.y = this.defaultRect.y - this.guiTouchOffset.y;
			this.guiBoundary.max.y = this.defaultRect.y + this.guiTouchOffset.y;
		}
	}

	// Token: 0x06001006 RID: 4102 RVA: 0x0000CD4F File Offset: 0x0000AF4F
	public void Enable()
	{
		base.enabled = true;
	}

	// Token: 0x06001007 RID: 4103 RVA: 0x0000CD58 File Offset: 0x0000AF58
	public void Disable()
	{
		base.enabled = false;
	}

	// Token: 0x06001008 RID: 4104 RVA: 0x00065334 File Offset: 0x00063534
	public void Restart()
	{
		this.gui.pixelInset = this.defaultRect;
		this.lastFingerId = -1;
		this.position = Vector2.zero;
		this.fingerDownPos = Vector2.zero;
		if (this.touchPad && this.fadeGUI)
		{
			this.gui.color = new Color(this.gui.color.r, this.gui.color.g, this.gui.color.b, 0.025f);
		}
	}

	// Token: 0x06001009 RID: 4105 RVA: 0x000653D4 File Offset: 0x000635D4
	private void Update()
	{
		int touchCount = Input.touchCount;
		if (this.tapTimeWindow > 0f)
		{
			this.tapTimeWindow -= Time.deltaTime;
		}
		else
		{
			this.tapCount = 0;
		}
		if (touchCount == 0)
		{
			this.Restart();
		}
		else
		{
			for (int i = 0; i < touchCount; i++)
			{
				Touch touch = Input.GetTouch(i);
				Vector2 vector = touch.position - this.guiTouchOffset;
				bool flag = false;
				if (this.touchPad && this.touchZone.Contains(touch.position))
				{
					flag = true;
				}
				else if (this.gui.HitTest(touch.position))
				{
					flag = true;
				}
				if (flag && (this.lastFingerId == -1 || this.lastFingerId != touch.fingerId))
				{
					if (this.touchPad)
					{
						if (this.fadeGUI)
						{
							this.gui.color = new Color(this.gui.color.r, this.gui.color.g, this.gui.color.b, 0.15f);
						}
						this.lastFingerId = touch.fingerId;
						this.fingerDownPos = touch.position;
					}
					this.lastFingerId = touch.fingerId;
					if (this.tapTimeWindow > 0f)
					{
						this.tapCount++;
					}
					else
					{
						this.tapCount = 1;
						this.tapTimeWindow = Joystick.tapTimeDelta;
					}
					foreach (Joystick joystick in Joystick.joysticks)
					{
						if (!(joystick == this))
						{
							joystick.latchedFinger = touch.fingerId;
						}
					}
				}
				if (this.lastFingerId == touch.fingerId)
				{
					if (touch.tapCount > this.tapCount)
					{
						this.tapCount = touch.tapCount;
					}
					if (this.touchPad)
					{
						this.position = new Vector2(Mathf.Clamp((touch.position.x - this.fingerDownPos.x) / (this.touchZone.width / 2f), -1f, 1f), Mathf.Clamp((touch.position.y - this.fingerDownPos.y) / (this.touchZone.height / 2f), -1f, 1f));
					}
					else
					{
						this.gui.pixelInset = new Rect(Mathf.Clamp(vector.x, this.guiBoundary.min.x, this.guiBoundary.max.x), Mathf.Clamp(vector.y, this.guiBoundary.min.y, this.guiBoundary.max.y), this.gui.pixelInset.width, this.gui.pixelInset.height);
					}
					if (touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled)
					{
						this.Restart();
					}
				}
			}
		}
		if (!this.touchPad)
		{
			this.position = new Vector2((this.gui.pixelInset.x + this.guiTouchOffset.x - this.guiCenter.x) / this.guiTouchOffset.x, (this.gui.pixelInset.y + this.guiTouchOffset.y - this.guiCenter.y) / this.guiTouchOffset.y);
		}
		float num = Mathf.Abs(this.position.x);
		float num2 = Mathf.Abs(this.position.y);
		if (num < this.deadZone.x)
		{
			this.position = new Vector2(0f, this.position.y);
		}
		else if (this.normalize)
		{
			this.position = new Vector2(Mathf.Sign(this.position.x) * (num - this.deadZone.x) / (1f - this.deadZone.x), this.position.y);
		}
		if (num2 < this.deadZone.y)
		{
			this.position = new Vector2(this.position.x, 0f);
		}
		else if (this.normalize)
		{
			this.position = new Vector2(this.position.x, Mathf.Sign(this.position.y) * (num2 - this.deadZone.y) / (1f - this.deadZone.y));
		}
	}

	// Token: 0x04000F61 RID: 3937
	public bool touchPad;

	// Token: 0x04000F62 RID: 3938
	public bool fadeGUI;

	// Token: 0x04000F63 RID: 3939
	public Vector2 deadZone = Vector2.zero;

	// Token: 0x04000F64 RID: 3940
	public bool normalize;

	// Token: 0x04000F65 RID: 3941
	public int tapCount = -1;

	// Token: 0x04000F66 RID: 3942
	private Rect touchZone;

	// Token: 0x04000F67 RID: 3943
	private int lastFingerId = -1;

	// Token: 0x04000F68 RID: 3944
	private float tapTimeWindow;

	// Token: 0x04000F69 RID: 3945
	private Vector2 fingerDownPos;

	// Token: 0x04000F6A RID: 3946
	private float firstDeltaTime;

	// Token: 0x04000F6B RID: 3947
	private GUITexture gui;

	// Token: 0x04000F6C RID: 3948
	private Rect defaultRect;

	// Token: 0x04000F6D RID: 3949
	private Boundary guiBoundary = new Boundary();

	// Token: 0x04000F6E RID: 3950
	private Vector2 guiTouchOffset;

	// Token: 0x04000F6F RID: 3951
	private Vector2 guiCenter;

	// Token: 0x04000F70 RID: 3952
	private static string joysticksTag = "joystick";

	// Token: 0x04000F71 RID: 3953
	private static List<Joystick> joysticks;

	// Token: 0x04000F72 RID: 3954
	private static bool enumeratedJoysticks;

	// Token: 0x04000F73 RID: 3955
	private static float tapTimeDelta = 0.3f;
}

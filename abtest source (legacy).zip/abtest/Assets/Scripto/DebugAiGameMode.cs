﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000167 RID: 359
public class DebugAiGameMode : InGameGameMode
{
	// Token: 0x060009A5 RID: 2469 RVA: 0x00008A4A File Offset: 0x00006C4A
	public override void CreatePlayers()
	{
		DebugMgr.Instance.LoadDefaultPlayer(0, this);
	}

	// Token: 0x060009A6 RID: 2470 RVA: 0x00043CD8 File Offset: 0x00041ED8
	private int GetRandomStartPos(List<int> pAvailableStartPos)
	{
		int num = pAvailableStartPos[UnityEngine.Random.Range(0, pAvailableStartPos.Count)];
		pAvailableStartPos.Remove(num);
		return num;
	}
}

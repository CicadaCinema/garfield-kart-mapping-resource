﻿using System;
using UnityEngine;

// Token: 0x020001A1 RID: 417
public class MenuOptionSound : AbstractMenu
{
	// Token: 0x06000B4C RID: 2892 RVA: 0x0004C4B8 File Offset: 0x0004A6B8
	public override void OnEnter()
	{
		base.OnEnter();
		this.m_fVolumeSfx = Singleton<GameOptionManager>.Instance.GetSfxVolume();
		if (this.m_pSfxSlider)
		{
			this.m_pSfxSlider.sliderValue = this.m_fVolumeSfx;
		}
		this.m_bIsMute = (this.m_fVolumeSfx == 0f);
		this.m_pMuteIcon.enabled = this.m_bIsMute;
	}

	// Token: 0x06000B4D RID: 2893 RVA: 0x0004C520 File Offset: 0x0004A720
	public override void OnExit()
	{
		base.OnExit();
		Singleton<GameOptionManager>.Instance.SetSfxVolume((!this.m_bIsMute) ? this.m_fVolumeSfx : 0f, true);
		Singleton<GameOptionManager>.Instance.SetMusicVolume((!this.m_bIsMute) ? this.m_fVolumeSfx : 0f, true);
	}

	// Token: 0x06000B4E RID: 2894 RVA: 0x0004C580 File Offset: 0x0004A780
	public void OnMute()
	{
		this.m_bIsMute = !this.m_bIsMute;
		Singleton<GameOptionManager>.Instance.SetSfxVolume((!this.m_bIsMute) ? this.m_fVolumeSfx : 0f, false);
		Singleton<GameOptionManager>.Instance.SetMusicVolume((!this.m_bIsMute) ? this.m_fVolumeSfx : 0f, false);
		this.m_pSfxSlider.sliderValue = ((!this.m_bIsMute) ? this.m_fVolumeSfx : 0f);
		this.m_pMuteIcon.enabled = this.m_bIsMute;
	}

	// Token: 0x06000B4F RID: 2895 RVA: 0x0004C620 File Offset: 0x0004A820
	public void OnChangeVolumeSfx(float fValue)
	{
		if (fValue > 0f)
		{
			this.m_fVolumeSfx = fValue;
		}
		Singleton<GameOptionManager>.Instance.SetSfxVolume(fValue, false);
		Singleton<GameOptionManager>.Instance.SetMusicVolume(fValue, false);
		this.m_bIsMute = (fValue == 0f);
		this.m_pMuteIcon.enabled = this.m_bIsMute;
	}

	// Token: 0x06000B50 RID: 2896 RVA: 0x00003B80 File Offset: 0x00001D80
	public void OnPressSfx(bool isPressed)
	{
	}

	// Token: 0x06000B51 RID: 2897 RVA: 0x000079F8 File Offset: 0x00005BF8
	public override void Update()
	{
		if (Application.platform == RuntimePlatform.Android && Input.GetKeyDown(KeyCode.Escape))
		{
			this.ActSwapMenu(EMenus.MENU_OPTIONS);
		}
	}

	// Token: 0x04000B19 RID: 2841
	private float m_fVolumeSfx;

	// Token: 0x04000B1A RID: 2842
	private bool m_bIsMute;

	// Token: 0x04000B1B RID: 2843
	public UISlider m_pSfxSlider;

	// Token: 0x04000B1C RID: 2844
	public UISprite m_pMuteIcon;
}

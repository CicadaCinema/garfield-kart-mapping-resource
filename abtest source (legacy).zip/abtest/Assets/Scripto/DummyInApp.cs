﻿using System;

// Token: 0x020001CB RID: 459
public class DummyInApp : AInAppService, IDisposable
{
	// Token: 0x06000C6E RID: 3182 RVA: 0x0000A9CB File Offset: 0x00008BCB
	public DummyInApp(string[] pProductIds) : base(pProductIds)
	{
		this._canMakePurchase = true;
	}

	// Token: 0x06000C6F RID: 3183 RVA: 0x00052FD8 File Offset: 0x000511D8
	~DummyInApp()
	{
		if (!this._hasBeenDisposed)
		{
			this.Dispose();
		}
	}

	// Token: 0x06000C70 RID: 3184 RVA: 0x0000A9DB File Offset: 0x00008BDB
	public override void Dispose()
	{
		base.Dispose();
	}

	// Token: 0x06000C71 RID: 3185 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void GetData()
	{
	}

	// Token: 0x06000C72 RID: 3186 RVA: 0x0000A9E3 File Offset: 0x00008BE3
	public override void PurchaseProduct(string pProductId)
	{
		this.OnPurchaseSucceed(pProductId);
	}
}

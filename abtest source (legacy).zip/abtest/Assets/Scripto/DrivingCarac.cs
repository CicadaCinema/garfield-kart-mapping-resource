﻿using System;

// Token: 0x0200013A RID: 314
public class DrivingCarac : IconCarac
{
	// Token: 0x060008B1 RID: 2225 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void Start()
	{
	}

	// Token: 0x060008B2 RID: 2226 RVA: 0x0003F28C File Offset: 0x0003D48C
	public float GetCarac(DrivingCaracteristics _Carac)
	{
		switch (_Carac)
		{
		case DrivingCaracteristics.SPEED:
			return this.Speed;
		case DrivingCaracteristics.ACCELERATION:
			return this.Acceleration;
		case DrivingCaracteristics.MANIABILITY:
			return this.Maniability;
		default:
			return 0f;
		}
	}

	// Token: 0x040008E8 RID: 2280
	public ECharacter Owner;

	// Token: 0x040008E9 RID: 2281
	public float Acceleration;

	// Token: 0x040008EA RID: 2282
	public float Speed;

	// Token: 0x040008EB RID: 2283
	public float Maniability;

	// Token: 0x040008EC RID: 2284
	public float Bonus;

	// Token: 0x040008ED RID: 2285
	public DrivingCaracteristics BonusCaracteristic;

	// Token: 0x040008EE RID: 2286
	public int NbSlots;
}

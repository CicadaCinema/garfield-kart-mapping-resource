﻿using System;
using UnityEngine;

// Token: 0x0200012C RID: 300
public class GameConfigurator : Singleton<GameConfigurator>
{
	// Token: 0x17000131 RID: 305
	// (get) Token: 0x0600081A RID: 2074 RVA: 0x00007B9E File Offset: 0x00005D9E
	// (set) Token: 0x0600081B RID: 2075 RVA: 0x00007BA6 File Offset: 0x00005DA6
	public GameSettings GameSettings
	{
		get
		{
			return this._gameSettings;
		}
		set
		{
			this._gameSettings = value;
		}
	}

	// Token: 0x17000132 RID: 306
	// (get) Token: 0x0600081C RID: 2076 RVA: 0x00007BAF File Offset: 0x00005DAF
	// (set) Token: 0x0600081D RID: 2077 RVA: 0x00007BB7 File Offset: 0x00005DB7
	public string StartScene
	{
		get
		{
			return this._startScene;
		}
		set
		{
			this._startScene = value;
		}
	}

	// Token: 0x17000133 RID: 307
	// (get) Token: 0x0600081E RID: 2078 RVA: 0x00007BC0 File Offset: 0x00005DC0
	public PlayerConfig PlayerConfig
	{
		get
		{
			return this.m_pPlayerConfig;
		}
	}

	// Token: 0x17000134 RID: 308
	// (get) Token: 0x0600081F RID: 2079 RVA: 0x00007BC8 File Offset: 0x00005DC8
	// (set) Token: 0x06000820 RID: 2080 RVA: 0x00007BD0 File Offset: 0x00005DD0
	public EDifficulty Difficulty
	{
		get
		{
			return this.m_eDifficulty;
		}
		set
		{
			this.m_eDifficulty = value;
		}
	}

	// Token: 0x17000135 RID: 309
	// (get) Token: 0x06000821 RID: 2081 RVA: 0x00007BD9 File Offset: 0x00005DD9
	// (set) Token: 0x06000822 RID: 2082 RVA: 0x00007BE1 File Offset: 0x00005DE1
	public AISettings AISettings
	{
		get
		{
			return this._aiSettings;
		}
		set
		{
			this._aiSettings = value;
		}
	}

	// Token: 0x17000136 RID: 310
	// (get) Token: 0x06000823 RID: 2083 RVA: 0x00007BEA File Offset: 0x00005DEA
	public ChampionShipData ChampionShipData
	{
		get
		{
			return this._championShipData;
		}
	}

	// Token: 0x17000137 RID: 311
	// (get) Token: 0x06000824 RID: 2084 RVA: 0x00007BF2 File Offset: 0x00005DF2
	// (set) Token: 0x06000825 RID: 2085 RVA: 0x00007BFA File Offset: 0x00005DFA
	public E_GameModeType GameModeType
	{
		get
		{
			return this._gameModeType;
		}
		set
		{
			this._gameModeType = value;
		}
	}

	// Token: 0x17000138 RID: 312
	// (get) Token: 0x06000826 RID: 2086 RVA: 0x00007C03 File Offset: 0x00005E03
	// (set) Token: 0x06000827 RID: 2087 RVA: 0x00007C0B File Offset: 0x00005E0B
	public int CurrentTrackIndex
	{
		get
		{
			return this._currentTrackIndex;
		}
		set
		{
			this._currentTrackIndex = value;
		}
	}

	// Token: 0x17000139 RID: 313
	// (get) Token: 0x06000828 RID: 2088 RVA: 0x00007C14 File Offset: 0x00005E14
	// (set) Token: 0x06000829 RID: 2089 RVA: 0x00007C1C File Offset: 0x00005E1C
	public int NbSlots
	{
		get
		{
			return this.m_iNbSlots;
		}
		set
		{
			this.m_iNbSlots = value;
		}
	}

	// Token: 0x1700013A RID: 314
	// (get) Token: 0x0600082A RID: 2090 RVA: 0x00007C25 File Offset: 0x00005E25
	public PriceConfig PriceConfig
	{
		get
		{
			return this.m_pPriceConfig;
		}
	}

	// Token: 0x1700013B RID: 315
	// (get) Token: 0x0600082B RID: 2091 RVA: 0x00007C2D File Offset: 0x00005E2D
	// (set) Token: 0x0600082C RID: 2092 RVA: 0x00007C35 File Offset: 0x00005E35
	public ChampionshipPass ChampionshipPass
	{
		get
		{
			return this.m_pChampionshipPass;
		}
		set
		{
			this.m_pChampionshipPass = value;
		}
	}

	// Token: 0x1700013C RID: 316
	// (get) Token: 0x0600082D RID: 2093 RVA: 0x00007C3E File Offset: 0x00005E3E
	// (set) Token: 0x0600082E RID: 2094 RVA: 0x00007C46 File Offset: 0x00005E46
	public EMenus MenuToLaunch
	{
		get
		{
			return this.m_eMenuToLaunch;
		}
		set
		{
			this.m_eMenuToLaunch = value;
		}
	}

	// Token: 0x0600082F RID: 2095 RVA: 0x0003D1C0 File Offset: 0x0003B3C0
	public void Init()
	{
		this.m_eDifficulty = EDifficulty.NORMAL;
		this.m_pChampionshipPass = null;
		this.m_pPlayerConfig = GameObject.Find("EntryPoint").GetComponent<PlayerConfig>();
		this.m_pPriceConfig = GameObject.Find("EntryPoint").GetComponent<PriceConfig>();
		this.m_eMenuToLaunch = EMenus.MENU_WELCOME;
		this.RankingManager = new RankingManager();
	}

	// Token: 0x06000830 RID: 2096 RVA: 0x00007C4F File Offset: 0x00005E4F
	public void ResetChampionShip()
	{
		if (this._gameModeType == E_GameModeType.CHAMPIONSHIP)
		{
			this._currentTrackIndex = 0;
		}
		this.RankingManager.Reset();
		if (this.PlayerDataList != null)
		{
			this.PlayerDataList = null;
		}
	}

	// Token: 0x06000831 RID: 2097 RVA: 0x0003D218 File Offset: 0x0003B418
	public void SetChampionshipData(bool _WithPass, int index)
	{
		UnityEngine.Object[] array = Resources.LoadAll("ChampionShip", typeof(ChampionShipData));
		foreach (UnityEngine.Object @object in array)
		{
			if (@object is ChampionShipData)
			{
				ChampionShipData championShipData = (ChampionShipData)@object;
				if (championShipData.Index == index)
				{
					this.SetChampionshipData(championShipData, _WithPass);
					break;
				}
			}
		}
	}

	// Token: 0x06000832 RID: 2098 RVA: 0x0003D284 File Offset: 0x0003B484
	public void SetChampionshipData(ChampionShipData _Data, bool _WithPass)
	{
		this._championShipData = _Data;
		this._championShipData.Localize();
		if (_WithPass)
		{
			this.m_pChampionshipPass = new ChampionshipPass();
			this.m_pChampionshipPass.State = EChampionshipPassState.Selected;
			this.m_pChampionshipPass.ChampionshipSelectionned = _Data;
			this.m_pChampionshipPass.Difficulty = this.m_eDifficulty;
		}
	}

	// Token: 0x06000833 RID: 2099 RVA: 0x00007C81 File Offset: 0x00005E81
	public void RestartChampionShipRace()
	{
		this.RankingManager.RestartRace();
	}

	// Token: 0x06000834 RID: 2100 RVA: 0x00007C8E File Offset: 0x00005E8E
	public RaceScoreData GetScoreData(int iKartIndex)
	{
		return this.RankingManager.GetScoreData(iKartIndex);
	}

	// Token: 0x04000861 RID: 2145
	public const int MAX_NB_PLAYERS = 6;

	// Token: 0x04000862 RID: 2146
	public const int MAX_NB_TRACKS_PER_CHAMPIONSHIP = 4;

	// Token: 0x04000863 RID: 2147
	private EDifficulty m_eDifficulty;

	// Token: 0x04000864 RID: 2148
	private PlayerConfig m_pPlayerConfig;

	// Token: 0x04000865 RID: 2149
	private string _startScene = "MenuRoot";

	// Token: 0x04000866 RID: 2150
	private AISettings _aiSettings;

	// Token: 0x04000867 RID: 2151
	private GameSettings _gameSettings;

	// Token: 0x04000868 RID: 2152
	private E_GameModeType _gameModeType;

	// Token: 0x04000869 RID: 2153
	private ChampionShipData _championShipData;

	// Token: 0x0400086A RID: 2154
	private int _currentTrackIndex;

	// Token: 0x0400086B RID: 2155
	private int m_iNbSlots;

	// Token: 0x0400086C RID: 2156
	private PriceConfig m_pPriceConfig;

	// Token: 0x0400086D RID: 2157
	private ChampionshipPass m_pChampionshipPass;

	// Token: 0x0400086E RID: 2158
	private EMenus m_eMenuToLaunch;

	// Token: 0x0400086F RID: 2159
	public RankingManager RankingManager;

	// Token: 0x04000870 RID: 2160
	public bool m_bMobilePlatform;

	// Token: 0x04000871 RID: 2161
	public PlayerData[] PlayerDataList;

	// Token: 0x04000872 RID: 2162
	public string ChartBoostAppID = "YOUR_APP_ID";

	// Token: 0x04000873 RID: 2163
	public string ChartBoostAppSignature = "YOUR_APP_SIGNATURE";

	// Token: 0x04000874 RID: 2164
	public string FacebookAppID = "YOUR_FACEBOOK_ID";
}

﻿using System;
using UnityEngine;

// Token: 0x020000DE RID: 222
public class MagicBonusEntity : BonusEntity
{
	// Token: 0x060005EB RID: 1515 RVA: 0x00006351 File Offset: 0x00004551
	public MagicBonusEntity()
	{
		this.m_eItem = EITEM.ITEM_MAGIC;
	}

	// Token: 0x060005EC RID: 1516 RVA: 0x0002F5F4 File Offset: 0x0002D7F4
	public override void Awake()
	{
		this._attackEffect = (GameObject)UnityEngine.Object.Instantiate(this.AttackEffect);
		this._impactEffect = (GameObject)UnityEngine.Object.Instantiate(this.ImpactEffect);
		this._secondImpactEffect = (GameObject)UnityEngine.Object.Instantiate(this.ImpactEffect);
		this._wallImpactEffect = (GameObject)UnityEngine.Object.Instantiate(this.WallImpactEffect);
		this._attackEffect.transform.position = Vector3.zero;
		this._attackEffect.transform.parent = base.transform;
		this._impactEffect.transform.position = Vector3.zero;
		this._impactEffect.transform.parent = base.transform.transform.parent;
		this._secondImpactEffect.transform.position = Vector3.zero;
		this._secondImpactEffect.transform.parent = base.transform.transform.parent;
		this._wallImpactEffect.transform.position = Vector3.zero;
		this._wallImpactEffect.transform.parent = base.transform.transform.parent;
		this.m_pRigidBody = base.GetComponent<Rigidbody>();
		this.m_fCurrentSpeed = 0f;
		this.m_bSynchronizePosition = true;
		base.Awake();
		base.ActivateGameObject(false);
	}

	// Token: 0x060005ED RID: 1517 RVA: 0x0002F750 File Offset: 0x0002D950
	public override void OnDestroy()
	{
		if (this._attackEffect != null)
		{
			UnityEngine.Object.Destroy(this._attackEffect.gameObject);
		}
		if (this._impactEffect != null)
		{
			UnityEngine.Object.Destroy(this._impactEffect.gameObject);
		}
		if (this._secondImpactEffect != null)
		{
			UnityEngine.Object.Destroy(this._secondImpactEffect.gameObject);
		}
		if (this._wallImpactEffect != null)
		{
			UnityEngine.Object.Destroy(this._wallImpactEffect.gameObject);
		}
	}

	// Token: 0x060005EE RID: 1518 RVA: 0x0002F7E4 File Offset: 0x0002D9E4
	public virtual void FixedUpdate()
	{
		if ((Network.peerType == NetworkPeerType.Disconnected || Network.isServer) && this.m_pRigidBody.velocity.z != 0f)
		{
			Vector3 vVelocity = this.m_vVelocity;
			vVelocity.y = this.m_pRigidBody.velocity.y;
			this.m_pRigidBody.velocity = vVelocity;
			this.m_pRigidBody.velocity = this.m_fCurrentSpeed * this.m_pRigidBody.velocity.normalized;
			this.m_pRigidBody.AddForce(new Vector3(0f, -this.GravityForward, 0f), ForceMode.Impulse);
		}
	}

	// Token: 0x060005EF RID: 1519 RVA: 0x0002F89C File Offset: 0x0002DA9C
	public override void Update()
	{
		base.Update();
		if (this.m_bActive)
		{
			float deltaTime = Time.deltaTime;
			if (this._attackEffect && !this._attackEffect.particleSystem.isPlaying && this.m_eState == BonusEntity.BonusState.BONUS_LAUNCHED)
			{
				this.m_TrailTimer += deltaTime;
				if (this.m_TrailTimer > 0.05f)
				{
					this.m_TrailTimer = 0f;
					this._attackEffect.particleSystem.Play();
				}
			}
			if (this._attackEffect.activeSelf)
			{
				this._durationTimer += deltaTime;
				if (this._durationTimer > this.DurationDelay)
				{
					this.DeactivateGameObject();
				}
			}
			else if (!this._isHidden && this._impactEffect.particleSystem.isStopped)
			{
				this.DeactivateGameObject();
			}
			if (this._isHidden)
			{
				this._hideTimer += deltaTime;
				if (this._hideTimer > this.HideDelay)
				{
					this.ActivateVehicle(base.Launcher, true);
					this.ActivateVehicle(this._secondKart, true);
					this._hideTimer = 0f;
					this._isHidden = false;
				}
			}
		}
	}

	// Token: 0x060005F0 RID: 1520 RVA: 0x0002F9E0 File Offset: 0x0002DBE0
	public new void Launch()
	{
		base.Launch();
		this.m_vVelocity = Vector3.zero;
		this.SetActive(true);
		if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
		{
			this.m_pTransform.position = base.Launcher.Transform.position;
			this.m_pTransform.position += base.Launcher.Transform.rotation * new Vector3(0f, 0.5f, 3f);
			this.m_pTransform.rotation = base.Launcher.Transform.rotation;
		}
		this.m_pRigidBody.isKinematic = false;
		this.m_pCollider.isTrigger = false;
		this._direction = base.Launcher.transform.forward;
		this._direction.Normalize();
		this._hideTimer = 0f;
		this._isHidden = false;
		this._durationTimer = 0f;
		if (this.SoundLaunched && this.SoundTravel)
		{
			this.SoundLaunched.Play();
			this.SoundTravel.Play();
		}
	}

	// Token: 0x060005F1 RID: 1521 RVA: 0x0002FB1C File Offset: 0x0002DD1C
	public void DeactivateGameObject()
	{
		if (this.m_IgnoreCol)
		{
			if (this.m_pCollider.enabled && this.m_pLauncher.transform.parent.collider.enabled)
			{
				Physics.IgnoreCollision(this.m_pCollider, this.m_pLauncher.transform.parent.collider, false);
			}
			this.m_IgnoreCol = false;
		}
		base.ActivateGameObject(false);
		this.m_bActive = false;
	}

	// Token: 0x060005F2 RID: 1522 RVA: 0x0002FB9C File Offset: 0x0002DD9C
	public override void SetActive(bool pActive)
	{
		if (!pActive)
		{
			this._attackEffect.particleSystem.Stop();
			this._attackEffect.SetActive(false);
			if (this.m_IgnoreCol && this.m_pCollider.gameObject.activeSelf && this.m_pLauncher.transform.parent.collider.gameObject.activeSelf)
			{
				Physics.IgnoreCollision(this.m_pCollider, this.m_pLauncher.transform.parent.collider, false);
				this.m_IgnoreCol = false;
			}
			this.m_pCollider.enabled = pActive;
		}
		else
		{
			this._attackEffect.SetActive(true);
			base.ActivateGameObject(true);
			this._impactEffect.particleSystem.Stop();
			this._secondImpactEffect.particleSystem.Stop();
			this._wallImpactEffect.particleSystem.Stop();
			this.ComputeBaseSpeed();
			this.m_vVelocity = base.LaunchHorizontalDirection * this.m_fCurrentSpeed;
			this.m_pRigidBody.velocity = this.m_vVelocity;
			this.m_bActive = true;
			this.m_IgnoreCol = true;
			this.m_pCollider.enabled = pActive;
			if (this.m_pCollider.gameObject.activeSelf && this.m_pLauncher.transform.parent.collider.gameObject.activeSelf)
			{
				Physics.IgnoreCollision(this.m_pCollider, this.m_pLauncher.transform.parent.collider, true);
			}
		}
	}

	// Token: 0x060005F3 RID: 1523 RVA: 0x0002FD30 File Offset: 0x0002DF30
	public override void DoOnTriggerEnter(GameObject pOther, int otherlayer)
	{
		int num = 1 << otherlayer;
		if ((num & this.VehicleLayer) != 0)
		{
			this._secondKart = pOther.GetComponentInChildren<Kart>();
			if (this._secondKart != null)
			{
				ParfumeBonusEffect parfumeBonusEffect = (ParfumeBonusEffect)this._secondKart.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_ATTRACTED);
				if (!parfumeBonusEffect.Activated || parfumeBonusEffect.StinkParfume)
				{
					this.ActivateBonusEffect();
				}
				this._secondImpactEffect.transform.position = this._secondKart.transform.position;
				this._impactEffect.transform.position = base.Launcher.transform.position;
				this._impactEffect.particleSystem.Play();
				this._secondImpactEffect.transform.position = this._secondKart.transform.position;
				this._secondImpactEffect.particleSystem.Play();
				if (this.SoundTouchPlayer && this.SoundTravel)
				{
					this.SoundTouchPlayer.Play();
					this.SoundTravel.Stop();
				}
				this.SetActive(false);
			}
		}
		else if ((num & this.ColLayer) != 0)
		{
			this._wallImpactEffect.transform.position = this.m_pTransform.position;
			this._wallImpactEffect.particleSystem.Play();
			if (this.SoundTouchWall && this.SoundTravel)
			{
				this.SoundTouchWall.Play();
				this.SoundTravel.Stop();
			}
			this.SetActive(false);
		}
	}

	// Token: 0x060005F4 RID: 1524 RVA: 0x0002FEEC File Offset: 0x0002E0EC
	public void OnCollisionEnter(Collision collision)
	{
		if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
		{
			int num = 1 << collision.gameObject.layer;
			if ((num & this.VehicleLayer) != 0)
			{
				if (collision.gameObject != null)
				{
					this.OnTriggerEnter(collision.collider);
				}
			}
			else if ((num & this.ColLayer) != 0)
			{
				this.PerformCollision(collision);
			}
		}
	}

	// Token: 0x060005F5 RID: 1525 RVA: 0x0002FF6C File Offset: 0x0002E16C
	public void OnCollisionStay(Collision collision)
	{
		if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
		{
			int num = 1 << collision.gameObject.layer;
			if ((num & this.ColLayer) != 0)
			{
				this.PerformCollision(collision);
			}
		}
	}

	// Token: 0x060005F6 RID: 1526 RVA: 0x0002FFB8 File Offset: 0x0002E1B8
	public void PerformCollision(Collision collision)
	{
		if (collision.collider != null && collision.collider.isTrigger)
		{
			return;
		}
		for (int i = 0; i < collision.contacts.Length; i++)
		{
			ContactPoint contactPoint = collision.contacts[i];
			if (contactPoint.normal.y < 0.5f)
			{
				this.DestroyByWall();
				break;
			}
		}
	}

	// Token: 0x060005F7 RID: 1527 RVA: 0x00030038 File Offset: 0x0002E238
	public void DestroyByWall()
	{
		if (this.m_bActive)
		{
			if (Network.isServer)
			{
				this.m_pNetworkView.RPC("OnNetworkDestroy", RPCMode.All, new object[0]);
			}
			else if (Network.peerType == NetworkPeerType.Disconnected)
			{
				this.DoDestroyByWall();
			}
		}
	}

	// Token: 0x060005F8 RID: 1528 RVA: 0x00030088 File Offset: 0x0002E288
	public void DoDestroyByWall()
	{
		this._wallImpactEffect.transform.position = this.m_pTransform.position;
		this._wallImpactEffect.particleSystem.Play();
		if (this.SoundTouchWall && this.SoundTravel)
		{
			this.SoundTouchWall.Play();
			this.SoundTravel.Stop();
		}
		this.SetActive(false);
	}

	// Token: 0x060005F9 RID: 1529 RVA: 0x00030100 File Offset: 0x0002E300
	public void ActivateBonusEffect()
	{
		MagicBonusEffect magicBonusEffect = (MagicBonusEffect)base.Launcher.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_TELEPORTED);
		magicBonusEffect.FirstKart = base.Launcher;
		magicBonusEffect.SecondKart = this._secondKart;
		base.Launcher.GetBonusMgr().GetBonusEffectMgr().ActivateBonusEffect(EBonusEffect.BONUSEFFECT_TELEPORTED);
		this._isHidden = true;
		this._hideTimer = 0f;
		this.ActivateVehicle(base.Launcher, false);
		this.ActivateVehicle(this._secondKart, false);
	}

	// Token: 0x060005FA RID: 1530 RVA: 0x00030184 File Offset: 0x0002E384
	public void ComputeBaseSpeed()
	{
		float num = this.Speed / 3.6f;
		this.m_fCurrentSpeed = num + this.m_pLauncher.GetBonusMgr().GetBonusValue(EITEM.ITEM_MAGIC, EBonusCustomEffect.SPEED) * num / 100f;
	}

	// Token: 0x060005FB RID: 1531 RVA: 0x00006377 File Offset: 0x00004577
	public void ActivateVehicle(Kart pKart, bool bActivate)
	{
		pKart.GetVehiclePhysic().Enable = bActivate;
		pKart.SetLocked(!bActivate);
		pKart.GetComponent<RcKinematicPhysic>().m_pVehicleMesh.gameObject.SetActive(bActivate);
		if (bActivate)
		{
			pKart.KartSound.PlaySound(0);
		}
	}

	// Token: 0x040005E2 RID: 1506
	private Vector3 _direction;

	// Token: 0x040005E3 RID: 1507
	public float Speed;

	// Token: 0x040005E4 RID: 1508
	public float GravityForward;

	// Token: 0x040005E5 RID: 1509
	protected float m_fCurrentSpeed;

	// Token: 0x040005E6 RID: 1510
	private GameObject _attackEffect;

	// Token: 0x040005E7 RID: 1511
	private GameObject _impactEffect;

	// Token: 0x040005E8 RID: 1512
	private GameObject _secondImpactEffect;

	// Token: 0x040005E9 RID: 1513
	private GameObject _wallImpactEffect;

	// Token: 0x040005EA RID: 1514
	public GameObject AttackEffect;

	// Token: 0x040005EB RID: 1515
	public GameObject ImpactEffect;

	// Token: 0x040005EC RID: 1516
	public GameObject WallImpactEffect;

	// Token: 0x040005ED RID: 1517
	private Kart _secondKart;

	// Token: 0x040005EE RID: 1518
	private float _hideTimer;

	// Token: 0x040005EF RID: 1519
	public float HideDelay = 0.8f;

	// Token: 0x040005F0 RID: 1520
	private bool _isHidden;

	// Token: 0x040005F1 RID: 1521
	public float DurationDelay = 5f;

	// Token: 0x040005F2 RID: 1522
	private float _durationTimer;

	// Token: 0x040005F3 RID: 1523
	protected Rigidbody m_pRigidBody;

	// Token: 0x040005F4 RID: 1524
	private Vector3 m_vVelocity;

	// Token: 0x040005F5 RID: 1525
	private float m_TrailTimer;

	// Token: 0x040005F6 RID: 1526
	private bool m_IgnoreCol;

	// Token: 0x040005F7 RID: 1527
	public AudioSource SoundLaunched;

	// Token: 0x040005F8 RID: 1528
	public AudioSource SoundTouchPlayer;

	// Token: 0x040005F9 RID: 1529
	public AudioSource SoundTouchWall;

	// Token: 0x040005FA RID: 1530
	public AudioSource SoundTravel;

	// Token: 0x040005FB RID: 1531
	public LayerMask VehicleLayer;

	// Token: 0x040005FC RID: 1532
	public LayerMask ColLayer;
}

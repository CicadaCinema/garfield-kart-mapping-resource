﻿using System;
using UnityEngine;

// Token: 0x020001B0 RID: 432
public class MenuRewardsStar : MenuRewards
{
	// Token: 0x06000B8A RID: 2954 RVA: 0x0004D288 File Offset: 0x0004B488
	public override void OnEnter()
	{
		base.OnEnter();
		int num = (int)Singleton<RewardManager>.Instance.PopStar();
		string format = Localization.instance.Get(this.MainKey);
		string arg = Localization.instance.Get(this.StarTypeKeys[num]);
		int num2 = Singleton<GameConfigurator>.Instance.PlayerConfig.NbStars - 1;
		string arg2 = Localization.instance.Get(this.StarNumberKeys[num2]);
		for (int i = 0; i < MenuRewardsStar.StarCount; i++)
		{
			if (this.Stars[i])
			{
				this.Stars[i].SetActive(i == num2);
			}
		}
		this.LbMessage.text = string.Format(format, arg, arg2);
	}

	// Token: 0x04000B49 RID: 2889
	public static int StarCount = 5;

	// Token: 0x04000B4A RID: 2890
	public string MainKey;

	// Token: 0x04000B4B RID: 2891
	public string[] StarTypeKeys = new string[MenuRewardsStar.StarCount];

	// Token: 0x04000B4C RID: 2892
	public string[] StarNumberKeys = new string[MenuRewardsStar.StarCount];

	// Token: 0x04000B4D RID: 2893
	public GameObject[] Stars = new GameObject[MenuRewardsStar.StarCount];
}

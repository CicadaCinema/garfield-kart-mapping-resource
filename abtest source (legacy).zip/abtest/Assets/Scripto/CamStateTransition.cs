﻿using System;
using UnityEngine;

// Token: 0x020001F1 RID: 497
public abstract class CamStateTransition : CamState
{
	// Token: 0x06000D72 RID: 3442 RVA: 0x0000B2D9 File Offset: 0x000094D9
	public void Setup(CamState _From, CamState _To, bool _bFreezeFrom)
	{
		this.m_FromState = _From;
		this.m_ToState = _To;
		this.m_bFreezeFrom = _bFreezeFrom;
	}

	// Token: 0x06000D73 RID: 3443 RVA: 0x0000B2F0 File Offset: 0x000094F0
	public override void Enter(Transform _Transform, Transform _Target)
	{
		base.Enter(_Transform, _Target);
		this.m_ToState.Enter(_Transform, _Target);
	}

	// Token: 0x06000D74 RID: 3444 RVA: 0x00057A18 File Offset: 0x00055C18
	public override ECamState Manage(float dt)
	{
		if (this.m_FromState != null && !this.m_bFreezeFrom)
		{
			this.m_FromState.Manage(dt);
		}
		if (this.m_ToState != null)
		{
			this.m_ToState.Manage(dt);
		}
		if (this.Merge(dt))
		{
			return this.m_ToState.state;
		}
		return this.state;
	}

	// Token: 0x06000D75 RID: 3445
	protected abstract bool Merge(float dt);

	// Token: 0x04000D1F RID: 3359
	protected CamState m_FromState;

	// Token: 0x04000D20 RID: 3360
	protected CamState m_ToState;

	// Token: 0x04000D21 RID: 3361
	private bool m_bFreezeFrom;
}

﻿using System;
using UnityEngine;

// Token: 0x02000118 RID: 280
public class HUDResultsChallenge : MonoBehaviour
{
	// Token: 0x060007C4 RID: 1988 RVA: 0x0003A4F0 File Offset: 0x000386F0
	public void Start()
	{
		string empty = string.Empty;
		string empty2 = string.Empty;
		Singleton<ChallengeManager>.Instance.GetLocalizedObjectives(out empty, out empty2);
		this.FirstObjective.text = empty;
		this.SecondObjective.text = empty2;
		this.State.text = ((!Singleton<ChallengeManager>.Instance.Success) ? Localization.instance.Get("HUD_RESULTS_FAILED") : Localization.instance.Get("HUD_RESULTS_CONGRATS"));
		this.Summary.text = ((!Singleton<ChallengeManager>.Instance.Success) ? Localization.instance.Get("HUD_CHALLENGE_FAILED") : Localization.instance.Get("HUD_CHALLENGE_SUCCESS"));
		this.ChampionshipIcon.ChangeTexture(Singleton<GameConfigurator>.Instance.ChampionShipData.Index);
		this.DifficultyIcon.ChangeTexture((int)Singleton<GameConfigurator>.Instance.Difficulty);
		E_GameModeType gameMode = Singleton<ChallengeManager>.Instance.GameMode;
		int iNum = 0;
		switch (gameMode)
		{
		case E_GameModeType.SINGLE:
			iNum = 0;
			break;
		case E_GameModeType.CHAMPIONSHIP:
			iNum = 1;
			break;
		case E_GameModeType.TIME_TRIAL:
			iNum = 2;
			break;
		}
		this.GameModeIcon.ChangeTexture(iNum);
		this.ValidFirstObjective.ChangeTexture((!Singleton<ChallengeManager>.Instance.SuccessFirstObjective) ? 0 : 1);
		if (Singleton<ChallengeManager>.Instance.GameMode == E_GameModeType.TIME_TRIAL)
		{
			this.ValidSecondObjective.gameObject.SetActive(false);
		}
		else
		{
			this.ValidSecondObjective.ChangeTexture((!Singleton<ChallengeManager>.Instance.SuccessSecondObjective) ? 0 : 1);
		}
	}

	// Token: 0x040007C0 RID: 1984
	public UILabel FirstObjective;

	// Token: 0x040007C1 RID: 1985
	public UILabel SecondObjective;

	// Token: 0x040007C2 RID: 1986
	public UILabel State;

	// Token: 0x040007C3 RID: 1987
	public UILabel Summary;

	// Token: 0x040007C4 RID: 1988
	public UITexturePattern ChampionshipIcon;

	// Token: 0x040007C5 RID: 1989
	public UITexturePattern GameModeIcon;

	// Token: 0x040007C6 RID: 1990
	public UITexturePattern DifficultyIcon;

	// Token: 0x040007C7 RID: 1991
	public UITexturePattern ValidFirstObjective;

	// Token: 0x040007C8 RID: 1992
	public UITexturePattern ValidSecondObjective;
}

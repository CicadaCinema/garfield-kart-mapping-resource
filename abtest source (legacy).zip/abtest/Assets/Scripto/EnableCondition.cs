﻿using System;

namespace AnimationOrTween
{
	// Token: 0x0200003A RID: 58
	public enum EnableCondition
	{
		// Token: 0x0400014F RID: 335
		DoNothing,
		// Token: 0x04000150 RID: 336
		EnableThenPlay
	}
}

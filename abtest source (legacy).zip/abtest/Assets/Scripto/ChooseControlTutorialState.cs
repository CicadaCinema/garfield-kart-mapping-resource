﻿using System;
using UnityEngine;

// Token: 0x02000180 RID: 384
public class ChooseControlTutorialState : IGTutorialState
{
	// Token: 0x06000A32 RID: 2610 RVA: 0x00008FC1 File Offset: 0x000071C1
	public void Start()
	{
		this.DisablePanelOnTouch = false;
	}

	// Token: 0x06000A33 RID: 2611 RVA: 0x00008FCA File Offset: 0x000071CA
	public void OnSelectGyro()
	{
		Singleton<GameOptionManager>.Instance.SetInputType(E_InputType.Gyroscopic, true);
		this.GameMode.OnSuccess();
		base.gameObject.SetActive(false);
	}

	// Token: 0x06000A34 RID: 2612 RVA: 0x00008FEF File Offset: 0x000071EF
	public void OnSelectTouch()
	{
		Singleton<GameOptionManager>.Instance.SetInputType(E_InputType.Touched, true);
		this.GameMode.OnSuccess();
		base.gameObject.SetActive(false);
	}

	// Token: 0x06000A35 RID: 2613 RVA: 0x00009014 File Offset: 0x00007214
	public new void OnDisable()
	{
		base.OnDisable();
		Time.timeScale = 1f;
		Singleton<GameManager>.Instance.GameMode.Hud.HUDControls.ShowExceptPause(true);
	}
}

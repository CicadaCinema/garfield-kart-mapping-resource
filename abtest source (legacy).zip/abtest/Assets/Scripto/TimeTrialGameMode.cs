﻿using System;
using UnityEngine;

// Token: 0x02000189 RID: 393
public class TimeTrialGameMode : InGameGameMode
{
	// Token: 0x06000A7E RID: 2686 RVA: 0x00008DA4 File Offset: 0x00006FA4
	public override void Dispose()
	{
		base.Dispose();
		ChanceDispatcher chanceDispatcher = this._chanceDispatcher;
		chanceDispatcher.OnCreatePlayer = (Action<PlayerData, int>)Delegate.Remove(chanceDispatcher.OnCreatePlayer, new Action<PlayerData, int>(this.AddPlayerData));
	}

	// Token: 0x06000A7F RID: 2687 RVA: 0x000093B9 File Offset: 0x000075B9
	public override void Awake()
	{
		base.Awake();
		ChanceDispatcher chanceDispatcher = this._chanceDispatcher;
		chanceDispatcher.OnCreatePlayer = (Action<PlayerData, int>)Delegate.Combine(chanceDispatcher.OnCreatePlayer, new Action<PlayerData, int>(this.AddPlayerData));
	}

	// Token: 0x06000A80 RID: 2688 RVA: 0x000093E9 File Offset: 0x000075E9
	public override void Start()
	{
		base.Start();
		Singleton<BonusMgr>.Instance.Reset();
	}

	// Token: 0x06000A81 RID: 2689 RVA: 0x00047784 File Offset: 0x00045984
	public override void CreatePlayers()
	{
		if (DebugMgr.Instance != null && !DebugMgr.Instance.dbgData.RandomPlayer)
		{
			DebugMgr.Instance.LoadDefaultPlayer(0, this);
		}
		else
		{
			ECharacter character = Singleton<GameConfigurator>.Instance.PlayerConfig.Character;
			ECharacter kart = Singleton<GameConfigurator>.Instance.PlayerConfig.Kart;
			GameObject gameObject = (GameObject)Resources.Load("Hat/" + Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat.name);
			GameObject gameObject2 = (GameObject)Resources.Load("Kart/" + Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom.name);
			int nbStars = Singleton<GameConfigurator>.Instance.PlayerConfig.NbStars;
			Singleton<GameSaveManager>.Instance.EarnAdvantage(EAdvantage.BoostStart, 1, false);
			Singleton<GameConfigurator>.Instance.PlayerConfig.SelectAdvantage(EAdvantage.BoostStart);
			base.CreatePlayer(character, kart, gameObject2.name, gameObject.name, nbStars, 0, true, false);
			this._chanceDispatcher.AddPlayerData(character, kart, gameObject2, gameObject, nbStars, 0);
		}
		base.CreateAIPaths();
		base.SubscribeRaceEnd();
		UnityEngine.Object @object = Resources.Load("TimeTrial_Ufo");
		if (Network.isServer)
		{
			this.UFO = (GameObject)Network.Instantiate(@object, Vector3.zero, Quaternion.identity, 0);
		}
		else if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.UFO = (GameObject)UnityEngine.Object.Instantiate(@object);
		}
	}

	// Token: 0x06000A82 RID: 2690 RVA: 0x000478EC File Offset: 0x00045AEC
	public static bool GetMedalBeaten(ref E_TimeTrialMedal _FromMedal, int record, out float _DiffTime)
	{
		_DiffTime = -1f;
		Kart humanKart = Singleton<GameManager>.Instance.GameMode.GetHumanKart();
		RcVehicleRaceStats raceStats = humanKart.RaceStats;
		GameObject gameObject = GameObject.Find("Race");
		TimeTrialConfig component = gameObject.GetComponent<TimeTrialConfig>();
		int[] array = new int[]
		{
			0,
			component.Bronze,
			component.Silver,
			component.Gold,
			component.Platinium
		};
		E_TimeTrialMedal e_TimeTrialMedal = E_TimeTrialMedal.None;
		if (raceStats.GetRaceTime() < array[4])
		{
			e_TimeTrialMedal = E_TimeTrialMedal.Platinium;
		}
		else
		{
			for (int i = 4; i > (int)_FromMedal; i--)
			{
				if (raceStats.GetRaceTime() <= array[i])
				{
					e_TimeTrialMedal = (E_TimeTrialMedal)i;
					break;
				}
			}
		}
		if (e_TimeTrialMedal > _FromMedal)
		{
			_FromMedal = e_TimeTrialMedal;
			return true;
		}
		if (_FromMedal != E_TimeTrialMedal.Platinium)
		{
			_DiffTime = (float)(raceStats.GetRaceTime() - array[(int)(_FromMedal + 1)]) / 1000f;
		}
		else if (_FromMedal == E_TimeTrialMedal.Platinium)
		{
			_DiffTime = (float)(record - raceStats.GetRaceTime()) / 1000f;
		}
		return false;
	}

	// Token: 0x06000A83 RID: 2691 RVA: 0x000479F0 File Offset: 0x00045BF0
	public static bool BeatTime(E_TimeTrialMedal _Medal)
	{
		GameObject gameObject = GameObject.Find("Race");
		TimeTrialConfig component = gameObject.GetComponent<TimeTrialConfig>();
		int[] array = new int[]
		{
			0,
			component.Bronze,
			component.Silver,
			component.Gold,
			component.Platinium
		};
		Kart humanKart = Singleton<GameManager>.Instance.GameMode.GetHumanKart();
		RcVehicleRaceStats raceStats = humanKart.RaceStats;
		if (_Medal == E_TimeTrialMedal.Platinium)
		{
			string startScene = Singleton<GameConfigurator>.Instance.StartScene;
			int num = 0;
			Singleton<GameSaveManager>.Instance.GetTimeTrialRecord(startScene, ref num);
			return raceStats.GetRaceTime() < num;
		}
		return raceStats.GetRaceTime() < array[(int)_Medal];
	}

	// Token: 0x06000A84 RID: 2692 RVA: 0x000093FB File Offset: 0x000075FB
	protected override void StateChange(E_GameState pNewState)
	{
		base.StateChange(pNewState);
		if (pNewState == E_GameState.Race)
		{
			this.UFO.GetComponent<TimeTrialUFO>().Launch();
		}
	}

	// Token: 0x06000A85 RID: 2693 RVA: 0x00047A90 File Offset: 0x00045C90
	protected override void RaceEnd(RcVehicle pVehicle)
	{
		base.RaceEnd(pVehicle);
		base.Hud.HUDEndTimeTrial.FillStats(Singleton<GameConfigurator>.Instance.PlayerDataList);
		base.Hud.HUDEndTimeTrial2.FillStats(Singleton<GameConfigurator>.Instance.PlayerDataList);
		string startScene = Singleton<GameConfigurator>.Instance.StartScene;
		Kart humanKart = Singleton<GameManager>.Instance.GameMode.GetHumanKart();
		RcVehicleRaceStats raceStats = humanKart.RaceStats;
		PlayerData playerData = Singleton<GameConfigurator>.Instance.PlayerDataList[0];
		E_TimeTrialMedal medal = Singleton<GameSaveManager>.Instance.GetMedal(startScene, false);
		base.Hud.HUDFinish.FillRank(1);
		base.Hud.HUDTimeTrialResults.SetPreviousMedal(medal);
		int num = 0;
		Singleton<GameSaveManager>.Instance.GetTimeTrialRecord(startScene, ref num);
		float pDiffTime;
		bool medalBeaten = TimeTrialGameMode.GetMedalBeaten(ref medal, num, out pDiffTime);
		Singleton<RewardManager>.Instance.EndTimeTrial(startScene, medal, pDiffTime);
		if (medalBeaten)
		{
			Singleton<GameSaveManager>.Instance.SetMedal(startScene, medal, false);
			humanKart.KartSound.PlayVoice(KartSound.EVoices.Selection);
			base.Hud.HUDFinish.FillRank(0);
		}
		bool flag = raceStats.GetRaceTime() < num || num < 0;
		if (flag)
		{
			Singleton<GameSaveManager>.Instance.SetTimeTrial(startScene, raceStats.GetRaceTime(), playerData.Character, playerData.Kart, playerData.Custom, playerData.Hat, false);
			humanKart.KartSound.PlayVoice(KartSound.EVoices.Selection);
			base.Hud.HUDFinish.FillRank(0);
		}
		if (Singleton<GameManager>.Instance.SoundManager)
		{
			if (medalBeaten || (medal == E_TimeTrialMedal.Platinium && flag))
			{
				Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.FinishGood);
			}
			else
			{
				Singleton<GameManager>.Instance.SoundManager.PlaySound(ERaceSounds.FinishBad);
			}
		}
		int num2 = 0;
		Singleton<GameSaveManager>.Instance.GetTimeTrialBestTime(startScene, ref num2);
		if (raceStats.GetBestLapTime() < num2 || num2 < 0)
		{
			Singleton<GameSaveManager>.Instance.SetTimeTrialBestTime(startScene, raceStats.GetBestLapTime());
		}
		Singleton<RewardManager>.Instance.CanUnlockPuzzlePieces(true);
	}

	// Token: 0x06000A86 RID: 2694 RVA: 0x00047C8C File Offset: 0x00045E8C
	public override void PlaceVehiclesOnStartLine()
	{
		GameObject gameObject = GameObject.Find("Start");
		if (gameObject != null)
		{
			Kart humanKart = base.GetHumanKart();
			if (humanKart != null)
			{
				this.StartPositions[0] = gameObject.transform.GetChild(gameObject.transform.GetChildCount() - 1);
			}
		}
		this.UFO.GetComponent<TimeTrialUFO>().Place();
	}

	// Token: 0x04000A59 RID: 2649
	private GameObject UFO;
}

﻿using System;

// Token: 0x02000104 RID: 260
public enum EInputAction
{
	// Token: 0x040006F8 RID: 1784
	SteerLeft,
	// Token: 0x040006F9 RID: 1785
	SteerRight,
	// Token: 0x040006FA RID: 1786
	Brake,
	// Token: 0x040006FB RID: 1787
	Drift
}

﻿using System;
using UnityEngine;

// Token: 0x020000B5 RID: 181
public class GameManager : Singleton<GameManager>
{
	// Token: 0x06000489 RID: 1161 RVA: 0x000280D0 File Offset: 0x000262D0
	public GameManager()
	{
		this.m_pGameMode = null;
		this.m_pGameModeObject = new GameObject("Game Mode");
		this.m_pNetworkView = (NetworkView)this.m_pGameModeObject.AddComponent(typeof(NetworkView));
		if (this.m_pNetworkView)
		{
			this.m_pNetworkView.stateSynchronization = NetworkStateSynchronization.Off;
			this.m_pNetworkView.observed = null;
		}
		UnityEngine.Object.DontDestroyOnLoad(this.m_pGameModeObject);
	}

	// Token: 0x170000E0 RID: 224
	// (get) Token: 0x0600048B RID: 1163 RVA: 0x00005453 File Offset: 0x00003653
	// (set) Token: 0x0600048C RID: 1164 RVA: 0x0000545B File Offset: 0x0000365B
	public GameMode GameMode
	{
		get
		{
			return this.m_pGameMode;
		}
		set
		{
			this.m_pGameMode = value;
		}
	}

	// Token: 0x170000E1 RID: 225
	// (get) Token: 0x0600048D RID: 1165 RVA: 0x00005464 File Offset: 0x00003664
	// (set) Token: 0x0600048E RID: 1166 RVA: 0x0000546C File Offset: 0x0000366C
	public SoundManager SoundManager
	{
		get
		{
			return this.m_pSoundManager;
		}
		set
		{
			this.m_pSoundManager = value;
		}
	}

	// Token: 0x170000E2 RID: 226
	// (get) Token: 0x0600048F RID: 1167 RVA: 0x00005475 File Offset: 0x00003675
	public NetworkView NetworkView
	{
		get
		{
			return this.m_pNetworkView;
		}
	}

	// Token: 0x06000490 RID: 1168 RVA: 0x0000547D File Offset: 0x0000367D
	public void Reset()
	{
		if (this.m_pGameMode != null)
		{
			this.m_pGameMode.Dispose();
			UnityEngine.Object.Destroy(this.m_pGameMode);
			this.m_pGameMode = null;
		}
	}

	// Token: 0x06000491 RID: 1169 RVA: 0x00003B80 File Offset: 0x00001D80
	public void Init()
	{
	}

	// Token: 0x06000492 RID: 1170 RVA: 0x00028150 File Offset: 0x00026350
	public void LaunchGame()
	{
		if (DebugMgr.Instance != null && Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.DEBUG)
		{
			Singleton<GameConfigurator>.Instance.GameModeType = E_GameModeType.CHAMPIONSHIP;
		}
		switch (Singleton<GameConfigurator>.Instance.GameModeType)
		{
		case E_GameModeType.DEBUG:
			this.m_pGameMode = (GameMode)this.m_pGameModeObject.AddComponent(typeof(DebugGameMode));
			break;
		case E_GameModeType.DEBUG_AI:
			this.m_pGameMode = (GameMode)this.m_pGameModeObject.AddComponent(typeof(DebugAiGameMode));
			break;
		case E_GameModeType.SINGLE:
			this.m_pGameMode = (GameMode)this.m_pGameModeObject.AddComponent(typeof(SingleRaceGameMode));
			break;
		case E_GameModeType.CHAMPIONSHIP:
			this.m_pGameMode = (GameMode)this.m_pGameModeObject.AddComponent(typeof(ChampionShipGameMode));
			break;
		case E_GameModeType.TIME_TRIAL:
			this.m_pGameMode = (GameMode)this.m_pGameModeObject.AddComponent(typeof(TimeTrialGameMode));
			break;
		case E_GameModeType.TUTORIAL:
			this.m_pGameMode = (GameMode)this.m_pGameModeObject.AddComponent(typeof(TutorialGameMode));
			break;
		}
		NetworkMgr networkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
		if (networkMgr)
		{
			this.m_pGameModeObject.networkView.viewID = networkMgr.GameModeId;
		}
	}

	// Token: 0x06000493 RID: 1171 RVA: 0x000054AD File Offset: 0x000036AD
	public void CreatePlayers()
	{
		this.m_pGameMode.CreatePlayers();
	}

	// Token: 0x04000453 RID: 1107
	private GameMode m_pGameMode;

	// Token: 0x04000454 RID: 1108
	private GameObject m_pGameModeObject;

	// Token: 0x04000455 RID: 1109
	public static readonly E_GameModeType FirstRealGameMode = E_GameModeType.SINGLE;

	// Token: 0x04000456 RID: 1110
	public static readonly E_GameModeType LastRealGameMode = E_GameModeType.TIME_TRIAL;

	// Token: 0x04000457 RID: 1111
	private SoundManager m_pSoundManager;

	// Token: 0x04000458 RID: 1112
	private NetworkView m_pNetworkView;
}

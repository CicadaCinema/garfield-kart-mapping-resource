﻿using System;
using UnityEngine;

// Token: 0x020001E2 RID: 482
[Serializable]
public class PidController
{
	// Token: 0x06000CF0 RID: 3312 RVA: 0x00055548 File Offset: 0x00053748
	public PidController()
	{
		this.Clear();
		this.pBehaviourSetting = Singleton<GameConfigurator>.Instance.AISettings.BehaviourSettings;
	}

	// Token: 0x170001AC RID: 428
	// (get) Token: 0x06000CF1 RID: 3313 RVA: 0x0000AE52 File Offset: 0x00009052
	public float PCoefficient
	{
		get
		{
			return this.pBehaviourSetting.PCoefficient;
		}
	}

	// Token: 0x170001AD RID: 429
	// (get) Token: 0x06000CF2 RID: 3314 RVA: 0x0000AE5F File Offset: 0x0000905F
	public float ICoefficient
	{
		get
		{
			return this.pBehaviourSetting.ICoefficient;
		}
	}

	// Token: 0x170001AE RID: 430
	// (get) Token: 0x06000CF3 RID: 3315 RVA: 0x0000AE6C File Offset: 0x0000906C
	public float DCoefficient
	{
		get
		{
			return this.pBehaviourSetting.DCoefficient;
		}
	}

	// Token: 0x170001AF RID: 431
	// (get) Token: 0x06000CF4 RID: 3316 RVA: 0x0000AE79 File Offset: 0x00009079
	public float Error
	{
		get
		{
			if (this._numErrorsRecorded >= 1)
			{
				return this._error[this._currentIndex];
			}
			return 0f;
		}
	}

	// Token: 0x170001B0 RID: 432
	// (get) Token: 0x06000CF5 RID: 3317 RVA: 0x0000AE9A File Offset: 0x0000909A
	public float ErrorIntegral
	{
		get
		{
			return this._currentIntegral;
		}
	}

	// Token: 0x06000CF6 RID: 3318 RVA: 0x0005559C File Offset: 0x0005379C
	public void Record(float pError, float pTimeStep)
	{
		if (pTimeStep <= 0f)
		{
			return;
		}
		this._previousIndex = this._currentIndex;
		this._currentIndex = (this._currentIndex + 1) % 40;
		float num = this._error[this._currentIndex];
		float num2 = this._timeStep[this._currentIndex];
		this._error[this._currentIndex] = pError;
		this._timeStep[this._currentIndex] = pTimeStep;
		this._numErrorsRecorded = Mathf.Min(this._numErrorsRecorded + 1, 40);
		if (this._currentIndex == this._lastIndexIntegral)
		{
			this._errorSum -= num * num2;
			this._timeSum -= num2;
			this._lastIndexIntegral = (this._lastIndexIntegral + 1) % 40;
		}
		this._errorSum += pError * pTimeStep;
		this._timeSum += pTimeStep;
		while (this._timeSum > this.IntegralDuration)
		{
			this._errorSum -= this._error[this._lastIndexIntegral] * this._timeStep[this._lastIndexIntegral];
			this._timeSum -= this._timeStep[this._lastIndexIntegral];
			this._lastIndexIntegral = (this._lastIndexIntegral + 1) % 40;
		}
		int num3 = (this._lastIndexIntegral + 40 - 1) % 40;
		if (num3 != this._currentIndex)
		{
			this._currentIntegral = this._error[num3] * (this.IntegralDuration - this._timeSum) + this._errorSum;
		}
		else
		{
			this._currentIntegral = this._errorSum * this.IntegralDuration / this._timeSum;
		}
	}

	// Token: 0x06000CF7 RID: 3319 RVA: 0x00055744 File Offset: 0x00053944
	public void Clear()
	{
		this._currentIndex = 0;
		this._previousIndex = 0;
		this._numErrorsRecorded = 0;
		this._currentIntegral = 0f;
		this._errorSum = 0f;
		this._timeSum = 0f;
		this._lastIndexIntegral = this._currentIndex;
		for (int i = 0; i < 40; i++)
		{
			this._error[i] = 0f;
			this._timeStep[i] = 0f;
		}
	}

	// Token: 0x06000CF8 RID: 3320 RVA: 0x0000AEA2 File Offset: 0x000090A2
	public void ResetErrorSum()
	{
		this._errorSum = 0f;
	}

	// Token: 0x06000CF9 RID: 3321 RVA: 0x000557C0 File Offset: 0x000539C0
	public float GetErrorDerivative()
	{
		if (this._numErrorsRecorded < 2)
		{
			return 0f;
		}
		float num = this._error[this._currentIndex] - this._error[this._previousIndex];
		float num2 = this._timeStep[this._currentIndex];
		if (num2 > 0.001f)
		{
			return num / num2;
		}
		return 999999f;
	}

	// Token: 0x06000CFA RID: 3322 RVA: 0x0000AEAF File Offset: 0x000090AF
	public float GetOutput()
	{
		if (this.pBehaviourSetting == null)
		{
			return this.Error;
		}
		return this.PCoefficient * this.Error + this.ICoefficient * this.ErrorIntegral + this.DCoefficient * this.GetErrorDerivative();
	}

	// Token: 0x04000C88 RID: 3208
	public const int NUM_ERROR_SLOTS = 40;

	// Token: 0x04000C89 RID: 3209
	public float IntegralDuration = 0.5f;

	// Token: 0x04000C8A RID: 3210
	private float[] _error = new float[40];

	// Token: 0x04000C8B RID: 3211
	private float[] _timeStep = new float[40];

	// Token: 0x04000C8C RID: 3212
	private int _currentIndex;

	// Token: 0x04000C8D RID: 3213
	private int _previousIndex;

	// Token: 0x04000C8E RID: 3214
	private int _numErrorsRecorded;

	// Token: 0x04000C8F RID: 3215
	private int _lastIndexIntegral;

	// Token: 0x04000C90 RID: 3216
	private float _currentIntegral;

	// Token: 0x04000C91 RID: 3217
	private float _errorSum;

	// Token: 0x04000C92 RID: 3218
	private float _timeSum;

	// Token: 0x04000C93 RID: 3219
	private BehaviourSettings pBehaviourSetting;
}

﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200009A RID: 154
[Serializable]
public class ChanceDispatcher
{
	// Token: 0x06000415 RID: 1045 RVA: 0x00024658 File Offset: 0x00022858
	public ChanceDispatcher()
	{
		this._chanceSettings = Singleton<GameConfigurator>.Instance.AISettings.ChanceSettings;
		UnityEngine.Object[] array = Resources.LoadAll("Hat");
		foreach (UnityEngine.Object @object in array)
		{
			if (@object is GameObject)
			{
				GameObject gameObject = (GameObject)@object;
				BonusCustom component = gameObject.GetComponent<BonusCustom>();
				if (component != null)
				{
					ECharacter character = component.Character;
					if (component.Category == EITEM.ITEM_NONE)
					{
						this._heads.Add(character, gameObject);
					}
					else if (character == ECharacter.NONE)
					{
						if (!this._availableHats.ContainsKey(character))
						{
							this._availableHats.Add(character, new List<GameObject>());
						}
						this._availableHats[character].Add(gameObject);
						this._allHats.Add(gameObject);
					}
					else
					{
						if (!this._availableUniqueHats.ContainsKey(character))
						{
							this._availableUniqueHats.Add(character, new List<GameObject>());
						}
						this._availableUniqueHats[character].Add(gameObject);
					}
				}
			}
		}
		UnityEngine.Object[] array3 = Resources.LoadAll("Kart");
		foreach (UnityEngine.Object object2 in array3)
		{
			if (object2 is GameObject)
			{
				GameObject gameObject2 = (GameObject)object2;
				KartCustom component2 = gameObject2.GetComponent<KartCustom>();
				if (component2 != null)
				{
					ECharacter character2 = component2.Character;
					if (character2 != ECharacter.NONE)
					{
						this._defaultKartCustoms.Add(character2, gameObject2);
					}
					else
					{
						if (!this._kartCustoms.ContainsKey(component2.Owner))
						{
							this._kartCustoms.Add(component2.Owner, new List<GameObject>());
						}
						this._kartCustoms[component2.Owner].Add(gameObject2);
						this._allKartCustoms.Add(gameObject2);
					}
				}
			}
		}
	}

	// Token: 0x06000416 RID: 1046 RVA: 0x0002491C File Offset: 0x00022B1C
	public void DispatchAI(int pIndex, bool pLock, out ECharacter vPerso, out ECharacter vKart, out GameObject vHat, out GameObject vKartCusto)
	{
		E_AILevel pLevel = E_AILevel.GOOD;
		if (pIndex == 5)
		{
			pLevel = E_AILevel.BAD;
		}
		else if (pIndex > 2)
		{
			pLevel = E_AILevel.AVERAGE;
		}
		if (Singleton<ChallengeManager>.Instance.IsActive && Singleton<ChallengeManager>.Instance.GetSomeoneToBeat() && this._availableCharacters.Contains(Singleton<ChallengeManager>.Instance.GetCharacterToBeat()))
		{
			vPerso = Singleton<ChallengeManager>.Instance.GetCharacterToBeat();
			this._availableCharacters.Remove(vPerso);
		}
		else
		{
			vPerso = this.GetRandomCharacter(this._availableCharacters);
		}
		vKart = this.GenerateKart(pLevel, vPerso);
		vHat = this.GenerateHat(pLevel, vPerso);
		vKartCusto = this.GenerateCustom(pLevel, vKart);
		if (this.OnCreatePlayer != null)
		{
			this.OnCreatePlayer(new PlayerData(vPerso, vKart, vKartCusto.name, vHat.name, 0, string.Empty, Color.white), pIndex);
		}
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x00024A08 File Offset: 0x00022C08
	public void AddPlayerData(ECharacter pPerso, ECharacter pKart, GameObject pKartCusto, GameObject pHat, int iNbStars, int pIndex)
	{
		if (this._availableCharacters.Contains(pPerso))
		{
			this._availableCharacters.Remove(pPerso);
		}
		if (this.OnCreatePlayer != null)
		{
			this.OnCreatePlayer(new PlayerData(pPerso, pKart, pKartCusto.name, pHat.name, iNbStars, string.Empty, Singleton<GameConfigurator>.Instance.PlayerConfig.PlayerColor), pIndex);
		}
	}

	// Token: 0x06000418 RID: 1048 RVA: 0x00024A78 File Offset: 0x00022C78
	private ECharacter GetRandomCharacter(List<ECharacter> pCharacters)
	{
		ECharacter randomItem = this.GetRandomItem(pCharacters.ToArray());
		pCharacters.Remove(randomItem);
		return randomItem;
	}

	// Token: 0x06000419 RID: 1049 RVA: 0x00024A9C File Offset: 0x00022C9C
	private ECharacter GetRandomItem(ECharacter[] pItems)
	{
		int num = Singleton<RandomManager>.Instance.Next(pItems.Length - 1);
		return pItems[num];
	}

	// Token: 0x0600041A RID: 1050 RVA: 0x00024ABC File Offset: 0x00022CBC
	private GameObject GetRandomObject(List<GameObject> pGameObjects)
	{
		int index = Singleton<RandomManager>.Instance.Next(pGameObjects.Count - 1);
		return pGameObjects[index];
	}

	// Token: 0x0600041B RID: 1051 RVA: 0x00024AE4 File Offset: 0x00022CE4
	private ECharacter GenerateKart(E_AILevel pLevel, ECharacter pCharacter)
	{
		int chance = this._chanceSettings.KartChance.GetChance(pLevel);
		if (this.ForceChoice(chance))
		{
			return pCharacter;
		}
		return this.GetRandomItem(this._availableKarts);
	}

	// Token: 0x0600041C RID: 1052 RVA: 0x00024B20 File Offset: 0x00022D20
	private GameObject GenerateCustom(E_AILevel pLevel, ECharacter pCharacter)
	{
		int chance = this._chanceSettings.HatChance.GetChance(pLevel);
		if (this.ForceChoice(chance))
		{
			List<GameObject> list = new List<GameObject>();
			if (this._kartCustoms.ContainsKey(pCharacter))
			{
				list = this._kartCustoms[pCharacter];
			}
			if (list.Count > 0)
			{
				return this.GetRandomObject(list);
			}
			if (this._defaultKartCustoms.ContainsKey(pCharacter))
			{
				return this._defaultKartCustoms[pCharacter];
			}
			return this._defaultKartCustoms[ECharacter.GARFIELD];
		}
		else
		{
			bool flag = this.IsNone(this._chanceSettings.CustoChance.None);
			if (!flag)
			{
				return this.GetRandomObject(this._allKartCustoms);
			}
			if (this._defaultKartCustoms.ContainsKey(pCharacter))
			{
				return this._defaultKartCustoms[pCharacter];
			}
			return this._defaultKartCustoms[ECharacter.GARFIELD];
		}
	}

	// Token: 0x0600041D RID: 1053 RVA: 0x00024C04 File Offset: 0x00022E04
	private List<GameObject> GetAll(List<GameObject> pLeftList, List<GameObject> pRightList)
	{
		List<GameObject> list = new List<GameObject>();
		foreach (GameObject item in pLeftList)
		{
			list.Add(item);
		}
		foreach (GameObject item2 in pRightList)
		{
			list.Add(item2);
		}
		return list;
	}

	// Token: 0x0600041E RID: 1054 RVA: 0x00024CA8 File Offset: 0x00022EA8
	private GameObject GenerateHat(E_AILevel pLevel, ECharacter pCharacter)
	{
		int chance = this._chanceSettings.HatChance.GetChance(pLevel);
		if (this.ForceChoice(chance))
		{
			List<GameObject> pLeftList = new List<GameObject>();
			if (this._availableHats.ContainsKey(pCharacter))
			{
				pLeftList = this._availableHats[pCharacter];
			}
			List<GameObject> pRightList = new List<GameObject>();
			if (this._availableUniqueHats.ContainsKey(pCharacter))
			{
				pRightList = this._availableUniqueHats[pCharacter];
			}
			List<GameObject> all = this.GetAll(pLeftList, pRightList);
			if (all.Count > 0)
			{
				return this.GetRandomObject(all);
			}
			return this._heads[pCharacter];
		}
		else
		{
			bool flag = this.IsNone(this._chanceSettings.HatChance.None);
			if (flag)
			{
				return this._heads[pCharacter];
			}
			List<GameObject> pRightList2 = new List<GameObject>();
			if (this._availableUniqueHats.ContainsKey(pCharacter))
			{
				pRightList2 = this._availableUniqueHats[pCharacter];
			}
			List<GameObject> all2 = this.GetAll(this._allHats, pRightList2);
			if (all2.Count > 0)
			{
				return this.GetRandomObject(all2);
			}
			return this._heads[pCharacter];
		}
	}

	// Token: 0x0600041F RID: 1055 RVA: 0x00024DCC File Offset: 0x00022FCC
	private bool ForceChoice(int pValue)
	{
		int num = Singleton<RandomManager>.Instance.Next(1, 100);
		return pValue >= num;
	}

	// Token: 0x06000420 RID: 1056 RVA: 0x00024DCC File Offset: 0x00022FCC
	private bool IsNone(int pValue)
	{
		int num = Singleton<RandomManager>.Instance.Next(1, 100);
		return pValue >= num;
	}

	// Token: 0x0400038D RID: 909
	private ChanceSettings _chanceSettings;

	// Token: 0x0400038E RID: 910
	private List<ECharacter> _availableCharacters = new List<ECharacter>
	{
		ECharacter.GARFIELD,
		ECharacter.HARRY,
		ECharacter.JON,
		ECharacter.ODIE,
		ECharacter.ARLENE,
		ECharacter.NERMAL,
		ECharacter.LIZ,
		ECharacter.SQUEAK
	};

	// Token: 0x0400038F RID: 911
	private ECharacter[] _availableKarts = new ECharacter[]
	{
		ECharacter.GARFIELD,
		ECharacter.HARRY,
		ECharacter.JON,
		ECharacter.ODIE,
		ECharacter.ARLENE,
		ECharacter.NERMAL,
		ECharacter.LIZ,
		ECharacter.SQUEAK
	};

	// Token: 0x04000390 RID: 912
	private Dictionary<ECharacter, List<GameObject>> _kartCustoms = new Dictionary<ECharacter, List<GameObject>>();

	// Token: 0x04000391 RID: 913
	private Dictionary<ECharacter, GameObject> _defaultKartCustoms = new Dictionary<ECharacter, GameObject>();

	// Token: 0x04000392 RID: 914
	private List<GameObject> _allKartCustoms = new List<GameObject>();

	// Token: 0x04000393 RID: 915
	private Dictionary<ECharacter, List<GameObject>> _availableUniqueHats = new Dictionary<ECharacter, List<GameObject>>();

	// Token: 0x04000394 RID: 916
	private Dictionary<ECharacter, List<GameObject>> _availableHats = new Dictionary<ECharacter, List<GameObject>>();

	// Token: 0x04000395 RID: 917
	private Dictionary<ECharacter, GameObject> _heads = new Dictionary<ECharacter, GameObject>();

	// Token: 0x04000396 RID: 918
	private List<GameObject> _allHats = new List<GameObject>();

	// Token: 0x04000397 RID: 919
	public Action<PlayerData, int> OnCreatePlayer;
}

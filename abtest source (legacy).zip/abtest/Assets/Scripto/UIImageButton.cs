﻿using System;
using UnityEngine;

// Token: 0x02000023 RID: 35
[ExecuteInEditMode]
[AddComponentMenu("NGUI/UI/Image Button")]
public class UIImageButton : MonoBehaviour
{
	// Token: 0x1700000C RID: 12
	// (get) Token: 0x060000B4 RID: 180 RVA: 0x0000D48C File Offset: 0x0000B68C
	// (set) Token: 0x060000B5 RID: 181 RVA: 0x00010C48 File Offset: 0x0000EE48
	public bool isEnabled
	{
		get
		{
			Collider collider = base.collider;
			return collider && collider.enabled;
		}
		set
		{
			Collider collider = base.collider;
			if (!collider)
			{
				return;
			}
			if (collider.enabled != value)
			{
				collider.enabled = value;
				this.UpdateImage();
			}
		}
	}

	// Token: 0x060000B6 RID: 182 RVA: 0x00002C0A File Offset: 0x00000E0A
	private void Awake()
	{
		if (this.target == null)
		{
			this.target = base.GetComponentInChildren<UISprite>();
		}
	}

	// Token: 0x060000B7 RID: 183 RVA: 0x00002C29 File Offset: 0x00000E29
	private void OnEnable()
	{
		this.UpdateImage();
	}

	// Token: 0x060000B8 RID: 184 RVA: 0x00010C84 File Offset: 0x0000EE84
	private void UpdateImage()
	{
		if (this.target != null)
		{
			if (this.isEnabled)
			{
				this.target.spriteName = ((!UICamera.IsHighlighted(base.gameObject)) ? this.normalSprite : this.hoverSprite);
			}
			else
			{
				this.target.spriteName = this.disabledSprite;
			}
			this.target.MakePixelPerfect();
		}
	}

	// Token: 0x060000B9 RID: 185 RVA: 0x00010CFC File Offset: 0x0000EEFC
	private void OnHover(bool isOver)
	{
		if (this.isEnabled && this.target != null)
		{
			this.target.spriteName = ((!isOver) ? this.normalSprite : this.hoverSprite);
			this.target.MakePixelPerfect();
		}
	}

	// Token: 0x060000BA RID: 186 RVA: 0x00002C31 File Offset: 0x00000E31
	private void OnPress(bool pressed)
	{
		if (pressed)
		{
			this.target.spriteName = this.pressedSprite;
			this.target.MakePixelPerfect();
		}
		else
		{
			this.UpdateImage();
		}
	}

	// Token: 0x040000CF RID: 207
	public UISprite target;

	// Token: 0x040000D0 RID: 208
	public string normalSprite;

	// Token: 0x040000D1 RID: 209
	public string hoverSprite;

	// Token: 0x040000D2 RID: 210
	public string pressedSprite;

	// Token: 0x040000D3 RID: 211
	public string disabledSprite;
}

﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x020000B8 RID: 184
public class LoadingManager : MonoBehaviour
{
	// Token: 0x060004AD RID: 1197 RVA: 0x000286E0 File Offset: 0x000268E0
	public void Awake()
	{
		Texture2D mainTexture = Resources.Load("ANIM", typeof(Texture2D)) as Texture2D;
		foreach (UISprite uisprite in this.Sprites)
		{
			uisprite.atlas.spriteMaterial.mainTexture = mainTexture;
		}
		UnityEngine.Object.DontDestroyOnLoad(this);
	}

	// Token: 0x170000E3 RID: 227
	// (get) Token: 0x060004AE RID: 1198 RVA: 0x00005669 File Offset: 0x00003869
	public static string SLevelToLoad
	{
		get
		{
			return LoadingManager.m_sLevelToLoad;
		}
	}

	// Token: 0x060004AF RID: 1199 RVA: 0x00028740 File Offset: 0x00026940
	public void Start()
	{
		LoadingManager.m_bLoadingInProgress = true;
		this.m_fElapsedTime = 0f;
		this.m_fEndTime = float.MinValue;
		this.m_pAO = null;
		this.Label.text = string.Empty;
		if (this.Label && LoadingManager.m_sLevelToLoad != "MenuRoot" && Singleton<GameConfigurator>.Instance.ChampionShipData != null)
		{
			this.Label.text = Singleton<GameConfigurator>.Instance.ChampionShipData.TracksName[Singleton<GameConfigurator>.Instance.CurrentTrackIndex];
		}
		LoadingManager.m_oNetworkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
		if (Network.peerType != NetworkPeerType.Disconnected)
		{
			foreach (NetworkPlayer player in Network.connections)
			{
				if (Network.isServer)
				{
					Network.SetReceivingEnabled(player, 0, true);
				}
				Network.isMessageQueueRunning = true;
				Network.SetSendingEnabled(0, true);
			}
		}
		base.StartCoroutine(this.StartLoading());
	}

	// Token: 0x060004B0 RID: 1200 RVA: 0x00028854 File Offset: 0x00026A54
	private IEnumerator StartLoading()
	{
		this.m_pAO = Application.LoadLevelAsync(LoadingManager.m_sLevelToLoad);
		yield return this.m_pAO;
		yield break;
	}

	// Token: 0x060004B1 RID: 1201 RVA: 0x00028870 File Offset: 0x00026A70
	public void OnDestroy()
	{
		foreach (UISprite uisprite in this.Sprites)
		{
			Resources.UnloadAsset(uisprite.atlas.spriteMaterial.mainTexture);
		}
	}

	// Token: 0x060004B2 RID: 1202 RVA: 0x000288B4 File Offset: 0x00026AB4
	public void Update()
	{
		if (LoadingManager.m_bLoadingInProgress)
		{
			this.m_fElapsedTime += Time.deltaTime;
			if (this.m_pAO != null && !Application.isLoadingLevel && this.m_fElapsedTime >= 1f)
			{
				this.m_fEndTime = this.m_fElapsedTime;
				LoadingManager.m_bLoadingInProgress = false;
			}
		}
		else
		{
			this.m_fEndTime += Time.deltaTime;
		}
		if (this.m_fEndTime > this.m_fElapsedTime + 0.2f)
		{
			UnityEngine.Object.DestroyObject(base.gameObject);
			LoadingManager.loadingFinished = true;
		}
	}

	// Token: 0x060004B3 RID: 1203 RVA: 0x00005670 File Offset: 0x00003870
	public static bool IsLoading()
	{
		return LoadingManager.m_bLoadingInProgress;
	}

	// Token: 0x060004B4 RID: 1204 RVA: 0x00028954 File Offset: 0x00026B54
	public static void LoadLevel(string _levelName)
	{
		if (Network.peerType != NetworkPeerType.Disconnected)
		{
			if (Network.isServer)
			{
				LoadingManager.LevelIndex++;
				LoadingManager.m_oNetworkMgr.networkView.RPC("SetLevelIndex", RPCMode.Others, new object[]
				{
					LoadingManager.LevelIndex
				});
			}
			foreach (NetworkPlayer player in Network.connections)
			{
				if (Network.isServer)
				{
					Network.SetReceivingEnabled(player, 0, false);
				}
			}
			Network.SetSendingEnabled(0, false);
			Network.isMessageQueueRunning = false;
			Network.SetLevelPrefix(LoadingManager.LevelIndex);
		}
		LoadingManager.loadingFinished = false;
		Singleton<GameManager>.Instance.Reset();
		LoadingManager.m_sLevelToLoad = _levelName;
		Application.LoadLevel("LoadingScreen");
		Resources.UnloadUnusedAssets();
		GC.Collect();
	}

	// Token: 0x0400046F RID: 1135
	private const float ms_fLoadingMinimumDuration = 1f;

	// Token: 0x04000470 RID: 1136
	private float m_fElapsedTime;

	// Token: 0x04000471 RID: 1137
	private float m_fEndTime;

	// Token: 0x04000472 RID: 1138
	private AsyncOperation m_pAO;

	// Token: 0x04000473 RID: 1139
	private static bool m_bLoadingInProgress;

	// Token: 0x04000474 RID: 1140
	public static bool loadingFinished;

	// Token: 0x04000475 RID: 1141
	private static string m_sLevelToLoad = string.Empty;

	// Token: 0x04000476 RID: 1142
	public static int LevelIndex;

	// Token: 0x04000477 RID: 1143
	private static NetworkMgr m_oNetworkMgr;

	// Token: 0x04000478 RID: 1144
	public UILabel Label;

	// Token: 0x04000479 RID: 1145
	public UISprite[] Sprites;
}

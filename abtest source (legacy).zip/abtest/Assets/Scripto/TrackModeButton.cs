﻿using System;
using UnityEngine;

// Token: 0x020001C2 RID: 450
public class TrackModeButton : MonoBehaviour
{
	// Token: 0x06000C0E RID: 3086 RVA: 0x0000A5EC File Offset: 0x000087EC
	private void OnClick()
	{
		if (this.PanelToHide != null)
		{
			this.PanelToHide.SetActive(false);
		}
		if (this.PanelToShow != null)
		{
			this.PanelToShow.SetActive(true);
		}
	}

	// Token: 0x04000BEB RID: 3051
	public GameObject PanelToHide;

	// Token: 0x04000BEC RID: 3052
	public GameObject PanelToShow;
}

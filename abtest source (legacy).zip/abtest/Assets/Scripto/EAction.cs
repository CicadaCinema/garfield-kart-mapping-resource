﻿using System;

// Token: 0x02000236 RID: 566
public enum EAction
{
	// Token: 0x04000F53 RID: 3923
	Accelerate,
	// Token: 0x04000F54 RID: 3924
	Steer,
	// Token: 0x04000F55 RID: 3925
	Drift,
	// Token: 0x04000F56 RID: 3926
	DriftJump,
	// Token: 0x04000F57 RID: 3927
	LaunchBonus,
	// Token: 0x04000F58 RID: 3928
	DropBonus,
	// Token: 0x04000F59 RID: 3929
	Respawn,
	// Token: 0x04000F5A RID: 3930
	Pause
}

﻿using System;

// Token: 0x0200015F RID: 351
public enum E_TimeTrialMedal
{
	// Token: 0x040009CA RID: 2506
	None,
	// Token: 0x040009CB RID: 2507
	Bronze,
	// Token: 0x040009CC RID: 2508
	Silver,
	// Token: 0x040009CD RID: 2509
	Gold,
	// Token: 0x040009CE RID: 2510
	Platinium
}

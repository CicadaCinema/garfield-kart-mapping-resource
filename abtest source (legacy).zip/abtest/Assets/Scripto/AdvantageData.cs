﻿using System;

// Token: 0x020000F4 RID: 244
public class AdvantageData : IconCarac
{
	// Token: 0x060006AB RID: 1707 RVA: 0x00034164 File Offset: 0x00032364
	public static int Compare(AdvantageData oItem1, AdvantageData oItem2)
	{
		int num = AdvantageData.CompareState(oItem1, oItem2);
		if (num == 0)
		{
			num = IconCarac.CompareName(oItem1, oItem2);
		}
		return num;
	}

	// Token: 0x060006AC RID: 1708 RVA: 0x00034188 File Offset: 0x00032388
	private static int CompareState(AdvantageData oItem1, AdvantageData oItem2)
	{
		GameSaveManager instance = Singleton<GameSaveManager>.Instance;
		return IconCarac.SuppressNewState(instance.GetAdvantageState(oItem2.AdvantageType)) - IconCarac.SuppressNewState(instance.GetAdvantageState(oItem1.AdvantageType));
	}

	// Token: 0x0400068F RID: 1679
	public EAdvantage AdvantageType;

	// Token: 0x04000690 RID: 1680
	public E_UnlockableItemSate State;

	// Token: 0x04000691 RID: 1681
	public int Price;

	// Token: 0x04000692 RID: 1682
	public bool bIsAvailableInSingle;

	// Token: 0x04000693 RID: 1683
	public bool bIsAvailableInChampionship;

	// Token: 0x04000694 RID: 1684
	public bool bIsAvailableInMulti;
}

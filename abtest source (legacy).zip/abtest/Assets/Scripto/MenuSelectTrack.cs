﻿using System;
using UnityEngine;

// Token: 0x020001B4 RID: 436
public class MenuSelectTrack : AbstractMenu
{
	// Token: 0x06000BBB RID: 3003 RVA: 0x0000A1FE File Offset: 0x000083FE
	public override void Start()
	{
		this.m_iCurrentTrack = 0;
	}

	// Token: 0x06000BBC RID: 3004 RVA: 0x000503D0 File Offset: 0x0004E5D0
	public override void OnEnter()
	{
		base.OnEnter();
		Singleton<GameConfigurator>.Instance.StartScene = Singleton<GameConfigurator>.Instance.ChampionShipData.Tracks[0];
		this.ChampionshipIcon.ChangeTexture(Singleton<GameConfigurator>.Instance.ChampionShipData.Index);
		this.LabelCup.text = Singleton<GameConfigurator>.Instance.ChampionShipData.ChampionShipName;
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
		{
			this.GameModeIcon.ChangeTexture(0);
			this.Description.text = string.Format(Localization.instance.Get("MENU_SELECT_TRACK_CHAMPIONSHIP"), Singleton<GameConfigurator>.Instance.ChampionShipData.ChampionShipName);
			this.TrackName.text = Singleton<GameConfigurator>.Instance.ChampionShipData.ChampionShipName;
			this.TimeTrialPanel.SetActive(false);
			this.ChampionshipPanel.SetActive(true);
		}
		else if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.SINGLE)
		{
			this.GameModeIcon.ChangeTexture(1);
			this.Description.text = Localization.instance.Get("MENU_SELECT_TRACK_SINGLE");
			this.TimeTrialPanel.SetActive(false);
			this.ChampionshipPanel.SetActive(true);
		}
		else if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
		{
			this.GameModeIcon.ChangeTexture(2);
			this.Description.text = Localization.instance.Get("MENU_SELECT_TRACK_TIMETRIAL");
			this.ChampionshipPanel.SetActive(false);
			this.TimeTrialPanel.SetActive(true);
		}
		this.DifficultyIcon.ChangeTexture((int)Singleton<GameConfigurator>.Instance.Difficulty);
		this.RefreshPanel();
		this.m_bLateInitialized = false;
	}

	// Token: 0x06000BBD RID: 3005 RVA: 0x0000A207 File Offset: 0x00008407
	public override void OnExit()
	{
		base.OnExit();
		this.DefaultButton.isChecked = true;
		Resources.UnloadAsset(this.TrackScreenshot.mainTexture);
	}

	// Token: 0x06000BBE RID: 3006 RVA: 0x00050578 File Offset: 0x0004E778
	public void LateUpdate()
	{
		if (!this.m_bLateInitialized)
		{
			if (this.ButtonSelectTrack[Singleton<GameConfigurator>.Instance.CurrentTrackIndex])
			{
				this.ButtonSelectTrack[Singleton<GameConfigurator>.Instance.CurrentTrackIndex].SendMessage("OnClick");
			}
			this.m_bLateInitialized = true;
		}
	}

	// Token: 0x06000BBF RID: 3007 RVA: 0x0000A22B File Offset: 0x0000842B
	public override void Update()
	{
		if (Application.platform == RuntimePlatform.Android && Input.GetKeyDown(KeyCode.Escape))
		{
			this.ActSwapMenu(EMenus.MENU_CHAMPIONSHIP);
		}
	}

	// Token: 0x06000BC0 RID: 3008 RVA: 0x000505D0 File Offset: 0x0004E7D0
	public void OnSelectTrack(int iTrack)
	{
		this.m_iCurrentTrack = iTrack;
		this.RefreshPanel();
		if (Singleton<GameConfigurator>.Instance.GameModeType != E_GameModeType.CHAMPIONSHIP)
		{
			Singleton<GameConfigurator>.Instance.StartScene = Singleton<GameConfigurator>.Instance.ChampionShipData.Tracks[this.m_iCurrentTrack];
			Singleton<GameConfigurator>.Instance.CurrentTrackIndex = iTrack;
		}
	}

	// Token: 0x06000BC1 RID: 3009 RVA: 0x00050628 File Offset: 0x0004E828
	public void RefreshPanel()
	{
		string text = Singleton<GameConfigurator>.Instance.ChampionShipData.Tracks[this.m_iCurrentTrack];
		this.TrackName.text = Singleton<GameConfigurator>.Instance.ChampionShipData.TracksName[this.m_iCurrentTrack];
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
		{
			int num = 0;
			Singleton<GameSaveManager>.Instance.GetTimeTrialRecord(text, ref num);
			string text2 = TimeSpan.FromMilliseconds((double)num).FormatRaceTime();
			this.TimeTrialTimeRef.text = text2;
			E_TimeTrialMedal medal = Singleton<GameSaveManager>.Instance.GetMedal(text, false);
			if (medal != E_TimeTrialMedal.None)
			{
				this.MedalSprite.gameObject.SetActive(true);
				this.MedalSprite.ChangeTexture(medal - E_TimeTrialMedal.Bronze);
			}
			else
			{
				this.MedalSprite.gameObject.SetActive(false);
			}
		}
		else
		{
			this.PuzzlePiece1.ChangeTexture((!Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(text + "_0")) ? 0 : 1);
			this.PuzzlePiece2.ChangeTexture((!Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(text + "_1")) ? 0 : 1);
			this.PuzzlePiece3.ChangeTexture((!Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(text + "_2")) ? 0 : 1);
		}
		if (this.TrackScreenshot != null)
		{
			Resources.UnloadAsset(this.TrackScreenshot.mainTexture);
			this.TrackScreenshot.mainTexture = (Resources.Load(text, typeof(Texture2D)) as Texture2D);
		}
	}

	// Token: 0x06000BC2 RID: 3010 RVA: 0x000507B8 File Offset: 0x0004E9B8
	public override void ActSwapMenu(EMenus NextMenu)
	{
		if (ASE_Tools.Available && NextMenu == EMenus.MENU_SELECT_KART)
		{
			ASE_Flurry.LogEvent("1J_SELECTION", new string[]
			{
				"DIFFICULTY",
				"CUP"
			}, new string[]
			{
				Singleton<GameConfigurator>.Instance.Difficulty.ToString(),
				Singleton<GameConfigurator>.Instance.ChampionShipData.ChampionShipName
			});
		}
		base.ActSwapMenu(NextMenu);
	}

	// Token: 0x04000B95 RID: 2965
	private int m_iCurrentTrack;

	// Token: 0x04000B96 RID: 2966
	public UILabel TrackName;

	// Token: 0x04000B97 RID: 2967
	public UICheckbox DefaultButton;

	// Token: 0x04000B98 RID: 2968
	public UITexturePattern ChampionshipIcon;

	// Token: 0x04000B99 RID: 2969
	public UITexturePattern GameModeIcon;

	// Token: 0x04000B9A RID: 2970
	public UITexturePattern DifficultyIcon;

	// Token: 0x04000B9B RID: 2971
	public UILabel LabelCup;

	// Token: 0x04000B9C RID: 2972
	public GameObject TimeTrialPanel;

	// Token: 0x04000B9D RID: 2973
	public GameObject ChampionshipPanel;

	// Token: 0x04000B9E RID: 2974
	public UILabel Description;

	// Token: 0x04000B9F RID: 2975
	public UILabel TimeTrialTimeRef;

	// Token: 0x04000BA0 RID: 2976
	public UITexturePattern MedalSprite;

	// Token: 0x04000BA1 RID: 2977
	public UITexturePattern PuzzlePiece1;

	// Token: 0x04000BA2 RID: 2978
	public UITexturePattern PuzzlePiece2;

	// Token: 0x04000BA3 RID: 2979
	public UITexturePattern PuzzlePiece3;

	// Token: 0x04000BA4 RID: 2980
	public UITexture TrackScreenshot;

	// Token: 0x04000BA5 RID: 2981
	public MessageButton[] ButtonSelectTrack = new MessageButton[4];

	// Token: 0x04000BA6 RID: 2982
	private bool m_bLateInitialized;
}

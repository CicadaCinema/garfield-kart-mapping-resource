﻿using System;
using UnityEngine;

// Token: 0x0200021E RID: 542
public class RcVehicleRaceStats : MonoBehaviour
{
	// Token: 0x06000F02 RID: 3842 RVA: 0x0005E664 File Offset: 0x0005C864
	public RcVehicleRaceStats()
	{
		this.m_pVehicle = null;
		this.m_iRank = 0;
		this.m_bReverse = false;
		this.m_iNbLapCompleted = 0;
		this.m_iLogicNbLap = 0;
		this.m_iLapStartTimeMs = 0;
		this.m_iRaceTimeMs = -1;
		this.m_iIdxLastLapTimeMs = -1;
		this.m_iBestLapTimeMs = 599990;
		this.m_iNbCheckPointValidated = 0;
		this.m_bRaceEnded = false;
		this.m_fDistToEndOfLap = 0f;
		this.m_fDistToEndOfRace = 0f;
		this.m_iRaceNbLap = 0;
		this.m_iRaceNbCheckPoints = 0;
		this.m_GuidePosition = MultiPathPosition.UNDEFINED_MP_POS;
		this.m_pPrecedingVehicle = null;
		this.m_pPursuantVehicle = null;
		this.m_bDebugDraw = false;
		this.m_LapTimeMs = new int[16];
		this.m_CheckPointTimeMs = new int[16];
		this.m_pRace = null;
		for (int i = 0; i < 16; i++)
		{
			this.m_LapTimeMs[i] = 0;
		}
		for (int j = 0; j < 16; j++)
		{
			this.m_CheckPointTimeMs[j] = 0;
		}
	}

	// Token: 0x06000F03 RID: 3843 RVA: 0x0000C52F File Offset: 0x0000A72F
	public int GetRank()
	{
		return this.m_iRank;
	}

	// Token: 0x06000F04 RID: 3844 RVA: 0x0000C537 File Offset: 0x0000A737
	public int GetBestLapTime()
	{
		return this.m_iBestLapTimeMs;
	}

	// Token: 0x06000F05 RID: 3845 RVA: 0x0000C53F File Offset: 0x0000A73F
	public void SetBestLapTime(int _iValue)
	{
		this.m_iBestLapTimeMs = _iValue;
	}

	// Token: 0x06000F06 RID: 3846 RVA: 0x0000C548 File Offset: 0x0000A748
	public bool IsReverse()
	{
		return this.m_bReverse;
	}

	// Token: 0x06000F07 RID: 3847 RVA: 0x0000C550 File Offset: 0x0000A750
	public int GetRaceTime()
	{
		return (this.m_iRaceTimeMs < 0) ? 0 : this.m_iRaceTimeMs;
	}

	// Token: 0x06000F08 RID: 3848 RVA: 0x0000C56A File Offset: 0x0000A76A
	public int GetCurrentLapTime()
	{
		return (this.m_iCurrentLapTime < 0) ? 0 : this.m_iCurrentLapTime;
	}

	// Token: 0x06000F09 RID: 3849 RVA: 0x0000C584 File Offset: 0x0000A784
	public int GetCurrentDiffTime()
	{
		return this.m_iCurrentDiffTime;
	}

	// Token: 0x06000F0A RID: 3850 RVA: 0x0000C58C File Offset: 0x0000A78C
	public void SetCurrentDiffTime(int _iValue)
	{
		this.m_iCurrentDiffTime = _iValue;
	}

	// Token: 0x06000F0B RID: 3851 RVA: 0x0000C595 File Offset: 0x0000A795
	public int GetLastLapTime()
	{
		return (this.m_iIdxLastLapTimeMs >= 0) ? this.m_LapTimeMs[this.m_iIdxLastLapTimeMs] : 0;
	}

	// Token: 0x06000F0C RID: 3852 RVA: 0x0000C5B6 File Offset: 0x0000A7B6
	public int GetLapTime(int _Idx)
	{
		return (_Idx <= this.m_iIdxLastLapTimeMs && this.m_iIdxLastLapTimeMs >= 0) ? this.m_LapTimeMs[_Idx] : 0;
	}

	// Token: 0x06000F0D RID: 3853 RVA: 0x0000C5DE File Offset: 0x0000A7DE
	public int GetCheckPointTime(int _Idx)
	{
		return (_Idx <= this.m_iNbCheckPointValidated && _Idx >= 0) ? this.m_CheckPointTimeMs[_Idx] : 0;
	}

	// Token: 0x06000F0E RID: 3854 RVA: 0x0000C601 File Offset: 0x0000A801
	public int GetNbLapCompleted()
	{
		return this.m_iNbLapCompleted;
	}

	// Token: 0x06000F0F RID: 3855 RVA: 0x0000C609 File Offset: 0x0000A809
	public int GetLogicNbLap()
	{
		return this.m_iLogicNbLap;
	}

	// Token: 0x06000F10 RID: 3856 RVA: 0x0000C611 File Offset: 0x0000A811
	public float GetDistToEndOfLap()
	{
		return this.m_fDistToEndOfLap;
	}

	// Token: 0x06000F11 RID: 3857 RVA: 0x0000C619 File Offset: 0x0000A819
	public float GetDistToEndOfRace()
	{
		return this.m_fDistToEndOfRace;
	}

	// Token: 0x06000F12 RID: 3858 RVA: 0x0000C621 File Offset: 0x0000A821
	public bool IsRaceEnded()
	{
		return this.m_bRaceEnded;
	}

	// Token: 0x06000F13 RID: 3859 RVA: 0x0000C629 File Offset: 0x0000A829
	public MultiPathPosition GetGuidePosition()
	{
		return this.m_GuidePosition;
	}

	// Token: 0x06000F14 RID: 3860 RVA: 0x0000C631 File Offset: 0x0000A831
	public void SetRank(int _Pos)
	{
		this.m_iRank = _Pos;
	}

	// Token: 0x06000F15 RID: 3861 RVA: 0x0000C63A File Offset: 0x0000A83A
	public void SetReverse(bool _bIsReverse)
	{
		this.m_bReverse = _bIsReverse;
	}

	// Token: 0x06000F16 RID: 3862 RVA: 0x0000C643 File Offset: 0x0000A843
	public void SetDistToEndOfLap(float _dist)
	{
		this.m_fDistToEndOfLap = _dist;
	}

	// Token: 0x06000F17 RID: 3863 RVA: 0x0000C64C File Offset: 0x0000A84C
	public void SetDistToEndOfRace(float _dist)
	{
		this.m_fDistToEndOfRace = _dist;
	}

	// Token: 0x06000F18 RID: 3864 RVA: 0x0000C655 File Offset: 0x0000A855
	public void SetPreceding(RcVehicle pPrecedingPlayer)
	{
		this.m_pPrecedingVehicle = pPrecedingPlayer;
	}

	// Token: 0x06000F19 RID: 3865 RVA: 0x0000C65E File Offset: 0x0000A85E
	public void SetPursuant(RcVehicle pPursuantPlayer)
	{
		this.m_pPursuantVehicle = pPursuantPlayer;
	}

	// Token: 0x06000F1A RID: 3866 RVA: 0x0000C667 File Offset: 0x0000A867
	public RcVehicle GetVehicle()
	{
		return this.m_pVehicle;
	}

	// Token: 0x06000F1B RID: 3867 RVA: 0x0000C66F File Offset: 0x0000A86F
	public RcVehicle GetPreceding()
	{
		return this.m_pPrecedingVehicle;
	}

	// Token: 0x06000F1C RID: 3868 RVA: 0x0000C677 File Offset: 0x0000A877
	public RcVehicle GetPursuant()
	{
		return this.m_pPursuantVehicle;
	}

	// Token: 0x06000F1D RID: 3869 RVA: 0x0000C67F File Offset: 0x0000A87F
	public int GetNbCheckPointValidated()
	{
		return this.m_iNbCheckPointValidated;
	}

	// Token: 0x06000F1E RID: 3870 RVA: 0x0000C687 File Offset: 0x0000A887
	public void SetRaceNbLap(int _NbLaps)
	{
		this.m_iRaceNbLap = _NbLaps;
	}

	// Token: 0x06000F1F RID: 3871 RVA: 0x0000C690 File Offset: 0x0000A890
	public void SetRaceNbCheckPoints(int _NbCheckpoints)
	{
		this.m_iRaceNbCheckPoints = _NbCheckpoints;
		this.m_iNbCheckPointValidated = this.m_iRaceNbCheckPoints;
	}

	// Token: 0x06000F20 RID: 3872 RVA: 0x0000C6A5 File Offset: 0x0000A8A5
	public int GetRaceNbLap()
	{
		return this.m_iRaceNbLap;
	}

	// Token: 0x06000F21 RID: 3873 RVA: 0x0000C6AD File Offset: 0x0000A8AD
	public void SetDebugDraw(bool bDebugDraw)
	{
		this.m_bDebugDraw = bDebugDraw;
	}

	// Token: 0x06000F22 RID: 3874 RVA: 0x0000C6B6 File Offset: 0x0000A8B6
	public void Awake()
	{
		this.m_pVehicle = base.transform.parent.GetComponentInChildren<RcVehicle>();
		if (this.m_pVehicle != null)
		{
			this.m_pVehicle.RaceStats = this;
		}
	}

	// Token: 0x06000F23 RID: 3875 RVA: 0x0005E76C File Offset: 0x0005C96C
	public void Start()
	{
		this.Reset();
		this.m_pRace = (UnityEngine.Object.FindObjectOfType(typeof(RcRace)) as RcRace);
		if (this.m_pRace != null)
		{
			this.m_pRace.AddVehicle(this);
		}
		this.m_bDebugDraw = (this.m_pVehicle.GetControlType() == RcVehicle.ControlType.Human);
	}

	// Token: 0x06000F24 RID: 3876 RVA: 0x0005E7CC File Offset: 0x0005C9CC
	public void Update()
	{
		MultiPathPosition guidePosition = this.GetGuidePosition();
		if (guidePosition.pathPosition.index != -1)
		{
			RcFastPath simplePath = guidePosition.section.GetSimplePath();
			int pInd = (guidePosition.pathPosition.index + 1) % simplePath.GetNbPoints();
			Vector3 lhs = simplePath.GetPositionPoint(pInd) - simplePath.GetPositionPoint(guidePosition.pathPosition.index);
			lhs.Normalize();
			Vector3 rhs = base.transform.rotation * Vector3.forward;
			float num = Vector3.Dot(lhs, rhs);
			num = Mathf.Clamp(num, -1f, 1f);
			if (num < 0f)
			{
				float num2 = Mathf.Acos(num);
				if (num2 > 1.57079637f)
				{
					this.SetReverse(true);
				}
				else
				{
					this.SetReverse(false);
				}
			}
			else
			{
				this.SetReverse(false);
			}
		}
	}

	// Token: 0x06000F25 RID: 3877 RVA: 0x0005E8B0 File Offset: 0x0005CAB0
	public void Reset()
	{
		this.m_GuidePosition = MultiPathPosition.UNDEFINED_MP_POS;
		this.m_iRank = 0;
		this.m_bReverse = false;
		this.m_iNbLapCompleted = 0;
		this.m_iLogicNbLap = 0;
		this.m_iLapStartTimeMs = 0;
		this.m_iRaceTimeMs = -1;
		this.m_iIdxLastLapTimeMs = -1;
		this.m_iBestLapTimeMs = int.MaxValue;
		this.m_iCurrentDiffTime = 0;
		this.m_iNbCheckPointValidated = this.m_iRaceNbCheckPoints;
		this.m_bRaceEnded = false;
		for (int i = 0; i < 16; i++)
		{
			this.m_LapTimeMs[i] = 0;
		}
		for (int j = 0; j < 16; j++)
		{
			this.m_CheckPointTimeMs[j] = 0;
		}
	}

	// Token: 0x06000F26 RID: 3878 RVA: 0x0000C6EB File Offset: 0x0000A8EB
	public void RefreshTime(int _gameTime)
	{
		if (!this.m_bRaceEnded)
		{
			if (this.m_iRaceTimeMs >= 0)
			{
				this.m_iRaceTimeMs = _gameTime;
			}
			this.m_iCurrentLapTime = this.m_iRaceTimeMs - this.m_iLapStartTimeMs;
		}
	}

	// Token: 0x06000F27 RID: 3879 RVA: 0x0005E958 File Offset: 0x0005CB58
	public void CrossEndLine(int _gameTime)
	{
		if (this.m_bRaceEnded)
		{
			return;
		}
		bool flag = false;
		if (this.m_iNbCheckPointValidated == this.m_iRaceNbCheckPoints)
		{
			this.m_iLogicNbLap++;
			this.m_CheckPointTimeMs[0] = this.m_iCurrentLapTime;
			this.m_iNbCheckPointValidated = 0;
		}
		if (this.m_iNbLapCompleted != 0)
		{
			return;
		}
		if (this.m_iNbLapCompleted <= this.m_iRaceNbLap && this.m_iNbLapCompleted < this.m_iLogicNbLap)
		{
			if (this.m_iNbLapCompleted < this.m_iRaceNbLap)
			{
				this.m_iNbLapCompleted++;
			}
			flag = true;
		}
		if (!this.CanCompleteLap)
		{
			this.m_iNbLapCompleted = 0;
			this.m_iLogicNbLap = 0;
		}
		bool flag2 = false;
		if (!this.m_bRaceEnded)
		{
			this.m_bRaceEnded = true;
			flag2 = true;
		}
		if (this.m_iRaceTimeMs >= 0 && this.m_iLogicNbLap > 1 && flag)
		{
			this.m_LapTimeMs[++this.m_iIdxLastLapTimeMs] = this.m_iCurrentLapTime;
			int iCurrentLapTime = this.m_iCurrentLapTime;
			if (!this.m_bRaceEnded)
			{
				this.m_iCurrentLapTime = 0;
			}
			if (iCurrentLapTime != 0 && iCurrentLapTime < this.m_iBestLapTimeMs)
			{
				this.m_iBestLapTimeMs = iCurrentLapTime;
			}
			this.m_iLapStartTimeMs = _gameTime;
			if (this.m_pVehicle.OnLapEnded != null)
			{
				this.m_pVehicle.OnLapEnded();
			}
		}
		if (flag2)
		{
			if (this.m_pVehicle.OnRaceEnded != null)
			{
				this.m_pVehicle.OnRaceEnded(this.m_pVehicle);
			}
			this.m_pVehicle.SetRaceEnded(true);
		}
	}

	// Token: 0x06000F28 RID: 3880 RVA: 0x0005EAF4 File Offset: 0x0005CCF4
	public void CrossStartLine(int _gameTime, bool _bReverse)
	{
		if (this.m_bRaceEnded)
		{
			if (this.m_pVehicle.OnLapEndedAfterRace != null)
			{
				this.m_pVehicle.OnLapEndedAfterRace();
			}
			return;
		}
		bool flag = false;
		if (_bReverse)
		{
			this.m_iLogicNbLap--;
			this.m_iNbCheckPointValidated = this.m_iRaceNbCheckPoints;
		}
		else if (this.m_iNbCheckPointValidated == this.m_iRaceNbCheckPoints)
		{
			this.m_iLogicNbLap++;
			this.m_CheckPointTimeMs[0] = this.m_iCurrentLapTime;
			this.m_iNbCheckPointValidated = 0;
		}
		if (this.m_pVehicle.OnCheckpointsReseted != null)
		{
			this.m_pVehicle.OnCheckpointsReseted();
		}
		if (this.m_iNbLapCompleted <= this.m_iRaceNbLap && this.m_iNbLapCompleted < this.m_iLogicNbLap)
		{
			if (this.m_iNbLapCompleted < this.m_iRaceNbLap)
			{
				this.m_iNbLapCompleted++;
			}
			flag = true;
		}
		if (!this.CanCompleteLap)
		{
			this.m_iNbLapCompleted = 0;
			this.m_iLogicNbLap = 0;
		}
		bool flag2 = false;
		if (this.m_iLogicNbLap >= this.m_iRaceNbLap + 1 && !this.m_bRaceEnded)
		{
			this.RefreshTime(_gameTime);
			this.m_bRaceEnded = true;
			flag2 = true;
		}
		if (this.m_iRaceTimeMs >= 0 && flag)
		{
			if (this.m_iLogicNbLap > 1)
			{
				this.m_LapTimeMs[++this.m_iIdxLastLapTimeMs] = this.m_iCurrentLapTime;
				int iCurrentLapTime = this.m_iCurrentLapTime;
				if (!this.m_bRaceEnded)
				{
					this.m_iCurrentLapTime = 0;
				}
				if (iCurrentLapTime != 0 && iCurrentLapTime < this.m_iBestLapTimeMs)
				{
					this.m_iBestLapTimeMs = iCurrentLapTime;
				}
				this.m_iLapStartTimeMs = _gameTime;
				if (this.m_pVehicle.OnLapEnded != null)
				{
					this.m_pVehicle.OnLapEnded();
				}
				if (this.m_pVehicle.OnLapEnded != null)
				{
					this.m_pVehicle.OnLapEnded();
				}
			}
			else if (this.m_iLogicNbLap == 0 && this.m_pVehicle.OnFirstLapStarted != null)
			{
				this.m_pVehicle.OnFirstLapStarted();
			}
		}
		if (flag2)
		{
			if (this.m_pVehicle.OnRaceEnded != null)
			{
				this.m_pVehicle.OnRaceEnded(this.m_pVehicle);
			}
			this.m_pVehicle.SetRaceEnded(true);
		}
	}

	// Token: 0x06000F29 RID: 3881 RVA: 0x0005ED54 File Offset: 0x0005CF54
	public void StartChrono()
	{
		if (this.m_iRaceTimeMs < 0)
		{
			this.m_iRaceTimeMs = 0;
			this.m_iLapStartTimeMs = 0;
		}
		this.m_iCurrentLapTime = 0;
		if (this.m_pVehicle.OnRaceStated != null)
		{
			this.m_pVehicle.OnRaceStated();
		}
	}

	// Token: 0x06000F2A RID: 3882 RVA: 0x0005EDA4 File Offset: 0x0005CFA4
	public void CrossCheckPoint(int _Cross)
	{
		if (_Cross == this.m_iNbCheckPointValidated)
		{
			this.m_CheckPointTimeMs[this.m_iNbCheckPointValidated] = this.m_iCurrentLapTime;
			this.m_iNbCheckPointValidated++;
			RcEventCheckPoint rcEventCheckPoint;
			rcEventCheckPoint.m_pVehicle = this.m_pVehicle;
			rcEventCheckPoint.m_iCheckpointIdx = _Cross;
			rcEventCheckPoint.m_iCheckpointTime = this.m_iCurrentLapTime;
			if (this.m_pVehicle.OnCheckpointValidated != null)
			{
				this.m_pVehicle.OnCheckpointValidated();
			}
		}
	}

	// Token: 0x06000F2B RID: 3883 RVA: 0x0000C71E File Offset: 0x0000A91E
	public void Respawn()
	{
		this.m_GuidePosition = MultiPathPosition.UNDEFINED_MP_POS;
	}

	// Token: 0x06000F2C RID: 3884 RVA: 0x0005EE20 File Offset: 0x0005D020
	public int ForceEndRace(int _OverallWorstLap, int _WorstRace)
	{
		this.m_bRaceEnded = true;
		int num = 0;
		this.m_iRaceTimeMs = 0;
		int num2 = 10;
		int num3 = num2 + this.GetRank();
		int num4 = _OverallWorstLap * num3 / num2;
		for (int i = 0; i < this.m_iNbLapCompleted; i++)
		{
			if (this.m_LapTimeMs[i] > num)
			{
				num = this.m_LapTimeMs[i];
			}
		}
		float length = this.m_GuidePosition.section.GetLength();
		float num5 = length - this.m_GuidePosition.section.GetDistToEndLine();
		int num6 = (int)((float)this.m_iCurrentLapTime * (length / num5));
		if (num < num6)
		{
			num = num6;
		}
		if (num == 0)
		{
			num = num4;
		}
		for (int i = 0; i < this.m_iRaceNbLap; i++)
		{
			if (this.m_LapTimeMs[i] == 0)
			{
				this.m_LapTimeMs[i] = num;
			}
			this.m_iRaceTimeMs += this.m_LapTimeMs[i];
			if (i == this.m_iRaceNbLap - 1 && this.m_iRaceTimeMs <= _WorstRace)
			{
				int num7 = _WorstRace - this.m_iRaceTimeMs;
				num7 += 500 + (int)(UnityEngine.Random.value * 1000f);
				this.m_LapTimeMs[i] += num7;
				this.m_iRaceTimeMs += num7;
			}
		}
		return this.m_iRaceTimeMs;
	}

	// Token: 0x06000F2D RID: 3885 RVA: 0x0005EF70 File Offset: 0x0005D170
	public int GetWorstLap()
	{
		int num = 0;
		for (int i = 0; i < this.m_iRaceNbLap; i++)
		{
			if (this.m_LapTimeMs[i] > num)
			{
				num = this.m_LapTimeMs[i];
			}
		}
		return num;
	}

	// Token: 0x06000F2E RID: 3886 RVA: 0x0000C72B File Offset: 0x0000A92B
	public void Stop()
	{
		if (this.m_pRace != null)
		{
			this.m_pRace.RemoveVehicle(this);
		}
	}

	// Token: 0x06000F2F RID: 3887 RVA: 0x0000C74A File Offset: 0x0000A94A
	public void ForceRefreshRespawn()
	{
		if (this.m_pRace != null)
		{
			this.m_pRace.ForceRefreshRespawn(this);
		}
	}

	// Token: 0x04000E87 RID: 3719
	private const int MAX_LAP = 16;

	// Token: 0x04000E88 RID: 3720
	private const int MAX_CHECKPOINTS = 16;

	// Token: 0x04000E89 RID: 3721
	public bool CanCompleteLap = true;

	// Token: 0x04000E8A RID: 3722
	protected int m_iRank;

	// Token: 0x04000E8B RID: 3723
	protected bool m_bReverse;

	// Token: 0x04000E8C RID: 3724
	protected int m_iNbLapCompleted;

	// Token: 0x04000E8D RID: 3725
	protected int m_iLogicNbLap;

	// Token: 0x04000E8E RID: 3726
	protected int m_iRaceTimeMs;

	// Token: 0x04000E8F RID: 3727
	protected int m_iLapStartTimeMs;

	// Token: 0x04000E90 RID: 3728
	protected int m_iCurrentLapTime;

	// Token: 0x04000E91 RID: 3729
	protected int m_iCurrentDiffTime;

	// Token: 0x04000E92 RID: 3730
	protected int[] m_LapTimeMs;

	// Token: 0x04000E93 RID: 3731
	protected int m_iIdxLastLapTimeMs;

	// Token: 0x04000E94 RID: 3732
	protected int[] m_CheckPointTimeMs;

	// Token: 0x04000E95 RID: 3733
	protected float m_fDistToEndOfLap;

	// Token: 0x04000E96 RID: 3734
	protected float m_fDistToEndOfRace;

	// Token: 0x04000E97 RID: 3735
	protected int m_iRaceNbLap;

	// Token: 0x04000E98 RID: 3736
	protected int m_iRaceNbCheckPoints;

	// Token: 0x04000E99 RID: 3737
	protected int m_iBestLapTimeMs;

	// Token: 0x04000E9A RID: 3738
	protected int m_iNbCheckPointValidated;

	// Token: 0x04000E9B RID: 3739
	protected bool m_bRaceEnded;

	// Token: 0x04000E9C RID: 3740
	public MultiPathPosition m_GuidePosition;

	// Token: 0x04000E9D RID: 3741
	protected RcVehicle m_pVehicle;

	// Token: 0x04000E9E RID: 3742
	protected RcVehicle m_pPrecedingVehicle;

	// Token: 0x04000E9F RID: 3743
	protected RcVehicle m_pPursuantVehicle;

	// Token: 0x04000EA0 RID: 3744
	protected bool m_bDebugDraw;

	// Token: 0x04000EA1 RID: 3745
	protected RcRace m_pRace;
}

﻿using System;

// Token: 0x0200025A RID: 602
[Serializable]
public class Tuple<T1, T2, T3, T4, T5, T6> : Tuple<T1, T2, T3, T4, T5>
{
	// Token: 0x06001082 RID: 4226 RVA: 0x00067894 File Offset: 0x00065A94
	public Tuple() : this(default(T1), default(T2), default(T3), default(T4), default(T5), default(T6))
	{
	}

	// Token: 0x06001083 RID: 4227 RVA: 0x0000D1C0 File Offset: 0x0000B3C0
	public Tuple(T1 pItem1, T2 pItem2, T3 pItem3, T4 pItem4, T5 pItem5, T6 pItem6) : base(pItem1, pItem2, pItem3, pItem4, pItem5)
	{
		this.Item6 = pItem6;
	}

	// Token: 0x04000FBF RID: 4031
	public T6 Item6;
}

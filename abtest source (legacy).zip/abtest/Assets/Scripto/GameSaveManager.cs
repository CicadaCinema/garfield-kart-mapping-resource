﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200012F RID: 303
public class GameSaveManager : Singleton<GameSaveManager>
{
	// Token: 0x0600084D RID: 2125 RVA: 0x0003D708 File Offset: 0x0003B908
	public void Init()
	{
		this.Load(out this._coins, out this._collectedCoins, out this._comicStrips, out this._puzzlePieces, out this._timeTrialRecords, out this._hats, out this._customs, out this._championShipsRecords, out this._characters, out this._karts, out this._championsShips, out this._timeTrialInfos, out this._advantagesQuantity, out this._advantages, out this._timeTrialMedals, out this._timeTrialBestTimes, out this._challenge, out this._pseudo, out this._gameSave, out this._playerConfig, out this._showTuto, out this._firstTime, out this._askRating, out this._askSharing);
		this.Save();
		this.CheckEasyChampionShipStar(false);
		this.CheckNormalChampionShipStar(false);
		this.CheckHardChampionShipStar(false);
		this.CheckTimeTrialStar(false);
		this.CheckEndStar(false);
	}

	// Token: 0x0600084E RID: 2126 RVA: 0x0003D7D4 File Offset: 0x0003B9D4
	public void Load(out int opCoins, out int opCollectedCoins, out Dictionary<string, E_UnlockableItemSate> opComicStrips, out Dictionary<string, bool> opPuzzlePieces, out Dictionary<string, int> opTimeTrialRecords, out Dictionary<string, E_UnlockableItemSate> opHats, out Dictionary<string, E_UnlockableItemSate> opCustoms, out Dictionary<string, int> opChampionShipsRecords, out Dictionary<string, E_UnlockableItemSate> opCharacters, out Dictionary<string, E_UnlockableItemSate> opKarts, out Dictionary<string, E_UnlockableItemSate> opChampionShips, out Dictionary<string, string> opTimeTrialInfos, out Dictionary<string, int> opAdvantagesQuantity, out Dictionary<string, E_UnlockableItemSate> opAdvantages, out Dictionary<string, E_TimeTrialMedal> opMedals, out Dictionary<string, int> opBestTimes, out string opChallenge, out string opPseudo, out GameSave opGameSave, out string opPlayerConfig, out bool opShowTuto, out bool opFirstTime, out int opAskRating, out bool opAskSharing)
	{
		opCoins = 0;
		opCollectedCoins = 0;
		opComicStrips = new Dictionary<string, E_UnlockableItemSate>();
		opPuzzlePieces = new Dictionary<string, bool>();
		opTimeTrialRecords = new Dictionary<string, int>();
		opHats = new Dictionary<string, E_UnlockableItemSate>();
		opCustoms = new Dictionary<string, E_UnlockableItemSate>();
		opChampionShipsRecords = new Dictionary<string, int>();
		opCharacters = new Dictionary<string, E_UnlockableItemSate>();
		opKarts = new Dictionary<string, E_UnlockableItemSate>();
		opChampionShips = new Dictionary<string, E_UnlockableItemSate>();
		opTimeTrialInfos = new Dictionary<string, string>();
		opAdvantagesQuantity = new Dictionary<string, int>();
		opAdvantages = new Dictionary<string, E_UnlockableItemSate>();
		opMedals = new Dictionary<string, E_TimeTrialMedal>();
		opBestTimes = new Dictionary<string, int>();
		opChallenge = string.Empty;
		opGameSave = GameSave.Load("progession");
		opPseudo = string.Empty;
		opPseudo = opGameSave.GetString("PSEUDO", string.Empty);
		string text = string.Format("{0};{1};{2};{3}", new object[]
		{
			ECharacter.GARFIELD,
			ECharacter.HARRY,
			"None",
			"None"
		});
		opPlayerConfig = text;
		opPlayerConfig = opGameSave.GetString("CONFIG", text);
		opShowTuto = opGameSave.GetBool("SHOWTUTO", true);
		opFirstTime = opGameSave.GetBool("FIRSTTIME", true);
		opAskRating = opGameSave.GetInt("ASKRATING", 0);
		opAskSharing = opGameSave.GetBool("ASKSHARING", true);
		opCoins = opGameSave.GetInt("coins", 400);
		opCollectedCoins = opGameSave.GetInt("col_coins", 0);
		UnityEngine.Object @object = Resources.Load("Tracks", typeof(TrackList));
		string[] tracks = ((TrackList)@object).Tracks;
		foreach (string str in tracks)
		{
			string text2 = "ct_" + str;
			int @int = opGameSave.GetInt(text2, 0);
			if (!opComicStrips.ContainsKey(text2))
			{
				opComicStrips.Add(text2, (E_UnlockableItemSate)@int);
			}
			for (int j = 0; j < 3; j++)
			{
				string text3 = "pp_" + str + "_" + j.ToString();
				bool @bool = opGameSave.GetBool(text3, false);
				if (!opPuzzlePieces.ContainsKey(text3))
				{
					opPuzzlePieces.Add(text3, @bool);
				}
			}
			string text4 = "tt_" + str;
			int int2 = opGameSave.GetInt(text4, -1);
			if (!opTimeTrialRecords.ContainsKey(text4))
			{
				opTimeTrialRecords.Add(text4, int2);
			}
			string text5 = text4.Replace("tt_", "tf_");
			string pDefaultValue = string.Format("{0};{1};{2};{3}", new object[]
			{
				ECharacter.NONE,
				ECharacter.NONE,
				"None",
				"None"
			});
			string @string = opGameSave.GetString(text5, pDefaultValue);
			if (!opTimeTrialInfos.ContainsKey(text5))
			{
				opTimeTrialInfos.Add(text5, @string);
			}
			string text6 = text4.Replace("tt_", "tb_");
			int int3 = opGameSave.GetInt(text6, -1);
			if (!opBestTimes.ContainsKey(text6))
			{
				opBestTimes.Add(text6, int3);
			}
			string text7 = text4.Replace("tt_", "tm_");
			int int4 = opGameSave.GetInt(text7, 0);
			opMedals.Add(text7, (E_TimeTrialMedal)int4);
		}
		UnityEngine.Object[] array2 = Resources.LoadAll("Hat", typeof(BonusCustom));
		foreach (UnityEngine.Object object2 in array2)
		{
			string text8 = "ht_" + object2.name;
			int int5 = opGameSave.GetInt(text8, (int)((BonusCustom)object2).State);
			if (!opHats.ContainsKey(text8))
			{
				opHats.Add(text8, (E_UnlockableItemSate)int5);
			}
		}
		UnityEngine.Object[] array4 = Resources.LoadAll("Kart", typeof(KartCustom));
		foreach (UnityEngine.Object object3 in array4)
		{
			string text9 = "cm_" + object3.name;
			int int6 = opGameSave.GetInt(text9, (int)((KartCustom)object3).State);
			if (!opCustoms.ContainsKey(text9))
			{
				opCustoms.Add(text9, (E_UnlockableItemSate)int6);
			}
		}
		UnityEngine.Object[] array6 = Resources.LoadAll("ChampionShip", typeof(ChampionShipData));
		string name = array6[0].name;
		foreach (UnityEngine.Object object4 in array6)
		{
			string str2 = "cr_" + object4.name;
			string text10 = str2 + "_Easy";
			int int7 = opGameSave.GetInt(text10, -1);
			if (!opChampionShipsRecords.ContainsKey(text10))
			{
				opChampionShipsRecords.Add(text10, int7);
			}
			string text11 = str2 + "_Normal";
			int int8 = opGameSave.GetInt(text11, -1);
			if (!opChampionShipsRecords.ContainsKey(text11))
			{
				opChampionShipsRecords.Add(text11, int8);
			}
			string text12 = str2 + "_Hard";
			int int9 = opGameSave.GetInt(text12, -1);
			if (!opChampionShipsRecords.ContainsKey(text12))
			{
				opChampionShipsRecords.Add(text12, int9);
			}
			string str3 = "cs_" + object4.name;
			string text13 = str3 + "_Easy";
			int int10 = opGameSave.GetInt(text13, (int)((ChampionShipData)object4).EasyState);
			if (!opChampionShips.ContainsKey(text13))
			{
				opChampionShips.Add(text13, (E_UnlockableItemSate)int10);
			}
			string text14 = str3 + "_Normal";
			int int11 = opGameSave.GetInt(text14, (int)((ChampionShipData)object4).NormalState);
			if (!opChampionShips.ContainsKey(text14))
			{
				opChampionShips.Add(text14, (E_UnlockableItemSate)int11);
			}
			string text15 = str3 + "_Hard";
			int int12 = opGameSave.GetInt(text15, (int)((ChampionShipData)object4).HardState);
			if (!opChampionShips.ContainsKey(text15))
			{
				opChampionShips.Add(text15, (E_UnlockableItemSate)int12);
			}
		}
		UnityEngine.Object[] array8 = Resources.LoadAll("Character", typeof(CharacterCarac));
		for (int n = 0; n < array8.Length; n++)
		{
			if (array8[n] is CharacterCarac)
			{
				CharacterCarac characterCarac = (CharacterCarac)array8[n];
				string str4 = characterCarac.Owner.ToString();
				string text16 = "ch_" + str4;
				int int13 = opGameSave.GetInt(text16, (int)characterCarac.State);
				if (!opCharacters.ContainsKey(text16))
				{
					opCharacters.Add(text16, (E_UnlockableItemSate)int13);
				}
			}
		}
		UnityEngine.Object[] array9 = Resources.LoadAll("Kart", typeof(KartCarac));
		for (int num = 0; num < array9.Length; num++)
		{
			if (array9[num] is KartCarac)
			{
				KartCarac kartCarac = (KartCarac)array9[num];
				string str5 = kartCarac.Owner.ToString();
				string text17 = "kt_" + str5;
				int int14 = opGameSave.GetInt(text17, (int)kartCarac.State);
				if (!opKarts.ContainsKey(text17))
				{
					opKarts.Add(text17, (E_UnlockableItemSate)int14);
				}
			}
		}
		UnityEngine.Object[] array10 = Resources.LoadAll("Advantages", typeof(AdvantageData));
		for (int num2 = 0; num2 < array10.Length; num2++)
		{
			if (array10[num2] is AdvantageData)
			{
				AdvantageData advantageData = (AdvantageData)array10[num2];
				string str6 = advantageData.AdvantageType.ToString();
				string text18 = "av_" + str6;
				int int15 = opGameSave.GetInt(text18, (int)advantageData.State);
				if (!opAdvantages.ContainsKey(text18))
				{
					opAdvantages.Add(text18, (E_UnlockableItemSate)int15);
				}
				string text19 = "aq_" + str6;
				int pDefaultValue2 = 0;
				if (advantageData.State != E_UnlockableItemSate.Hidden)
				{
					pDefaultValue2 = 2;
				}
				int int16 = opGameSave.GetInt(text19, pDefaultValue2);
				if (!opAdvantagesQuantity.ContainsKey(text19))
				{
					opAdvantagesQuantity.Add(text19, int16);
				}
			}
		}
		string format = "{0};{1};{2};{3};{4};{5};{6};{7};{8};{9};{10};{11};{12};{13};{14};{15};{16}";
		object[] array11 = new object[17];
		int num3 = 0;
		DateTime dateTime = new DateTime(2000, 1, 1);
		array11[num3] = dateTime.ToString("ddMMyyyy");
		array11[1] = E_GameModeType.SINGLE.ToString();
		array11[2] = EChallengeFirstObjective.FinishAtPosX.ToString();
		array11[3] = ECharacter.NONE.ToString();
		array11[4] = EChallengeSingleRaceObjective.EarnXCoins.ToString();
		array11[5] = EChallengeChampionshipObjective.EarnXCoins.ToString();
		array11[6] = E_TimeTrialMedal.None.ToString();
		array11[7] = ECharacter.NONE.ToString();
		array11[8] = ECharacter.NONE.ToString();
		array11[9] = name;
		array11[10] = 0.ToString();
		array11[11] = EChallengeState.NotPlayed;
		array11[12] = true.ToString();
		array11[13] = EDifficulty.NORMAL;
		array11[14] = string.Empty;
		array11[15] = E_RewardType.Custom;
		array11[16] = ERarity.Base;
		string pDefaultValue3 = string.Format(format, array11);
		opChallenge = opGameSave.GetString("chal", pDefaultValue3);
	}

	// Token: 0x0600084F RID: 2127 RVA: 0x00007CE2 File Offset: 0x00005EE2
	public void Save()
	{
		this._gameSave.Save();
	}

	// Token: 0x06000850 RID: 2128 RVA: 0x00007CEF File Offset: 0x00005EEF
	public void SetPseudo(string pPseudo, bool pSave)
	{
		this._pseudo = pPseudo;
		this._gameSave.SetString("PSEUDO", this._pseudo);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x06000851 RID: 2129 RVA: 0x00007D1A File Offset: 0x00005F1A
	public string GetPseudo()
	{
		if (this._pseudo.Equals(string.Empty))
		{
			return Localization.instance.Get("MENU_PLAYER");
		}
		return this._pseudo;
	}

	// Token: 0x06000852 RID: 2130 RVA: 0x0003E150 File Offset: 0x0003C350
	public void SetPlayerConfig(ECharacter pCharacter, ECharacter pKart, string pCustom, string pHat, bool pSave)
	{
		string playerConfig = string.Format("{0};{1};{2};{3}", new object[]
		{
			pCharacter,
			pKart,
			pCustom,
			pHat
		});
		this._playerConfig = playerConfig;
		this._gameSave.SetString("CONFIG", this._playerConfig);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x06000853 RID: 2131 RVA: 0x0003E1B4 File Offset: 0x0003C3B4
	public void GetPlayerConfig(ref ECharacter rpCharacter, ref ECharacter rpKart, ref string rpCustom, ref string rpHat)
	{
		string[] array = this._playerConfig.Split(new char[]
		{
			';'
		});
		rpCharacter = (ECharacter)((int)Enum.Parse(typeof(ECharacter), array[0]));
		rpKart = (ECharacter)((int)Enum.Parse(typeof(ECharacter), array[1]));
		rpCustom = array[2];
		rpHat = array[3];
	}

	// Token: 0x06000854 RID: 2132 RVA: 0x0003E218 File Offset: 0x0003C418
	public void GetChallengeInfos(out string opDateTime, out E_GameModeType opGameModeType, out EChallengeFirstObjective opFirstObjective, out ECharacter opCharacterToBeat, out EChallengeSingleRaceObjective opSingleRaceObj, out EChallengeChampionshipObjective opChampionShipObj, out E_TimeTrialMedal opMedal, out ECharacter opImposedCharacter, out ECharacter opImposedKart, out string opChampionShipData, out int opTrack, out EChallengeState opState, out bool opIsMonday, out EDifficulty opDifficulty, out string opReward, out E_RewardType opRewardType, out ERarity opRarity)
	{
		string[] array = this._challenge.Split(new char[]
		{
			';'
		});
		opDateTime = array[0];
		opGameModeType = (E_GameModeType)((int)Enum.Parse(typeof(E_GameModeType), array[1]));
		opFirstObjective = (EChallengeFirstObjective)((int)Enum.Parse(typeof(EChallengeFirstObjective), array[2]));
		opCharacterToBeat = (ECharacter)((int)Enum.Parse(typeof(ECharacter), array[3]));
		opSingleRaceObj = (EChallengeSingleRaceObjective)((int)Enum.Parse(typeof(EChallengeSingleRaceObjective), array[4]));
		opChampionShipObj = (EChallengeChampionshipObjective)((int)Enum.Parse(typeof(EChallengeChampionshipObjective), array[5]));
		opMedal = (E_TimeTrialMedal)((int)Enum.Parse(typeof(E_TimeTrialMedal), array[6]));
		opImposedCharacter = (ECharacter)((int)Enum.Parse(typeof(ECharacter), array[7]));
		opImposedKart = (ECharacter)((int)Enum.Parse(typeof(ECharacter), array[8]));
		opChampionShipData = array[9];
		opTrack = int.Parse(array[10]);
		opState = (EChallengeState)((int)Enum.Parse(typeof(EChallengeState), array[11]));
		opIsMonday = bool.Parse(array[12]);
		opDifficulty = (EDifficulty)((int)Enum.Parse(typeof(EDifficulty), array[13]));
		opReward = array[14];
		opRewardType = (E_RewardType)((int)Enum.Parse(typeof(E_RewardType), array[15]));
		opRarity = (ERarity)((int)Enum.Parse(typeof(ERarity), array[16]));
	}

	// Token: 0x06000855 RID: 2133 RVA: 0x0003E3A4 File Offset: 0x0003C5A4
	public void SetChallengeInfos(E_GameModeType pGameModeType, EChallengeFirstObjective pFirstObjective, ECharacter pCharacterToBeat, EChallengeSingleRaceObjective pSingleRaceObj, EChallengeChampionshipObjective pChampionShipObj, E_TimeTrialMedal pMedal, ECharacter pImposedCharacter, ECharacter pImposedKart, string pChampionShipData, int pTrack, EChallengeState pState, bool pIsMonday, EDifficulty pDifficulty, string pReward, E_RewardType pRewardType, ERarity pRarity, bool pSave)
	{
		this._challenge = string.Format("{0};{1};{2};{3};{4};{5};{6};{7};{8};{9};{10};{11};{12};{13};{14};{15};{16}", new object[]
		{
			DateTime.Today.ToString("ddMMyyyy"),
			pGameModeType.ToString(),
			pFirstObjective.ToString(),
			pCharacterToBeat.ToString(),
			pSingleRaceObj.ToString(),
			pChampionShipObj.ToString(),
			pMedal.ToString(),
			pImposedCharacter.ToString(),
			pImposedKart.ToString(),
			pChampionShipData.ToString(),
			pTrack.ToString(),
			pState.ToString(),
			pIsMonday.ToString(),
			pDifficulty.ToString(),
			pReward,
			pRewardType.ToString(),
			pRarity
		});
		if (pSave)
		{
			this._gameSave.SetString("chal", this._challenge);
			this.Save();
		}
	}

	// Token: 0x06000856 RID: 2134 RVA: 0x00007D47 File Offset: 0x00005F47
	public bool GetShowTutorial()
	{
		return this._showTuto;
	}

	// Token: 0x06000857 RID: 2135 RVA: 0x00007D4F File Offset: 0x00005F4F
	public void SetShowTutorial(bool showTuto, bool pSave)
	{
		this._showTuto = showTuto;
		this._gameSave.SetBool("SHOWTUTO", this._showTuto);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x06000858 RID: 2136 RVA: 0x00007D7A File Offset: 0x00005F7A
	public bool GetFirstTime()
	{
		if (this._firstTime)
		{
			this.SetFirstTime(false, true);
			return true;
		}
		return false;
	}

	// Token: 0x06000859 RID: 2137 RVA: 0x00007D92 File Offset: 0x00005F92
	public void SetFirstTime(bool firstTime, bool pSave)
	{
		this._firstTime = firstTime;
		this._gameSave.SetBool("FIRSTTIME", this._firstTime);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x0600085A RID: 2138 RVA: 0x00007DBD File Offset: 0x00005FBD
	public int GetAskRating()
	{
		return this._askRating;
	}

	// Token: 0x0600085B RID: 2139 RVA: 0x00007DC5 File Offset: 0x00005FC5
	public void SetAskRating(int askRating, bool pSave)
	{
		this._askRating = askRating;
		this._gameSave.SetInt("ASKRATING", this._askRating);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x0600085C RID: 2140 RVA: 0x0003E4D8 File Offset: 0x0003C6D8
	public void AddAskRating(bool pSave)
	{
		if (this._askRating != -1 && this._askRating < 11)
		{
			this._askRating++;
			this._gameSave.SetInt("ASKRATING", this._askRating);
			if (pSave)
			{
				this.Save();
			}
		}
	}

	// Token: 0x0600085D RID: 2141 RVA: 0x00007DF0 File Offset: 0x00005FF0
	public bool GetAskSharing()
	{
		return this._askSharing;
	}

	// Token: 0x0600085E RID: 2142 RVA: 0x00007DF8 File Offset: 0x00005FF8
	public void SetAskSharing(bool askSharing, bool pSave)
	{
		this._askSharing = askSharing;
		this._gameSave.SetBool("ASKSHARING", this._askSharing);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x0600085F RID: 2143 RVA: 0x00007E23 File Offset: 0x00006023
	public int GetCoins()
	{
		return this._coins;
	}

	// Token: 0x06000860 RID: 2144 RVA: 0x00007E2B File Offset: 0x0000602B
	public int GetCollectedCoins()
	{
		return this._collectedCoins;
	}

	// Token: 0x06000861 RID: 2145 RVA: 0x00007E33 File Offset: 0x00006033
	private void SetCoins(int pValue, bool pSave)
	{
		this._coins += pValue;
		this._gameSave.SetInt("coins", this._coins);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x06000862 RID: 2146 RVA: 0x00007E65 File Offset: 0x00006065
	public void EarnCoins(int pValue, bool pCollectCoins, bool pSave)
	{
		if (pCollectCoins)
		{
			this._collectedCoins += pValue;
			this._gameSave.SetInt("col_coins", this._collectedCoins);
		}
		this.SetCoins(pValue, pSave);
	}

	// Token: 0x06000863 RID: 2147 RVA: 0x00007E99 File Offset: 0x00006099
	public void SpendCoins(int pValue, bool pSave)
	{
		this.SetCoins(-pValue, pSave);
	}

	// Token: 0x06000864 RID: 2148 RVA: 0x00007EA4 File Offset: 0x000060A4
	public void GetTimeTrialRecord(string pTrack, ref int rpTime)
	{
		rpTime = this._timeTrialRecords["tt_" + pTrack];
	}

	// Token: 0x06000865 RID: 2149 RVA: 0x0003E530 File Offset: 0x0003C730
	public void GetTimeTrialRecord(string pTrack, ref string rpTime)
	{
		int num = 0;
		this.GetTimeTrialRecord(pTrack, ref num);
		rpTime = TimeSpan.FromMilliseconds((double)num).FormatRaceTime();
	}

	// Token: 0x06000866 RID: 2150 RVA: 0x0003E558 File Offset: 0x0003C758
	private void GetTimeTrialInfos(string pTrack, ref ECharacter rpCharacter, ref ECharacter rpKart, ref string rpCustom, ref string rpHat)
	{
		string[] array = this._timeTrialInfos["tf_" + pTrack].Split(new char[]
		{
			';'
		});
		rpCharacter = (ECharacter)((int)Enum.Parse(typeof(ECharacter), array[0]));
		rpKart = (ECharacter)((int)Enum.Parse(typeof(ECharacter), array[1]));
		rpCustom = array[2];
		rpHat = array[3];
	}

	// Token: 0x06000867 RID: 2151 RVA: 0x00007EBE File Offset: 0x000060BE
	public void GetTimeTrial(string pTrack, ref string pTime, ref ECharacter rpCharacter, ref ECharacter rpKart, ref string rpCustom, ref string rpHat)
	{
		this.GetTimeTrialRecord(pTrack, ref pTime);
		this.GetTimeTrialInfos(pTrack, ref rpCharacter, ref rpKart, ref rpCustom, ref rpHat);
	}

	// Token: 0x06000868 RID: 2152 RVA: 0x00007ED6 File Offset: 0x000060D6
	public void GetTimeTrial(string pTrack, ref int pTime, ref ECharacter rpCharacter, ref ECharacter rpKart, ref string rpCustom, ref string rpHat)
	{
		this.GetTimeTrialRecord(pTrack, ref pTime);
		this.GetTimeTrialInfos(pTrack, ref rpCharacter, ref rpKart, ref rpCustom, ref rpHat);
	}

	// Token: 0x06000869 RID: 2153 RVA: 0x0003E5CC File Offset: 0x0003C7CC
	private void SetTimeTrialRecord(string pTrack, int pTime)
	{
		string text = "tt_" + pTrack;
		this._timeTrialRecords[text] = pTime;
		this._gameSave.SetInt(text, pTime);
	}

	// Token: 0x0600086A RID: 2154 RVA: 0x0003E600 File Offset: 0x0003C800
	private void SetTimeTrialInfos(string pTrack, ECharacter pCharacter, ECharacter pKart, string pCustom, string pHat)
	{
		string text = "tf_" + pTrack;
		string text2 = string.Format("{0};{1};{2};{3}", new object[]
		{
			pCharacter,
			pKart,
			pCustom,
			pHat
		});
		this._timeTrialInfos[text] = text2;
		this._gameSave.SetString(text, text2);
	}

	// Token: 0x0600086B RID: 2155 RVA: 0x00007EEE File Offset: 0x000060EE
	public void SetTimeTrial(string pTrack, int pTime, ECharacter pCharacter, ECharacter pKart, string pCustom, string pHat, bool pSave)
	{
		this.SetTimeTrialRecord(pTrack, pTime);
		this.SetTimeTrialInfos(pTrack, pCharacter, pKart, pCustom, pHat);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x0600086C RID: 2156 RVA: 0x0003E660 File Offset: 0x0003C860
	public E_TimeTrialMedal GetMedal(string pTrack, bool bIsChallenge)
	{
		if (bIsChallenge && Singleton<ChallengeManager>.Instance.IsActive && Singleton<ChallengeManager>.Instance.GameMode == E_GameModeType.TIME_TRIAL)
		{
			return Singleton<ChallengeManager>.Instance.MedalImposed - 1;
		}
		string key = "tm_" + pTrack;
		return this._timeTrialMedals[key];
	}

	// Token: 0x0600086D RID: 2157 RVA: 0x0003E6B8 File Offset: 0x0003C8B8
	public void SetMedal(string pTrack, E_TimeTrialMedal pMedal, bool pSave)
	{
		string text = "tm_" + pTrack;
		this._timeTrialMedals[text] = pMedal;
		this._gameSave.SetInt(text, (int)pMedal);
		if (pSave)
		{
			this._gameSave.Save();
		}
		if (pMedal == E_TimeTrialMedal.Platinium && !Singleton<GameConfigurator>.Instance.PlayerConfig.HasTimeTrialStar)
		{
			this.CheckTimeTrialStar(true);
		}
	}

	// Token: 0x0600086E RID: 2158 RVA: 0x00007F13 File Offset: 0x00006113
	public void GetTimeTrialBestTime(string pTrack, ref int rpTime)
	{
		rpTime = this._timeTrialBestTimes["tb_" + pTrack];
	}

	// Token: 0x0600086F RID: 2159 RVA: 0x0003E720 File Offset: 0x0003C920
	public void GetTimeTrialBestTime(string pTrack, ref string rpTime)
	{
		int num = 0;
		this.GetTimeTrialBestTime(pTrack, ref num);
		rpTime = TimeSpan.FromMilliseconds((double)num).FormatRaceTime();
	}

	// Token: 0x06000870 RID: 2160 RVA: 0x0003E748 File Offset: 0x0003C948
	public void SetTimeTrialBestTime(string pTrack, int pTime)
	{
		string text = "tb_" + pTrack;
		this._timeTrialBestTimes[text] = pTime;
		this._gameSave.SetInt(text, pTime);
	}

	// Token: 0x06000871 RID: 2161 RVA: 0x00007F2D File Offset: 0x0000612D
	public bool IsPuzzlePieceUnlocked(string pPiece)
	{
		return this._puzzlePieces["pp_" + pPiece];
	}

	// Token: 0x06000872 RID: 2162 RVA: 0x0003E77C File Offset: 0x0003C97C
	public void UnlockPuzzlePiece(string pPiece, bool pSave)
	{
		string text = "pp_" + pPiece;
		this._puzzlePieces[text] = true;
		this._gameSave.SetBool(text, true);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x06000873 RID: 2163 RVA: 0x00007F45 File Offset: 0x00006145
	public E_UnlockableItemSate GetComicStripState(string pComicStrip)
	{
		return this._comicStrips["ct_" + pComicStrip];
	}

	// Token: 0x06000874 RID: 2164 RVA: 0x0003E7BC File Offset: 0x0003C9BC
	public void SetComicStripState(string pComicStrip, E_UnlockableItemSate pState, bool pSave)
	{
		string text = "ct_" + pComicStrip;
		this._comicStrips[text] = pState;
		this._gameSave.SetInt(text, (int)pState);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x06000875 RID: 2165 RVA: 0x00007F5D File Offset: 0x0000615D
	public E_UnlockableItemSate GetHatState(string pHat)
	{
		return this._hats["ht_" + pHat];
	}

	// Token: 0x06000876 RID: 2166 RVA: 0x0003E7FC File Offset: 0x0003C9FC
	public void SetHatState(string pHat, E_UnlockableItemSate pState, bool pSave)
	{
		string text = "ht_" + pHat;
		this._hats[text] = pState;
		this._gameSave.SetInt(text, (int)pState);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x06000877 RID: 2167 RVA: 0x0003E83C File Offset: 0x0003CA3C
	public List<string> GetAvailableHats(ERarity pRarity, bool pIncludeDefault)
	{
		List<string> hats = GkUtils.GetHats(pRarity, pIncludeDefault);
		List<string> list = new List<string>();
		foreach (string text in hats)
		{
			if (this.GetHatState(text) != E_UnlockableItemSate.Hidden)
			{
				list.Add(text);
			}
		}
		return list;
	}

	// Token: 0x06000878 RID: 2168 RVA: 0x00007F75 File Offset: 0x00006175
	public E_UnlockableItemSate GetCustomState(string pCustom)
	{
		return this._customs["cm_" + pCustom];
	}

	// Token: 0x06000879 RID: 2169 RVA: 0x0003E8AC File Offset: 0x0003CAAC
	public void SetCustomState(string pCustom, E_UnlockableItemSate pState, bool pSave)
	{
		string text = "cm_" + pCustom;
		this._customs[text] = pState;
		this._gameSave.SetInt(text, (int)pState);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x0600087A RID: 2170 RVA: 0x0003E8EC File Offset: 0x0003CAEC
	public List<string> GetAvailableCustoms(ERarity pRarity, bool pIncludeDefault)
	{
		List<string> customs = GkUtils.GetCustoms(pRarity, pIncludeDefault);
		List<string> list = new List<string>();
		foreach (string text in customs)
		{
			if (this.GetCustomState(text) != E_UnlockableItemSate.Hidden)
			{
				list.Add(text);
			}
		}
		return list;
	}

	// Token: 0x0600087B RID: 2171 RVA: 0x00007F8D File Offset: 0x0000618D
	public E_UnlockableItemSate GetCharacterState(ECharacter pCharacter)
	{
		return this._characters["ch_" + pCharacter.ToString()];
	}

	// Token: 0x0600087C RID: 2172 RVA: 0x0003E95C File Offset: 0x0003CB5C
	public void SetCharacterState(ECharacter pCharacter, E_UnlockableItemSate pState, bool pSave)
	{
		string text = "ch_" + pCharacter.ToString();
		this._characters[text] = pState;
		this._gameSave.SetInt(text, (int)pState);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x0600087D RID: 2173 RVA: 0x00007FAF File Offset: 0x000061AF
	public E_UnlockableItemSate GetKartState(ECharacter pKart)
	{
		return this._karts["kt_" + pKart.ToString()];
	}

	// Token: 0x0600087E RID: 2174 RVA: 0x0003E9A8 File Offset: 0x0003CBA8
	public void SetKartState(ECharacter pKart, E_UnlockableItemSate pState, bool pSave)
	{
		string text = "kt_" + pKart.ToString();
		this._karts[text] = pState;
		this._gameSave.SetInt(text, (int)pState);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x0600087F RID: 2175 RVA: 0x0003E9F4 File Offset: 0x0003CBF4
	public List<ECharacter> GetAvailableKarts()
	{
		List<ECharacter> karts = GkUtils.GetKarts();
		List<ECharacter> list = new List<ECharacter>();
		foreach (ECharacter echaracter in karts)
		{
			if (this.GetKartState(echaracter) == E_UnlockableItemSate.Locked)
			{
				list.Add(echaracter);
			}
		}
		return list;
	}

	// Token: 0x06000880 RID: 2176 RVA: 0x0003EA64 File Offset: 0x0003CC64
	public string DifficultyToString(EDifficulty pDifficulty)
	{
		switch (pDifficulty)
		{
		case EDifficulty.NORMAL:
			return "_Normal";
		case EDifficulty.HARD:
			return "_Hard";
		case EDifficulty.EASY:
			return "_Easy";
		default:
			return "_Normal";
		}
	}

	// Token: 0x06000881 RID: 2177 RVA: 0x00007FD1 File Offset: 0x000061D1
	public int GetRank(string pChampionShip, EDifficulty pDifficulty)
	{
		return this._championShipsRecords["cr_" + pChampionShip + this.DifficultyToString(pDifficulty)];
	}

	// Token: 0x06000882 RID: 2178 RVA: 0x0003EAA4 File Offset: 0x0003CCA4
	public void SetRank(string pChampionShip, int pRank, EDifficulty pDifficulty, bool pSave)
	{
		string str = this.DifficultyToString(pDifficulty);
		string text = "cr_" + pChampionShip + str;
		this._championShipsRecords[text] = pRank;
		this._gameSave.SetInt(text, pRank);
		if (pSave)
		{
			this.Save();
		}
		if (pRank == 0)
		{
			if (pDifficulty == EDifficulty.EASY && !Singleton<GameConfigurator>.Instance.PlayerConfig.HasEasyChampionShipStar)
			{
				this.CheckEasyChampionShipStar(true);
			}
			else if (pDifficulty == EDifficulty.NORMAL && !Singleton<GameConfigurator>.Instance.PlayerConfig.HasNormalChampionShipStar)
			{
				this.CheckNormalChampionShipStar(true);
			}
			else if (pDifficulty == EDifficulty.HARD && !Singleton<GameConfigurator>.Instance.PlayerConfig.HasHardChampionShipStar)
			{
				this.CheckHardChampionShipStar(true);
			}
		}
	}

	// Token: 0x06000883 RID: 2179 RVA: 0x0003EB64 File Offset: 0x0003CD64
	public E_UnlockableItemSate GetChampionShipState(string pChampionShip, EDifficulty pDifficulty)
	{
		string str = this.DifficultyToString(pDifficulty);
		string key = "cs_" + pChampionShip + str;
		return this._championsShips[key];
	}

	// Token: 0x06000884 RID: 2180 RVA: 0x0003EB94 File Offset: 0x0003CD94
	public void SetChampionShipState(string pChampionShip, EDifficulty pDifficulty, E_UnlockableItemSate pState, bool pSave)
	{
		string str = this.DifficultyToString(pDifficulty);
		string text = "cs_" + pChampionShip + str;
		this._championsShips[text] = pState;
		this._gameSave.SetInt(text, (int)pState);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x06000885 RID: 2181 RVA: 0x0003EBE0 File Offset: 0x0003CDE0
	public int GetAdvantageQuantity(EAdvantage pAdvantage)
	{
		string key = "aq_" + pAdvantage.ToString();
		return this._advantagesQuantity[key];
	}

	// Token: 0x06000886 RID: 2182 RVA: 0x0003EC10 File Offset: 0x0003CE10
	private void IncrementAdvantageQuantity(EAdvantage pAdvantage, int pQuantity, bool pSave)
	{
		string text = "aq_" + pAdvantage.ToString();
		Dictionary<string, int> advantagesQuantity;
		Dictionary<string, int> dictionary = advantagesQuantity = this._advantagesQuantity;
		string key2;
		string key = key2 = text;
		int num = advantagesQuantity[key2];
		dictionary[key] = num + pQuantity;
		this._gameSave.SetInt(text, this._advantagesQuantity[text]);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x06000887 RID: 2183 RVA: 0x0003EC74 File Offset: 0x0003CE74
	public void SetAdvantageQuantity(EAdvantage pAdvantage, int pQuantity, bool pSave)
	{
		string text = "aq_" + pAdvantage.ToString();
		this._advantagesQuantity[text] = pQuantity;
		this._gameSave.SetInt(text, this._advantagesQuantity[text]);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x06000888 RID: 2184 RVA: 0x00007FF0 File Offset: 0x000061F0
	public void EarnAdvantage(EAdvantage pAdvantage, int pQuantity, bool pSave)
	{
		this.IncrementAdvantageQuantity(pAdvantage, pQuantity, pSave);
	}

	// Token: 0x06000889 RID: 2185 RVA: 0x00007FFB File Offset: 0x000061FB
	public void UseAdvantage(EAdvantage pAdvantage, int pQuantity, bool pSave)
	{
		this.IncrementAdvantageQuantity(pAdvantage, -pQuantity, pSave);
	}

	// Token: 0x0600088A RID: 2186 RVA: 0x00008007 File Offset: 0x00006207
	public E_UnlockableItemSate GetAdvantageState(EAdvantage pAdvantage)
	{
		return this._advantages["av_" + pAdvantage.ToString()];
	}

	// Token: 0x0600088B RID: 2187 RVA: 0x0003ECC8 File Offset: 0x0003CEC8
	public void SetAdvantageState(EAdvantage pAdvantage, E_UnlockableItemSate pState, bool pSave)
	{
		string text = "av_" + pAdvantage.ToString();
		this._advantages[text] = pState;
		this._gameSave.SetInt(text, (int)pState);
		if (pSave)
		{
			this.Save();
		}
	}

	// Token: 0x0600088C RID: 2188 RVA: 0x0003ED14 File Offset: 0x0003CF14
	private bool CheckChampionShipStar(string pDifficulty)
	{
		int num = 0;
		foreach (KeyValuePair<string, int> keyValuePair in this._championShipsRecords)
		{
			if (keyValuePair.Key.EndsWith(pDifficulty) && keyValuePair.Value == 0)
			{
				num++;
			}
		}
		return num == 4;
	}

	// Token: 0x0600088D RID: 2189 RVA: 0x0003ED90 File Offset: 0x0003CF90
	public void CheckEasyChampionShipStar(bool pCheckNew)
	{
		bool flag = this.CheckChampionShipStar("_Easy");
		if (pCheckNew && !Singleton<GameConfigurator>.Instance.PlayerConfig.HasEasyChampionShipStar && flag)
		{
			Singleton<RewardManager>.Instance.WinEasyChampionShipStar();
		}
		Singleton<GameConfigurator>.Instance.PlayerConfig.HasEasyChampionShipStar = flag;
	}

	// Token: 0x0600088E RID: 2190 RVA: 0x0003EDE4 File Offset: 0x0003CFE4
	public void CheckNormalChampionShipStar(bool pCheckNew)
	{
		bool flag = this.CheckChampionShipStar("_Normal");
		if (pCheckNew && !Singleton<GameConfigurator>.Instance.PlayerConfig.HasNormalChampionShipStar && flag)
		{
			Singleton<RewardManager>.Instance.WinNormalChampionShipStar();
		}
		Singleton<GameConfigurator>.Instance.PlayerConfig.HasNormalChampionShipStar = flag;
	}

	// Token: 0x0600088F RID: 2191 RVA: 0x0003EE38 File Offset: 0x0003D038
	public void CheckHardChampionShipStar(bool pCheckNew)
	{
		bool flag = this.CheckChampionShipStar("_Hard");
		if (pCheckNew && !Singleton<GameConfigurator>.Instance.PlayerConfig.HasHardChampionShipStar && flag)
		{
			Singleton<RewardManager>.Instance.WinHardChampionShipStar();
		}
		Singleton<GameConfigurator>.Instance.PlayerConfig.HasHardChampionShipStar = flag;
	}

	// Token: 0x06000890 RID: 2192 RVA: 0x0003EE8C File Offset: 0x0003D08C
	public void CheckTimeTrialStar(bool pCheckNew)
	{
		int num = 0;
		foreach (KeyValuePair<string, E_TimeTrialMedal> keyValuePair in this._timeTrialMedals)
		{
			if (keyValuePair.Value == E_TimeTrialMedal.Platinium)
			{
				num++;
			}
		}
		bool flag = num == 16;
		if (pCheckNew && !Singleton<GameConfigurator>.Instance.PlayerConfig.HasTimeTrialStar && flag)
		{
			Singleton<RewardManager>.Instance.WinTimeTrialStar();
		}
		Singleton<GameConfigurator>.Instance.PlayerConfig.HasTimeTrialStar = flag;
	}

	// Token: 0x06000891 RID: 2193 RVA: 0x0003EF34 File Offset: 0x0003D134
	public void CheckEndStar(bool pCheckNew)
	{
		bool flag = Singleton<GameConfigurator>.Instance.PlayerConfig.HasEasyChampionShipStar && Singleton<GameConfigurator>.Instance.PlayerConfig.HasNormalChampionShipStar && Singleton<GameConfigurator>.Instance.PlayerConfig.HasHardChampionShipStar && Singleton<GameConfigurator>.Instance.PlayerConfig.HasTimeTrialStar;
		if (flag)
		{
			foreach (KeyValuePair<string, bool> keyValuePair in this._puzzlePieces)
			{
				flag = (flag && keyValuePair.Value);
			}
			foreach (KeyValuePair<string, E_UnlockableItemSate> keyValuePair2 in this._hats)
			{
				flag = (flag && (keyValuePair2.Value == E_UnlockableItemSate.NewUnlocked || keyValuePair2.Value == E_UnlockableItemSate.Unlocked));
			}
			foreach (KeyValuePair<string, E_UnlockableItemSate> keyValuePair3 in this._customs)
			{
				flag = (flag && (keyValuePair3.Value == E_UnlockableItemSate.NewUnlocked || keyValuePair3.Value == E_UnlockableItemSate.Unlocked));
			}
			foreach (KeyValuePair<string, E_UnlockableItemSate> keyValuePair4 in this._karts)
			{
				flag = (flag && (keyValuePair4.Value == E_UnlockableItemSate.NewUnlocked || keyValuePair4.Value == E_UnlockableItemSate.Unlocked));
			}
		}
		if (pCheckNew && !Singleton<GameConfigurator>.Instance.PlayerConfig.HasEndStar && flag)
		{
			Singleton<RewardManager>.Instance.WinEndStar();
		}
		Singleton<GameConfigurator>.Instance.PlayerConfig.HasEndStar = flag;
	}

	// Token: 0x0400087E RID: 2174
	private const string _SAVE = "progession";

	// Token: 0x0400087F RID: 2175
	private const string _COINS = "coins";

	// Token: 0x04000880 RID: 2176
	private const string _COINS_COLLECTED = "col_coins";

	// Token: 0x04000881 RID: 2177
	private const string _PUZZLE_PIECE = "pp_";

	// Token: 0x04000882 RID: 2178
	private const string _COMIC_STRIP = "ct_";

	// Token: 0x04000883 RID: 2179
	private const string _TIME_TRIAL = "tt_";

	// Token: 0x04000884 RID: 2180
	private const string _TIME_TRIAL_INFO = "tf_";

	// Token: 0x04000885 RID: 2181
	private const string _TIME_TRIAL_MEDAL = "tm_";

	// Token: 0x04000886 RID: 2182
	private const string _TIME_TRIAL_BEST_LAP = "tb_";

	// Token: 0x04000887 RID: 2183
	private const string _HAT = "ht_";

	// Token: 0x04000888 RID: 2184
	private const string _CUSTOM = "cm_";

	// Token: 0x04000889 RID: 2185
	private const string _CHAMPION_SHIP_RECORDS = "cr_";

	// Token: 0x0400088A RID: 2186
	private const string _CHARACTER = "ch_";

	// Token: 0x0400088B RID: 2187
	private const string _KART = "kt_";

	// Token: 0x0400088C RID: 2188
	private const string _CHAMPION_SHIP = "cs_";

	// Token: 0x0400088D RID: 2189
	private const string _ADVANTAGE = "av_";

	// Token: 0x0400088E RID: 2190
	private const string _ADVANTAGE_QUANTITY = "aq_";

	// Token: 0x0400088F RID: 2191
	private const string _CHALLENGE = "chal";

	// Token: 0x04000890 RID: 2192
	private const string _PSEUDO = "PSEUDO";

	// Token: 0x04000891 RID: 2193
	private const string _CONFIG = "CONFIG";

	// Token: 0x04000892 RID: 2194
	private const string _SHOWTUTO = "SHOWTUTO";

	// Token: 0x04000893 RID: 2195
	private const string _FIRSTTIME = "FIRSTTIME";

	// Token: 0x04000894 RID: 2196
	private const string _ASKRATING = "ASKRATING";

	// Token: 0x04000895 RID: 2197
	private const string _ASKSHARING = "ASKSHARING";

	// Token: 0x04000896 RID: 2198
	private GameSave _gameSave;

	// Token: 0x04000897 RID: 2199
	private int _coins;

	// Token: 0x04000898 RID: 2200
	private int _collectedCoins;

	// Token: 0x04000899 RID: 2201
	private Dictionary<string, E_UnlockableItemSate> _comicStrips;

	// Token: 0x0400089A RID: 2202
	private Dictionary<string, bool> _puzzlePieces;

	// Token: 0x0400089B RID: 2203
	private Dictionary<string, int> _timeTrialRecords;

	// Token: 0x0400089C RID: 2204
	private Dictionary<string, int> _timeTrialBestTimes;

	// Token: 0x0400089D RID: 2205
	private Dictionary<string, E_TimeTrialMedal> _timeTrialMedals;

	// Token: 0x0400089E RID: 2206
	private Dictionary<string, string> _timeTrialInfos;

	// Token: 0x0400089F RID: 2207
	private Dictionary<string, E_UnlockableItemSate> _hats;

	// Token: 0x040008A0 RID: 2208
	private Dictionary<string, E_UnlockableItemSate> _customs;

	// Token: 0x040008A1 RID: 2209
	private Dictionary<string, int> _championShipsRecords;

	// Token: 0x040008A2 RID: 2210
	private Dictionary<string, E_UnlockableItemSate> _characters;

	// Token: 0x040008A3 RID: 2211
	private Dictionary<string, E_UnlockableItemSate> _karts;

	// Token: 0x040008A4 RID: 2212
	private Dictionary<string, E_UnlockableItemSate> _championsShips;

	// Token: 0x040008A5 RID: 2213
	private Dictionary<string, int> _advantagesQuantity;

	// Token: 0x040008A6 RID: 2214
	private Dictionary<string, E_UnlockableItemSate> _advantages;

	// Token: 0x040008A7 RID: 2215
	private string _challenge;

	// Token: 0x040008A8 RID: 2216
	private string _pseudo;

	// Token: 0x040008A9 RID: 2217
	private string _playerConfig;

	// Token: 0x040008AA RID: 2218
	private bool _showTuto;

	// Token: 0x040008AB RID: 2219
	private bool _firstTime;

	// Token: 0x040008AC RID: 2220
	private int _askRating;

	// Token: 0x040008AD RID: 2221
	private bool _askSharing;
}

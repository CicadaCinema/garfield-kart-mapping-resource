﻿using System;

// Token: 0x020000AA RID: 170
public enum EChallengeSingleRaceObjective
{
	// Token: 0x040003F5 RID: 1013
	EarnXCoins,
	// Token: 0x040003F6 RID: 1014
	NoDrift,
	// Token: 0x040003F7 RID: 1015
	NoBonus,
	// Token: 0x040003F8 RID: 1016
	NoFall
}

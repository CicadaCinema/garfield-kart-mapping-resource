﻿using System;
using UnityEngine;

// Token: 0x020001DF RID: 479
public class ForecastedCar : Forecasted
{
	// Token: 0x06000CE5 RID: 3301 RVA: 0x0000AE23 File Offset: 0x00009023
	public ForecastedCar()
	{
	}

	// Token: 0x06000CE6 RID: 3302 RVA: 0x0000AE2B File Offset: 0x0000902B
	public ForecastedCar(MonoBehaviour pEntity) : base(pEntity)
	{
	}

	// Token: 0x06000CE7 RID: 3303 RVA: 0x00003B7D File Offset: 0x00001D7D
	public override bool IsAttractiveFor(ForecastClient pClient)
	{
		return false;
	}
}

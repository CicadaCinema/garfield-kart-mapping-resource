﻿using System;
using UnityEngine;

// Token: 0x020001F7 RID: 503
public class RcNetworkController : RcController
{
	// Token: 0x06000D9C RID: 3484 RVA: 0x000583E4 File Offset: 0x000565E4
	public RcNetworkController()
	{
		this.m_dInterpBkTime = 0.12;
		this.m_dMaxExtrap = 0.55;
		this.m_iTimestampCount = -1;
		this.m_pPhysic = null;
	}

	// Token: 0x06000D9D RID: 3485 RVA: 0x0000B51A File Offset: 0x0000971A
	public override void Awake()
	{
		this.m_pVehicle = base.GetComponentInChildren<RcVehicle>();
		this.m_pPhysic = base.GetComponentInChildren<RcVehiclePhysic>();
		base.networkView.observed = this;
	}

	// Token: 0x06000D9E RID: 3486 RVA: 0x0000B540 File Offset: 0x00009740
	public void OnNetworkInstantiate(NetworkMessageInfo info)
	{
		if (!base.networkView.isMine)
		{
			this.m_pVehicle.SetControlType(RcVehicle.ControlType.Net);
		}
	}

	// Token: 0x06000D9F RID: 3487 RVA: 0x0000B55E File Offset: 0x0000975E
	public void OnSerializeNetworkView(BitStream stream, NetworkMessageInfo info)
	{
		if (base.networkView.stateSynchronization == NetworkStateSynchronization.ReliableDeltaCompressed)
		{
			this.OnSerializeNetworkViewReliable(stream, info);
		}
		else
		{
			this.OnSerializeNetworkViewUnreliable(stream, info);
		}
	}

	// Token: 0x06000DA0 RID: 3488 RVA: 0x00058430 File Offset: 0x00056630
	public void OnSerializeNetworkViewReliable(BitStream stream, NetworkMessageInfo info)
	{
		if (stream.isWriting)
		{
			Vector3 position = base.rigidbody.position;
			Quaternion rotation = base.rigidbody.rotation;
			Vector3 linearVelocity = this.m_pPhysic.GetLinearVelocity();
			Vector3 angularVelocity = this.m_pPhysic.GetAngularVelocity();
			stream.Serialize(ref position);
			stream.Serialize(ref linearVelocity);
			stream.Serialize(ref rotation);
			stream.Serialize(ref angularVelocity);
			float steeringFactor = this.m_pVehicle.GetSteeringFactor();
			float moveFactor = this.m_pVehicle.GetMoveFactor();
			stream.Serialize(ref steeringFactor);
			stream.Serialize(ref moveFactor);
			float wheelSpeedMS = this.m_pVehicle.GetWheelSpeedMS();
			float arcadeDriftFactor = this.m_pVehicle.GetArcadeDriftFactor();
			stream.Serialize(ref wheelSpeedMS);
			stream.Serialize(ref arcadeDriftFactor);
		}
		else if (this.m_pVehicle.GetControlType() == RcVehicle.ControlType.Net)
		{
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Quaternion identity = Quaternion.identity;
			Vector3 zero3 = Vector3.zero;
			float leftRightFactor = 0f;
			float fwdBkdFactor = 0f;
			stream.Serialize(ref zero);
			stream.Serialize(ref zero2);
			stream.Serialize(ref identity);
			stream.Serialize(ref zero3);
			stream.Serialize(ref leftRightFactor);
			stream.Serialize(ref fwdBkdFactor);
			float engineVel = 0f;
			float drift = 0f;
			stream.Serialize(ref engineVel);
			stream.Serialize(ref drift);
			for (int i = this.m_BufferedState.Length - 1; i >= 1; i--)
			{
				this.m_BufferedState[i] = this.m_BufferedState[i - 1];
			}
			RcNetworkController.Packet packet;
			packet.time = info.timestamp;
			packet.pos = zero;
			packet.vel = zero2;
			packet.quat = identity;
			packet.omega = zero3;
			packet.leftRightFactor = leftRightFactor;
			packet.FwdBkdFactor = fwdBkdFactor;
			packet.engineVel = engineVel;
			packet.drift = drift;
			this.m_BufferedState[0] = packet;
			this.m_iTimestampCount = Mathf.Min(this.m_iTimestampCount + 1, this.m_BufferedState.Length);
		}
	}

	// Token: 0x06000DA1 RID: 3489 RVA: 0x00058644 File Offset: 0x00056844
	public void OnSerializeNetworkViewUnreliable(BitStream stream, NetworkMessageInfo info)
	{
		if (stream.isWriting && this.m_pVehicle.GetControlType() != RcVehicle.ControlType.Net)
		{
			Vector3 position = base.rigidbody.position;
			Quaternion rotation = base.rigidbody.rotation;
			Vector3 linearVelocity = this.m_pPhysic.GetLinearVelocity();
			Vector3 angularVelocity = this.m_pPhysic.GetAngularVelocity();
			RcUtils.SerializeAndCompressVector(stream, position, new Vector3(1000f, 200f, 100f));
			RcUtils.SerializeAndCompressVector(stream, linearVelocity, Vector3.one * 300f);
			RcUtils.SerializeAndCompressQuaternion(stream, rotation);
			RcUtils.SerializeAndCompressVector(stream, angularVelocity, Vector3.one * 100f);
			float steeringFactor = this.m_pVehicle.GetSteeringFactor();
			float moveFactor = this.m_pVehicle.GetMoveFactor();
			short num = RcUtils.CompressFloat(steeringFactor, -1f, 1f);
			short num2 = RcUtils.CompressFloat(moveFactor, -1f, 2f);
			stream.Serialize(ref num);
			stream.Serialize(ref num2);
			float wheelSpeedMS = this.m_pVehicle.GetWheelSpeedMS();
			float arcadeDriftFactor = this.m_pVehicle.GetArcadeDriftFactor();
			short num3 = RcUtils.CompressFloat(wheelSpeedMS, -300f, 300f);
			short num4 = RcUtils.CompressFloat(arcadeDriftFactor, -1f, 1f);
			stream.Serialize(ref num3);
			stream.Serialize(ref num4);
		}
		else if (this.m_pVehicle.GetControlType() == RcVehicle.ControlType.Net)
		{
			Vector3 pos = Vector3.zero;
			Vector3 vel = Vector3.zero;
			Quaternion quat = Quaternion.identity;
			Vector3 omega = Vector3.zero;
			pos = RcUtils.UnserializeCompressedVector(stream, new Vector3(1000f, 200f, 100f));
			vel = RcUtils.UnserializeCompressedVector(stream, Vector3.one * 300f);
			quat = RcUtils.UnserializeCompressedQuaternion(stream);
			omega = RcUtils.UnserializeCompressedVector(stream, Vector3.one * 100f);
			short value_in = 0;
			short value_in2 = 0;
			stream.Serialize(ref value_in);
			stream.Serialize(ref value_in2);
			float leftRightFactor = RcUtils.DecompressFloat(value_in, -1f, 1f);
			float fwdBkdFactor = RcUtils.DecompressFloat(value_in2, -1f, 2f);
			short value_in3 = 0;
			short value_in4 = 0;
			stream.Serialize(ref value_in3);
			stream.Serialize(ref value_in4);
			float engineVel = RcUtils.DecompressFloat(value_in3, -300f, 300f);
			float drift = RcUtils.DecompressFloat(value_in4, -1f, 1f);
			for (int i = this.m_BufferedState.Length - 1; i >= 1; i--)
			{
				this.m_BufferedState[i] = this.m_BufferedState[i - 1];
			}
			RcNetworkController.Packet packet;
			packet.time = info.timestamp;
			packet.pos = pos;
			packet.vel = vel;
			packet.quat = quat;
			packet.omega = omega;
			packet.leftRightFactor = leftRightFactor;
			packet.FwdBkdFactor = fwdBkdFactor;
			packet.engineVel = engineVel;
			packet.drift = drift;
			this.m_BufferedState[0] = packet;
			this.m_iTimestampCount = Mathf.Min(this.m_iTimestampCount + 1, this.m_BufferedState.Length);
		}
	}

	// Token: 0x06000DA2 RID: 3490 RVA: 0x0005896C File Offset: 0x00056B6C
	public void FixedUpdate()
	{
		if (this.m_pVehicle.GetControlType() != RcVehicle.ControlType.Net)
		{
			return;
		}
		double num = Network.time - this.m_dInterpBkTime;
		if (this.m_BufferedState[0].time > num)
		{
			for (int i = 0; i < this.m_iTimestampCount; i++)
			{
				if (this.m_BufferedState[i].time <= num || i == this.m_iTimestampCount - 1)
				{
					RcNetworkController.Packet packet = this.m_BufferedState[Mathf.Max(i - 1, 0)];
					RcNetworkController.Packet packet2 = this.m_BufferedState[i];
					double num2 = packet.time - packet2.time;
					float num3 = 0f;
					if (num2 > 0.0001)
					{
						num3 = (float)((num - packet2.time) / num2);
					}
					this.m_pPhysic.NetMove(Vector3.Lerp(packet2.pos, packet.pos, num3), Quaternion.Slerp(packet2.quat, packet.quat, num3), Vector3.Lerp(packet2.vel, packet.vel, num3), Vector3.zero);
					float steering = RcUtils.LinearInterpolation(0f, packet2.leftRightFactor, 1f, packet.leftRightFactor, num3, true);
					float accelerationPrc = RcUtils.LinearInterpolation(0f, packet2.FwdBkdFactor, 1f, packet.FwdBkdFactor, num3, true);
					float wheelSpeedMS = RcUtils.LinearInterpolation(0f, packet2.engineVel, 1f, packet.engineVel, num3, true);
					float arcadeDriftFactor = RcUtils.LinearInterpolation(0f, packet2.drift, 1f, packet.drift, num3, true);
					this.m_pVehicle.SetWheelSpeedMS(wheelSpeedMS);
					this.m_pVehicle.SetArcadeDriftFactor(arcadeDriftFactor);
					this.m_pVehicle.Accelerate(accelerationPrc);
					this.m_pVehicle.Turn(steering, false);
					return;
				}
			}
		}
		else
		{
			RcNetworkController.Packet packet3 = this.m_BufferedState[0];
			float num4 = (float)(num - packet3.time);
			if ((double)num4 < this.m_dMaxExtrap)
			{
				float angle = num4 * packet3.omega.magnitude * 57.29578f;
				Quaternion lhs = Quaternion.AngleAxis(angle, packet3.omega);
				this.m_pPhysic.NetMove(packet3.pos + packet3.vel * num4, lhs * packet3.quat, packet3.vel, packet3.omega);
				this.m_pPhysic.SetLinearVelocity(packet3.vel);
				this.m_pPhysic.SetAngularVelocity(packet3.omega);
				float leftRightFactor = packet3.leftRightFactor;
				float fwdBkdFactor = packet3.FwdBkdFactor;
				this.m_pVehicle.SetWheelSpeedMS(packet3.engineVel);
				this.m_pVehicle.SetArcadeDriftFactor(packet3.drift);
				this.m_pVehicle.Accelerate(fwdBkdFactor);
				this.m_pVehicle.Turn(leftRightFactor, false);
			}
		}
	}

	// Token: 0x04000D40 RID: 3392
	public double m_dInterpBkTime;

	// Token: 0x04000D41 RID: 3393
	public double m_dMaxExtrap;

	// Token: 0x04000D42 RID: 3394
	protected int m_iTimestampCount;

	// Token: 0x04000D43 RID: 3395
	protected RcNetworkController.Packet[] m_BufferedState = new RcNetworkController.Packet[20];

	// Token: 0x04000D44 RID: 3396
	protected RcVehiclePhysic m_pPhysic;

	// Token: 0x020001F8 RID: 504
	public struct Packet
	{
		// Token: 0x04000D45 RID: 3397
		public double time;

		// Token: 0x04000D46 RID: 3398
		public Vector3 pos;

		// Token: 0x04000D47 RID: 3399
		public Vector3 vel;

		// Token: 0x04000D48 RID: 3400
		public Quaternion quat;

		// Token: 0x04000D49 RID: 3401
		public Vector3 omega;

		// Token: 0x04000D4A RID: 3402
		public float leftRightFactor;

		// Token: 0x04000D4B RID: 3403
		public float FwdBkdFactor;

		// Token: 0x04000D4C RID: 3404
		public float engineVel;

		// Token: 0x04000D4D RID: 3405
		public float drift;
	}
}

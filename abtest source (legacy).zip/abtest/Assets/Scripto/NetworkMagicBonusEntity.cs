﻿using System;
using UnityEngine;

// Token: 0x020000E4 RID: 228
public class NetworkMagicBonusEntity : NetworkMovableBonusEntity
{
	// Token: 0x0600062A RID: 1578 RVA: 0x000065C0 File Offset: 0x000047C0
	[RPC]
	public new void OnNetworkDestroy()
	{
		((MagicBonusEntity)this.m_pBonusEntity).DoDestroyByWall();
	}

	// Token: 0x0600062B RID: 1579 RVA: 0x000065D2 File Offset: 0x000047D2
	[RPC]
	public override void Launch(NetworkViewID launcherViewID)
	{
		this.NetworkInitialize(launcherViewID);
		((MagicBonusEntity)this.m_pBonusEntity).Launch();
	}
}

﻿using System;

// Token: 0x0200012B RID: 299
public enum E_InputType
{
	// Token: 0x0400085D RID: 2141
	Keyboard,
	// Token: 0x0400085E RID: 2142
	Gamepad,
	// Token: 0x0400085F RID: 2143
	Touched,
	// Token: 0x04000860 RID: 2144
	Gyroscopic
}

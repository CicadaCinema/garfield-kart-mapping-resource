﻿using System;

// Token: 0x02000100 RID: 256
public enum BonusAnimation_State
{
	// Token: 0x040006CF RID: 1743
	STOPPED,
	// Token: 0x040006D0 RID: 1744
	STARTED,
	// Token: 0x040006D1 RID: 1745
	DECELERATED
}

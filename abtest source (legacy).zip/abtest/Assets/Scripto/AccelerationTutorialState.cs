﻿using System;
using UnityEngine;

// Token: 0x0200017D RID: 381
public class AccelerationTutorialState : IGTutorialState
{
	// Token: 0x17000167 RID: 359
	// (get) Token: 0x06000A2A RID: 2602 RVA: 0x00008F09 File Offset: 0x00007109
	public override ETutorialState NextState
	{
		get
		{
			if (Application.platform == RuntimePlatform.IPhonePlayer || Application.platform == RuntimePlatform.Android)
			{
				return this.ENextState_Mobile;
			}
			return this.ENextState;
		}
	}

	// Token: 0x04000A28 RID: 2600
	public ETutorialState ENextState_Mobile = ETutorialState.Direction_Gyro;
}

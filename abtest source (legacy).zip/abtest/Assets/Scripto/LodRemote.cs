﻿using System;
using UnityEngine;

// Token: 0x020001D0 RID: 464
public class LodRemote : MonoBehaviour
{
	// Token: 0x06000C8B RID: 3211 RVA: 0x00053304 File Offset: 0x00051504
	public void SetCurrentLod(int iLodId)
	{
		foreach (LODGroup lodgroup in this.m_pLodGroupReceiver)
		{
			if (lodgroup)
			{
				lodgroup.ForceLOD(iLodId);
				Animator component = lodgroup.GetComponent<Animator>();
				if (component)
				{
					component.enabled = (iLodId == 0);
				}
			}
		}
	}

	// Token: 0x04000C33 RID: 3123
	public LODGroup[] m_pLodGroupReceiver = new LODGroup[3];
}

﻿using System;
using UnityEngine;

// Token: 0x0200002E RID: 46
[AddComponentMenu("NGUI/Interaction/Slider")]
public class UISlider : IgnoreTimeScale
{
	// Token: 0x1700001A RID: 26
	// (get) Token: 0x06000100 RID: 256 RVA: 0x000127E0 File Offset: 0x000109E0
	// (set) Token: 0x06000101 RID: 257 RVA: 0x00002F00 File Offset: 0x00001100
	public float sliderValue
	{
		get
		{
			float num = this.rawValue;
			if (this.numberOfSteps > 1)
			{
				num = Mathf.Round(num * (float)(this.numberOfSteps - 1)) / (float)(this.numberOfSteps - 1);
			}
			return num;
		}
		set
		{
			this.Set(value, false);
		}
	}

	// Token: 0x1700001B RID: 27
	// (get) Token: 0x06000102 RID: 258 RVA: 0x00002F0A File Offset: 0x0000110A
	// (set) Token: 0x06000103 RID: 259 RVA: 0x00002F12 File Offset: 0x00001112
	public Vector2 fullSize
	{
		get
		{
			return this.mSize;
		}
		set
		{
			if (this.mSize != value)
			{
				this.mSize = value;
				this.ForceUpdate();
			}
		}
	}

	// Token: 0x06000104 RID: 260 RVA: 0x0001281C File Offset: 0x00010A1C
	private void Init()
	{
		this.mInitDone = true;
		if (this.foreground != null)
		{
			this.mFGWidget = this.foreground.GetComponent<UIWidget>();
			this.mFGFilled = ((!(this.mFGWidget != null)) ? null : (this.mFGWidget as UISprite));
			this.mFGTrans = this.foreground.transform;
			if (this.mSize == Vector2.zero)
			{
				this.mSize = this.foreground.localScale;
			}
			if (this.mCenter == Vector2.zero)
			{
				this.mCenter = this.foreground.localPosition + this.foreground.localScale * 0.5f;
			}
		}
		else if (this.mCol != null)
		{
			if (this.mSize == Vector2.zero)
			{
				this.mSize = this.mCol.size;
			}
			if (this.mCenter == Vector2.zero)
			{
				this.mCenter = this.mCol.center;
			}
		}
		else
		{
			Debug.LogWarning("UISlider expected to find a foreground object or a box collider to work with", this);
		}
	}

	// Token: 0x06000105 RID: 261 RVA: 0x00002F32 File Offset: 0x00001132
	private void Awake()
	{
		this.mTrans = base.transform;
		this.mCol = (base.collider as BoxCollider);
	}

	// Token: 0x06000106 RID: 262 RVA: 0x00012978 File Offset: 0x00010B78
	private void Start()
	{
		this.Init();
		if (Application.isPlaying && this.thumb != null && this.thumb.collider != null)
		{
			UIEventListener uieventListener = UIEventListener.Get(this.thumb.gameObject);
			UIEventListener uieventListener2 = uieventListener;
			uieventListener2.onPress = (UIEventListener.BoolDelegate)Delegate.Combine(uieventListener2.onPress, new UIEventListener.BoolDelegate(this.OnPressThumb));
			UIEventListener uieventListener3 = uieventListener;
			uieventListener3.onDrag = (UIEventListener.VectorDelegate)Delegate.Combine(uieventListener3.onDrag, new UIEventListener.VectorDelegate(this.OnDragThumb));
		}
		this.Set(this.rawValue, true);
	}

	// Token: 0x06000107 RID: 263 RVA: 0x00002F51 File Offset: 0x00001151
	private void OnPress(bool pressed)
	{
		if (pressed && UICamera.currentTouchID != -100)
		{
			this.UpdateDrag();
		}
	}

	// Token: 0x06000108 RID: 264 RVA: 0x00002F6B File Offset: 0x0000116B
	private void OnDrag(Vector2 delta)
	{
		this.UpdateDrag();
	}

	// Token: 0x06000109 RID: 265 RVA: 0x00002F73 File Offset: 0x00001173
	private void OnPressThumb(GameObject go, bool pressed)
	{
		if (pressed)
		{
			this.UpdateDrag();
		}
	}

	// Token: 0x0600010A RID: 266 RVA: 0x00002F6B File Offset: 0x0000116B
	private void OnDragThumb(GameObject go, Vector2 delta)
	{
		this.UpdateDrag();
	}

	// Token: 0x0600010B RID: 267 RVA: 0x00012A20 File Offset: 0x00010C20
	private void OnKey(KeyCode key)
	{
		float num = ((float)this.numberOfSteps <= 1f) ? 0.125f : (1f / (float)(this.numberOfSteps - 1));
		if (this.direction == UISlider.Direction.Horizontal)
		{
			if (key == KeyCode.LeftArrow)
			{
				this.Set(this.rawValue - num, false);
			}
			else if (key == KeyCode.RightArrow)
			{
				this.Set(this.rawValue + num, false);
			}
		}
		else if (key == KeyCode.DownArrow)
		{
			this.Set(this.rawValue - num, false);
		}
		else if (key == KeyCode.UpArrow)
		{
			this.Set(this.rawValue + num, false);
		}
	}

	// Token: 0x0600010C RID: 268 RVA: 0x00012ADC File Offset: 0x00010CDC
	private void UpdateDrag()
	{
		if (this.mCol == null || UICamera.currentCamera == null || UICamera.currentTouch == null)
		{
			return;
		}
		UICamera.currentTouch.clickNotification = UICamera.ClickNotification.None;
		Ray ray = UICamera.currentCamera.ScreenPointToRay(UICamera.currentTouch.pos);
		Plane plane = new Plane(this.mTrans.rotation * Vector3.back, this.mTrans.position);
		float distance;
		if (!plane.Raycast(ray, out distance))
		{
			return;
		}
		Vector3 b = (Vector2) this.mTrans.localPosition + (this.mCenter - this.mSize * 0.5f);
		Vector3 b2 = this.mTrans.localPosition - b;
		Vector3 a = this.mTrans.InverseTransformPoint(ray.GetPoint(distance));
		Vector3 vector = a + b2;
		this.Set((this.direction != UISlider.Direction.Horizontal) ? (vector.y / this.mSize.y) : (vector.x / this.mSize.x), false);
	}

	// Token: 0x0600010D RID: 269 RVA: 0x00012C14 File Offset: 0x00010E14
	private void Set(float input, bool force)
	{
		if (!this.mInitDone)
		{
			this.Init();
		}
		float num = Mathf.Clamp01(input);
		if (num < 0.001f)
		{
			num = 0f;
		}
		float sliderValue = this.sliderValue;
		this.rawValue = num;
		float sliderValue2 = this.sliderValue;
		if (force || sliderValue != sliderValue2)
		{
			Vector3 localScale = this.mSize;
			if (this.direction == UISlider.Direction.Horizontal)
			{
				localScale.x *= sliderValue2;
			}
			else
			{
				localScale.y *= sliderValue2;
			}
			if (this.mFGFilled != null && this.mFGFilled.type == UISprite.Type.Filled)
			{
				this.mFGFilled.fillAmount = sliderValue2;
			}
			else if (this.foreground != null)
			{
				this.mFGTrans.localScale = localScale;
				if (this.mFGWidget != null)
				{
					if (sliderValue2 > 0.001f)
					{
						this.mFGWidget.enabled = true;
						this.mFGWidget.MarkAsChanged();
					}
					else
					{
						this.mFGWidget.enabled = false;
					}
				}
			}
			if (this.thumb != null)
			{
				Vector3 localPosition = this.thumb.localPosition;
				if (this.mFGFilled != null && this.mFGFilled.type == UISprite.Type.Filled)
				{
					if (this.mFGFilled.fillDirection == UISprite.FillDirection.Horizontal)
					{
						localPosition.x = ((!this.mFGFilled.invert) ? localScale.x : (this.mSize.x - localScale.x));
					}
					else if (this.mFGFilled.fillDirection == UISprite.FillDirection.Vertical)
					{
						localPosition.y = ((!this.mFGFilled.invert) ? localScale.y : (this.mSize.y - localScale.y));
					}
					else
					{
						Debug.LogWarning("Slider thumb is only supported with Horizontal or Vertical fill direction", this);
					}
				}
				else if (this.direction == UISlider.Direction.Horizontal)
				{
					localPosition.x = localScale.x;
				}
				else
				{
					localPosition.y = localScale.y;
				}
				this.thumb.localPosition = localPosition;
			}
			UISlider.current = this;
			if (this.eventReceiver != null && !string.IsNullOrEmpty(this.functionName) && Application.isPlaying)
			{
				this.eventReceiver.SendMessage(this.functionName, sliderValue2, SendMessageOptions.DontRequireReceiver);
			}
			if (this.onValueChange != null)
			{
				this.onValueChange(sliderValue2);
			}
			UISlider.current = null;
		}
	}

	// Token: 0x0600010E RID: 270 RVA: 0x00002F81 File Offset: 0x00001181
	public void ForceUpdate()
	{
		this.Set(this.rawValue, true);
	}

	// Token: 0x0400010D RID: 269
	public static UISlider current;

	// Token: 0x0400010E RID: 270
	public Transform foreground;

	// Token: 0x0400010F RID: 271
	public Transform thumb;

	// Token: 0x04000110 RID: 272
	public UISlider.Direction direction;

	// Token: 0x04000111 RID: 273
	public GameObject eventReceiver;

	// Token: 0x04000112 RID: 274
	public string functionName = "OnSliderChange";

	// Token: 0x04000113 RID: 275
	public UISlider.OnValueChange onValueChange;

	// Token: 0x04000114 RID: 276
	public int numberOfSteps;

	// Token: 0x04000115 RID: 277
	[SerializeField]
	[HideInInspector]
	private float rawValue = 1f;

	// Token: 0x04000116 RID: 278
	private BoxCollider mCol;

	// Token: 0x04000117 RID: 279
	private Transform mTrans;

	// Token: 0x04000118 RID: 280
	private Transform mFGTrans;

	// Token: 0x04000119 RID: 281
	private UIWidget mFGWidget;

	// Token: 0x0400011A RID: 282
	private UISprite mFGFilled;

	// Token: 0x0400011B RID: 283
	private bool mInitDone;

	// Token: 0x0400011C RID: 284
	private Vector2 mSize = Vector2.zero;

	// Token: 0x0400011D RID: 285
	private Vector2 mCenter = Vector3.zero;

	// Token: 0x0200002F RID: 47
	public enum Direction
	{
		// Token: 0x0400011F RID: 287
		Horizontal,
		// Token: 0x04000120 RID: 288
		Vertical
	}

	// Token: 0x02000030 RID: 48
	// (Invoke) Token: 0x06000110 RID: 272
	public delegate void OnValueChange(float val);
}

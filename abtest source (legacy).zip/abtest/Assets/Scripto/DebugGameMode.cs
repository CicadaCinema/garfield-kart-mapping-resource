﻿using System;
using UnityEngine;

// Token: 0x02000168 RID: 360
public class DebugGameMode : GameMode
{
	// Token: 0x060009A8 RID: 2472 RVA: 0x00008A60 File Offset: 0x00006C60
	public override void Awake()
	{
		base.Awake();
		this.StartPosition = null;
		this.PlaceVehicles = false;
	}

	// Token: 0x060009A9 RID: 2473 RVA: 0x00043D04 File Offset: 0x00041F04
	public override void CreatePlayers()
	{
		if (!DebugMgr.Instance.dbgData.RandomPlayer)
		{
			DebugMgr.Instance.LoadDefaultPlayer(0, this);
		}
		else
		{
			ECharacter character = Singleton<GameConfigurator>.Instance.PlayerConfig.Character;
			ECharacter kart = Singleton<GameConfigurator>.Instance.PlayerConfig.Kart;
			GameObject gameObject = (GameObject)Resources.Load("Hat/" + Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat.name);
			GameObject gameObject2 = (GameObject)Resources.Load("Kart/" + Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom.name);
			base.CreatePlayer(character, kart, gameObject2.name, gameObject.name, 0, 0, false, false);
		}
	}

	// Token: 0x060009AA RID: 2474 RVA: 0x00043DC0 File Offset: 0x00041FC0
	public void FixedUpdate()
	{
		if (this.PlaceVehicles)
		{
			RcKinematicPhysic rcKinematicPhysic = (RcKinematicPhysic)this.m_pPlayers[0].Item2.GetVehiclePhysic();
			rcKinematicPhysic.Teleport(this.StartPosition.position, this.StartPosition.rotation);
			this.m_pPlayers[0].Item2.Enable();
			this.PlaceVehicles = false;
			this.m_bReadyToStart = true;
			foreach (RcPortalTrigger rcPortalTrigger in UnityEngine.Object.FindSceneObjectsOfType(typeof(RcPortalTrigger)))
			{
				rcPortalTrigger.enabled = true;
			}
		}
	}

	// Token: 0x060009AB RID: 2475 RVA: 0x00043E60 File Offset: 0x00042060
	public override void StartScene()
	{
		base.ComputePlayerAdvantages();
		GameObject gameObject = GameObject.Find("Start");
		if (gameObject != null)
		{
			this.StartPosition = gameObject.transform.GetChild(0);
			this.PlaceVehicles = true;
		}
	}

	// Token: 0x040009E6 RID: 2534
	private bool PlaceVehicles;

	// Token: 0x040009E7 RID: 2535
	private Transform StartPosition;
}

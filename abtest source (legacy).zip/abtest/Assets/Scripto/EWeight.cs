﻿using System;

// Token: 0x02000137 RID: 311
public enum EWeight
{
	// Token: 0x040008DF RID: 2271
	Light,
	// Token: 0x040008E0 RID: 2272
	Medium,
	// Token: 0x040008E1 RID: 2273
	Heavy
}

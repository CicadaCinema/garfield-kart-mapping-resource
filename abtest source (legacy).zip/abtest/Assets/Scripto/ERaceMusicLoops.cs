﻿using System;

// Token: 0x020000C6 RID: 198
public enum ERaceMusicLoops
{
	// Token: 0x0400050A RID: 1290
	TrackPresentation,
	// Token: 0x0400050B RID: 1291
	PodiumVictory,
	// Token: 0x0400050C RID: 1292
	PodiumDefeat,
	// Token: 0x0400050D RID: 1293
	InterRace
}

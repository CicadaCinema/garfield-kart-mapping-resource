﻿using System;

// Token: 0x020001AD RID: 429
public class MenuRewardsHatShown : MenuRewards
{
	// Token: 0x06000B7F RID: 2943 RVA: 0x0004D078 File Offset: 0x0004B278
	public override void OnEnter()
	{
		base.OnEnter();
		this._hats = Singleton<RewardManager>.Instance.PopLockedHats();
		this.LbMessage.text = string.Format(Localization.instance.Get("MENU_REWARDS_HATS_GROUPE"), Singleton<GameSaveManager>.Instance.GetCollectedCoins());
	}

	// Token: 0x06000B80 RID: 2944 RVA: 0x0004D0CC File Offset: 0x0004B2CC
	public override void OnGoNext()
	{
		foreach (string text in this._hats)
		{
			if (text != null)
			{
				Singleton<GameSaveManager>.Instance.SetHatState(text, E_UnlockableItemSate.NewLocked, false);
			}
		}
		base.OnGoNext();
	}

	// Token: 0x04000B42 RID: 2882
	private string[] _hats;
}

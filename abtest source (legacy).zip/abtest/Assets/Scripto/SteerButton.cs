﻿using System;
using UnityEngine;

// Token: 0x02000127 RID: 295
public class SteerButton : MonoBehaviour
{
	// Token: 0x0600080E RID: 2062 RVA: 0x0003CEC4 File Offset: 0x0003B0C4
	public void Start()
	{
		BoxCollider boxCollider = base.collider as BoxCollider;
		this.m_pBounds.center = boxCollider.center;
		this.m_pBounds.width = boxCollider.size.x;
		this.m_pBounds.height = boxCollider.size.y;
	}

	// Token: 0x0600080F RID: 2063 RVA: 0x0003CF28 File Offset: 0x0003B128
	public void Update()
	{
		foreach (Touch touch in Input.touches)
		{
			if (this.m_pBounds.Contains(touch.position))
			{
				if (this.Left)
				{
					Singleton<InputManager>.Instance.NullSafeAct(new Action<EAction, float>(Singleton<InputManager>.Instance.SetAction), EAction.Steer, -1f);
				}
				else
				{
					Singleton<InputManager>.Instance.NullSafeAct(new Action<EAction, float>(Singleton<InputManager>.Instance.SetAction), EAction.Steer, 1f);
				}
				break;
			}
		}
	}

	// Token: 0x06000810 RID: 2064 RVA: 0x00003B80 File Offset: 0x00001D80
	public void OnEnter()
	{
	}

	// Token: 0x04000852 RID: 2130
	public bool Left;

	// Token: 0x04000853 RID: 2131
	private Rect m_pBounds;
}

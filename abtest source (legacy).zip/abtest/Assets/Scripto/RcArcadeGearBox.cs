﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000204 RID: 516
public class RcArcadeGearBox : RcGearBox
{
	// Token: 0x06000E01 RID: 3585 RVA: 0x0000B9C9 File Offset: 0x00009BC9
	public RcArcadeGearBox()
	{
		this.m_vAcceleration = new List<float>();
		this.m_vSpeed = new List<float>();
		this.m_iGear = 0;
		this.m_fReverseMaxSpeedKph = 0f;
	}

	// Token: 0x06000E02 RID: 3586 RVA: 0x0000B9F9 File Offset: 0x00009BF9
	public override float GetBackwardMaxSpeed()
	{
		return -this.m_fReverseMaxSpeedKph / 3.6f;
	}

	// Token: 0x06000E03 RID: 3587 RVA: 0x0000BA08 File Offset: 0x00009C08
	public override int GetCurrentGear()
	{
		return this.m_iGear;
	}

	// Token: 0x06000E04 RID: 3588 RVA: 0x0000BA10 File Offset: 0x00009C10
	public virtual void Awake()
	{
		this.m_pVehicle = base.transform.parent.GetComponentInChildren<RcVehicle>();
	}

	// Token: 0x06000E05 RID: 3589 RVA: 0x0005ACB4 File Offset: 0x00058EB4
	public override float ComputeAcceleration(float _speedMS)
	{
		if (_speedMS < 0f)
		{
			return 0f;
		}
		int i;
		for (i = 0; i < this.m_vSpeed.Count; i++)
		{
			if (_speedMS < this.GetSpeed(i) / 3.6f)
			{
				break;
			}
		}
		this.m_iGear = i;
		if (i == this.m_vSpeed.Count)
		{
			this.m_iGear--;
		}
		if (i != 0)
		{
			i--;
		}
		if (i < 0 || i >= this.m_vSpeed.Count)
		{
			return 0f;
		}
		for (i = 0; i < this.m_vSpeed.Count; i++)
		{
			if (_speedMS < this.GetSpeed(i))
			{
				break;
			}
		}
		i--;
		if (i < 0 || i >= this.m_vSpeed.Count)
		{
			return 0f;
		}
		if (this.m_vAcceleration.Count != this.m_vSpeed.Count || i >= this.m_vSpeed.Count - 1)
		{
			return 0f;
		}
		float speed = this.GetSpeed(i + 1);
		if (speed < this.GetSpeed(i))
		{
			this.m_vSpeed[i + 1] = this.GetSpeed(i) + 0.01f;
			return 0f;
		}
		float num = (speed - this.GetSpeed(i)) / 3.6f;
		float acceleration = this.GetAcceleration(i + 1);
		if (acceleration < this.GetAcceleration(i))
		{
			this.m_vAcceleration[i + 1] = this.GetAcceleration(i) + 0.01f;
			return 0f;
		}
		return num / (acceleration - this.GetAcceleration(i));
	}

	// Token: 0x06000E06 RID: 3590 RVA: 0x0000BA28 File Offset: 0x00009C28
	public override float GetMaxSpeed()
	{
		if (this.m_vSpeed.Count > 0)
		{
			return this.GetSpeed(this.m_vSpeed.Count - 1) / 3.6f;
		}
		return 0f;
	}

	// Token: 0x06000E07 RID: 3591 RVA: 0x0005AE70 File Offset: 0x00059070
	public override float ComputeRpm(float speedMs)
	{
		int i;
		for (i = 0; i < this.m_vSpeed.Count; i++)
		{
			if (Mathf.Abs(speedMs) < this.GetSpeed(i) / 3.6f)
			{
				break;
			}
		}
		if (i != 0)
		{
			i--;
		}
		if (i < this.m_vSpeed.Count - 1)
		{
			if (i == 0)
			{
				return RcUtils.LinearInterpolation(this.GetSpeed(i), 2000f, this.GetSpeed(i + 1), 6000f, 3.6f * Mathf.Abs(speedMs));
			}
			return RcUtils.LinearInterpolation(this.GetSpeed(i), 3500f, this.GetSpeed(i + 1), 6000f, 3.6f * Mathf.Abs(speedMs));
		}
		else
		{
			if (i > 0)
			{
				return RcUtils.LinearInterpolation(this.GetSpeed(i - 1), 3500f, this.GetSpeed(i), 6000f, 3.6f * Mathf.Abs(speedMs));
			}
			return 2000f;
		}
	}

	// Token: 0x06000E08 RID: 3592 RVA: 0x00003B7D File Offset: 0x00001D7D
	public override bool IsGoingTooFast()
	{
		return false;
	}

	// Token: 0x06000E09 RID: 3593 RVA: 0x0000BA5A File Offset: 0x00009C5A
	public virtual float GetSpeed(int _Index)
	{
		return this.m_vSpeed[_Index];
	}

	// Token: 0x06000E0A RID: 3594 RVA: 0x0000BA68 File Offset: 0x00009C68
	public virtual float GetAcceleration(int _Index)
	{
		return this.m_vAcceleration[_Index];
	}

	// Token: 0x04000D84 RID: 3460
	public List<float> m_vAcceleration;

	// Token: 0x04000D85 RID: 3461
	public List<float> m_vSpeed;

	// Token: 0x04000D86 RID: 3462
	private int m_iGear;

	// Token: 0x04000D87 RID: 3463
	public float m_fReverseMaxSpeedKph;

	// Token: 0x04000D88 RID: 3464
	protected RcVehicle m_pVehicle;
}

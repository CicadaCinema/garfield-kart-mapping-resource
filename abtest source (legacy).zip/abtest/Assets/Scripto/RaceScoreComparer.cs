﻿using System;
using System.Collections.Generic;

// Token: 0x0200017A RID: 378
internal class RaceScoreComparer : IComparer<Tuple<int, int>>
{
	// Token: 0x06000A1C RID: 2588 RVA: 0x00008E05 File Offset: 0x00007005
	public int Compare(int pScore1, int pScore2)
	{
		return pScore2.CompareTo(pScore1);
	}

	// Token: 0x06000A1D RID: 2589 RVA: 0x00008E0F File Offset: 0x0000700F
	public int Compare(Tuple<int, int> x, Tuple<int, int> y)
	{
		return this.Compare(x.Item2, y.Item2);
	}
}

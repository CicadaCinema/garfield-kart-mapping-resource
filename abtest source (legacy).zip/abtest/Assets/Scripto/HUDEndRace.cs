﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200011F RID: 287
public abstract class HUDEndRace : MonoBehaviour
{
	// Token: 0x060007ED RID: 2029 RVA: 0x0003B870 File Offset: 0x00039A70
	public virtual void Init()
	{
		UnityEngine.Object[] array = Resources.LoadAll("Character", typeof(CharacterCarac));
		foreach (UnityEngine.Object @object in array)
		{
			this.m_oCharacterList.Add((CharacterCarac)@object);
		}
		UnityEngine.Object[] array3 = Resources.LoadAll("Hat", typeof(BonusCustom));
		foreach (UnityEngine.Object object2 in array3)
		{
			if (object2.name.Contains("_Def"))
			{
				this.m_oHatList.Insert(0, (BonusCustom)object2);
			}
			else
			{
				this.m_oHatList.Add((BonusCustom)object2);
			}
		}
		UnityEngine.Object[] array5 = Resources.LoadAll("Kart", typeof(KartCarac));
		foreach (UnityEngine.Object object3 in array5)
		{
			this.m_oKartList.Add((KartCarac)object3);
		}
		UnityEngine.Object[] array7 = Resources.LoadAll("Kart", typeof(KartCustom));
		foreach (UnityEngine.Object object4 in array7)
		{
			if (object4.name.Contains("_Def"))
			{
				this.m_oKartCustomList.Insert(0, (KartCustom)object4);
			}
			else
			{
				this.m_oKartCustomList.Add((KartCustom)object4);
			}
		}
		UnityEngine.Object[] array9 = Resources.LoadAll("Advantages", typeof(AdvantageData));
		foreach (UnityEngine.Object object5 in array9)
		{
			this.m_oAdvantagesList.Add((AdvantageData)object5);
		}
		for (int n = 0; n < 6; n++)
		{
			string text = base.gameObject.name + "/Anchor_Center/Panel" + (n + 1).ToString() + "place";
			GameObject gameObject = GameObject.Find(text + "/02LabelName");
			this.LabelCharacter.Add(gameObject.GetComponent<UILabel>());
			GameObject gameObject2 = GameObject.Find(text + "/02LabelPts");
			this.LabelPoint.Add(gameObject2.GetComponent<UILabel>());
			this.PointsToAdd.Add(-1);
			this.CurrentPointsAdded.Add(0f);
			this.BasePoints.Add(0);
			this.LabelPosition.Add(GameObject.Find(text + "/02place").GetComponent<UITexturePattern>());
			if (this.LabelPosition[n] != null)
			{
				this.LabelPosition[n].ChangeTexture(0);
			}
			GameObject gameObject3 = GameObject.Find(text + "/02PersonagePlace");
			this.BackgroundPlace.Add(gameObject3.GetComponent<UITexturePattern>());
			gameObject3 = GameObject.Find(text + "/02Personage");
			this.BackgroundPersonage.Add(gameObject3.GetComponent<UITexturePattern>());
			GameObject gameObject4 = GameObject.Find(text + "/02custom");
			this.m_Custom.Add(gameObject4);
			gameObject4 = GameObject.Find(text + "/02custom/02custom");
			this.m_CustomRarity.Add(gameObject4.GetComponent<UITexturePattern>());
			gameObject4 = GameObject.Find(text + "/02custom/02customIcon");
			this.m_CustomSprite.Add(gameObject4.GetComponent<UISprite>());
			GameObject gameObject5 = GameObject.Find(text + "/02hat");
			this.m_Hat.Add(gameObject5);
			gameObject5 = GameObject.Find(text + "/02hat/02hat");
			this.m_HatRarity.Add(gameObject5.GetComponent<UITexturePattern>());
			gameObject5 = GameObject.Find(text + "/02hat/02hatIcon");
			this.m_HatSprite.Add(gameObject5.GetComponent<UISprite>());
			GameObject gameObject6 = GameObject.Find(text + "/02iconpersonage");
			this.m_Character.Add(gameObject6.GetComponent<UISprite>());
			gameObject6 = GameObject.Find(text + "/02kartIcon");
			this.m_Kart.Add(gameObject6.GetComponent<UISprite>());
			this.m_Stars.Add(new List<GameObject>());
			for (int num = 0; num < 5; num++)
			{
				string name = text + "/stars/02star" + (num + 1);
				GameObject item = GameObject.Find(name);
				this.m_Stars[n].Add(item);
			}
			GameObject gameObject7 = GameObject.Find(text + "/02adv");
			this.m_Advantage.Add(gameObject7.GetComponent<UISprite>());
		}
		for (int num2 = 0; num2 < 3; num2++)
		{
			string name2 = base.gameObject.name + "/Anchor_TopRight/Puzzle" + (num2 + 1).ToString();
			GameObject gameObject8 = GameObject.Find(name2);
			this.m_PuzzlePieces.Add(gameObject8.GetComponent<UITexturePattern>());
		}
		GameObject gameObject9 = GameObject.Find(base.gameObject.name + "/Anchor_Center/TrackPres/Title");
		this.LabelTitle = gameObject9.GetComponent<UILabel>();
		this.DifficultySprite.ChangeTexture((int)Singleton<GameConfigurator>.Instance.Difficulty);
		if (Singleton<GameConfigurator>.Instance.ChampionShipData != null)
		{
			this.ChampionshipIcon.ChangeTexture(Singleton<GameConfigurator>.Instance.ChampionShipData.Index);
		}
		this.m_fElapsedTime = Time.time;
	}

	// Token: 0x060007EE RID: 2030 RVA: 0x0003BDFC File Offset: 0x00039FFC
	public virtual void FillPositions()
	{
		int trackIndex = this.GetTrackIndex();
		string str = Singleton<GameConfigurator>.Instance.ChampionShipData.Tracks[trackIndex];
		foreach (UITexturePattern uitexturePattern in this.BackgroundPersonage)
		{
			uitexturePattern.ChangeTexture(0);
		}
		foreach (UITexturePattern uitexturePattern2 in this.BackgroundPlace)
		{
			uitexturePattern2.ChangeTexture(0);
		}
		for (int i = 0; i < 3; i++)
		{
			string pPiece = str + "_" + i.ToString();
			this.m_PuzzlePieces[i].ChangeTexture((!Singleton<GameSaveManager>.Instance.IsPuzzlePieceUnlocked(pPiece)) ? 0 : 1);
		}
		PlayerData[] playerDataList = Singleton<GameConfigurator>.Instance.PlayerDataList;
		bool pEquality = false;
		int humanPlayerVehicleId = Singleton<GameManager>.Instance.GameMode.GetHumanPlayerVehicleId();
		for (int j = 0; j < Singleton<GameConfigurator>.Instance.RankingManager.RaceScoreCount(); j++)
		{
			int num;
			int iScore;
			int iTotalScore;
			this.GetScoreInfos(j, out num, out iScore, out iTotalScore, out pEquality);
			PlayerData playerData = null;
			for (int k = 0; k < playerDataList.Length; k++)
			{
				if (playerDataList[k].KartIndex == num)
				{
					playerData = playerDataList[k];
					break;
				}
			}
			this.FillRank(playerData, iScore, iTotalScore, j, pEquality, humanPlayerVehicleId == playerData.KartIndex);
		}
		if (LogManager.Instance != null)
		{
			this.m_fElapsedTime = Time.time - this.m_fElapsedTime;
			if (!(this is HUDChampionsShipRanking) && Singleton<GameConfigurator>.Instance.CurrentTrackIndex >= 0 && Singleton<GameConfigurator>.Instance.CurrentTrackIndex < Singleton<GameConfigurator>.Instance.ChampionShipData.TracksName.Length)
			{
				RaceScoreData scoreData = Singleton<GameConfigurator>.Instance.RankingManager.GetScoreData(Singleton<GameManager>.Instance.GameMode.GetHumanPlayerVehicleId());
				KartHumanController componentInChildren = Singleton<GameManager>.Instance.GameMode.GetHumanPlayer().GetComponentInChildren<KartHumanController>();
				if (componentInChildren != null)
				{
				}
			}
		}
	}

	// Token: 0x060007EF RID: 2031 RVA: 0x0003C054 File Offset: 0x0003A254
	private void FillRank(PlayerData pData, int iScore, int iTotalScore, int pPosition, bool pEquality, bool bHighlight)
	{
		if (pData != null)
		{
			this.LabelCharacter[pPosition].text = pData.Character.ToString();
			foreach (CharacterCarac characterCarac in this.m_oCharacterList)
			{
				if (characterCarac.Owner == pData.Character)
				{
					this.m_Character[pPosition].spriteName = characterCarac.spriteName;
					break;
				}
			}
			foreach (KartCarac kartCarac in this.m_oKartList)
			{
				if (kartCarac.Owner == pData.Character)
				{
					this.m_Kart[pPosition].spriteName = kartCarac.spriteName;
					break;
				}
			}
			if (pData.Hat.Contains("_Def"))
			{
				this.m_Hat[pPosition].SetActive(false);
			}
			else
			{
				this.m_Hat[pPosition].SetActive(true);
				foreach (BonusCustom bonusCustom in this.m_oHatList)
				{
					if (bonusCustom.name == pData.Hat)
					{
						this.m_HatSprite[pPosition].spriteName = bonusCustom.spriteName;
						this.m_HatRarity[pPosition].ChangeTexture((int)bonusCustom.Rarity);
						break;
					}
				}
			}
			if (pData.Custom.Contains("_Def"))
			{
				this.m_Custom[pPosition].SetActive(false);
			}
			else
			{
				this.m_Custom[pPosition].SetActive(true);
				foreach (KartCustom kartCustom in this.m_oKartCustomList)
				{
					if (kartCustom.name == pData.Custom)
					{
						this.m_CustomSprite[pPosition].spriteName = kartCustom.spriteName;
						this.m_CustomRarity[pPosition].ChangeTexture((int)kartCustom.Rarity);
						break;
					}
				}
			}
			Kart kartWithVehicleId = Singleton<GameManager>.Instance.GameMode.GetKartWithVehicleId(pData.KartIndex);
			if (kartWithVehicleId)
			{
				RaceScoreData scoreData = Singleton<GameConfigurator>.Instance.RankingManager.GetScoreData(kartWithVehicleId.GetVehicleId());
				if (!scoreData.IsAI)
				{
					if (Network.peerType != NetworkPeerType.Disconnected)
					{
						this.LabelCharacter[pPosition].color = pData.CharacColor;
					}
					if (kartWithVehicleId.GetControlType() == RcVehicle.ControlType.Human)
					{
						this.LabelCharacter[pPosition].text = Singleton<GameSaveManager>.Instance.GetPseudo();
					}
					else
					{
						this.LabelCharacter[pPosition].text = pData.Pseudo;
					}
				}
				if (kartWithVehicleId.SelectedAdvantage != EAdvantage.None)
				{
					this.m_Advantage[pPosition].gameObject.SetActive(true);
					foreach (AdvantageData advantageData in this.m_oAdvantagesList)
					{
						if (advantageData.AdvantageType == kartWithVehicleId.SelectedAdvantage)
						{
							this.m_Advantage[pPosition].spriteName = advantageData.spriteName;
							break;
						}
					}
				}
				else
				{
					this.m_Advantage[pPosition].gameObject.SetActive(false);
				}
			}
			foreach (GameObject gameObject in this.m_Stars[pPosition])
			{
				gameObject.SetActive(false);
			}
			for (int i = 0; i < pData.NbStars; i++)
			{
				this.m_Stars[pPosition][i].SetActive(true);
			}
		}
		this.LabelPoint[pPosition].text = iTotalScore.ToString() + " pts";
		this.PointsToAdd[pPosition] = iScore;
		this.CurrentPointsAdded[pPosition] = (float)iTotalScore;
		this.BasePoints[pPosition] = iTotalScore;
		if (pEquality && this.LabelPosition[pPosition] != null)
		{
			this.LabelPosition[pPosition].ChangeTexture(1);
		}
		if (this.BackgroundPersonage[pPosition] && this.BackgroundPlace[pPosition])
		{
			if (bHighlight)
			{
				this.BackgroundPersonage[pPosition].ChangeTexture(2);
				this.BackgroundPlace[pPosition].ChangeTexture(2);
			}
			else
			{
				this.BackgroundPersonage[pPosition].ChangeTexture(pPosition % 2);
				this.BackgroundPlace[pPosition].ChangeTexture(pPosition % 2);
			}
		}
	}

	// Token: 0x060007F0 RID: 2032
	public abstract void GetScoreInfos(int iIndex, out int iKartIndex, out int iScore, out int iTotalScore, out bool bEquality);

	// Token: 0x060007F1 RID: 2033 RVA: 0x0000794C File Offset: 0x00005B4C
	public virtual int GetTrackIndex()
	{
		return Singleton<GameConfigurator>.Instance.CurrentTrackIndex;
	}

	// Token: 0x060007F2 RID: 2034 RVA: 0x0003C610 File Offset: 0x0003A810
	public virtual void Update()
	{
		float deltaTime = Time.deltaTime;
		if (this.PointsToAdd.Count > 0 && this.m_fDelayCounter < 1f)
		{
			this.m_fDelayCounter += deltaTime;
		}
		if (this.m_fDelayCounter >= 1f)
		{
			for (int i = 0; i < this.PointsToAdd.Count; i++)
			{
				if (this.PointsToAdd[i] + this.BasePoints[i] != (int)(this.CurrentPointsAdded[i] + 0.5f))
				{
					this.CurrentPointsAdded[i] = Tricks.ComputeInertia(this.CurrentPointsAdded[i], (float)(this.PointsToAdd[i] + this.BasePoints[i]), this.m_fInertia, deltaTime);
					this.LabelPoint[i].text = ((int)(this.CurrentPointsAdded[i] + 0.5f)).ToString() + " pts";
				}
			}
		}
	}

	// Token: 0x0400080B RID: 2059
	private float m_fInertia = 0.3f;

	// Token: 0x0400080C RID: 2060
	private float m_fDelayCounter;

	// Token: 0x0400080D RID: 2061
	private List<UILabel> LabelCharacter = new List<UILabel>();

	// Token: 0x0400080E RID: 2062
	protected List<UILabel> LabelPoint = new List<UILabel>();

	// Token: 0x0400080F RID: 2063
	private List<float> CurrentPointsAdded = new List<float>();

	// Token: 0x04000810 RID: 2064
	protected List<int> PointsToAdd = new List<int>();

	// Token: 0x04000811 RID: 2065
	protected List<int> BasePoints = new List<int>();

	// Token: 0x04000812 RID: 2066
	private List<UITexturePattern> LabelPosition = new List<UITexturePattern>();

	// Token: 0x04000813 RID: 2067
	private List<UITexturePattern> BackgroundPlace = new List<UITexturePattern>();

	// Token: 0x04000814 RID: 2068
	private List<UITexturePattern> BackgroundPersonage = new List<UITexturePattern>();

	// Token: 0x04000815 RID: 2069
	private List<UITexturePattern> m_CustomRarity = new List<UITexturePattern>();

	// Token: 0x04000816 RID: 2070
	private List<UISprite> m_CustomSprite = new List<UISprite>();

	// Token: 0x04000817 RID: 2071
	private List<GameObject> m_Custom = new List<GameObject>();

	// Token: 0x04000818 RID: 2072
	private List<UITexturePattern> m_HatRarity = new List<UITexturePattern>();

	// Token: 0x04000819 RID: 2073
	private List<UISprite> m_HatSprite = new List<UISprite>();

	// Token: 0x0400081A RID: 2074
	private List<GameObject> m_Hat = new List<GameObject>();

	// Token: 0x0400081B RID: 2075
	private List<UISprite> m_Character = new List<UISprite>();

	// Token: 0x0400081C RID: 2076
	private List<UISprite> m_Kart = new List<UISprite>();

	// Token: 0x0400081D RID: 2077
	private List<List<GameObject>> m_Stars = new List<List<GameObject>>();

	// Token: 0x0400081E RID: 2078
	protected List<UISprite> m_Advantage = new List<UISprite>();

	// Token: 0x0400081F RID: 2079
	private List<UITexturePattern> m_PuzzlePieces = new List<UITexturePattern>();

	// Token: 0x04000820 RID: 2080
	public UITexturePattern DifficultySprite;

	// Token: 0x04000821 RID: 2081
	public UITexturePattern ChampionshipIcon;

	// Token: 0x04000822 RID: 2082
	protected UILabel LabelTitle;

	// Token: 0x04000823 RID: 2083
	private List<CharacterCarac> m_oCharacterList = new List<CharacterCarac>();

	// Token: 0x04000824 RID: 2084
	private List<BonusCustom> m_oHatList = new List<BonusCustom>();

	// Token: 0x04000825 RID: 2085
	private List<KartCarac> m_oKartList = new List<KartCarac>();

	// Token: 0x04000826 RID: 2086
	private List<KartCustom> m_oKartCustomList = new List<KartCustom>();

	// Token: 0x04000827 RID: 2087
	private List<AdvantageData> m_oAdvantagesList = new List<AdvantageData>();

	// Token: 0x04000828 RID: 2088
	private float m_fElapsedTime;
}

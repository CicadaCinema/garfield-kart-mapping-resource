﻿using System;
using UnityEngine;

// Token: 0x020000C4 RID: 196
public class SceneEntryPoint : MonoBehaviour
{
	// Token: 0x0600052D RID: 1325 RVA: 0x00003B80 File Offset: 0x00001D80
	public void Start()
	{
	}
}

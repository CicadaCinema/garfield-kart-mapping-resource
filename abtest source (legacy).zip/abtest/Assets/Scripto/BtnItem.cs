﻿using System;
using UnityEngine;

// Token: 0x0200018D RID: 397
public class BtnItem : AbstractMenu
{
	// Token: 0x06000AB5 RID: 2741 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void Awake()
	{
	}

	// Token: 0x06000AB6 RID: 2742 RVA: 0x00048C60 File Offset: 0x00046E60
	public override void Update()
	{
		base.Update();
		if (this.m_oCheckBox && this.m_oCheckBox.isChecked && this.m_oMenuParent && this.m_oDragPanel && this.m_oDragPanel)
		{
			UIPanel component = this.m_oDragPanel.GetComponent<UIPanel>();
			Bounds bounds = NGUIMath.CalculateRelativeWidgetBounds(this.m_oDragPanel.transform, base.transform);
			Vector3 vector = component.CalculateConstrainOffset(bounds.min, bounds.max);
			float num = (bounds.max.x - bounds.min.x) * 0.4f;
			MenuSelectKart component2 = this.m_oMenuParent.GetComponent<MenuSelectKart>();
			component2.SetPanelTextAlpha(1f - Math.Min(num, Math.Max(0f, Math.Abs(vector.x) - (bounds.max.x - bounds.min.x) * 0.2f)) / num);
		}
	}

	// Token: 0x06000AB7 RID: 2743 RVA: 0x00048D90 File Offset: 0x00046F90
	public void Init(GameObject oMenuParent, GameObject oDragPanel, string sSpriteName, ERarity eRarity, int iPrice, UnityEngine.Object oData, E_UnlockableItemSate eState, bool bSelected)
	{
		this.m_oMenuParent = oMenuParent;
		this.m_oData = oData;
		this.m_oDragPanel = oDragPanel;
		Transform transform = base.transform.FindChild("Button");
		if (transform)
		{
			UIDragPanelContents component = transform.gameObject.GetComponent<UIDragPanelContents>();
			if (component)
			{
				component.draggablePanel = oDragPanel.GetComponent<UIDraggablePanel>();
			}
			Transform transform2;
			if (eState != E_UnlockableItemSate.Hidden)
			{
				transform2 = transform.FindChild("Icon");
				if (transform2)
				{
					UISprite component2 = transform2.GetComponent<UISprite>();
					if (component2)
					{
						component2.atlas = this.m_oAtlas;
						component2.spriteName = sSpriteName;
					}
				}
			}
			else
			{
				transform.GetComponent<BoxCollider>().enabled = false;
			}
			transform2 = transform.FindChild("IconNew");
			if (transform2)
			{
				if (eState == E_UnlockableItemSate.NewLocked || eState == E_UnlockableItemSate.NewUnlocked)
				{
					transform2.gameObject.SetActive(true);
				}
				else
				{
					transform2.gameObject.SetActive(false);
				}
			}
			transform2 = transform.FindChild("Rarity");
			if (transform2)
			{
				UITexturePattern component3 = transform2.GetComponent<UITexturePattern>();
				if (component3)
				{
					component3.ChangeTexture(Tricks.LogBase2(Math.Max(1, (int)eRarity)));
				}
			}
			transform2 = transform.FindChild("PriceTag");
			if (transform2)
			{
				if ((eState == E_UnlockableItemSate.Locked || eState == E_UnlockableItemSate.NewLocked) && iPrice > 0)
				{
					UILabel component4 = transform2.GetComponent<UILabel>();
					if (component4)
					{
						component4.text = string.Format("{0}", iPrice);
					}
					transform2.gameObject.SetActive(true);
					transform2 = transform.FindChild("BgPrice");
					if (transform2)
					{
						transform2.gameObject.SetActive(true);
					}
					transform2 = transform.FindChild("IconMoney");
					if (transform2)
					{
						transform2.gameObject.SetActive(true);
					}
				}
				else
				{
					transform2.gameObject.SetActive(false);
					transform2 = transform.FindChild("BgPrice");
					if (transform2)
					{
						transform2.gameObject.SetActive(false);
					}
					transform2 = transform.FindChild("IconMoney");
					if (transform2)
					{
						transform2.gameObject.SetActive(false);
					}
				}
			}
			this.m_oCheckBox = transform.GetComponent<UICheckbox>();
			if (this.m_oCheckBox)
			{
				this.m_oCheckBox.isChecked = bSelected;
				this.m_oCheckBox.radioButtonRoot = oDragPanel.transform;
			}
		}
		this.OnEnter();
	}

	// Token: 0x06000AB8 RID: 2744 RVA: 0x00049010 File Offset: 0x00047210
	public void OnClick()
	{
		if (this.m_oCheckBox && !this.m_oCheckBox.isChecked)
		{
			this.m_oCheckBox.isChecked = true;
		}
		if (this.m_oMenuParent)
		{
			this.m_oMenuParent.SendMessage("OnClickItem", this.m_oData, SendMessageOptions.DontRequireReceiver);
		}
		UIPanel component = this.m_oDragPanel.GetComponent<UIPanel>();
		Bounds bounds = NGUIMath.CalculateRelativeWidgetBounds(this.m_oDragPanel.transform, base.transform);
		Vector3 b = component.CalculateConstrainOffset(bounds.min, bounds.max);
		SpringPanel.Begin(component.gameObject, this.m_oDragPanel.transform.localPosition + b, 13f);
	}

	// Token: 0x06000AB9 RID: 2745 RVA: 0x000095CB File Offset: 0x000077CB
	public bool IsDataEqual(UnityEngine.Object oData)
	{
		return this.m_oData == oData;
	}

	// Token: 0x06000ABA RID: 2746 RVA: 0x000490DC File Offset: 0x000472DC
	public void RefreshState(E_UnlockableItemSate eState)
	{
		Transform transform = base.transform.FindChild("Button");
		if (transform)
		{
			if (eState != E_UnlockableItemSate.Hidden)
			{
				transform.GetComponent<BoxCollider>().enabled = true;
			}
			Transform transform2 = transform.FindChild("IconNew");
			if (transform2)
			{
				if (eState == E_UnlockableItemSate.NewLocked || eState == E_UnlockableItemSate.NewUnlocked)
				{
					transform2.gameObject.SetActive(true);
				}
				else
				{
					transform2.gameObject.SetActive(false);
				}
			}
			transform2 = transform.FindChild("PriceTag");
			if (transform2 && (eState == E_UnlockableItemSate.Unlocked || eState == E_UnlockableItemSate.NewUnlocked))
			{
				transform2.gameObject.SetActive(false);
				transform2 = transform.FindChild("BgPrice");
				if (transform2)
				{
					transform2.gameObject.SetActive(false);
				}
				transform2 = transform.FindChild("IconMoney");
				if (transform2)
				{
					transform2.gameObject.SetActive(false);
				}
			}
		}
	}

	// Token: 0x06000ABB RID: 2747 RVA: 0x000095E5 File Offset: 0x000077E5
	public UnityEngine.Object GetData()
	{
		return this.m_oData;
	}

	// Token: 0x04000A89 RID: 2697
	private GameObject m_oMenuParent;

	// Token: 0x04000A8A RID: 2698
	private UnityEngine.Object m_oData;

	// Token: 0x04000A8B RID: 2699
	private GameObject m_oDragPanel;

	// Token: 0x04000A8C RID: 2700
	private UICheckbox m_oCheckBox;

	// Token: 0x04000A8D RID: 2701
	public UIAtlas m_oAtlas;
}

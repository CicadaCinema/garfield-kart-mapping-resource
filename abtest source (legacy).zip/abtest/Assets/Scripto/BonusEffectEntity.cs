﻿using System;
using UnityEngine;

// Token: 0x020000CC RID: 204
public class BonusEffectEntity : BonusEntity
{
	// Token: 0x06000555 RID: 1365 RVA: 0x00005D62 File Offset: 0x00003F62
	public override void Awake()
	{
		base.Awake();
		if (base.renderer != null)
		{
			base.renderer.enabled = true;
		}
		this.m_pCollider.enabled = true;
		this.m_bActive = true;
	}

	// Token: 0x06000556 RID: 1366 RVA: 0x00005D9A File Offset: 0x00003F9A
	public override void Update()
	{
		base.Update();
	}

	// Token: 0x06000557 RID: 1367 RVA: 0x0002B374 File Offset: 0x00029574
	public override void DoOnTriggerEnter(GameObject other, int otherlayer)
	{
		if (this.m_bActive)
		{
			int num = 1 << otherlayer;
			if ((num & this.layer) != 0)
			{
				this.OnGoodCollision(other);
			}
		}
	}

	// Token: 0x06000558 RID: 1368 RVA: 0x0002B3AC File Offset: 0x000295AC
	public virtual void OnGoodCollision(GameObject other)
	{
		Kart componentInChildren = other.GetComponentInChildren<Kart>();
		if (componentInChildren)
		{
			componentInChildren.GetBonusMgr().GetBonusEffectMgr().ActivateBonusEffect(this.BonusEffect);
		}
		if (this.ReactivationDelay > 0f)
		{
			this.SetActive(false);
		}
	}

	// Token: 0x06000559 RID: 1369 RVA: 0x00005DA2 File Offset: 0x00003FA2
	public override void DoDestroy()
	{
		base.DoDestroy();
	}

	// Token: 0x0600055A RID: 1370 RVA: 0x00005DAA File Offset: 0x00003FAA
	public override void Launch()
	{
		base.Launch();
	}

	// Token: 0x0400052C RID: 1324
	public LayerMask layer;

	// Token: 0x0400052D RID: 1325
	public EBonusEffect BonusEffect;
}

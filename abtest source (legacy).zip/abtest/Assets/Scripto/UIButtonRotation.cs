﻿using System;
using UnityEngine;

// Token: 0x0200000D RID: 13
[AddComponentMenu("NGUI/Interaction/Button Rotation")]
public class UIButtonRotation : MonoBehaviour
{
	// Token: 0x06000039 RID: 57 RVA: 0x0000DEA8 File Offset: 0x0000C0A8
	private void Start()
	{
		if (!this.mStarted)
		{
			this.mStarted = true;
			if (this.tweenTarget == null)
			{
				this.tweenTarget = base.transform;
			}
			this.mRot = this.tweenTarget.localRotation;
		}
	}

	// Token: 0x0600003A RID: 58 RVA: 0x000024CC File Offset: 0x000006CC
	private void OnEnable()
	{
		if (this.mStarted && this.mHighlighted)
		{
			this.OnHover(UICamera.IsHighlighted(base.gameObject));
		}
	}

	// Token: 0x0600003B RID: 59 RVA: 0x0000DEF8 File Offset: 0x0000C0F8
	private void OnDisable()
	{
		if (this.mStarted && this.tweenTarget != null)
		{
			TweenRotation component = this.tweenTarget.GetComponent<TweenRotation>();
			if (component != null)
			{
				component.rotation = this.mRot;
				component.enabled = false;
			}
		}
	}

	// Token: 0x0600003C RID: 60 RVA: 0x0000DF4C File Offset: 0x0000C14C
	private void OnPress(bool isPressed)
	{
		if (base.enabled)
		{
			if (!this.mStarted)
			{
				this.Start();
			}
			TweenRotation.Begin(this.tweenTarget.gameObject, this.duration, (!isPressed) ? ((!UICamera.IsHighlighted(base.gameObject)) ? this.mRot : (this.mRot * Quaternion.Euler(this.hover))) : (this.mRot * Quaternion.Euler(this.pressed))).method = UITweener.Method.EaseInOut;
		}
	}

	// Token: 0x0600003D RID: 61 RVA: 0x0000DFE4 File Offset: 0x0000C1E4
	private void OnHover(bool isOver)
	{
		if (base.enabled)
		{
			if (!this.mStarted)
			{
				this.Start();
			}
			TweenRotation.Begin(this.tweenTarget.gameObject, this.duration, (!isOver) ? this.mRot : (this.mRot * Quaternion.Euler(this.hover))).method = UITweener.Method.EaseInOut;
			this.mHighlighted = isOver;
		}
	}

	// Token: 0x04000035 RID: 53
	public Transform tweenTarget;

	// Token: 0x04000036 RID: 54
	public Vector3 hover = Vector3.zero;

	// Token: 0x04000037 RID: 55
	public Vector3 pressed = Vector3.zero;

	// Token: 0x04000038 RID: 56
	public float duration = 0.2f;

	// Token: 0x04000039 RID: 57
	private Quaternion mRot;

	// Token: 0x0400003A RID: 58
	private bool mStarted;

	// Token: 0x0400003B RID: 59
	private bool mHighlighted;
}

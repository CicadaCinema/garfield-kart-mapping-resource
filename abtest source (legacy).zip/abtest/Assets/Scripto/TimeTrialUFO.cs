﻿using System;
using UnityEngine;

// Token: 0x02000166 RID: 358
public class TimeTrialUFO : MonoBehaviour
{
	// Token: 0x0600099F RID: 2463 RVA: 0x00008A1F File Offset: 0x00006C1F
	public void Awake()
	{
		this.m_pTransform = base.transform;
		base.renderer.enabled = false;
	}

	// Token: 0x060009A0 RID: 2464 RVA: 0x00043744 File Offset: 0x00041944
	public void FixedUpdate()
	{
		if (!this._Active)
		{
			return;
		}
		if (this.m_cPathToTake == null)
		{
			return;
		}
		int num = (int)(Time.fixedDeltaTime * 1000f);
		float d = (float)num / 1000f;
		this.m_cPathToTake.UpdatePathPosition(ref this.m_PathPosition, this.m_pTransform.position, 3, 1, false, true);
		this.m_NextPathPosition = this.m_PathPosition;
		if (this.FirstDistanceToPath == 0f)
		{
			this.FirstDistanceToPath = 5f + Mathf.Clamp(Mathf.Abs(this.m_cPathToTake.GetSignedDistToSegment2D(this.m_pTransform.position, this.m_PathPosition.index, Vector3.up)), 0f, 50f);
		}
		else if (this.FirstDistanceToPath > 5f && Mathf.Abs(this.m_cPathToTake.GetSignedDistToSegment2D(this.m_pTransform.position, this.m_PathPosition.index, Vector3.up)) < 1f)
		{
			this.FirstDistanceToPath = 5f;
		}
		float firstDistanceToPath = this.FirstDistanceToPath;
		Vector3 a = this.m_cPathToTake.MoveOnPath(ref this.m_NextPathPosition, ref firstDistanceToPath, true) + Vector3.up * this.UfoHeight;
		this.m_Direction = (a - this.m_pTransform.position).normalized;
		if (this.m_Direction != Vector3.zero)
		{
			Quaternion quaternion = default(Quaternion);
			quaternion = Quaternion.LookRotation(this.m_Direction);
			if (this.m_pTransform.rotation != quaternion)
			{
				this.m_pTransform.rotation = quaternion;
			}
			this.m_pTransform.position += d * (this.m_Direction * this.m_fCurrentSpeed);
		}
		if (this.m_iNbLap < 0)
		{
			this.m_fCurrentSpeed = this.m_fBaseSpeed;
		}
		else
		{
			this.m_iTimeToBeatMs -= num;
			float num2 = this.m_cPathToTake.GetDistToEndOfPath(this.m_NextPathPosition.index, this.m_NextPathPosition.ratio);
			int num3 = this.m_iNbLap;
			if (!this.m_bFirstStartCross && this.m_NextPathPosition.index == 0)
			{
				num3--;
			}
			num2 += this.m_fPathLength * (float)num3 - this.m_fCrossDistance;
			if (num2 > 1f && this.m_iTimeToBeatMs > 200)
			{
				this.m_fCurrentSpeed = num2 / ((float)this.m_iTimeToBeatMs / 1000f);
			}
		}
	}

	// Token: 0x060009A1 RID: 2465 RVA: 0x000439E4 File Offset: 0x00041BE4
	public void Place()
	{
		GameObject gameObject = GameObject.Find("Race");
		this.m_Race = null;
		if (gameObject != null)
		{
			this.m_Race = gameObject.GetComponent<RcRace>();
		}
		GameObject gameObject2 = GameObject.Find("Paths" + Singleton<GameConfigurator>.Instance.StartScene + "(Clone)");
		if (gameObject2 != null)
		{
			AIPathHandler component = gameObject2.GetComponent<AIPathHandler>();
			if (component)
			{
				this.m_cPathToTake = component.GetFirstPath(E_PathType.GOOD);
			}
		}
		if (this.m_cPathToTake != null)
		{
			GameObject gameObject3 = GameObject.Find("Start");
			if (gameObject3 != null)
			{
				Transform child = gameObject3.transform.GetChild(gameObject3.transform.GetChildCount() - 1);
				this.m_pTransform.position = child.position + Vector3.up * this.UfoHeight + child.right * this.XOffset;
			}
			this.m_cPathToTake.UpdatePathPosition(ref this.m_PathPosition, this.m_pTransform.position, 0, 0, false, true);
			this.m_fPathLength = this.m_cPathToTake.GetTotalLength(true);
			float num = this.m_cPathToTake.GetDistToEndOfPath(this.m_PathPosition.index, this.m_PathPosition.ratio);
			this.m_iNbLap = this.m_Race.GetRaceNbLap();
			num += this.m_fPathLength * (float)this.m_iNbLap;
			string startScene = Singleton<GameConfigurator>.Instance.StartScene;
			TimeTrialConfig component2 = this.m_Race.GetComponent<TimeTrialConfig>();
			E_TimeTrialMedal medal = Singleton<GameSaveManager>.Instance.GetMedal(startScene, true);
			this.m_iTimeToBeatMs = 0;
			switch (medal)
			{
			case E_TimeTrialMedal.None:
				this.m_iTimeToBeatMs = component2.Bronze;
				break;
			case E_TimeTrialMedal.Bronze:
				this.m_iTimeToBeatMs = component2.Silver;
				break;
			case E_TimeTrialMedal.Silver:
				this.m_iTimeToBeatMs = component2.Gold;
				break;
			case E_TimeTrialMedal.Gold:
				this.m_iTimeToBeatMs = component2.Platinium;
				break;
			case E_TimeTrialMedal.Platinium:
				Singleton<GameSaveManager>.Instance.GetTimeTrialRecord(startScene, ref this.m_iTimeToBeatMs);
				break;
			default:
				this.m_iTimeToBeatMs = 1;
				break;
			}
			this.m_fCurrentSpeed = num / ((float)this.m_iTimeToBeatMs / 1000f);
			this.m_fBaseSpeed = this.m_fCurrentSpeed;
			this.m_bFirstStartCross = false;
		}
		base.renderer.enabled = true;
	}

	// Token: 0x060009A2 RID: 2466 RVA: 0x00008A39 File Offset: 0x00006C39
	public void Launch()
	{
		this._Active = true;
	}

	// Token: 0x060009A3 RID: 2467 RVA: 0x00043C4C File Offset: 0x00041E4C
	public void CrossStartLine()
	{
		if (!this.m_bFirstStartCross)
		{
			this.m_bFirstStartCross = true;
		}
		if (this.m_iNbLap == 0)
		{
		}
		this.m_iNbLap--;
		this.m_fCrossDistance = this.m_cPathToTake.GetDistToEndOfPath(this.m_NextPathPosition.index, this.m_NextPathPosition.ratio);
		if (this.m_fCrossDistance > this.m_fPathLength * 0.5f)
		{
			this.m_fCrossDistance -= this.m_fPathLength;
		}
	}

	// Token: 0x040009D5 RID: 2517
	private RcRace m_Race;

	// Token: 0x040009D6 RID: 2518
	private RcFastPath m_cPathToTake;

	// Token: 0x040009D7 RID: 2519
	private PathPosition m_PathPosition = PathPosition.UNDEFINED_POSITION;

	// Token: 0x040009D8 RID: 2520
	private PathPosition m_NextPathPosition = PathPosition.UNDEFINED_POSITION;

	// Token: 0x040009D9 RID: 2521
	private float FirstDistanceToPath;

	// Token: 0x040009DA RID: 2522
	private float m_fCurrentSpeed;

	// Token: 0x040009DB RID: 2523
	protected Vector3 m_Direction = Vector3.zero;

	// Token: 0x040009DC RID: 2524
	public float UfoHeight = 3f;

	// Token: 0x040009DD RID: 2525
	private bool _Active;

	// Token: 0x040009DE RID: 2526
	private Transform m_pTransform;

	// Token: 0x040009DF RID: 2527
	private int m_iTimeToBeatMs;

	// Token: 0x040009E0 RID: 2528
	private int m_iNbLap;

	// Token: 0x040009E1 RID: 2529
	private float m_fPathLength;

	// Token: 0x040009E2 RID: 2530
	private bool m_bFirstStartCross;

	// Token: 0x040009E3 RID: 2531
	private float m_fBaseSpeed;

	// Token: 0x040009E4 RID: 2532
	private float m_fCrossDistance;

	// Token: 0x040009E5 RID: 2533
	public float XOffset;
}

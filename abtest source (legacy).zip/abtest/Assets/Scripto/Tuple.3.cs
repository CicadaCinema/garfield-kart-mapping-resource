﻿using System;

// Token: 0x02000257 RID: 599
[Serializable]
public class Tuple<T1, T2, T3> : Tuple<T1, T2>
{
	// Token: 0x0600107C RID: 4220 RVA: 0x000677E8 File Offset: 0x000659E8
	public Tuple() : this(default(T1), default(T2), default(T3))
	{
	}

	// Token: 0x0600107D RID: 4221 RVA: 0x0000D187 File Offset: 0x0000B387
	public Tuple(T1 pItem1, T2 pItem2, T3 pItem3) : base(pItem1, pItem2)
	{
		this.Item3 = pItem3;
	}

	// Token: 0x04000FBC RID: 4028
	public T3 Item3;
}

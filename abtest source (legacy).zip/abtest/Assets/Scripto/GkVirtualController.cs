﻿using System;
using UnityEngine;

// Token: 0x020000F2 RID: 242
public class GkVirtualController : RcVirtualController
{
	// Token: 0x060006A3 RID: 1699 RVA: 0x00006B16 File Offset: 0x00004D16
	public override void Turn()
	{
		base.GetVehicle().Turn(this.m_fWantedSteer - this.Influence, false);
	}

	// Token: 0x0400068C RID: 1676
	[HideInInspector]
	public float Influence;
}

﻿using System;
using UnityEngine;

// Token: 0x020000EF RID: 239
public class UFOAnimation : MonoBehaviour
{
	// Token: 0x06000683 RID: 1667 RVA: 0x00006A28 File Offset: 0x00004C28
	public void Start()
	{
		this.m_pParent = base.transform.parent.GetComponent<UFO>();
	}

	// Token: 0x06000684 RID: 1668 RVA: 0x00006A40 File Offset: 0x00004C40
	public void DoLeaveFinished()
	{
		if (this.m_pParent)
		{
			this.m_pParent.Leave();
		}
	}

	// Token: 0x06000685 RID: 1669 RVA: 0x00006A5D File Offset: 0x00004C5D
	public void DoLaunchFinished()
	{
		if (this.m_pParent)
		{
			this.m_pParent.Idle();
		}
	}

	// Token: 0x0400066A RID: 1642
	private UFO m_pParent;
}

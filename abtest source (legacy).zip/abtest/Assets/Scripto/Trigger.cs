﻿using System;

namespace AnimationOrTween
{
	// Token: 0x02000038 RID: 56
	public enum Trigger
	{
		// Token: 0x0400013C RID: 316
		OnClick,
		// Token: 0x0400013D RID: 317
		OnHover,
		// Token: 0x0400013E RID: 318
		OnPress,
		// Token: 0x0400013F RID: 319
		OnHoverTrue,
		// Token: 0x04000140 RID: 320
		OnHoverFalse,
		// Token: 0x04000141 RID: 321
		OnPressTrue,
		// Token: 0x04000142 RID: 322
		OnPressFalse,
		// Token: 0x04000143 RID: 323
		OnActivate,
		// Token: 0x04000144 RID: 324
		OnActivateTrue,
		// Token: 0x04000145 RID: 325
		OnActivateFalse,
		// Token: 0x04000146 RID: 326
		OnDoubleClick,
		// Token: 0x04000147 RID: 327
		OnSelect,
		// Token: 0x04000148 RID: 328
		OnSelectTrue,
		// Token: 0x04000149 RID: 329
		OnSelectFalse
	}
}

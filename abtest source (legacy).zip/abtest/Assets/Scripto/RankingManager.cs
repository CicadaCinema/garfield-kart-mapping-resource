﻿using System;
using System.Collections.Generic;

// Token: 0x020000C1 RID: 193
public class RankingManager
{
	// Token: 0x060004E3 RID: 1251 RVA: 0x000057F2 File Offset: 0x000039F2
	public void Reset()
	{
		this.m_vRaceScores.Clear();
		this.m_vChampionshipSorted.Clear();
		this.m_vRaceSorted.Clear();
	}

	// Token: 0x060004E4 RID: 1252 RVA: 0x000297D0 File Offset: 0x000279D0
	public void InitPlayer(int iKartIndex, bool bIsAi)
	{
		foreach (RaceScoreData raceScoreData in this.m_vRaceScores)
		{
			if (raceScoreData.KartIndex == iKartIndex)
			{
				return;
			}
		}
		RaceScoreData item;
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
		{
			item = new ChampionShipScoreData(iKartIndex, bIsAi);
			this.m_vChampionshipSorted.Add(this.m_vRaceScores.Count);
		}
		else
		{
			item = new RaceScoreData(iKartIndex, bIsAi);
		}
		this.m_vRaceSorted.Add(this.m_vRaceScores.Count);
		this.m_vRaceScores.Add(item);
	}

	// Token: 0x060004E5 RID: 1253 RVA: 0x00029894 File Offset: 0x00027A94
	public void PlayerFinish(int iKartIndex, int iScore)
	{
		foreach (RaceScoreData raceScoreData in this.m_vRaceScores)
		{
			if (raceScoreData.KartIndex == iKartIndex)
			{
				raceScoreData.SetRaceScore(iScore);
				break;
			}
		}
	}

	// Token: 0x060004E6 RID: 1254 RVA: 0x00029900 File Offset: 0x00027B00
	public void RestartRace()
	{
		foreach (RaceScoreData raceScoreData in this.m_vRaceScores)
		{
			raceScoreData.RestartRace();
		}
	}

	// Token: 0x060004E7 RID: 1255 RVA: 0x0002995C File Offset: 0x00027B5C
	public void ResetRace()
	{
		foreach (RaceScoreData raceScoreData in this.m_vRaceScores)
		{
			raceScoreData.ResetRace();
		}
	}

	// Token: 0x060004E8 RID: 1256 RVA: 0x000299B8 File Offset: 0x00027BB8
	public void ComputePositions(bool bChampionship, bool bScore)
	{
		int[] array = this.m_vRaceSorted.ToArray();
		Array.Sort<int>(array, new RaceScoreDataComparer(this.m_vRaceScores.ToArray(), bScore));
		for (int i = 0; i < array.Length; i++)
		{
			this.m_vRaceSorted[i] = array[i];
			this.m_vRaceScores[this.m_vRaceSorted[i]].SetRacePosition(i);
		}
		if (bChampionship)
		{
			int[] array2 = this.m_vChampionshipSorted.ToArray();
			Array.Sort<int>(array2, new ChampionShipScoreDataComparer(this.m_vRaceScores.ToArray()));
			for (int j = 0; j < array2.Length; j++)
			{
				this.m_vChampionshipSorted[j] = array2[j];
				ChampionShipScoreData championShipScoreData = (ChampionShipScoreData)this.m_vRaceScores[this.m_vChampionshipSorted[j]];
				championShipScoreData.SetChampionShipPosition(j);
			}
		}
	}

	// Token: 0x060004E9 RID: 1257 RVA: 0x00005815 File Offset: 0x00003A15
	public RaceScoreData GetRacePos(int iPos)
	{
		if (iPos >= 0 && iPos < this.m_vRaceSorted.Count)
		{
			return this.m_vRaceScores[this.m_vRaceSorted[iPos]];
		}
		return null;
	}

	// Token: 0x060004EA RID: 1258 RVA: 0x00005848 File Offset: 0x00003A48
	public ChampionShipScoreData GetChampionshipPos(int iPos)
	{
		if (iPos >= 0 && iPos < this.m_vChampionshipSorted.Count)
		{
			return (ChampionShipScoreData)this.m_vRaceScores[this.m_vChampionshipSorted[iPos]];
		}
		return null;
	}

	// Token: 0x060004EB RID: 1259 RVA: 0x00029A9C File Offset: 0x00027C9C
	public RaceScoreData GetScoreData(int iKartIndex)
	{
		foreach (RaceScoreData raceScoreData in this.m_vRaceScores)
		{
			if (raceScoreData.KartIndex == iKartIndex)
			{
				return raceScoreData;
			}
		}
		return null;
	}

	// Token: 0x060004EC RID: 1260 RVA: 0x00029B08 File Offset: 0x00027D08
	public void SetInitialRank(int iKartIndex, int iRank)
	{
		RaceScoreData scoreData = this.GetScoreData(iKartIndex);
		if (scoreData != null && scoreData.RacePosition == 0 && scoreData.PreviousRacePosition == 0)
		{
			scoreData.SetRacePosition(iRank);
		}
	}

	// Token: 0x060004ED RID: 1261 RVA: 0x00005880 File Offset: 0x00003A80
	public int RaceScoreCount()
	{
		return this.m_vRaceScores.Count;
	}

	// Token: 0x060004EE RID: 1262 RVA: 0x0000588D File Offset: 0x00003A8D
	public List<RaceScoreData> GetRaceScoreDataList()
	{
		return this.m_vRaceScores;
	}

	// Token: 0x040004D6 RID: 1238
	private List<RaceScoreData> m_vRaceScores = new List<RaceScoreData>();

	// Token: 0x040004D7 RID: 1239
	private List<int> m_vChampionshipSorted = new List<int>();

	// Token: 0x040004D8 RID: 1240
	private List<int> m_vRaceSorted = new List<int>();
}

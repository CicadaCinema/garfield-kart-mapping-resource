﻿using System;
using UnityEngine;

// Token: 0x020000F7 RID: 247
[Serializable]
public class Template
{
	// Token: 0x060006B4 RID: 1716 RVA: 0x00006B90 File Offset: 0x00004D90
	public Template(ECharacter pCharacter)
	{
		this.Character = pCharacter;
	}

	// Token: 0x040006A9 RID: 1705
	public ECharacter Character = ECharacter.NONE;

	// Token: 0x040006AA RID: 1706
	public Vector3 Position = Vector3.zero;

	// Token: 0x040006AB RID: 1707
	public Vector3 Scale = Vector3.zero;
}

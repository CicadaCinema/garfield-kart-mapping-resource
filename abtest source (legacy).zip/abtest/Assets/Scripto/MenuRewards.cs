﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020001A3 RID: 419
public class MenuRewards : AbstractMenu
{
	// Token: 0x06000B5B RID: 2907 RVA: 0x00009E94 File Offset: 0x00008094
	public override void Awake()
	{
		base.Awake();
		this.m_pAudioSource = base.GetComponent<AudioSource>();
	}

	// Token: 0x06000B5C RID: 2908 RVA: 0x00009EA8 File Offset: 0x000080A8
	public override void OnEnter()
	{
		base.OnEnter();
	}

	// Token: 0x06000B5D RID: 2909 RVA: 0x00009EB0 File Offset: 0x000080B0
	public virtual void OnGoNext()
	{
		this.m_pMenuEntryPoint.SetStateDelay(Singleton<RewardManager>.Instance.GetState(), 0.1f);
	}

	// Token: 0x06000B5E RID: 2910 RVA: 0x0004C7C8 File Offset: 0x0004A9C8
	public new void Update()
	{
		if (!this.m_bPlayedAnim && !LoadingManager.IsLoading())
		{
			this.m_bPlayedAnim = true;
			if (this.m_pAudioSource)
			{
				this.m_pAudioSource.Play();
			}
			foreach (Animation animation in this.Animations)
			{
				if (animation.gameObject.activeSelf)
				{
					animation.Play();
				}
			}
		}
	}

	// Token: 0x06000B5F RID: 2911 RVA: 0x0004C86C File Offset: 0x0004AA6C
	public Tuple<string, UIAtlas, string, ERarity> GetInfos(string Name, E_RewardType Type)
	{
		Tuple<string, UIAtlas, string, ERarity> tuple = new Tuple<string, UIAtlas, string, ERarity>();
		switch (Type)
		{
		case E_RewardType.Kart:
		{
			UnityEngine.Object @object = Resources.Load("Kart/K" + Name[0] + "_body");
			if (@object != null)
			{
				KartCarac component = ((GameObject)@object).GetComponent<KartCarac>();
				tuple.Item1 = Localization.instance.Get(component.m_TitleTextId);
				tuple.Item3 = component.spriteName;
				tuple.Item4 = ERarity.Unique;
			}
			break;
		}
		case E_RewardType.Custom:
		{
			UnityEngine.Object @object = Resources.Load("Kart/" + Name);
			if (@object != null)
			{
				KartCustom component2 = ((GameObject)@object).GetComponent<KartCustom>();
				tuple.Item1 = Localization.instance.Get(component2.m_TitleTextId);
				tuple.Item3 = component2.spriteName;
				tuple.Item4 = component2.Rarity;
			}
			break;
		}
		case E_RewardType.Hat:
		{
			UnityEngine.Object @object = Resources.Load("Hat/" + Name);
			if (@object != null)
			{
				BonusCustom component3 = ((GameObject)@object).GetComponent<BonusCustom>();
				tuple.Item1 = Localization.instance.Get(component3.m_TitleTextId);
				tuple.Item3 = component3.spriteName;
				tuple.Item4 = component3.Rarity;
			}
			break;
		}
		}
		return tuple;
	}

	// Token: 0x04000B22 RID: 2850
	public UILabel LbRewardName;

	// Token: 0x04000B23 RID: 2851
	public UILabel LbMessage;

	// Token: 0x04000B24 RID: 2852
	public UISprite Sprite;

	// Token: 0x04000B25 RID: 2853
	public UITexturePattern SpriteRarity;

	// Token: 0x04000B26 RID: 2854
	private AudioSource m_pAudioSource;

	// Token: 0x04000B27 RID: 2855
	public List<Animation> Animations = new List<Animation>();

	// Token: 0x04000B28 RID: 2856
	private bool m_bPlayedAnim;
}

﻿using System;
using UnityEngine;

// Token: 0x02000098 RID: 152
public class Rotate : MonoBehaviour
{
	// Token: 0x06000410 RID: 1040 RVA: 0x000050CF File Offset: 0x000032CF
	public void Awake()
	{
		this.m_oTransform = base.gameObject.transform;
	}

	// Token: 0x06000411 RID: 1041 RVA: 0x00024594 File Offset: 0x00022794
	public void Update()
	{
		Vector3 a = new Vector3((!this._x) ? 0f : 1f, (!this._y) ? 0f : 1f, (!this._z) ? 0f : 1f);
		this.m_oTransform.Rotate(a * Time.deltaTime * this.vitesse);
	}

	// Token: 0x04000385 RID: 901
	public float vitesse = 1f;

	// Token: 0x04000386 RID: 902
	public bool _x = true;

	// Token: 0x04000387 RID: 903
	public bool _y;

	// Token: 0x04000388 RID: 904
	public bool _z;

	// Token: 0x04000389 RID: 905
	public Transform m_oTransform;
}

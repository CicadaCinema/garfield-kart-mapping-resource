﻿using System;
using System.Collections.Generic;

// Token: 0x02000187 RID: 391
internal class RaceScoreDataComparer : IComparer<int>
{
	// Token: 0x06000A72 RID: 2674 RVA: 0x000093A3 File Offset: 0x000075A3
	public RaceScoreDataComparer(RaceScoreData[] pData, bool bScore)
	{
		this.m_pData = pData;
		this.m_bScore = bScore;
	}

	// Token: 0x06000A73 RID: 2675 RVA: 0x0004729C File Offset: 0x0004549C
	public int Compare(int a, int b)
	{
		RaceScoreData raceScoreData = this.m_pData[a];
		RaceScoreData raceScoreData2 = this.m_pData[b];
		if (raceScoreData.KartIndex == raceScoreData2.KartIndex)
		{
			return 0;
		}
		if (this.m_bScore)
		{
			if (raceScoreData.RaceScore != raceScoreData2.RaceScore)
			{
				return raceScoreData2.RaceScore.CompareTo(raceScoreData.RaceScore);
			}
			if (raceScoreData2.IsAI == raceScoreData.IsAI)
			{
				return raceScoreData.PreviousRaceScore.CompareTo(raceScoreData2.PreviousRaceScore);
			}
			if (raceScoreData2.IsAI)
			{
				return raceScoreData2.RaceScore.CompareTo(raceScoreData.RaceScore + 1);
			}
			return raceScoreData2.RaceScore.CompareTo(raceScoreData.RaceScore - 1);
		}
		else
		{
			if (raceScoreData.RacePosition != raceScoreData2.RacePosition)
			{
				return raceScoreData.RacePosition.CompareTo(raceScoreData2.RacePosition);
			}
			if (raceScoreData2.IsAI)
			{
				return raceScoreData.RacePosition.CompareTo(raceScoreData2.RacePosition + 1);
			}
			return raceScoreData.RacePosition.CompareTo(raceScoreData2.RacePosition - 1);
		}
	}

	// Token: 0x04000A57 RID: 2647
	private RaceScoreData[] m_pData;

	// Token: 0x04000A58 RID: 2648
	private bool m_bScore;
}

﻿using UnityEngine;
using System.Collections;
using System;

public class RotateCube : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {

        System.Reflection.Assembly b = System.Reflection.Assembly.GetExecutingAssembly();
        Debug.Log(b.FullName);
    }

    // Update is called once per frame
    void Update()
    {
        gameObject.transform.Rotate(Vector3.up * Time.deltaTime * 100);

        gameObject.transform.Rotate(Vector3.right * (int)(Math.Sin(Time.deltaTime) * 110));
    }
}
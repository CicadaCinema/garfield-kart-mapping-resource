﻿using System;
using UnityEngine;

// Token: 0x020001DB RID: 475
public class ForecastClient : ForecastedCar
{
	// Token: 0x06000CC1 RID: 3265 RVA: 0x00054BA8 File Offset: 0x00052DA8
	public ForecastClient(RcVehicle pVehicle)
	{
		this.Vehicle = pVehicle;
	}

	// Token: 0x1700019F RID: 415
	// (get) Token: 0x06000CC2 RID: 3266 RVA: 0x0000AD21 File Offset: 0x00008F21
	// (set) Token: 0x06000CC3 RID: 3267 RVA: 0x0000AD29 File Offset: 0x00008F29
	public bool ObserverEnabled
	{
		get
		{
			return this._observerEnabled;
		}
		set
		{
			this._observerEnabled = value;
			if (this._observerEnabled)
			{
				this.ResetBorderPositions();
			}
		}
	}

	// Token: 0x170001A0 RID: 416
	// (get) Token: 0x06000CC4 RID: 3268 RVA: 0x0000AD43 File Offset: 0x00008F43
	public ForecastResult ForecastAttractive
	{
		get
		{
			return this._forecastAttractive;
		}
	}

	// Token: 0x170001A1 RID: 417
	// (get) Token: 0x06000CC5 RID: 3269 RVA: 0x0000AD4B File Offset: 0x00008F4B
	public ForecastResult ForecastRepulsive
	{
		get
		{
			return this._forecastRepulsive;
		}
	}

	// Token: 0x170001A2 RID: 418
	// (get) Token: 0x06000CC6 RID: 3270 RVA: 0x0000AD53 File Offset: 0x00008F53
	// (set) Token: 0x06000CC7 RID: 3271 RVA: 0x0000AD5B File Offset: 0x00008F5B
	public RcFastPath LeftBorder
	{
		get
		{
			return this._leftBorder;
		}
		set
		{
			this._leftBorder = value;
		}
	}

	// Token: 0x170001A3 RID: 419
	// (get) Token: 0x06000CC8 RID: 3272 RVA: 0x0000AD64 File Offset: 0x00008F64
	// (set) Token: 0x06000CC9 RID: 3273 RVA: 0x0000AD6C File Offset: 0x00008F6C
	public RcFastPath RightBorder
	{
		get
		{
			return this._rightBorder;
		}
		set
		{
			this._rightBorder = value;
		}
	}

	// Token: 0x170001A4 RID: 420
	// (get) Token: 0x06000CCA RID: 3274 RVA: 0x0000AD75 File Offset: 0x00008F75
	public Vector2 Pos
	{
		get
		{
			return this._pos;
		}
	}

	// Token: 0x170001A5 RID: 421
	// (get) Token: 0x06000CCB RID: 3275 RVA: 0x0000AD7D File Offset: 0x00008F7D
	public Vector2 ForecastSegment
	{
		get
		{
			return this._forecastSegment;
		}
	}

	// Token: 0x170001A6 RID: 422
	// (get) Token: 0x06000CCC RID: 3276 RVA: 0x0000AD85 File Offset: 0x00008F85
	public float SpeedMs
	{
		get
		{
			return ((RcVehicle)this._entity).GetRealSpeedMs();
		}
	}

	// Token: 0x06000CCD RID: 3277 RVA: 0x00054BF8 File Offset: 0x00052DF8
	public void Start()
	{
		RcVehicle vehicle = this.Vehicle;
		vehicle.OnTeleported = (Action)Delegate.Combine(vehicle.OnTeleported, new Action(this.NeedResetBorderPositions));
		RcVehicle vehicle2 = this.Vehicle;
		vehicle2.OnAutoPilotChanged = (Action)Delegate.Combine(vehicle2.OnAutoPilotChanged, new Action(this.NeedResetBorderPositions));
	}

	// Token: 0x06000CCE RID: 3278 RVA: 0x00054C54 File Offset: 0x00052E54
	~ForecastClient()
	{
		try
		{
			RcVehicle vehicle = this.Vehicle;
			vehicle.OnTeleported = (Action)Delegate.Remove(vehicle.OnTeleported, new Action(this.NeedResetBorderPositions));
			RcVehicle vehicle2 = this.Vehicle;
			vehicle2.OnAutoPilotChanged = (Action)Delegate.Remove(vehicle2.OnAutoPilotChanged, new Action(this.NeedResetBorderPositions));
		}
		finally
		{
			//base.Finalize();
		}
	}

	// Token: 0x06000CCF RID: 3279 RVA: 0x00054CCC File Offset: 0x00052ECC
	public override void Refresh(float pForecastTime)
	{
		base.Refresh(pForecastTime);
		this._pos.x = this._entity.transform.position.x;
		this._pos.y = this._entity.transform.position.z;
		this._forecastSegment.x = this._forecastPosition.x - this._pos.x;
		this._forecastSegment.y = this._forecastPosition.z - this._pos.y;
		this._forecastAttractive.Refresh();
		this._forecastRepulsive.Refresh();
	}

	// Token: 0x06000CD0 RID: 3280 RVA: 0x0000AD97 File Offset: 0x00008F97
	public bool IsObjectInFront(Forecasted pOther)
	{
		return Vector3.Dot(this._entity.transform.rotation * Vector3.forward, pOther.CurrentPosition - base.CurrentPosition) >= 0f;
	}

	// Token: 0x06000CD1 RID: 3281 RVA: 0x00054D80 File Offset: 0x00052F80
	public bool IsObjectOnRight(Forecasted pOther)
	{
		return RcUtils.IsOnRight(base.CurrentPosition, base.CurrentPosition + this._entity.transform.rotation * Vector3.forward, pOther.ForecastPosition, this._entity.transform.rotation * Vector3.up);
	}

	// Token: 0x06000CD2 RID: 3282 RVA: 0x00054DE0 File Offset: 0x00052FE0
	public bool IsSegmentOnRight(Vector2 pP1, Vector2 pP2)
	{
		Vector3 vector = this._entity.transform.rotation * Vector3.forward;
		Vector2 vector2 = new Vector2(vector.x, vector.z);
		bool flag = RcUtils.IsOnRight(this.Pos, this.Pos + vector2, pP1);
		bool flag2 = RcUtils.IsOnRight(this.Pos, this.Pos + vector2, pP2);
		if (flag && flag2)
		{
			return true;
		}
		if (!flag && !flag2)
		{
			return false;
		}
		float num = Vector2.Dot(pP2 - pP1, vector2);
		Vector2 zero = Vector2.zero;
		Vector2 zero2 = Vector2.zero;
		int num2 = RcUtils.SegmentsIntersection(this.Pos, this.Pos + vector2 * 10000f, pP1, pP2, ref zero, ref zero2);
		bool flag3 = num2 == 0;
		if (flag)
		{
			if (num > 0f)
			{
				return !flag3;
			}
			return flag3;
		}
		else
		{
			if (num < 0f)
			{
				return !flag3;
			}
			return flag3;
		}
	}

	// Token: 0x06000CD3 RID: 3283 RVA: 0x00054F14 File Offset: 0x00053114
	public void ResetBorderPositions()
	{
		if (this._leftBorder != null)
		{
			this._leftBorder.ResetSidedPosition(ref this.LeftBorderPosition, this._entity.transform.position, true, RcFastPath.PathSide.SIDE_RIGHT, this._entity.transform.rotation * Vector3.up);
		}
		if (this._rightBorder != null)
		{
			this._rightBorder.ResetSidedPosition(ref this.RightBorderPosition, this._entity.transform.position, true, RcFastPath.PathSide.SIDE_RIGHT, this._entity.transform.rotation * Vector3.up);
		}
	}

	// Token: 0x06000CD4 RID: 3284 RVA: 0x0000ADD3 File Offset: 0x00008FD3
	public void NeedResetBorderPositions()
	{
		this.ResetBorderPositions();
	}

	// Token: 0x04000C68 RID: 3176
	private RcFastPath _leftBorder;

	// Token: 0x04000C69 RID: 3177
	private RcFastPath _rightBorder;

	// Token: 0x04000C6A RID: 3178
	public PathPosition LeftBorderPosition;

	// Token: 0x04000C6B RID: 3179
	public PathPosition RightBorderPosition;

	// Token: 0x04000C6C RID: 3180
	public RcVehicle Vehicle;

	// Token: 0x04000C6D RID: 3181
	public float FrustrumStartWidth;

	// Token: 0x04000C6E RID: 3182
	public float FrustrumEndWidth;

	// Token: 0x04000C6F RID: 3183
	private bool _observerEnabled = true;

	// Token: 0x04000C70 RID: 3184
	private ForecastResult _forecastAttractive = new ForecastResult();

	// Token: 0x04000C71 RID: 3185
	private ForecastResult _forecastRepulsive = new ForecastResult();

	// Token: 0x04000C72 RID: 3186
	private Vector2 _pos = Vector2.zero;

	// Token: 0x04000C73 RID: 3187
	private Vector2 _forecastSegment = Vector2.zero;
}

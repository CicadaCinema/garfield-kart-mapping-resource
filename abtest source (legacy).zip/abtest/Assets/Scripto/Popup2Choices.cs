﻿using System;

// Token: 0x020001BD RID: 445
public class Popup2Choices : AbstractPopup
{
	// Token: 0x06000BFA RID: 3066 RVA: 0x00051E44 File Offset: 0x00050044
	public void Show(string sTextIdDialog, Popup2Choices.Callback oCbLeft = null, Popup2Choices.Callback oCbRight = null, object oParam = null, string sTextIdBtnLeft = "MENU_POPUP_NO", string sTextIdBtnRight = "MENU_POPUP_YES")
	{
		this.m_oCbButtonLeft = oCbLeft;
		this.m_oCbButtonRight = oCbRight;
		this.m_oParam = oParam;
		if (sTextIdBtnLeft != null)
		{
			this.m_oLabelButtonLeft.key = sTextIdBtnLeft;
		}
		if (sTextIdBtnRight != null)
		{
			this.m_oLabelButtonRight.key = sTextIdBtnRight;
		}
		base.Show(sTextIdDialog);
	}

	// Token: 0x06000BFB RID: 3067 RVA: 0x00051E98 File Offset: 0x00050098
	public void ShowText(string sTextDialog, Popup2Choices.Callback oCbLeft = null, Popup2Choices.Callback oCbRight = null, object oParam = null, string sTextIdBtnLeft = "MENU_POPUP_NO", string sTextIdBtnRight = "MENU_POPUP_YES")
	{
		base.gameObject.SetActive(true);
		this.m_oCbButtonLeft = oCbLeft;
		this.m_oCbButtonRight = oCbRight;
		this.m_oParam = oParam;
		if (sTextIdBtnLeft != null)
		{
			this.m_oLabelButtonLeft.key = sTextIdBtnLeft;
		}
		if (sTextIdBtnRight != null)
		{
			this.m_oLabelButtonRight.key = sTextIdBtnRight;
		}
		UILabel component = this.Text.gameObject.GetComponent<UILabel>();
		if (component)
		{
			component.text = sTextDialog;
		}
	}

	// Token: 0x06000BFC RID: 3068 RVA: 0x0000A538 File Offset: 0x00008738
	public void OnButtonLeft()
	{
		base.OnQuit();
		if (this.m_oCbButtonLeft != null)
		{
			this.m_oCbButtonLeft(this.m_oParam);
		}
	}

	// Token: 0x06000BFD RID: 3069 RVA: 0x0000A55C File Offset: 0x0000875C
	public void OnButtonRight()
	{
		base.OnQuit();
		if (this.m_oCbButtonRight != null)
		{
			this.m_oCbButtonRight(this.m_oParam);
		}
	}

	// Token: 0x04000BDF RID: 3039
	public UILocalize m_oLabelButtonRight;

	// Token: 0x04000BE0 RID: 3040
	public UILocalize m_oLabelButtonLeft;

	// Token: 0x04000BE1 RID: 3041
	private Popup2Choices.Callback m_oCbButtonRight;

	// Token: 0x04000BE2 RID: 3042
	private Popup2Choices.Callback m_oCbButtonLeft;

	// Token: 0x04000BE3 RID: 3043
	private object m_oParam;

	// Token: 0x020001BE RID: 446
	// (Invoke) Token: 0x06000BFF RID: 3071
	public delegate void Callback(object param);
}

﻿using System;
using UnityEngine;

// Token: 0x02000032 RID: 50
[AddComponentMenu("NGUI/Interaction/Sound Volume")]
[RequireComponent(typeof(UISlider))]
public class UISoundVolume : MonoBehaviour
{
	// Token: 0x06000117 RID: 279 RVA: 0x00002FA4 File Offset: 0x000011A4
	private void Awake()
	{
		this.mSlider = base.GetComponent<UISlider>();
		this.mSlider.sliderValue = NGUITools.soundVolume;
		this.mSlider.eventReceiver = base.gameObject;
	}

	// Token: 0x06000118 RID: 280 RVA: 0x00002FD3 File Offset: 0x000011D3
	private void OnSliderChange(float val)
	{
		NGUITools.soundVolume = val;
	}

	// Token: 0x04000124 RID: 292
	private UISlider mSlider;
}

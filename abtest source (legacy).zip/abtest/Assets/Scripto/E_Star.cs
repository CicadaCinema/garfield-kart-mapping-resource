﻿using System;

// Token: 0x020000C2 RID: 194
public enum E_Star
{
	// Token: 0x040004DA RID: 1242
	None = -1,
	// Token: 0x040004DB RID: 1243
	ChNormal,
	// Token: 0x040004DC RID: 1244
	ChHard,
	// Token: 0x040004DD RID: 1245
	TimeTrial,
	// Token: 0x040004DE RID: 1246
	ChEasy,
	// Token: 0x040004DF RID: 1247
	End
}

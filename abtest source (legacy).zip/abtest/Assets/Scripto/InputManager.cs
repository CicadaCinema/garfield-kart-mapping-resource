﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000239 RID: 569
public class InputManager : Singleton<InputManager>
{
	// Token: 0x06000FF4 RID: 4084 RVA: 0x00064D90 File Offset: 0x00062F90
	public InputManager()
	{
		for (int i = 0; i < Enum.GetValues(typeof(EAction)).Length; i++)
		{
			this.m_Actions.Add((EAction)i, new InputData());
		}
	}

	// Token: 0x17000204 RID: 516
	public float this[EAction pKey]
	{
		get
		{
			InputData inputData;
			if (this.m_Actions.TryGetValue(pKey, out inputData))
			{
				return inputData.Value;
			}
			return 0f;
		}
		set
		{
			InputData inputData;
			if (this.m_Actions.TryGetValue(pKey, out inputData))
			{
				inputData.NextValue = value;
				inputData.LifeTime = 1;
			}
		}
	}

	// Token: 0x06000FF7 RID: 4087 RVA: 0x00003B80 File Offset: 0x00001D80
	public void Init()
	{
	}

	// Token: 0x06000FF8 RID: 4088 RVA: 0x00003B80 File Offset: 0x00001D80
	public void Term()
	{
	}

	// Token: 0x06000FF9 RID: 4089 RVA: 0x00064E48 File Offset: 0x00063048
	public void Update()
	{
		foreach (KeyValuePair<EAction, InputData> keyValuePair in this.m_Actions)
		{
			InputData value = keyValuePair.Value;
			if (value.NextValue != 0f || value.Value != 0f)
			{
				if (value.LifeTime > 0)
				{
					if (value.NextValue != value.Value)
					{
						value.Value = value.NextValue;
					}
					value.LifeTime--;
				}
				else
				{
					value.Value = 0f;
				}
			}
		}
		if (Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
		{
			this.SetAction(EAction.Accelerate, Input.GetAxis("Vertical"));
			this.SetAction(EAction.Steer, Input.GetAxis("Horizontal"));
			this.SetAction(EAction.Drift, Convert.ToSingle(Input.GetButton("Fire1")));
			this.SetAction(EAction.DriftJump, Convert.ToSingle(Input.GetButtonDown("Fire1")));
			this.SetAction(EAction.LaunchBonus, Convert.ToSingle(Input.GetButtonDown("Fire2")));
			this.SetAction(EAction.DropBonus, Convert.ToSingle(Input.GetButtonDown("DropBonus")));
			if (Debug.isDebugBuild)
			{
				this.SetAction(EAction.Respawn, Convert.ToSingle(Input.GetButtonDown("Jump")));
			}
			this.SetAction(EAction.Pause, Convert.ToSingle(Input.GetButtonDown("Pause")));
		}
	}

	// Token: 0x06000FFA RID: 4090 RVA: 0x0000CCB1 File Offset: 0x0000AEB1
	public void SetAction(EAction _Action, float _Value)
	{
		this.SetAction(_Action, _Value, 1);
	}

	// Token: 0x06000FFB RID: 4091 RVA: 0x00064FD4 File Offset: 0x000631D4
	public void SetAction(EAction _Action, float _Value, int _LifeTime)
	{
		InputData inputData;
		if (this.m_Actions.TryGetValue(_Action, out inputData))
		{
			inputData.NextValue = _Value;
			inputData.LifeTime = _LifeTime;
		}
	}

	// Token: 0x06000FFC RID: 4092 RVA: 0x00064DEC File Offset: 0x00062FEC
	public float GetAction(EAction _Action)
	{
		InputData inputData;
		if (this.m_Actions.TryGetValue(_Action, out inputData))
		{
			return inputData.Value;
		}
		return 0f;
	}

	// Token: 0x04000F5E RID: 3934
	private Dictionary<EAction, InputData> m_Actions = new Dictionary<EAction, InputData>(new EActionKeyComparer());
}

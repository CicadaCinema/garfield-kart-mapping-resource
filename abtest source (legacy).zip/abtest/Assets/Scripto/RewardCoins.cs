﻿using System;

// Token: 0x02000159 RID: 345
public class RewardCoins : RewardBase
{
	// Token: 0x0600098B RID: 2443 RVA: 0x000089AB File Offset: 0x00006BAB
	protected override void GetReward()
	{
		Singleton<RewardManager>.Instance.EarnCoins(this.Quantity);
	}

	// Token: 0x040009C0 RID: 2496
	public int Quantity;
}

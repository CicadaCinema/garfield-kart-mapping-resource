﻿using System;
using UnityEngine;

// Token: 0x02000235 RID: 565
public class FpsDisplay : MonoBehaviour
{
	// Token: 0x06000FEE RID: 4078 RVA: 0x0000CC5D File Offset: 0x0000AE5D
	public void Start()
	{
		if (!base.guiText)
		{
			base.enabled = false;
			return;
		}
		this.timeleft = this.updateInterval;
	}

	// Token: 0x06000FEF RID: 4079 RVA: 0x00064C8C File Offset: 0x00062E8C
	public void Update()
	{
		this.timeleft -= Time.deltaTime;
		this.accum += Time.timeScale / Time.deltaTime;
		this.frames++;
		if ((double)this.timeleft <= 0.0)
		{
			float num = this.accum / (float)this.frames;
			string text = string.Format("{0:F2} FPS", num);
			base.guiText.text = text;
			if (num < 30f)
			{
				base.guiText.material.color = Color.yellow;
			}
			else if (num < 10f)
			{
				base.guiText.material.color = Color.red;
			}
			else
			{
				base.guiText.material.color = Color.green;
			}
			this.timeleft = this.updateInterval;
			this.accum = 0f;
			this.frames = 0;
		}
	}

	// Token: 0x04000F4E RID: 3918
	public float updateInterval = 0.5f;

	// Token: 0x04000F4F RID: 3919
	private float accum;

	// Token: 0x04000F50 RID: 3920
	private int frames;

	// Token: 0x04000F51 RID: 3921
	private float timeleft;
}

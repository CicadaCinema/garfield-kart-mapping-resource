﻿using System;
using UnityEngine;

// Token: 0x0200008D RID: 141
[AddComponentMenu("NGUI/UI/Texture")]
[ExecuteInEditMode]
public class UITexture : UIWidget
{
	// Token: 0x170000C0 RID: 192
	// (get) Token: 0x060003DE RID: 990 RVA: 0x00004EA5 File Offset: 0x000030A5
	// (set) Token: 0x060003DF RID: 991 RVA: 0x00004EAD File Offset: 0x000030AD
	public Rect uvRect
	{
		get
		{
			return this.mRect;
		}
		set
		{
			if (this.mRect != value)
			{
				this.mRect = value;
				this.MarkAsChanged();
			}
		}
	}

	// Token: 0x170000C1 RID: 193
	// (get) Token: 0x060003E0 RID: 992 RVA: 0x000236A0 File Offset: 0x000218A0
	// (set) Token: 0x060003E1 RID: 993 RVA: 0x00023704 File Offset: 0x00021904
	public Shader shader
	{
		get
		{
			if (this.mShader == null)
			{
				Material material = this.material;
				if (material != null)
				{
					this.mShader = material.shader;
				}
				if (this.mShader == null)
				{
					this.mShader = Shader.Find("Unlit/Texture");
				}
			}
			return this.mShader;
		}
		set
		{
			if (this.mShader != value)
			{
				this.mShader = value;
				Material material = this.material;
				if (material != null)
				{
					material.shader = value;
				}
				this.mPMA = -1;
			}
		}
	}

	// Token: 0x170000C2 RID: 194
	// (get) Token: 0x060003E2 RID: 994 RVA: 0x00004ECD File Offset: 0x000030CD
	public bool hasDynamicMaterial
	{
		get
		{
			return this.mDynamicMat != null;
		}
	}

	// Token: 0x170000C3 RID: 195
	// (get) Token: 0x060003E3 RID: 995 RVA: 0x00004C05 File Offset: 0x00002E05
	public override bool keepMaterial
	{
		get
		{
			return true;
		}
	}

	// Token: 0x170000C4 RID: 196
	// (get) Token: 0x060003E4 RID: 996 RVA: 0x0002374C File Offset: 0x0002194C
	// (set) Token: 0x060003E5 RID: 997 RVA: 0x000237FC File Offset: 0x000219FC
	public override Material material
	{
		get
		{
			if (!this.mCreatingMat && this.mMat == null)
			{
				this.mCreatingMat = true;
				if (this.mainTexture != null)
				{
					if (this.mShader == null)
					{
						this.mShader = Shader.Find("Unlit/Texture");
					}
					this.mDynamicMat = new Material(this.mShader);
					this.mDynamicMat.hideFlags = HideFlags.DontSave;
					this.mDynamicMat.mainTexture = this.mainTexture;
					base.material = this.mDynamicMat;
					this.mPMA = 0;
				}
				this.mCreatingMat = false;
			}
			return this.mMat;
		}
		set
		{
			if (this.mDynamicMat != value && this.mDynamicMat != null)
			{
				NGUITools.Destroy(this.mDynamicMat);
				this.mDynamicMat = null;
			}
			base.material = value;
			this.mPMA = -1;
		}
	}

	// Token: 0x170000C5 RID: 197
	// (get) Token: 0x060003E6 RID: 998 RVA: 0x0002384C File Offset: 0x00021A4C
	public bool premultipliedAlpha
	{
		get
		{
			if (this.mPMA == -1)
			{
				Material material = this.material;
				this.mPMA = ((!(material != null) || !(material.shader != null) || !material.shader.name.Contains("Premultiplied")) ? 0 : 1);
			}
			return this.mPMA == 1;
		}
	}

	// Token: 0x170000C6 RID: 198
	// (get) Token: 0x060003E7 RID: 999 RVA: 0x00004EDB File Offset: 0x000030DB
	// (set) Token: 0x060003E8 RID: 1000 RVA: 0x000238BC File Offset: 0x00021ABC
	public override Texture mainTexture
	{
		get
		{
			return (!(this.mTexture != null)) ? base.mainTexture : this.mTexture;
		}
		set
		{
			if (this.mPanel != null && this.mMat != null)
			{
				this.mPanel.RemoveWidget(this);
			}
			if (this.mMat == null)
			{
				this.mDynamicMat = new Material(this.shader);
				this.mDynamicMat.hideFlags = HideFlags.DontSave;
				this.mMat = this.mDynamicMat;
			}
			this.mPanel = null;
			this.mTex = value;
			this.mTexture = value;
			this.mMat.mainTexture = value;
			if (base.enabled)
			{
				base.CreatePanel();
			}
		}
	}

	// Token: 0x060003E9 RID: 1001 RVA: 0x00004EFF File Offset: 0x000030FF
	private void OnDestroy()
	{
		NGUITools.Destroy(this.mDynamicMat);
	}

	// Token: 0x060003EA RID: 1002 RVA: 0x00023964 File Offset: 0x00021B64
	public override void MakePixelPerfect()
	{
		Texture mainTexture = this.mainTexture;
		if (mainTexture != null)
		{
			Vector3 localScale = base.cachedTransform.localScale;
			localScale.x = (float)mainTexture.width * this.uvRect.width;
			localScale.y = (float)mainTexture.height * this.uvRect.height;
			localScale.z = 1f;
			base.cachedTransform.localScale = localScale;
		}
		base.MakePixelPerfect();
	}

	// Token: 0x060003EB RID: 1003 RVA: 0x000239E8 File Offset: 0x00021BE8
	public override void OnFill(BetterList<Vector3> verts, BetterList<Vector2> uvs, BetterList<Color32> cols)
	{
		Color color = base.color;
		color.a *= this.mPanel.alpha;
		Color32 item = (!this.premultipliedAlpha) ? color : NGUITools.ApplyPMA(color);
		verts.Add(new Vector3(1f, 0f, 0f));
		verts.Add(new Vector3(1f, -1f, 0f));
		verts.Add(new Vector3(0f, -1f, 0f));
		verts.Add(new Vector3(0f, 0f, 0f));
		uvs.Add(new Vector2(this.mRect.xMax, this.mRect.yMax));
		uvs.Add(new Vector2(this.mRect.xMax, this.mRect.yMin));
		uvs.Add(new Vector2(this.mRect.xMin, this.mRect.yMin));
		uvs.Add(new Vector2(this.mRect.xMin, this.mRect.yMax));
		cols.Add(item);
		cols.Add(item);
		cols.Add(item);
		cols.Add(item);
	}

	// Token: 0x0400035E RID: 862
	[HideInInspector]
	[SerializeField]
	private Rect mRect = new Rect(0f, 0f, 1f, 1f);

	// Token: 0x0400035F RID: 863
	[HideInInspector]
	[SerializeField]
	private Shader mShader;

	// Token: 0x04000360 RID: 864
	[HideInInspector]
	[SerializeField]
	private Texture mTexture;

	// Token: 0x04000361 RID: 865
	private Material mDynamicMat;

	// Token: 0x04000362 RID: 866
	private bool mCreatingMat;

	// Token: 0x04000363 RID: 867
	private int mPMA = -1;
}

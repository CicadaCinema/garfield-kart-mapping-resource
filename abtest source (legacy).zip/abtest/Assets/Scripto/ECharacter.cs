﻿using System;

// Token: 0x02000136 RID: 310
public enum ECharacter
{
	// Token: 0x040008D5 RID: 2261
	NONE = -1,
	// Token: 0x040008D6 RID: 2262
	GARFIELD,
	// Token: 0x040008D7 RID: 2263
	JON,
	// Token: 0x040008D8 RID: 2264
	LIZ,
	// Token: 0x040008D9 RID: 2265
	ODIE,
	// Token: 0x040008DA RID: 2266
	ARLENE,
	// Token: 0x040008DB RID: 2267
	NERMAL,
	// Token: 0x040008DC RID: 2268
	SQUEAK,
	// Token: 0x040008DD RID: 2269
	HARRY
}

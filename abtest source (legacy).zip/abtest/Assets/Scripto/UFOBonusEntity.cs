﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000F0 RID: 240
public class UFOBonusEntity : BonusEntity
{
	// Token: 0x06000686 RID: 1670 RVA: 0x00032C40 File Offset: 0x00030E40
	public UFOBonusEntity()
	{
		this.m_pTarget = null;
		this.IdealPath = null;
		this.m_PathPosition = MultiPathPosition.UNDEFINED_MP_POS;
		this.m_NextPathPosition = MultiPathPosition.UNDEFINED_MP_POS;
		this.m_Direction = Vector3.zero;
		this.CrossTarget = false;
		this.m_pUfo = new List<UFO>();
		this.m_pRay = default(Ray);
		this.m_eItem = EITEM.ITEM_UFO;
	}

	// Token: 0x17000100 RID: 256
	// (get) Token: 0x06000687 RID: 1671 RVA: 0x00006A7A File Offset: 0x00004C7A
	public float BonusDuration
	{
		get
		{
			return this.m_fBonusDuration;
		}
	}

	// Token: 0x06000688 RID: 1672 RVA: 0x00032CF4 File Offset: 0x00030EF4
	public override void Awake()
	{
		base.Awake();
		this.m_IgnoreCollision = (LayerMask.NameToLayer("Everything") & ~LayerMask.NameToLayer("ColWallUFO"));
		int num = 0;
		foreach (object obj in base.transform)
		{
			Transform transform = (Transform)obj;
			if (transform.GetComponent<UFO>() != null)
			{
				this.m_pUfo.Add(transform.GetComponent<UFO>());
				num++;
			}
		}
		this.m_bSynchronizePosition = true;
		this.m_bSynchronizeRotation = true;
	}

	// Token: 0x06000689 RID: 1673 RVA: 0x00032DB0 File Offset: 0x00030FB0
	public override void Launch()
	{
		base.Launch();
		this.m_fCurrentSafeCounter = 0f;
		float num = this.SpeedForward + this.m_pLauncher.GetBonusMgr().GetBonusValue(EITEM.ITEM_UFO, EBonusCustomEffect.SPEED) * this.SpeedForward / 100f;
		this.m_fCurrentSpeed = num / 3.6f;
		if (this.Race != null)
		{
			this.m_fCurrentTimerToDestroyUFO = 0f;
			this.SetActive(true);
			this.UFOReset();
			this.m_fCurrentTimerFinalDestination = 0f;
			if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
			{
				int randomGood = Singleton<RandomManager>.Instance.Next(0, this.m_pUfo.Count - 1);
				this.ChooseGoodRay(randomGood);
			}
			this.m_pTarget = (Kart)this.Race.GetRankedVehicle(0).GetVehicle();
			if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
			{
				this.m_Direction = this.m_pLauncher.Transform.position + this.m_pLauncher.Transform.parent.rotation * new Vector3(0f, 0f, 3f);
				this.m_pTransform.rotation = this.m_pLauncher.Transform.rotation;
				this.m_pTransform.position = this.m_pLauncher.Transform.position + this.m_pLauncher.transform.up * 7f;
			}
			for (int i = 0; i < this.m_pUfo.Count; i++)
			{
				this.m_pUfo[i].Appear();
			}
			this.m_eState = BonusEntity.BonusState.BONUS_LAUNCHED;
			if (this.SoundLaunched && this.SoundTravel)
			{
				this.SoundLaunched.Play();
				this.SoundTravel.Play();
			}
		}
	}

	// Token: 0x0600068A RID: 1674 RVA: 0x00032FA4 File Offset: 0x000311A4
	public override void SetActive(bool _Active)
	{
		base.SetActive(_Active);
		base.ActivateGameObject(_Active);
		if (_Active)
		{
			if (this.IdealPath != null)
			{
				this.IdealPath.UpdateMPPosition(ref this.m_PathPosition, this.m_pLauncher.Transform.position, 0, 0, false);
				this.m_LastUfoDist = this.IdealPath.GetDistToEndLine(this.m_PathPosition);
			}
			if (Singleton<GameManager>.Instance.GameMode != null && Singleton<GameManager>.Instance.GameMode.Hud != null)
			{
				Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp.SetUfoToNormal();
				Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp.UpdateUFO(this.m_LastUfoDist);
			}
		}
		else
		{
			this.SetDefaultValues();
		}
		if (Singleton<GameManager>.Instance.GameMode != null && Singleton<GameManager>.Instance.GameMode.Hud && Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp)
		{
			Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp.Ufo.enabled = _Active;
		}
	}

	// Token: 0x0600068B RID: 1675 RVA: 0x000330F0 File Offset: 0x000312F0
	public override void Update()
	{
		base.Update();
		float deltaTime = Time.deltaTime;
		if (this.IdealPath == null)
		{
			return;
		}
		if (this.m_bActive && this.m_pTarget != null)
		{
			if (this.m_eState == BonusEntity.BonusState.BONUS_ANIMLAUNCHED)
			{
				this.m_fCurrentTimerFinalDestination += deltaTime;
				if (this.m_fCurrentTimerFinalDestination > this.TimerToFinalDestination)
				{
					this.UFOInPlace(this.m_UfoToMove);
				}
				else
				{
					this.MoveUFOToFinalDestination(deltaTime, this.m_UfoToMove);
				}
			}
			if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
			{
				this.m_fCurrentTimerToDestroyUFO += deltaTime;
				if (this.m_fCurrentTimerToDestroyUFO > -1f && this.m_fCurrentTimerToDestroyUFO > this.TimerToDestroyUFO && this.m_eState < BonusEntity.BonusState.BONUS_ANIMLAUNCHED)
				{
					this.RemoveUFO(true);
					this.m_fCurrentTimerToDestroyUFO = -1f;
				}
				Vector3 a = this.m_pTarget.GetPosition();
				if (this.m_eState == BonusEntity.BonusState.BONUS_LAUNCHED)
				{
					this.m_pTarget = (Kart)this.Race.GetRankedVehicle(0).GetVehicle();
					bool flag = false;
					float distToEndLine = this.IdealPath.GetDistToEndLine(this.m_PathPosition);
					if (distToEndLine - this.m_LastUfoDist > 500f)
					{
						flag = true;
					}
					float distToEndLine2 = this.IdealPath.GetDistToEndLine(this.m_pTarget.RaceStats.GetGuidePosition());
					if (this.m_pTarget == this.m_pLauncher || (Mathf.Abs(distToEndLine2 - distToEndLine) < 15f && distToEndLine < distToEndLine2))
					{
						this.CrossTarget = true;
					}
					RcFastValuePath rcFastValuePath = null;
					if (this.IdealPath.BValuePaths)
					{
						rcFastValuePath = (RcFastValuePath)this.m_PathPosition.section.GetSimplePath();
					}
					if (this.CrossTarget && Mathf.Abs(((this.m_fSpecifiedTargetPos == 0f) ? distToEndLine2 : this.m_fSpecifiedTargetPos) - distToEndLine) > this.EndDistance && !flag && rcFastValuePath != null && (rcFastValuePath.GetIntPointValue(this.m_PathPosition.pathPosition.index) & 2) == 0 && !this.m_bCrossSection)
					{
						this.UFOArrived();
					}
					else
					{
						if (flag && Mathf.Abs(distToEndLine2 - this.m_LastUfoDist) < this.EndDistance)
						{
							this.m_fSpecifiedTargetPos = distToEndLine - this.EndDistance;
						}
						this.SynchronizePosition(distToEndLine);
						this.IdealPath.UpdateMPPosition(ref this.m_PathPosition, this.m_pTransform.position, 3, 1, false);
						this.m_NextPathPosition = this.m_PathPosition;
						if (this.FirstDistanceToPath == 0f)
						{
							this.FirstDistanceToPath = 5f + Mathf.Clamp(Mathf.Abs(this.m_PathPosition.section.GetSimplePath().GetSignedDistToSegment2D(this.m_pTransform.position, this.m_PathPosition.pathPosition.index, Vector3.up)), 0f, 50f);
						}
						else if (this.FirstDistanceToPath > 5f && Mathf.Abs(this.m_PathPosition.section.GetSimplePath().GetSignedDistToSegment2D(this.m_pTransform.position, this.m_PathPosition.pathPosition.index, Vector3.up)) < 1f)
						{
							this.FirstDistanceToPath = 5f;
						}
						float firstDistanceToPath = this.FirstDistanceToPath;
						a = this.m_PathPosition.section.GetSimplePath().MoveOnPath(ref this.m_NextPathPosition.pathPosition, ref firstDistanceToPath, true) + Vector3.up * this.UfoHeight;
						if (this.m_NextPathPosition.pathPosition.index == this.m_PathPosition.section.GetSimplePath().GetNbPoints() - 1 && firstDistanceToPath > 0f)
						{
							RcMultiPathSection rcMultiPathSection = null;
							float num = 1E+38f;
							foreach (RcMultiPathSection rcMultiPathSection2 in this.m_PathPosition.section.m_pAfterBranches)
							{
								if (this.m_pTarget.RaceStats.GetGuidePosition().section == rcMultiPathSection2)
								{
									rcMultiPathSection = rcMultiPathSection2;
									break;
								}
								if (rcMultiPathSection2 && rcMultiPathSection2.GetDistToEndLine() < num)
								{
									rcMultiPathSection = rcMultiPathSection2;
									num = rcMultiPathSection2.GetDistToEndLine();
								}
							}
							if (rcMultiPathSection != null)
							{
								if (this.CrossTarget && this.m_PathPosition.section.m_pAfterBranches.Length > 1)
								{
									this.m_bCrossSection = true;
								}
								else if (this.CrossTarget && this.m_bCrossSection && this.m_PathPosition.section.m_pAfterBranches.Length == 1)
								{
									this.m_bCrossSection = false;
								}
								this.m_NextPathPosition.pathPosition = PathPosition.UNDEFINED_POSITION;
								a = rcMultiPathSection.GetSimplePath().MoveOnPath(ref this.m_NextPathPosition.pathPosition, ref firstDistanceToPath, true) + Vector3.up * this.UfoHeight;
							}
						}
						this.m_Direction = (a - this.m_pTransform.position).normalized;
						if (this.m_Direction != Vector3.zero)
						{
							Quaternion quaternion = default(Quaternion);
							quaternion = Quaternion.LookRotation(this.m_Direction);
							if (this.m_pTransform.rotation != quaternion)
							{
								this.m_pTransform.rotation = quaternion;
							}
							this.m_pTransform.position += deltaTime * (this.m_Direction * this.m_fCurrentSpeed);
						}
					}
				}
				else if (this.m_eState == BonusEntity.BonusState.BONUS_TRIGGERED)
				{
					bool flag2 = true;
					this.m_fCurrentSafeCounter += deltaTime;
					for (int j = 0; j < this.m_pUfo.Count; j++)
					{
						if (this.m_pUfo[j].AnimLeaveIsPlaying())
						{
							flag2 = false;
							break;
						}
					}
					if (this.m_fCurrentSafeCounter >= this.m_fSafeCounter)
					{
						flag2 = true;
					}
					if (flag2)
					{
						this.SynchronizeDestroy();
					}
				}
			}
			if (this.m_fTimerToLeaveUfo != -1f)
			{
				this.m_fTimerToLeaveUfo += deltaTime;
				if (this.m_fTimerToLeaveUfo > 0.8f)
				{
					this.LeaveUfo();
					this.m_fTimerToLeaveUfo = -1f;
				}
			}
		}
		if (Singleton<GameManager>.Instance.GameMode != null && Singleton<GameManager>.Instance.GameMode.Hud != null)
		{
			Singleton<GameManager>.Instance.GameMode.Hud.HudRadarComp.UpdateUFO(this.m_LastUfoDist);
		}
	}

	// Token: 0x0600068C RID: 1676 RVA: 0x00006A82 File Offset: 0x00004C82
	public override void DoDestroy()
	{
		base.DoDestroy();
		this.SetDefaultValues();
		this.SetActive(false);
		Singleton<BonusMgr>.Instance.UfoLaunched = false;
	}

	// Token: 0x0600068D RID: 1677 RVA: 0x000337C4 File Offset: 0x000319C4
	public void SetDefaultValues()
	{
		this.m_PathPosition = MultiPathPosition.UNDEFINED_MP_POS;
		this.m_NextPathPosition = MultiPathPosition.UNDEFINED_MP_POS;
		this.m_pTarget = null;
		this.CrossTarget = false;
		this.m_LastUfoDist = 0f;
		this.m_fSpecifiedTargetPos = 0f;
		this.m_UfoToMove = -1;
		this.m_bCrossSection = false;
		this.UFOReset();
		this.m_fTimerToLeaveUfo = -1f;
	}

	// Token: 0x0600068E RID: 1678 RVA: 0x0003382C File Offset: 0x00031A2C
	public void UFOArrived()
	{
		this.m_pRay.origin = this.m_pTransform.position;
		this.m_pRay.direction = this.m_pTransform.rotation * Vector3.left;
		Vector3 vector = Vector3.zero;
		Vector3 a = Vector3.zero;
		RaycastHit raycastHit;
		bool flag = Physics.Raycast(this.m_pRay, out raycastHit, 25f, this.m_IgnoreCollision);
		this.m_pRay.direction = this.m_pTransform.rotation * Vector3.right;
		RaycastHit raycastHit2;
		bool flag2 = Physics.Raycast(this.m_pRay, out raycastHit2, 25f, this.m_IgnoreCollision);
		if (flag && flag2)
		{
			vector = raycastHit.point;
			a = raycastHit2.point;
			float num = (a - vector).magnitude;
			num /= 3f;
			this.SynchronizeUfoLaunch(num, vector);
		}
	}

	// Token: 0x0600068F RID: 1679 RVA: 0x0003391C File Offset: 0x00031B1C
	public void UFOReset()
	{
		for (int i = 0; i < this.m_pUfo.Count; i++)
		{
			this.m_pUfo[i].Reset();
		}
	}

	// Token: 0x06000690 RID: 1680 RVA: 0x00033958 File Offset: 0x00031B58
	public void UFOInPlace(int _UfoToMove)
	{
		this.m_eState = BonusEntity.BonusState.BONUS_ONGROUND;
		if (_UfoToMove == -1)
		{
			for (int i = 0; i < this.m_pUfo.Count; i++)
			{
				this.m_pUfo[i].InPlace(true);
			}
		}
		else
		{
			this.m_pUfo[_UfoToMove].InPlace(false);
		}
		if (this.SoundTravel && this.SoundDeploy)
		{
			this.SoundDeploy.Play();
			this.SoundTravel.Stop();
		}
	}

	// Token: 0x06000691 RID: 1681 RVA: 0x000339F0 File Offset: 0x00031BF0
	public void MoveUFOToFinalDestination(float _deltaTime, int _UfoToMove)
	{
		if (_UfoToMove == -1)
		{
			for (int i = 0; i < this.m_pUfo.Count; i++)
			{
				this.m_pUfo[i].Move(_deltaTime);
			}
		}
		else
		{
			this.m_pUfo[_UfoToMove].Move(_deltaTime);
		}
	}

	// Token: 0x06000692 RID: 1682 RVA: 0x00033A4C File Offset: 0x00031C4C
	public void RemoveUFO(bool _All)
	{
		if (Network.peerType != NetworkPeerType.Disconnected && this.m_pNetworkView != null)
		{
			this.m_pNetworkView.RPC("OnRemoveUFO", RPCMode.All, new object[]
			{
				_All
			});
		}
		else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
		{
			this.DoRemoveUFO(_All);
		}
	}

	// Token: 0x06000693 RID: 1683 RVA: 0x00033ABC File Offset: 0x00031CBC
	public void DoRemoveUFO(bool _All)
	{
		if (_All)
		{
			for (int i = 0; i < this.m_pUfo.Count; i++)
			{
				this.m_pUfo[i].DeactivateCollider();
			}
			this.m_fTimerToLeaveUfo = 0f;
		}
		else
		{
			this.m_pUfo[this.m_UfoToMove].PlayLeaveAnim();
			this.m_eState = BonusEntity.BonusState.BONUS_TRIGGERED;
		}
		if (this.SoundDeploy)
		{
			this.SoundDeploy.Stop();
		}
	}

	// Token: 0x06000694 RID: 1684 RVA: 0x00033B44 File Offset: 0x00031D44
	public void MatchToTarget(UFO _Ufo, Kart _newTarget)
	{
		this.m_fBonusDuration = _newTarget.GetBonusMgr().GetBonusValue(EITEM.ITEM_UFO, EBonusCustomEffect.DURATION);
		this.m_eState = BonusEntity.BonusState.BONUS_ANIMLAUNCHED;
		this.m_fCurrentTimerFinalDestination = 0f;
		this.m_pTarget = _newTarget;
		for (int i = 0; i < this.m_pUfo.Count; i++)
		{
			if (this.m_pUfo[i] != _Ufo)
			{
				this.m_pUfo[i].PlayLeaveAnim();
			}
			else
			{
				this.m_UfoToMove = i;
				this.m_pUfo[i].MoveToTarget(this.m_pTarget, this.TimerToFinalDestination);
			}
		}
	}

	// Token: 0x06000695 RID: 1685 RVA: 0x00033BEC File Offset: 0x00031DEC
	public void ChooseGoodRay(int RandomGood)
	{
		if (Network.peerType != NetworkPeerType.Disconnected && this.m_pNetworkView != null)
		{
			this.m_pNetworkView.RPC("OnChooseGoodRay", RPCMode.All, new object[]
			{
				RandomGood
			});
		}
		else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
		{
			this.DoChooseGoodRay(RandomGood);
		}
	}

	// Token: 0x06000696 RID: 1686 RVA: 0x00006AA2 File Offset: 0x00004CA2
	public void DoChooseGoodRay(int RandomGood)
	{
		if (this.m_pUfo[RandomGood] != null)
		{
			this.m_pUfo[RandomGood].GoodRay = true;
		}
	}

	// Token: 0x06000697 RID: 1687 RVA: 0x00006ACD File Offset: 0x00004CCD
	public void SynchronizeDestroy()
	{
		if (Network.isServer)
		{
			this.m_pNetworkView.RPC("OnSynchronizeDestroy", RPCMode.All, new object[0]);
		}
		else if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.DoDestroy();
		}
	}

	// Token: 0x06000698 RID: 1688 RVA: 0x00033C5C File Offset: 0x00031E5C
	public void LeaveUfo()
	{
		if (Network.peerType != NetworkPeerType.Disconnected && this.m_pNetworkView != null)
		{
			this.m_pNetworkView.RPC("OnLeaveUfo", RPCMode.All, new object[0]);
		}
		else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
		{
			this.DoLeaveUfo();
		}
	}

	// Token: 0x06000699 RID: 1689 RVA: 0x00033CC4 File Offset: 0x00031EC4
	public void DoLeaveUfo()
	{
		for (int i = 0; i < this.m_pUfo.Count; i++)
		{
			this.m_pUfo[i].PlayLeaveAnim();
			this.m_eState = BonusEntity.BonusState.BONUS_TRIGGERED;
		}
	}

	// Token: 0x0600069A RID: 1690 RVA: 0x00033D08 File Offset: 0x00031F08
	public void SynchronizePosition(float _UfoDist)
	{
		if (Network.peerType != NetworkPeerType.Disconnected && this.m_pNetworkView != null)
		{
			this.m_pNetworkView.RPC("OnSynchronizePosition", RPCMode.All, new object[]
			{
				_UfoDist
			});
		}
		else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
		{
			this.DoSynchronizePosition(_UfoDist);
		}
	}

	// Token: 0x0600069B RID: 1691 RVA: 0x00006B05 File Offset: 0x00004D05
	public void DoSynchronizePosition(float _UfoDist)
	{
		this.m_LastUfoDist = _UfoDist;
	}

	// Token: 0x0600069C RID: 1692 RVA: 0x00033D78 File Offset: 0x00031F78
	public void SynchronizeUfoLaunch(float Dist, Vector3 LeftPos)
	{
		if (Network.peerType != NetworkPeerType.Disconnected && this.m_pNetworkView != null)
		{
			this.m_pNetworkView.RPC("OnSynchronizeUfoLaunch", RPCMode.All, new object[]
			{
				Dist,
				LeftPos
			});
		}
		else if (Network.peerType == NetworkPeerType.Disconnected || this.m_pNetworkView == null)
		{
			this.DoSynchronizeUfoLaunch(Dist, LeftPos);
		}
	}

	// Token: 0x0600069D RID: 1693 RVA: 0x00033DF4 File Offset: 0x00031FF4
	public void DoSynchronizeUfoLaunch(float Dist, Vector3 LeftPos)
	{
		for (int i = 0; i < this.m_pUfo.Count; i++)
		{
			Vector3 finalPosition = LeftPos + this.m_pRay.direction * ((float)i * Dist + Dist / 2f);
			this.m_pUfo[i].Launch(finalPosition, this.TimerToFinalDestination, Dist);
		}
		if (this.m_eState == BonusEntity.BonusState.BONUS_LAUNCHED)
		{
			this.m_eState = BonusEntity.BonusState.BONUS_ANIMLAUNCHED;
		}
	}

	// Token: 0x0400066B RID: 1643
	private Kart m_pTarget;

	// Token: 0x0400066C RID: 1644
	public float SpeedForward;

	// Token: 0x0400066D RID: 1645
	public RcRace Race;

	// Token: 0x0400066E RID: 1646
	public RcMultiPath IdealPath;

	// Token: 0x0400066F RID: 1647
	private MultiPathPosition m_PathPosition;

	// Token: 0x04000670 RID: 1648
	private MultiPathPosition m_NextPathPosition;

	// Token: 0x04000671 RID: 1649
	private float FirstDistanceToPath;

	// Token: 0x04000672 RID: 1650
	public float EndDistance = 100f;

	// Token: 0x04000673 RID: 1651
	private float m_fCurrentSpeed;

	// Token: 0x04000674 RID: 1652
	protected Vector3 m_Direction;

	// Token: 0x04000675 RID: 1653
	private bool CrossTarget;

	// Token: 0x04000676 RID: 1654
	private float m_LastUfoDist;

	// Token: 0x04000677 RID: 1655
	private float m_fSpecifiedTargetPos;

	// Token: 0x04000678 RID: 1656
	private List<UFO> m_pUfo;

	// Token: 0x04000679 RID: 1657
	private Ray m_pRay;

	// Token: 0x0400067A RID: 1658
	private LayerMask m_IgnoreCollision;

	// Token: 0x0400067B RID: 1659
	public float TimerToFinalDestination = 1f;

	// Token: 0x0400067C RID: 1660
	private float m_fCurrentTimerFinalDestination;

	// Token: 0x0400067D RID: 1661
	private int m_UfoToMove = -1;

	// Token: 0x0400067E RID: 1662
	public float UfoHeight = 3f;

	// Token: 0x0400067F RID: 1663
	private bool m_bCrossSection;

	// Token: 0x04000680 RID: 1664
	private float m_fTimerToLeaveUfo = -1f;

	// Token: 0x04000681 RID: 1665
	public float TimerToDestroyUFO = 20f;

	// Token: 0x04000682 RID: 1666
	private float m_fCurrentTimerToDestroyUFO;

	// Token: 0x04000683 RID: 1667
	private float m_fSafeCounter = 6f;

	// Token: 0x04000684 RID: 1668
	private float m_fCurrentSafeCounter;

	// Token: 0x04000685 RID: 1669
	private float m_fBonusDuration;

	// Token: 0x04000686 RID: 1670
	public AudioSource SoundLaunched;

	// Token: 0x04000687 RID: 1671
	public AudioSource SoundTravel;

	// Token: 0x04000688 RID: 1672
	public AudioSource SoundDeploy;
}

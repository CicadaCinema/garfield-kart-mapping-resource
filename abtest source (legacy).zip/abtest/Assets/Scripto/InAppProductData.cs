﻿using System;

// Token: 0x020001CD RID: 461
public class InAppProductData
{
	// Token: 0x06000C7F RID: 3199 RVA: 0x0000AB03 File Offset: 0x00008D03
	public InAppProductData(string pProductID, string pName, string pPrice, string pDescription)
	{
		this._productID = pProductID;
		this._name = pName;
		this._price = pPrice;
		this._description = pDescription;
		this._isInPromo = this._description.StartsWith("#");
	}

	// Token: 0x17000199 RID: 409
	// (get) Token: 0x06000C80 RID: 3200 RVA: 0x0000AB3E File Offset: 0x00008D3E
	public string ProductID
	{
		get
		{
			return this._productID;
		}
	}

	// Token: 0x1700019A RID: 410
	// (get) Token: 0x06000C81 RID: 3201 RVA: 0x0000AB46 File Offset: 0x00008D46
	public string Name
	{
		get
		{
			return this._name;
		}
	}

	// Token: 0x1700019B RID: 411
	// (get) Token: 0x06000C82 RID: 3202 RVA: 0x0000AB4E File Offset: 0x00008D4E
	public string Price
	{
		get
		{
			return this._price;
		}
	}

	// Token: 0x1700019C RID: 412
	// (get) Token: 0x06000C83 RID: 3203 RVA: 0x0000AB56 File Offset: 0x00008D56
	public string Description
	{
		get
		{
			return this._description;
		}
	}

	// Token: 0x1700019D RID: 413
	// (get) Token: 0x06000C84 RID: 3204 RVA: 0x0000AB5E File Offset: 0x00008D5E
	public bool IsInPromo
	{
		get
		{
			return this._isInPromo;
		}
	}

	// Token: 0x06000C85 RID: 3205 RVA: 0x00053270 File Offset: 0x00051470
	public override string ToString()
	{
		return string.Format("[InAppProductData: ProductID={0}, Name={1}, Price={2}, Description={3}, IsInPromo={4}]", new object[]
		{
			this.ProductID,
			this.Name,
			this.Price,
			this.Description,
			this.IsInPromo
		});
	}

	// Token: 0x04000C29 RID: 3113
	private string _productID;

	// Token: 0x04000C2A RID: 3114
	private string _name;

	// Token: 0x04000C2B RID: 3115
	private string _price;

	// Token: 0x04000C2C RID: 3116
	private string _description;

	// Token: 0x04000C2D RID: 3117
	private bool _isInPromo;
}

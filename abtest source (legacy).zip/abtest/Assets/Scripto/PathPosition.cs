﻿using System;

// Token: 0x020001FA RID: 506
public struct PathPosition
{
	// Token: 0x06000DAB RID: 3499 RVA: 0x0000B615 File Offset: 0x00009815
	public PathPosition(int i, float r, float s)
	{
		this.index = i;
		this.ratio = r;
		this.sqrDist = s;
	}

	// Token: 0x170001D5 RID: 469
	// (get) Token: 0x06000DAC RID: 3500 RVA: 0x0000B62C File Offset: 0x0000982C
	public static PathPosition UNDEFINED_POSITION
	{
		get
		{
			return new PathPosition(-1, 0f, float.MaxValue);
		}
	}

	// Token: 0x04000D51 RID: 3409
	public int index;

	// Token: 0x04000D52 RID: 3410
	public float ratio;

	// Token: 0x04000D53 RID: 3411
	public float sqrDist;
}

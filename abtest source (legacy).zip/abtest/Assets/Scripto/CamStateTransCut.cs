﻿using System;
using UnityEngine;

// Token: 0x020001EF RID: 495
public class CamStateTransCut : CamStateTransition
{
	// Token: 0x170001D1 RID: 465
	// (get) Token: 0x06000D6B RID: 3435 RVA: 0x0000B290 File Offset: 0x00009490
	public override ECamState state
	{
		get
		{
			return ECamState.TransCut;
		}
	}

	// Token: 0x06000D6C RID: 3436 RVA: 0x0000B293 File Offset: 0x00009493
	public override void Enter(Transform _Transform, Transform _Target)
	{
		base.Enter(_Transform, _Target);
		this.m_ToState.m_bDamping = false;
	}

	// Token: 0x06000D6D RID: 3437 RVA: 0x0000B2A9 File Offset: 0x000094A9
	protected override bool Merge(float dt)
	{
		this.m_ToState.m_bDamping = true;
		return true;
	}
}

﻿using System;
using UnityEngine;

// Token: 0x02000203 RID: 515
public class RcMultiPathSection : MonoBehaviour
{
	// Token: 0x06000DEF RID: 3567 RVA: 0x0000B8EA File Offset: 0x00009AEA
	public RcFastPath GetSimplePath()
	{
		return this.m_pSimplePath;
	}

	// Token: 0x06000DF0 RID: 3568 RVA: 0x0000B8F2 File Offset: 0x00009AF2
	public void SetDistToEndLine(float _dist, RcMultiPathSection _firstSection)
	{
		if (_dist != this.m_fShortestDistToEndLine)
		{
			this.m_fShortestDistToEndLine = _dist;
			this.UpdateDistToEndLine(_firstSection);
		}
	}

	// Token: 0x06000DF1 RID: 3569 RVA: 0x0000B90E File Offset: 0x00009B0E
	public float GetDistToEndLine()
	{
		return this.m_fShortestDistToEndLine;
	}

	// Token: 0x06000DF2 RID: 3570 RVA: 0x0000B916 File Offset: 0x00009B16
	public float GetRescaledLength()
	{
		return this.m_pSimplePath.GetTotalLength(false) * this.m_fMultipathScale;
	}

	// Token: 0x06000DF3 RID: 3571 RVA: 0x0000B92B File Offset: 0x00009B2B
	public float GetLength()
	{
		return this.m_pSimplePath.GetTotalLength(false);
	}

	// Token: 0x06000DF4 RID: 3572 RVA: 0x0000B939 File Offset: 0x00009B39
	public float GetMultipathScale()
	{
		return this.m_fMultipathScale;
	}

	// Token: 0x06000DF5 RID: 3573 RVA: 0x0000B941 File Offset: 0x00009B41
	public void SetMultipathScale(float scale)
	{
		this.m_fMultipathScale = scale;
	}

	// Token: 0x06000DF6 RID: 3574 RVA: 0x0000B94A File Offset: 0x00009B4A
	public RcMultiPathSection GetAfterSection(int _branch)
	{
		return this.m_pAfterBranches[_branch];
	}

	// Token: 0x06000DF7 RID: 3575 RVA: 0x0000B954 File Offset: 0x00009B54
	public RcMultiPathSection GetBeforeSection(int _branch)
	{
		return this.m_pBeforeBranches[_branch];
	}

	// Token: 0x06000DF8 RID: 3576 RVA: 0x0000B95E File Offset: 0x00009B5E
	public int GetNbBranchesBefore()
	{
		if (this.m_pBeforeBranches != null)
		{
			return this.m_pBeforeBranches.Length;
		}
		return 0;
	}

	// Token: 0x06000DF9 RID: 3577 RVA: 0x0000B975 File Offset: 0x00009B75
	public int GetNbBranchesAfter()
	{
		if (this.m_pAfterBranches != null)
		{
			return this.m_pAfterBranches.Length;
		}
		return 0;
	}

	// Token: 0x06000DFA RID: 3578 RVA: 0x0005A8B8 File Offset: 0x00058AB8
	public void CreateFastPath(bool _Value)
	{
		if (!_Value)
		{
			this.m_pSimplePath = new RcFastPath(base.gameObject);
		}
		else
		{
			this.m_pSimplePath = new RcFastValuePath(base.gameObject);
		}
		this.m_fShortestDistToEndLine = 0f;
		this.m_fSegmentAverageLength = this.m_pSimplePath.GetTotalLength(false) / (float)this.m_pSimplePath.GetNbPoints();
	}

	// Token: 0x06000DFB RID: 3579 RVA: 0x0000B98C File Offset: 0x00009B8C
	public void DeleteFastPath()
	{
		if (this.m_pSimplePath != null)
		{
			this.m_pSimplePath = null;
		}
	}

	// Token: 0x06000DFC RID: 3580 RVA: 0x0005A91C File Offset: 0x00058B1C
	public void UpdateDistToEndLine(RcMultiPathSection _firstSection)
	{
		for (int i = 0; i < this.m_pBeforeBranches.Length; i++)
		{
			RcMultiPathSection rcMultiPathSection = this.m_pBeforeBranches[i];
			if (rcMultiPathSection != null && rcMultiPathSection != _firstSection)
			{
				Vector3 firstPoint = this.GetSimplePath().GetFirstPoint();
				Vector3 lastPoint = rcMultiPathSection.GetSimplePath().GetLastPoint();
				float magnitude = (firstPoint - lastPoint).magnitude;
				float num = this.m_fShortestDistToEndLine + magnitude + this.GetSimplePath().GetTotalLength(false);
				if (rcMultiPathSection.GetDistToEndLine() < num)
				{
					rcMultiPathSection.SetDistToEndLine(num, _firstSection);
				}
			}
		}
	}

	// Token: 0x06000DFD RID: 3581 RVA: 0x0005A9BC File Offset: 0x00058BBC
	public void UpdateMPPosition(ref MultiPathPosition _mpPosition, Vector3 position, int _segmentForward, int _segmentBackward, bool _2D)
	{
		RcMultiPathSection[] array = new RcMultiPathSection[8];
		for (int i = 0; i < 8; i++)
		{
			array[i] = null;
		}
		int num = 0;
		this.UpdateMPPosition(ref _mpPosition, position, _segmentForward, _segmentBackward, _2D, ref array, ref num, false);
	}

	// Token: 0x06000DFE RID: 3582 RVA: 0x0005A9FC File Offset: 0x00058BFC
	public void UpdateMPPosition(ref MultiPathPosition _mpPosition, Vector3 position, int _segmentForward, int _segmentBackward, bool _2D, ref RcMultiPathSection[] _pSkipTable, ref int _skipTableSize, bool _loopSection)
	{
		if (!_loopSection)
		{
			for (int i = 0; i < _skipTableSize; i++)
			{
				if (_pSkipTable[i] == this)
				{
					return;
				}
			}
		}
		if (this.m_pSimplePath == null)
		{
			return;
		}
		int num = _segmentForward;
		int num2 = _segmentBackward;
		int index = _mpPosition.pathPosition.index;
		bool flag = false;
		bool flag2 = false;
		if (num2 > index)
		{
			num2 = index;
			flag = true;
		}
		if (index + num >= this.m_pSimplePath.GetNbPoints())
		{
			num = this.m_pSimplePath.GetNbPoints() - 1 - index;
			flag2 = true;
		}
		_mpPosition.pathPosition.sqrDist = 1E+38f;
		this.m_pSimplePath.UpdatePathPosition(ref _mpPosition.pathPosition, position, num, num2, _2D, false);
		_pSkipTable[_skipTableSize] = this;
		_skipTableSize++;
		if (flag2 && _skipTableSize < 8)
		{
			int num3 = this.m_pSimplePath.GetNbPoints() - index;
			int segmentBackward = _segmentBackward + num3;
			int num4 = _segmentForward - num3;
			MultiPathPosition undefined_MP_POS = MultiPathPosition.UNDEFINED_MP_POS;
			for (int j = 0; j < this.m_pAfterBranches.Length; j++)
			{
				RcMultiPathSection rcMultiPathSection = this.m_pAfterBranches[j];
				if (rcMultiPathSection)
				{
					bool flag3 = rcMultiPathSection == this;
					undefined_MP_POS.section = rcMultiPathSection;
					undefined_MP_POS.pathPosition.index = 0;
					undefined_MP_POS.pathPosition.sqrDist = 1E+38f;
					rcMultiPathSection.UpdateMPPosition(ref undefined_MP_POS, position, (!flag3) ? num4 : 0, segmentBackward, _2D, ref _pSkipTable, ref _skipTableSize, flag3);
					if (undefined_MP_POS.pathPosition.sqrDist <= _mpPosition.pathPosition.sqrDist)
					{
						_mpPosition = undefined_MP_POS;
					}
				}
			}
		}
		if (flag && _skipTableSize < 8)
		{
			int num5 = _segmentBackward - index;
			int segmentForward = _segmentForward + index;
			MultiPathPosition undefined_MP_POS2 = MultiPathPosition.UNDEFINED_MP_POS;
			for (int k = 0; k < this.m_pBeforeBranches.Length; k++)
			{
				RcMultiPathSection rcMultiPathSection2 = this.m_pBeforeBranches[k];
				if (rcMultiPathSection2)
				{
					bool flag4 = rcMultiPathSection2 == this;
					undefined_MP_POS2.section = rcMultiPathSection2;
					undefined_MP_POS2.pathPosition.index = rcMultiPathSection2.GetSimplePath().GetNbPoints() - 2;
					undefined_MP_POS2.pathPosition.sqrDist = 1E+38f;
					rcMultiPathSection2.UpdateMPPosition(ref undefined_MP_POS2, position, segmentForward, (!flag4) ? num5 : 0, _2D, ref _pSkipTable, ref _skipTableSize, flag4);
					if (undefined_MP_POS2.pathPosition.sqrDist <= _mpPosition.pathPosition.sqrDist)
					{
						_mpPosition = undefined_MP_POS2;
					}
				}
			}
		}
	}

	// Token: 0x06000DFF RID: 3583 RVA: 0x0000B9A0 File Offset: 0x00009BA0
	public float GetDistToEndLine(PathPosition _pos)
	{
		return this.GetSimplePath().GetDistToEndOfPath(_pos.index, _pos.ratio) * this.m_fMultipathScale + this.m_fShortestDistToEndLine;
	}

	// Token: 0x06000E00 RID: 3584 RVA: 0x0005AC7C File Offset: 0x00058E7C
	public PathPosition GetPosAtDistToEndLine(float distToEnd)
	{
		float r;
		int segmentForEndOfPathDist = this.GetSimplePath().GetSegmentForEndOfPathDist((distToEnd - this.m_fShortestDistToEndLine) / this.m_fMultipathScale, out r);
		return new PathPosition(segmentForEndOfPathDist, r, 0f);
	}

	// Token: 0x04000D7D RID: 3453
	private const int MAX_RECURSIVE_CALL = 8;

	// Token: 0x04000D7E RID: 3454
	public RcMultiPathSection[] m_pBeforeBranches;

	// Token: 0x04000D7F RID: 3455
	public RcMultiPathSection[] m_pAfterBranches;

	// Token: 0x04000D80 RID: 3456
	protected RcFastPath m_pSimplePath;

	// Token: 0x04000D81 RID: 3457
	protected float m_fShortestDistToEndLine;

	// Token: 0x04000D82 RID: 3458
	protected float m_fSegmentAverageLength;

	// Token: 0x04000D83 RID: 3459
	[NonSerialized]
	protected float m_fMultipathScale = 1f;
}

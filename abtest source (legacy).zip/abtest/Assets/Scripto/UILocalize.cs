﻿using System;
using UnityEngine;

// Token: 0x0200007C RID: 124
[AddComponentMenu("NGUI/UI/Localize")]
[RequireComponent(typeof(UIWidget))]
public class UILocalize : MonoBehaviour
{
	// Token: 0x0600035F RID: 863 RVA: 0x000049C7 File Offset: 0x00002BC7
	private void OnLocalize(Localization loc)
	{
		if (this.mLanguage != loc.currentLanguage)
		{
			this.Localize();
		}
	}

	// Token: 0x06000360 RID: 864 RVA: 0x000049E5 File Offset: 0x00002BE5
	private void OnEnable()
	{
		if (this.mStarted && Localization.instance != null)
		{
			this.Localize();
		}
	}

	// Token: 0x06000361 RID: 865 RVA: 0x00004A08 File Offset: 0x00002C08
	private void Start()
	{
		this.mStarted = true;
		if (Localization.instance != null)
		{
			this.Localize();
		}
	}

	// Token: 0x06000362 RID: 866 RVA: 0x0001EFF4 File Offset: 0x0001D1F4
	public void Localize()
	{
		Localization instance = Localization.instance;
		UIWidget component = base.GetComponent<UIWidget>();
		UILabel uilabel = component as UILabel;
		UISprite uisprite = component as UISprite;
		if (string.IsNullOrEmpty(this.mLanguage) && string.IsNullOrEmpty(this.key) && uilabel != null)
		{
			this.key = uilabel.text;
		}
		string text = (!string.IsNullOrEmpty(this.key)) ? instance.Get(this.key) : string.Empty;
		if (uilabel != null)
		{
			UIInput uiinput = NGUITools.FindInParents<UIInput>(uilabel.gameObject);
			if (uiinput != null && uiinput.label == uilabel)
			{
				uiinput.defaultText = text;
			}
			else
			{
				uilabel.text = text;
			}
		}
		else if (uisprite != null)
		{
			uisprite.spriteName = text;
			uisprite.MakePixelPerfect();
		}
		this.mLanguage = instance.currentLanguage;
	}

	// Token: 0x040002E7 RID: 743
	public string key;

	// Token: 0x040002E8 RID: 744
	private string mLanguage;

	// Token: 0x040002E9 RID: 745
	private bool mStarted;
}

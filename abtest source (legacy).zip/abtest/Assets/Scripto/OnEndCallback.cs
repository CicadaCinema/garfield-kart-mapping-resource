﻿using System;

// Token: 0x0200026D RID: 621
// (Invoke) Token: 0x060010FA RID: 4346
public delegate void OnEndCallback();

﻿using System;
using UnityEngine;

// Token: 0x0200019E RID: 414
public class MenuMultiCreate : AbstractMenu
{
	// Token: 0x06000B22 RID: 2850 RVA: 0x00009B0E File Offset: 0x00007D0E
	public override void Awake()
	{
		base.Awake();
		this.networkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
	}

	// Token: 0x06000B23 RID: 2851 RVA: 0x0004B0B4 File Offset: 0x000492B4
	public override void OnEnter()
	{
		base.OnEnter();
		this.Input.text = this.networkMgr.SGameName;
		this.m_bNeedToCreateSolo = false;
		this.m_bNeedToCreateChampionship = false;
		if (this.CreatingLabel != null)
		{
			this.CreatingLabel.enabled = false;
		}
		this.Input.defaultText = Localization.instance.Get("MENU_GAME_NAME");
	}

	// Token: 0x06000B24 RID: 2852 RVA: 0x00009B30 File Offset: 0x00007D30
	public override void OnExit()
	{
		this.OnSubmit();
		base.OnExit();
	}

	// Token: 0x06000B25 RID: 2853 RVA: 0x0004B124 File Offset: 0x00049324
	private bool CreateSession()
	{
		Network.Disconnect();
		Network.maxConnections = this.networkMgr.maxPlayers;
		NetworkConnectionError networkConnectionError = Network.InitializeServer(this.networkMgr.maxPlayers, this.networkMgr.port, !Network.HavePublicAddress());
		if (networkConnectionError != NetworkConnectionError.NoError)
		{
			PopupDialog popupDialog = (PopupDialog)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG, false);
			if (popupDialog)
			{
				popupDialog.Show("MENU_POPUP_ERROR_INIT_SERVER");
			}
			Network.Disconnect();
			return false;
		}
		NetworkViewID networkViewID = Network.AllocateViewID();
		this.networkMgr.networkView.RPC("SetGameModeID", RPCMode.All, new object[]
		{
			networkViewID
		});
		return true;
	}

	// Token: 0x06000B26 RID: 2854 RVA: 0x00009B3E File Offset: 0x00007D3E
	public void OnButtonSingle()
	{
		this.OnSubmit();
		if (this.CreateSession())
		{
			if (this.CreatingLabel != null)
			{
				this.CreatingLabel.enabled = true;
			}
			this.m_bNeedToCreateSolo = true;
		}
	}

	// Token: 0x06000B27 RID: 2855 RVA: 0x00009B75 File Offset: 0x00007D75
	public void OnButtonChampionship()
	{
		this.OnSubmit();
		if (this.CreateSession())
		{
			if (this.CreatingLabel != null)
			{
				this.CreatingLabel.enabled = true;
			}
			this.m_bNeedToCreateChampionship = true;
		}
	}

	// Token: 0x06000B28 RID: 2856 RVA: 0x0004B1CC File Offset: 0x000493CC
	private void OnSubmit()
	{
		if (this.Input != null)
		{
			string text = string.Empty;
			if (this.Input.text != string.Empty)
			{
				text = NGUITools.StripSymbols(this.Input.text);
			}
			else
			{
				text = Localization.instance.Get(this.Input.defaultText);
			}
			if (!string.IsNullOrEmpty(text) && this.networkMgr != null && text != Localization.instance.Get("MENU_GAME_NAME"))
			{
				this.networkMgr.SGameName = text;
			}
			else if (this.Input.text.Equals(string.Empty))
			{
				this.networkMgr.SGameName = string.Empty;
			}
			this.Input.selected = false;
		}
	}

	// Token: 0x06000B29 RID: 2857 RVA: 0x0004B2B4 File Offset: 0x000494B4
	public void OnFailedToConnectToMasterServer(NetworkConnectionError Error)
	{
		this.ActSwapMenu(EMenus.MENU_SOLO);
		PopupDialog popupDialog = (PopupDialog)this.m_pMenuEntryPoint.ShowPopup(EPopUps.POPUP_DIALOG, false);
		if (popupDialog)
		{
			popupDialog.Show("MENU_POPUP_MASTER_CONNECTION_ERROR");
		}
		Network.Disconnect();
	}

	// Token: 0x06000B2A RID: 2858 RVA: 0x0004B2F8 File Offset: 0x000494F8
	public override void Update()
	{
		if (UnityEngine.Input.GetKeyDown(KeyCode.Escape))
		{
			this.ActSwapMenu(EMenus.MENU_MULTI);
		}
		if (this.networkMgr.DoneTesting)
		{
			if (this.m_bNeedToCreateSolo)
			{
				MasterServer.RegisterHost("GK12", "GK12", string.Concat(new string[]
				{
					"Single race,",
					(!this.networkMgr.BLanOnly) ? "WAN," : "LAN,",
					this.networkMgr.SGameName,
					",",
					this.networkMgr.ExternalIP,
					",waitPlayers,",
					((int)this.networkMgr.ConnectionStatus).ToString()
				}));
				this.ActSwapMenu(EMenus.MENU_MULTI_PLAYERS_LIST);
				(this.m_pMenuEntryPoint.MenuRefList[7] as MenuMultiWaitingRoom).Init(EMenus.MENU_MULTI_CREATE, 0, this.networkMgr.SGameName, 0);
				Singleton<GameConfigurator>.Instance.GameModeType = E_GameModeType.SINGLE;
				Singleton<GameConfigurator>.Instance.CurrentTrackIndex = UnityEngine.Random.Range(0, 3);
				this.m_bNeedToCreateSolo = false;
				return;
			}
			if (this.m_bNeedToCreateChampionship)
			{
				MasterServer.RegisterHost("GK12", "GK12", string.Concat(new string[]
				{
					"Championship,",
					(!this.networkMgr.BLanOnly) ? "WAN," : "LAN,",
					this.networkMgr.SGameName,
					",",
					this.networkMgr.ExternalIP,
					",waitPlayers,",
					((int)this.networkMgr.ConnectionStatus).ToString()
				}));
				this.ActSwapMenu(EMenus.MENU_MULTI_PLAYERS_LIST);
				(this.m_pMenuEntryPoint.MenuRefList[7] as MenuMultiWaitingRoom).Init(EMenus.MENU_MULTI_CREATE, 0, this.networkMgr.SGameName, 1);
				Singleton<GameConfigurator>.Instance.GameModeType = E_GameModeType.CHAMPIONSHIP;
				Singleton<GameConfigurator>.Instance.CurrentTrackIndex = 0;
				this.m_bNeedToCreateChampionship = false;
			}
		}
	}

	// Token: 0x04000AF3 RID: 2803
	private NetworkMgr networkMgr;

	// Token: 0x04000AF4 RID: 2804
	public UIInput Input;

	// Token: 0x04000AF5 RID: 2805
	public UILabel CreatingLabel;

	// Token: 0x04000AF6 RID: 2806
	private bool m_bNeedToCreateSolo;

	// Token: 0x04000AF7 RID: 2807
	private bool m_bNeedToCreateChampionship;
}

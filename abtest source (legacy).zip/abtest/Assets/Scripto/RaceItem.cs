﻿using System;
using UnityEngine;

// Token: 0x02000152 RID: 338
public abstract class RaceItem : MonoBehaviour
{
	// Token: 0x06000978 RID: 2424 RVA: 0x00042EE0 File Offset: 0x000410E0
	public virtual void Awake()
	{
		if (base.networkView != null)
		{
			base.networkView.observed = this;
		}
		this._effect = (GameObject)UnityEngine.Object.Instantiate(this.Effect);
		this._effect.transform.parent = base.transform;
		this._effect.transform.localPosition = Vector3.zero;
	}

	// Token: 0x06000979 RID: 2425 RVA: 0x00042F4C File Offset: 0x0004114C
	public virtual void DoOnTriggerEnter(GameObject other, int otherlayer)
	{
		if ((this.Layer & 1 << otherlayer) != 0 && other != null)
		{
			Kart componentInChildren = other.GetComponentInChildren<Kart>();
			if (componentInChildren.GetControlType() == RcVehicle.ControlType.Human)
			{
				this.DoTrigger(componentInChildren);
			}
		}
	}

	// Token: 0x0600097A RID: 2426 RVA: 0x00042F98 File Offset: 0x00041198
	public void OnTriggerEnter(Collider other)
	{
		if (Network.isServer && base.networkView != null)
		{
			if (other.gameObject.networkView != null)
			{
				NetworkViewID viewID = other.gameObject.networkView.viewID;
				base.networkView.RPC("OnNetworkViewTriggerEnter", RPCMode.All, new object[]
				{
					viewID
				});
			}
			else
			{
				base.networkView.RPC("OnLayerTriggerEnter", RPCMode.All, new object[]
				{
					other.gameObject.layer
				});
			}
		}
		else if (Network.peerType == NetworkPeerType.Disconnected || base.networkView == null)
		{
			this.DoOnTriggerEnter(other.gameObject, other.gameObject.layer);
		}
	}

	// Token: 0x0600097B RID: 2427 RVA: 0x00008954 File Offset: 0x00006B54
	[RPC]
	public void OnLayerTriggerEnter(int layer)
	{
		this.DoOnTriggerEnter(null, layer);
	}

	// Token: 0x0600097C RID: 2428 RVA: 0x00043070 File Offset: 0x00041270
	[RPC]
	public void OnNetworkViewTriggerEnter(NetworkViewID viewId)
	{
		NetworkView networkView = NetworkView.Find(viewId);
		if (networkView != null)
		{
			this.DoOnTriggerEnter(networkView.gameObject, networkView.gameObject.layer);
		}
	}

	// Token: 0x0600097D RID: 2429 RVA: 0x0000895E File Offset: 0x00006B5E
	protected virtual void DoTrigger(RcVehicle pVehicle)
	{
		this._effect.particleSystem.Play();
		base.collider.enabled = false;
		base.renderer.enabled = false;
	}

	// Token: 0x040009B1 RID: 2481
	public GameObject Effect;

	// Token: 0x040009B2 RID: 2482
	public LayerMask Layer;

	// Token: 0x040009B3 RID: 2483
	private GameObject _effect;
}

﻿using System;

// Token: 0x020000D9 RID: 217
public class KartBonus
{
	// Token: 0x060005C1 RID: 1473 RVA: 0x000060E4 File Offset: 0x000042E4
	public KartBonus()
	{
		this.m_eItem = EITEM.ITEM_NONE;
		this.m_iQuantity = 0;
		this.m_bAnimated = false;
		this.m_pSprite = null;
		this.m_fSecureAnimationTimer = 0f;
	}

	// Token: 0x060005C3 RID: 1475 RVA: 0x00006113 File Offset: 0x00004313
	public void Reset()
	{
		if (this.m_eItem == EITEM.ITEM_UFO)
		{
			Singleton<BonusMgr>.Instance.UfoLaunched = false;
		}
		this.m_eItem = EITEM.ITEM_NONE;
		this.m_iQuantity = 0;
		this.m_bAnimated = false;
		this.m_pSprite = null;
		this.m_fSecureAnimationTimer = 0f;
	}

	// Token: 0x060005C4 RID: 1476 RVA: 0x00006153 File Offset: 0x00004353
	public void Affect(KartBonus kb)
	{
		this.m_eItem = kb.m_eItem;
		this.m_iQuantity = kb.m_iQuantity;
		this.m_bAnimated = kb.m_bAnimated;
		this.m_pSprite = kb.m_pSprite;
		this.m_fSecureAnimationTimer = kb.m_fSecureAnimationTimer;
	}

	// Token: 0x060005C5 RID: 1477 RVA: 0x0002E7BC File Offset: 0x0002C9BC
	public static bool IsBehind(EITEM _Item)
	{
		foreach (Tuple<EITEM, bool> tuple in KartBonus.BonusBehind)
		{
			if (tuple.Item1 == _Item)
			{
				return tuple.Item2;
			}
		}
		return false;
	}

	// Token: 0x040005C8 RID: 1480
	public static Tuple<EITEM, bool>[] BonusBehind = new Tuple<EITEM, bool>[]
	{
		new Tuple<EITEM, bool>(EITEM.ITEM_NONE, false),
		new Tuple<EITEM, bool>(EITEM.ITEM_PIE, true),
		new Tuple<EITEM, bool>(EITEM.ITEM_AUTOLOCK_PIE, true),
		new Tuple<EITEM, bool>(EITEM.ITEM_SPRING, true),
		new Tuple<EITEM, bool>(EITEM.ITEM_LASAGNA, false),
		new Tuple<EITEM, bool>(EITEM.ITEM_DIAMOND, true),
		new Tuple<EITEM, bool>(EITEM.ITEM_UFO, false),
		new Tuple<EITEM, bool>(EITEM.ITEM_NAP, false),
		new Tuple<EITEM, bool>(EITEM.ITEM_PARFUME, false),
		new Tuple<EITEM, bool>(EITEM.ITEM_MAGIC, false)
	};

	// Token: 0x040005C9 RID: 1481
	public EITEM m_eItem;

	// Token: 0x040005CA RID: 1482
	public int m_iQuantity;

	// Token: 0x040005CB RID: 1483
	public bool m_bAnimated;

	// Token: 0x040005CC RID: 1484
	public BonusAnimation m_pSprite;

	// Token: 0x040005CD RID: 1485
	public float m_fSecureAnimationTimer;
}

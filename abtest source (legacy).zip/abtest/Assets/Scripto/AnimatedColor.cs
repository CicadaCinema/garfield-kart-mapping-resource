﻿using System;
using UnityEngine;

// Token: 0x02000057 RID: 87
[RequireComponent(typeof(UIWidget))]
[ExecuteInEditMode]
public class AnimatedColor : MonoBehaviour
{
	// Token: 0x0600024F RID: 591 RVA: 0x00003BDB File Offset: 0x00001DDB
	private void Awake()
	{
		this.mWidget = base.GetComponent<UIWidget>();
	}

	// Token: 0x06000250 RID: 592 RVA: 0x00003BE9 File Offset: 0x00001DE9
	private void Update()
	{
		this.mWidget.color = this.color;
	}

	// Token: 0x040001D9 RID: 473
	public Color color = Color.white;

	// Token: 0x040001DA RID: 474
	private UIWidget mWidget;
}

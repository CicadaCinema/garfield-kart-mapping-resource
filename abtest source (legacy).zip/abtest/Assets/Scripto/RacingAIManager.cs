﻿using System;
using UnityEngine;

// Token: 0x020001E6 RID: 486
[Serializable]
public class RacingAIManager
{
	// Token: 0x170001C5 RID: 453
	// (get) Token: 0x06000D28 RID: 3368 RVA: 0x0000B06F File Offset: 0x0000926F
	private float m_fMinRatioIdealFromMaxSpeed
	{
		get
		{
			return Singleton<GameConfigurator>.Instance.AISettings.BehaviourSettings.m_fMinRatioIdealFromMaxSpeed;
		}
	}

	// Token: 0x06000D29 RID: 3369 RVA: 0x00056064 File Offset: 0x00054264
	public virtual void Init(AIPathHandler pPathModule)
	{
		this._pathModule = pPathModule;
		for (int i = 0; i < 6; i++)
		{
			this.AIs[i] = null;
		}
	}

	// Token: 0x06000D2A RID: 3370 RVA: 0x00056094 File Offset: 0x00054294
	public void Reset()
	{
		if (this._forecaster)
		{
			this._forecaster.Reset();
		}
		for (int i = 0; i < this._nbAI; i++)
		{
			this.AIs[i].Reset();
		}
	}

	// Token: 0x06000D2B RID: 3371 RVA: 0x0000B085 File Offset: 0x00009285
	public virtual RacingAI CreateAI()
	{
		return new RacingAI();
	}

	// Token: 0x06000D2C RID: 3372 RVA: 0x000560E0 File Offset: 0x000542E0
	public void RegisterVirtualController(RcVirtualController pVirtualController, E_AILevel pLevel)
	{
		this.AIs[this._nbAI] = this.CreateAI();
		this.AIs[this._nbAI].Level = pLevel;
		this.AIs[this._nbAI].VirtualController = pVirtualController;
		this.AIs[this._nbAI].VirtualController.AIIndex = this._nbAI;
		this.AIs[this._nbAI].Init();
		if (this._forecaster != null)
		{
			this._forecaster.RegisterClient(pVirtualController.GetVehicle(), this._pathModule.GetLeftBorder(this._nbAI), this._pathModule.GetRightBorder(this._nbAI));
			this._forecaster.UnableObserver(pVirtualController.GetVehicle().GetVehicleId(), true);
		}
		this._pathModule.InitIdealPaths(this.AIs[this._nbAI], this._nbAI);
		this._nbAI++;
	}

	// Token: 0x06000D2D RID: 3373 RVA: 0x000561DC File Offset: 0x000543DC
	public void RegisterHumanControllerForForecasterTests(RcController pController)
	{
		if (this._forecaster != null)
		{
			this._forecaster.RegisterClient(pController.GetVehicle(), this._pathModule.GetLeftBorder(0), this._pathModule.GetRightBorder(0));
			this._forecaster.UnableObserver(pController.GetVehicle().GetVehicleId(), true);
		}
	}

	// Token: 0x06000D2E RID: 3374 RVA: 0x0005623C File Offset: 0x0005443C
	public void UnregisterVirtualController(RcVirtualController pVirtualController)
	{
		for (int i = 0; i < this._nbAI; i++)
		{
			if (this.AIs[i].VirtualController == pVirtualController)
			{
				this.AIs[i].Term();
				this.AIs[i] = this.AIs[this._nbAI - 1];
				this.AIs[this._nbAI - 1] = null;
				this._nbAI--;
				break;
			}
		}
		if (this._forecaster)
		{
			this._forecaster.UnRegisterClient(pVirtualController.GetVehicle());
		}
	}

	// Token: 0x06000D2F RID: 3375 RVA: 0x000562E0 File Offset: 0x000544E0
	public RacingAI GetControllerAI(RcVirtualController pVirtualController)
	{
		for (int i = 0; i < this._nbAI; i++)
		{
			if (this.AIs[i].VirtualController == pVirtualController)
			{
				return this.AIs[i];
			}
		}
		return null;
	}

	// Token: 0x06000D30 RID: 3376 RVA: 0x00056328 File Offset: 0x00054528
	public void Update()
	{
		this.DispatchModes();
		if (this._forecaster && (!this._forceMode || this._forcedMode != 0))
		{
			this._forecaster.Update();
		}
		for (int i = 0; i < this._nbAI; i++)
		{
			if (this.AIs[i].VirtualController.IsDrivingEnabled())
			{
				this.UpdateAI(this.AIs[i]);
				this.AIs[i].Update();
			}
		}
	}

	// Token: 0x06000D31 RID: 3377 RVA: 0x000563B8 File Offset: 0x000545B8
	private void UpdateAI(RacingAI pAi)
	{
		float pWantedSteer = pAi.Steer;
		float pSpeedBehaviour = pAi.SpeedBehaviour;
		ForecastResult forecastResult = new ForecastResult();
		forecastResult.Direction = 0f;
		forecastResult.Weight = 0f;
		int vehicleId = pAi.Vehicle.GetVehicleId();
		switch (pAi.Mode)
		{
		case E_AIMode.IDLE_MODE:
			pWantedSteer = 0f;
			if (pAi.Vehicle.GetSpeedKPH() > 0f)
			{
				pSpeedBehaviour = -1f;
			}
			else
			{
				pSpeedBehaviour = 0f;
			}
			goto IL_189;
		case E_AIMode.START_MODE:
		case E_AIMode.DRIVEN_MODE:
			if (pAi.PreviousMode != E_AIMode.DRIVEN_MODE && pAi.PreviousMode != E_AIMode.START_MODE && this._forecaster)
			{
				this._forecaster.UnableForecast(vehicleId, true);
				this._forecaster.UnableObserver(vehicleId, true);
			}
			this.ComputeDriveParameters(pAi, ref pWantedSteer, ref pSpeedBehaviour);
			goto IL_189;
		case E_AIMode.GO_BACK_MODE:
		case E_AIMode.HALF_TURN_MODE:
			pSpeedBehaviour = -1f;
			pWantedSteer = 0f;
			if (pAi.Vehicle.GetSpeedKPH() <= 10f)
			{
				this._pathModule.UpdatePositionOnPath(pAi);
				RcFastPath currentPath = pAi.CurrentPath;
				int currentPathIndex = pAi.CurrentPathIndex;
				if (currentPathIndex != -1)
				{
					Vector3 lhs = Vector3.Cross(pAi.Vehicle.GetCameraUp(), currentPath.GetSegment(currentPathIndex));
					if (Vector3.Dot(lhs, pAi.Vehicle.GetCameraAt()) < 0f)
					{
						pWantedSteer = 1f;
					}
					else
					{
						pWantedSteer = -1f;
					}
				}
			}
			goto IL_189;
		}
		pWantedSteer = 0f;
		pSpeedBehaviour = 0f;
		IL_189:
		pAi.SetDriveParameters(pWantedSteer, pSpeedBehaviour);
	}

	// Token: 0x06000D32 RID: 3378 RVA: 0x00056558 File Offset: 0x00054758
	private void DispatchModes()
	{
		for (int i = 0; i < this._nbAI; i++)
		{
			RacingAI racingAI = this.AIs[i];
			RcVehicle vehicle = racingAI.Vehicle;
			if (this._forceMode)
			{
				racingAI.Mode = (E_AIMode)this._forcedMode;
			}
			else if (vehicle.IsLocked())
			{
				racingAI.Mode = E_AIMode.IDLE_MODE;
			}
			else if (racingAI.Mode == E_AIMode.IDLE_MODE)
			{
				racingAI.Mode = E_AIMode.START_MODE;
				racingAI.StartStartMode();
			}
			else if (racingAI.Mode == E_AIMode.START_MODE && racingAI.StartModeTime > 0f)
			{
				racingAI.Mode = E_AIMode.START_MODE;
			}
			else if (racingAI.AntiReverseRemainingTime > 0f)
			{
				racingAI.Mode = E_AIMode.HALF_TURN_MODE;
			}
			else if (racingAI.AntiJamRemainingTime > 0f)
			{
				racingAI.Mode = E_AIMode.GO_BACK_MODE;
			}
			else
			{
				racingAI.Mode = E_AIMode.DRIVEN_MODE;
			}
		}
	}

	// Token: 0x06000D33 RID: 3379 RVA: 0x00056644 File Offset: 0x00054844
	private bool IsOnRight(Vector3 pSegBegin, Vector3 pSegEnd, Vector3 pPt, Vector3 pUp)
	{
		Vector3 lhs = pSegEnd - pSegBegin;
		Vector3 rhs = pPt - pSegBegin;
		Vector3 lhs2 = Vector3.Cross(lhs, rhs);
		return Vector3.Dot(lhs2, pUp) <= 0f;
	}

	// Token: 0x06000D34 RID: 3380 RVA: 0x00003B80 File Offset: 0x00001D80
	protected virtual void CheckPositionOnPath(RacingAI pAi)
	{
	}

	// Token: 0x06000D35 RID: 3381 RVA: 0x0005667C File Offset: 0x0005487C
	public void ComputeDriveParameters(RacingAI pAi, ref float rpWantedSteer, ref float rpSpeedBehaviour)
	{
		if (this._pathModule.UpdatePositionOnPath(pAi))
		{
			this.CheckPositionOnPath(pAi);
			this._pathModule.UpdatePositionOnPath(pAi);
		}
		if (pAi.Vehicle.BArcadeDriftLock)
		{
			pAi.Vehicle.SetArcadeDriftFactor(0f);
			pAi.Vehicle.BArcadeDriftLock = false;
		}
		int currentPathIndex = pAi.CurrentPathIndex;
		if (currentPathIndex == -1)
		{
			rpSpeedBehaviour = 0f;
			rpWantedSteer = 0f;
			return;
		}
		RcVehicle vehicle = pAi.Vehicle;
		int vehicleId = pAi.Vehicle.GetVehicleId();
		Vector3 position = vehicle.GetPosition();
		Vector3 cameraUp = vehicle.GetCameraUp();
		Vector3 cameraAt = vehicle.GetCameraAt();
		Vector3 a = -1f * Vector3.Cross(cameraUp, cameraAt);
		ForecastResult forecastResult = new ForecastResult();
		ForecastResult forecastResult2 = new ForecastResult();
		if (this._forecaster)
		{
			forecastResult = this._forecaster.GetRepulsiveForecast(vehicleId);
			forecastResult2 = this._forecaster.GetAttractiveForecast(vehicleId);
		}
		Vector3 targetPoint = pAi.GetTargetPoint();
		float direction = forecastResult.Direction;
		float num = -forecastResult2.Direction;
		Vector3 vector = targetPoint - (num + direction) * a;
		float deltaTime = Time.deltaTime;
		Vector3 lhs = vector - position;
		lhs.Normalize();
		float num2 = Vector3.Dot(lhs, cameraAt);
		num2 = Mathf.Clamp(num2, -1f, 1f);
		float num3 = Mathf.Acos(num2) * 0.0174532924f;
		if (!this.IsOnRight(position, position + cameraAt, vector, cameraUp))
		{
			num3 = -num3;
		}
		float num4 = this.ComputeIdealRadius(vehicle, ref vector);
		float pIdealSpeedKPH = RcUtils.MsToKph(this.ComputeMaxSpeed(vehicle, num4));
		this.ComputeSpeedBehaviour(vehicle, forecastResult.Weight - Mathf.Abs(forecastResult.Direction), pIdealSpeedKPH, ref forecastResult, ref rpSpeedBehaviour);
		float num5 = 0f;
		float radius = vehicle.GetCarac().ComputeMinRadius(Mathf.Abs(vehicle.GetWheelSpeedMS()));
		float num6 = vehicle.SteeringRadiusToAngle(radius);
		if (num4 != 0f)
		{
			float num7 = vehicle.SteeringRadiusToAngle(num4);
			num5 = num7 / num6;
		}
		pAi.PidController.Record(num5, deltaTime);
		float output = pAi.PidController.GetOutput();
		rpWantedSteer = output;
		if (pAi.Mode == E_AIMode.START_MODE)
		{
			rpWantedSteer *= RcUtils.LinearInterpolation(pAi.StartModeDelay, 0f, 0f, 1f, pAi.StartModeTime, true);
		}
		this._debugAttraction = num;
		this._debugErrorAngle = num3;
		this._debugCollError = direction;
		this._debugPidOutput = output;
		this._debugMaxAngle = num6;
		this._debugIdealSteer = num5;
		this._debugWantedSteer = rpWantedSteer;
	}

	// Token: 0x06000D36 RID: 3382 RVA: 0x00056910 File Offset: 0x00054B10
	public void ComputeSpeedBehaviour(RcVehicle pVehicle, float pErrorDiff, float pIdealSpeedKPH, ref ForecastResult rpCollisionForecast, ref float rpSpeedBehaviour)
	{
		float num = pIdealSpeedKPH;
		if (pErrorDiff > this._speedCtrlMinError && this._speedCtrlMaxReduction > 0f)
		{
			float num2;
			if (pErrorDiff < this._speedCtrlMaxError)
			{
				num2 = RcUtils.LinearInterpolation(this._speedCtrlMinError, 0f, this._speedCtrlMaxError, this._speedCtrlMaxReduction, pErrorDiff, true);
			}
			else
			{
				num2 = this._speedCtrlMaxReduction;
			}
			num -= num2 * num;
		}
		if (num < this._minSpeed)
		{
			num = this._minSpeed;
		}
		float speedKPH = pVehicle.GetSpeedKPH();
		if (speedKPH < num)
		{
			rpSpeedBehaviour = 1f;
		}
		else if (speedKPH < num * 1.1f)
		{
			rpSpeedBehaviour = 0f;
		}
		else
		{
			rpSpeedBehaviour = -1f;
		}
	}

	// Token: 0x06000D37 RID: 3383 RVA: 0x0000B08C File Offset: 0x0000928C
	public void RegisterVehicle(RcVehicle pVehicle)
	{
		this.RegisterEntity(pVehicle, 4);
	}

	// Token: 0x06000D38 RID: 3384 RVA: 0x0000B096 File Offset: 0x00009296
	public void RegisterEntity(MonoBehaviour pEntity, int pType)
	{
		this._forecaster.RegisterEntity(pEntity, pType);
	}

	// Token: 0x06000D39 RID: 3385 RVA: 0x0000B0A5 File Offset: 0x000092A5
	public void UnregisterVehicle(RcVehicle pVehicle)
	{
		this._forecaster.UnRegisterEntity(pVehicle);
	}

	// Token: 0x06000D3A RID: 3386 RVA: 0x000569D0 File Offset: 0x00054BD0
	public float ComputeMaxSpeed(RcVehicle pVehicle, float pRadius)
	{
		float result;
		if (pRadius == 0f)
		{
			result = pVehicle.GetMaxSpeed();
		}
		else
		{
			result = Mathf.Max(pVehicle.GetMaxSpeed() * this.m_fMinRatioIdealFromMaxSpeed, pVehicle.GetCarac().ComputeMaxSpeedForRadius(Mathf.Abs(pRadius)));
		}
		return result;
	}

	// Token: 0x06000D3B RID: 3387 RVA: 0x00056A20 File Offset: 0x00054C20
	public float ComputeIdealRadius(RcVehicle pVehicle, ref Vector3 targetPoint)
	{
		Vector3 lhs = targetPoint - pVehicle.GetPosition();
		Vector3 cameraUp = pVehicle.GetCameraUp();
		Vector3 cameraAt = pVehicle.GetCameraAt();
		Vector3 rhs = -1f * Vector3.Cross(cameraUp, cameraAt);
		float num = Vector3.Dot(lhs, rhs);
		if (Mathf.Abs(num) == 0f)
		{
			return 0f;
		}
		float num2 = Vector3.Dot(lhs, pVehicle.GetCameraAt());
		return (num2 * num2 + num * num) / (2f * num);
	}

	// Token: 0x06000D3C RID: 3388 RVA: 0x00056AA4 File Offset: 0x00054CA4
	public void DebugDraw(bool pDebugDraw, int iAIDebugIndex)
	{
		if (pDebugDraw)
		{
			int i = iAIDebugIndex % this.AIs.Length;
			if (this.AIs[i] != null)
			{
				this.AIs[i].DebugDraw();
			}
			GUI.Label(new Rect(20f, 50f, 200f, 20f), string.Concat(new object[]
			{
				"AI ",
				i,
				" of ",
				this.AIs.Length.ToString()
			}));
			string[] array = new string[]
			{
				"Angle Error",
				"Col Error",
				"Attraction",
				"P",
				"I",
				"D",
				"PID",
				"Ideal Steer",
				"Wanted Steer"
			};
			for (i = 0; i < 9; i++)
			{
				GUI.contentColor = new Color(200f, 200f, 200f);
				GUI.Label(new Rect(400f, (float)(i * 19 + 12), 200f, 20f), array[i]);
			}
		}
		int num = 50;
		foreach (RacingAI racingAI in this.AIs)
		{
			if (racingAI != null)
			{
				GUI.contentColor = new Color(200f, 200f, 200f);
				GUI.Label(new Rect(600f, (float)num, 300f, 20f), string.Format("AI : {0} ; PATH : {1} ; {2}", racingAI.Level.ToString(), ((RcFastValuePath)racingAI.CurrentPath).PathType.ToString(), this._pathModule.GetPathIndex((RcFastValuePath)racingAI.CurrentPath).ToString()));
				num += 20;
			}
		}
	}

	// Token: 0x06000D3D RID: 3389 RVA: 0x00056C90 File Offset: 0x00054E90
	public void DebugDrawGizmos(bool pDebugDraw, int iAIDebugIndex)
	{
		if (pDebugDraw)
		{
			RacingAI racingAI = this.AIs[iAIDebugIndex % this.AIs.Length];
			if (racingAI != null && racingAI.Vehicle != null)
			{
				Vector3 start = Vector3.zero;
				Vector3 end = Vector3.zero;
				float[] array = new float[]
				{
					this._debugErrorAngle,
					0.15f * this._debugCollError,
					0.15f * this._debugAttraction,
					1f * racingAI.PidController.PCoefficient * racingAI.PidController.Error,
					1f * racingAI.PidController.ICoefficient * racingAI.PidController.ErrorIntegral,
					1f * racingAI.PidController.DCoefficient * racingAI.PidController.GetErrorDerivative(),
					this._debugPidOutput / this._debugMaxAngle,
					-this._debugIdealSteer,
					-this._debugWantedSteer
				};
				float num = -0.1f;
				float num2 = 3.5f;
				Vector3 position = racingAI.Vehicle.transform.position;
				Vector3 cameraUp = racingAI.Vehicle.GetCameraUp();
				Vector3 cameraAt = racingAI.Vehicle.GetCameraAt();
				Vector3 a = -1f * Vector3.Cross(cameraUp, cameraAt);
				start = position + num2 * cameraUp;
				end = position + (num2 + 8f * num) * cameraUp;
				Color color = new Color(0f, 1f, 0f, 1f);
				for (int i = 0; i < 9; i++)
				{
					start = position + num2 * cameraUp;
					end = position + num2 * cameraUp - array[i] * a;
					if (i > 5)
					{
						color = new Color(0f, 0f, 1f, 1f);
					}
					else if (i > 2)
					{
						color = new Color(1f, 0f, 1f, 1f);
					}
					else if (i == 2)
					{
						color = new Color(0f, 1f, 0f, 1f);
					}
					else if (i == 1)
					{
						color = new Color(1f, 0f, 0f, 1f);
					}
					else if (i == 0)
					{
						color = new Color(1f, 1f, 0f, 1f);
					}
					start.y -= 1f;
					end.y -= 1f;
					Debug.DrawLine(start, end, color);
					num2 += num;
				}
			}
			foreach (RacingAI racingAI2 in this.AIs)
			{
				if (racingAI2 != null)
				{
					Vector3 position2 = racingAI2.Vehicle.transform.position;
					Debug.DrawLine(position2, racingAI2.GetTargetPoint(), Color.red);
					racingAI2.DebugDrawGizmos();
				}
			}
		}
	}

	// Token: 0x04000CD2 RID: 3282
	public const int MAX_NB_AI = 6;

	// Token: 0x04000CD3 RID: 3283
	public const float GRAPH_SCALE_1 = 1f;

	// Token: 0x04000CD4 RID: 3284
	public const float GRAPH_SCALE_2 = 0.15f;

	// Token: 0x04000CD5 RID: 3285
	public const float GRAPH_SCALE_3 = 0.01f;

	// Token: 0x04000CD6 RID: 3286
	public const float GRAPH_V_STEP = -0.1f;

	// Token: 0x04000CD7 RID: 3287
	public const float GRAPH_INIT_ORD = 3.5f;

	// Token: 0x04000CD8 RID: 3288
	public const int NB_GRAPH_VALUES = 9;

	// Token: 0x04000CD9 RID: 3289
	private AIForecaster _forecaster;

	// Token: 0x04000CDA RID: 3290
	protected AIPathHandler _pathModule;

	// Token: 0x04000CDB RID: 3291
	public RacingAI[] AIs = new RacingAI[6];

	// Token: 0x04000CDC RID: 3292
	private int _nbAI;

	// Token: 0x04000CDD RID: 3293
	private bool _forceMode;

	// Token: 0x04000CDE RID: 3294
	private int _forcedMode;

	// Token: 0x04000CDF RID: 3295
	private float _speedCtrlMinError;

	// Token: 0x04000CE0 RID: 3296
	private float _speedCtrlMaxError;

	// Token: 0x04000CE1 RID: 3297
	private float _speedCtrlMaxReduction;

	// Token: 0x04000CE2 RID: 3298
	private float _minSpeed;

	// Token: 0x04000CE3 RID: 3299
	private float _debugAttraction;

	// Token: 0x04000CE4 RID: 3300
	private float _debugErrorAngle;

	// Token: 0x04000CE5 RID: 3301
	private float _debugCollError;

	// Token: 0x04000CE6 RID: 3302
	private float _debugPidOutput;

	// Token: 0x04000CE7 RID: 3303
	private float _debugMaxAngle;

	// Token: 0x04000CE8 RID: 3304
	private float _debugIdealSteer;

	// Token: 0x04000CE9 RID: 3305
	private float _debugWantedSteer;
}

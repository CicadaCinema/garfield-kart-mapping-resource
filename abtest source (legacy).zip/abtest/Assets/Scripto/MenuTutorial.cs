﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020001B7 RID: 439
public class MenuTutorial : AbstractMenu
{
	// Token: 0x06000BC9 RID: 3017 RVA: 0x000508AC File Offset: 0x0004EAAC
	public override void Awake()
	{
		base.Awake();
		UnityEngine.Object[] array = Resources.LoadAll("Tutorials", typeof(TutorialData));
		foreach (UnityEngine.Object @object in array)
		{
			if (((TutorialData)@object).bShownOnPc)
			{
				switch (((TutorialData)@object).m_eTutoType)
				{
				case MenuTutorial.ETutoMode.MODE_DRVING:
					this.m_oSelectedList = this.m_oTutorialDrivingList;
					break;
				case MenuTutorial.ETutoMode.MODE_BONUS:
					this.m_oSelectedList = this.m_oTutorialBonusList;
					break;
				case MenuTutorial.ETutoMode.MODE_CUSTOM:
					this.m_oSelectedList = this.m_oTutorialCustomList;
					break;
				}
				Resources.UnloadAsset(((TutorialData)@object).atlas.spriteMaterial.mainTexture);
				this.m_oSelectedList.Add((TutorialData)@object);
			}
		}
	}

	// Token: 0x06000BCA RID: 3018 RVA: 0x00050988 File Offset: 0x0004EB88
	public override void OnEnter(int iEntryPoint)
	{
		base.OnEnter();
		switch (iEntryPoint)
		{
		case 0:
			this.m_oSelectedList = this.m_oTutorialDrivingList;
			this.m_oCategory.key = "MENU_BT_TUTO_CONTROLE";
			break;
		case 1:
			this.m_oSelectedList = this.m_oTutorialBonusList;
			this.m_oCategory.key = "MENU_BT_TUTO_BONUS";
			break;
		case 2:
			this.m_oSelectedList = this.m_oTutorialCustomList;
			this.m_oCategory.key = "MENU_BT_TUTO_BONUS";
			break;
		}
		this.m_oCategory.Localize();
		this.m_iPage = 0;
		this.UpdatePanel();
	}

	// Token: 0x06000BCB RID: 3019 RVA: 0x0000A2B5 File Offset: 0x000084B5
	public override void OnExit()
	{
		base.OnExit();
		if (this.m_oPicture.atlas)
		{
			Resources.UnloadAsset(this.m_oPicture.atlas.spriteMaterial.mainTexture);
		}
	}

	// Token: 0x06000BCC RID: 3020 RVA: 0x0000A2EC File Offset: 0x000084EC
	public void OnButtonLeft()
	{
		this.m_iPage = (this.m_iPage + this.m_oSelectedList.Count - 1) % this.m_oSelectedList.Count;
		this.UpdatePanel();
	}

	// Token: 0x06000BCD RID: 3021 RVA: 0x0000A31A File Offset: 0x0000851A
	public void OnButtonRight()
	{
		this.m_iPage = (this.m_iPage + 1) % this.m_oSelectedList.Count;
		this.UpdatePanel();
	}

	// Token: 0x06000BCE RID: 3022 RVA: 0x00050A30 File Offset: 0x0004EC30
	public void UpdatePanel()
	{
		TutorialData tutorialData = this.m_oSelectedList[this.m_iPage];
		if (this.m_oTitle)
		{
			this.m_oTitle.key = tutorialData.m_TitleTextId;
			this.m_oTitle.Localize();
		}
		if (this.m_oDesc)
		{
			this.m_oDesc.key = tutorialData.m_InfoTextId;
			this.m_oDesc.Localize();
		}
		for (int i = 0; i < this.m_oLabel.Count; i++)
		{
			if (this.m_oLabel[i] && i < tutorialData.m_LabelId.Count)
			{
				if (tutorialData.m_LabelId[i] == string.Empty)
				{
					this.m_oLabel[i].gameObject.SetActive(false);
				}
				else
				{
					this.m_oLabel[i].gameObject.SetActive(true);
					this.m_oLabel[i].key = tutorialData.m_LabelId[i];
					this.m_oLabel[i].Localize();
				}
			}
		}
		if (this.m_oPicture)
		{
			if (this.m_oPicture.atlas)
			{
				Resources.UnloadAsset(this.m_oPicture.atlas.spriteMaterial.mainTexture);
			}
			this.m_oPicture.atlas = tutorialData.atlas;
			this.m_oPicture.atlas.spriteMaterial.mainTexture = (Resources.Load(this.m_oPicture.atlas.name, typeof(Texture2D)) as Texture2D);
			this.m_oPicture.spriteName = tutorialData.spriteName;
		}
		if (this.m_oPage)
		{
			this.m_oPage.text = (this.m_iPage + 1).ToString() + "/" + this.m_oSelectedList.Count.ToString();
		}
	}

	// Token: 0x06000BCF RID: 3023 RVA: 0x0000A33C File Offset: 0x0000853C
	public override void Update()
	{
		if (Application.platform == RuntimePlatform.Android && Input.GetKeyDown(KeyCode.Escape))
		{
			this.ActSwapMenu(EMenus.MENU_TUTO_HUB);
		}
	}

	// Token: 0x04000BA7 RID: 2983
	public UISprite m_oPicture;

	// Token: 0x04000BA8 RID: 2984
	public UILocalize m_oCategory;

	// Token: 0x04000BA9 RID: 2985
	public UILocalize m_oTitle;

	// Token: 0x04000BAA RID: 2986
	public UILocalize m_oDesc;

	// Token: 0x04000BAB RID: 2987
	public List<UILocalize> m_oLabel;

	// Token: 0x04000BAC RID: 2988
	public UILabel m_oPage;

	// Token: 0x04000BAD RID: 2989
	private List<TutorialData> m_oTutorialDrivingList = new List<TutorialData>();

	// Token: 0x04000BAE RID: 2990
	private List<TutorialData> m_oTutorialBonusList = new List<TutorialData>();

	// Token: 0x04000BAF RID: 2991
	private List<TutorialData> m_oTutorialCustomList = new List<TutorialData>();

	// Token: 0x04000BB0 RID: 2992
	private List<TutorialData> m_oSelectedList;

	// Token: 0x04000BB1 RID: 2993
	private int m_iPage;

	// Token: 0x020001B8 RID: 440
	public enum ETutoMode
	{
		// Token: 0x04000BB3 RID: 2995
		MODE_DRVING,
		// Token: 0x04000BB4 RID: 2996
		MODE_BONUS,
		// Token: 0x04000BB5 RID: 2997
		MODE_CUSTOM
	}
}

﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000264 RID: 612
public class ASE_ChartBoost
{
	// Token: 0x060010AC RID: 4268
	[DllImport("__Internal")]
	private static extern void ASE_ChartBoostInit(string sAppId, string sAppSignature);

	// Token: 0x060010AD RID: 4269 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void Init(string sAppId, string sAppSignature)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010AE RID: 4270
	[DllImport("__Internal")]
	private static extern void ASE_ChartBoostShowInterstitial(string sLocation);

	// Token: 0x060010AF RID: 4271 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void ShowInterstitial(string sLocation)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010B0 RID: 4272
	[DllImport("__Internal")]
	private static extern void ASE_ChartBoostCacheInterstitial(string sLocation);

	// Token: 0x060010B1 RID: 4273 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void CacheInterstitial(string sLocation)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010B2 RID: 4274
	[DllImport("__Internal")]
	private static extern void ASE_ChartBoostSetInterstitialRules(string sLocation, bool bShouldRequest, bool bShouldDisplay);

	// Token: 0x060010B3 RID: 4275 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetInterstitialRules(string sLocation, bool bShouldRequest, bool bShouldDisplay)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010B4 RID: 4276
	[DllImport("__Internal")]
	private static extern void ASE_ChartBoostShowMoreApps();

	// Token: 0x060010B5 RID: 4277 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void ShowMoreApps()
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010B6 RID: 4278
	[DllImport("__Internal")]
	private static extern void ASE_ChartBoostCacheMoreApps();

	// Token: 0x060010B7 RID: 4279 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void CacheMoreApps()
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010B8 RID: 4280
	[DllImport("__Internal")]
	private static extern void ASE_ChartBoostSetMoreAppsRules(bool bShouldRequest, bool bShouldDisplay);

	// Token: 0x060010B9 RID: 4281 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetMoreAppsRules(bool bShouldRequest, bool bShouldDisplay)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010BA RID: 4282
	[DllImport("__Internal")]
	private static extern void ASE_ChartBoostSetGameObjectName(string sGameObjectName);

	// Token: 0x060010BB RID: 4283
	[DllImport("__Internal")]
	private static extern void ASE_ChartBoostSetMethodName(string sMethodName);

	// Token: 0x060010BC RID: 4284 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetGameObjectName(string sGameObjectName)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010BD RID: 4285 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetMethodName(string sMethodName)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010BE RID: 4286 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetCallbackInformations(string sGameObjectName, string sMethodName)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x02000265 RID: 613
	public enum ChartBoostEvent
	{
		// Token: 0x04000FEB RID: 4075
		CBEVENT_INTERSTITIAL_DISMISS,
		// Token: 0x04000FEC RID: 4076
		CBEVENT_INTERSTITIAL_CLOSE,
		// Token: 0x04000FED RID: 4077
		CBEVENT_INTERSTITIAL_CLICK,
		// Token: 0x04000FEE RID: 4078
		CBEVENT_INTERSTITIAL_LOADFAIL,
		// Token: 0x04000FEF RID: 4079
		CBEVENT_MOREAPPS_DISMISS,
		// Token: 0x04000FF0 RID: 4080
		CBEVENT_MOREAPPS_CLOSE,
		// Token: 0x04000FF1 RID: 4081
		CBEVENT_MOREAPPS_CLICK,
		// Token: 0x04000FF2 RID: 4082
		CBEVENT_MOREAPPS_LOADFAIL
	}
}

﻿using System;
using UnityEngine;

// Token: 0x02000134 RID: 308
public class TimeTrialConfig : MonoBehaviour
{
	// Token: 0x040008CF RID: 2255
	public int Bronze;

	// Token: 0x040008D0 RID: 2256
	public int Silver;

	// Token: 0x040008D1 RID: 2257
	public int Gold;

	// Token: 0x040008D2 RID: 2258
	public int Platinium;
}

﻿using System;
using UnityEngine;

// Token: 0x02000096 RID: 150
public class PostEffects : MonoBehaviour
{
	// Token: 0x0600040B RID: 1035 RVA: 0x000244F4 File Offset: 0x000226F4
	public static Material CheckShaderAndCreateMaterial(Shader s, Material m2Create)
	{
		if (m2Create && m2Create.shader == s)
		{
			return m2Create;
		}
		if (!s)
		{
			return null;
		}
		if (!s.isSupported)
		{
			return null;
		}
		m2Create = new Material(s);
		m2Create.hideFlags = HideFlags.DontSave;
		return m2Create;
	}

	// Token: 0x0600040C RID: 1036 RVA: 0x00005060 File Offset: 0x00003260
	public static bool CheckSupport(bool needDepth)
	{
		return SystemInfo.supportsImageEffects && SystemInfo.supportsRenderTextures && (!needDepth || SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.Depth));
	}
}

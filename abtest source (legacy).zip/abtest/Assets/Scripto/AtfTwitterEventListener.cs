﻿using System;
using UnityEngine;

// Token: 0x0200022C RID: 556
public class AtfTwitterEventListener : MonoBehaviour
{
}

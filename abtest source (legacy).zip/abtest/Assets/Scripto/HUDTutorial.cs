﻿using System;
using UnityEngine;

// Token: 0x0200011D RID: 285
public class HUDTutorial : MonoBehaviour
{
	// Token: 0x060007E2 RID: 2018 RVA: 0x000078E8 File Offset: 0x00005AE8
	public void Awake()
	{
		if (Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
		{
			this.OnNext();
		}
	}

	// Token: 0x060007E3 RID: 2019 RVA: 0x00003B80 File Offset: 0x00001D80
	public void OnEnter()
	{
	}

	// Token: 0x060007E4 RID: 2020 RVA: 0x00003B80 File Offset: 0x00001D80
	public void OnExit()
	{
	}

	// Token: 0x060007E5 RID: 2021 RVA: 0x00007907 File Offset: 0x00005B07
	public void OnNext()
	{
		if (this.Next != null)
		{
			this.Next(this.m_bShowAgain);
		}
	}

	// Token: 0x060007E6 RID: 2022 RVA: 0x00007925 File Offset: 0x00005B25
	public void OnActivate(bool Checked)
	{
		this.m_bShowAgain = !Checked;
	}

	// Token: 0x04000803 RID: 2051
	public Action<bool> Next;

	// Token: 0x04000804 RID: 2052
	private bool m_bShowAgain;
}

﻿using System;
using UnityEngine;

// Token: 0x020001DD RID: 477
public class Forecasted : MonoBehaviour
{
	// Token: 0x06000CD5 RID: 3285 RVA: 0x0000ADDB File Offset: 0x00008FDB
	public Forecasted() : this(null)
	{
	}

	// Token: 0x06000CD6 RID: 3286 RVA: 0x00054FB4 File Offset: 0x000531B4
	public Forecasted(MonoBehaviour pEntity)
	{
		this._entity = pEntity;
		this._prevPos = base.transform.position;
	}

	// Token: 0x170001A7 RID: 423
	// (get) Token: 0x06000CD7 RID: 3287 RVA: 0x0000ADE4 File Offset: 0x00008FE4
	// (set) Token: 0x06000CD8 RID: 3288 RVA: 0x0000ADEC File Offset: 0x00008FEC
	public MonoBehaviour Entity
	{
		get
		{
			return this._entity;
		}
		set
		{
			this._entity = value;
		}
	}

	// Token: 0x170001A8 RID: 424
	// (get) Token: 0x06000CD9 RID: 3289 RVA: 0x0000ADF5 File Offset: 0x00008FF5
	// (set) Token: 0x06000CDA RID: 3290 RVA: 0x0000ADFD File Offset: 0x00008FFD
	public bool ForecastEnabled
	{
		get
		{
			return this._forecastEnabled;
		}
		set
		{
			this._forecastEnabled = value;
		}
	}

	// Token: 0x170001A9 RID: 425
	// (get) Token: 0x06000CDB RID: 3291 RVA: 0x0000AE06 File Offset: 0x00009006
	public Vector3 CurrentPosition
	{
		get
		{
			return base.transform.position;
		}
	}

	// Token: 0x170001AA RID: 426
	// (get) Token: 0x06000CDC RID: 3292 RVA: 0x0000AE13 File Offset: 0x00009013
	public Vector3 ForecastPosition
	{
		get
		{
			return this._forecastPosition;
		}
	}

	// Token: 0x06000CDD RID: 3293 RVA: 0x00055008 File Offset: 0x00053208
	public virtual void Refresh(float pForecastTime)
	{
		if (Time.deltaTime != 0f)
		{
			this._linearVelocity = (this.CurrentPosition - this._prevPos) / Time.deltaTime;
		}
		this._prevPos = this.CurrentPosition;
		this._forecastPosition = Vector3.Cross(this.CurrentPosition, this._linearVelocity) * pForecastTime;
		this._hit = false;
	}

	// Token: 0x06000CDE RID: 3294 RVA: 0x0000AE1B File Offset: 0x0000901B
	public virtual float GetWeightFor(ForecastClient pClient)
	{
		return this.Weight;
	}

	// Token: 0x06000CDF RID: 3295 RVA: 0x00003B7D File Offset: 0x00001D7D
	public virtual bool IsAttractiveFor(ForecastClient pClient)
	{
		return false;
	}

	// Token: 0x06000CE0 RID: 3296 RVA: 0x00003B7D File Offset: 0x00001D7D
	public virtual bool HasInfluenceFor(ForecastClient pClient)
	{
		return false;
	}

	// Token: 0x06000CE1 RID: 3297 RVA: 0x00055078 File Offset: 0x00053278
	public void ForecastCollision(ForecastClient pAI, float pForecastTime)
	{
		if (!this.HasInfluenceFor(pAI))
		{
			return;
		}
		float num = (this.ForecastPosition - pAI.CurrentPosition).sqrMagnitude;
		float num2 = pAI.FrustrumEndWidth + pAI.SpeedMs * pForecastTime + this.Range;
		float num3 = 0f;
		if (num < num2 * num2)
		{
			if ((double)pAI.ForecastSegment.magnitude < 1E-12)
			{
				return;
			}
			float num4 = 1f / pAI.ForecastSegment.magnitude;
			float num5 = (this.ForecastPosition.x - pAI.Pos.x) * pAI.ForecastSegment.x + (this.ForecastPosition.z - pAI.Pos.y) * pAI.ForecastSegment.y;
			float num6 = num5 * num4;
			float num7;
			float num8;
			if (num6 < 0f)
			{
				num7 = pAI.Pos.x - this.ForecastPosition.x;
				num8 = pAI.Pos.y - this.ForecastPosition.z;
			}
			else if (num6 > 1f)
			{
				num7 = pAI.ForecastPosition.x - this.ForecastPosition.x;
				num8 = pAI.ForecastPosition.z - this.ForecastPosition.z;
			}
			else
			{
				num7 = (1f - num6) * pAI.Pos.x + num6 * pAI.ForecastPosition.x - this.ForecastPosition.x;
				num8 = (1f - num6) * pAI.Pos.y + num6 * pAI.ForecastPosition.z - this.ForecastPosition.z;
			}
			num = num7 * num7 + num8 * num8;
			float num9 = pAI.FrustrumStartWidth + Mathf.Min(num6, 1f) * (pAI.FrustrumEndWidth - pAI.FrustrumStartWidth);
			num2 = this.Range + num9;
			if (num < num2 * num2)
			{
				num3 += num2 - RcUtils.FastSqrtApprox(num);
				this._hit = true;
			}
		}
		if (num3 > 0f)
		{
			float num10 = this.GetWeightFor(pAI) * num3;
			bool flag = this.IsAttractiveFor(pAI);
			if (pAI.IsObjectOnRight(this))
			{
				if (flag)
				{
					pAI.ForecastAttractive.Direction -= num10;
					pAI.ForecastAttractive.Weight += num10;
				}
				else
				{
					pAI.ForecastRepulsive.Direction -= num10;
					pAI.ForecastRepulsive.Weight += num10;
				}
			}
			else if (flag)
			{
				pAI.ForecastAttractive.Direction += num10;
				pAI.ForecastAttractive.Weight += num10;
			}
			else
			{
				pAI.ForecastRepulsive.Direction += num10;
				pAI.ForecastRepulsive.Weight += num10;
			}
		}
	}

	// Token: 0x04000C7B RID: 3195
	public float Range;

	// Token: 0x04000C7C RID: 3196
	public float Weight;

	// Token: 0x04000C7D RID: 3197
	protected MonoBehaviour _entity;

	// Token: 0x04000C7E RID: 3198
	protected bool _forecastEnabled = true;

	// Token: 0x04000C7F RID: 3199
	protected Vector3 _forecastPosition = Vector3.zero;

	// Token: 0x04000C80 RID: 3200
	protected Vector3 _linearVelocity = Vector3.zero;

	// Token: 0x04000C81 RID: 3201
	protected Vector3 _prevPos = Vector3.zero;

	// Token: 0x04000C82 RID: 3202
	protected bool _hit;
}

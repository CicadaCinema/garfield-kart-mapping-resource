﻿using System;

// Token: 0x020001BF RID: 447
public class Popup3Choices : AbstractPopup
{
	// Token: 0x06000C03 RID: 3075 RVA: 0x00051F14 File Offset: 0x00050114
	public void Show(string sTextIdDialog, Popup3Choices.Callback oCb1 = null, Popup3Choices.Callback oCb2 = null, Popup3Choices.Callback oCb3 = null, object oParam = null, string sTextIdBtn1 = null, string sTextIdBtn2 = null, string sTextIdBtn3 = null)
	{
		this.m_oCbButton1 = oCb1;
		this.m_oCbButton2 = oCb2;
		this.m_oCbButton3 = oCb3;
		this.m_oParam = oParam;
		if (sTextIdBtn1 != null)
		{
			this.m_oLabelButton1.key = sTextIdBtn1;
		}
		if (sTextIdBtn2 != null)
		{
			this.m_oLabelButton2.key = sTextIdBtn2;
		}
		if (sTextIdBtn3 != null)
		{
			this.m_oLabelButton3.key = sTextIdBtn3;
		}
		base.Show(sTextIdDialog);
	}

	// Token: 0x06000C04 RID: 3076 RVA: 0x00051F84 File Offset: 0x00050184
	public void ShowText(string sTextDialog, Popup3Choices.Callback oCb1 = null, Popup3Choices.Callback oCb2 = null, Popup3Choices.Callback oCb3 = null, object oParam = null, string sTextIdBtn1 = null, string sTextIdBtn2 = null, string sTextIdBtn3 = null)
	{
		base.gameObject.SetActive(true);
		this.m_oCbButton1 = oCb1;
		this.m_oCbButton2 = oCb2;
		this.m_oCbButton3 = oCb3;
		this.m_oParam = oParam;
		if (sTextIdBtn1 != null)
		{
			this.m_oLabelButton1.key = sTextIdBtn1;
		}
		if (sTextIdBtn2 != null)
		{
			this.m_oLabelButton2.key = sTextIdBtn2;
		}
		if (sTextIdBtn3 != null)
		{
			this.m_oLabelButton3.key = sTextIdBtn3;
		}
		UILabel component = this.Text.gameObject.GetComponent<UILabel>();
		if (component)
		{
			component.text = sTextDialog;
		}
	}

	// Token: 0x06000C05 RID: 3077 RVA: 0x0000A580 File Offset: 0x00008780
	public void OnButton1()
	{
		base.OnQuit();
		if (this.m_oCbButton1 != null)
		{
			this.m_oCbButton1(this.m_oParam);
		}
	}

	// Token: 0x06000C06 RID: 3078 RVA: 0x0000A5A4 File Offset: 0x000087A4
	public void OnButton2()
	{
		base.OnQuit();
		if (this.m_oCbButton2 != null)
		{
			this.m_oCbButton2(this.m_oParam);
		}
	}

	// Token: 0x06000C07 RID: 3079 RVA: 0x0000A5C8 File Offset: 0x000087C8
	public void OnButton3()
	{
		base.OnQuit();
		if (this.m_oCbButton3 != null)
		{
			this.m_oCbButton3(this.m_oParam);
		}
	}

	// Token: 0x04000BE4 RID: 3044
	public UILocalize m_oLabelButton1;

	// Token: 0x04000BE5 RID: 3045
	public UILocalize m_oLabelButton2;

	// Token: 0x04000BE6 RID: 3046
	public UILocalize m_oLabelButton3;

	// Token: 0x04000BE7 RID: 3047
	private Popup3Choices.Callback m_oCbButton1;

	// Token: 0x04000BE8 RID: 3048
	private Popup3Choices.Callback m_oCbButton2;

	// Token: 0x04000BE9 RID: 3049
	private Popup3Choices.Callback m_oCbButton3;

	// Token: 0x04000BEA RID: 3050
	private object m_oParam;

	// Token: 0x020001C0 RID: 448
	// (Invoke) Token: 0x06000C09 RID: 3081
	public delegate void Callback(object param);
}

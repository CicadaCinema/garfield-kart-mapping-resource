﻿using System;
using UnityEngine;

// Token: 0x020000E0 RID: 224
public class NapBonusEffect : BonusEffect
{
	// Token: 0x170000FB RID: 251
	// (set) Token: 0x0600060D RID: 1549 RVA: 0x00006463 File Offset: 0x00004663
	public Kart Launcher
	{
		set
		{
			this.m_pLauncher = value;
		}
	}

	// Token: 0x0600060E RID: 1550 RVA: 0x0003048C File Offset: 0x0002E68C
	public override void Start()
	{
		this.m_iAnimParameter = Animator.StringToHash("NapAttack_Impact");
		this.m_iAnimState = Animator.StringToHash("NapAttack.NapAttack_Loop");
		this.InertiaVehicle = false;
		this.m_bStoppedByAnim = false;
		this._attackEffect = (GameObject)UnityEngine.Object.Instantiate(this.AttackEffect);
		base.Start();
	}

	// Token: 0x0600060F RID: 1551 RVA: 0x0000646C File Offset: 0x0000466C
	public override void OnDestroy()
	{
		if (this._attackEffect != null)
		{
			UnityEngine.Object.Destroy(this._attackEffect);
		}
	}

	// Token: 0x06000610 RID: 1552 RVA: 0x0000600B File Offset: 0x0000420B
	public override void Update()
	{
		base.Update();
	}

	// Token: 0x06000611 RID: 1553 RVA: 0x0000648A File Offset: 0x0000468A
	public override void SetDuration()
	{
		this.m_fCurrentDuration = this.EffectDuration + this.m_pBonusEffectMgr.Target.GetBonusMgr().GetBonusValue(EITEM.ITEM_NAP, EBonusCustomEffect.DURATION) * this.EffectDuration / 100f;
	}

	// Token: 0x06000612 RID: 1554 RVA: 0x000304E4 File Offset: 0x0002E6E4
	public override bool Activate()
	{
		base.Activate();
		Kart target = this.m_pBonusEffectMgr.Target;
		target.CancelDrift();
		if (NapBonusEffect.OnLaunched != null && target.GetControlType() == RcVehicle.ControlType.Human)
		{
			NapBonusEffect.OnLaunched();
		}
		float pIntertiaFactor = this.InertiaFactor + this.m_pLauncher.GetBonusMgr().GetBonusValue(EITEM.ITEM_NAP, EBonusCustomEffect.INERTIA) * this.InertiaFactor / 100f;
		target.SlowDown(this.SlowDownFactor, this.m_fCurrentDuration, this.DecelerationSpeed);
		target.StartSleepMode(pIntertiaFactor, this.m_fCurrentDuration);
		target.Anim.LaunchBonusAnimOnCharacter(this.m_iAnimParameter, this.m_iAnimState, false);
		target.Anim.CanQueueAnim = false;
		target.KartSound.CanSpeak = false;
		target.KartSound.PlaySound(13);
		target.KartSound.PlayVoice(KartSound.EVoices.Snore);
		this._attackEffect.transform.position = target.Transform.position;
		this._attackEffect.transform.parent = target.Transform;
		this._attackEffect.transform.localPosition = target.Transform.rotation * this.NapOffset;
		this._attackEffect.particleSystem.Play();
		if (target.GetControlType() == RcVehicle.ControlType.Human)
		{
			this.Music.Play();
			Singleton<GameManager>.Instance.GameMode.MainMusic.volume = 0.3f;
		}
		return true;
	}

	// Token: 0x06000613 RID: 1555 RVA: 0x00030658 File Offset: 0x0002E858
	public override void Deactivate()
	{
		base.Deactivate();
		Kart target = this.m_pBonusEffectMgr.Target;
		target.Anim.ForceStopBonusAnim(this.m_iAnimParameter, false, true);
		target.KartSound.CanSpeak = true;
		target.Anim.CanQueueAnim = true;
		if (this._attackEffect != null)
		{
			this._attackEffect.particleSystem.Stop();
		}
		target.KartSound.StopSound(13);
		if (target.GetControlType() == RcVehicle.ControlType.Human)
		{
			this.Music.Stop();
			Singleton<GameManager>.Instance.GameMode.MainMusic.volume = 0.8f;
		}
		target.KartSound.StopVoice();
		target.KartSound.PlayVoice(KartSound.EVoices.Awake);
	}

	// Token: 0x04000603 RID: 1539
	[HideInInspector]
	[SerializeField]
	public float SlowDownFactor = 50f;

	// Token: 0x04000604 RID: 1540
	[HideInInspector]
	[SerializeField]
	public float DecelerationSpeed = 0.5f;

	// Token: 0x04000605 RID: 1541
	[SerializeField]
	[HideInInspector]
	public float InertiaFactor = 0.5f;

	// Token: 0x04000606 RID: 1542
	public GameObject AttackEffect;

	// Token: 0x04000607 RID: 1543
	private GameObject _attackEffect;

	// Token: 0x04000608 RID: 1544
	public static Action OnLaunched;

	// Token: 0x04000609 RID: 1545
	public AudioSource Music;

	// Token: 0x0400060A RID: 1546
	private Kart m_pLauncher;

	// Token: 0x0400060B RID: 1547
	public Vector3 NapOffset;
}

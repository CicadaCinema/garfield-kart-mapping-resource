﻿using System;
using UnityEngine;

// Token: 0x02000123 RID: 291
public class MessageButton : UIButtonMessage
{
	// Token: 0x060007FF RID: 2047 RVA: 0x0003C874 File Offset: 0x0003AA74
	public override void Start()
	{
		base.Start();
		GameObject gameObject = GameObject.Find("MenuEntryPoint");
		if (gameObject)
		{
			this.m_oMenuEntryPoint = gameObject.GetComponent<MenuEntryPoint>();
		}
	}

	// Token: 0x06000800 RID: 2048 RVA: 0x0003C8AC File Offset: 0x0003AAAC
	public override void Send()
	{
		if (string.IsNullOrEmpty(this.functionName))
		{
			return;
		}
		if (this.target == null)
		{
			this.target = base.gameObject;
		}
		object value;
		switch (this.m_iParamType)
		{
		default:
			value = this.m_iParamInt;
			break;
		case 1:
			value = this.m_fParamFloat;
			break;
		case 2:
			value = this.m_oParamVector2;
			break;
		case 3:
			value = this.m_oParamVector3;
			break;
		case 4:
			value = this.m_sParamString;
			break;
		case 5:
			value = this.m_oParamGameObject;
			break;
		case 6:
			value = this.m_iParamInt;
			break;
		}
		if (this.includeChildren)
		{
			Transform[] componentsInChildren = this.target.GetComponentsInChildren<Transform>();
			int i = 0;
			int num = componentsInChildren.Length;
			while (i < num)
			{
				Transform transform = componentsInChildren[i];
				transform.gameObject.SendMessage(this.functionName, value, SendMessageOptions.DontRequireReceiver);
				i++;
			}
		}
		else
		{
			this.target.SendMessage(this.functionName, value, SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x06000801 RID: 2049 RVA: 0x00007A22 File Offset: 0x00005C22
	public override void OnHover(bool isOver)
	{
		base.OnHover(isOver);
		if (base.enabled && isOver && this.m_oMenuEntryPoint)
		{
			this.m_oMenuEntryPoint.PlayHoverSound();
		}
	}

	// Token: 0x06000802 RID: 2050 RVA: 0x0003C9E4 File Offset: 0x0003ABE4
	public override void OnClick()
	{
		base.OnClick();
		if (base.enabled && this.m_oMenuEntryPoint)
		{
			if (base.gameObject.name == "ButtonPrev")
			{
				this.m_oMenuEntryPoint.PlayBackSound();
			}
			else if (base.gameObject.name == "ButtonGo")
			{
				this.m_oMenuEntryPoint.PlayGoSound();
			}
			else if (base.gameObject.name.Contains("ButtonArrow"))
			{
				this.m_oMenuEntryPoint.PlaySwitchPageSound();
			}
			else
			{
				this.m_oMenuEntryPoint.PlayValidSound();
			}
		}
	}

	// Token: 0x04000831 RID: 2097
	public int m_iParamInt;

	// Token: 0x04000832 RID: 2098
	public float m_fParamFloat;

	// Token: 0x04000833 RID: 2099
	public Vector2 m_oParamVector2;

	// Token: 0x04000834 RID: 2100
	public Vector3 m_oParamVector3;

	// Token: 0x04000835 RID: 2101
	public string m_sParamString;

	// Token: 0x04000836 RID: 2102
	public GameObject m_oParamGameObject;

	// Token: 0x04000837 RID: 2103
	private MenuEntryPoint m_oMenuEntryPoint;

	// Token: 0x04000838 RID: 2104
	public int m_iParamType;

	// Token: 0x02000124 RID: 292
	public enum EnumParamType
	{
		// Token: 0x0400083A RID: 2106
		TypeInt,
		// Token: 0x0400083B RID: 2107
		TypeFloat,
		// Token: 0x0400083C RID: 2108
		TypeVector2,
		// Token: 0x0400083D RID: 2109
		TypeVector3,
		// Token: 0x0400083E RID: 2110
		TypeString,
		// Token: 0x0400083F RID: 2111
		TypeGameObject,
		// Token: 0x04000840 RID: 2112
		TypeEMenus
	}
}

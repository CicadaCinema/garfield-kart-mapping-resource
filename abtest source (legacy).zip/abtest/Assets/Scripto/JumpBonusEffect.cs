﻿using System;
using UnityEngine;

// Token: 0x020000D7 RID: 215
public class JumpBonusEffect : BonusEffect
{
	// Token: 0x060005BC RID: 1468 RVA: 0x0002E5D0 File Offset: 0x0002C7D0
	public JumpBonusEffect()
	{
		this.JumpHeight = 0f;
		this.JumpForward = 0f;
		this.InertiaVehicle = false;
		this.m_bStoppedByAnim = false;
		this.BackwardJump = false;
		this.m_iAnimState = Animator.StringToHash("UpsideDown.UpsideDown_Front");
		this.m_iAnimParameter = Animator.StringToHash("UpsideDown_Front");
	}

	// Token: 0x170000F7 RID: 247
	// (set) Token: 0x060005BD RID: 1469 RVA: 0x000060DB File Offset: 0x000042DB
	public bool BackwardJump
	{
		set
		{
			this.m_bBackwardJump = value;
		}
	}

	// Token: 0x060005BE RID: 1470 RVA: 0x00006003 File Offset: 0x00004203
	public override void Start()
	{
		base.Start();
	}

	// Token: 0x060005BF RID: 1471 RVA: 0x0000600B File Offset: 0x0000420B
	public override void Update()
	{
		base.Update();
	}

	// Token: 0x060005C0 RID: 1472 RVA: 0x0002E63C File Offset: 0x0002C83C
	public override bool Activate()
	{
		if (this.m_pBonusEffectMgr.GetBonusEffect(EBonusEffect.BONUSEFFECT_LEVITATE).Activated)
		{
			return true;
		}
		base.Activate();
		Kart target = this.m_pBonusEffectMgr.Target;
		float num = this.JumpForward + this.m_pBonusEffectMgr.Target.GetBonusMgr().GetBonusValue(EITEM.ITEM_SPRING, EBonusCustomEffect.HEIGHT) * this.JumpForward / 100f;
		if (this.m_bBackwardJump)
		{
			num += this.RepulseJump * target.GetWheelSpeedMS() / target.GetMaxSpeed();
		}
		if (target.SpringJump(this.JumpHeight, num, this.m_bBackwardJump))
		{
			target.FxMgr.PlayKartFx(eKartFx.Jump);
		}
		target.KartSound.PlaySound(16);
		target.KartSound.PlayVoice(KartSound.EVoices.Good);
		if (this.m_bBackwardJump)
		{
			target.Anim.LaunchBonusAnimAll(this.m_iAnimParameter, this.m_iAnimState, false);
			target.Anim.StopBonusAnimAll(this.m_iAnimState);
		}
		this.m_bBackwardJump = false;
		return true;
	}

	// Token: 0x040005B8 RID: 1464
	[SerializeField]
	[HideInInspector]
	public float JumpHeight;

	// Token: 0x040005B9 RID: 1465
	[HideInInspector]
	[SerializeField]
	public float JumpForward;

	// Token: 0x040005BA RID: 1466
	private bool m_bBackwardJump;

	// Token: 0x040005BB RID: 1467
	public float RepulseJump = 20f;
}

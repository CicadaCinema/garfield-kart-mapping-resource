﻿using System;
using UnityEngine;

// Token: 0x02000009 RID: 9
[AddComponentMenu("NGUI/Interaction/Button Message")]
public class UIButtonMessage : MonoBehaviour
{
	// Token: 0x06000021 RID: 33 RVA: 0x000022E2 File Offset: 0x000004E2
	public virtual void Start()
	{
		this.mStarted = true;
	}

	// Token: 0x06000022 RID: 34 RVA: 0x000022EB File Offset: 0x000004EB
	private void OnEnable()
	{
		if (this.mStarted && this.mHighlighted)
		{
			this.OnHover(UICamera.IsHighlighted(base.gameObject));
		}
	}

	// Token: 0x06000023 RID: 35 RVA: 0x00002314 File Offset: 0x00000514
	public virtual void OnHover(bool isOver)
	{
		if (base.enabled)
		{
			if ((isOver && this.trigger == UIButtonMessage.Trigger.OnMouseOver) || (!isOver && this.trigger == UIButtonMessage.Trigger.OnMouseOut))
			{
				this.Send();
			}
			this.mHighlighted = isOver;
		}
	}

	// Token: 0x06000024 RID: 36 RVA: 0x00002352 File Offset: 0x00000552
	private void OnPress(bool isPressed)
	{
		if (base.enabled && ((isPressed && this.trigger == UIButtonMessage.Trigger.OnPress) || (!isPressed && this.trigger == UIButtonMessage.Trigger.OnRelease)))
		{
			this.Send();
		}
	}

	// Token: 0x06000025 RID: 37 RVA: 0x00002389 File Offset: 0x00000589
	public virtual void OnClick()
	{
		if (base.enabled && this.trigger == UIButtonMessage.Trigger.OnClick)
		{
			this.Send();
		}
	}

	// Token: 0x06000026 RID: 38 RVA: 0x000023A7 File Offset: 0x000005A7
	private void OnDoubleClick()
	{
		if (base.enabled && this.trigger == UIButtonMessage.Trigger.OnDoubleClick)
		{
			this.Send();
		}
	}

	// Token: 0x06000027 RID: 39 RVA: 0x0000DA08 File Offset: 0x0000BC08
	public virtual void Send()
	{
		if (string.IsNullOrEmpty(this.functionName))
		{
			return;
		}
		if (this.target == null)
		{
			this.target = base.gameObject;
		}
		if (this.includeChildren)
		{
			Transform[] componentsInChildren = this.target.GetComponentsInChildren<Transform>();
			int i = 0;
			int num = componentsInChildren.Length;
			while (i < num)
			{
				Transform transform = componentsInChildren[i];
				transform.gameObject.SendMessage(this.functionName, base.gameObject, SendMessageOptions.DontRequireReceiver);
				i++;
			}
		}
		else
		{
			this.target.SendMessage(this.functionName, base.gameObject, SendMessageOptions.DontRequireReceiver);
		}
	}

	// Token: 0x04000014 RID: 20
	public GameObject target;

	// Token: 0x04000015 RID: 21
	public string functionName;

	// Token: 0x04000016 RID: 22
	public UIButtonMessage.Trigger trigger;

	// Token: 0x04000017 RID: 23
	public bool includeChildren;

	// Token: 0x04000018 RID: 24
	private bool mStarted;

	// Token: 0x04000019 RID: 25
	private bool mHighlighted;

	// Token: 0x0200000A RID: 10
	public enum Trigger
	{
		// Token: 0x0400001B RID: 27
		OnClick,
		// Token: 0x0400001C RID: 28
		OnMouseOver,
		// Token: 0x0400001D RID: 29
		OnMouseOut,
		// Token: 0x0400001E RID: 30
		OnPress,
		// Token: 0x0400001F RID: 31
		OnRelease,
		// Token: 0x04000020 RID: 32
		OnDoubleClick
	}
}

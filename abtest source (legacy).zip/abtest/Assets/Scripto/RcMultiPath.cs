﻿using System;
using UnityEngine;

// Token: 0x02000201 RID: 513
public class RcMultiPath : MonoBehaviour
{
	// Token: 0x06000DDD RID: 3549 RVA: 0x0000B859 File Offset: 0x00009A59
	public RcMultiPath()
	{
		this.m_iNbSection = 0;
		this.m_fTotalLength = 0f;
		this.m_pFirstSection = null;
		this.m_bDebugDraw = false;
		this.m_bValuePaths = true;
	}

	// Token: 0x170001D8 RID: 472
	// (get) Token: 0x06000DDE RID: 3550 RVA: 0x0000B888 File Offset: 0x00009A88
	public bool BValuePaths
	{
		get
		{
			return this.m_bValuePaths;
		}
	}

	// Token: 0x170001D9 RID: 473
	// (get) Token: 0x06000DDF RID: 3551 RVA: 0x0000B890 File Offset: 0x00009A90
	public int NbSections
	{
		get
		{
			return this.m_iNbSection;
		}
	}

	// Token: 0x06000DE0 RID: 3552 RVA: 0x0000B898 File Offset: 0x00009A98
	public RcMultiPathSection GetMultiPathSection(int _Index)
	{
		return this.m_pSections[_Index];
	}

	// Token: 0x170001DA RID: 474
	// (get) Token: 0x06000DE1 RID: 3553 RVA: 0x0000B8A2 File Offset: 0x00009AA2
	public float TotalLength
	{
		get
		{
			return this.m_fTotalLength;
		}
	}

	// Token: 0x06000DE2 RID: 3554 RVA: 0x0000B8AA File Offset: 0x00009AAA
	public void Start()
	{
		this.Rebuild();
	}

	// Token: 0x06000DE3 RID: 3555 RVA: 0x0005A264 File Offset: 0x00058464
	public void Rebuild()
	{
		this.m_iNbSection = 0;
		this.m_fTotalLength = 0f;
		RcMultiPathSection[] componentsInChildren = base.GetComponentsInChildren<RcMultiPathSection>();
		this.m_pSections = new RcMultiPathSection[componentsInChildren.Length];
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].CreateFastPath(this.m_bValuePaths);
		}
		RcMultiPathSection component = this.m_pFirstSection.GetComponent<RcMultiPathSection>();
		if (component)
		{
			this.AddSection(component);
			int num = 0;
			while (num < component.GetNbBranchesBefore() && component.GetBeforeSection(num))
			{
				Vector3 firstPoint = component.GetSimplePath().GetFirstPoint();
				Vector3 lastPoint = component.GetBeforeSection(num).GetSimplePath().GetLastPoint();
				float magnitude = (firstPoint - lastPoint).magnitude;
				component.GetBeforeSection(num).SetDistToEndLine(magnitude, component.GetBeforeSection(num));
				num++;
			}
			this.m_fTotalLength = component.GetDistToEndLine() + component.GetLength();
		}
		this.NormalizeSectionLengthes();
	}

	// Token: 0x06000DE4 RID: 3556 RVA: 0x0005A364 File Offset: 0x00058564
	public void Stop()
	{
		RcMultiPathSection[] componentsInChildren = base.GetComponentsInChildren<RcMultiPathSection>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].DeleteFastPath();
		}
		for (int j = 0; j < this.m_pSections.Length; j++)
		{
			this.m_pSections[j] = null;
		}
		this.m_iNbSection = 0;
	}

	// Token: 0x06000DE5 RID: 3557 RVA: 0x0005A3C0 File Offset: 0x000585C0
	public float GetDistToEndLine(MultiPathPosition _mpPosition)
	{
		if (this.m_iNbSection > 0 && _mpPosition.section == this.m_pSections[0] && _mpPosition.pathPosition.index == 0 && _mpPosition.pathPosition.ratio < 0f)
		{
			RcFastPath simplePath = _mpPosition.section.GetSimplePath();
			return -1f * simplePath.GetSegmentLength(_mpPosition.pathPosition.index) * _mpPosition.pathPosition.ratio;
		}
		if (_mpPosition.section != null)
		{
			return _mpPosition.section.GetDistToEndLine(_mpPosition.pathPosition);
		}
		return 0f;
	}

	// Token: 0x06000DE6 RID: 3558 RVA: 0x0000B8B2 File Offset: 0x00009AB2
	public void AddSection(RcMultiPathSection pSection)
	{
		this.m_pSections[this.m_iNbSection] = pSection;
		this.m_iNbSection++;
		this.AttachExtremities(pSection);
	}

	// Token: 0x06000DE7 RID: 3559 RVA: 0x0005A478 File Offset: 0x00058678
	public void AttachExtremities(RcMultiPathSection pSection)
	{
		this.AttachExtremity(pSection);
		int num = 0;
		while (num < pSection.GetNbBranchesAfter() && pSection.GetAfterSection(num))
		{
			this.AttachExtremity(pSection.GetAfterSection(num));
			num++;
		}
	}

	// Token: 0x06000DE8 RID: 3560 RVA: 0x0005A4C4 File Offset: 0x000586C4
	public void AttachExtremity(RcMultiPathSection pSection)
	{
		if (pSection == null)
		{
			return;
		}
		RcMultiPathSection exists = null;
		for (int i = 0; i < this.m_iNbSection; i++)
		{
			if (this.m_pSections[i] == pSection)
			{
				exists = this.m_pSections[i];
				break;
			}
		}
		if (!exists)
		{
			this.AddSection(pSection);
		}
	}

	// Token: 0x06000DE9 RID: 3561 RVA: 0x0005A52C File Offset: 0x0005872C
	public void ResetPosition(ref MultiPathPosition _mpPosition, Vector3 _position3D)
	{
		PathPosition undefined_POSITION = PathPosition.UNDEFINED_POSITION;
		float num = 1E+38f;
		for (int i = 0; i < this.m_iNbSection; i++)
		{
			RcMultiPathSection rcMultiPathSection = this.m_pSections[i];
			undefined_POSITION = PathPosition.UNDEFINED_POSITION;
			rcMultiPathSection.GetSimplePath().UpdatePathPosition(ref undefined_POSITION, _position3D, 3, 1, true, true);
			if (undefined_POSITION.sqrDist < num || _mpPosition.section == null)
			{
				_mpPosition.section = rcMultiPathSection;
				_mpPosition.pathPosition = undefined_POSITION;
				num = undefined_POSITION.sqrDist;
			}
		}
	}

	// Token: 0x06000DEA RID: 3562 RVA: 0x0005A5B4 File Offset: 0x000587B4
	public void UpdateMPPosition(ref MultiPathPosition _mpPosition, Vector3 _position3D, int segmentForward, int segmentBackward, bool _2D)
	{
		if (_mpPosition.pathPosition.index != -1 && _mpPosition.pathPosition.sqrDist < 2500f)
		{
			_mpPosition.section.UpdateMPPosition(ref _mpPosition, _position3D, segmentForward, segmentBackward, _2D);
		}
		else
		{
			this.ResetPosition(ref _mpPosition, _position3D);
		}
	}

	// Token: 0x06000DEB RID: 3563 RVA: 0x0005A608 File Offset: 0x00058808
	public void RefreshRespawn(RcVehicleRaceStats _Stats)
	{
		this.UpdateMPPosition(ref _Stats.m_GuidePosition, _Stats.GetVehicle().GetPosition(), 2, 1, false);
		RcFastPath simplePath = _Stats.GetGuidePosition().section.GetSimplePath();
		int index = _Stats.GetGuidePosition().pathPosition.index;
		float prc = Mathf.Clamp(_Stats.GetGuidePosition().pathPosition.ratio, 0f, 1f);
		bool flag = true;
		if (this.m_bValuePaths)
		{
			RcFastValuePath rcFastValuePath = (RcFastValuePath)simplePath;
			flag = (_Stats.GetVehicle().GetGroundSurface() != -1 && rcFastValuePath.GetPointValue(index) != -1f);
		}
		if (flag && _Stats.GetVehicle().IsOnGround())
		{
			Vector3 vector;
			simplePath.GetRawPos(index, prc, out vector);
			vector += Vector3.up;
			Vector3 vector2 = simplePath.GetSegment(index);
			vector2 -= Vector3.Dot(vector2, Vector3.up) * Vector3.up;
			vector2.Normalize();
			Quaternion respawnOrientation = default(Quaternion);
			respawnOrientation.SetLookRotation(vector2, Vector3.up);
			_Stats.GetVehicle().SetRespawnPos(vector);
			_Stats.GetVehicle().SetRespawnOrientation(respawnOrientation);
		}
		float num = Mathf.Max(this.m_fTotalLength * 0.25f, 10f);
		float num2 = this.GetDistToEndLine(_Stats.GetGuidePosition());
		if (_Stats.GetNbCheckPointValidated() == 0 && num2 < num)
		{
			num2 = this.m_fTotalLength;
		}
		if (_Stats.GetNbCheckPointValidated() > 0 && num2 > this.m_fTotalLength - num)
		{
			num2 = 0f;
		}
		_Stats.SetDistToEndOfLap(num2);
		float num3 = num2;
		num3 += (float)(_Stats.GetRaceNbLap() - _Stats.GetLogicNbLap()) * this.m_fTotalLength;
		_Stats.SetDistToEndOfRace(num3);
	}

	// Token: 0x06000DEC RID: 3564 RVA: 0x0005A7DC File Offset: 0x000589DC
	protected void NormalizeSectionLengthes()
	{
		foreach (RcMultiPathSection rcMultiPathSection in this.m_pSections)
		{
			if (rcMultiPathSection != null && rcMultiPathSection != this.m_pFirstSection)
			{
				float length = rcMultiPathSection.GetLength();
				float distToEndLine = rcMultiPathSection.GetDistToEndLine();
				float distToEndLine2 = rcMultiPathSection.m_pBeforeBranches[0].GetDistToEndLine();
				float num = distToEndLine2 - distToEndLine;
				if (length > 0f && num > length)
				{
					rcMultiPathSection.SetMultipathScale(num / length);
				}
			}
		}
	}

	// Token: 0x04000D6A RID: 3434
	private const float RESET_MULTIPATH_SQR_DIST = 2500f;

	// Token: 0x04000D6B RID: 3435
	protected RcMultiPathSection[] m_pSections;

	// Token: 0x04000D6C RID: 3436
	protected int m_iNbSection;

	// Token: 0x04000D6D RID: 3437
	protected float m_fTotalLength;

	// Token: 0x04000D6E RID: 3438
	public GameObject m_pFirstSection;

	// Token: 0x04000D6F RID: 3439
	public bool m_bDebugDraw;

	// Token: 0x04000D70 RID: 3440
	protected bool m_bValuePaths;
}

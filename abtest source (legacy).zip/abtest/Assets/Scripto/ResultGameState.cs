﻿using System;

// Token: 0x02000171 RID: 369
public class ResultGameState : GameState
{
	// Token: 0x060009F2 RID: 2546 RVA: 0x00008C1D File Offset: 0x00006E1D
	public override void Enter()
	{
		((InGameGameMode)this.m_pGameMode).UpdateScores();
		((InGameGameMode)this.m_pGameMode).FillResults();
	}

	// Token: 0x060009F3 RID: 2547 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void Exit()
	{
	}

	// Token: 0x060009F4 RID: 2548 RVA: 0x0004535C File Offset: 0x0004355C
	public override void Update()
	{
		if (!Singleton<GameManager>.Instance.SoundManager.SoundsList[3].isPlaying && !Singleton<GameManager>.Instance.SoundManager.SoundsList[4].isPlaying)
		{
			Singleton<GameManager>.Instance.SoundManager.PlayMusic(ERaceMusicLoops.InterRace);
		}
	}
}

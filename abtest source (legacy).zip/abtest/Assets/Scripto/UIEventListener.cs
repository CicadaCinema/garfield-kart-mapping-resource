﻿using System;
using UnityEngine;

// Token: 0x0200004B RID: 75
[AddComponentMenu("NGUI/Internal/Event Listener")]
public class UIEventListener : MonoBehaviour
{
	// Token: 0x060001EF RID: 495 RVA: 0x00003704 File Offset: 0x00001904
	private void OnSubmit()
	{
		if (this.onSubmit != null)
		{
			this.onSubmit(base.gameObject);
		}
	}

	// Token: 0x060001F0 RID: 496 RVA: 0x00003722 File Offset: 0x00001922
	private void OnClick()
	{
		if (this.onClick != null)
		{
			this.onClick(base.gameObject);
		}
	}

	// Token: 0x060001F1 RID: 497 RVA: 0x00003740 File Offset: 0x00001940
	private void OnDoubleClick()
	{
		if (this.onDoubleClick != null)
		{
			this.onDoubleClick(base.gameObject);
		}
	}

	// Token: 0x060001F2 RID: 498 RVA: 0x0000375E File Offset: 0x0000195E
	private void OnHover(bool isOver)
	{
		if (this.onHover != null)
		{
			this.onHover(base.gameObject, isOver);
		}
	}

	// Token: 0x060001F3 RID: 499 RVA: 0x0000377D File Offset: 0x0000197D
	private void OnPress(bool isPressed)
	{
		if (this.onPress != null)
		{
			this.onPress(base.gameObject, isPressed);
		}
	}

	// Token: 0x060001F4 RID: 500 RVA: 0x0000379C File Offset: 0x0000199C
	private void OnSelect(bool selected)
	{
		if (this.onSelect != null)
		{
			this.onSelect(base.gameObject, selected);
		}
	}

	// Token: 0x060001F5 RID: 501 RVA: 0x000037BB File Offset: 0x000019BB
	private void OnScroll(float delta)
	{
		if (this.onScroll != null)
		{
			this.onScroll(base.gameObject, delta);
		}
	}

	// Token: 0x060001F6 RID: 502 RVA: 0x000037DA File Offset: 0x000019DA
	private void OnDrag(Vector2 delta)
	{
		if (this.onDrag != null)
		{
			this.onDrag(base.gameObject, delta);
		}
	}

	// Token: 0x060001F7 RID: 503 RVA: 0x000037F9 File Offset: 0x000019F9
	private void OnDrop(GameObject go)
	{
		if (this.onDrop != null)
		{
			this.onDrop(base.gameObject, go);
		}
	}

	// Token: 0x060001F8 RID: 504 RVA: 0x00003818 File Offset: 0x00001A18
	private void OnInput(string text)
	{
		if (this.onInput != null)
		{
			this.onInput(base.gameObject, text);
		}
	}

	// Token: 0x060001F9 RID: 505 RVA: 0x00003837 File Offset: 0x00001A37
	private void OnKey(KeyCode key)
	{
		if (this.onKey != null)
		{
			this.onKey(base.gameObject, key);
		}
	}

	// Token: 0x060001FA RID: 506 RVA: 0x000172B0 File Offset: 0x000154B0
	public static UIEventListener Get(GameObject go)
	{
		UIEventListener uieventListener = go.GetComponent<UIEventListener>();
		if (uieventListener == null)
		{
			uieventListener = go.AddComponent<UIEventListener>();
		}
		return uieventListener;
	}

	// Token: 0x040001A5 RID: 421
	public object parameter;

	// Token: 0x040001A6 RID: 422
	public UIEventListener.VoidDelegate onSubmit;

	// Token: 0x040001A7 RID: 423
	public UIEventListener.VoidDelegate onClick;

	// Token: 0x040001A8 RID: 424
	public UIEventListener.VoidDelegate onDoubleClick;

	// Token: 0x040001A9 RID: 425
	public UIEventListener.BoolDelegate onHover;

	// Token: 0x040001AA RID: 426
	public UIEventListener.BoolDelegate onPress;

	// Token: 0x040001AB RID: 427
	public UIEventListener.BoolDelegate onSelect;

	// Token: 0x040001AC RID: 428
	public UIEventListener.FloatDelegate onScroll;

	// Token: 0x040001AD RID: 429
	public UIEventListener.VectorDelegate onDrag;

	// Token: 0x040001AE RID: 430
	public UIEventListener.ObjectDelegate onDrop;

	// Token: 0x040001AF RID: 431
	public UIEventListener.StringDelegate onInput;

	// Token: 0x040001B0 RID: 432
	public UIEventListener.KeyCodeDelegate onKey;

	// Token: 0x0200004C RID: 76
	// (Invoke) Token: 0x060001FC RID: 508
	public delegate void VoidDelegate(GameObject go);

	// Token: 0x0200004D RID: 77
	// (Invoke) Token: 0x06000200 RID: 512
	public delegate void BoolDelegate(GameObject go, bool state);

	// Token: 0x0200004E RID: 78
	// (Invoke) Token: 0x06000204 RID: 516
	public delegate void FloatDelegate(GameObject go, float delta);

	// Token: 0x0200004F RID: 79
	// (Invoke) Token: 0x06000208 RID: 520
	public delegate void VectorDelegate(GameObject go, Vector2 delta);

	// Token: 0x02000050 RID: 80
	// (Invoke) Token: 0x0600020C RID: 524
	public delegate void StringDelegate(GameObject go, string text);

	// Token: 0x02000051 RID: 81
	// (Invoke) Token: 0x06000210 RID: 528
	public delegate void ObjectDelegate(GameObject go, GameObject draggedObject);

	// Token: 0x02000052 RID: 82
	// (Invoke) Token: 0x06000214 RID: 532
	public delegate void KeyCodeDelegate(GameObject go, KeyCode key);
}

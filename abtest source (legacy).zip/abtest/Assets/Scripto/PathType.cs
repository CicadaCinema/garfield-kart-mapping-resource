﻿using System;
using UnityEngine;

// Token: 0x020000A4 RID: 164
public class PathType : MonoBehaviour
{
	// Token: 0x040003C7 RID: 967
	public E_PathType Type;
}

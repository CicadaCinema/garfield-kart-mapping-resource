﻿using System;

// Token: 0x020000A7 RID: 167
[Serializable]
public class ChanceSettings
{
	// Token: 0x040003E2 RID: 994
	public Chance KartChance = new Chance(33, 20, 10);

	// Token: 0x040003E3 RID: 995
	public ItemChance CustoChance = new ItemChance(33, 20, 5, 33);

	// Token: 0x040003E4 RID: 996
	public ItemChance HatChance = new ItemChance(33, 20, 5, 33);
}

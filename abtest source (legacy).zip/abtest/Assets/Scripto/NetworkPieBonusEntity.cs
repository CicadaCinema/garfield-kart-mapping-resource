﻿using System;
using UnityEngine;

// Token: 0x020000E7 RID: 231
public class NetworkPieBonusEntity : NetworkMovableBonusEntity
{
	// Token: 0x06000631 RID: 1585 RVA: 0x00006639 File Offset: 0x00004839
	[RPC]
	public void OnStickOnGround(Vector3 normal)
	{
		((PieBonusEntity)this.m_pBonusEntity).DoStickOnGround(normal);
	}

	// Token: 0x06000632 RID: 1586 RVA: 0x0000664C File Offset: 0x0000484C
	[RPC]
	public void Launch(NetworkViewID launcherViewID, bool _Behind)
	{
		this.NetworkInitialize(launcherViewID);
		((PieBonusEntity)this.m_pBonusEntity).Launch(_Behind);
	}
}

﻿using System;
using UnityEngine;

// Token: 0x02000192 RID: 402
public class CoinsDisplayManager : MonoBehaviour
{
	// Token: 0x06000ADB RID: 2779 RVA: 0x0000974D File Offset: 0x0000794D
	public void Awake()
	{
		this.m_pLabel = base.GetComponent<UILabel>();
		CoinsDisplayManager.m_fMoney = (double)((float)Singleton<GameSaveManager>.Instance.GetCoins());
		this.DisplayMoney();
		this.m_fSoundRequest = 0f;
	}

	// Token: 0x06000ADC RID: 2780 RVA: 0x0004996C File Offset: 0x00047B6C
	public void Update()
	{
		if (!this.m_pLabel)
		{
			return;
		}
		int coins = Singleton<GameSaveManager>.Instance.GetCoins();
		if (coins != (int)(CoinsDisplayManager.m_fMoney + 0.5))
		{
			float deltaTime = Time.deltaTime;
			CoinsDisplayManager.m_fMoney = Tricks.ComputeInertia(CoinsDisplayManager.m_fMoney, (double)coins, this.m_fInertia, (double)deltaTime);
			this.m_fSoundRequest += deltaTime;
			this.DisplayMoney();
			if (this.CoinsSound && this.m_fSoundRequest > this.SoundToPlay)
			{
				this.CoinsSound.Play();
				this.m_fSoundRequest = 0f;
			}
		}
	}

	// Token: 0x06000ADD RID: 2781 RVA: 0x0000977D File Offset: 0x0000797D
	public void OnEnable()
	{
		this.DisplayMoney();
	}

	// Token: 0x06000ADE RID: 2782 RVA: 0x00049A18 File Offset: 0x00047C18
	private void DisplayMoney()
	{
		if (this.m_pLabel)
		{
			if (CoinsDisplayManager.m_fMoney == 0.0)
			{
				this.m_pLabel.text = "0";
			}
			else
			{
				this.m_pLabel.text = string.Format("{0:# ### ### ###}", (int)(CoinsDisplayManager.m_fMoney + 0.5));
			}
		}
	}

	// Token: 0x04000AA7 RID: 2727
	private UILabel m_pLabel;

	// Token: 0x04000AA8 RID: 2728
	private static double m_fMoney;

	// Token: 0x04000AA9 RID: 2729
	public double m_fInertia = 0.3;

	// Token: 0x04000AAA RID: 2730
	public AudioSource CoinsSound;

	// Token: 0x04000AAB RID: 2731
	private float m_fSoundRequest;

	// Token: 0x04000AAC RID: 2732
	public float SoundToPlay = 0.1f;
}

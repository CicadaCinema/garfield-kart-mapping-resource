﻿using System;
using UnityEngine;

// Token: 0x020001E9 RID: 489
public class CamStateCarPres : CamState
{
	// Token: 0x170001C9 RID: 457
	// (get) Token: 0x06000D48 RID: 3400 RVA: 0x000042D1 File Offset: 0x000024D1
	public override ECamState state
	{
		get
		{
			return ECamState.CarPres;
		}
	}

	// Token: 0x06000D49 RID: 3401 RVA: 0x00057060 File Offset: 0x00055260
	public override void Enter(Transform _Transform, Transform _Target)
	{
		base.Enter(_Transform, _Target);
		this.m_Start = GameObject.Find("Start");
		base.m_Transform.position = this.m_Start.transform.position;
		base.m_Transform.rotation = this.m_Start.transform.rotation;
		base.m_Transform.position += base.m_Transform.up * this.Height + base.m_Transform.forward * this.StartDistance;
		base.m_Transform.LookAt(base.m_Transform.position - base.m_Transform.forward);
	}

	// Token: 0x06000D4A RID: 3402 RVA: 0x0000B115 File Offset: 0x00009315
	public override ECamState Manage(float dt)
	{
		base.m_Transform.position += base.m_Transform.forward * dt * this.Speed;
		return this.state;
	}

	// Token: 0x06000D4B RID: 3403 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void Exit()
	{
	}

	// Token: 0x04000CFB RID: 3323
	private GameObject m_Start;

	// Token: 0x04000CFC RID: 3324
	public float StartDistance = 1f;

	// Token: 0x04000CFD RID: 3325
	public float Height = 1f;

	// Token: 0x04000CFE RID: 3326
	public float Speed = 1f;
}

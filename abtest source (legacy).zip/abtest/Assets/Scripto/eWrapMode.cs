﻿using System;

// Token: 0x02000250 RID: 592
public enum eWrapMode
{
	// Token: 0x04000FAD RID: 4013
	ONCE,
	// Token: 0x04000FAE RID: 4014
	LOOP
}

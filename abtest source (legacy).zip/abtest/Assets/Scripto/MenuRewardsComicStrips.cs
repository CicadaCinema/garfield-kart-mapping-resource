﻿using System;

// Token: 0x020001A8 RID: 424
public class MenuRewardsComicStrips : MenuRewards
{
	// Token: 0x06000B6D RID: 2925 RVA: 0x00009F2E File Offset: 0x0000812E
	public override void OnEnter()
	{
		base.OnEnter();
		this._comicStrip = Singleton<RewardManager>.Instance.PopComicStrip();
		this.LbRewardName.text = Localization.instance.Get("TRACK_NAME_" + this._comicStrip);
	}

	// Token: 0x06000B6E RID: 2926 RVA: 0x00009F6B File Offset: 0x0000816B
	public override void OnGoNext()
	{
		Singleton<GameSaveManager>.Instance.SetComicStripState(this._comicStrip, E_UnlockableItemSate.NewUnlocked, false);
		base.OnGoNext();
	}

	// Token: 0x04000B2F RID: 2863
	private string _comicStrip;
}

﻿using System;
using UnityEngine;

// Token: 0x0200000F RID: 15
[AddComponentMenu("NGUI/Interaction/Button Sound")]
public class UIButtonSound : MonoBehaviour
{
	// Token: 0x06000045 RID: 69 RVA: 0x0000E250 File Offset: 0x0000C450
	private void OnHover(bool isOver)
	{
		if (base.enabled && ((isOver && this.trigger == UIButtonSound.Trigger.OnMouseOver) || (!isOver && this.trigger == UIButtonSound.Trigger.OnMouseOut)))
		{
			NGUITools.PlaySound(this.audioClip, this.volume, this.pitch);
		}
	}

	// Token: 0x06000046 RID: 70 RVA: 0x0000E2A4 File Offset: 0x0000C4A4
	private void OnPress(bool isPressed)
	{
		if (base.enabled && ((isPressed && this.trigger == UIButtonSound.Trigger.OnPress) || (!isPressed && this.trigger == UIButtonSound.Trigger.OnRelease)))
		{
			NGUITools.PlaySound(this.audioClip, this.volume, this.pitch);
		}
	}

	// Token: 0x06000047 RID: 71 RVA: 0x0000253C File Offset: 0x0000073C
	private void OnClick()
	{
		if (base.enabled && this.trigger == UIButtonSound.Trigger.OnClick)
		{
			NGUITools.PlaySound(this.audioClip, this.volume, this.pitch);
		}
	}

	// Token: 0x04000043 RID: 67
	public AudioClip audioClip;

	// Token: 0x04000044 RID: 68
	public UIButtonSound.Trigger trigger;

	// Token: 0x04000045 RID: 69
	public float volume = 1f;

	// Token: 0x04000046 RID: 70
	public float pitch = 1f;

	// Token: 0x02000010 RID: 16
	public enum Trigger
	{
		// Token: 0x04000048 RID: 72
		OnClick,
		// Token: 0x04000049 RID: 73
		OnMouseOver,
		// Token: 0x0400004A RID: 74
		OnMouseOut,
		// Token: 0x0400004B RID: 75
		OnPress,
		// Token: 0x0400004C RID: 76
		OnRelease
	}
}

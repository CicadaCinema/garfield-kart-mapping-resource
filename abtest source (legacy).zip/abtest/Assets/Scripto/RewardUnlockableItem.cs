﻿using System;

// Token: 0x02000165 RID: 357
public abstract class RewardUnlockableItem : RewardBase
{
	// Token: 0x0600099D RID: 2461 RVA: 0x000089A3 File Offset: 0x00006BA3
	public RewardUnlockableItem()
	{
	}

	// Token: 0x040009D4 RID: 2516
	public E_UnlockableItemSate State;
}

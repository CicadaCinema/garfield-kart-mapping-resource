﻿using System;
using UnityEngine;

// Token: 0x0200014F RID: 335
public class PuzzlePiece : MonoBehaviour
{
	// Token: 0x0600096C RID: 2412 RVA: 0x000088BA File Offset: 0x00006ABA
	public void Start()
	{
		this.Player = null;
		this.m_pTransform = base.transform;
		this.m_pAudio = base.GetComponent<AudioSource>();
	}

	// Token: 0x0600096D RID: 2413 RVA: 0x00042CE4 File Offset: 0x00040EE4
	public void Update()
	{
		if (this.Player != null)
		{
			float sqrMagnitude = (this.m_pTransform.position - this.Player.Transform.position).sqrMagnitude;
			if (sqrMagnitude < this.DistThreshold)
			{
				if (!this.m_pAudio.enabled)
				{
					this.m_pAudio.enabled = true;
				}
			}
			else if (this.m_pAudio.enabled)
			{
				this.m_pAudio.enabled = false;
			}
		}
	}

	// Token: 0x040009A8 RID: 2472
	public Kart Player;

	// Token: 0x040009A9 RID: 2473
	private Transform m_pTransform;

	// Token: 0x040009AA RID: 2474
	public float DistThreshold = 30f;

	// Token: 0x040009AB RID: 2475
	private AudioSource m_pAudio;
}

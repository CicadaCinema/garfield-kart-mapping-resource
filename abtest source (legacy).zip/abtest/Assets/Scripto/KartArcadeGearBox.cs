﻿using System;
using UnityEngine;

// Token: 0x02000142 RID: 322
public class KartArcadeGearBox : RcArcadeGearBox
{
	// Token: 0x06000911 RID: 2321 RVA: 0x000407CC File Offset: 0x0003E9CC
	public KartArcadeGearBox()
	{
		this.m_pPlayerCarac = null;
		this.MaxSpeed = 0f;
		this.m_fSpeedDiff = -1f;
	}

	// Token: 0x06000912 RID: 2322 RVA: 0x0004081C File Offset: 0x0003EA1C
	public override void Awake()
	{
		base.Awake();
		this.m_eLastDifficulty = Singleton<GameConfigurator>.Instance.Difficulty;
		this.m_pCustom = base.transform.parent.FindChild("Base").GetComponent<PlayerCustom>();
		this.m_pPlayerCarac = base.transform.parent.FindChild("Tunning").GetComponent<PlayerCarac>();
		this.m_fAccelerationDiff = this.m_vAcceleration[this.m_vAcceleration.Count - 1] - this.MaxAcceleration;
		this.ComputeDiffSpeed();
	}

	// Token: 0x06000913 RID: 2323 RVA: 0x000408AC File Offset: 0x0003EAAC
	public void ComputeDiffSpeed()
	{
		if (this.m_vSpeed.Count > 0)
		{
			float num = this.PercentDifficulty[(int)this.m_eLastDifficulty] / 100f;
			float num2 = this.m_vSpeed[this.m_vSpeed.Count - 1] + num * this.m_vSpeed[this.m_vSpeed.Count - 1];
			this.m_fDifficultyMaxSpeed = this.MaxSpeed + num * this.MaxSpeed;
			this.m_fSpeedDiff = this.m_fDifficultyMaxSpeed - num2;
		}
	}

	// Token: 0x06000914 RID: 2324 RVA: 0x00008542 File Offset: 0x00006742
	public float GetDifficultyPercent()
	{
		return this.PercentDifficulty[(int)this.m_eLastDifficulty];
	}

	// Token: 0x06000915 RID: 2325 RVA: 0x00040938 File Offset: 0x0003EB38
	public void Update()
	{
		float deltaTime = Time.deltaTime;
		if (this.m_BoostTimer > 0f)
		{
			this.m_BoostTimer -= deltaTime;
		}
		else if (this.m_BoostTimer != 0f)
		{
			this.m_BoostTimer = 0f;
			this.m_BoostSpeedUp = 0f;
			this.m_BoostAcceleration = 0f;
			Kart kart = (Kart)this.m_pVehicle;
			kart.FxMgr.StopKartFx(eKartFx.BoostLeft);
			kart.FxMgr.StopKartFx(eKartFx.BoostRight);
			if (kart.GetControlType() == RcVehicle.ControlType.Human)
			{
				Camera.mainCamera.GetComponent<CamStateFollow>().bBoost = false;
				ParticleSystem componentInChildren = Camera.mainCamera.GetComponentInChildren<ParticleSystem>();
				if (componentInChildren)
				{
					componentInChildren.Stop();
				}
			}
		}
		if (this.m_SlowedDownTimer > 0f)
		{
			this.m_SlowedDownTimer -= deltaTime;
		}
		else if (this.m_SlowedDownTimer != 0f)
		{
			this.m_SlowedDownTimer = 0f;
			this.m_SlowedDownAcceleration = 0f;
			this.m_SlowedDownMaxSpeed = 0f;
			if (this.m_pVehicle.GetControlType() == RcVehicle.ControlType.Human)
			{
				Camera.mainCamera.GetComponent<CamStateFollow>().bSlow = false;
			}
		}
		if (this.m_ParfumeBoostTimer > 0f)
		{
			this.m_ParfumeBoostTimer -= deltaTime;
		}
		else if (this.m_ParfumeBoostTimer != 0f)
		{
			this.m_ParfumeBoostTimer = 0f;
			this.m_ParfumeBoostSpeedUp = 0f;
		}
	}

	// Token: 0x06000916 RID: 2326 RVA: 0x00040AB8 File Offset: 0x0003ECB8
	public void SetDefaultValues()
	{
		this.m_BoostTimer = -1f;
		this.m_BoostSpeedUp = 0f;
		this.m_BoostAcceleration = 0f;
		this.m_SlowedDownTimer = 0f;
		this.m_SlowedDownMaxSpeed = 0f;
		this.m_SlowedDownAcceleration = 0f;
		this.m_ParfumeBoostTimer = -1f;
		this.m_ParfumeBoostSpeedUp = 0f;
	}

	// Token: 0x06000917 RID: 2327 RVA: 0x00040B20 File Offset: 0x0003ED20
	public override float GetMaxSpeed()
	{
		float num = base.GetMaxSpeed();
		if (this.m_SlowedDownTimer > 0f && num > this.m_SlowedDownMaxSpeed)
		{
			num = this.m_SlowedDownMaxSpeed;
		}
		if (this.m_BoostTimer > 0f || this.m_BoostTimer == -1f)
		{
			num += this.m_BoostSpeedUp;
		}
		else if (this.m_ParfumeBoostTimer > 0f)
		{
			num += this.m_ParfumeBoostSpeedUp;
		}
		return num;
	}

	// Token: 0x06000918 RID: 2328 RVA: 0x00008551 File Offset: 0x00006751
	public float GetBaseMaxSpeed()
	{
		return base.GetMaxSpeed();
	}

	// Token: 0x06000919 RID: 2329 RVA: 0x00040BA0 File Offset: 0x0003EDA0
	public override float ComputeAcceleration(float _speedMS)
	{
		float num = base.ComputeAcceleration(_speedMS);
		if (this.m_BoostTimer > 0f || this.m_BoostTimer == -1f)
		{
			return num * this.m_BoostAcceleration;
		}
		if (this.m_SlowedDownTimer > 0f)
		{
			return num * this.m_SlowedDownAcceleration;
		}
		return num;
	}

	// Token: 0x0600091A RID: 2330 RVA: 0x00040BF8 File Offset: 0x0003EDF8
	public void Boost(float _speedUpMs, float _boostDelay, float _BoostAcceleration, bool bWithEffect)
	{
		this.m_BoostSpeedUp = Mathf.Max(this.m_BoostSpeedUp, _speedUpMs * base.GetMaxSpeed() / 100f);
		this.m_BoostTimer = Mathf.Max(this.m_BoostTimer, _boostDelay);
		this.m_BoostAcceleration = Mathf.Max(this.m_BoostAcceleration, _BoostAcceleration);
		Kart kart = (Kart)this.m_pVehicle;
		if (bWithEffect)
		{
			kart.FxMgr.Boost();
		}
		if (kart.GetControlType() == RcVehicle.ControlType.Human && bWithEffect)
		{
			Camera.mainCamera.GetComponent<CamStateFollow>().bBoost = true;
			ParticleSystem componentInChildren = Camera.mainCamera.GetComponentInChildren<ParticleSystem>();
			if (componentInChildren)
			{
				componentInChildren.Play();
			}
		}
	}

	// Token: 0x0600091B RID: 2331 RVA: 0x00008559 File Offset: 0x00006759
	public void ParfumeBoost(float _speedUpMs, float _boostDelay)
	{
		this.m_ParfumeBoostSpeedUp = Mathf.Max(this.m_ParfumeBoostSpeedUp, _speedUpMs * base.GetMaxSpeed() / 100f);
		this.m_ParfumeBoostTimer = Mathf.Max(this.m_ParfumeBoostTimer, _boostDelay);
	}

	// Token: 0x0600091C RID: 2332 RVA: 0x00040CA4 File Offset: 0x0003EEA4
	public void SlowDown(float _SlowedDownMaxSpeed, float _SlowedDownDelay, float _SlowedDownDownMs)
	{
		this.m_SlowedDownMaxSpeed = base.GetMaxSpeed() - _SlowedDownMaxSpeed * base.GetMaxSpeed() / 100f;
		this.m_SlowedDownTimer = _SlowedDownDelay;
		this.m_SlowedDownAcceleration = _SlowedDownDownMs;
		if (this.m_pVehicle.GetControlType() == RcVehicle.ControlType.Human)
		{
			Camera.mainCamera.GetComponent<CamStateFollow>().bSlow = true;
		}
	}

	// Token: 0x0600091D RID: 2333 RVA: 0x0000858C File Offset: 0x0000678C
	public bool IsBoosting()
	{
		return this.m_BoostTimer > 0f;
	}

	// Token: 0x0600091E RID: 2334 RVA: 0x0000859B File Offset: 0x0000679B
	public bool IsParfume()
	{
		return this.m_ParfumeBoostTimer > 0f;
	}

	// Token: 0x0600091F RID: 2335 RVA: 0x00040CFC File Offset: 0x0003EEFC
	public void ApplySpeedAdvantages(int _Index)
	{
		float speed = base.GetSpeed(_Index);
		if (speed <= 0f)
		{
			return;
		}
		if (this.m_fSpeedDiff == -1f || this.m_eLastDifficulty != Singleton<GameConfigurator>.Instance.Difficulty)
		{
			this.m_eLastDifficulty = Singleton<GameConfigurator>.Instance.Difficulty;
			this.ComputeDiffSpeed();
		}
		float num = speed + this.PercentDifficulty[(int)this.m_eLastDifficulty] * speed / 100f;
		float percentAdvantages = this.GetPercentAdvantages(DrivingCaracteristics.SPEED);
		num += percentAdvantages * this.m_fSpeedDiff / 100f;
		this.m_vSpeed[_Index] = num;
	}

	// Token: 0x06000920 RID: 2336 RVA: 0x00040D98 File Offset: 0x0003EF98
	public void ApplyAccelerationAdvantages(int _Index)
	{
		float num = base.GetAcceleration(_Index);
		if (num != 0f)
		{
			float percentAdvantages = this.GetPercentAdvantages(DrivingCaracteristics.ACCELERATION);
			num -= percentAdvantages * this.m_fAccelerationDiff / 100f;
		}
		this.m_vAcceleration[_Index] = num;
	}

	// Token: 0x06000921 RID: 2337 RVA: 0x000085AA File Offset: 0x000067AA
	public float GetSpeedDiff()
	{
		return this.m_fSpeedDiff;
	}

	// Token: 0x06000922 RID: 2338 RVA: 0x00040DE0 File Offset: 0x0003EFE0
	public float GetPercentAdvantages(DrivingCaracteristics _Carac)
	{
		float num = 0f;
		float num2 = 0f;
		float num3 = 0f;
		if (this.m_pPlayerCarac != null && this.m_pPlayerCarac.KartCarac != null)
		{
			num = this.m_pPlayerCarac.KartCarac.GetCarac(_Carac);
			if (this.m_pPlayerCarac.CharacterCarac != null && this.m_pPlayerCarac.KartCarac.BonusCaracteristic == _Carac)
			{
				num += ((this.m_pPlayerCarac.CharacterCarac.Owner != this.m_pPlayerCarac.KartCarac.Owner) ? 0f : this.m_pPlayerCarac.KartCarac.Bonus);
			}
		}
		if (this.m_pPlayerCarac != null && this.m_pPlayerCarac.CharacterCarac != null)
		{
			num2 = this.m_pPlayerCarac.CharacterCarac.GetCarac(_Carac);
		}
		if (this.m_pCustom != null && this.m_pCustom.KartCustom != null)
		{
			num3 = this.m_pCustom.KartCustom.GetCarac(_Carac);
			if (this.m_pPlayerCarac != null && this.m_pPlayerCarac.KartCarac != null && this.m_pCustom.KartCustom.BonusCaracteristic == _Carac)
			{
				num3 += ((this.m_pPlayerCarac.KartCarac.Owner != this.m_pCustom.KartCustom.Owner) ? 0f : this.m_pCustom.KartCustom.Bonus);
			}
		}
		return num + num2 + num3;
	}

	// Token: 0x06000923 RID: 2339 RVA: 0x00040FA4 File Offset: 0x0003F1A4
	public void StartScene()
	{
		for (int i = 0; i < this.m_vSpeed.Count; i++)
		{
			this.ApplySpeedAdvantages(i);
		}
		for (int j = 0; j < this.m_vAcceleration.Count; j++)
		{
			this.ApplyAccelerationAdvantages(j);
		}
	}

	// Token: 0x06000924 RID: 2340 RVA: 0x000085B2 File Offset: 0x000067B2
	public float GetDifficultyMaxSpeed()
	{
		return this.m_fDifficultyMaxSpeed;
	}

	// Token: 0x04000934 RID: 2356
	public float MaxSpeed;

	// Token: 0x04000935 RID: 2357
	public float MaxAcceleration;

	// Token: 0x04000936 RID: 2358
	public float[] PercentDifficulty = new float[Enum.GetValues(typeof(EDifficulty)).Length];

	// Token: 0x04000937 RID: 2359
	private float m_fSpeedDiff;

	// Token: 0x04000938 RID: 2360
	private float m_fAccelerationDiff;

	// Token: 0x04000939 RID: 2361
	private EDifficulty m_eLastDifficulty;

	// Token: 0x0400093A RID: 2362
	private float m_BoostTimer;

	// Token: 0x0400093B RID: 2363
	private float m_BoostSpeedUp;

	// Token: 0x0400093C RID: 2364
	private float m_BoostAcceleration;

	// Token: 0x0400093D RID: 2365
	private float m_SlowedDownTimer;

	// Token: 0x0400093E RID: 2366
	private float m_SlowedDownMaxSpeed;

	// Token: 0x0400093F RID: 2367
	private float m_SlowedDownAcceleration;

	// Token: 0x04000940 RID: 2368
	private float m_ParfumeBoostTimer;

	// Token: 0x04000941 RID: 2369
	private float m_ParfumeBoostSpeedUp;

	// Token: 0x04000942 RID: 2370
	private PlayerCarac m_pPlayerCarac;

	// Token: 0x04000943 RID: 2371
	private PlayerCustom m_pCustom;

	// Token: 0x04000944 RID: 2372
	private float m_fDifficultyMaxSpeed;
}

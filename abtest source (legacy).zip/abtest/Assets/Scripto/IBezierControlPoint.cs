﻿using System;
using UnityEngine;

// Token: 0x02000249 RID: 585
public interface IBezierControlPoint
{
	// Token: 0x17000212 RID: 530
	// (get) Token: 0x0600104A RID: 4170
	BezierControlPointSide Side { get; }

	// Token: 0x17000213 RID: 531
	// (get) Token: 0x0600104B RID: 4171
	// (set) Token: 0x0600104C RID: 4172
	Vector3 CurrentPosition { get; set; }
}

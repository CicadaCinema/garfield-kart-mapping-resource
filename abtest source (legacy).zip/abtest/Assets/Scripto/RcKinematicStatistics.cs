﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

// Token: 0x02000227 RID: 551
public class RcKinematicStatistics : MonoBehaviour
{
	// Token: 0x06000F81 RID: 3969 RVA: 0x0000C919 File Offset: 0x0000AB19
	public void Awake()
	{
		this.m_pComp = base.gameObject.GetComponent<RcKinematicPhysic>();
	}

	// Token: 0x06000F82 RID: 3970 RVA: 0x00003B80 File Offset: 0x00001D80
	public void Start()
	{
	}

	// Token: 0x06000F83 RID: 3971 RVA: 0x0000C92C File Offset: 0x0000AB2C
	public void StartRecording()
	{
		this.m_bRecording = true;
		this.m_fCurTime = 0f;
		this.m_pRecord = new List<RcPhysStats>();
	}

	// Token: 0x06000F84 RID: 3972 RVA: 0x0000C94B File Offset: 0x0000AB4B
	public void StopRecording()
	{
		this.m_bRecording = false;
	}

	// Token: 0x06000F85 RID: 3973 RVA: 0x000635F0 File Offset: 0x000617F0
	public void FixedUpdate()
	{
		if (this.m_bRecording && this.m_pComp != null)
		{
			if (this.iStorageLimit > 0 && this.m_pRecord.Count >= this.iStorageLimit)
			{
				this.m_pRecord.RemoveAt(0);
			}
			float fixedDeltaTime = Time.fixedDeltaTime;
			RcPhysStats item = default(RcPhysStats);
			item.fTime = this.m_fCurTime;
			item.vPos = this.m_pComp.GetVehicleBodyTransform().position;
			item.vCombineMv = this.m_pComp.CombineTrickMv;
			item.vOrient = this.m_pComp.GetVehicleBodyTransform().rotation;
			item.bFlying = this.m_pComp.Flying;
			item.bInertiaMode = this.m_pComp.BInertiaMode;
			item.fWheelSpeed = this.m_pComp.GetWheelSpeed();
			item.fWheelSpeedMs = this.m_pComp.GetVehicle().GetWheelSpeedMS();
			float fTurningRadius = 0f;
			float steeringAngle = this.m_pComp.GetVehicle().GetSteeringAngle();
			if (Mathf.Abs(steeringAngle) > 0.0001f)
			{
				float num = Mathf.Tan(steeringAngle);
				fTurningRadius = -1f * this.m_pComp.GetFrontToRearWheelLength() / num;
			}
			item.fTurningRadius = fTurningRadius;
			int num2 = 0;
			item.Wheel = new RcWheelStats[this.m_pComp.GetWheels().Length];
			foreach (RcPhysicWheel rcPhysicWheel in this.m_pComp.GetWheels())
			{
				RcKinematicWheel rcKinematicWheel = rcPhysicWheel as RcKinematicWheel;
				item.Wheel[num2].bOnGround = rcKinematicWheel.BOnGround;
				item.Wheel[num2].fRestHeight = rcKinematicWheel.VRestContactPoint.y;
				item.Wheel[num2].fGroundHeight = rcKinematicWheel.OGroundCharac.point.y;
				item.Wheel[num2].fAnchorSpeed = rcKinematicWheel.AnchorSpeed;
				item.Wheel[num2].vGroundNormal = rcKinematicWheel.OGroundCharac.normal;
				item.Wheel[num2].iSurface = rcKinematicWheel.OGroundCharac.surface;
				item.Wheel[num2].fCompression = rcKinematicWheel.FStretch;
				num2++;
			}
			this.m_pRecord.Add(item);
			this.m_fCurTime += fixedDeltaTime;
		}
	}

	// Token: 0x06000F86 RID: 3974 RVA: 0x0006388C File Offset: 0x00061A8C
	public void Update()
	{
		if (this.m_pComp.GetVehicle().GetControlType() == RcVehicle.ControlType.Human)
		{
			if (Input.GetKeyDown(KeyCode.T))
			{
				if (Time.fixedDeltaTime < 0.01f)
				{
					Time.fixedDeltaTime = 0.0166666675f;
				}
				else
				{
					Time.fixedDeltaTime = 0.008333334f;
				}
			}
			if (Input.GetKeyDown(KeyCode.Y))
			{
				this.Record = !this.m_bRecording;
			}
			if (Input.GetKeyDown(KeyCode.U))
			{
				this.Save = true;
			}
		}
		if (this.Record != this.m_bRecording)
		{
			if (this.m_bRecording)
			{
				this.StopRecording();
			}
			else
			{
				this.StartRecording();
			}
		}
		if (this.Save)
		{
			this.Save = false;
			this.AutoSaveNew();
		}
	}

	// Token: 0x06000F87 RID: 3975 RVA: 0x00063958 File Offset: 0x00061B58
	public void OnDrawGizmos()
	{
		if (this.m_pRecord != null)
		{
			foreach (RcPhysStats rcPhysStats in this.m_pRecord)
			{
				Gizmos.color = ((!rcPhysStats.bInertiaMode) ? ((!rcPhysStats.bFlying) ? Color.gray : Color.cyan) : ((!rcPhysStats.bFlying) ? Color.red : Color.magenta));
				Gizmos.DrawSphere(rcPhysStats.vPos, this.fDebugScale);
			}
		}
	}

	// Token: 0x06000F88 RID: 3976 RVA: 0x00063A14 File Offset: 0x00061C14
	public void OnGUI()
	{
		GUI.Label(new Rect(0f, 0f, 200f, 50f), "Sim at : " + ((Time.fixedDeltaTime >= 0.01f) ? "60 fps" : "120 fps"));
	}

	// Token: 0x06000F89 RID: 3977 RVA: 0x00063A68 File Offset: 0x00061C68
	public void AutoSaveNew()
	{
		string text;
		do
		{
			text = "CarPhysStats" + ++RcKinematicStatistics.s_iSaveIndex + ".csv";
		}
		while (File.Exists(text));
		this.SaveAs(text);
	}

	// Token: 0x06000F8A RID: 3978 RVA: 0x00063AB8 File Offset: 0x00061CB8
	public void SaveAs(string fileName)
	{
		using (StreamWriter streamWriter = new StreamWriter(fileName))
		{
			streamWriter.Write("Time; PosX; PosY; PosZ; TrickMvY; Ground; Inertia; VX; VY; VZ; WheelSpeed; SteeringRadius");
			foreach (RcPhysicWheel rcPhysicWheel in this.m_pComp.GetWheels())
			{
				string text = "W";
				text += ((rcPhysicWheel.m_eAxle != RcPhysicWheel.WheelAxle.Front) ? ((rcPhysicWheel.m_eAxle != RcPhysicWheel.WheelAxle.Rear) ? "C" : "R") : "F");
				text += ((rcPhysicWheel.m_eSide != RcPhysicWheel.WheelSide.Left) ? ((rcPhysicWheel.m_eSide != RcPhysicWheel.WheelSide.Right) ? "C" : "R") : "L");
				streamWriter.Write("; {0}_Height; {0}_GroundHeight; {0}_Compression; {0}_AnchorSpeed; {0}_NX; {0}_NY; {0}_NZ; {0}_Surface; {0}_Ground; {0}_VH; {0}_VGH", text);
			}
			streamWriter.WriteLine();
			bool flag = true;
			RcPhysStats rcPhysStats = default(RcPhysStats);
			foreach (RcPhysStats rcPhysStats2 in this.m_pRecord)
			{
				float num = 1f / Time.fixedDeltaTime;
				if (flag)
				{
					rcPhysStats = rcPhysStats2;
				}
				else
				{
					num = 1f / (rcPhysStats2.fTime - rcPhysStats.fTime);
				}
				streamWriter.Write("{0}; {1}; {2}; {3}; {4}; {5}; {6}", new object[]
				{
					rcPhysStats2.fTime,
					rcPhysStats2.vPos.x,
					rcPhysStats2.vPos.y,
					rcPhysStats2.vPos.z,
					rcPhysStats2.vCombineMv.y,
					(!rcPhysStats2.bFlying) ? 1 : 0,
					(!rcPhysStats2.bInertiaMode) ? 0 : 1
				});
				float num2 = (rcPhysStats2.vPos.x - rcPhysStats.vPos.x) * num;
				float num3 = (rcPhysStats2.vPos.y - rcPhysStats.vPos.y) * num;
				float num4 = (rcPhysStats2.vPos.z - rcPhysStats.vPos.z) * num;
				streamWriter.Write("; {0}; {1}; {2}; {3}; {4}", new object[]
				{
					num2,
					num3,
					num4,
					rcPhysStats2.fWheelSpeedMs,
					rcPhysStats2.fTurningRadius
				});
				for (int j = 0; j < rcPhysStats2.Wheel.Length; j++)
				{
					RcWheelStats rcWheelStats = rcPhysStats2.Wheel[j];
					RcWheelStats rcWheelStats2 = rcPhysStats.Wheel[j];
					streamWriter.Write("; {0}; {1}; {2}; {3}", new object[]
					{
						rcWheelStats.fRestHeight,
						rcWheelStats.fGroundHeight,
						rcWheelStats.fCompression,
						rcWheelStats.fAnchorSpeed
					});
					streamWriter.Write("; {0}; {1}; {2}; {3}; {4}", new object[]
					{
						rcWheelStats.vGroundNormal.x,
						rcWheelStats.vGroundNormal.y,
						rcWheelStats.vGroundNormal.z,
						rcWheelStats.iSurface,
						(!rcWheelStats.bOnGround) ? 0 : 1
					});
					float num5 = (rcWheelStats.fRestHeight - rcWheelStats2.fRestHeight) * num;
					float num6 = (rcWheelStats.fGroundHeight - rcWheelStats2.fGroundHeight) * num;
					if (!rcWheelStats.bOnGround || !rcWheelStats2.bOnGround)
					{
						num6 = 0f;
					}
					streamWriter.Write("; {0}; {1}", num5, num6);
				}
				streamWriter.WriteLine();
				flag = false;
				rcPhysStats = rcPhysStats2;
			}
		}
	}

	// Token: 0x04000F10 RID: 3856
	public float fDebugScale = 0.05f;

	// Token: 0x04000F11 RID: 3857
	public int iStorageLimit = 1000;

	// Token: 0x04000F12 RID: 3858
	public bool Record;

	// Token: 0x04000F13 RID: 3859
	public bool Save;

	// Token: 0x04000F14 RID: 3860
	protected RcKinematicPhysic m_pComp;

	// Token: 0x04000F15 RID: 3861
	protected List<RcPhysStats> m_pRecord;

	// Token: 0x04000F16 RID: 3862
	protected float m_fCurTime;

	// Token: 0x04000F17 RID: 3863
	protected bool m_bRecording;

	// Token: 0x04000F18 RID: 3864
	protected static int s_iSaveIndex;
}

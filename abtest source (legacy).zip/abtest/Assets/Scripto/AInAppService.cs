﻿using System;
using System.Collections.Generic;

// Token: 0x020001C7 RID: 455
public abstract class AInAppService
{
	// Token: 0x06000C5D RID: 3165 RVA: 0x0000A996 File Offset: 0x00008B96
	public AInAppService(string[] pProductIds)
	{
		this._hasBeenDisposed = false;
		this._isServiceAvailable = false;
		this._canMakePurchase = false;
		this._productIds = pProductIds;
	}

	// Token: 0x17000197 RID: 407
	// (get) Token: 0x06000C5E RID: 3166 RVA: 0x0000A9BA File Offset: 0x00008BBA
	public bool CanMakePurchase
	{
		get
		{
			return this._canMakePurchase;
		}
	}

	// Token: 0x06000C5F RID: 3167
	public abstract void PurchaseProduct(string pProductId);

	// Token: 0x06000C60 RID: 3168
	public abstract void GetData();

	// Token: 0x06000C61 RID: 3169 RVA: 0x0000A9C2 File Offset: 0x00008BC2
	public virtual void Dispose()
	{
		this._hasBeenDisposed = true;
	}

	// Token: 0x04000C16 RID: 3094
	protected bool _hasBeenDisposed;

	// Token: 0x04000C17 RID: 3095
	protected bool _isServiceAvailable;

	// Token: 0x04000C18 RID: 3096
	protected bool _canMakePurchase;

	// Token: 0x04000C19 RID: 3097
	protected string[] _productIds;

	// Token: 0x04000C1A RID: 3098
	public Action<List<InAppProductData>> OnProductListReceived;

	// Token: 0x04000C1B RID: 3099
	public AInAppService.PurchaseDelegate OnPurchaseSucceed;

	// Token: 0x04000C1C RID: 3100
	public AInAppService.PurchaseDelegate OnPurchaseFailed;

	// Token: 0x04000C1D RID: 3101
	public AInAppService.PurchaseDelegate OnPurchaseCancelled;

	// Token: 0x04000C1E RID: 3102
	public AInAppService.RestoreSucceedDelegate OnRestoreSucceed;

	// Token: 0x04000C1F RID: 3103
	public AInAppService.RestoreFailedDelegate OnRestoreFailed;

	// Token: 0x020001C8 RID: 456
	// (Invoke) Token: 0x06000C63 RID: 3171
	public delegate void PurchaseDelegate(string pProductId);

	// Token: 0x020001C9 RID: 457
	// (Invoke) Token: 0x06000C67 RID: 3175
	public delegate void RestoreSucceedDelegate();

	// Token: 0x020001CA RID: 458
	// (Invoke) Token: 0x06000C6B RID: 3179
	public delegate void RestoreFailedDelegate(string pError);
}

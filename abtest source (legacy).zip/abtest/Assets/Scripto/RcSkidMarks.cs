﻿using System;
using UnityEngine;

// Token: 0x0200021F RID: 543
public class RcSkidMarks : MonoBehaviour
{
	// Token: 0x06000F30 RID: 3888 RVA: 0x0005EFB0 File Offset: 0x0005D1B0
	public RcSkidMarks()
	{
		this.m_pVehicle = null;
		this.m_pPhysicWheel = null;
		this.m_fBrakingTimer = 0f;
		this.m_fAlpha = 0f;
		this.m_iPoolSize = 50;
		this.m_fWidth = 0.05f;
		this.m_fLength = 0.4f;
		this.m_vOffset = new Vector3(0f, 0.05f, 0f);
		this.m_fDetailFactor = 1f;
		this.m_vValidPrevPos = false;
		this.m_vPrevPos = Vector3.zero;
		this.m_vPrevSide = Vector3.zero;
		this.m_iNbQuads = 0;
		this.m_iNextQuad = 0;
		this.updated = false;
		this.m_fUVOffset = 0f;
	}

	// Token: 0x06000F31 RID: 3889 RVA: 0x0005F068 File Offset: 0x0005D268
	public void Awake()
	{
		this.m_pPhysicWheel = base.GetComponent<RcPhysicWheel>();
		this.m_pVehicle = base.transform.parent.GetComponentInChildren<RcVehicle>();
		MeshFilter meshFilter = base.GetComponent<MeshFilter>();
		if (meshFilter == null)
		{
			meshFilter = (MeshFilter)base.gameObject.AddComponent(typeof(MeshFilter));
		}
		if (meshFilter.mesh == null)
		{
			meshFilter.mesh = new Mesh();
		}
		this.m_pMesh = meshFilter.mesh;
	}

	// Token: 0x06000F32 RID: 3890 RVA: 0x0005F0F0 File Offset: 0x0005D2F0
	public void Start()
	{
		this.m_iNbQuads = this.m_iPoolSize;
		this.m_pMesh.Clear();
		this.m_pMesh.MarkDynamic();
		this.vertices = new Vector3[this.m_iPoolSize * 4];
		this.normals = new Vector3[this.m_iPoolSize * 4];
		this.tangents = new Vector4[this.m_iPoolSize * 4];
		this.colors = new Color[this.m_iPoolSize * 4];
		this.uvs = new Vector2[this.m_iPoolSize * 4];
		this.triangles = new int[this.m_iPoolSize * 6];
		for (int i = 0; i < this.m_iPoolSize; i++)
		{
			this.vertices[i * 4] = Vector3.zero;
			this.vertices[i * 4 + 1] = Vector3.zero;
			this.vertices[i * 4 + 2] = Vector3.zero;
			this.vertices[i * 4 + 3] = Vector3.zero;
			this.normals[i * 4] = Vector3.up;
			this.normals[i * 4 + 1] = Vector3.up;
			this.normals[i * 4 + 2] = Vector3.up;
			this.normals[i * 4 + 3] = Vector3.up;
			this.tangents[i * 4] = Vector4.zero;
			this.tangents[i * 4 + 1] = Vector4.zero;
			this.tangents[i * 4 + 2] = Vector4.zero;
			this.tangents[i * 4 + 3] = Vector4.zero;
			this.colors[i * 4] = new Color(0f, 0f, 0f, 0f);
			this.colors[i * 4 + 1] = new Color(0f, 0f, 0f, 0f);
			this.colors[i * 4 + 2] = new Color(0f, 0f, 0f, 0f);
			this.colors[i * 4 + 3] = new Color(0f, 0f, 0f, 0f);
			this.uvs[i * 4] = new Vector2(0f, 0f);
			this.uvs[i * 4 + 1] = new Vector2(1f, 0f);
			this.uvs[i * 4 + 2] = new Vector2(0f, 1f);
			this.uvs[i * 4 + 3] = new Vector2(1f, 1f);
			this.triangles[i * 6] = i * 4;
			this.triangles[i * 6 + 1] = i * 4 + 1;
			this.triangles[i * 6 + 2] = i * 4 + 2;
			this.triangles[i * 6 + 3] = i * 4;
			this.triangles[i * 6 + 4] = i * 4 + 2;
			this.triangles[i * 6 + 5] = i * 4 + 3;
		}
		this.m_pMesh.vertices = this.vertices;
		this.m_pMesh.normals = this.normals;
		this.m_pMesh.tangents = this.tangents;
		this.m_pMesh.colors = this.colors;
		this.m_pMesh.uv = this.uvs;
		this.m_pMesh.triangles = this.triangles;
	}

	// Token: 0x06000F33 RID: 3891 RVA: 0x0005F4E4 File Offset: 0x0005D6E4
	public void LateUpdate()
	{
		base.transform.position = Vector3.zero;
		base.transform.rotation = Quaternion.identity;
		if (base.transform.lossyScale != Vector3.one)
		{
			Vector3 one = Vector3.one;
			one.x = 1f / base.transform.lossyScale.x;
			one.y = 1f / base.transform.lossyScale.y;
			one.z = 1f / base.transform.lossyScale.z;
			base.transform.localScale = one;
		}
		float deltaTime = Time.deltaTime;
		float driftRatio = this.m_pVehicle.GetDriftRatio();
		if (Mathf.Abs(driftRatio) > 0f && this.m_pPhysicWheel.BOnGround)
		{
			this.m_fAlpha = Mathf.Abs(driftRatio);
		}
		else
		{
			this.m_fAlpha = 0f;
		}
		float motorSpeedMS = this.m_pVehicle.GetMotorSpeedMS();
		float moveFactor = this.m_pVehicle.GetMoveFactor();
		if (moveFactor < 0f && motorSpeedMS > 0f)
		{
			this.m_fBrakingTimer += deltaTime;
		}
		else
		{
			this.m_fBrakingTimer = 0f;
		}
		if (this.m_fBrakingTimer > 0.3f)
		{
			float value = this.m_fBrakingTimer / 1.5f;
			this.m_fAlpha = Mathf.Max(Mathf.Clamp(value, 0f, 1f), this.m_fAlpha);
		}
		if (this.m_pPhysicWheel.FHandBrake * 0.5f > this.m_fAlpha && this.m_pPhysicWheel.EAxle == RcPhysicWheel.WheelAxle.Rear)
		{
			this.m_fAlpha = 0.5f * this.m_pPhysicWheel.FHandBrake;
		}
		GroundCharac ogroundCharac = this.m_pPhysicWheel.OGroundCharac;
		Vector3 vector = this.m_pPhysicWheel.VehicleRoot.parent.forward;
		Vector3 normal = ogroundCharac.normal;
		Vector3 vector2 = Vector3.Cross(normal, vector);
		vector = Vector3.Cross(vector2, normal);
		Vector3 vector3 = this.m_pPhysicWheel.GetWorldPos() + normal * (this.m_vOffset.y - this.m_pPhysicWheel.m_fRadius) + vector * this.m_vOffset.z;
		if (!this.m_pPhysicWheel.BOnGround || this.m_fAlpha <= 0f)
		{
			this.m_vValidPrevPos = false;
		}
		else
		{
			if (this.m_pPhysicWheel.ESide == RcPhysicWheel.WheelSide.Left)
			{
				vector3 -= vector2 * this.m_vOffset.x;
			}
			else if (this.m_pPhysicWheel.ESide == RcPhysicWheel.WheelSide.Right)
			{
				vector3 += vector2 * this.m_vOffset.x;
			}
			if (!this.m_vValidPrevPos)
			{
				this.m_vPrevSide = vector2;
				this.m_vPrevPos = vector3;
			}
			float magnitude = (this.m_vPrevPos - vector3).magnitude;
			bool reverse = Vector3.Dot(vector3 - this.m_vPrevPos, vector) < 0f;
			this.UpdateQuad(normal, this.m_vPrevPos, vector3, this.m_vPrevSide, vector2, this.m_fWidth, this.m_fAlpha, reverse);
			this.updated = true;
			if (magnitude > this.m_fLength / this.m_fDetailFactor)
			{
				this.NextQuad();
				this.m_vPrevPos = vector3;
				this.m_vPrevSide = vector2;
			}
			this.m_vValidPrevPos = true;
		}
		if (this.updated)
		{
			this.m_pMesh.Clear();
			this.m_pMesh.vertices = this.vertices;
			this.m_pMesh.normals = this.normals;
			this.m_pMesh.tangents = this.tangents;
			this.m_pMesh.triangles = this.triangles;
			this.m_pMesh.colors = this.colors;
			this.m_pMesh.uv = this.uvs;
			this.updated = false;
		}
	}

	// Token: 0x06000F34 RID: 3892 RVA: 0x0005F904 File Offset: 0x0005DB04
	public void UpdateQuad(Vector3 up, Vector3 previousPos, Vector3 pos, Vector3 previousSide, Vector3 side, float width, float alpha, bool reverse)
	{
		Vector3 lhs = pos - previousPos;
		Vector3 vector = Vector3.Cross(lhs, up);
		vector.Normalize();
		this.normals[this.m_iNextQuad * 4] = up;
		this.normals[this.m_iNextQuad * 4 + 1] = up;
		this.normals[this.m_iNextQuad * 4 + 2] = up;
		this.normals[this.m_iNextQuad * 4 + 3] = up;
		this.tangents[this.m_iNextQuad * 4] = new Vector4(vector.x, vector.y, vector.z, 1f);
		this.tangents[this.m_iNextQuad * 4 + 1] = new Vector4(vector.x, vector.y, vector.z, 1f);
		this.tangents[this.m_iNextQuad * 4 + 2] = new Vector4(vector.x, vector.y, vector.z, 1f);
		this.tangents[this.m_iNextQuad * 4 + 3] = new Vector4(vector.x, vector.y, vector.z, 1f);
		float num = (pos - previousPos).magnitude / width;
		if (reverse)
		{
			this.vertices[this.m_iNextQuad * 4 + 3] = pos - side * width;
			this.uvs[this.m_iNextQuad * 4 + 3] = new Vector2(0f, num + this.m_fUVOffset);
			this.vertices[this.m_iNextQuad * 4 + 2] = pos + side * width;
			this.uvs[this.m_iNextQuad * 4 + 2] = new Vector2(1f, num + this.m_fUVOffset);
			this.vertices[this.m_iNextQuad * 4 + 1] = previousPos + previousSide * width;
			this.uvs[this.m_iNextQuad * 4 + 1] = new Vector2(1f, this.m_fUVOffset);
			this.vertices[this.m_iNextQuad * 4] = previousPos - previousSide * width;
			this.uvs[this.m_iNextQuad * 4] = new Vector2(0f, this.m_fUVOffset);
			this.colors[this.m_iNextQuad * 4 + 3] = new Color(0f, 0f, 0f, alpha);
			this.colors[this.m_iNextQuad * 4 + 2] = new Color(0f, 0f, 0f, alpha);
			this.colors[this.m_iNextQuad * 4 + 1] = new Color(0f, 0f, 0f, this.m_fPrevAlpha);
			this.colors[this.m_iNextQuad * 4] = new Color(0f, 0f, 0f, this.m_fPrevAlpha);
		}
		else
		{
			this.vertices[this.m_iNextQuad * 4] = pos - side * width;
			this.uvs[this.m_iNextQuad * 4] = new Vector2(0f, num + this.m_fUVOffset);
			this.vertices[this.m_iNextQuad * 4 + 1] = pos + side * width;
			this.uvs[this.m_iNextQuad * 4 + 1] = new Vector2(1f, num + this.m_fUVOffset);
			this.vertices[this.m_iNextQuad * 4 + 2] = previousPos + previousSide * width;
			this.uvs[this.m_iNextQuad * 4 + 2] = new Vector2(1f, this.m_fUVOffset);
			this.vertices[this.m_iNextQuad * 4 + 3] = previousPos - previousSide * width;
			this.uvs[this.m_iNextQuad * 4 + 3] = new Vector2(0f, this.m_fUVOffset);
			this.colors[this.m_iNextQuad * 4] = new Color(0f, 0f, 0f, alpha);
			this.colors[this.m_iNextQuad * 4 + 1] = new Color(0f, 0f, 0f, alpha);
			this.colors[this.m_iNextQuad * 4 + 2] = new Color(0f, 0f, 0f, this.m_fPrevAlpha);
			this.colors[this.m_iNextQuad * 4 + 3] = new Color(0f, 0f, 0f, this.m_fPrevAlpha);
		}
		this.m_fUVOffset += num;
		this.m_fUVOffset -= (float)((int)this.m_fUVOffset);
		this.m_fPrevAlpha = alpha;
	}

	// Token: 0x06000F35 RID: 3893 RVA: 0x0000C769 File Offset: 0x0000A969
	public void NextQuad()
	{
		this.m_iNextQuad++;
		if (this.m_iNextQuad >= this.m_iNbQuads)
		{
			this.m_iNextQuad = 0;
		}
	}

	// Token: 0x04000EA2 RID: 3746
	private RcPhysicWheel m_pPhysicWheel;

	// Token: 0x04000EA3 RID: 3747
	private RcVehicle m_pVehicle;

	// Token: 0x04000EA4 RID: 3748
	private float m_fBrakingTimer;

	// Token: 0x04000EA5 RID: 3749
	private float m_fAlpha;

	// Token: 0x04000EA6 RID: 3750
	private float m_fPrevAlpha;

	// Token: 0x04000EA7 RID: 3751
	public int m_iPoolSize;

	// Token: 0x04000EA8 RID: 3752
	public float m_fWidth;

	// Token: 0x04000EA9 RID: 3753
	public float m_fLength;

	// Token: 0x04000EAA RID: 3754
	public Vector3 m_vOffset;

	// Token: 0x04000EAB RID: 3755
	public float m_fUVOffset;

	// Token: 0x04000EAC RID: 3756
	public float m_fDetailFactor;

	// Token: 0x04000EAD RID: 3757
	private int m_iNbQuads;

	// Token: 0x04000EAE RID: 3758
	private int m_iNextQuad;

	// Token: 0x04000EAF RID: 3759
	private bool m_vValidPrevPos;

	// Token: 0x04000EB0 RID: 3760
	private Vector3 m_vPrevPos;

	// Token: 0x04000EB1 RID: 3761
	private Vector3 m_vPrevSide;

	// Token: 0x04000EB2 RID: 3762
	private bool updated;

	// Token: 0x04000EB3 RID: 3763
	private Vector3[] vertices;

	// Token: 0x04000EB4 RID: 3764
	private Vector3[] normals;

	// Token: 0x04000EB5 RID: 3765
	private Vector4[] tangents;

	// Token: 0x04000EB6 RID: 3766
	private Color[] colors;

	// Token: 0x04000EB7 RID: 3767
	private Vector2[] uvs;

	// Token: 0x04000EB8 RID: 3768
	private int[] triangles;

	// Token: 0x04000EB9 RID: 3769
	private MeshFilter meshFilter;

	// Token: 0x04000EBA RID: 3770
	private MeshRenderer meshRenderer;

	// Token: 0x04000EBB RID: 3771
	private Mesh m_pMesh;
}

﻿using System;

// Token: 0x0200017E RID: 382
public enum LaunchType
{
	// Token: 0x04000A2A RID: 2602
	ANY,
	// Token: 0x04000A2B RID: 2603
	FRONT,
	// Token: 0x04000A2C RID: 2604
	BACK
}

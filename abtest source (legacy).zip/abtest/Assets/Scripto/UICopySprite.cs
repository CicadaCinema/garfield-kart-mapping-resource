﻿using System;
using UnityEngine;

// Token: 0x02000128 RID: 296
public class UICopySprite : MonoBehaviour
{
	// Token: 0x06000812 RID: 2066 RVA: 0x0003CFC8 File Offset: 0x0003B1C8
	public void Start()
	{
		if (this.m_pCopiedSprite)
		{
			this.m_pSpriteInstance = (GameObject)UnityEngine.Object.Instantiate(this.m_pCopiedSprite.gameObject);
		}
		if (this.m_pSpriteInstance)
		{
			this.m_pSpriteInstance.transform.parent = base.transform.parent;
			this.m_pSpriteInstance.transform.localPosition = new Vector3(base.transform.localPosition.x, base.transform.localPosition.y, base.transform.localPosition.z - 1f);
			this.m_pSpriteInstance.transform.localScale = base.transform.localScale;
			this.m_pSpriteInstance.SetActive(false);
			this.m_pUISprite = this.m_pSpriteInstance.GetComponent<UISprite>();
		}
	}

	// Token: 0x06000813 RID: 2067 RVA: 0x00003B80 File Offset: 0x00001D80
	public void Update()
	{
	}

	// Token: 0x06000814 RID: 2068 RVA: 0x0003D0B8 File Offset: 0x0003B2B8
	public void LateUpdate()
	{
		if (!this.m_pSpriteInstance || !this.m_pCopiedSprite || !this.m_pUISprite)
		{
			return;
		}
		this.m_pSpriteInstance.SetActive(this.m_pCopiedSprite.gameObject.activeSelf);
		if (!this.m_pCopiedSprite.atlas.Equals(this.m_pUISprite.atlas))
		{
			this.m_pUISprite.atlas = this.m_pCopiedSprite.atlas;
		}
		if (!this.m_pCopiedSprite.spriteName.Equals(this.m_pUISprite.spriteName))
		{
			this.m_pUISprite.spriteName = this.m_pCopiedSprite.spriteName;
		}
	}

	// Token: 0x06000815 RID: 2069 RVA: 0x00007B1C File Offset: 0x00005D1C
	public void OnDestroy()
	{
		if (this.m_pSpriteInstance)
		{
			UnityEngine.Object.Destroy(this.m_pSpriteInstance);
		}
	}

	// Token: 0x06000816 RID: 2070 RVA: 0x00007B39 File Offset: 0x00005D39
	public void OnDisable()
	{
		if (this.m_pSpriteInstance)
		{
			this.m_pSpriteInstance.SetActive(false);
		}
	}

	// Token: 0x04000854 RID: 2132
	public UISprite m_pCopiedSprite;

	// Token: 0x04000855 RID: 2133
	private GameObject m_pSpriteInstance;

	// Token: 0x04000856 RID: 2134
	private UISprite m_pUISprite;
}

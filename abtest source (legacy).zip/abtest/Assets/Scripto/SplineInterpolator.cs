﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000251 RID: 593
public class SplineInterpolator : MonoBehaviour
{
	// Token: 0x06001065 RID: 4197 RVA: 0x0000D053 File Offset: 0x0000B253
	public void Awake()
	{
		this.Reset();
	}

	// Token: 0x06001066 RID: 4198 RVA: 0x00066E4C File Offset: 0x0006504C
	public void StartInterpolation(OnEndCallback endCallback, bool bRotations, eWrapMode mode)
	{
		if (this.mState != "Reset")
		{
			throw new Exception("First reset, add points and then call here");
		}
		this.mState = ((mode != eWrapMode.ONCE) ? "Loop" : "Once");
		this.mRotations = bRotations;
		this.mOnEndCallback = endCallback;
		this.SetInput();
	}

	// Token: 0x06001067 RID: 4199 RVA: 0x0000D05B File Offset: 0x0000B25B
	public void Reset()
	{
		this.mNodes.Clear();
		this.mState = "Reset";
		this.mCurrentIdx = 1;
		this.mCurrentTime = 0f;
		this.mRotations = false;
		this.mEndPointsMode = eEndPointsMode.AUTO;
	}

	// Token: 0x06001068 RID: 4200 RVA: 0x0000D093 File Offset: 0x0000B293
	public void AddPoint(Vector3 pos, Quaternion quat, float timeInSeconds, Vector2 easeInOut)
	{
		if (this.mState != "Reset")
		{
			throw new Exception("Cannot add points after start");
		}
		this.mNodes.Add(new SplineInterpolator.SplineNode(pos, quat, timeInSeconds, easeInOut));
	}

	// Token: 0x06001069 RID: 4201 RVA: 0x00066EA8 File Offset: 0x000650A8
	private void SetInput()
	{
		if (this.mNodes.Count < 2)
		{
			throw new Exception("Invalid number of points");
		}
		if (this.mRotations)
		{
			for (int i = 1; i < this.mNodes.Count; i++)
			{
				SplineInterpolator.SplineNode splineNode = this.mNodes[i];
				SplineInterpolator.SplineNode splineNode2 = this.mNodes[i - 1];
				if (Quaternion.Dot(splineNode.Rot, splineNode2.Rot) < 0f)
				{
					splineNode.Rot.x = -splineNode.Rot.x;
					splineNode.Rot.y = -splineNode.Rot.y;
					splineNode.Rot.z = -splineNode.Rot.z;
					splineNode.Rot.w = -splineNode.Rot.w;
				}
			}
		}
		if (this.mEndPointsMode == eEndPointsMode.AUTO)
		{
			this.mNodes.Insert(0, this.mNodes[0]);
			this.mNodes.Add(this.mNodes[this.mNodes.Count - 1]);
		}
		else if (this.mEndPointsMode == eEndPointsMode.EXPLICIT && this.mNodes.Count < 4)
		{
			throw new Exception("Invalid number of points");
		}
	}

	// Token: 0x0600106A RID: 4202 RVA: 0x0000D0CA File Offset: 0x0000B2CA
	private void SetExplicitMode()
	{
		if (this.mState != "Reset")
		{
			throw new Exception("Cannot change mode after start");
		}
		this.mEndPointsMode = eEndPointsMode.EXPLICIT;
	}

	// Token: 0x0600106B RID: 4203 RVA: 0x00067000 File Offset: 0x00065200
	public void SetAutoCloseMode(float joiningPointTime)
	{
		if (this.mState != "Reset")
		{
			throw new Exception("Cannot change mode after start");
		}
		this.mEndPointsMode = eEndPointsMode.AUTOCLOSED;
		this.mNodes.Add(new SplineInterpolator.SplineNode(this.mNodes[0]));
		this.mNodes[this.mNodes.Count - 1].Time = joiningPointTime;
		Vector3 normalized = (this.mNodes[1].Point - this.mNodes[0].Point).normalized;
		Vector3 normalized2 = (this.mNodes[this.mNodes.Count - 2].Point - this.mNodes[this.mNodes.Count - 1].Point).normalized;
		float magnitude = (this.mNodes[1].Point - this.mNodes[0].Point).magnitude;
		float magnitude2 = (this.mNodes[this.mNodes.Count - 2].Point - this.mNodes[this.mNodes.Count - 1].Point).magnitude;
		SplineInterpolator.SplineNode splineNode = new SplineInterpolator.SplineNode(this.mNodes[0]);
		splineNode.Point = this.mNodes[0].Point + normalized2 * magnitude;
		SplineInterpolator.SplineNode splineNode2 = new SplineInterpolator.SplineNode(this.mNodes[this.mNodes.Count - 1]);
		splineNode2.Point = this.mNodes[0].Point + normalized * magnitude2;
		this.mNodes.Insert(0, splineNode);
		this.mNodes.Add(splineNode2);
	}

	// Token: 0x0600106C RID: 4204 RVA: 0x000671F8 File Offset: 0x000653F8
	public void Update()
	{
		if (this.mState == "Reset" || this.mState == "Stopped" || this.mNodes.Count < 4)
		{
			return;
		}
		this.mCurrentTime += Time.deltaTime;
		if (this.mCurrentTime >= this.mNodes[this.mCurrentIdx + 1].Time)
		{
			if (this.mCurrentIdx < this.mNodes.Count - 3)
			{
				this.mCurrentIdx++;
			}
			else if (this.mState != "Loop")
			{
				this.mState = "Stopped";
				base.transform.position = this.mNodes[this.mNodes.Count - 2].Point;
				if (this.mRotations)
				{
					base.transform.rotation = this.mNodes[this.mNodes.Count - 2].Rot;
				}
				if (this.mOnEndCallback != null)
				{
					this.mOnEndCallback();
				}
			}
			else
			{
				this.mCurrentIdx = 1;
				this.mCurrentTime = 0f;
			}
		}
		if (this.mState != "Stopped")
		{
			float t = (this.mCurrentTime - this.mNodes[this.mCurrentIdx].Time) / (this.mNodes[this.mCurrentIdx + 1].Time - this.mNodes[this.mCurrentIdx].Time);
			t = MathUtils.Ease(t, this.mNodes[this.mCurrentIdx].EaseIO.x, this.mNodes[this.mCurrentIdx].EaseIO.y);
			base.transform.position = this.GetHermiteInternal(this.mCurrentIdx, t);
			if (this.mRotations)
			{
				base.transform.rotation = this.GetSquad(this.mCurrentIdx, t);
			}
		}
	}

	// Token: 0x0600106D RID: 4205 RVA: 0x00067424 File Offset: 0x00065624
	private Quaternion GetSquad(int idxFirstPoint, float t)
	{
		Quaternion rot = this.mNodes[idxFirstPoint - 1].Rot;
		Quaternion rot2 = this.mNodes[idxFirstPoint].Rot;
		Quaternion rot3 = this.mNodes[idxFirstPoint + 1].Rot;
		Quaternion rot4 = this.mNodes[idxFirstPoint + 2].Rot;
		Quaternion squadIntermediate = MathUtils.GetSquadIntermediate(rot, rot2, rot3);
		Quaternion squadIntermediate2 = MathUtils.GetSquadIntermediate(rot2, rot3, rot4);
		return MathUtils.GetQuatSquad(t, rot2, rot3, squadIntermediate, squadIntermediate2);
	}

	// Token: 0x0600106E RID: 4206 RVA: 0x000674A0 File Offset: 0x000656A0
	public Vector3 GetHermiteInternal(int idxFirstPoint, float t)
	{
		float num = t * t;
		float num2 = num * t;
		Vector3 point = this.mNodes[idxFirstPoint - 1].Point;
		Vector3 point2 = this.mNodes[idxFirstPoint].Point;
		Vector3 point3 = this.mNodes[idxFirstPoint + 1].Point;
		Vector3 point4 = this.mNodes[idxFirstPoint + 2].Point;
		float d = 0.5f;
		Vector3 a = d * (point3 - point);
		Vector3 a2 = d * (point4 - point2);
		float d2 = 2f * num2 - 3f * num + 1f;
		float d3 = -2f * num2 + 3f * num;
		float d4 = num2 - 2f * num + t;
		float d5 = num2 - num;
		return d2 * point2 + d3 * point3 + d4 * a + d5 * a2;
	}

	// Token: 0x0600106F RID: 4207 RVA: 0x0006759C File Offset: 0x0006579C
	public Vector3 GetHermiteAtTime(float timeParam)
	{
		if (timeParam >= this.mNodes[this.mNodes.Count - 2].Time)
		{
			return this.mNodes[this.mNodes.Count - 2].Point;
		}
		int i;
		for (i = 1; i < this.mNodes.Count - 2; i++)
		{
			if (this.mNodes[i].Time > timeParam)
			{
				break;
			}
		}
		int num = i - 1;
		float t = (timeParam - this.mNodes[num].Time) / (this.mNodes[num + 1].Time - this.mNodes[num].Time);
		t = MathUtils.Ease(t, this.mNodes[num].EaseIO.x, this.mNodes[num].EaseIO.y);
		return this.GetHermiteInternal(num, t);
	}

	// Token: 0x04000FAF RID: 4015
	private eEndPointsMode mEndPointsMode;

	// Token: 0x04000FB0 RID: 4016
	private List<SplineInterpolator.SplineNode> mNodes = new List<SplineInterpolator.SplineNode>();

	// Token: 0x04000FB1 RID: 4017
	private string mState = string.Empty;

	// Token: 0x04000FB2 RID: 4018
	private bool mRotations;

	// Token: 0x04000FB3 RID: 4019
	private OnEndCallback mOnEndCallback;

	// Token: 0x04000FB4 RID: 4020
	private float mCurrentTime;

	// Token: 0x04000FB5 RID: 4021
	private int mCurrentIdx = 1;

	// Token: 0x02000252 RID: 594
	internal class SplineNode
	{
		// Token: 0x06001070 RID: 4208 RVA: 0x0000D0F3 File Offset: 0x0000B2F3
		internal SplineNode(Vector3 p, Quaternion q, float t, Vector2 io)
		{
			this.Point = p;
			this.Rot = q;
			this.Time = t;
			this.EaseIO = io;
		}

		// Token: 0x06001071 RID: 4209 RVA: 0x0000D118 File Offset: 0x0000B318
		internal SplineNode(SplineInterpolator.SplineNode o)
		{
			this.Point = o.Point;
			this.Rot = o.Rot;
			this.Time = o.Time;
			this.EaseIO = o.EaseIO;
		}

		// Token: 0x04000FB6 RID: 4022
		internal Vector3 Point;

		// Token: 0x04000FB7 RID: 4023
		internal Quaternion Rot;

		// Token: 0x04000FB8 RID: 4024
		internal float Time;

		// Token: 0x04000FB9 RID: 4025
		internal Vector2 EaseIO;
	}
}

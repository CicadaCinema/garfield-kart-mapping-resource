﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000AF RID: 175
public class EntryPoint : MonoBehaviour
{
   
	// Token: 0x170000D8 RID: 216
	// (get) Token: 0x0600045F RID: 1119 RVA: 0x000052F6 File Offset: 0x000034F6
	// (set) Token: 0x06000460 RID: 1120 RVA: 0x000052FE File Offset: 0x000034FE
	public bool DisplayHighlightTutorial
	{
		get
		{
			return this.m_bDisplayHighlightTutorial;
		}
		set
		{
			this.m_bDisplayHighlightTutorial = value;
		}
	}

	// Token: 0x170000D9 RID: 217
	// (get) Token: 0x06000461 RID: 1121 RVA: 0x00005307 File Offset: 0x00003507
	// (set) Token: 0x06000462 RID: 1122 RVA: 0x0000530F File Offset: 0x0000350F
	public EntryPoint.eFacebookState FacebookState
	{
		get
		{
			return this.m_eFacebookState;
		}
		set
		{
			this.m_eFacebookState = value;
		}
	}

	// Token: 0x170000DA RID: 218
	// (get) Token: 0x06000463 RID: 1123 RVA: 0x00003B7D File Offset: 0x00001D7D
	// (set) Token: 0x06000464 RID: 1124 RVA: 0x00005318 File Offset: 0x00003518
	public bool AskForRating
	{
		get
		{
			return false;
		}
		set
		{
			this.m_bAskForRating = value;
			if (value)
			{
				Singleton<GameSaveManager>.Instance.AddAskRating(true);
			}
		}
	}

	// Token: 0x170000DB RID: 219
	// (get) Token: 0x06000465 RID: 1125 RVA: 0x00003B7D File Offset: 0x00001D7D
	// (set) Token: 0x06000466 RID: 1126 RVA: 0x00005332 File Offset: 0x00003532
	public bool AskForSharing
	{
		get
		{
			return false;
		}
		set
		{
			this.m_bAskForSharing = value;
		}
	}

	// Token: 0x170000DC RID: 220
	// (get) Token: 0x06000467 RID: 1127 RVA: 0x00003B7D File Offset: 0x00001D7D
	// (set) Token: 0x06000468 RID: 1128 RVA: 0x0000533B File Offset: 0x0000353B
	public bool ShowInterstitial
	{
		get
		{
			return false;
		}
		set
		{
			this.m_bShowInterstitial = value;
		}
	}

	// Token: 0x06000469 RID: 1129 RVA: 0x00027700 File Offset: 0x00025900
	public void Awake()
	{
		if (LogManager.Instance != null)
		{
		}
		if (!Debug.isDebugBuild)
		{
			this.StartScene = "MenuRoot";
		}
		InAppManager instance = Singleton<InAppManager>.Instance;
		instance.OnProductDataReceived = (Action<List<InAppProductData>>)Delegate.Combine(instance.OnProductDataReceived, new Action<List<InAppProductData>>(this.InAppProductDataReceived));
		UnityEngine.Object.DontDestroyOnLoad(this);
		//ASE_ChartBoost.SetGameObjectName(base.name);
		//ASE_Facebook.SetGameObjectName(base.name);
        
        //TODO put discord rich integration here

        
    }


    // Token: 0x0600046A RID: 1130 RVA: 0x00005344 File Offset: 0x00003544
    private void DoDestroy()
	{
		InAppManager instance = Singleton<InAppManager>.Instance;
		instance.OnProductDataReceived = (Action<List<InAppProductData>>)Delegate.Remove(instance.OnProductDataReceived, new Action<List<InAppProductData>>(this.InAppProductDataReceived));
	}

	// Token: 0x0600046B RID: 1131 RVA: 0x00027770 File Offset: 0x00025970
	public void Start()
	{
		UnityEngine.Object[] array = Resources.LoadAll("InApp", typeof(InAppCarac));
		Singleton<GameManager>.Instance.Init();
		Singleton<GameConfigurator>.Instance.Init();
		Singleton<GameConfigurator>.Instance.FacebookAppID = this.FacebookAppID;
		Singleton<InputManager>.Instance.Init();
		Singleton<RandomManager>.Instance.Init();
		Singleton<GameOptionManager>.Instance.Init();
		Singleton<GameSaveManager>.Instance.Init();
		Singleton<ChallengeManager>.Instance.Init();
		Singleton<RewardManager>.Instance.Reset();
		string[] array2 = new string[array.Length];
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i] is InAppCarac)
			{
				InAppCarac inAppCarac = (InAppCarac)array[i];
				array2[i] = inAppCarac.ProdutId;
			}
		}
		Singleton<InAppManager>.Instance.CollectStoreInfo(array2);
		Singleton<GameConfigurator>.Instance.StartScene = this.StartScene;
		LoadingManager.LoadLevel(this.StartScene);
		GameObject gameObject = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("AISettings"));
		UnityEngine.Object.DontDestroyOnLoad(gameObject);
		AISettings component = gameObject.GetComponent<AISettings>();
		Singleton<GameConfigurator>.Instance.AISettings = component;
		GameObject gameObject2 = (GameObject)UnityEngine.Object.Instantiate(Resources.Load("GameSettings"));
		UnityEngine.Object.DontDestroyOnLoad(gameObject2);
		GameSettings component2 = gameObject2.GetComponent<GameSettings>();
		Singleton<GameConfigurator>.Instance.GameSettings = component2;
		if (ASE_Tools.Available)
		{
			ASE_ChartBoost.Init(Singleton<GameConfigurator>.Instance.ChartBoostAppID, Singleton<GameConfigurator>.Instance.ChartBoostAppSignature);
			ASE_ChartBoost.CacheInterstitial("Default");
			ASE_ChartBoost.CacheMoreApps();
			ASE_Facebook.Connect(Singleton<GameConfigurator>.Instance.FacebookAppID);
			ASE_Flurry.Init(this.FlurryApiID);
		}
		this.m_eFacebookState = EntryPoint.eFacebookState.None;
        //GKML.ModLoader.EntryPoint();
    }

	// Token: 0x0600046C RID: 1132 RVA: 0x0002790C File Offset: 0x00025B0C
	public void Update()
	{
		DebugMgr.Instance.NullSafe(delegate(DebugMgr i)
		{
		});
		Singleton<ChallengeManager>.Instance.NullSafe(delegate(ChallengeManager i)
		{
			i.Update();
		});
	}

	// Token: 0x0600046D RID: 1133 RVA: 0x0000536C File Offset: 0x0000356C
	public void LateUpdate()
	{
		Singleton<InputManager>.Instance.Update();
	}

	// Token: 0x0600046E RID: 1134 RVA: 0x00005378 File Offset: 0x00003578
	public void InAppProductDataReceived(List<InAppProductData> pList)
	{
		this.m_pInAppProduct = pList;
	}

	// Token: 0x0600046F RID: 1135 RVA: 0x00027968 File Offset: 0x00025B68
	public InAppProductData GetInAppData(string sProductID)
	{
		if (this.m_pInAppProduct.Count == 0)
		{
			return null;
		}
		foreach (InAppProductData inAppProductData in this.m_pInAppProduct)
		{
			if (inAppProductData.ProductID == sProductID)
			{
				return inAppProductData;
			}
		}
		return null;
	}

	// Token: 0x06000470 RID: 1136 RVA: 0x000279E8 File Offset: 0x00025BE8
	private void AutoChooseQualityLevel()
	{
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			float[] array = new float[]
			{
				0.4f,
				0.5f,
				0.6f,
				0.7f,
				1.5f,
				2f
			};
			if (Application.platform == RuntimePlatform.IPhonePlayer)
			{
				QualitySettings.lodBias = array[4];
			}
			else
			{
				int graphicsShaderLevel = SystemInfo.graphicsShaderLevel;
				int num = SystemInfo.graphicsPixelFillrate;
				int graphicsMemorySize = SystemInfo.graphicsMemorySize;
				int processorCount = SystemInfo.processorCount;
				if (num < 0)
				{
					if (graphicsShaderLevel < 10)
					{
						num = 1000;
					}
					else if (graphicsShaderLevel < 20)
					{
						num = 1300;
					}
					else if (graphicsShaderLevel < 30)
					{
						num = 2000;
					}
					else
					{
						num = 3000;
					}
					if (processorCount >= 6)
					{
						num *= 3;
					}
					else if (processorCount >= 3)
					{
						num *= 2;
					}
					if (graphicsMemorySize >= 512)
					{
						num *= 2;
					}
					else if (graphicsMemorySize <= 128)
					{
						num /= 2;
					}
				}
				int width = Screen.width;
				int height = Screen.height;
				float num2 = (float)(width * height + 120000) * 3E-05f;
				float[] array2 = new float[]
				{
					5f,
					30f,
					80f,
					130f,
					200f,
					320f
				};
				int num3 = 0;
				string[] names = QualitySettings.names;
				while (num3 < names.Length && (float)num > num2 * array2[num3 + 1])
				{
					num3++;
				}
				QualitySettings.lodBias = array[num3];
			}
		}
	}

	// Token: 0x06000471 RID: 1137 RVA: 0x00027B44 File Offset: 0x00025D44
	private void FacebookEvent(string sData)
	{
		string text = ((ASE_Facebook.FacebookEvent)ASE_Tools.GetDataEvent(sData)).ToString();
		if (sData.Length > 1)
		{
			text = text + " : " + ASE_Tools.GetDataMessage(sData);
		}
		if (text.Contains("FBEVENT_PUBLICATION_DID_SHARED"))
		{
			if (this.m_eFacebookState == EntryPoint.eFacebookState.SharingAsked)
			{
				Singleton<RewardManager>.Instance.GiveSharingReward();
				Singleton<GameSaveManager>.Instance.SetAskSharing(false, true);
			}
		}
		else if (text.Contains("FBEVENT_PUBLICATION_DID_CANCELED"))
		{
		}
	}

	// Token: 0x06000472 RID: 1138 RVA: 0x00027BC8 File Offset: 0x00025DC8
	private void ChartBoostEvent(string sData)
	{
		string str = ((ASE_ChartBoost.ChartBoostEvent)ASE_Tools.GetDataEvent(sData)).ToString();
		if (sData.Length > 1)
		{
			str = str + " : " + ASE_Tools.GetDataMessage(sData);
		}
	}

	// Token: 0x06000473 RID: 1139 RVA: 0x00027C04 File Offset: 0x00025E04
	public void OnFacebook(string sTitle, string sDescription)
	{
		if (ASE_Tools.Available)
		{
			this.m_sFacebookTitle = sTitle;
			this.m_sFacebookDescription = sDescription;
			if (!ASE_Facebook.IsConnected())
			{
				ASE_Facebook.Connect(Singleton<GameConfigurator>.Instance.FacebookAppID);
			}
			if (ASE_Facebook.IsConnected())
			{
				this.FacebookOperations();
			}
		}
	}

	// Token: 0x06000474 RID: 1140 RVA: 0x00005381 File Offset: 0x00003581
	public void DoSharing()
	{
		this.m_bSharingOn = true;
		this.OnFacebook(string.Empty, string.Empty);
	}

	// Token: 0x06000475 RID: 1141 RVA: 0x0000539A File Offset: 0x0000359A
	public void FacebookLogin()
	{
		if (ASE_Facebook.IsConnected() && string.IsNullOrEmpty(ASE_Facebook.GetUserId()))
		{
			ASE_Facebook.Login();
			Debug.Log("login facebook");
			this.m_eFacebookState = EntryPoint.eFacebookState.Login;
		}
	}

	// Token: 0x06000476 RID: 1142 RVA: 0x00027C54 File Offset: 0x00025E54
	public void FacebookOperations()
	{
		if (this.m_bSharingOn)
		{
			ASE_Facebook.Publish("GarfieldKart", string.Empty, Localization.instance.Get("FB_SHARE_TEXT"), "https://itunes.apple.com/fr/app/id656101044?mt=8", "http://iphone.anuman.fr/FACEBOOK/Microidsgamesforall/GarfielKart/garfieldkart_320.jpg");
			this.m_eFacebookState = EntryPoint.eFacebookState.SharingAsked;
			this.m_bSharingOn = false;
		}
		else
		{
			string icon = string.Empty;
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.CHAMPIONSHIP)
			{
				icon = "http://iphone.anuman.fr/FACEBOOK/Microidsgamesforall/GarfielKart/GK12_championship.png";
			}
			else if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.SINGLE)
			{
				icon = "http://iphone.anuman.fr/FACEBOOK/Microidsgamesforall/GarfielKart/GK12_single_race.png";
			}
			else if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
			{
				icon = "http://iphone.anuman.fr/FACEBOOK/Microidsgamesforall/GarfielKart/GK12_time_trial.png";
			}
			ASE_Facebook.Publish(this.m_sFacebookTitle, string.Empty, this.m_sFacebookDescription, "https://itunes.apple.com/fr/app/id656101044?mt=8", icon);
			this.m_eFacebookState = EntryPoint.eFacebookState.PublishAsked;
		}
	}

	// Token: 0x06000477 RID: 1143 RVA: 0x000053CB File Offset: 0x000035CB
	public void OnApplicationQuit()
	{
		if (ASE_Tools.Available)
		{
			ASE_Flurry.Stop();
		}
	}

	// Token: 0x06000478 RID: 1144 RVA: 0x000053DC File Offset: 0x000035DC
	public void OnApplicationPause(bool goingPause)
	{
		if (ASE_Tools.Available)
		{
			if (goingPause)
			{
				ASE_Flurry.Stop();
			}
			else
			{
				ASE_Flurry.Init(this.FlurryApiID);
			}
		}
	}

	// Token: 0x06000479 RID: 1145 RVA: 0x00027D1C File Offset: 0x00025F1C
	private void SetupScreen()
	{
		if (SystemInfo.deviceModel == "Amazon KFAPWA" || SystemInfo.deviceModel == "Amazon KFAPWI" || SystemInfo.deviceModel == "Amazon KFTHWA" || SystemInfo.deviceModel == "Amazon KFTHWI" || SystemInfo.deviceModel == "Amazon KFSOWI")
		{
			if (Input.deviceOrientation == DeviceOrientation.LandscapeLeft)
			{
				Screen.orientation = ScreenOrientation.LandscapeRight;
			}
			else if (Input.deviceOrientation == DeviceOrientation.LandscapeRight)
			{
				Screen.orientation = ScreenOrientation.LandscapeLeft;
			}
		}
		else if (Input.deviceOrientation == DeviceOrientation.LandscapeLeft)
		{
			Screen.orientation = ScreenOrientation.LandscapeLeft;
		}
		else if (Input.deviceOrientation == DeviceOrientation.LandscapeRight)
		{
			Screen.orientation = ScreenOrientation.LandscapeRight;
		}
	}

	// Token: 0x04000424 RID: 1060
	public string StartScene = "MenuRoot";

	// Token: 0x04000425 RID: 1061
	private List<InAppProductData> m_pInAppProduct = new List<InAppProductData>();

	// Token: 0x04000426 RID: 1062
	public string ChartBoostAppIDIOS = "YOUR_APP_ID";

	// Token: 0x04000427 RID: 1063
	public string ChartBoostAppSignatureIOS = "YOUR_APP_SIGNATURE";

	// Token: 0x04000428 RID: 1064
	public string ChartBoostAppIDAndroid = "YOUR_APP_ID";

	// Token: 0x04000429 RID: 1065
	public string ChartBoostAppSignatureAndroid = "YOUR_APP_SIGNATURE";

	// Token: 0x0400042A RID: 1066
	public string ChartBoostAppIDAmazon = "YOUR_APP_ID";

	// Token: 0x0400042B RID: 1067
	public string ChartBoostAppSignatureAmazon = "YOUR_APP_SIGNATURE";

	// Token: 0x0400042C RID: 1068
	public string FacebookAppID = "YOUR_FACEBOOK_ID";

	// Token: 0x0400042D RID: 1069
	public string FlurryApiID = "YOUR_FLURRY_API_KEY";

	// Token: 0x0400042E RID: 1070
	private bool m_bDisplayHighlightTutorial;

	// Token: 0x0400042F RID: 1071
	private bool m_bAskForRating;

	// Token: 0x04000430 RID: 1072
	private bool m_bAskForSharing;

	// Token: 0x04000431 RID: 1073
	private bool m_bShowInterstitial;

	// Token: 0x04000432 RID: 1074
	private bool m_bSharingOn;

	// Token: 0x04000433 RID: 1075
	private EntryPoint.eFacebookState m_eFacebookState;

	// Token: 0x04000434 RID: 1076
	private string m_sFacebookTitle;

	// Token: 0x04000435 RID: 1077
	private string m_sFacebookDescription;

	// Token: 0x020000B0 RID: 176
	public enum eFacebookState
	{
		// Token: 0x04000439 RID: 1081
		None,
		// Token: 0x0400043A RID: 1082
		Login,
		// Token: 0x0400043B RID: 1083
		Logged,
		// Token: 0x0400043C RID: 1084
		SharingAsked,
		// Token: 0x0400043D RID: 1085
		PublishAsked
	}
}

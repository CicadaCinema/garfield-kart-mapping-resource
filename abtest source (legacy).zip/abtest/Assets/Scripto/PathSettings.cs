﻿using System;

// Token: 0x020000A8 RID: 168
[Serializable]
public class PathSettings
{
	// Token: 0x040003E5 RID: 997
	public Chance EasyBadPathChance = new Chance(10, 20, 80);

	// Token: 0x040003E6 RID: 998
	public Chance EasyAveragePathChance = new Chance(30, 70, 20);

	// Token: 0x040003E7 RID: 999
	public Chance EasyGoodPathChance = new Chance(60, 10, 0);

	// Token: 0x040003E8 RID: 1000
	public Chance EasyShortcutPathChance = new Chance(60, 10, 0);

	// Token: 0x040003E9 RID: 1001
	public Chance NormalBadPathChance = new Chance(10, 20, 80);

	// Token: 0x040003EA RID: 1002
	public Chance NormalAveragePathChance = new Chance(30, 70, 20);

	// Token: 0x040003EB RID: 1003
	public Chance NormalGoodPathChance = new Chance(60, 10, 0);

	// Token: 0x040003EC RID: 1004
	public Chance NormalShortcutPathChance = new Chance(60, 10, 0);

	// Token: 0x040003ED RID: 1005
	public Chance HardBadPathChance = new Chance(0, 10, 60);

	// Token: 0x040003EE RID: 1006
	public Chance HardAveragePathChance = new Chance(20, 60, 30);

	// Token: 0x040003EF RID: 1007
	public Chance HardGoodPathChance = new Chance(80, 30, 10);

	// Token: 0x040003F0 RID: 1008
	public Chance HardShortcutPathChance = new Chance(80, 30, 10);
}

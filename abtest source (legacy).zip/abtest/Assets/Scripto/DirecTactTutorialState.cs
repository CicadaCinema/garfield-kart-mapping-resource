﻿using System;
using UnityEngine;

// Token: 0x02000181 RID: 385
public class DirecTactTutorialState : IGTutorialState
{
	// Token: 0x06000A37 RID: 2615 RVA: 0x000461FC File Offset: 0x000443FC
	public override void OnEnable()
	{
		Singleton<GameOptionManager>.Instance.SetInputType(E_InputType.Touched, false);
		Singleton<GameManager>.Instance.GameMode.Hud.HUDControls.ShowExceptPause(true);
		base.OnEnable();
		if (this.ControlsAnim)
		{
			this.ControlsAnim.Play();
		}
	}

	// Token: 0x06000A38 RID: 2616 RVA: 0x00009040 File Offset: 0x00007240
	public override void OnDisable()
	{
		if (this.ControlsAnim)
		{
			this.ControlsAnim.Stop();
		}
		base.OnDisable();
	}

	// Token: 0x04000A31 RID: 2609
	public Animation ControlsAnim;
}

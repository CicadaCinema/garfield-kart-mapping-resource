﻿using System;
using UnityEngine;

// Token: 0x0200010E RID: 270
public class HUDFinish : MonoBehaviour
{
	// Token: 0x17000114 RID: 276
	// (get) Token: 0x0600074B RID: 1867 RVA: 0x000072AD File Offset: 0x000054AD
	public bool isDisplaying
	{
		get
		{
			return this.Finish.activeSelf;
		}
	}

	// Token: 0x17000115 RID: 277
	// (get) Token: 0x0600074C RID: 1868 RVA: 0x000072BA File Offset: 0x000054BA
	public float AnimDuration
	{
		get
		{
			return this.Finish.animation.clip.length;
		}
	}

	// Token: 0x17000116 RID: 278
	// (set) Token: 0x0600074D RID: 1869 RVA: 0x000072D1 File Offset: 0x000054D1
	public EndRaceGameState EndState
	{
		set
		{
			this.m_pState = value;
		}
	}

	// Token: 0x0600074E RID: 1870 RVA: 0x000072DA File Offset: 0x000054DA
	public void Awake()
	{
		this.Finish.SetActive(false);
		this.Victory.SetActive(false);
	}

	// Token: 0x0600074F RID: 1871 RVA: 0x000072F4 File Offset: 0x000054F4
	public void FillRank(int _iRank)
	{
		this.m_iRank = _iRank;
	}

	// Token: 0x06000750 RID: 1872 RVA: 0x00036E60 File Offset: 0x00035060
	public void Show()
	{
		this.Finish.SetActive(true);
		this.Victory.SetActive(false);
		this.m_bDelayedHideMessage = true;
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
		{
			this.Message.text = Localization.instance.Get("HUD_SUCCESS");
			this.m_bDelayedHideMessage = false;
		}
		else if (this.m_iRank == 0)
		{
			this.Victory.SetActive(true);
			if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TIME_TRIAL)
			{
				this.Message.text = Localization.instance.Get("HUD_FINISHTIMETRIAL_RECORD");
			}
			else
			{
				this.Message.text = Localization.instance.Get("HUD_FINISHRACE_FINISHFIRST");
			}
		}
		else
		{
			this.Message.text = Localization.instance.Get("HUD_FINISHRACE_FINISH");
		}
	}

	// Token: 0x06000751 RID: 1873 RVA: 0x00036F44 File Offset: 0x00035144
	public void ShowLap(int iLap)
	{
		this.Finish.SetActive(true);
		this.Victory.SetActive(false);
		this.Message.text = Localization.instance.Get("HUD_LAP_" + iLap);
		this.m_bDelayedHideMessage = true;
	}

	// Token: 0x06000752 RID: 1874 RVA: 0x000072FD File Offset: 0x000054FD
	public void Update()
	{
		if (this.m_bDelayedHideMessage)
		{
			this.m_fLabelHideDelay += Time.deltaTime;
			if (this.m_fLabelHideDelay >= this.LabelHideDelay)
			{
				this.Hide();
			}
		}
	}

	// Token: 0x06000753 RID: 1875 RVA: 0x00007333 File Offset: 0x00005533
	public void Hide()
	{
		this.Finish.SetActive(false);
		this.m_fLabelHideDelay = 0f;
		this.m_bDelayedHideMessage = false;
	}

	// Token: 0x06000754 RID: 1876 RVA: 0x00007353 File Offset: 0x00005553
	public void Next()
	{
		if (this.m_pState)
		{
			this.m_pState.Next();
		}
	}

	// Token: 0x04000730 RID: 1840
	public GameObject Finish;

	// Token: 0x04000731 RID: 1841
	public GameObject Victory;

	// Token: 0x04000732 RID: 1842
	public UILabel Message;

	// Token: 0x04000733 RID: 1843
	public float LabelHideDelay = 1f;

	// Token: 0x04000734 RID: 1844
	private int m_iRank;

	// Token: 0x04000735 RID: 1845
	private EndRaceGameState m_pState;

	// Token: 0x04000736 RID: 1846
	private float m_fLabelHideDelay;

	// Token: 0x04000737 RID: 1847
	private bool m_bDelayedHideMessage;
}

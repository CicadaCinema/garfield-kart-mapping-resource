﻿using System;
using UnityEngine;

// Token: 0x02000015 RID: 21
[AddComponentMenu("NGUI/Interaction/Checkbox Controlled Component")]
public class UICheckboxControlledComponent : MonoBehaviour
{
	// Token: 0x06000064 RID: 100 RVA: 0x0000EC08 File Offset: 0x0000CE08
	private void Start()
	{
		UICheckbox component = base.GetComponent<UICheckbox>();
		if (component != null)
		{
			this.mUsingDelegates = true;
			UICheckbox uicheckbox = component;
			uicheckbox.onStateChange = (UICheckbox.OnStateChange)Delegate.Combine(uicheckbox.onStateChange, new UICheckbox.OnStateChange(this.OnActivateDelegate));
		}
	}

	// Token: 0x06000065 RID: 101 RVA: 0x000026BB File Offset: 0x000008BB
	private void OnActivateDelegate(bool isActive)
	{
		if (base.enabled && this.target != null)
		{
			this.target.enabled = ((!this.inverse) ? isActive : (!isActive));
		}
	}

	// Token: 0x06000066 RID: 102 RVA: 0x000026F9 File Offset: 0x000008F9
	private void OnActivate(bool isActive)
	{
		if (!this.mUsingDelegates)
		{
			this.OnActivateDelegate(isActive);
		}
	}

	// Token: 0x0400006D RID: 109
	public MonoBehaviour target;

	// Token: 0x0400006E RID: 110
	public bool inverse;

	// Token: 0x0400006F RID: 111
	private bool mUsingDelegates;
}

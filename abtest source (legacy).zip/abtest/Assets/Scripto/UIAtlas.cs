﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000069 RID: 105
[AddComponentMenu("NGUI/UI/Atlas")]
public class UIAtlas : MonoBehaviour
{
	// Token: 0x17000064 RID: 100
	// (get) Token: 0x060002A4 RID: 676 RVA: 0x00004054 File Offset: 0x00002254
	// (set) Token: 0x060002A5 RID: 677 RVA: 0x0001973C File Offset: 0x0001793C
	public Material spriteMaterial
	{
		get
		{
			return (!(this.mReplacement != null)) ? this.material : this.mReplacement.spriteMaterial;
		}
		set
		{
			if (this.mReplacement != null)
			{
				this.mReplacement.spriteMaterial = value;
			}
			else if (this.material == null)
			{
				this.mPMA = 0;
				this.material = value;
			}
			else
			{
				this.MarkAsDirty();
				this.mPMA = -1;
				this.material = value;
				this.MarkAsDirty();
			}
		}
	}

	// Token: 0x17000065 RID: 101
	// (get) Token: 0x060002A6 RID: 678 RVA: 0x000197AC File Offset: 0x000179AC
	public bool premultipliedAlpha
	{
		get
		{
			if (this.mReplacement != null)
			{
				return this.mReplacement.premultipliedAlpha;
			}
			if (this.mPMA == -1)
			{
				Material spriteMaterial = this.spriteMaterial;
				this.mPMA = ((!(spriteMaterial != null) || !(spriteMaterial.shader != null) || !spriteMaterial.shader.name.Contains("Premultiplied")) ? 0 : 1);
			}
			return this.mPMA == 1;
		}
	}

	// Token: 0x17000066 RID: 102
	// (get) Token: 0x060002A7 RID: 679 RVA: 0x0000407D File Offset: 0x0000227D
	// (set) Token: 0x060002A8 RID: 680 RVA: 0x000040A6 File Offset: 0x000022A6
	public List<UIAtlas.Sprite> spriteList
	{
		get
		{
			return (!(this.mReplacement != null)) ? this.sprites : this.mReplacement.spriteList;
		}
		set
		{
			if (this.mReplacement != null)
			{
				this.mReplacement.spriteList = value;
			}
			else
			{
				this.sprites = value;
			}
		}
	}

	// Token: 0x17000067 RID: 103
	// (get) Token: 0x060002A9 RID: 681 RVA: 0x00019838 File Offset: 0x00017A38
	public Texture texture
	{
		get
		{
			return (!(this.mReplacement != null)) ? ((!(this.material != null)) ? null : this.material.mainTexture) : this.mReplacement.texture;
		}
	}

	// Token: 0x17000068 RID: 104
	// (get) Token: 0x060002AA RID: 682 RVA: 0x000040D1 File Offset: 0x000022D1
	// (set) Token: 0x060002AB RID: 683 RVA: 0x00019888 File Offset: 0x00017A88
	public UIAtlas.Coordinates coordinates
	{
		get
		{
			return (!(this.mReplacement != null)) ? this.mCoordinates : this.mReplacement.coordinates;
		}
		set
		{
			if (this.mReplacement != null)
			{
				this.mReplacement.coordinates = value;
			}
			else if (this.mCoordinates != value)
			{
				if (this.material == null || this.material.mainTexture == null)
				{
					Debug.LogError("Can't switch coordinates until the atlas material has a valid texture");
					return;
				}
				this.mCoordinates = value;
				Texture mainTexture = this.material.mainTexture;
				int i = 0;
				int count = this.sprites.Count;
				while (i < count)
				{
					UIAtlas.Sprite sprite = this.sprites[i];
					if (this.mCoordinates == UIAtlas.Coordinates.TexCoords)
					{
						sprite.outer = NGUIMath.ConvertToTexCoords(sprite.outer, mainTexture.width, mainTexture.height);
						sprite.inner = NGUIMath.ConvertToTexCoords(sprite.inner, mainTexture.width, mainTexture.height);
					}
					else
					{
						sprite.outer = NGUIMath.ConvertToPixels(sprite.outer, mainTexture.width, mainTexture.height, true);
						sprite.inner = NGUIMath.ConvertToPixels(sprite.inner, mainTexture.width, mainTexture.height, true);
					}
					i++;
				}
			}
		}
	}

	// Token: 0x17000069 RID: 105
	// (get) Token: 0x060002AC RID: 684 RVA: 0x000040FA File Offset: 0x000022FA
	// (set) Token: 0x060002AD RID: 685 RVA: 0x000199BC File Offset: 0x00017BBC
	public float pixelSize
	{
		get
		{
			return (!(this.mReplacement != null)) ? this.mPixelSize : this.mReplacement.pixelSize;
		}
		set
		{
			if (this.mReplacement != null)
			{
				this.mReplacement.pixelSize = value;
			}
			else
			{
				float num = Mathf.Clamp(value, 0.25f, 4f);
				if (this.mPixelSize != num)
				{
					this.mPixelSize = num;
					this.MarkAsDirty();
				}
			}
		}
	}

	// Token: 0x1700006A RID: 106
	// (get) Token: 0x060002AE RID: 686 RVA: 0x00004123 File Offset: 0x00002323
	// (set) Token: 0x060002AF RID: 687 RVA: 0x00019A18 File Offset: 0x00017C18
	public UIAtlas replacement
	{
		get
		{
			return this.mReplacement;
		}
		set
		{
			UIAtlas uiatlas = value;
			if (uiatlas == this)
			{
				uiatlas = null;
			}
			if (this.mReplacement != uiatlas)
			{
				if (uiatlas != null && uiatlas.replacement == this)
				{
					uiatlas.replacement = null;
				}
				if (this.mReplacement != null)
				{
					this.MarkAsDirty();
				}
				this.mReplacement = uiatlas;
				this.MarkAsDirty();
			}
		}
	}

	// Token: 0x060002B0 RID: 688 RVA: 0x00019A90 File Offset: 0x00017C90
	public UIAtlas.Sprite GetSprite(string name)
	{
		if (this.mReplacement != null)
		{
			return this.mReplacement.GetSprite(name);
		}
		if (!string.IsNullOrEmpty(name))
		{
			int i = 0;
			int count = this.sprites.Count;
			while (i < count)
			{
				UIAtlas.Sprite sprite = this.sprites[i];
				if (!string.IsNullOrEmpty(sprite.name) && name == sprite.name)
				{
					return sprite;
				}
				i++;
			}
		}
		return null;
	}

	// Token: 0x060002B1 RID: 689 RVA: 0x0000412B File Offset: 0x0000232B
	private static int CompareString(string a, string b)
	{
		return a.CompareTo(b);
	}

	// Token: 0x060002B2 RID: 690 RVA: 0x00019B18 File Offset: 0x00017D18
	public BetterList<string> GetListOfSprites()
	{
		if (this.mReplacement != null)
		{
			return this.mReplacement.GetListOfSprites();
		}
		BetterList<string> betterList = new BetterList<string>();
		int i = 0;
		int count = this.sprites.Count;
		while (i < count)
		{
			UIAtlas.Sprite sprite = this.sprites[i];
			if (sprite != null && !string.IsNullOrEmpty(sprite.name))
			{
				betterList.Add(sprite.name);
			}
			i++;
		}
		return betterList;
	}

	// Token: 0x060002B3 RID: 691 RVA: 0x00019B98 File Offset: 0x00017D98
	public BetterList<string> GetListOfSprites(string match)
	{
		if (this.mReplacement != null)
		{
			return this.mReplacement.GetListOfSprites(match);
		}
		if (string.IsNullOrEmpty(match))
		{
			return this.GetListOfSprites();
		}
		BetterList<string> betterList = new BetterList<string>();
		int i = 0;
		int count = this.sprites.Count;
		while (i < count)
		{
			UIAtlas.Sprite sprite = this.sprites[i];
			if (sprite != null && !string.IsNullOrEmpty(sprite.name) && string.Equals(match, sprite.name, StringComparison.OrdinalIgnoreCase))
			{
				betterList.Add(sprite.name);
				return betterList;
			}
			i++;
		}
		string[] array = match.Split(new char[]
		{
			' '
		}, StringSplitOptions.RemoveEmptyEntries);
		for (int j = 0; j < array.Length; j++)
		{
			array[j] = array[j].ToLower();
		}
		int k = 0;
		int count2 = this.sprites.Count;
		while (k < count2)
		{
			UIAtlas.Sprite sprite2 = this.sprites[k];
			if (sprite2 != null && !string.IsNullOrEmpty(sprite2.name))
			{
				string text = sprite2.name.ToLower();
				int num = 0;
				for (int l = 0; l < array.Length; l++)
				{
					if (text.Contains(array[l]))
					{
						num++;
					}
				}
				if (num == array.Length)
				{
					betterList.Add(sprite2.name);
				}
			}
			k++;
		}
		return betterList;
	}

	// Token: 0x060002B4 RID: 692 RVA: 0x00019D20 File Offset: 0x00017F20
	private bool References(UIAtlas atlas)
	{
		return !(atlas == null) && (atlas == this || (this.mReplacement != null && this.mReplacement.References(atlas)));
	}

	// Token: 0x060002B5 RID: 693 RVA: 0x00004134 File Offset: 0x00002334
	public static bool CheckIfRelated(UIAtlas a, UIAtlas b)
	{
		return !(a == null) && !(b == null) && (a == b || a.References(b) || b.References(a));
	}

	// Token: 0x060002B6 RID: 694 RVA: 0x00019D6C File Offset: 0x00017F6C
	public void MarkAsDirty()
	{
		if (this.mReplacement != null)
		{
			this.mReplacement.MarkAsDirty();
		}
		UISprite[] array = NGUITools.FindActive<UISprite>();
		int i = 0;
		int num = array.Length;
		while (i < num)
		{
			UISprite uisprite = array[i];
			if (UIAtlas.CheckIfRelated(this, uisprite.atlas))
			{
				UIAtlas atlas = uisprite.atlas;
				uisprite.atlas = null;
				uisprite.atlas = atlas;
			}
			i++;
		}
		UIFont[] array2 = Resources.FindObjectsOfTypeAll(typeof(UIFont)) as UIFont[];
		int j = 0;
		int num2 = array2.Length;
		while (j < num2)
		{
			UIFont uifont = array2[j];
			if (UIAtlas.CheckIfRelated(this, uifont.atlas))
			{
				UIAtlas atlas2 = uifont.atlas;
				uifont.atlas = null;
				uifont.atlas = atlas2;
			}
			j++;
		}
		UILabel[] array3 = NGUITools.FindActive<UILabel>();
		int k = 0;
		int num3 = array3.Length;
		while (k < num3)
		{
			UILabel uilabel = array3[k];
			if (uilabel.font != null && UIAtlas.CheckIfRelated(this, uilabel.font.atlas))
			{
				UIFont font = uilabel.font;
				uilabel.font = null;
				uilabel.font = font;
			}
			k++;
		}
	}

	// Token: 0x0400023B RID: 571
	[HideInInspector]
	[SerializeField]
	private Material material;

	// Token: 0x0400023C RID: 572
	[HideInInspector]
	[SerializeField]
	private List<UIAtlas.Sprite> sprites = new List<UIAtlas.Sprite>();

	// Token: 0x0400023D RID: 573
	[SerializeField]
	[HideInInspector]
	private UIAtlas.Coordinates mCoordinates;

	// Token: 0x0400023E RID: 574
	[SerializeField]
	[HideInInspector]
	private float mPixelSize = 1f;

	// Token: 0x0400023F RID: 575
	[HideInInspector]
	[SerializeField]
	private UIAtlas mReplacement;

	// Token: 0x04000240 RID: 576
	private int mPMA = -1;

	// Token: 0x0200006A RID: 106
	[Serializable]
	public class Sprite
	{
		// Token: 0x1700006B RID: 107
		// (get) Token: 0x060002B8 RID: 696 RVA: 0x00019F10 File Offset: 0x00018110
		public bool hasPadding
		{
			get
			{
				return this.paddingLeft != 0f || this.paddingRight != 0f || this.paddingTop != 0f || this.paddingBottom != 0f;
			}
		}

		// Token: 0x04000241 RID: 577
		public string name = "Unity Bug";

		// Token: 0x04000242 RID: 578
		public Rect outer = new Rect(0f, 0f, 1f, 1f);

		// Token: 0x04000243 RID: 579
		public Rect inner = new Rect(0f, 0f, 1f, 1f);

		// Token: 0x04000244 RID: 580
		public bool rotated;

		// Token: 0x04000245 RID: 581
		public float paddingLeft;

		// Token: 0x04000246 RID: 582
		public float paddingRight;

		// Token: 0x04000247 RID: 583
		public float paddingTop;

		// Token: 0x04000248 RID: 584
		public float paddingBottom;
	}

	// Token: 0x0200006B RID: 107
	public enum Coordinates
	{
		// Token: 0x0400024A RID: 586
		Pixels,
		// Token: 0x0400024B RID: 587
		TexCoords
	}
}

﻿using System;
using UnityEngine;

// Token: 0x02000105 RID: 261
public class HUDControls : MonoBehaviour
{
	// Token: 0x06000715 RID: 1813 RVA: 0x000356B0 File Offset: 0x000338B0
	public void Awake()
	{
		this.m_pSteerLeft = null;
		this.m_pSteerRight = null;
		this.m_pBrake = null;
		this.m_pDrift = null;
		this.m_pPause = null;
		this.m_pSteerLeft = GameObject.Find("SteerLeft");
		this.m_pSteerRight = GameObject.Find("SteerRight");
		this.m_pBrake = GameObject.Find("Brake");
		this.m_pDrift = GameObject.Find("Drift");
		this.m_pPause = GameObject.Find("Pause");
	}

	// Token: 0x06000716 RID: 1814 RVA: 0x000070BE File Offset: 0x000052BE
	public void Start()
	{
		this.StartGame();
	}

	// Token: 0x06000717 RID: 1815 RVA: 0x000070C6 File Offset: 0x000052C6
	public void StartGame()
	{
		this.ShowExceptPause(false);
	}

	// Token: 0x06000718 RID: 1816 RVA: 0x000070CF File Offset: 0x000052CF
	public void StartRace()
	{
		this.ShowExceptPause(true);
	}

	// Token: 0x06000719 RID: 1817 RVA: 0x000070D8 File Offset: 0x000052D8
	public void Pause(bool _Pause)
	{
		this.ShowAll(!_Pause);
	}

	// Token: 0x0600071A RID: 1818 RVA: 0x00035730 File Offset: 0x00033930
	public void ShowExceptPause(bool _Show)
	{
		this.m_pSteerLeft.SetActive(_Show);
		this.m_pSteerRight.SetActive(_Show);
		if (_Show && Singleton<GameOptionManager>.Instance.GetInputType() == E_InputType.Gyroscopic)
		{
			this.m_pSteerLeft.gameObject.SetActive(false);
			this.m_pSteerRight.gameObject.SetActive(false);
		}
		this.m_pBrake.SetActive(_Show);
		this.m_pDrift.SetActive(_Show);
	}

	// Token: 0x0600071B RID: 1819 RVA: 0x000070E4 File Offset: 0x000052E4
	public void ShowAll(bool _Show)
	{
		this.ShowExceptPause(_Show);
		this.m_pPause.SetActive(_Show);
	}

	// Token: 0x0600071C RID: 1820 RVA: 0x000357A8 File Offset: 0x000339A8
	public void OnAction(EInputAction _Action)
	{
		switch (_Action)
		{
		case EInputAction.SteerLeft:
			Singleton<InputManager>.Instance.NullSafeAct(new Action<EAction, float>(Singleton<InputManager>.Instance.SetAction), EAction.Steer, -1f);
			break;
		case EInputAction.SteerRight:
			Singleton<InputManager>.Instance.NullSafeAct(new Action<EAction, float>(Singleton<InputManager>.Instance.SetAction), EAction.Steer, 1f);
			break;
		case EInputAction.Brake:
			Singleton<InputManager>.Instance.NullSafeAct(new Action<EAction, float>(Singleton<InputManager>.Instance.SetAction), EAction.Accelerate, -1f);
			break;
		case EInputAction.Drift:
			Singleton<InputManager>.Instance.NullSafeAct(new Action<EAction, float>(Singleton<InputManager>.Instance.SetAction), EAction.Drift, 1f);
			break;
		}
	}

	// Token: 0x0600071D RID: 1821 RVA: 0x000070F9 File Offset: 0x000052F9
	public void OnRespawn()
	{
		Singleton<InputManager>.Instance.NullSafeAct(new Action<EAction, float>(Singleton<InputManager>.Instance.SetAction), EAction.Respawn, 1f);
	}

	// Token: 0x0600071E RID: 1822 RVA: 0x0000711B File Offset: 0x0000531B
	public void OnQuit()
	{
		LoadingManager.LoadLevel("MenuRoot");
	}

	// Token: 0x0600071F RID: 1823 RVA: 0x00007127 File Offset: 0x00005327
	public void OnLaunchBonus()
	{
		Singleton<InputManager>.Instance.NullSafeAct(new Action<EAction, float>(Singleton<InputManager>.Instance.SetAction), EAction.LaunchBonus, 1f);
	}

	// Token: 0x06000720 RID: 1824 RVA: 0x00007149 File Offset: 0x00005349
	public void OnDrift()
	{
		Singleton<InputManager>.Instance.NullSafeAct(new Action<EAction, float>(Singleton<InputManager>.Instance.SetAction), EAction.DriftJump, 1f);
	}

	// Token: 0x06000721 RID: 1825 RVA: 0x0000716B File Offset: 0x0000536B
	public void OnPause()
	{
		Singleton<InputManager>.Instance.NullSafeAct(new Action<EAction, float>(Singleton<InputManager>.Instance.SetAction), EAction.Pause, 1f);
	}

	// Token: 0x040006FC RID: 1788
	private GameObject m_pSteerLeft;

	// Token: 0x040006FD RID: 1789
	private GameObject m_pSteerRight;

	// Token: 0x040006FE RID: 1790
	private GameObject m_pBrake;

	// Token: 0x040006FF RID: 1791
	private GameObject m_pDrift;

	// Token: 0x04000700 RID: 1792
	private GameObject m_pPause;
}

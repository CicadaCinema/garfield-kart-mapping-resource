﻿using System;
using UnityEngine;

// Token: 0x0200021C RID: 540
public class RcRespawnChecker : MonoBehaviour
{
	// Token: 0x06000EFD RID: 3837 RVA: 0x0000C4D9 File Offset: 0x0000A6D9
	public RcRespawnChecker()
	{
		this.m_bKillingCollOn = true;
		this.m_bUnderwaterKillOn = true;
		this.m_bUpsideDownKillOn = true;
		this.m_bHyperspaceKillOn = true;
		this.m_fHyperspaceHeight = 1000f;
		this.m_fSeaLevel = -100f;
	}

	// Token: 0x06000EFE RID: 3838 RVA: 0x00003B80 File Offset: 0x00001D80
	public void Awake()
	{
	}

	// Token: 0x06000EFF RID: 3839 RVA: 0x0000C513 File Offset: 0x0000A713
	public void Start()
	{
		this.m_pVehicles = (RcVehicle[])UnityEngine.Object.FindObjectsOfType(typeof(RcVehicle));
	}

	// Token: 0x06000F00 RID: 3840 RVA: 0x0005E4D0 File Offset: 0x0005C6D0
	public void Update()
	{
		for (int i = 0; i < this.m_pVehicles.Length; i++)
		{
			float respawnDelay;
			if (this.m_pVehicles[i] != null && this.m_pVehicles[i].GetState(RcVehicle.eVehicleState.S_IS_RUNNING) && !this.m_pVehicles[i].GetState(RcVehicle.eVehicleState.S_IS_TELEPORTING) && !this.m_pVehicles[i].IsLocked() && this.CheckRespawn(this.m_pVehicles[i], out respawnDelay))
			{
				this.m_pVehicles[i].Kill(respawnDelay);
			}
		}
	}

	// Token: 0x06000F01 RID: 3841 RVA: 0x0005E564 File Offset: 0x0005C764
	public bool CheckRespawn(RcVehicle pVehicle, out float respawnDelay)
	{
		respawnDelay = 1.5f;
		if (this.m_bKillingCollOn && pVehicle.GetVehiclePhysic().BTouchedDeath)
		{
			respawnDelay = pVehicle.GetVehiclePhysic().FDeathDelay;
			if (pVehicle.GetControlType() == RcVehicle.ControlType.Human)
			{
				Camera.mainCamera.GetComponent<CameraBase>().SwitchCamera(ECamState.Kill, ECamState.TransCut);
			}
			return true;
		}
		return !pVehicle.GetVehiclePhysic().GetVehicleBody().isKinematic && ((this.m_bUpsideDownKillOn && Vector3.Dot(pVehicle.GetOrientation() * Vector3.up, Vector3.up) < 0.0871f && !pVehicle.IsOnGround()) || (this.m_bUnderwaterKillOn && Vector3.Dot(pVehicle.GetPosition(), Vector3.up) < this.m_fSeaLevel) || (this.m_bHyperspaceKillOn && Vector3.Dot(pVehicle.GetPosition(), Vector3.up) > this.m_fHyperspaceHeight));
	}

	// Token: 0x04000E7C RID: 3708
	private const float COS_85 = 0.0871f;

	// Token: 0x04000E7D RID: 3709
	private RcVehicle[] m_pVehicles;

	// Token: 0x04000E7E RID: 3710
	public bool m_bKillingCollOn;

	// Token: 0x04000E7F RID: 3711
	public bool m_bUnderwaterKillOn;

	// Token: 0x04000E80 RID: 3712
	public bool m_bUpsideDownKillOn;

	// Token: 0x04000E81 RID: 3713
	public bool m_bHyperspaceKillOn;

	// Token: 0x04000E82 RID: 3714
	public float m_fHyperspaceHeight;

	// Token: 0x04000E83 RID: 3715
	public float m_fSeaLevel;
}

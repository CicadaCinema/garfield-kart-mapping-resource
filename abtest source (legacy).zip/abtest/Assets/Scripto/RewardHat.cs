﻿using System;

// Token: 0x02000162 RID: 354
[Serializable]
public class RewardHat : RewardRandomBase
{
	// Token: 0x06000999 RID: 2457 RVA: 0x00043638 File Offset: 0x00041838
	protected override void GetReward()
	{
		if (this.State == E_UnlockableItemSate.NewLocked && Singleton<GameSaveManager>.Instance.GetHatState(this.Items[0]) == E_UnlockableItemSate.Hidden)
		{
			foreach (string pHat in this.Items)
			{
				Singleton<RewardManager>.Instance.ShowHat(pHat);
			}
		}
		else if (this.State == E_UnlockableItemSate.NewUnlocked)
		{
			for (int i = 0; i < this.Items.Count; i++)
			{
				Singleton<RewardManager>.Instance.UnlockHat(this.Items[i], this.Rarities[i]);
			}
		}
	}
}

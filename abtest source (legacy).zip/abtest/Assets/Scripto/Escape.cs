﻿using System;
using UnityEngine;

// Token: 0x02000091 RID: 145
public class Escape : MonoBehaviour
{
	// Token: 0x060003FA RID: 1018 RVA: 0x00004F9B File Offset: 0x0000319B
	public void Update()
	{
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			Application.Quit();
		}
	}
}

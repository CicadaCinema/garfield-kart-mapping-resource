﻿using System;
using UnityEngine;

// Token: 0x020001F6 RID: 502
public class RcHumanController : RcController
{
	// Token: 0x06000D8B RID: 3467 RVA: 0x00057D44 File Offset: 0x00055F44
	public RcHumanController()
	{
		this.m_pAutopilotController = null;
		this.m_bPreviousOnGround = false;
		this.m_fTakeOffSteer = 0f;
		this.m_fPrevDriftInput = 0f;
		this.m_pGyroscope = null;
		this.m_bAccelerometer = false;
	}

	// Token: 0x170001D4 RID: 468
	// (get) Token: 0x06000D8C RID: 3468 RVA: 0x0000B40E File Offset: 0x0000960E
	public int LogBrake
	{
		get
		{
			return this.m_iLogBrake;
		}
	}

	// Token: 0x06000D8D RID: 3469 RVA: 0x0000B416 File Offset: 0x00009616
	public override float GetSteer()
	{
		return -this.Steer();
	}

	// Token: 0x06000D8E RID: 3470 RVA: 0x0000B41F File Offset: 0x0000961F
	public override float GetSpeedBehaviour()
	{
		return this.Accelerate();
	}

	// Token: 0x06000D8F RID: 3471 RVA: 0x0000B427 File Offset: 0x00009627
	public void SetMirrorMode(bool _mirror)
	{
		this.m_bMirrorMode = _mirror;
	}

	// Token: 0x06000D90 RID: 3472 RVA: 0x0000B430 File Offset: 0x00009630
	public RcVirtualController GetAutopilot()
	{
		return this.m_pAutopilotController;
	}

	// Token: 0x06000D91 RID: 3473 RVA: 0x00057DCC File Offset: 0x00055FCC
	public virtual void Start()
	{
		this.m_pAutopilotController = base.transform.parent.GetComponentInChildren<RcVirtualController>();
		if (this.m_pAutopilotController != null)
		{
			this.m_pAutopilotController.SetDrivingEnabled(this.m_pVehicle.GetControlType() == RcVehicle.ControlType.AI);
		}
		RcVehicle pVehicle = this.m_pVehicle;
		pVehicle.OnRaceEnded = (Action<RcVehicle>)Delegate.Combine(pVehicle.OnRaceEnded, new Action<RcVehicle>(this.RaceEnd));
		if (SystemInfo.supportsGyroscope)
		{
			this.m_pGyroscope = Input.gyro;
			this.m_pGyroscope.enabled = true;
			this.RadianThreshold = 3.14159274f * this.DegreeThresholdGyroMax / 180f;
			this.m_fLastGyroValue = 0f;
		}
		else if (SystemInfo.supportsAccelerometer)
		{
			this.m_bAccelerometer = true;
		}
	}

	// Token: 0x06000D92 RID: 3474 RVA: 0x0000B438 File Offset: 0x00009638
	public virtual void Stop()
	{
		RcVehicle pVehicle = this.m_pVehicle;
		pVehicle.OnRaceEnded = (Action<RcVehicle>)Delegate.Remove(pVehicle.OnRaceEnded, new Action<RcVehicle>(this.RaceEnd));
	}

	// Token: 0x06000D93 RID: 3475 RVA: 0x0000B461 File Offset: 0x00009661
	public override void Reset()
	{
		base.Reset();
		if (this.m_pAutopilotController)
		{
			this.m_pAutopilotController.Reset();
		}
	}

	// Token: 0x06000D94 RID: 3476 RVA: 0x00057E9C File Offset: 0x0005609C
	public virtual void FixedUpdate()
	{
		if (base.GetVehicle().GetControlType() != RcVehicle.ControlType.Human)
		{
			return;
		}
		if (base.GetVehicle().IsAutoPilot())
		{
			return;
		}
		if (this.m_bDrivingEnabled)
		{
			float num = 0f;
			if (base.GetVehicle().IsOnGround())
			{
				num = this.Accelerate();
			}
			float num2 = this.Steer();
			if (!base.GetVehicle().IsOnGround() && this.m_bPreviousOnGround)
			{
				this.m_fTakeOffSteer = num2;
			}
			if (num2 > 0f)
			{
				num2 *= num2;
			}
			else
			{
				num2 = -num2 * num2;
			}
			if (num > 0.1f)
			{
				base.GetVehicle().Accelerate(num);
				if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
				{
					(Singleton<GameManager>.Instance.GameMode as TutorialGameMode).Accelerate();
				}
				if (LogManager.Instance != null)
				{
					this.m_bLogBrake = false;
				}
			}
			else if (num < -0.1f)
			{
				base.GetVehicle().Brake(-num);
				if (LogManager.Instance != null && !this.m_bLogBrake)
				{
					this.m_iLogBrake++;
					this.m_bLogBrake = true;
				}
				if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
				{
					(Singleton<GameManager>.Instance.GameMode as TutorialGameMode).Brake();
				}
			}
			else
			{
				base.GetVehicle().Decelerate();
			}
			this.Turn(num2);
			float action = Singleton<InputManager>.Instance.GetAction(EAction.Drift);
			if (action > 0f && this.m_fPrevDriftInput == 0f)
			{
				if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
				{
					(Singleton<GameManager>.Instance.GameMode as TutorialGameMode).DriftAttempt();
				}
				base.GetVehicle().BArcadeDriftLock = false;
			}
			this.m_fPrevDriftInput = action;
			if (action == 1f && num >= 0f && !base.GetVehicle().BArcadeDriftLock && base.GetVehicle().GetWheelSpeedMS() * 3.6f > base.GetVehicle().m_fDriftMinSpeedKph)
			{
				if (base.GetVehicle().IsOnGround() && base.GetVehicle().GetArcadeDriftFactor() == 0f && !this.m_bPreviousOnGround)
				{
					if (num2 > 0f)
					{
						base.GetVehicle().SetArcadeDriftFactor(1f);
					}
					else if (num2 < 0f)
					{
						base.GetVehicle().SetArcadeDriftFactor(-1f);
					}
					else if (this.m_fTakeOffSteer > 0f)
					{
						base.GetVehicle().SetArcadeDriftFactor(1f);
					}
					else if (this.m_fTakeOffSteer < 0f)
					{
						base.GetVehicle().SetArcadeDriftFactor(-1f);
					}
					else
					{
						base.GetVehicle().SetArcadeDriftFactor(0f);
					}
				}
			}
			else
			{
				base.GetVehicle().SetArcadeDriftFactor(0f);
			}
			if (Singleton<InputManager>.Instance.GetAction(EAction.Respawn) == 1f)
			{
				base.GetVehicle().ForceRespawn();
			}
		}
		this.m_bPreviousOnGround = base.GetVehicle().IsOnGround();
	}

	// Token: 0x06000D95 RID: 3477 RVA: 0x0000B484 File Offset: 0x00009684
	public virtual void Turn(float _Steer)
	{
		base.GetVehicle().Turn(-_Steer, 0f == _Steer);
	}

	// Token: 0x06000D96 RID: 3478 RVA: 0x0000B49B File Offset: 0x0000969B
	public void SetAutopilotEnabled(bool _enabled)
	{
		this.SetDrivingEnabled(!_enabled);
		if (this.m_pAutopilotController)
		{
			this.m_pAutopilotController.SetDrivingEnabled(_enabled);
		}
	}

	// Token: 0x06000D97 RID: 3479 RVA: 0x0000B4C3 File Offset: 0x000096C3
	public override void SetVehicle(RcVehicle _pVehicle)
	{
		base.SetVehicle(_pVehicle);
		if (this.m_pAutopilotController)
		{
			this.m_pAutopilotController.SetVehicle(_pVehicle);
		}
	}

	// Token: 0x06000D98 RID: 3480 RVA: 0x000581C0 File Offset: 0x000563C0
	public float Accelerate()
	{
		if (Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
		{
			return Singleton<InputManager>.Instance.GetAction(EAction.Accelerate);
		}
		float action = Singleton<InputManager>.Instance.GetAction(EAction.Accelerate);
		if (action != -1f)
		{
			return 1f;
		}
		return action;
	}

	// Token: 0x06000D99 RID: 3481 RVA: 0x00058210 File Offset: 0x00056410
	public float Steer()
	{
		float num4;
		if (this.m_pGyroscope != null && Singleton<GameOptionManager>.Instance.GetInputType() == E_InputType.Gyroscopic)
		{
			float gyroSensibility = Singleton<GameOptionManager>.Instance.GetGyroSensibility();
			float num = this.DegreeThresholdGyroMin + (1f - gyroSensibility) * (this.DegreeThresholdGyroMax - this.DegreeThresholdGyroMin);
			this.RadianThreshold = 3.14159274f * num / 180f;
			Quaternion attitude = this.m_pGyroscope.attitude;
			float num2 = Mathf.Asin(2f * (attitude.x * attitude.z - attitude.w * attitude.y));
			if (this.m_fLastGyroValue == 0f)
			{
				this.m_fLastGyroValue = num2;
			}
			float num3 = this.m_fLastGyroValue;
			this.EstimatedError += this.ProcessNoise;
			this.KalmanFilterGain = this.EstimatedError / (this.EstimatedError + this.SensorNoise);
			num3 += this.KalmanFilterGain * (num2 - num3);
			this.EstimatedError = (1f - this.KalmanFilterGain) * this.EstimatedError;
			this.m_fLastGyroValue = num3;
			num3 = Mathf.Clamp(num3, -this.RadianThreshold, this.RadianThreshold) / this.RadianThreshold;
			num4 = -num3;
		}
		else if (Singleton<GameOptionManager>.Instance.GetInputType() == E_InputType.Gyroscopic && this.m_bAccelerometer)
		{
			float num5 = 2f * Mathf.Max(0.3f, Singleton<GameOptionManager>.Instance.GetGyroSensibility());
			num4 = Input.acceleration.x * num5;
		}
		else
		{
			num4 = Singleton<InputManager>.Instance.GetAction(EAction.Steer);
		}
		if (this.m_bMirrorMode)
		{
			return -num4;
		}
		if (Singleton<GameConfigurator>.Instance.GameModeType == E_GameModeType.TUTORIAL)
		{
			(Singleton<GameManager>.Instance.GameMode as TutorialGameMode).Direction(num4);
		}
		return num4;
	}

	// Token: 0x06000D9A RID: 3482 RVA: 0x0000B4E8 File Offset: 0x000096E8
	public void SetInputIndex(int _inputIndex)
	{
		this.m_iInputIndex = _inputIndex;
	}

	// Token: 0x06000D9B RID: 3483 RVA: 0x0000B4F1 File Offset: 0x000096F1
	public void RaceEnd(RcVehicle pVehicle)
	{
		if (base.GetVehicle().GetControlType() == RcVehicle.ControlType.Human)
		{
			base.GetVehicle().SetArcadeDriftFactor(0f);
			this.SetAutopilotEnabled(true);
		}
	}

	// Token: 0x04000D2E RID: 3374
	protected int m_iInputIndex;

	// Token: 0x04000D2F RID: 3375
	protected bool m_bMirrorMode;

	// Token: 0x04000D30 RID: 3376
	protected bool m_bPreviousOnGround;

	// Token: 0x04000D31 RID: 3377
	private RcVirtualController m_pAutopilotController;

	// Token: 0x04000D32 RID: 3378
	protected float m_fTakeOffSteer;

	// Token: 0x04000D33 RID: 3379
	protected float m_fPrevDriftInput;

	// Token: 0x04000D34 RID: 3380
	protected Gyroscope m_pGyroscope;

	// Token: 0x04000D35 RID: 3381
	protected bool m_bAccelerometer;

	// Token: 0x04000D36 RID: 3382
	public float DegreeThresholdGyroMin = 15f;

	// Token: 0x04000D37 RID: 3383
	public float DegreeThresholdGyroMax = 35f;

	// Token: 0x04000D38 RID: 3384
	private float RadianThreshold;

	// Token: 0x04000D39 RID: 3385
	private float m_fLastGyroValue;

	// Token: 0x04000D3A RID: 3386
	public float ProcessNoise = 0.1f;

	// Token: 0x04000D3B RID: 3387
	public float SensorNoise = 0.05f;

	// Token: 0x04000D3C RID: 3388
	public float EstimatedError = 0.1f;

	// Token: 0x04000D3D RID: 3389
	public float KalmanFilterGain = 0.5f;

	// Token: 0x04000D3E RID: 3390
	private int m_iLogBrake;

	// Token: 0x04000D3F RID: 3391
	private bool m_bLogBrake;
}

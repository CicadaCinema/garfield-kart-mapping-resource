﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000117 RID: 279
public class HUDRadar : MonoBehaviour
{
	// Token: 0x060007B5 RID: 1973 RVA: 0x000399A4 File Offset: 0x00037BA4
	public void Start()
	{
		foreach (UISprite uisprite in this.CharacterSprites)
		{
			uisprite.enabled = false;
		}
		foreach (UISprite uisprite2 in this.Pies)
		{
			uisprite2.enabled = false;
		}
		foreach (UISprite uisprite3 in this.AutolockPies)
		{
			uisprite3.enabled = false;
		}
		foreach (GameObject gameObject in this.Results)
		{
			gameObject.SetActive(false);
		}
		this.Ufo.enabled = false;
		UpsideDownBonusEffect.OnLaunch = (Action<int>)Delegate.Combine(UpsideDownBonusEffect.OnLaunch, new Action<int>(this.LaunchAnim));
		SpinBonusEffect.OnLaunch = (Action<int>)Delegate.Combine(SpinBonusEffect.OnLaunch, new Action<int>(this.LaunchAnim));
		GameObject gameObject2 = GameObject.Find("RadarRef");
		this.m_fPosXLimit = gameObject2.transform.parent.localPosition.x + gameObject2.transform.localPosition.x;
		this.vProgressionBarTranform = this.ProgressionBar.transform;
	}

	// Token: 0x060007B6 RID: 1974 RVA: 0x00039B64 File Offset: 0x00037D64
	public void OnDestroy()
	{
		UpsideDownBonusEffect.OnLaunch = (Action<int>)Delegate.Remove(UpsideDownBonusEffect.OnLaunch, new Action<int>(this.LaunchAnim));
		SpinBonusEffect.OnLaunch = (Action<int>)Delegate.Remove(SpinBonusEffect.OnLaunch, new Action<int>(this.LaunchAnim));
	}

	// Token: 0x060007B7 RID: 1975 RVA: 0x00007788 File Offset: 0x00005988
	private void LaunchAnim(int pIndex)
	{
		this.CharacterMiniMap[pIndex].animation.Play();
		this.CharacterSprites[pIndex].animation.Play();
	}

	// Token: 0x060007B8 RID: 1976 RVA: 0x00039BB4 File Offset: 0x00037DB4
	public void StartRace()
	{
		GameObject gameObject = GameObject.Find("SplineRespawn");
		this._idealPath = null;
		if (gameObject != null)
		{
			this._idealPath = gameObject.GetComponent<RcMultiPath>();
			this._raceLength = this._idealPath.TotalLength;
		}
		this._vehicles = new List<Tuple<GameObject, int, Renderer, RcVehicleRaceStats>>();
		this._playerIndex = Singleton<GameManager>.Instance.GameMode.GetHumanPlayerVehicleId();
		PlayerData[] playerDataList = Singleton<GameConfigurator>.Instance.PlayerDataList;
		for (int i = 0; i < 6; i++)
		{
			GameObject playerWithVehicleId = Singleton<GameManager>.Instance.GameMode.GetPlayerWithVehicleId(i);
			Kart kartWithVehicleId = Singleton<GameManager>.Instance.GameMode.GetKartWithVehicleId(i);
			if (playerWithVehicleId != null && kartWithVehicleId != null)
			{
				int vehicleId = kartWithVehicleId.GetVehicleId();
				Kart kart = kartWithVehicleId;
				kart.OnRaceEnded = (Action<RcVehicle>)Delegate.Combine(kart.OnRaceEnded, new Action<RcVehicle>(this.RaceEnd));
				ECharacter owner = playerWithVehicleId.GetComponentInChildren<CharacterCarac>().Owner;
				this._vehicles.Add(new Tuple<GameObject, int, Renderer, RcVehicleRaceStats>(playerWithVehicleId, vehicleId, playerWithVehicleId.GetComponentInChildren<SkinnedMeshRenderer>(), playerWithVehicleId.GetComponentInChildren<RcVehicleRaceStats>()));
				this.vVehicleTransforms[vehicleId] = playerWithVehicleId.transform;
				this.CharacterMiniMap[vehicleId].enabled = true;
				this.CharacterMiniMap[vehicleId].GetComponent<UITexturePattern>().ChangeTexture((int)owner);
				this.CharacterSprites[vehicleId].GetComponent<UITexturePattern>().ChangeTexture((int)owner);
				this._characters[vehicleId] = (int)owner;
				if (Network.peerType != NetworkPeerType.Disconnected)
				{
					if (vehicleId == this._playerIndex)
					{
						this.SelectorMiniMap[this._playerIndex].enabled = true;
					}
					else
					{
						RaceScoreData scoreData = Singleton<GameConfigurator>.Instance.RankingManager.GetScoreData(vehicleId);
						if (scoreData != null)
						{
							this.SelectorMiniMap[vehicleId].enabled = !scoreData.IsAI;
						}
						else
						{
							this.SelectorMiniMap[vehicleId].enabled = false;
						}
					}
					if (playerDataList[vehicleId] != null)
					{
						this.SelectorMiniMap[vehicleId].color = playerDataList[vehicleId].CharacColor;
					}
				}
				else
				{
					this.SelectorMiniMap[vehicleId].enabled = false;
				}
				if (vehicleId == this._playerIndex)
				{
					this.CharacterMiniMap[this._playerIndex].depth = 30;
					this._player = playerWithVehicleId;
					this._playerStats = playerWithVehicleId.GetComponentInChildren<RcVehicleRaceStats>();
					this.vPlayerTransform = this._player.transform;
				}
				this.vCharacterMiniMapTransform[vehicleId] = this.CharacterMiniMap[vehicleId].transform.parent.transform;
			}
		}
		this._hasStart = true;
	}

	// Token: 0x060007B9 RID: 1977 RVA: 0x00039E60 File Offset: 0x00038060
	public void Update()
	{
		if (this._hasStart && ++this.m_bUpdate % this.RefreshRate == 0)
		{
			float num = this._playerStats.GetDistToEndOfLap();
			float y = this.vProgressionBarTranform.localScale.y;
			float num2 = -y * (num / this._raceLength);
			num2 -= this.vProgressionBarTranform.localPosition.y;
			Transform transform = this.vCharacterMiniMapTransform[this._playerIndex];
			this.vCharacterMiniMapTransform[this._playerIndex].localPosition = new Vector3(transform.localPosition.x, num2, transform.localPosition.z);
			int rank = this._playerStats.GetRank();
			if (rank < 3)
			{
				this.PositionsMiniMap[this._playerIndex].text = (rank + 1).ToString();
			}
			else
			{
				this.PositionsMiniMap[this._playerIndex].text = string.Empty;
			}
			foreach (Tuple<GameObject, int, Renderer, RcVehicleRaceStats> tuple in this._vehicles)
			{
				GameObject item = tuple.Item1;
				int item2 = tuple.Item2;
				Renderer item3 = tuple.Item3;
				RcVehicleRaceStats item4 = tuple.Item4;
				if (item2 != this._playerIndex)
				{
					int rank2 = item4.GetRank();
					if (rank2 < 3)
					{
						this.PositionsMiniMap[item2].text = (rank2 + 1).ToString();
					}
					else
					{
						this.PositionsMiniMap[item2].text = string.Empty;
					}
					if (!(item == null))
					{
						Transform transform2 = this.vVehicleTransforms[item2];
						float distToEndOfLap = item4.GetDistToEndOfLap();
						if (!item3.isVisible)
						{
							float num3;
							if (item4.GetLogicNbLap() != this._playerStats.GetLogicNbLap())
							{
								num = this._raceLength - num;
								num3 = num + distToEndOfLap;
							}
							else
							{
								num3 = distToEndOfLap - num;
							}
							Vector3 vector = transform2.position - this.vPlayerTransform.position;
							if (num3 >= 0f && num3 <= 50f)
							{
								float d = Vector3.Dot(vector, this.vPlayerTransform.forward);
								Vector3 b = this.vPlayerTransform.position + this.vPlayerTransform.forward * d;
								float num4 = (transform2.position - b).magnitude;
								num4 *= this.AngleDir(this.vPlayerTransform.forward, vector, this.vPlayerTransform.up);
								this.UpdateSprite(item2, num4, num3, this.CharacterSprites, 0.1f, true);
							}
							else
							{
								this.CharacterSprites[item2].enabled = false;
							}
						}
						else
						{
							this.CharacterSprites[item2].enabled = false;
						}
						float num5 = -y * (distToEndOfLap / this._raceLength);
						num5 -= this.vProgressionBarTranform.localPosition.y;
						Transform transform3 = this.vCharacterMiniMapTransform[item2];
						this.vCharacterMiniMapTransform[item2].localPosition = new Vector3(transform3.localPosition.x, num5, transform3.localPosition.z);
						int depth = (int) item4.GetVehicle().m_eControlType * 10 - rank2;
						this.CharacterMiniMap[item2].depth = depth;
						this.PositionsMiniMap[item2].depth = depth;
					}
				}
			}
		}
	}

	// Token: 0x060007BA RID: 1978 RVA: 0x0003A244 File Offset: 0x00038444
	private void RaceEnd(RcVehicle pVehicle)
	{
		if (pVehicle is Kart)
		{
			int vehicleId = pVehicle.GetVehicleId();
			bool enabled = this.SelectorMiniMap[vehicleId].enabled;
			Color color = this.SelectorMiniMap[vehicleId].color;
			this.PositionsMiniMap[vehicleId].alpha = 0.25f;
			this.SelectorMiniMap[vehicleId].alpha = 0.25f;
			this.CharacterMiniMap[vehicleId].alpha = 0.25f;
			int rank;
			if (vehicleId != this._playerIndex)
			{
				rank = this._vehicles[vehicleId].Item4.GetRank();
			}
			else
			{
				rank = this._playerStats.GetRank();
				this.CharacterSprites[this._playerIndex].transform.parent.gameObject.SetActive(false);
			}
			if (rank < 3)
			{
				this.Results[rank].SetActive(true);
				UITexturePattern componentInChildren = this.Results[rank].GetComponentInChildren<UITexturePattern>();
				if (componentInChildren)
				{
					componentInChildren.ChangeTexture(this._characters[vehicleId]);
				}
				UISprite component = this.Results[rank].transform.GetChild(2).GetComponent<UISprite>();
				component.enabled = enabled;
				component.color = color;
			}
		}
	}

	// Token: 0x060007BB RID: 1979 RVA: 0x00031810 File Offset: 0x0002FA10
	private float AngleDir(Vector3 pForward, Vector3 pTargetDir, Vector3 pUp)
	{
		Vector3 lhs = Vector3.Cross(pForward, pTargetDir);
		float num = Vector3.Dot(lhs, pUp);
		if ((double)num > 0.0)
		{
			return 1f;
		}
		if ((double)num < 0.0)
		{
			return -1f;
		}
		return 0f;
	}

	// Token: 0x060007BC RID: 1980 RVA: 0x0003A390 File Offset: 0x00038590
	public void UpdateSprite(int pIndex, float pPosX, float pDistance, List<UISprite> vSprites, float pPriority, bool pTransformParent)
	{
		UISprite uisprite = vSprites[pIndex];
		uisprite.enabled = true;
		float num = 1f - pDistance / 50f;
		float num2 = Mathf.Abs(this.m_fPosXLimit);
		float num3 = pPosX * num2 / (this.MaxLimit * this.MaxLimit);
		num3 = Mathf.Clamp(num3, -num2, num2);
		uisprite.alpha = Mathf.Lerp(0.2f, 1f, num);
		if (pTransformParent)
		{
			uisprite.transform.parent.localPosition = new Vector3(num3, uisprite.transform.parent.localPosition.y, -num - pPriority);
		}
		else
		{
			uisprite.transform.localPosition = new Vector3(num3, uisprite.transform.localPosition.y, -num - pPriority);
		}
	}

	// Token: 0x060007BD RID: 1981 RVA: 0x000077B8 File Offset: 0x000059B8
	public void UpdatePie(int pIndex, float pPosX, float pDistance)
	{
		this.UpdateSprite(pIndex, pPosX, pDistance, this.Pies, 0.2f, false);
	}

	// Token: 0x060007BE RID: 1982 RVA: 0x000077CF File Offset: 0x000059CF
	public void UpdateAutolockPie(int pIndex, float pPosX, float pDistance)
	{
		this.UpdateSprite(pIndex, pPosX, pDistance, this.AutolockPies, 0.3f, false);
	}

	// Token: 0x060007BF RID: 1983 RVA: 0x0003A464 File Offset: 0x00038664
	public void UpdateUFO(float pDistance)
	{
		float y = this.vProgressionBarTranform.localScale.y;
		float num = -y * (pDistance / this._raceLength);
		num -= this.vProgressionBarTranform.localPosition.y;
		Transform transform = this.Ufo.transform;
		this.Ufo.transform.localPosition = new Vector3(transform.localPosition.x, num - 38f, transform.localPosition.z);
	}

	// Token: 0x060007C0 RID: 1984 RVA: 0x000077E6 File Offset: 0x000059E6
	public void SetUfoToGood()
	{
		this.Ufo.color = this.GoodUfoColor;
	}

	// Token: 0x060007C1 RID: 1985 RVA: 0x000077F9 File Offset: 0x000059F9
	public void SetUfoToBad()
	{
		this.Ufo.color = this.BadUfoColor;
	}

	// Token: 0x060007C2 RID: 1986 RVA: 0x0000780C File Offset: 0x00005A0C
	public void SetUfoToNormal()
	{
		this.Ufo.color = Color.white;
	}

	// Token: 0x040007A3 RID: 1955
	public GameObject[] Results = new GameObject[3];

	// Token: 0x040007A4 RID: 1956
	public List<UISprite> CharacterSprites = new List<UISprite>();

	// Token: 0x040007A5 RID: 1957
	public List<UISprite> Pies = new List<UISprite>();

	// Token: 0x040007A6 RID: 1958
	public List<UISprite> AutolockPies = new List<UISprite>();

	// Token: 0x040007A7 RID: 1959
	public List<UISprite> CharacterMiniMap = new List<UISprite>();

	// Token: 0x040007A8 RID: 1960
	public List<UILabel> PositionsMiniMap = new List<UILabel>();

	// Token: 0x040007A9 RID: 1961
	public List<UISprite> SelectorMiniMap = new List<UISprite>();

	// Token: 0x040007AA RID: 1962
	public List<Color> SelectorColors = new List<Color>();

	// Token: 0x040007AB RID: 1963
	public UISprite Ufo;

	// Token: 0x040007AC RID: 1964
	public UISprite EndLine;

	// Token: 0x040007AD RID: 1965
	public UISprite ProgressionBar;

	// Token: 0x040007AE RID: 1966
	public Color BadUfoColor;

	// Token: 0x040007AF RID: 1967
	public Color GoodUfoColor;

	// Token: 0x040007B0 RID: 1968
	private GameObject _player;

	// Token: 0x040007B1 RID: 1969
	private int _playerIndex = -1;

	// Token: 0x040007B2 RID: 1970
	private RcVehicleRaceStats _playerStats;

	// Token: 0x040007B3 RID: 1971
	private List<Tuple<GameObject, int, Renderer, RcVehicleRaceStats>> _vehicles;

	// Token: 0x040007B4 RID: 1972
	private RcMultiPath _idealPath;

	// Token: 0x040007B5 RID: 1973
	private bool _hasStart;

	// Token: 0x040007B6 RID: 1974
	private float _raceLength;

	// Token: 0x040007B7 RID: 1975
	private int[] _characters = new int[6];

	// Token: 0x040007B8 RID: 1976
	public float MaxLimit;

	// Token: 0x040007B9 RID: 1977
	private float m_fPosXLimit;

	// Token: 0x040007BA RID: 1978
	public int RefreshRate = 5;

	// Token: 0x040007BB RID: 1979
	private Transform vPlayerTransform;

	// Token: 0x040007BC RID: 1980
	private Transform vProgressionBarTranform;

	// Token: 0x040007BD RID: 1981
	private Transform[] vCharacterMiniMapTransform = new Transform[6];

	// Token: 0x040007BE RID: 1982
	private Transform[] vVehicleTransforms = new Transform[6];

	// Token: 0x040007BF RID: 1983
	private int m_bUpdate;
}

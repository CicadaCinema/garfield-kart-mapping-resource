﻿using System;
using UnityEngine;

// Token: 0x020001BA RID: 442
public class PanelAdvantages : AbstractMenu
{
	// Token: 0x06000BE9 RID: 3049 RVA: 0x0005134C File Offset: 0x0004F54C
	public override void Awake()
	{
		Transform parent = base.transform.parent;
		this.m_pMenuSelectKart = parent.GetComponent<MenuSelectKart>();
		while (this.m_pMenuSelectKart == null)
		{
			parent = parent.parent;
			if (!parent)
			{
				return;
			}
			this.m_pMenuSelectKart = parent.GetComponent<MenuSelectKart>();
		}
		this.m_oPanel = GameObject.Find("Anchor_Center/PanelData/PanelAdvantages");
		if (this.m_oPanel != null)
		{
			this.m_oTweenPosition = this.m_oPanel.GetComponent<TweenPosition>();
			this.m_oTweenScale = this.m_oPanel.GetComponent<TweenScale>();
			if (this.m_oTweenPosition != null)
			{
				this.m_oTweenPosition.to = this.m_oPanel.transform.localPosition;
				this.m_oTweenPosition.from = base.transform.InverseTransformPoint(this.m_oTarget.transform.position);
				this.m_oTweenPosition.eventReceiver = base.gameObject;
				if (this.m_oTweenScale != null)
				{
					this.m_oTweenScale.delay = this.m_oTweenPosition.delay;
				}
			}
		}
	}

	// Token: 0x06000BEA RID: 3050 RVA: 0x00051474 File Offset: 0x0004F674
	public void Initialize()
	{
		int nbSlots = Singleton<GameConfigurator>.Instance.NbSlots;
		for (int i = 0; i < 4; i++)
		{
			this.m_oSlots[i].SetEnable(i < nbSlots);
			this.m_oSlots[i].Initialize();
		}
		base.BroadcastMessage("OnInitialize", SendMessageOptions.DontRequireReceiver);
	}

	// Token: 0x06000BEB RID: 3051 RVA: 0x000514D4 File Offset: 0x0004F6D4
	public override void OnEnter()
	{
		base.OnEnter();
		if (this.m_oTweenPosition != null && this.m_oTweenScale != null)
		{
			foreach (GameObject gameObject in this.m_oToHide)
			{
				gameObject.SetActive(true);
			}
			this.m_oTweenPosition.callWhenFinished = string.Empty;
			this.m_oTweenPosition.Play(true);
			this.m_oTweenScale.Play(true);
		}
		this.m_oTarget.SetActive(true);
		this.Initialize();
	}

	// Token: 0x06000BEC RID: 3052 RVA: 0x0005156C File Offset: 0x0004F76C
	public override void OnExit()
	{
		if (base.gameObject.activeSelf)
		{
			if (this.m_oTweenPosition != null && this.m_oTweenScale != null)
			{
				this.m_oTweenPosition.Play(false);
				this.m_oTweenPosition.callWhenFinished = "Disable";
				this.m_oTweenScale.Play(false);
				this.m_bHaveToBeDisabled = true;
				foreach (GameObject gameObject in this.m_oToHide)
				{
					gameObject.SetActive(false);
				}
				this.m_oTarget.SetActive(false);
			}
			else
			{
				base.OnExit();
			}
		}
	}

	// Token: 0x06000BED RID: 3053 RVA: 0x00051618 File Offset: 0x0004F818
	public void HiddenExit()
	{
		if (base.gameObject.activeSelf)
		{
			if (this.m_oTweenPosition != null && this.m_oTweenScale != null)
			{
				this.m_oTweenPosition.Reset();
				this.m_oTweenScale.Reset();
			}
			base.OnExit();
		}
	}

	// Token: 0x06000BEE RID: 3054 RVA: 0x0000A4AF File Offset: 0x000086AF
	public void Disable()
	{
		if (this.m_bHaveToBeDisabled)
		{
			this.m_bHaveToBeDisabled = false;
			base.gameObject.SetActive(false);
			this.m_oTarget.SetActive(true);
		}
	}

	// Token: 0x06000BEF RID: 3055 RVA: 0x00051674 File Offset: 0x0004F874
	public void ValidSlots()
	{
		int nbSlots = Singleton<GameConfigurator>.Instance.NbSlots;
		for (int i = 0; i < nbSlots; i++)
		{
			this.m_oSlots[i].ValidSlot();
		}
	}

	// Token: 0x06000BF0 RID: 3056 RVA: 0x0000A4DB File Offset: 0x000086DB
	public bool IsAdvantageAvailable(EAdvantage eAdvantage)
	{
		return this.m_pMenuSelectKart && this.m_pMenuSelectKart.IsAdvantageAvailable(eAdvantage);
	}

	// Token: 0x06000BF1 RID: 3057 RVA: 0x000516AC File Offset: 0x0004F8AC
	public Transform GetAdvantageBtnItem(EAdvantage eAdv)
	{
		if (!this.m_pMenuSelectKart || !this.m_pMenuSelectKart.m_oScrollPanel)
		{
			return null;
		}
		foreach (BtnItem btnItem in this.m_pMenuSelectKart.m_oScrollPanel.GetComponentsInChildren<BtnItem>())
		{
			AdvantageData advantageData = (AdvantageData)btnItem.GetData();
			if (advantageData && advantageData.AdvantageType == eAdv)
			{
				return btnItem.transform;
			}
		}
		return null;
	}

	// Token: 0x06000BF2 RID: 3058 RVA: 0x00051734 File Offset: 0x0004F934
	public BtnSlotAdvantage GetFreeSlot()
	{
		foreach (BtnSlotAdvantage btnSlotAdvantage in this.m_oSlots)
		{
			if (btnSlotAdvantage.IsActive && btnSlotAdvantage.IsEmpty)
			{
				return btnSlotAdvantage;
			}
		}
		return null;
	}

	// Token: 0x04000BC2 RID: 3010
	public BtnSlotAdvantage[] m_oSlots = new BtnSlotAdvantage[4];

	// Token: 0x04000BC3 RID: 3011
	private MenuSelectKart m_pMenuSelectKart;

	// Token: 0x04000BC4 RID: 3012
	public GameObject[] m_oToHide;

	// Token: 0x04000BC5 RID: 3013
	public GameObject m_oTarget;

	// Token: 0x04000BC6 RID: 3014
	private GameObject m_oPanel;

	// Token: 0x04000BC7 RID: 3015
	private TweenPosition m_oTweenPosition;

	// Token: 0x04000BC8 RID: 3016
	private TweenScale m_oTweenScale;

	// Token: 0x04000BC9 RID: 3017
	private bool m_bHaveToBeDisabled;
}

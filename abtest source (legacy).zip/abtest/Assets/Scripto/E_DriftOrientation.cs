﻿using System;

// Token: 0x0200009D RID: 157
public enum E_DriftOrientation
{
	// Token: 0x0400039D RID: 925
	Left = -1,
	// Token: 0x0400039E RID: 926
	None,
	// Token: 0x0400039F RID: 927
	Right
}

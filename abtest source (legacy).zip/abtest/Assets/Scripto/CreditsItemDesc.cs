﻿using System;
using UnityEngine;

// Token: 0x02000195 RID: 405
public struct CreditsItemDesc
{
	// Token: 0x1700017E RID: 382
	// (get) Token: 0x06000AEC RID: 2796 RVA: 0x000097F4 File Offset: 0x000079F4
	// (set) Token: 0x06000AED RID: 2797 RVA: 0x000097FC File Offset: 0x000079FC
	public string FontName
	{
		get
		{
			return this.SavedFontName;
		}
		set
		{
			this.SavedFontName = value;
		}
	}

	// Token: 0x1700017F RID: 383
	// (get) Token: 0x06000AEE RID: 2798 RVA: 0x00049B8C File Offset: 0x00047D8C
	public UIFont ItemFont
	{
		get
		{
			if (this.FontPrefab == null)
			{
				this.FontPrefab = (Resources.Load(this.SavedFontName) as GameObject);
			}
			if (this.FontPrefab != null)
			{
				return this.FontPrefab.GetComponent<UIFont>();
			}
			return null;
		}
	}

	// Token: 0x04000AB2 RID: 2738
	public float FontSize;

	// Token: 0x04000AB3 RID: 2739
	public float Offset;

	// Token: 0x04000AB4 RID: 2740
	public Color FontColor;

	// Token: 0x04000AB5 RID: 2741
	private GameObject FontPrefab;

	// Token: 0x04000AB6 RID: 2742
	private string SavedFontName;
}

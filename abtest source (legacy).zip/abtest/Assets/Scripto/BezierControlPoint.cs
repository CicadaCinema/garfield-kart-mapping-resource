﻿using System;
using UnityEngine;

// Token: 0x02000245 RID: 581
public class BezierControlPoint : MonoBehaviour, IBezierControlPoint
{
	// Token: 0x1700020C RID: 524
	// (get) Token: 0x06001034 RID: 4148 RVA: 0x0000CE9F File Offset: 0x0000B09F
	public BezierControlPointSide Side
	{
		get
		{
			return this.side;
		}
	}

	// Token: 0x1700020D RID: 525
	// (get) Token: 0x06001035 RID: 4149 RVA: 0x0000AE06 File Offset: 0x00009006
	// (set) Token: 0x06001036 RID: 4150 RVA: 0x0000CEA7 File Offset: 0x0000B0A7
	public Vector3 CurrentPosition
	{
		get
		{
			return base.transform.position;
		}
		set
		{
			base.transform.position = value;
		}
	}

	// Token: 0x06001037 RID: 4151 RVA: 0x00066258 File Offset: 0x00064458
	public void OnDrawGizmos()
	{
		if (base.transform.parent.parent != null)
		{
			BezierCurveManager bezierCurveManager = base.transform.parent.parent.GetComponent(typeof(BezierCurveManager)) as BezierCurveManager;
			if (bezierCurveManager.DrawControlPoints)
			{
				Gizmos.DrawIcon(base.transform.position, "/BezierControlPoint.png");
			}
		}
	}

	// Token: 0x06001038 RID: 4152 RVA: 0x000662C8 File Offset: 0x000644C8
	public void OnDrawGizmosSelected()
	{
		if (base.transform.parent != null)
		{
			Component component = base.transform.parent.GetComponent(typeof(BezierWaypoint));
			if (component != null && component is BezierWaypoint)
			{
				BezierWaypoint bezierWaypoint = component as BezierWaypoint;
				Vector3 vectorToFootPoint = bezierWaypoint.CurrentPosition - base.transform.position;
				bezierWaypoint.SetPositionOfOther(this, vectorToFootPoint);
			}
		}
	}

	// Token: 0x04000F8A RID: 3978
	public BezierControlPointSide side;
}

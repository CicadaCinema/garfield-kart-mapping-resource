﻿using System;
using UnityEngine;

// Token: 0x020001EC RID: 492
public class CamStateKill : CamState
{
	// Token: 0x170001CE RID: 462
	// (get) Token: 0x06000D5A RID: 3418 RVA: 0x00004F14 File Offset: 0x00003114
	public override ECamState state
	{
		get
		{
			return ECamState.Kill;
		}
	}

	// Token: 0x06000D5B RID: 3419 RVA: 0x0000B1CE File Offset: 0x000093CE
	public override void Enter(Transform _Transform, Transform _Target)
	{
		base.Enter(_Transform, _Target);
	}

	// Token: 0x06000D5C RID: 3420 RVA: 0x0000B1D8 File Offset: 0x000093D8
	public override ECamState Manage(float dt)
	{
		base.m_Transform.LookAt(base.m_Target);
		return this.state;
	}

	// Token: 0x06000D5D RID: 3421 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void Exit()
	{
	}
}

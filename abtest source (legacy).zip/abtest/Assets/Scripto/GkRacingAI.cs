﻿using System;
using UnityEngine;

// Token: 0x020000A1 RID: 161
public class GkRacingAI : RacingAI
{
	// Token: 0x0600042F RID: 1071 RVA: 0x000254D4 File Offset: 0x000236D4
	public override void Init()
	{
		base.Init();
		this._bonusTimer = 0f;
		this._bonusMaxTimer = 0f;
		BehaviourSettings behaviourSettings = Singleton<GameConfigurator>.Instance.AISettings.BehaviourSettings;
		EDifficulty difficulty = Singleton<GameConfigurator>.Instance.Difficulty;
		if (difficulty == EDifficulty.EASY)
		{
			this._bonusDefenseDelay = behaviourSettings.EasyBonusDelay;
		}
		else if (difficulty == EDifficulty.NORMAL)
		{
			this._bonusDefenseDelay = behaviourSettings.NormalBonusDelay;
		}
		else if (difficulty == EDifficulty.HARD)
		{
			this._bonusDefenseDelay = behaviourSettings.HardBonusDelay;
		}
		this._bonusDelayMax = behaviourSettings.BonusDelayMax + UnityEngine.Random.Range(behaviourSettings.BonusDelayBeforeUseMin, behaviourSettings.BonusDelayBeforeUseMax);
		this._bonusAttackDelay = UnityEngine.Random.Range(behaviourSettings.BonusDelayBeforeUseMin, behaviourSettings.BonusDelayBeforeUseMax);
		this._pieBeforeDistance = behaviourSettings.PieBeforeDistance;
		this._pieBehindDistance = behaviourSettings.PieBehindDistance;
		this._diamondBeforeDistance = behaviourSettings.DiamondBeforeDistance;
		this._diamondBehindDistance = behaviourSettings.DiamondBehindDistance;
		this._parfumeDistance = behaviourSettings.ParfumeDistance;
		this._magicDistance = behaviourSettings.MagicDistance;
		this._defenseZoneRadius = behaviourSettings.DefenseZoneRadius;
		this._shootChance = (float)behaviourSettings.ShootChance.GetChance(this._level);
		this._keepItemChance = behaviourSettings.KeepItemChance;
		this._RatioItemSphereCollider = behaviourSettings.RatioSphereCollider;
		this._tryDetachDiamondTimer = 0f;
		this._wantDetachDiamond = false;
		this._DontUseItem = false;
		Kart kart = (Kart)base.Vehicle;
		kart.OnHit = (Action)Delegate.Combine(kart.OnHit, new Action(base.Reset));
		if (this._level == E_AILevel.BAD)
		{
			this.Manage = new GkRacingAI.ManageDelegate(this.ManageAI);
		}
		else
		{
			this.Manage = new GkRacingAI.ManageDelegate(this.ManageAI);
		}
		this._layerMaskGlobal = this._layerMaskVehicle;
	}

	// Token: 0x06000430 RID: 1072 RVA: 0x0002569C File Offset: 0x0002389C
	public override void StartAntiJam()
	{
		base.StartAntiJam();
		if (this.OnNeedPath != null)
		{
			RcFastValuePath rcFastValuePath = (RcFastValuePath)base.CurrentPath;
			if (rcFastValuePath.PathType == E_PathType.SHORTCUT || rcFastValuePath.PathType == E_PathType.NONE)
			{
				this.OnNeedPath(this);
				this._jamTime = 0f;
				this._reverseTime = 0f;
				this._antiJamTime = 0f;
				base.Reset();
			}
		}
	}

	// Token: 0x06000431 RID: 1073 RVA: 0x00025710 File Offset: 0x00023910
	public override void Update()
	{
		base.Update();
		Kart kart = (Kart)base.Vehicle;
		EITEM item = kart.GetBonusMgr().GetItem(0);
		if (item != EITEM.ITEM_NONE && Singleton<GameManager>.Instance.GameMode.State != E_GameState.Podium)
		{
			this._bonusTimer += Time.deltaTime;
			if (!this.m_bKeepItem)
			{
				this._bonusMaxTimer += Time.deltaTime;
			}
			else if (kart.GetBonusMgr().GetItem(1) != EITEM.ITEM_NONE)
			{
				this.m_bKeepItem = false;
			}
			if (this._bonusTimer > this._bonusDefenseDelay)
			{
				this.m_bCanAttack = (this._bonusMaxTimer > this._bonusAttackDelay);
				this._bonusTimer -= this._bonusDefenseDelay;
				switch (item)
				{
				case EITEM.ITEM_PIE:
					this.Manage(true, true, true, true, this._defenseZoneRadius, this._pieBeforeDistance, this._pieBehindDistance, Singleton<BonusMgr>.Instance.m_pPieEntities[0].GetComponent<SphereCollider>().radius * this._RatioItemSphereCollider, Singleton<BonusMgr>.Instance.m_pPieEntities[0].SpeedForward / 3.6f);
					break;
				case EITEM.ITEM_AUTOLOCK_PIE:
					if (kart.RaceStats.GetRank() == 0)
					{
						this.Manage(true, true, false, true, this._defenseZoneRadius, 0f, this._pieBehindDistance, Singleton<BonusMgr>.Instance.m_pAutolockPieEntities[0].GetComponent<SphereCollider>().radius * this._RatioItemSphereCollider, Singleton<BonusMgr>.Instance.m_pAutolockPieEntities[0].SpeedForward / 3.6f);
					}
					else
					{
						this.Manage(true, true, true, true, this._defenseZoneRadius, 0f, this._pieBehindDistance, Singleton<BonusMgr>.Instance.m_pAutolockPieEntities[0].GetComponent<SphereCollider>().radius * this._RatioItemSphereCollider, Singleton<BonusMgr>.Instance.m_pAutolockPieEntities[0].SpeedForward / 3.6f);
					}
					break;
				case EITEM.ITEM_SPRING:
					if ((kart.HasDiamondAttached || kart.HasNapEffect()) && (float)Singleton<RandomManager>.Instance.Next(0, 100) < this._shootChance && !this._DontUseItem)
					{
						this.ActivateBonus(kart, false);
					}
					else
					{
						if (kart.HasDiamondAttached || kart.HasNapEffect())
						{
							this._DontUseItem = true;
						}
						this.Manage(true, true, false, false, this._defenseZoneRadius, 0f, 0f, 0f, 0f);
					}
					break;
				case EITEM.ITEM_LASAGNA:
					if (kart.HasDiamondAttached && (float)Singleton<RandomManager>.Instance.Next(0, 100) < this._shootChance)
					{
						this.ActivateBonus(kart, false);
					}
					break;
				case EITEM.ITEM_DIAMOND:
					this.Manage(true, false, true, true, this._defenseZoneRadius, this._diamondBeforeDistance, this._diamondBehindDistance, Singleton<BonusMgr>.Instance.m_pDiamondEntities[0].MinDistance * this._RatioItemSphereCollider, Singleton<GameConfigurator>.Instance.AISettings.BehaviourSettings.DiamondBeforeDistance / (Singleton<BonusMgr>.Instance.m_pDiamondEntities[0].LifeTime * 0.5f));
					break;
				case EITEM.ITEM_UFO:
				case EITEM.ITEM_NAP:
				{
					int num = Singleton<RandomManager>.Instance.Next(0, 100);
					if ((float)num < this._shootChance && (item == EITEM.ITEM_NAP || (item == EITEM.ITEM_UFO && kart.RaceStats.GetRank() != 0)))
					{
						this.ActivateBonus(kart, false);
					}
					break;
				}
				case EITEM.ITEM_PARFUME:
					if (kart.GetBonusMgr().GetBonusValue(EITEM.ITEM_PARFUME, EBonusCustomEffect.REPULSE) != 0f)
					{
						if (this.m_bCanAttack)
						{
							if ((float)Singleton<RandomManager>.Instance.Next(0, 100) < this._shootChance)
							{
								Kart kart2 = (Kart)kart.RaceStats.GetPreceding();
								if (kart2 != null && Mathf.Abs(kart2.RaceStats.GetDistToEndOfRace() - kart.RaceStats.GetDistToEndOfRace()) < this._defenseZoneRadius * 3f)
								{
									this.ActivateBonus(kart, false);
								}
								else
								{
									kart2 = (Kart)kart.RaceStats.GetPursuant();
									if (kart2 != null && Mathf.Abs(kart2.RaceStats.GetDistToEndOfRace() - kart.RaceStats.GetDistToEndOfRace()) < this._defenseZoneRadius * 3f)
									{
										this.ActivateBonus(kart, false);
									}
								}
							}
							else
							{
								BehaviourSettings behaviourSettings = Singleton<GameConfigurator>.Instance.AISettings.BehaviourSettings;
								this._bonusAttackDelay += UnityEngine.Random.Range(behaviourSettings.BonusDelayBeforeUseMin, behaviourSettings.BonusDelayBeforeUseMax);
							}
						}
					}
					else
					{
						if (kart.OnUfoCatchMe == null)
						{
							Kart kart3 = kart;
							kart3.OnUfoCatchMe = (Action<Kart>)Delegate.Combine(kart3.OnUfoCatchMe, new Action<Kart>(this.UseParfume));
						}
						if (kart.IsSleeping() && (float)Singleton<RandomManager>.Instance.Next(0, 100) < this._shootChance && !this._DontUseItem)
						{
							this.ActivateBonus(kart, false);
						}
						else if (kart.HasDiamondAttached && (float)Singleton<RandomManager>.Instance.Next(0, 100) < this._shootChance && !this._DontUseItem)
						{
							this.ActivateBonus(kart, false);
						}
						else
						{
							if (kart.HasDiamondAttached)
							{
								this._DontUseItem = true;
							}
							this.Manage(true, true, false, false, this._defenseZoneRadius, 0f, 0f, 0f, 0f);
						}
					}
					break;
				case EITEM.ITEM_MAGIC:
					this.Manage(false, false, true, false, 0f, this._magicDistance, 0f, Singleton<BonusMgr>.Instance.m_pMagicEntities[0].GetComponent<SphereCollider>().radius * this._RatioItemSphereCollider, Singleton<BonusMgr>.Instance.m_pMagicEntities[0].Speed / 3.6f);
					break;
				}
			}
			else
			{
				this.m_bKeepItem = ((float)Singleton<RandomManager>.Instance.Next(0, 100) < this._keepItemChance);
			}
			if (this._bonusMaxTimer > this._bonusDelayMax)
			{
				this._bonusMaxTimer = 0f;
				this.ForceThrow(item);
			}
		}
		if (kart.HasDiamondAttached)
		{
			if (this._tryDetachDiamondTimer > 0f)
			{
				this._tryDetachDiamondTimer -= Time.deltaTime;
			}
			if (this._tryDetachDiamondTimer <= 0f)
			{
				if (!this._wantDetachDiamond)
				{
					if ((float)Singleton<RandomManager>.Instance.Next(0, 100) < this._shootChance)
					{
						this._wantDetachDiamond = true;
					}
					else
					{
						this._tryDetachDiamondTimer = this._bonusDefenseDelay * 10f;
					}
				}
				else if (kart.IsOnGround())
				{
					kart.Jump(0f, 0f);
					this._tryDetachDiamondTimer = 0.5f;
				}
			}
		}
		else
		{
			this._wantDetachDiamond = false;
		}
	}

	// Token: 0x06000432 RID: 1074 RVA: 0x00025E0C File Offset: 0x0002400C
	public void ForceThrow(EITEM pItem)
	{
		switch (pItem)
		{
		case EITEM.ITEM_PIE:
		case EITEM.ITEM_AUTOLOCK_PIE:
		case EITEM.ITEM_SPRING:
		case EITEM.ITEM_DIAMOND:
		case EITEM.ITEM_PARFUME:
			this.ActivateBonus((Kart)base.Vehicle, true);
			break;
		case EITEM.ITEM_LASAGNA:
		case EITEM.ITEM_NAP:
		case EITEM.ITEM_MAGIC:
			this.ActivateBonus((Kart)base.Vehicle, false);
			break;
		}
	}

	// Token: 0x06000433 RID: 1075 RVA: 0x00025E7C File Offset: 0x0002407C
	public void ActivateBonus(Kart pKart, bool pBehind)
	{
		BehaviourSettings behaviourSettings = Singleton<GameConfigurator>.Instance.AISettings.BehaviourSettings;
		pKart.GetBonusMgr().ActivateBonus(pBehind);
		this._bonusTimer = 0f;
		this._bonusMaxTimer = 0f;
		this._bonusAttackDelay = UnityEngine.Random.Range(behaviourSettings.BonusDelayBeforeUseMin, behaviourSettings.BonusDelayBeforeUseMax);
		this._bonusDelayMax = behaviourSettings.BonusDelayMax + UnityEngine.Random.Range(behaviourSettings.BonusDelayBeforeUseMin, behaviourSettings.BonusDelayBeforeUseMax);
		this.m_bKeepItem = false;
		this._DontUseItem = false;
		if (pKart.OnUfoCatchMe != null)
		{
			pKart.OnUfoCatchMe = (Action<Kart>)Delegate.Remove(pKart.OnUfoCatchMe, new Action<Kart>(this.UseParfume));
		}
	}

	// Token: 0x06000434 RID: 1076 RVA: 0x00025F2C File Offset: 0x0002412C
	public override void DebugDrawGizmos()
	{
		Kart kart = (Kart)base.Vehicle;
		Vector3 forward = kart.transform.parent.forward;
		forward.Normalize();
		float num = kart.transform.parent.GetComponent<SphereCollider>().radius + 0.2f;
		Vector3 position = kart.GetPosition();
		Debug.DrawLine(position, position + forward * 10f, Color.white);
		Debug.DrawLine(position, position + kart.GetCameraAt() * 10f, Color.green);
	}

	// Token: 0x06000435 RID: 1077 RVA: 0x00025FC0 File Offset: 0x000241C0
	public void ManageAI(bool bCheckBonusBehind, bool bCheckBonusForward, bool bCheckForward, bool bCheckBehind, float fBonusDistance, float fVehicleForwardDistance, float fVehicleBehindDistance, float fItemColRadius, float fItemSpeed)
	{
		if ((float)Singleton<RandomManager>.Instance.Next(0, 100) > this._shootChance)
		{
			return;
		}
		Kart kart = (Kart)base.Vehicle;
		Vector3 launchHorizontalDirection = kart.LaunchHorizontalDirection;
		Vector2 vector = new Vector2(launchHorizontalDirection.x, launchHorizontalDirection.z);
		Vector2 vector2 = new Vector2(kart.transform.position.x, kart.transform.position.z);
		float radius = kart.transform.parent.GetComponent<SphereCollider>().radius;
		fBonusDistance *= fBonusDistance;
		fVehicleForwardDistance *= fVehicleForwardDistance;
		fVehicleBehindDistance *= fVehicleBehindDistance;
		if (bCheckBonusBehind)
		{
			foreach (AutolockPieBonusEntity autolockPieBonusEntity in Singleton<BonusMgr>.Instance.m_pAutolockPieEntities)
			{
				if (autolockPieBonusEntity.Activate && !autolockPieBonusEntity.IsStatic())
				{
					Vector2 rhs = vector2 - autolockPieBonusEntity.GetFlatPosition();
					if (rhs.sqrMagnitude < fBonusDistance && Vector2.Dot(vector, rhs) > 0f)
					{
						bool pBehind = true;
						if (fItemColRadius == 0f)
						{
							pBehind = false;
						}
						this.ActivateBonus(kart, pBehind);
						return;
					}
				}
			}
			foreach (PieBonusEntity pieBonusEntity in Singleton<BonusMgr>.Instance.m_pPieEntities)
			{
				if (pieBonusEntity.Activate && !pieBonusEntity.IsStatic())
				{
					Vector2 rhs2 = vector2 - pieBonusEntity.GetFlatPosition();
					if (rhs2.sqrMagnitude < fBonusDistance)
					{
						if (fItemColRadius == 0f)
						{
							if (Vector2.Dot(rhs2.normalized, pieBonusEntity.GetFlatVelocity().normalized) > 0.707f)
							{
								this.ActivateBonus(kart, false);
								return;
							}
						}
						else if (Vector2.Dot(vector, pieBonusEntity.GetFlatVelocity()) / pieBonusEntity.GetFlatVelocity().magnitude > 0.707f && Vector2.Dot(vector, rhs2) / rhs2.magnitude > 0.707f)
						{
							this.ActivateBonus(kart, true);
							return;
						}
					}
				}
			}
		}
		if (bCheckBonusForward)
		{
			BonusEntity[][] array = new BonusEntity[][]
			{
				Singleton<BonusMgr>.Instance.m_pAutolockPieEntities,
				Singleton<BonusMgr>.Instance.m_pPieEntities,
				Singleton<BonusMgr>.Instance.m_pDiamondEntities,
				Singleton<BonusMgr>.Instance.m_pSpringEntities
			};
			foreach (BonusEntity[] array3 in array)
			{
				float radius2 = array3[0].GetComponent<SphereCollider>().radius;
				foreach (BonusEntity bonusEntity in array3)
				{
					if (bonusEntity.Activate && bonusEntity.IsStatic())
					{
						Vector2 rhs3 = bonusEntity.GetFlatPosition() - vector2;
						if (rhs3.sqrMagnitude < fBonusDistance)
						{
							float num = Vector2.Dot(vector, rhs3);
							float num2 = radius + radius2;
							if (num > 0f && rhs3.sqrMagnitude - num * num < num2 * num2)
							{
								num2 = radius2 + fItemColRadius;
								if (fItemColRadius == 0f || rhs3.sqrMagnitude - num * num < num2 * num2)
								{
									this.ActivateBonus(kart, false);
									return;
								}
							}
						}
					}
				}
			}
		}
		if (this.m_bCanAttack)
		{
			bool flag = false;
			bool flag2 = false;
			GameMode gameMode = Singleton<GameManager>.Instance.GameMode;
			int playerCount = gameMode.PlayerCount;
			int rank = kart.RaceStats.GetRank();
			if (bCheckForward && fVehicleForwardDistance == 0f)
			{
				this.ActivateBonus(kart, false);
			}
			for (int m = 0; m < playerCount; m++)
			{
				if (m != kart.Index)
				{
					Kart kart2 = gameMode.GetKart(m);
					if (kart2.gameObject.activeSelf && kart2.enabled)
					{
						RcVehiclePhysic vehiclePhysic = kart2.GetVehiclePhysic();
						Vector2 vector3 = new Vector2(vehiclePhysic.GetLinearVelocity().x, vehiclePhysic.GetLinearVelocity().z);
						float magnitude = vector3.magnitude;
						if (magnitude != 0f)
						{
							vector3 /= magnitude;
						}
						else
						{
							Vector2 vector4 = new Vector2(kart2.transform.forward.x, kart2.transform.forward.z);
							vector3 = vector4.normalized;
						}
						Vector2 vector5 = new Vector2(kart2.transform.position.x, kart2.transform.position.z);
						Vector2 lhs = new Vector2(vector3.y, -vector3.x);
						float num3 = Vector2.SqrMagnitude(vector2 - vector5);
						if (bCheckForward && kart2.RaceStats.GetRank() < rank && num3 < fVehicleForwardDistance)
						{
							float num4 = Vector2.Dot(lhs, vector * fItemSpeed);
							if (num4 != 0f)
							{
								float d = Vector2.Dot(lhs, vector5 - vector2) / num4;
								Vector2 lhs2 = vector * fItemSpeed * d;
								Vector2 rhs4 = vector5 + vector3 * magnitude * d - vector2;
								float num5 = Vector2.Dot(lhs2, rhs4);
								float num6 = rhs4.sqrMagnitude - num5 * num5 / lhs2.sqrMagnitude;
								float num7 = fItemColRadius + radius;
								if (num6 < num7 * num7)
								{
									flag2 = true;
									bCheckBehind = false;
									m = playerCount;
								}
							}
						}
						if (bCheckBehind && !flag && kart2.RaceStats.GetNbLapCompleted() >= kart.RaceStats.GetNbLapCompleted() && num3 < fVehicleBehindDistance)
						{
							Vector2 rhs5 = vector2 - vector5;
							if (Vector2.Dot(vector, rhs5) > 0f)
							{
								float num8 = Vector2.Dot(vector3, rhs5);
								float num9 = fItemColRadius + radius;
								if (num8 > 0f && rhs5.sqrMagnitude - num8 * num8 < num9 * num9)
								{
									flag = true;
								}
							}
						}
					}
				}
			}
			if (flag2)
			{
				this.ActivateBonus(kart, false);
				return;
			}
			if (flag)
			{
				this.ActivateBonus(kart, true);
				return;
			}
		}
	}

	// Token: 0x06000436 RID: 1078 RVA: 0x00005168 File Offset: 0x00003368
	public void UseParfume(Kart pKart)
	{
		if ((float)Singleton<RandomManager>.Instance.Next(0, 100) < this._shootChance)
		{
			this.ActivateBonus(pKart, false);
		}
	}

	// Token: 0x040003A9 RID: 937
	private float _bonusDefenseDelay;

	// Token: 0x040003AA RID: 938
	private float _bonusAttackDelay;

	// Token: 0x040003AB RID: 939
	private float _bonusDelayMax;

	// Token: 0x040003AC RID: 940
	private float _bonusTimer;

	// Token: 0x040003AD RID: 941
	private float _bonusMaxTimer;

	// Token: 0x040003AE RID: 942
	private float _tryDetachDiamondTimer;

	// Token: 0x040003AF RID: 943
	private float _pieBeforeDistance;

	// Token: 0x040003B0 RID: 944
	private float _pieBehindDistance;

	// Token: 0x040003B1 RID: 945
	private float _diamondBeforeDistance;

	// Token: 0x040003B2 RID: 946
	private float _diamondBehindDistance;

	// Token: 0x040003B3 RID: 947
	private float _defenseZoneRadius;

	// Token: 0x040003B4 RID: 948
	private float _magicDistance;

	// Token: 0x040003B5 RID: 949
	private float _parfumeDistance;

	// Token: 0x040003B6 RID: 950
	private float _shootChance;

	// Token: 0x040003B7 RID: 951
	private int _layerMaskVehicle = 1 << LayerMask.NameToLayer("Vehicle");

	// Token: 0x040003B8 RID: 952
	private int _layerMaskGlobal = 1;

	// Token: 0x040003B9 RID: 953
	private bool m_bCanAttack;

	// Token: 0x040003BA RID: 954
	private bool m_bKeepItem;

	// Token: 0x040003BB RID: 955
	private float _keepItemChance;

	// Token: 0x040003BC RID: 956
	public Action<GkRacingAI> OnNeedPath;

	// Token: 0x040003BD RID: 957
	private float _RatioItemSphereCollider = 1.3f;

	// Token: 0x040003BE RID: 958
	private bool _wantDetachDiamond;

	// Token: 0x040003BF RID: 959
	private bool _DontUseItem;

	// Token: 0x040003C0 RID: 960
	public GkRacingAI.ManageDelegate Manage;

	// Token: 0x020000A2 RID: 162
	// (Invoke) Token: 0x06000438 RID: 1080
	public delegate void ManageDelegate(bool bCheckBonusBehind, bool bCheckBonusForward, bool bCheckForward, bool bCheckBehind, float fBonusDistance, float fVehicleForwardDistance, float fVehicleBehindDistance, float fItemColRadius, float fItemSpeed);
}

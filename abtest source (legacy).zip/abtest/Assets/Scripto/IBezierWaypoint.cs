﻿using System;
using UnityEngine;

// Token: 0x0200024B RID: 587
public interface IBezierWaypoint
{
	// Token: 0x17000214 RID: 532
	// (get) Token: 0x0600104F RID: 4175
	IBezierControlPoint LeftPoint { get; }

	// Token: 0x17000215 RID: 533
	// (get) Token: 0x06001050 RID: 4176
	IBezierControlPoint RightPoint { get; }

	// Token: 0x17000216 RID: 534
	// (get) Token: 0x06001051 RID: 4177
	Vector3 CurrentPosition { get; }
}

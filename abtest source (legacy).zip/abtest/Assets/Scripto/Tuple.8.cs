﻿using System;

// Token: 0x0200025C RID: 604
[Serializable]
public class Tuple<T1, T2, T3, T4, T5, T6, T7, T8> : Tuple<T1, T2, T3, T4, T5, T6, T7>
{
	// Token: 0x06001086 RID: 4230 RVA: 0x00067938 File Offset: 0x00065B38
	public Tuple() : this(default(T1), default(T2), default(T3), default(T4), default(T5), default(T6), default(T7), default(T8))
	{
	}

	// Token: 0x06001087 RID: 4231 RVA: 0x0000D1F0 File Offset: 0x0000B3F0
	public Tuple(T1 pItem1, T2 pItem2, T3 pItem3, T4 pItem4, T5 pItem5, T6 pItem6, T7 pItem7, T8 pItem8) : base(pItem1, pItem2, pItem3, pItem4, pItem5, pItem6, pItem7)
	{
		this.Item8 = pItem8;
	}

	// Token: 0x04000FC1 RID: 4033
	public T8 Item8;
}

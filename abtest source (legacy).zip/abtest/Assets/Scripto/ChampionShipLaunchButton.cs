﻿using System;
using UnityEngine;

// Token: 0x02000191 RID: 401
public class ChampionShipLaunchButton : MonoBehaviour
{
	// Token: 0x06000AD9 RID: 2777 RVA: 0x00049900 File Offset: 0x00047B00
	private void OnClick()
	{
		ChampionShipData component = this.ChampionShipTracks.GetComponent<ChampionShipData>();
		Singleton<GameConfigurator>.Instance.GameModeType = E_GameModeType.CHAMPIONSHIP;
		Singleton<GameConfigurator>.Instance.SetChampionshipData(component, false);
		Singleton<GameConfigurator>.Instance.StartScene = component.Tracks[0];
		Singleton<GameConfigurator>.Instance.CurrentTrackIndex = 0;
		UnityEngine.Object.Destroy(GameObject.Find("MenuEntryPoint"));
		LoadingManager.LoadLevel(Singleton<GameConfigurator>.Instance.StartScene);
	}

	// Token: 0x04000AA6 RID: 2726
	public GameObject ChampionShipTracks;
}

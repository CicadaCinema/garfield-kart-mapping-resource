﻿using System;
using UnityEngine;

// Token: 0x020001D6 RID: 470
public class DebugAiHandler : AIPathHandler
{
	// Token: 0x06000CAC RID: 3244 RVA: 0x00054490 File Offset: 0x00052690
	public override void Start()
	{
		if (Application.isPlaying)
		{
			this.StartIdealPath();
			base._AIManager.Init(this);
			Kart kart = Singleton<GameManager>.Instance.GameMode.GetKart(0);
			GameObject player = Singleton<GameManager>.Instance.GameMode.GetPlayer(0);
			if (kart && this.IsPlayerIA)
			{
				kart.SetControlType(RcVehicle.ControlType.AI);
				base.RegisterController(player, this.AILevel);
				player.GetComponentInChildren<RcVirtualController>().SetDrivingEnabled(true);
			}
			else
			{
				kart.SetControlType(RcVehicle.ControlType.Human);
			}
		}
	}

	// Token: 0x06000CAD RID: 3245 RVA: 0x0000AC53 File Offset: 0x00008E53
	public override void InitIdealPaths(RacingAI pAI, int pIndex)
	{
		pAI.IdealPath = new RcFastValuePath(this.StartPath);
	}

	// Token: 0x06000CAE RID: 3246 RVA: 0x0000AC66 File Offset: 0x00008E66
	public override void OnDrawGizmos()
	{
		base.OnDrawGizmos();
	}

	// Token: 0x04000C4F RID: 3151
	public E_AILevel AILevel;

	// Token: 0x04000C50 RID: 3152
	public bool IsPlayerIA;

	// Token: 0x04000C51 RID: 3153
	public GameObject StartPath;
}

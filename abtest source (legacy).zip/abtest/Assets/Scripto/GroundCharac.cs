﻿using System;
using UnityEngine;

// Token: 0x02000212 RID: 530
public struct GroundCharac
{
	// Token: 0x06000EA8 RID: 3752 RVA: 0x0000C16F File Offset: 0x0000A36F
	public void reset()
	{
		this.point = Vector3.zero;
		this.normal = Vector3.zero;
		this.surface = 0;
	}

	// Token: 0x04000E21 RID: 3617
	public Vector3 point;

	// Token: 0x04000E22 RID: 3618
	public Vector3 normal;

	// Token: 0x04000E23 RID: 3619
	public int surface;
}

﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

// Token: 0x0200025F RID: 607
public class ASE_AdMob
{
	// Token: 0x06001097 RID: 4247
	[DllImport("__Internal")]
	private static extern void ASE_AdMobInit(string publisherId, bool isTesting);

	// Token: 0x06001098 RID: 4248 RVA: 0x0000D2BF File Offset: 0x0000B4BF
	public static void Init(string publisherId)
	{
		if (ASE_Tools.Available)
		{
			ASE_AdMob.Init(publisherId, false);
		}
	}

	// Token: 0x06001099 RID: 4249 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void Init(string publisherId, bool isTesting)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x0600109A RID: 4250
	[DllImport("__Internal")]
	private static extern void ASE_AdMobCreateBanner(int bannerType, bool bannerOnBottom);

	// Token: 0x0600109B RID: 4251 RVA: 0x0000D2DE File Offset: 0x0000B4DE
	[Obsolete("CreateBanner( AdMobBannerType bannerType, bool bannerOnBottom ) is deprecated, please use CreateBanner( iOSAdMobBannerType bannerType, bool bannerOnBottom ) instead.")]
	public static void CreateBanner(ASE_AdMob.AdMobBannerType bannerType, bool bannerOnBottom)
	{
		if (Application.platform == RuntimePlatform.IPhonePlayer)
		{
			ASE_AdMob.ASE_AdMobCreateBanner((int)bannerType, bannerOnBottom);
		}
		else
		{
			Debug.LogWarning(" Can't create the banner ! You're not on a iOS device ( Have you set the correct enum ? )");
		}
	}

	// Token: 0x0600109C RID: 4252 RVA: 0x0000D2DE File Offset: 0x0000B4DE
	public static void CreateBanner(ASE_AdMob.iOSAdMobBannerType bannerType, bool bannerOnBottom)
	{
		if (Application.platform == RuntimePlatform.IPhonePlayer)
		{
			ASE_AdMob.ASE_AdMobCreateBanner((int)bannerType, bannerOnBottom);
		}
		else
		{
			Debug.LogWarning(" Can't create the banner ! You're not on a iOS device ( Have you set the correct enum ? )");
		}
	}

	// Token: 0x0600109D RID: 4253 RVA: 0x00003B80 File Offset: 0x00001D80
	public static void CreateBanner(ASE_AdMob.AndroidAdMobBannerType bannerType, bool bannerOnBottom)
	{
	}

	// Token: 0x0600109E RID: 4254
	[DllImport("__Internal")]
	private static extern void ASE_AdMobDestroyBanner();

	// Token: 0x0600109F RID: 4255 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void DestroyBanner()
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010A0 RID: 4256
	[DllImport("__Internal")]
	private static extern void ASE_AdMobRequestInterstitalAd(string interstitialUnitId);

	// Token: 0x060010A1 RID: 4257 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void RequestInterstitalAd(string interstitialUnitId)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010A2 RID: 4258
	[DllImport("__Internal")]
	private static extern bool ASE_AdMobIsInterstitialAdReady();

	// Token: 0x060010A3 RID: 4259 RVA: 0x0000D301 File Offset: 0x0000B501
	public static bool IsInterstitialAdReady()
	{
		if (ASE_Tools.Available)
		{
		}
		return false;
	}

	// Token: 0x060010A4 RID: 4260
	[DllImport("__Internal")]
	private static extern void ASE_AdMobShowInterstitialAd();

	// Token: 0x060010A5 RID: 4261 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void ShowInterstitialAd()
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010A6 RID: 4262
	[DllImport("__Internal")]
	private static extern void ASE_AdMobSetGameObjectName(string sGameObject);

	// Token: 0x060010A7 RID: 4263
	[DllImport("__Internal")]
	private static extern void ASE_AdMobSetMethodName(string sMethodName);

	// Token: 0x060010A8 RID: 4264 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetGameObjectName(string sGameObjectName)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010A9 RID: 4265 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetMethodName(string sMethodName)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010AA RID: 4266 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetCallbackInformations(string sGameObjectName, string sMethodName)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x02000260 RID: 608
	[Obsolete("AdMobBannerType is deprecated, please use iOSAdMobBannerType instead.")]
	public enum AdMobBannerType
	{
		// Token: 0x04000FD2 RID: 4050
		iPhone_320x50,
		// Token: 0x04000FD3 RID: 4051
		iPad_728x90,
		// Token: 0x04000FD4 RID: 4052
		iPad_468x60,
		// Token: 0x04000FD5 RID: 4053
		iPad_320x250,
		// Token: 0x04000FD6 RID: 4054
		SmartBannerPortrait,
		// Token: 0x04000FD7 RID: 4055
		SmartBannerLandscape
	}

	// Token: 0x02000261 RID: 609
	public enum iOSAdMobBannerType
	{
		// Token: 0x04000FD9 RID: 4057
		iPhone_320x50,
		// Token: 0x04000FDA RID: 4058
		iPad_728x90,
		// Token: 0x04000FDB RID: 4059
		iPad_468x60,
		// Token: 0x04000FDC RID: 4060
		iPad_320x250,
		// Token: 0x04000FDD RID: 4061
		SmartBannerPortrait,
		// Token: 0x04000FDE RID: 4062
		SmartBannerLandscape
	}

	// Token: 0x02000262 RID: 610
	public enum AndroidAdMobBannerType
	{
		// Token: 0x04000FE0 RID: 4064
		phone_320x50,
		// Token: 0x04000FE1 RID: 4065
		tablet_300x250,
		// Token: 0x04000FE2 RID: 4066
		tablet_468x60,
		// Token: 0x04000FE3 RID: 4067
		tablet_728x90,
		// Token: 0x04000FE4 RID: 4068
		SmartBanner
	}

	// Token: 0x02000263 RID: 611
	public enum AdMobEvent
	{
		// Token: 0x04000FE6 RID: 4070
		AD_DID_RECEIVED_AD,
		// Token: 0x04000FE7 RID: 4071
		AD_FAILED_TO_RECEIVED_AD,
		// Token: 0x04000FE8 RID: 4072
		INTERSTITIAL_DID_RECEIVED_AD,
		// Token: 0x04000FE9 RID: 4073
		INTERSTITIAL_FAILED_TO_RECEIVED_AD
	}
}

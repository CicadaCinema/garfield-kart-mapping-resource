﻿using System;
using UnityEngine;

// Token: 0x020000EC RID: 236
public class SpringBonusEntity : BonusEffectEntity
{
	// Token: 0x06000665 RID: 1637 RVA: 0x000068C0 File Offset: 0x00004AC0
	public SpringBonusEntity()
	{
		this.ReactivationDelay = 0f;
		this.m_eItem = EITEM.ITEM_SPRING;
	}

	// Token: 0x06000666 RID: 1638 RVA: 0x000068E5 File Offset: 0x00004AE5
	public override void Awake()
	{
		base.Awake();
		this.m_bSynchronizePosition = true;
		this.SetActive(false);
		base.ActivateGameObject(false);
	}

	// Token: 0x06000667 RID: 1639 RVA: 0x00031F30 File Offset: 0x00030130
	public override void Launch()
	{
		this.m_bBehind = true;
		base.Launch();
		this.SetActive(true);
		base.ActivateGameObject(true);
		if (Network.peerType == NetworkPeerType.Disconnected || Network.isServer)
		{
			this.m_pTransform.position = base.Launcher.Transform.position + base.Launcher.Transform.parent.rotation * new Vector3(0f, 1f, -1.5f);
		}
		this.LauncherCollider = base.Launcher.Transform.parent.collider;
		Physics.IgnoreCollision(this.m_pCollider, this.LauncherCollider, true);
		this.m_fTimerNoCollision = 0f;
		this.m_bOnGround = false;
		if (this.SoundDropped)
		{
			this.SoundDropped.Play();
		}
	}

	// Token: 0x06000668 RID: 1640 RVA: 0x00032014 File Offset: 0x00030214
	public override void Update()
	{
		base.Update();
		if (base.Launcher != null)
		{
			float deltaTime = Time.deltaTime;
			this.m_fTimerNoCollision += deltaTime;
			if (this.m_fTimerNoCollision > 1f)
			{
				Physics.IgnoreCollision(this.m_pCollider, this.LauncherCollider, false);
				base.Launcher = null;
			}
			if ((Network.peerType == NetworkPeerType.Disconnected || Network.isServer) && !this.m_bOnGround)
			{
				float num = this.SpeedBackward / 3.6f;
				base.transform.position += deltaTime * num * Vector3.down;
			}
		}
	}

	// Token: 0x06000669 RID: 1641 RVA: 0x000320C4 File Offset: 0x000302C4
	public override void OnGoodCollision(GameObject other)
	{
		Kart componentInChildren = other.GetComponentInChildren<Kart>();
		if (componentInChildren)
		{
			ParfumeBonusEffect parfumeBonusEffect = (ParfumeBonusEffect)componentInChildren.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(EBonusEffect.BONUSEFFECT_ATTRACTED);
			if (!parfumeBonusEffect.Activated || parfumeBonusEffect.StinkParfume)
			{
				JumpBonusEffect jumpBonusEffect = (JumpBonusEffect)componentInChildren.GetBonusMgr().GetBonusEffectMgr().GetBonusEffect(this.BonusEffect);
				jumpBonusEffect.BackwardJump = true;
				base.OnGoodCollision(other);
			}
		}
		this.SetActive(false);
		base.ActivateGameObject(false);
	}

	// Token: 0x0600066A RID: 1642 RVA: 0x00032148 File Offset: 0x00030348
	public override void DoDestroy()
	{
		base.DoDestroy();
		if (this.SpringUsed)
		{
			this.SpringUsed.transform.position = this.m_pTransform.position;
			this.SpringUsed.Play(true);
		}
		this.SetActive(false);
		base.ActivateGameObject(false);
	}

	// Token: 0x0600066B RID: 1643 RVA: 0x000321A0 File Offset: 0x000303A0
	public override void DoOnTriggerEnter(GameObject other, int otherlayer)
	{
		base.DoOnTriggerEnter(other, otherlayer);
		if ((Network.peerType == NetworkPeerType.Disconnected || Network.isServer) && this.m_bActive)
		{
			int num = 1 << otherlayer;
			if ((num & this.RoadLayer) != 0)
			{
				Ray ray = new Ray(this.m_pTransform.position, Vector3.down);
				RaycastHit raycastHit;
				if (Physics.Raycast(ray, out raycastHit, 5f, this.RoadLayer))
				{
					this.m_pTransform.position = new Vector3(raycastHit.point.x, raycastHit.point.y, raycastHit.point.z);
					Quaternion rotation = default(Quaternion);
					rotation = Quaternion.FromToRotation(this.m_pTransform.rotation * Vector3.up, raycastHit.normal);
					this.m_pTransform.rotation = rotation;
					this.m_bOnGround = true;
				}
			}
		}
	}

	// Token: 0x04000647 RID: 1607
	private float m_fTimerNoCollision;

	// Token: 0x04000648 RID: 1608
	private Collider LauncherCollider;

	// Token: 0x04000649 RID: 1609
	public LayerMask RoadLayer;

	// Token: 0x0400064A RID: 1610
	private bool m_bOnGround;

	// Token: 0x0400064B RID: 1611
	public float SpeedBackward = 50f;

	// Token: 0x0400064C RID: 1612
	public ParticleSystem SpringUsed;

	// Token: 0x0400064D RID: 1613
	public AudioSource SoundDropped;
}

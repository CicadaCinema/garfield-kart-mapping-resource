﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200020F RID: 527
public class RcVehicleSnd : MonoBehaviour, RcCollisionListener
{
	// Token: 0x06000E8D RID: 3725 RVA: 0x0005C600 File Offset: 0x0005A800
	public RcVehicleSnd()
	{
		this.m_pVehicle = null;
		this.m_pGearBox = null;
		this.m_fEngineOriginalRpm = 0f;
		this.m_fSkidVolume = 0f;
		this.m_fBrakeVolume = 0f;
		this.m_fMinDist = 0f;
		this.m_fMaxDist = 0f;
		this.m_fBrakingTimer = 0f;
	}

	// Token: 0x06000E8E RID: 3726 RVA: 0x0000C004 File Offset: 0x0000A204
	public void Awake()
	{
		this.m_pVehicle = base.transform.parent.GetComponentInChildren<RcVehicle>();
		this.m_pGearBox = base.transform.parent.GetComponentInChildren<RcGearBox>();
	}

	// Token: 0x06000E8F RID: 3727 RVA: 0x0000C032 File Offset: 0x0000A232
	public void OnDestroy()
	{
		this.Stop();
	}

	// Token: 0x06000E90 RID: 3728 RVA: 0x0000C03A File Offset: 0x0000A23A
	public virtual void Start()
	{
		if (this.m_pVehicle)
		{
			this.m_pVehicle.AddCollisionListener(this);
		}
		this.ApplyVolume();
	}

	// Token: 0x06000E91 RID: 3729 RVA: 0x0000C05E File Offset: 0x0000A25E
	public void StartSound()
	{
		this.InitSound(0);
	}

	// Token: 0x06000E92 RID: 3730 RVA: 0x0005C67C File Offset: 0x0005A87C
	public void Stop()
	{
		if (this.m_pVehicle)
		{
			this.m_pVehicle.RemoveCollisionListener(this);
			this.m_pVehicle = null;
		}
		for (int i = 0; i < this.SoundsList.Count; i++)
		{
			this.TermSound(i);
		}
	}

	// Token: 0x06000E93 RID: 3731 RVA: 0x0000C067 File Offset: 0x0000A267
	public void InitSound(int _soundIndex)
	{
		if (_soundIndex != 4 && _soundIndex != 5 && _soundIndex != 1)
		{
			this.PlaySound(_soundIndex);
		}
	}

	// Token: 0x06000E94 RID: 3732 RVA: 0x0000C085 File Offset: 0x0000A285
	public void TermSound(int _soundIndex)
	{
		if (this.SoundsList[_soundIndex] != null && this.SoundsList[_soundIndex].isPlaying)
		{
			this.SoundsList[_soundIndex].Stop();
		}
	}

	// Token: 0x06000E95 RID: 3733 RVA: 0x0005C6D0 File Offset: 0x0005A8D0
	public virtual void Update()
	{
		bool flag = this.m_pVehicle.IsOnGround();
		if (this.SoundsList[0] != null)
		{
			float num = this.m_pGearBox.ComputeRpm(this.m_pVehicle.GetWheelSpeedMS());
			this.SoundsList[0].pitch = num / this.m_fEngineOriginalRpm;
		}
		int skidSound = this.GetSkidSound();
		float driftRatio = this.m_pVehicle.GetDriftRatio();
		if (Mathf.Abs(driftRatio) > 0f && this.m_pVehicle.GetGroundSurface() != 0)
		{
			this.PlaySound(skidSound);
			if (this.SoundsList[skidSound] != null)
			{
				this.SoundsList[skidSound].volume = Mathf.Clamp(this.m_fSkidVolume * Mathf.Abs(driftRatio), 0f, 1f);
			}
		}
		else
		{
			this.StopSound(skidSound);
		}
		float num2 = Mathf.Abs(this.m_pVehicle.GetMotorSpeedMS());
		float moveFactor = this.m_pVehicle.GetMoveFactor();
		if (moveFactor <= -0.5f && this.m_pVehicle.GetMotorSpeedMS() > 0f && flag)
		{
			this.m_fBrakingTimer += Time.deltaTime;
		}
		else
		{
			this.m_fBrakingTimer = 0f;
		}
		bool flag2 = this.m_pVehicle.GetDrift() > 0f && this.m_pVehicle.IsOnGround() && this.m_pVehicle.GetMotorSpeedMS() > 0f;
		if (this.m_fBrakingTimer > 0.3f || flag2)
		{
			this.PlaySound(2);
			if (this.SoundsList[2] != null)
			{
				float value = this.m_fBrakingTimer / 2f;
				this.SoundsList[2].volume = Mathf.Clamp(Mathf.Clamp(value, 0f, 1f) * 2f * this.m_fBrakeVolume, 0f, 1f);
			}
		}
		else
		{
			this.StopSound(2);
		}
		for (int i = 0; i < this.SurfaceSoundsList.Count; i++)
		{
			bool flag3 = false;
			if (flag && num2 > 1f)
			{
				for (int j = 0; j < this.m_pVehicle.GetVehiclePhysic().GetNbWheels(); j++)
				{
					int surface = this.m_pVehicle.GetGroundCharac(j).surface;
					if ((1 << surface & this.SurfaceSoundsList[i].Mask.value) != 0 && this.SurfaceSoundsList[i].Sound != null)
					{
						flag3 = true;
						if (!this.SurfaceSoundsList[i].Sound.isPlaying)
						{
							this.SurfaceSoundsList[i].Sound.minDistance = this.m_fMinDist;
							this.SurfaceSoundsList[i].Sound.maxDistance = this.m_fMaxDist;
							this.SurfaceSoundsList[i].Sound.Play();
						}
						this.SurfaceSoundsList[i].Sound.pitch = RcUtils.LinearInterpolation(2f, 0.5f, this.m_pVehicle.GetMaxSpeed(), 2f, num2, true);
					}
				}
			}
			if (this.SurfaceSoundsList[i].Sound != null && this.SurfaceSoundsList[i].Sound.isPlaying && !flag3)
			{
				this.SurfaceSoundsList[i].Sound.Stop();
			}
		}
	}

	// Token: 0x06000E96 RID: 3734 RVA: 0x0005CAA0 File Offset: 0x0005ACA0
	public void PlaySound(int _Sound)
	{
		if (this.SoundsList[_Sound] != null)
		{
			if (this.SoundsList[_Sound].isPlaying)
			{
				if (_Sound == 4 || _Sound == 5 || _Sound == 1)
				{
					this.SoundsList[_Sound].Stop();
					this.SoundsList[_Sound].Play();
				}
			}
			else
			{
				this.SoundsList[_Sound].pitch = 1f;
				this.SoundsList[_Sound].minDistance = this.m_fMinDist;
				this.SoundsList[_Sound].maxDistance = this.m_fMaxDist;
				this.SoundsList[_Sound].Play();
			}
		}
	}

	// Token: 0x06000E97 RID: 3735 RVA: 0x0000C0C5 File Offset: 0x0000A2C5
	public void PlaySoundImmediately(int _Sound)
	{
		if (this.SoundsList[_Sound] != null)
		{
			this.SoundsList[_Sound].Play();
		}
	}

	// Token: 0x06000E98 RID: 3736 RVA: 0x0000C085 File Offset: 0x0000A285
	public void StopSound(int _Sound)
	{
		if (this.SoundsList[_Sound] != null && this.SoundsList[_Sound].isPlaying)
		{
			this.SoundsList[_Sound].Stop();
		}
	}

	// Token: 0x06000E99 RID: 3737 RVA: 0x0005CB6C File Offset: 0x0005AD6C
	public void OnCollision(CollisionData collisionInfo)
	{
		Vector3 a = Vector3.zero;
		Vector3 b = Vector3.zero;
		if (this.m_pVehicle)
		{
			a = this.m_pVehicle.GetVehiclePhysic().GetLinearVelocity();
		}
		if (collisionInfo.other != null)
		{
			b = collisionInfo.other.velocity;
		}
		float f = Vector3.Dot(a - b, collisionInfo.normal);
		if (Mathf.Abs(f) > 2f && !this.m_pVehicle.IsLocked())
		{
			this.PlayCollisionSound(collisionInfo.other != null);
		}
	}

	// Token: 0x06000E9A RID: 3738 RVA: 0x0005CC0C File Offset: 0x0005AE0C
	public virtual void PlayCollisionSound(bool bOther)
	{
		float num = UnityEngine.Random.Range(-0.5f, 0.5f);
		int num2;
		if (bOther)
		{
			num2 = 4;
		}
		else
		{
			num2 = 5;
		}
		this.PlaySound(num2);
		this.SoundsList[num2].pitch = 1f + num;
	}

	// Token: 0x06000E9B RID: 3739 RVA: 0x0000C0EF File Offset: 0x0000A2EF
	public void PauseSounds(bool _Pause)
	{
		if (this.m_pVehicle.AudioListener && this.m_pVehicle.AudioListener.enabled)
		{
			AudioListener.pause = _Pause;
		}
	}

	// Token: 0x06000E9C RID: 3740 RVA: 0x0005CC5C File Offset: 0x0005AE5C
	public virtual void ApplyVolume()
	{
		float sfxVolume = Singleton<GameOptionManager>.Instance.GetSfxVolume();
		for (int i = 0; i < this.SoundsList.Count; i++)
		{
			if (this.SoundsList[i])
			{
				this.SoundsList[i].volume = sfxVolume;
			}
		}
		for (int j = 0; j < this.SurfaceSoundsList.Count; j++)
		{
			if (this.SurfaceSoundsList[j].Sound)
			{
				this.SurfaceSoundsList[j].Sound.volume = sfxVolume;
			}
		}
	}

	// Token: 0x06000E9D RID: 3741 RVA: 0x000042D1 File Offset: 0x000024D1
	public virtual int GetSkidSound()
	{
		return 3;
	}

	// Token: 0x04000DFD RID: 3581
	public const RcVehicleSnd.eVehicleSounds LastVehicleSound = RcVehicleSnd.eVehicleSounds.SND_BOOST;

	// Token: 0x04000DFE RID: 3582
	[HideInInspector]
	public List<AudioSource> SoundsList = new List<AudioSource>();

	// Token: 0x04000DFF RID: 3583
	public List<SurfaceSounds> SurfaceSoundsList = new List<SurfaceSounds>();

	// Token: 0x04000E00 RID: 3584
	protected RcVehicle m_pVehicle;

	// Token: 0x04000E01 RID: 3585
	private RcGearBox m_pGearBox;

	// Token: 0x04000E02 RID: 3586
	private float m_fBrakingTimer;

	// Token: 0x04000E03 RID: 3587
	[HideInInspector]
	public float m_fEngineOriginalRpm;

	// Token: 0x04000E04 RID: 3588
	[HideInInspector]
	public float m_fSkidVolume;

	// Token: 0x04000E05 RID: 3589
	[HideInInspector]
	public float m_fBrakeVolume;

	// Token: 0x04000E06 RID: 3590
	[HideInInspector]
	public float m_fMinDist;

	// Token: 0x04000E07 RID: 3591
	[HideInInspector]
	public float m_fMaxDist;

	// Token: 0x02000210 RID: 528
	public enum eVehicleSounds
	{
		// Token: 0x04000E09 RID: 3593
		SND_MOTOR,
		// Token: 0x04000E0A RID: 3594
		SND_SHIFT,
		// Token: 0x04000E0B RID: 3595
		SND_BRAKE,
		// Token: 0x04000E0C RID: 3596
		SND_SKID,
		// Token: 0x04000E0D RID: 3597
		SND_COLL1,
		// Token: 0x04000E0E RID: 3598
		SND_COLL2,
		// Token: 0x04000E0F RID: 3599
		SND_BOOST
	}
}

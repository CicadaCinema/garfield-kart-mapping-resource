﻿using System;
using UnityEngine;

// Token: 0x02000071 RID: 113
[ExecuteInEditMode]
public class UIFilledSprite : UISprite
{
	// Token: 0x17000073 RID: 115
	// (get) Token: 0x060002E2 RID: 738 RVA: 0x000042D1 File Offset: 0x000024D1
	public override UISprite.Type type
	{
		get
		{
			return UISprite.Type.Filled;
		}
	}
}

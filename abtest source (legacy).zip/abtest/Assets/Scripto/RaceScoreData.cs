﻿using System;

// Token: 0x02000186 RID: 390
public class RaceScoreData
{
	// Token: 0x06000A65 RID: 2661 RVA: 0x000092A6 File Offset: 0x000074A6
	public RaceScoreData(int pKartIndex, bool pIsAI)
	{
		this._kartIndex = pKartIndex;
		this._raceScore = 0;
		this._isAI = pIsAI;
		this._previousPosition = 0;
		this._racePosition = 0;
		this._previousRaceScore = 0;
		this._previousPositionForReset = 0;
	}

	// Token: 0x1700016D RID: 365
	// (get) Token: 0x06000A66 RID: 2662 RVA: 0x000092DF File Offset: 0x000074DF
	public int RaceScore
	{
		get
		{
			return this._raceScore;
		}
	}

	// Token: 0x1700016E RID: 366
	// (get) Token: 0x06000A67 RID: 2663 RVA: 0x000092E7 File Offset: 0x000074E7
	// (set) Token: 0x06000A68 RID: 2664 RVA: 0x000092EF File Offset: 0x000074EF
	public bool IsAI
	{
		get
		{
			return this._isAI;
		}
		set
		{
			this._isAI = value;
		}
	}

	// Token: 0x1700016F RID: 367
	// (get) Token: 0x06000A69 RID: 2665 RVA: 0x000092F8 File Offset: 0x000074F8
	// (set) Token: 0x06000A6A RID: 2666 RVA: 0x00009300 File Offset: 0x00007500
	public int RacePosition
	{
		get
		{
			return this._racePosition;
		}
		set
		{
			this._racePosition = value;
		}
	}

	// Token: 0x17000170 RID: 368
	// (get) Token: 0x06000A6B RID: 2667 RVA: 0x00009309 File Offset: 0x00007509
	public int KartIndex
	{
		get
		{
			return this._kartIndex;
		}
	}

	// Token: 0x17000171 RID: 369
	// (get) Token: 0x06000A6C RID: 2668 RVA: 0x00009311 File Offset: 0x00007511
	public int PreviousRaceScore
	{
		get
		{
			return this._previousRaceScore;
		}
	}

	// Token: 0x17000172 RID: 370
	// (get) Token: 0x06000A6D RID: 2669 RVA: 0x00009319 File Offset: 0x00007519
	public int PreviousRacePosition
	{
		get
		{
			return this._previousPosition;
		}
	}

	// Token: 0x06000A6E RID: 2670 RVA: 0x00009321 File Offset: 0x00007521
	public virtual void RestartRace()
	{
		this._raceScore = this._previousRaceScore;
		this._racePosition = this._previousPosition;
		this._previousPosition = this._previousPositionForReset;
	}

	// Token: 0x06000A6F RID: 2671 RVA: 0x00009347 File Offset: 0x00007547
	public void ResetRace()
	{
		this._raceScore = 0;
		this._previousRaceScore = 0;
	}

	// Token: 0x06000A70 RID: 2672 RVA: 0x00009357 File Offset: 0x00007557
	public virtual bool SetRaceScore(int iScore)
	{
		if (this._raceScore <= 0)
		{
			this._previousRaceScore = this._raceScore;
			this._raceScore += iScore;
			return true;
		}
		return false;
	}

	// Token: 0x06000A71 RID: 2673 RVA: 0x00009382 File Offset: 0x00007582
	public void SetRacePosition(int pPosition)
	{
		this._previousPositionForReset = this._previousPosition;
		this._previousPosition = this._racePosition;
		this._racePosition = pPosition;
	}

	// Token: 0x04000A50 RID: 2640
	private int _raceScore;

	// Token: 0x04000A51 RID: 2641
	private int _previousPosition;

	// Token: 0x04000A52 RID: 2642
	private int _previousPositionForReset;

	// Token: 0x04000A53 RID: 2643
	private int _racePosition;

	// Token: 0x04000A54 RID: 2644
	private bool _isAI;

	// Token: 0x04000A55 RID: 2645
	private int _kartIndex;

	// Token: 0x04000A56 RID: 2646
	private int _previousRaceScore;
}

﻿using System;
using UnityEngine;

// Token: 0x020001BC RID: 444
public class PanelKartIcon : MonoBehaviour
{
	// Token: 0x06000BF8 RID: 3064 RVA: 0x00051CCC File Offset: 0x0004FECC
	public void OnUpdatePanel()
	{
		if (!this.m_oCharacterIcon || !this.m_oHatIcon || !this.m_oKartIcon || !this.m_oCustomIcon)
		{
			return;
		}
		PlayerConfig playerConfig = Singleton<GameConfigurator>.Instance.PlayerConfig;
		KartCarac kartCarac = (KartCarac)Resources.Load("Kart/" + playerConfig.KartPrefab[(int)playerConfig.m_eKart], typeof(KartCarac));
		if (playerConfig.m_oHat.name.Contains("_Def"))
		{
			this.m_oHatIcon.color = this.NoneColor;
		}
		else
		{
			this.m_oHatIcon.color = this.CharacterColor[(int)playerConfig.m_oHat.Character];
		}
		if (playerConfig.m_oKartCustom.name.Contains("_Def"))
		{
			this.m_oCustomIcon.color = this.NoneColor;
		}
		else
		{
			this.m_oCustomIcon.color = this.CharacterColor[(int)playerConfig.m_oKartCustom.Owner];
		}
		this.m_oKartIcon.color = this.CharacterColor[(int)kartCarac.Owner];
		this.m_oCharacterIcon.color = this.CharacterColor[(int)playerConfig.m_eCharacter];
	}

	// Token: 0x04000BD9 RID: 3033
	public UISprite m_oCharacterIcon;

	// Token: 0x04000BDA RID: 3034
	public UISprite m_oKartIcon;

	// Token: 0x04000BDB RID: 3035
	public UISprite m_oCustomIcon;

	// Token: 0x04000BDC RID: 3036
	public UISprite m_oHatIcon;

	// Token: 0x04000BDD RID: 3037
	public Color NoneColor = default(Color);

	// Token: 0x04000BDE RID: 3038
	[HideInInspector]
	public Color[] CharacterColor = new Color[Enum.GetValues(typeof(ECharacter)).Length - 1];
}

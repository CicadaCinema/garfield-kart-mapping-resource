﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000183 RID: 387
public class IGTutorialState : MonoBehaviour
{
	// Token: 0x1700016B RID: 363
	// (get) Token: 0x06000A3C RID: 2620 RVA: 0x000090B1 File Offset: 0x000072B1
	public virtual ETutorialState NextState
	{
		get
		{
			return this.ENextState;
		}
	}

	// Token: 0x06000A3D RID: 2621 RVA: 0x000090B9 File Offset: 0x000072B9
	public virtual bool CanBeDisabled()
	{
		return Time.realtimeSinceStartup >= this.m_fDisablePanelOnTouchTimer + this.DisablePanelOnTouchTimer && this.DisablePanelOnTouch;
	}

	// Token: 0x06000A3E RID: 2622 RVA: 0x000462A4 File Offset: 0x000444A4
	public virtual void OnEnable()
	{
		if (!this.GameMode)
		{
			this.GameMode = (TutorialGameMode)UnityEngine.Object.FindObjectOfType(typeof(TutorialGameMode));
		}
		if (Application.platform == RuntimePlatform.IPhonePlayer || Application.platform == RuntimePlatform.Android)
		{
			foreach (GameObject gameObject in this.PCSpecificObjects)
			{
				gameObject.SetActive(false);
			}
		}
		else
		{
			foreach (GameObject gameObject2 in this.MobileSpecificObjects)
			{
				gameObject2.SetActive(false);
			}
		}
		this.m_fDisablePanelOnTouchTimer = Time.realtimeSinceStartup;
	}

	// Token: 0x06000A3F RID: 2623 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void OnEnter()
	{
	}

	// Token: 0x06000A40 RID: 2624 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void OnExit()
	{
	}

	// Token: 0x06000A41 RID: 2625 RVA: 0x00003B80 File Offset: 0x00001D80
	public virtual void OnDisable()
	{
	}

	// Token: 0x04000A35 RID: 2613
	public ETutorialState ID;

	// Token: 0x04000A36 RID: 2614
	public ETutorialState ENextState;

	// Token: 0x04000A37 RID: 2615
	public List<GameObject> PCSpecificObjects;

	// Token: 0x04000A38 RID: 2616
	public List<GameObject> MobileSpecificObjects;

	// Token: 0x04000A39 RID: 2617
	public float AfterSuccessDelay = 5f;

	// Token: 0x04000A3A RID: 2618
	public float MaxStateTime = 30f;

	// Token: 0x04000A3B RID: 2619
	public bool DisablePanelOnTouch = true;

	// Token: 0x04000A3C RID: 2620
	public float DisablePanelOnTouchTimer = 2f;

	// Token: 0x04000A3D RID: 2621
	private float m_fDisablePanelOnTouchTimer;

	// Token: 0x04000A3E RID: 2622
	[HideInInspector]
	public TutorialGameMode GameMode;
}

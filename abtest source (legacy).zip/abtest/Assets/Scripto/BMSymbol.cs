﻿using System;
using UnityEngine;

// Token: 0x0200003E RID: 62
[Serializable]
public class BMSymbol
{
	// Token: 0x17000025 RID: 37
	// (get) Token: 0x06000146 RID: 326 RVA: 0x00003139 File Offset: 0x00001339
	public int length
	{
		get
		{
			if (this.mLength == 0)
			{
				this.mLength = this.sequence.Length;
			}
			return this.mLength;
		}
	}

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x06000147 RID: 327 RVA: 0x0000315D File Offset: 0x0000135D
	public int offsetX
	{
		get
		{
			return this.mOffsetX;
		}
	}

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x06000148 RID: 328 RVA: 0x00003165 File Offset: 0x00001365
	public int offsetY
	{
		get
		{
			return this.mOffsetY;
		}
	}

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x06000149 RID: 329 RVA: 0x0000316D File Offset: 0x0000136D
	public int width
	{
		get
		{
			return this.mWidth;
		}
	}

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x0600014A RID: 330 RVA: 0x00003175 File Offset: 0x00001375
	public int height
	{
		get
		{
			return this.mHeight;
		}
	}

	// Token: 0x1700002A RID: 42
	// (get) Token: 0x0600014B RID: 331 RVA: 0x0000317D File Offset: 0x0000137D
	public int advance
	{
		get
		{
			return this.mAdvance;
		}
	}

	// Token: 0x1700002B RID: 43
	// (get) Token: 0x0600014C RID: 332 RVA: 0x00003185 File Offset: 0x00001385
	public Rect uvRect
	{
		get
		{
			return this.mUV;
		}
	}

	// Token: 0x0600014D RID: 333 RVA: 0x0000318D File Offset: 0x0000138D
	public void MarkAsDirty()
	{
		this.mIsValid = false;
	}

	// Token: 0x0600014E RID: 334 RVA: 0x00013D58 File Offset: 0x00011F58
	public bool Validate(UIAtlas atlas)
	{
		if (atlas == null)
		{
			return false;
		}
		if (!this.mIsValid)
		{
			if (string.IsNullOrEmpty(this.spriteName))
			{
				return false;
			}
			this.mSprite = ((!(atlas != null)) ? null : atlas.GetSprite(this.spriteName));
			if (this.mSprite != null)
			{
				Texture texture = atlas.texture;
				if (texture == null)
				{
					this.mSprite = null;
				}
				else
				{
					Rect rect = this.mSprite.outer;
					this.mUV = rect;
					if (atlas.coordinates == UIAtlas.Coordinates.Pixels)
					{
						this.mUV = NGUIMath.ConvertToTexCoords(this.mUV, texture.width, texture.height);
					}
					else
					{
						rect = NGUIMath.ConvertToPixels(rect, texture.width, texture.height, true);
					}
					this.mOffsetX = Mathf.RoundToInt(this.mSprite.paddingLeft * rect.width);
					this.mOffsetY = Mathf.RoundToInt(this.mSprite.paddingTop * rect.width);
					this.mWidth = Mathf.RoundToInt(rect.width);
					this.mHeight = Mathf.RoundToInt(rect.height);
					this.mAdvance = Mathf.RoundToInt(rect.width + (this.mSprite.paddingRight + this.mSprite.paddingLeft) * rect.width);
					this.mIsValid = true;
				}
			}
		}
		return this.mSprite != null;
	}

	// Token: 0x04000166 RID: 358
	public string sequence;

	// Token: 0x04000167 RID: 359
	public string spriteName;

	// Token: 0x04000168 RID: 360
	private UIAtlas.Sprite mSprite;

	// Token: 0x04000169 RID: 361
	private bool mIsValid;

	// Token: 0x0400016A RID: 362
	private int mLength;

	// Token: 0x0400016B RID: 363
	private int mOffsetX;

	// Token: 0x0400016C RID: 364
	private int mOffsetY;

	// Token: 0x0400016D RID: 365
	private int mWidth;

	// Token: 0x0400016E RID: 366
	private int mHeight;

	// Token: 0x0400016F RID: 367
	private int mAdvance;

	// Token: 0x04000170 RID: 368
	private Rect mUV;
}

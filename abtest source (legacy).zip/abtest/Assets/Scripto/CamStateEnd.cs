﻿using System;
using UnityEngine;

// Token: 0x020001EA RID: 490
public class CamStateEnd : CamState
{
	// Token: 0x170001CA RID: 458
	// (get) Token: 0x06000D4D RID: 3405 RVA: 0x0000B157 File Offset: 0x00009357
	public override ECamState state
	{
		get
		{
			return ECamState.End;
		}
	}

	// Token: 0x06000D4E RID: 3406 RVA: 0x0000B15A File Offset: 0x0000935A
	public override void Enter(Transform _Transform, Transform _Target)
	{
		base.Enter(_Transform, _Target);
		if (base.m_Target != null)
		{
			base.m_Transform.position = base.m_Target.position + this.Offset;
		}
	}

	// Token: 0x06000D4F RID: 3407 RVA: 0x00057128 File Offset: 0x00055328
	public override ECamState Manage(float dt)
	{
		if (base.m_Target == null)
		{
			GameMode gameMode = Singleton<GameManager>.Instance.GameMode;
			if (gameMode != null)
			{
				GameObject player = gameMode.GetPlayer(0);
				if (player != null)
				{
					base.m_Target = player.transform.Find("cible_camera").transform;
				}
			}
			if (base.m_Target == null)
			{
				return this.state;
			}
			base.m_Transform.position = base.m_Target.position + this.Offset;
		}
		base.m_Transform.RotateAround(base.m_Target.localPosition, Vector3.up, this.Speed * dt);
		Vector3 forward = -base.m_Transform.forward;
		forward.y = 0f;
		base.m_Transform.position = base.m_Target.position + Quaternion.LookRotation(forward) * this.Offset;
		base.m_Transform.LookAt(base.m_Target);
		return this.state;
	}

	// Token: 0x06000D50 RID: 3408 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void Exit()
	{
	}

	// Token: 0x04000CFF RID: 3327
	public Vector3 Offset;

	// Token: 0x04000D00 RID: 3328
	public float Speed;
}

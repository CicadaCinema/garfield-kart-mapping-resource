﻿using System;
using System.IO;
using UnityEngine;

// Token: 0x02000234 RID: 564
public static class Extensions
{
	// Token: 0x06000FDE RID: 4062 RVA: 0x0000CBCA File Offset: 0x0000ADCA
	public static void NullSafe<T>(this T target, Action<T> action)
	{
		if (target != null)
		{
			action(target);
		}
	}

	// Token: 0x06000FDF RID: 4063 RVA: 0x0000CBDE File Offset: 0x0000ADDE
	public static void NullSafeAct<T>(this T pTarget, Action pAction)
	{
		if (pTarget != null)
		{
			pAction();
		}
	}

	// Token: 0x06000FE0 RID: 4064 RVA: 0x0000CBF1 File Offset: 0x0000ADF1
	public static void NullSafeAct<T, T1>(this T pTarget, Action<T1> pAction, T1 pParam1)
	{
		if (pTarget != null)
		{
			pAction(pParam1);
		}
	}

	// Token: 0x06000FE1 RID: 4065 RVA: 0x0000CC05 File Offset: 0x0000AE05
	public static void NullSafeAct<T, T1, T2>(this T pTarget, Action<T1, T2> pAction, T1 pParam1, T2 pParam2)
	{
		if (pTarget != null)
		{
			pAction(pParam1, pParam2);
		}
	}

	// Token: 0x06000FE2 RID: 4066 RVA: 0x0000CC1A File Offset: 0x0000AE1A
	public static void NullSafeAct<T, T1, T2, T3>(this T pTarget, Action<T1, T2, T3> pAction, T1 pParam1, T2 pParam2, T3 pParam3)
	{
		if (pTarget != null)
		{
			pAction(pParam1, pParam2, pParam3);
		}
	}

	// Token: 0x06000FE3 RID: 4067 RVA: 0x0000CC31 File Offset: 0x0000AE31
	public static void NullSafeAct<T, T1, T2, T3, T4>(this T pTarget, Action<T1, T2, T3, T4> pAction, T1 pParam1, T2 pParam2, T3 pParam3, T4 pParam4)
	{
		if (pTarget != null)
		{
			pAction(pParam1, pParam2, pParam3, pParam4);
		}
	}

	// Token: 0x06000FE4 RID: 4068 RVA: 0x000648EC File Offset: 0x00062AEC
	public static TResult NullSafeFunc<T, TResult>(this T pTarget, Func<TResult> pFunc)
	{
		if (pTarget != null)
		{
			return pFunc();
		}
		return default(TResult);
	}

	// Token: 0x06000FE5 RID: 4069 RVA: 0x00064914 File Offset: 0x00062B14
	public static TResult NullSafeFunc<T, TResult, T1>(this T pTarget, Func<T1, TResult> pFunc, T1 pParam1)
	{
		if (pTarget != null)
		{
			return pFunc(pParam1);
		}
		return default(TResult);
	}

	// Token: 0x06000FE6 RID: 4070 RVA: 0x00064940 File Offset: 0x00062B40
	public static TResult NullSafeFunc<T, TResult, T1, T2>(this T pTarget, Func<T1, T2, TResult> pFunc, T1 pParam1, T2 pParam2)
	{
		if (pTarget != null)
		{
			return pFunc(pParam1, pParam2);
		}
		return default(TResult);
	}

	// Token: 0x06000FE7 RID: 4071 RVA: 0x0006496C File Offset: 0x00062B6C
	public static TResult NullSafeFunc<T, TResult, T1, T2, T3>(this T pTarget, Func<T1, T2, T3, TResult> pFunc, T1 pParam1, T2 pParam2, T3 pParam3)
	{
		if (pTarget != null)
		{
			return pFunc(pParam1, pParam2, pParam3);
		}
		return default(TResult);
	}

	// Token: 0x06000FE8 RID: 4072 RVA: 0x00064998 File Offset: 0x00062B98
	public static TResult NullSafeFunc<T, TResult, T1, T2, T3, T4>(this T pTarget, Func<T1, T2, T3, T4, TResult> pFunc, T1 pParam1, T2 pParam2, T3 pParam3, T4 pParam4)
	{
		if (pTarget != null)
		{
			return pFunc(pParam1, pParam2, pParam3, pParam4);
		}
		return default(TResult);
	}

	// Token: 0x06000FE9 RID: 4073 RVA: 0x000649C8 File Offset: 0x00062BC8
	public static string Combine(params string[] pPaths)
	{
		string text = null;
		if (pPaths != null)
		{
			text = pPaths[0];
			for (int i = 1; i < pPaths.Length; i++)
			{
				text = Path.Combine(text, pPaths[i]);
			}
		}
		return text;
	}

	// Token: 0x06000FEA RID: 4074 RVA: 0x00064A00 File Offset: 0x00062C00
	public static void FromAxes(ref Quaternion pQuaternion, Vector3 pXaxis, Vector3 pYaxis, Vector3 pZaxis)
	{
		Matrix4x4 identity = Matrix4x4.identity;
		identity[0, 0] = pXaxis.x;
		identity[1, 0] = pXaxis.y;
		identity[2, 0] = pXaxis.z;
		identity[0, 1] = pYaxis.x;
		identity[1, 1] = pYaxis.y;
		identity[2, 1] = pYaxis.z;
		identity[0, 2] = pZaxis.x;
		identity[1, 2] = pZaxis.y;
		identity[2, 2] = pZaxis.z;
		Extensions.FromRotationMatrix(ref pQuaternion, identity);
	}

	// Token: 0x06000FEB RID: 4075 RVA: 0x00064AAC File Offset: 0x00062CAC
	public static void FromRotationMatrix(ref Quaternion pQuaternion, Matrix4x4 pRotMatrix)
	{
		float num = pRotMatrix[0, 0] + pRotMatrix[1, 1] + pRotMatrix[2, 2];
		if ((double)num > 0.0)
		{
			float num2 = Mathf.Sqrt(num + 1f);
			pQuaternion.w = 0.5f * num2;
			num2 = 0.5f / num2;
			pQuaternion.x = (pRotMatrix[2, 1] - pRotMatrix[1, 2]) * num2;
			pQuaternion.y = (pRotMatrix[0, 2] - pRotMatrix[2, 0]) * num2;
			pQuaternion.z = (pRotMatrix[1, 0] - pRotMatrix[0, 1]) * num2;
		}
		else
		{
			int[] array = new int[3];
			array[0] = 1;
			array[1] = 2;
			int[] array2 = array;
			int num3 = 0;
			if (pRotMatrix[1, 1] > pRotMatrix[0, 0])
			{
				num3 = 1;
			}
			if (pRotMatrix[2, 2] > pRotMatrix[num3, num3])
			{
				num3 = 2;
			}
			int num4 = array2[num3];
			int num5 = array2[num4];
			float num2 = Mathf.Sqrt(pRotMatrix[num3, num3] - pRotMatrix[num4, num4] - pRotMatrix[num5, num5] + 1f);
			float[] array3 = new float[]
			{
				pQuaternion.x,
				pQuaternion.y,
				pQuaternion.z
			};
			array3[num3] = 0.5f * num2;
			num2 = 0.5f / num2;
			pQuaternion.w = (pRotMatrix[num5, num4] - pRotMatrix[num4, num5]) * num2;
			array3[num4] = (pRotMatrix[num4, num3] + pRotMatrix[num3, num4]) * num2;
			array3[num5] = (pRotMatrix[num5, num3] + pRotMatrix[num3, num5]) * num2;
		}
	}

	// Token: 0x06000FEC RID: 4076 RVA: 0x00064C68 File Offset: 0x00062E68
	public static Vector3 Project(this Vector3 pFrom, Vector3 pTo)
	{
		Vector3 normalized = pTo.normalized;
		return Vector3.Dot(pFrom, normalized) * normalized;
	}
}

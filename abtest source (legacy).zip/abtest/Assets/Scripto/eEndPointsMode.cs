﻿using System;

// Token: 0x0200024F RID: 591
public enum eEndPointsMode
{
	// Token: 0x04000FA9 RID: 4009
	AUTO,
	// Token: 0x04000FAA RID: 4010
	AUTOCLOSED,
	// Token: 0x04000FAB RID: 4011
	EXPLICIT
}

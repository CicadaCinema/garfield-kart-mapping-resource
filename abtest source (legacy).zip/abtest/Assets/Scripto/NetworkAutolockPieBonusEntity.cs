﻿using System;
using UnityEngine;

// Token: 0x020000E1 RID: 225
public class NetworkAutolockPieBonusEntity : NetworkPieBonusEntity
{
	// Token: 0x06000615 RID: 1557 RVA: 0x000064C5 File Offset: 0x000046C5
	[RPC]
	public void OnSynchronizeOffRail()
	{
		((AutolockPieBonusEntity)this.m_pBonusEntity).DoSynchronizeOffRail();
	}

	// Token: 0x06000616 RID: 1558 RVA: 0x000064D7 File Offset: 0x000046D7
	[RPC]
	public new void Launch(NetworkViewID launcherViewID, bool _Behind)
	{
		this.NetworkInitialize(launcherViewID);
		((AutolockPieBonusEntity)this.m_pBonusEntity).Launch(this.m_pBonusEntity.Launcher, _Behind);
	}
}

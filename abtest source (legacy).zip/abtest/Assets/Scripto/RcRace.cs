﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200021A RID: 538
public class RcRace : MonoBehaviour
{
	// Token: 0x06000EE2 RID: 3810 RVA: 0x0005DD04 File Offset: 0x0005BF04
	public RcRace()
	{
		this.m_iRaceTime = 0;
		this.m_bEndOfRace = false;
		this.m_iRaceNbCheckPoints = 0;
		this.m_iNbPlayers = 0;
		this.m_pMultiPath = null;
		this.m_pCatchUp = null;
		this.m_pVehicleRaceStats = new List<RcVehicleRaceStats>();
	}

	// Token: 0x06000EE3 RID: 3811 RVA: 0x0000C3C3 File Offset: 0x0000A5C3
	public int GetRaceNbLap()
	{
		return this.m_iRaceNbLap;
	}

	// Token: 0x06000EE4 RID: 3812 RVA: 0x0000C3CB File Offset: 0x0000A5CB
	public int GetRaceNbCheckPoints()
	{
		return this.m_iRaceNbCheckPoints;
	}

	// Token: 0x06000EE5 RID: 3813 RVA: 0x0000C3D3 File Offset: 0x0000A5D3
	public int GetRaceNbPlayers()
	{
		return this.m_iNbPlayers;
	}

	// Token: 0x06000EE6 RID: 3814 RVA: 0x0000C3DB File Offset: 0x0000A5DB
	public void ResetRaceTime()
	{
		this.m_iRaceTime = 0;
	}

	// Token: 0x06000EE7 RID: 3815 RVA: 0x0000C3E4 File Offset: 0x0000A5E4
	public int GetRaceTime()
	{
		return this.m_iRaceTime;
	}

	// Token: 0x06000EE8 RID: 3816 RVA: 0x0005DD54 File Offset: 0x0005BF54
	public void Awake()
	{
		this.AwakeNet();
		this.m_iRaceNbCheckPoints = 0;
		RcPortalTrigger[] array = (RcPortalTrigger[])UnityEngine.Object.FindObjectsOfType(typeof(RcPortalTrigger));
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].m_eActionType == RcPortalTrigger.PortalAction.CheckPoint)
			{
				this.m_iRaceNbCheckPoints++;
			}
		}
		this.m_pMultiPath = (RcMultiPath)UnityEngine.Object.FindObjectOfType(typeof(RcMultiPath));
		this.m_bRaceStarted = false;
	}

	// Token: 0x06000EE9 RID: 3817 RVA: 0x0005DDD4 File Offset: 0x0005BFD4
	public void AddVehicle(RcVehicleRaceStats pStats)
	{
		pStats.SetRaceNbLap(this.m_iRaceNbLap);
		pStats.SetRaceNbCheckPoints(this.m_iRaceNbCheckPoints);
		this.m_pVehicleRaceStats.Add(pStats);
		this.m_iNbPlayers++;
		if (this.m_iRaceTime > 0)
		{
			pStats.GetVehicle().SetLocked(false);
			pStats.StartChrono();
			pStats.RefreshTime(this.m_iRaceTime);
		}
	}

	// Token: 0x06000EEA RID: 3818 RVA: 0x0000C3EC File Offset: 0x0000A5EC
	public void RemoveVehicle(RcVehicleRaceStats pStats)
	{
		this.m_pVehicleRaceStats.Remove(pStats);
		this.m_iNbPlayers--;
	}

	// Token: 0x06000EEB RID: 3819 RVA: 0x0000C409 File Offset: 0x0000A609
	public void Start()
	{
		this.Reset();
		this.m_pCatchUp = base.GetComponent<RcCatchUp>();
	}

	// Token: 0x06000EEC RID: 3820 RVA: 0x0005DE40 File Offset: 0x0005C040
	public RcVehicleRaceStats GetRankedVehicle(int _Rank)
	{
		for (int i = 0; i < this.m_iNbPlayers; i++)
		{
			if (this.m_pVehicleRaceStats[i] && this.m_pVehicleRaceStats[i].GetRank() == _Rank)
			{
				return this.m_pVehicleRaceStats[i];
			}
		}
		return null;
	}

	// Token: 0x06000EED RID: 3821 RVA: 0x0000C41E File Offset: 0x0000A61E
	public void FixedUpdate()
	{
		if (this.m_bRaceStarted)
		{
			this.m_iRaceTime += (int)(Time.fixedDeltaTime * 1000f);
		}
	}

	// Token: 0x06000EEE RID: 3822 RVA: 0x0005DEA0 File Offset: 0x0005C0A0
	public void Update()
	{
		if (this.m_bRaceStarted)
		{
			for (int i = 0; i < this.m_iNbPlayers; i++)
			{
				if (this.m_pVehicleRaceStats[i])
				{
					this.m_pVehicleRaceStats[i].RefreshTime(this.m_iRaceTime);
				}
			}
		}
		if (this.m_pMultiPath)
		{
			float refDistToEndOfRace = 0f;
			if (Singleton<GameManager>.Instance.GameMode)
			{
				if (Network.peerType == NetworkPeerType.Disconnected)
				{
					GameObject humanPlayer = Singleton<GameManager>.Instance.GameMode.GetHumanPlayer();
					if (humanPlayer)
					{
						RcVehicleRaceStats componentInChildren = humanPlayer.GetComponentInChildren<RcVehicleRaceStats>();
						if (componentInChildren)
						{
							refDistToEndOfRace = componentInChildren.GetDistToEndOfRace();
						}
					}
				}
				else if (this.m_pVehicleRaceStats.Count != 0)
				{
					List<RaceScoreData> raceScoreDataList = Singleton<GameConfigurator>.Instance.RankingManager.GetRaceScoreDataList();
					float num = 1E+12f;
					for (int j = 0; j < raceScoreDataList.Count; j++)
					{
						RaceScoreData raceScoreData = raceScoreDataList[j];
						if (raceScoreData != null && !raceScoreData.IsAI && raceScoreData.KartIndex < this.m_pVehicleRaceStats.Count)
						{
							num = Mathf.Min(num, this.m_pVehicleRaceStats[raceScoreData.KartIndex].GetDistToEndOfRace());
						}
					}
					refDistToEndOfRace = num;
				}
			}
			for (int k = 0; k < this.m_iNbPlayers; k++)
			{
				if (this.m_pVehicleRaceStats[k])
				{
					this.m_pMultiPath.RefreshRespawn(this.m_pVehicleRaceStats[k]);
					if (this.m_pCatchUp)
					{
						float distToEndOfRace = this.m_pVehicleRaceStats[k].GetDistToEndOfRace();
						this.m_pCatchUp.ComputeCatchUp(this.m_pVehicleRaceStats[k].GetVehicle(), distToEndOfRace, refDistToEndOfRace);
					}
				}
			}
		}
		this.ComputeRacePositions();
	}

	// Token: 0x06000EEF RID: 3823 RVA: 0x0005E09C File Offset: 0x0005C29C
	public void ComputeRacePositions()
	{
		List<RcVehicleRaceStats> list = new List<RcVehicleRaceStats>();
		for (int i = 0; i < this.m_iNbPlayers; i++)
		{
			if (this.m_pVehicleRaceStats[i])
			{
				list.Add(this.m_pVehicleRaceStats[i]);
			}
		}
		RcRace.VehicleComparer comparer = new RcRace.VehicleComparer();
		list.Sort(comparer);
		for (int j = 0; j < list.Count; j++)
		{
			list[j].SetRank(j);
			if (j == 0)
			{
				list[j].SetPreceding(list[list.Count - 1].GetVehicle());
			}
			else
			{
				list[j].SetPreceding(list[j - 1].GetVehicle());
			}
			if (j == list.Count - 1)
			{
				list[j].SetPursuant(list[0].GetVehicle());
			}
			else
			{
				list[j].SetPursuant(list[j + 1].GetVehicle());
			}
		}
	}

	// Token: 0x06000EF0 RID: 3824 RVA: 0x0000C444 File Offset: 0x0000A644
	public bool Reset()
	{
		this.m_bEndOfRace = false;
		return true;
	}

	// Token: 0x06000EF1 RID: 3825 RVA: 0x0005E1A8 File Offset: 0x0005C3A8
	public void StartRace()
	{
		for (int i = 0; i < this.m_iNbPlayers; i++)
		{
			if (this.m_pVehicleRaceStats[i])
			{
				this.m_pVehicleRaceStats[i].StartChrono();
			}
		}
		this.m_bRaceStarted = true;
	}

	// Token: 0x06000EF2 RID: 3826 RVA: 0x0005E1FC File Offset: 0x0005C3FC
	public void End()
	{
		int num = 0;
		int num2 = 0;
		RcVehicleRaceStats[] array = new RcVehicleRaceStats[this.m_iNbPlayers];
		for (int i = 0; i < this.m_iNbPlayers; i++)
		{
			array[i] = null;
		}
		for (int j = 0; j < this.m_iNbPlayers; j++)
		{
			if (this.m_pVehicleRaceStats[j])
			{
				int worstLap = this.m_pVehicleRaceStats[j].GetWorstLap();
				if (worstLap > num)
				{
					num = worstLap;
				}
				if (this.m_pVehicleRaceStats[j].IsRaceEnded())
				{
					int raceTime = this.m_pVehicleRaceStats[j].GetRaceTime();
					if (raceTime > num2)
					{
						num2 = raceTime;
					}
				}
				array[this.m_pVehicleRaceStats[j].GetRank()] = this.m_pVehicleRaceStats[j];
			}
		}
		for (int k = 0; k < this.m_iNbPlayers; k++)
		{
			if (array[k] && !array[k].IsRaceEnded())
			{
				num2 = array[k].ForceEndRace(num, num2);
			}
		}
		this.m_bEndOfRace = true;
	}

	// Token: 0x06000EF3 RID: 3827 RVA: 0x0005E330 File Offset: 0x0005C530
	public void CrossStartLine(RcVehicleRaceStats pStats, bool _bReverse)
	{
		pStats.CrossStartLine(this.m_iRaceTime, _bReverse);
		if (_bReverse)
		{
			return;
		}
		if (pStats.GetLogicNbLap() >= this.m_iRaceNbLap + 1)
		{
			this.ComputeRacePositions();
			if (pStats.GetRank() == this.m_iNbPlayers)
			{
				this.m_bEndOfRace = true;
			}
		}
		this.ComputeRacePositions();
	}

	// Token: 0x06000EF4 RID: 3828 RVA: 0x0000C44E File Offset: 0x0000A64E
	public void CrossEndLine(RcVehicleRaceStats pStats)
	{
		pStats.CrossEndLine(this.m_iRaceTime);
		if (pStats.GetRank() == this.m_iNbPlayers)
		{
			this.m_bEndOfRace = true;
		}
		this.ComputeRacePositions();
	}

	// Token: 0x06000EF5 RID: 3829 RVA: 0x0000C47A File Offset: 0x0000A67A
	public void CrossCheckPoint(RcVehicleRaceStats pStats, int _Id)
	{
		pStats.CrossCheckPoint(_Id);
	}

	// Token: 0x06000EF6 RID: 3830 RVA: 0x0000C483 File Offset: 0x0000A683
	public void ForceRefreshRespawn(RcVehicleRaceStats pStats)
	{
		this.m_pMultiPath.ResetPosition(ref pStats.m_GuidePosition, pStats.GetVehicle().GetPosition());
	}

	// Token: 0x06000EF7 RID: 3831 RVA: 0x0000C4A1 File Offset: 0x0000A6A1
	private void AwakeNet()
	{
		if (base.networkView == null)
		{
		}
		base.networkView.stateSynchronization = NetworkStateSynchronization.Unreliable;
		base.networkView.observed = base.transform;
	}

	// Token: 0x06000EF8 RID: 3832 RVA: 0x0005E388 File Offset: 0x0005C588
	public void OnSerializeNetworkView(BitStream stream, NetworkMessageInfo info)
	{
		if (!Network.isClient && stream.isWriting)
		{
			stream.Serialize(ref this.m_iRaceTime);
		}
		else if (Network.isClient && !stream.isWriting)
		{
			int num = 0;
			stream.Serialize(ref num);
			this.m_iRaceTime = num + (int)((Network.time - info.timestamp) * 1000.0);
		}
	}

	// Token: 0x06000EF9 RID: 3833 RVA: 0x0005E3FC File Offset: 0x0005C5FC
	public RcVehicleRaceStats GetVehicleStats(NetworkViewID id)
	{
		for (int i = 0; i < this.m_iNbPlayers; i++)
		{
			if (this.m_pVehicleRaceStats[i].transform.parent.gameObject.networkView.viewID == id)
			{
				return this.m_pVehicleRaceStats[i];
			}
		}
		return null;
	}

	// Token: 0x06000EFA RID: 3834 RVA: 0x0000C4D1 File Offset: 0x0000A6D1
	public void OnNetworkLoadedLevel()
	{
		this.StartRace();
	}

	// Token: 0x04000E73 RID: 3699
	protected int m_iRaceTime;

	// Token: 0x04000E74 RID: 3700
	protected List<RcVehicleRaceStats> m_pVehicleRaceStats;

	// Token: 0x04000E75 RID: 3701
	protected bool m_bEndOfRace;

	// Token: 0x04000E76 RID: 3702
	public int m_iRaceNbLap = 3;

	// Token: 0x04000E77 RID: 3703
	private int m_iRaceNbCheckPoints;

	// Token: 0x04000E78 RID: 3704
	protected int m_iNbPlayers;

	// Token: 0x04000E79 RID: 3705
	protected RcMultiPath m_pMultiPath;

	// Token: 0x04000E7A RID: 3706
	protected RcCatchUp m_pCatchUp;

	// Token: 0x04000E7B RID: 3707
	private bool m_bRaceStarted;

	// Token: 0x0200021B RID: 539
	public class VehicleComparer : IComparer<RcVehicleRaceStats>
	{
		// Token: 0x06000EFC RID: 3836 RVA: 0x0005E460 File Offset: 0x0005C660
		public int Compare(RcVehicleRaceStats pa, RcVehicleRaceStats pb)
		{
			if (pa.IsRaceEnded() != pb.IsRaceEnded())
			{
				return (!pa.IsRaceEnded()) ? 1 : -1;
			}
			if (pa.IsRaceEnded() && pb.IsRaceEnded())
			{
				return pa.GetRaceTime() - pb.GetRaceTime();
			}
			return (pa.GetDistToEndOfRace() >= pb.GetDistToEndOfRace()) ? 1 : -1;
		}
	}
}

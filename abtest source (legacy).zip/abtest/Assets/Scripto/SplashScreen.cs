﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

// Token: 0x02000126 RID: 294
public class SplashScreen : MonoBehaviour
{
	// Token: 0x06000809 RID: 2057 RVA: 0x0003CB7C File Offset: 0x0003AD7C
	private void Awake()
	{
		if (Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(Application.dataPath + "/../External/");
			FileInfo[] files = directoryInfo.GetFiles("*.png");
			foreach (FileInfo fileInfo in files)
			{
				WWW www = new WWW("file://" + fileInfo.FullName);
				while (!www.isDone)
				{
				}
				Texture2D texture2D = new Texture2D(1024, 768, TextureFormat.ARGB32, false);
				www.LoadImageIntoTexture(texture2D);
				this.m_vTextures.Add(texture2D);
			}
			this.m_oTweenColor = this.Texture.GetComponent<TweenColor>();
			this.m_oTexture = this.Texture.GetComponent<UITexture>();
		}
	}

	// Token: 0x0600080A RID: 2058 RVA: 0x0003CC54 File Offset: 0x0003AE54
	private void OnDestroy()
	{
		if (this.m_oTexture)
		{
			this.m_oTexture.mainTexture = null;
		}
		foreach (Texture2D obj in this.m_vTextures)
		{
			UnityEngine.Object.Destroy(obj);
		}
	}

	// Token: 0x0600080B RID: 2059 RVA: 0x0003CCCC File Offset: 0x0003AECC
	private void Update()
	{
		if (this.m_vTextures == null || this.m_vTextures.Count == 0)
		{
			Application.LoadLevel("RootScene");
			return;
		}
		if (this.m_iIndex == -1)
		{
			this.m_bFadeIn = true;
			this.m_iIndex = 0;
			this.Texture.SetActive(true);
			this.m_oTexture.mainTexture = this.m_vTextures[this.m_iIndex];
			this.m_oTexture.MakePixelPerfect();
			this.m_oTweenColor.enabled = true;
			this.m_oTweenColor.duration = this.FadeTimer;
			this.m_oTweenColor.Play(true);
		}
		if (this.m_fTimer >= 0f)
		{
			this.m_fTimer += Time.deltaTime;
			if (this.m_fTimer >= this.SplashTimer)
			{
				this.m_bFadeIn = false;
				this.m_oTweenColor.duration = this.FadeTimer - (this.m_fTimer - this.SplashTimer);
				this.m_fTimer = -1f;
				this.m_oTweenColor.Play(false);
			}
		}
	}

	// Token: 0x0600080C RID: 2060 RVA: 0x0003CDE8 File Offset: 0x0003AFE8
	public void DoSplashFinished()
	{
		if (this.m_iIndex == -1)
		{
			return;
		}
		if (this.m_bFadeIn)
		{
			this.m_fTimer = 0f;
		}
		else
		{
			this.Texture.SetActive(false);
			if (this.m_iIndex < this.m_vTextures.Count - 1)
			{
				this.m_iIndex++;
				this.Texture.SetActive(true);
				this.m_oTexture.mainTexture = this.m_vTextures[this.m_iIndex];
				this.m_oTexture.MakePixelPerfect();
				this.m_oTweenColor.enabled = true;
				this.m_oTweenColor.duration = this.FadeTimer;
				this.m_oTweenColor.Play(true);
				this.m_bFadeIn = true;
			}
			else
			{
				Application.LoadLevel("RootScene");
			}
		}
	}

	// Token: 0x04000849 RID: 2121
	public float FadeTimer = 0.5f;

	// Token: 0x0400084A RID: 2122
	public float SplashTimer = 1f;

	// Token: 0x0400084B RID: 2123
	public GameObject Texture;

	// Token: 0x0400084C RID: 2124
	private float m_fTimer = -1f;

	// Token: 0x0400084D RID: 2125
	private bool m_bFadeIn;

	// Token: 0x0400084E RID: 2126
	private int m_iIndex = -1;

	// Token: 0x0400084F RID: 2127
	private TweenColor m_oTweenColor;

	// Token: 0x04000850 RID: 2128
	private UITexture m_oTexture;

	// Token: 0x04000851 RID: 2129
	private List<Texture2D> m_vTextures = new List<Texture2D>();
}

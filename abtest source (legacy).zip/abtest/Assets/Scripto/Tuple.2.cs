﻿using System;

// Token: 0x02000256 RID: 598
[Serializable]
public class Tuple<T1, T2> : Tuple<T1>
{
	// Token: 0x0600107A RID: 4218 RVA: 0x000677C0 File Offset: 0x000659C0
	public Tuple() : this(default(T1), default(T2))
	{
	}

	// Token: 0x0600107B RID: 4219 RVA: 0x0000D177 File Offset: 0x0000B377
	public Tuple(T1 pItem1, T2 pItem2) : base(pItem1)
	{
		this.Item2 = pItem2;
	}

	// Token: 0x04000FBB RID: 4027
	public T2 Item2;
}

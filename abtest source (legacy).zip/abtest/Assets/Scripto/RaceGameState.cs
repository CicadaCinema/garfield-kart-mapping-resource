﻿using System;
using UnityEngine;

// Token: 0x0200016F RID: 367
public class RaceGameState : GameState
{
	// Token: 0x060009E5 RID: 2533 RVA: 0x00044F20 File Offset: 0x00043120
	public void Awake()
	{
		this.networkMgr = (NetworkMgr)UnityEngine.Object.FindObjectOfType(typeof(NetworkMgr));
		GameObject gameObject = GameObject.Find("Race");
		if (gameObject != null)
		{
			this.m_pRace = gameObject.GetComponent<RcRace>();
		}
	}

	// Token: 0x060009E6 RID: 2534 RVA: 0x00044F6C File Offset: 0x0004316C
	public override void Enter()
	{
		for (int i = 0; i < this.m_pGameMode.PlayerCount; i++)
		{
			if (this.m_pGameMode.GetKart(i) != null)
			{
				Kart kart = this.m_pGameMode.GetKart(i);
				kart.SetLocked(false);
				kart.StartRace();
			}
		}
		if (this.m_pRace != null)
		{
			this.m_pRace.StartRace();
		}
		Kart humanKart = this.m_pGameMode.GetHumanKart();
		humanKart.OnRaceEnded = (Action<RcVehicle>)Delegate.Combine(humanKart.OnRaceEnded, new Action<RcVehicle>(this.OnRaceEnded));
		this.selfEnded = false;
		Singleton<GameManager>.Instance.GameMode.MainMusic.Play();
	}

	// Token: 0x060009E7 RID: 2535 RVA: 0x00003B80 File Offset: 0x00001D80
	public override void Exit()
	{
	}

	// Token: 0x060009E8 RID: 2536 RVA: 0x0004502C File Offset: 0x0004322C
	public override void Update()
	{
		if (this.selfEnded)
		{
			if (!this.networkMgr.WaitingSynchronization)
			{
				this.OnStateChanged(E_GameState.End);
			}
			if (!Singleton<GameManager>.Instance.SoundManager.SoundsList[3].isPlaying && !Singleton<GameManager>.Instance.SoundManager.SoundsList[4].isPlaying)
			{
				Singleton<GameManager>.Instance.SoundManager.PlayMusic(ERaceMusicLoops.InterRace);
			}
		}
	}

	// Token: 0x060009E9 RID: 2537 RVA: 0x000450B0 File Offset: 0x000432B0
	protected void OnRaceEnded(RcVehicle pVehicle)
	{
		if (Network.peerType == NetworkPeerType.Disconnected)
		{
			this.OnStateChanged(E_GameState.End);
		}
		else
		{
			this.selfEnded = true;
			this.networkMgr.StartSynchronization();
		}
		Camera.main.GetComponent<CameraBase>().SwitchCamera(ECamState.End, ECamState.TransCut);
		Singleton<GameManager>.Instance.GameMode.MainMusic.Stop();
	}

	// Token: 0x04000A00 RID: 2560
	private bool selfEnded;

	// Token: 0x04000A01 RID: 2561
	private RcRace m_pRace;

	// Token: 0x04000A02 RID: 2562
	private NetworkMgr networkMgr;
}

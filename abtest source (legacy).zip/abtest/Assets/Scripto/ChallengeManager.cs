﻿using System;
using UnityEngine;

// Token: 0x020000AD RID: 173
public class ChallengeManager : Singleton<ChallengeManager>
{
	// Token: 0x170000C9 RID: 201
	// (get) Token: 0x06000441 RID: 1089 RVA: 0x000051F9 File Offset: 0x000033F9
	public bool IsMonday
	{
		get
		{
			return this.m_bIsMonday;
		}
	}

	// Token: 0x170000CA RID: 202
	// (get) Token: 0x06000442 RID: 1090 RVA: 0x00005201 File Offset: 0x00003401
	public bool IsActive
	{
		get
		{
			return this.m_bIsChallengeActive;
		}
	}

	// Token: 0x170000CB RID: 203
	// (get) Token: 0x06000443 RID: 1091 RVA: 0x00005209 File Offset: 0x00003409
	public E_GameModeType GameMode
	{
		get
		{
			return this.m_eGameMode;
		}
	}

	// Token: 0x170000CC RID: 204
	// (get) Token: 0x06000444 RID: 1092 RVA: 0x00005211 File Offset: 0x00003411
	public bool Success
	{
		get
		{
			return this.m_eState == EChallengeState.Succeeded;
		}
	}

	// Token: 0x170000CD RID: 205
	// (get) Token: 0x06000445 RID: 1093 RVA: 0x0000521C File Offset: 0x0000341C
	public ChampionShipData ChampionshipData
	{
		get
		{
			return this.m_pChampionshipImposed;
		}
	}

	// Token: 0x170000CE RID: 206
	// (get) Token: 0x06000446 RID: 1094 RVA: 0x00005224 File Offset: 0x00003424
	public EDifficulty Difficulty
	{
		get
		{
			return this.m_eDifficulty;
		}
	}

	// Token: 0x170000CF RID: 207
	// (get) Token: 0x06000447 RID: 1095 RVA: 0x0000522C File Offset: 0x0000342C
	public string Reward
	{
		get
		{
			return this.m_sReward;
		}
	}

	// Token: 0x170000D0 RID: 208
	// (get) Token: 0x06000448 RID: 1096 RVA: 0x00005234 File Offset: 0x00003434
	public E_RewardType RewardType
	{
		get
		{
			return this.m_eRewardType;
		}
	}

	// Token: 0x170000D1 RID: 209
	// (get) Token: 0x06000449 RID: 1097 RVA: 0x0000523C File Offset: 0x0000343C
	public ERarity RewardRarity
	{
		get
		{
			return this.m_eRarity;
		}
	}

	// Token: 0x170000D2 RID: 210
	// (get) Token: 0x0600044A RID: 1098 RVA: 0x00005244 File Offset: 0x00003444
	public int TrackIndex
	{
		get
		{
			return this.m_iTrackImposed;
		}
	}

	// Token: 0x170000D3 RID: 211
	// (get) Token: 0x0600044B RID: 1099 RVA: 0x0000524C File Offset: 0x0000344C
	public bool SuccessFirstObjective
	{
		get
		{
			return this.m_bSuccesFirstObjective;
		}
	}

	// Token: 0x170000D4 RID: 212
	// (get) Token: 0x0600044C RID: 1100 RVA: 0x00005254 File Offset: 0x00003454
	public bool SuccessSecondObjective
	{
		get
		{
			return this.m_bSuccesSecondObjective;
		}
	}

	// Token: 0x170000D5 RID: 213
	// (get) Token: 0x0600044D RID: 1101 RVA: 0x0000525C File Offset: 0x0000345C
	public E_TimeTrialMedal MedalImposed
	{
		get
		{
			return this.m_eMedalImposed;
		}
	}

	// Token: 0x170000D6 RID: 214
	// (get) Token: 0x0600044E RID: 1102 RVA: 0x00005264 File Offset: 0x00003464
	public bool AlreadyPlayed
	{
		get
		{
			return this.m_eState != EChallengeState.NotPlayed;
		}
	}

	// Token: 0x170000D7 RID: 215
	// (get) Token: 0x0600044F RID: 1103 RVA: 0x00005272 File Offset: 0x00003472
	public bool CurrentSuccess
	{
		get
		{
			return !this.m_bCurrentFailed;
		}
	}

	// Token: 0x06000450 RID: 1104 RVA: 0x0000527D File Offset: 0x0000347D
	public void ForceInit(bool _Monday)
	{
		this.m_bForceMonday = _Monday;
		this.m_bForceInit = true;
		this.Init();
	}

	// Token: 0x06000451 RID: 1105 RVA: 0x000267C8 File Offset: 0x000249C8
	public void Init()
	{
		string b = DateTime.Today.ToString("ddMMyyyy");
		bool flag = false;
		string a;
		string str;
		Singleton<GameSaveManager>.Instance.GetChallengeInfos(out a, out this.m_eGameMode, out this.m_eFirstObjective, out this.m_eCharacterToBeat, out this.m_eSingleRaceObjective, out this.m_eChampionshipObjective, out this.m_eMedalImposed, out this.m_eCharacterImposed, out this.m_eKartImposed, out str, out this.m_iTrackImposed, out this.m_eState, out this.m_bIsMonday, out this.m_eDifficulty, out this.m_sReward, out this.m_eRewardType, out this.m_eRarity);
		if (a != b || this.m_bForceInit)
		{
			flag = true;
			this.m_bForceInit = false;
		}
		if (flag)
		{
			this.m_bIsMonday = (DateTime.Now.DayOfWeek == DayOfWeek.Monday || this.m_bForceMonday);
			this.m_eGameMode = (E_GameModeType)Singleton<RandomManager>.Instance.Next((int)GameManager.FirstRealGameMode, (int)GameManager.LastRealGameMode);
			this.m_eDifficulty = ((!this.m_bIsMonday) ? EDifficulty.NORMAL : EDifficulty.HARD);
			Singleton<RewardManager>.Instance.GetChallengeReward(this.m_bIsMonday, ref this.m_sReward, ref this.m_eRewardType, ref this.m_eRarity);
		}
		if (this.m_eGameMode != E_GameModeType.TIME_TRIAL)
		{
			if (flag)
			{
				this.m_eFirstObjective = (EChallengeFirstObjective)UnityEngine.Random.Range(0, Enum.GetValues(typeof(EChallengeFirstObjective)).Length);
			}
			if (this.m_eFirstObjective == EChallengeFirstObjective.FinishAtPosX)
			{
				this.m_iPosToFinish = ((!this.m_bIsMonday) ? 2 : 1);
			}
			else if (this.m_eFirstObjective == EChallengeFirstObjective.FinishBeforeX && flag)
			{
				this.m_eCharacterToBeat = (ECharacter)UnityEngine.Random.Range(0, Enum.GetValues(typeof(ECharacter)).Length - 1);
			}
			if (this.m_eGameMode == E_GameModeType.SINGLE)
			{
				if (flag)
				{
					this.m_eSingleRaceObjective = (EChallengeSingleRaceObjective)UnityEngine.Random.Range(0, Enum.GetValues(typeof(EChallengeSingleRaceObjective)).Length);
				}
			}
			else if (this.m_eGameMode == E_GameModeType.CHAMPIONSHIP && flag)
			{
				this.m_eChampionshipObjective = (EChallengeChampionshipObjective)UnityEngine.Random.Range(0, Enum.GetValues(typeof(EChallengeChampionshipObjective)).Length);
			}
			if ((this.m_eGameMode == E_GameModeType.SINGLE && this.m_eSingleRaceObjective == EChallengeSingleRaceObjective.EarnXCoins) || (this.m_eGameMode == E_GameModeType.CHAMPIONSHIP && this.m_eChampionshipObjective == EChallengeChampionshipObjective.EarnXCoins))
			{
				this.m_iCoinsToEarn = ((!this.m_bIsMonday) ? 5 : 10);
			}
			else if (this.m_eChampionshipObjective == EChallengeChampionshipObjective.FinishAllAtPosX)
			{
				this.m_iPosToFinishForAll = ((!this.m_bIsMonday) ? 2 : 1);
			}
		}
		else if (this.m_bIsMonday)
		{
			this.m_eMedalImposed = E_TimeTrialMedal.Gold;
		}
		else if (flag)
		{
			this.m_eMedalImposed = (E_TimeTrialMedal)UnityEngine.Random.Range(1, Enum.GetValues(typeof(E_TimeTrialMedal)).Length - 1);
		}
		if (this.m_bIsMonday || (this.m_eGameMode != E_GameModeType.TIME_TRIAL && this.m_eFirstObjective == EChallengeFirstObjective.FinishBeforeX))
		{
			if (flag)
			{
				if (this.m_eGameMode != E_GameModeType.TIME_TRIAL && this.m_eFirstObjective == EChallengeFirstObjective.FinishBeforeX)
				{
					this.ChooseOppositeCharacter();
				}
				else
				{
					this.m_eCharacterImposed = (ECharacter)UnityEngine.Random.Range(0, Enum.GetValues(typeof(ECharacter)).Length - 1);
				}
				this.m_eKartImposed = (ECharacter)UnityEngine.Random.Range(0, Enum.GetValues(typeof(ECharacter)).Length - 1);
			}
			UnityEngine.Object[] array = Resources.LoadAll("Kart");
			foreach (UnityEngine.Object @object in array)
			{
				if (@object is GameObject)
				{
					GameObject gameObject = (GameObject)@object;
					if (gameObject.name.Contains("_Def"))
					{
						KartCustom component = gameObject.GetComponent<KartCustom>();
						if (component != null)
						{
							ECharacter character = component.Character;
							if (character == this.m_eKartImposed)
							{
								this.m_pCustoImposed = component;
								break;
							}
						}
					}
				}
			}
			UnityEngine.Object[] array3 = Resources.LoadAll("Hat");
			foreach (UnityEngine.Object object2 in array3)
			{
				if (object2 is GameObject)
				{
					GameObject gameObject2 = (GameObject)object2;
					if (gameObject2.name.Contains("_Def"))
					{
						BonusCustom component2 = gameObject2.GetComponent<BonusCustom>();
						if (component2 != null)
						{
							ECharacter character2 = component2.Character;
							if (character2 == this.m_eCharacterImposed)
							{
								this.m_pHatImposed = component2;
								break;
							}
						}
					}
				}
			}
		}
		if (flag)
		{
			this.m_pChampionshipImposed = null;
			int num = 0;
			while (this.m_pChampionshipImposed == null)
			{
				num++;
				UnityEngine.Object[] array5 = Resources.LoadAll("ChampionShip", typeof(ChampionShipData));
				int num2 = UnityEngine.Random.Range(0, array5.Length);
				if (array5[num2] is ChampionShipData)
				{
					ChampionShipData championShipData = (ChampionShipData)array5[num2];
					if ((this.m_eDifficulty == EDifficulty.NORMAL && (championShipData.NormalState == E_UnlockableItemSate.NewUnlocked || championShipData.NormalState == E_UnlockableItemSate.Unlocked)) || (this.m_eDifficulty == EDifficulty.HARD && (championShipData.HardState == E_UnlockableItemSate.NewUnlocked || championShipData.HardState == E_UnlockableItemSate.Unlocked)))
					{
						this.m_pChampionshipImposed = (ChampionShipData)array5[num2];
						if (this.m_eGameMode != E_GameModeType.CHAMPIONSHIP)
						{
							this.m_iTrackImposed = UnityEngine.Random.Range(0, this.m_pChampionshipImposed.Tracks.Length);
						}
						else
						{
							this.m_iTrackImposed = 0;
						}
					}
					if (num >= 20)
					{
						this.m_pChampionshipImposed = (ChampionShipData)array5[0];
						if (this.m_eGameMode != E_GameModeType.CHAMPIONSHIP)
						{
							this.m_iTrackImposed = UnityEngine.Random.Range(0, this.m_pChampionshipImposed.Tracks.Length);
						}
						else
						{
							this.m_iTrackImposed = 0;
						}
					}
				}
			}
		}
		else
		{
			this.m_pChampionshipImposed = (ChampionShipData)Resources.Load("ChampionShip/" + str, typeof(ChampionShipData));
		}
		this.m_pChampionshipImposed.Localize();
		if (flag)
		{
			this.m_eState = EChallengeState.NotPlayed;
			Singleton<GameSaveManager>.Instance.SetChallengeInfos(this.m_eGameMode, this.m_eFirstObjective, this.m_eCharacterToBeat, this.m_eSingleRaceObjective, this.m_eChampionshipObjective, this.m_eMedalImposed, this.m_eCharacterImposed, this.m_eKartImposed, this.m_pChampionshipImposed.name, this.m_iTrackImposed, this.m_eState, this.m_bIsMonday, this.m_eDifficulty, this.m_sReward, this.m_eRewardType, this.m_eRarity, true);
		}
		this.m_iTimer = 0f;
	}

	// Token: 0x06000452 RID: 1106 RVA: 0x00005293 File Offset: 0x00003493
	public void SetTried()
	{
		if (this.m_eState == EChallengeState.NotPlayed)
		{
			this.m_eState = EChallengeState.Failed;
		}
	}

	// Token: 0x06000453 RID: 1107 RVA: 0x00026E4C File Offset: 0x0002504C
	public void Launch()
	{
		this.m_bIsChallengeActive = true;
		this.m_bCurrentFailed = false;
		this.m_iTimer = 0f;
		this.m_bSuccesFirstObjective = false;
		this.m_bSuccesSecondObjective = false;
		if ((this.m_bIsMonday && this.m_eGameMode != E_GameModeType.TIME_TRIAL) || (this.m_eGameMode != E_GameModeType.TIME_TRIAL && this.m_eFirstObjective == EChallengeFirstObjective.FinishBeforeX))
		{
			Singleton<GameConfigurator>.Instance.PlayerConfig.Character = this.m_eCharacterImposed;
			Singleton<GameConfigurator>.Instance.PlayerConfig.Kart = this.m_eKartImposed;
			Singleton<GameConfigurator>.Instance.PlayerConfig.m_oHat = this.m_pHatImposed;
			Singleton<GameConfigurator>.Instance.PlayerConfig.m_oKartCustom = this.m_pCustoImposed;
		}
		Singleton<GameConfigurator>.Instance.StartScene = this.m_pChampionshipImposed.Tracks[this.m_iTrackImposed];
		Singleton<GameConfigurator>.Instance.CurrentTrackIndex = this.m_iTrackImposed;
		Singleton<GameConfigurator>.Instance.SetChampionshipData(this.m_pChampionshipImposed, false);
		Singleton<GameConfigurator>.Instance.GameModeType = this.m_eGameMode;
		Singleton<GameConfigurator>.Instance.Difficulty = this.m_eDifficulty;
		Singleton<GameSaveManager>.Instance.SetChallengeInfos(this.m_eGameMode, this.m_eFirstObjective, this.m_eCharacterToBeat, this.m_eSingleRaceObjective, this.m_eChampionshipObjective, this.m_eMedalImposed, this.m_eCharacterImposed, this.m_eKartImposed, this.m_pChampionshipImposed.name, this.m_iTrackImposed, this.m_eState, this.m_bIsMonday, this.m_eDifficulty, this.m_sReward, this.m_eRewardType, this.m_eRarity, true);
		if ((this.m_bIsMonday && this.m_eGameMode != E_GameModeType.TIME_TRIAL) || (this.m_eGameMode != E_GameModeType.TIME_TRIAL && this.m_eFirstObjective == EChallengeFirstObjective.FinishBeforeX))
		{
			LoadingManager.LoadLevel(Singleton<GameConfigurator>.Instance.StartScene);
		}
		else
		{
			MenuEntryPoint component = GameObject.Find("MenuEntryPoint").GetComponent<MenuEntryPoint>();
			component.SetState(EMenus.MENU_SELECT_KART, 2);
		}
	}

	// Token: 0x06000454 RID: 1108 RVA: 0x000052A7 File Offset: 0x000034A7
	public void DeActivate()
	{
		this.m_bIsChallengeActive = false;
	}

	// Token: 0x06000455 RID: 1109 RVA: 0x0002702C File Offset: 0x0002522C
	public void Update()
	{
		if (this.m_bCurrentFailed && this.m_iTimer >= 0f)
		{
			this.m_iTimer += Time.deltaTime;
			if (this.m_iTimer >= 2f)
			{
				if (Singleton<GameManager>.Instance.GameMode != null)
				{
					Singleton<GameManager>.Instance.GameMode.FailedChallenge();
				}
				this.m_iTimer = -1f;
			}
		}
	}

	// Token: 0x06000456 RID: 1110 RVA: 0x000270A8 File Offset: 0x000252A8
	public void CheckSuccess()
	{
		if (!this.m_bCurrentFailed)
		{
			if (this.m_eGameMode == E_GameModeType.TIME_TRIAL)
			{
				if (Singleton<GameManager>.Instance.GameMode is TimeTrialGameMode)
				{
					E_TimeTrialMedal eMedalImposed = this.m_eMedalImposed;
					if (!TimeTrialGameMode.BeatTime(eMedalImposed))
					{
						this.ImmediateFailed();
						this.m_bSuccesFirstObjective = false;
						return;
					}
					this.m_bSuccesFirstObjective = true;
				}
			}
			else
			{
				this.m_bSuccesFirstObjective = true;
				this.m_bSuccesSecondObjective = true;
				bool flag = false;
				int num = -1;
				Kart humanKart = Singleton<GameManager>.Instance.GameMode.GetHumanKart();
				if (humanKart != null)
				{
					RcVehicleRaceStats raceStats = humanKart.RaceStats;
					num = raceStats.GetRank();
				}
				if (this.m_eGameMode == E_GameModeType.SINGLE || Singleton<GameConfigurator>.Instance.CurrentTrackIndex == 3)
				{
					if (this.m_eFirstObjective == EChallengeFirstObjective.FinishBeforeX)
					{
						Kart kart = Singleton<GameManager>.Instance.GameMode.GetKart(this.m_eCharacterToBeat, true);
						if (kart != null)
						{
							RcVehicleRaceStats raceStats2 = kart.RaceStats;
							if (raceStats2.GetRank() < num)
							{
								flag = true;
								this.m_bSuccesFirstObjective = false;
							}
						}
					}
					else if (this.m_eFirstObjective == EChallengeFirstObjective.FinishAtPosX && this.m_iPosToFinish < num)
					{
						flag = true;
						this.m_bSuccesFirstObjective = false;
					}
				}
				if (((this.m_eGameMode == E_GameModeType.SINGLE && this.m_eSingleRaceObjective == EChallengeSingleRaceObjective.EarnXCoins) || (this.m_eGameMode == E_GameModeType.CHAMPIONSHIP && this.m_eChampionshipObjective == EChallengeChampionshipObjective.EarnXCoins)) && Singleton<RewardManager>.Instance.RaceCoins < this.m_iCoinsToEarn)
				{
					flag = true;
					this.m_bSuccesSecondObjective = false;
				}
				if (this.m_eGameMode == E_GameModeType.CHAMPIONSHIP && this.m_eChampionshipObjective == EChallengeChampionshipObjective.FinishAllAtPosX && this.m_iPosToFinishForAll < num)
				{
					flag = true;
					this.m_bSuccesSecondObjective = false;
				}
				if (flag)
				{
					this.ImmediateFailed();
					return;
				}
			}
			if (this.m_eGameMode != E_GameModeType.CHAMPIONSHIP || (this.m_eGameMode == E_GameModeType.CHAMPIONSHIP && Singleton<GameConfigurator>.Instance.CurrentTrackIndex == 3))
			{
				this.m_eState = EChallengeState.Succeeded;
				Singleton<RewardManager>.Instance.EndChallenge(true, this.m_sReward, this.m_eRewardType, this.m_eRarity);
				Singleton<GameSaveManager>.Instance.SetChallengeInfos(this.m_eGameMode, this.m_eFirstObjective, this.m_eCharacterToBeat, this.m_eSingleRaceObjective, this.m_eChampionshipObjective, this.m_eMedalImposed, this.m_eCharacterImposed, this.m_eKartImposed, this.m_pChampionshipImposed.name, this.m_iTrackImposed, this.m_eState, this.m_bIsMonday, this.m_eDifficulty, this.m_sReward, this.m_eRewardType, this.m_eRarity, true);
			}
		}
	}

	// Token: 0x06000457 RID: 1111 RVA: 0x00027320 File Offset: 0x00025520
	public void ImmediateFailed()
	{
		this.m_bCurrentFailed = true;
		if (this.m_eState != EChallengeState.Succeeded)
		{
			this.m_eState = EChallengeState.Failed;
		}
		Singleton<GameSaveManager>.Instance.SetChallengeInfos(this.m_eGameMode, this.m_eFirstObjective, this.m_eCharacterToBeat, this.m_eSingleRaceObjective, this.m_eChampionshipObjective, this.m_eMedalImposed, this.m_eCharacterImposed, this.m_eKartImposed, this.m_pChampionshipImposed.name, this.m_iTrackImposed, this.m_eState, this.m_bIsMonday, this.m_eDifficulty, this.m_sReward, this.m_eRewardType, this.m_eRarity, true);
	}

	// Token: 0x06000458 RID: 1112 RVA: 0x000052B0 File Offset: 0x000034B0
	public void Notify(EChallengeSingleRaceObjective _Objective)
	{
		if (this.m_eGameMode == E_GameModeType.SINGLE && this.m_eSingleRaceObjective == _Objective)
		{
			this.ImmediateFailed();
		}
	}

	// Token: 0x06000459 RID: 1113 RVA: 0x000273B8 File Offset: 0x000255B8
	public void GetLocalizedObjectives(out string _First, out string _Second)
	{
		_First = null;
		_Second = null;
		if (this.m_eGameMode == E_GameModeType.TIME_TRIAL)
		{
			_First = Localization.instance.Get("MENU_CHALLENGE_TIMETRIAL") + " " + Localization.instance.Get("MENU_REWARDS_MEDAL" + (int)this.m_eMedalImposed);
		}
		else
		{
			if (this.m_eFirstObjective == EChallengeFirstObjective.FinishAtPosX)
			{
				_First = string.Format(Localization.instance.Get("MENU_CHALLENGE_FIRST_OBJ2"), this.m_iPosToFinish + 1);
			}
			else if (this.m_eFirstObjective == EChallengeFirstObjective.FinishBeforeX)
			{
				if (this.m_eGameMode == E_GameModeType.SINGLE)
				{
					_First = string.Format(Localization.instance.Get("MENU_CHALLENGE_FIRST_OBJ1"), this.m_eCharacterToBeat.ToString());
				}
				else
				{
					_First = string.Format(Localization.instance.Get("MENU_CHALLENGE_FIRST_OBJ1B"), this.m_eCharacterToBeat.ToString());
				}
			}
			if (this.m_eGameMode == E_GameModeType.SINGLE)
			{
				switch (this.m_eSingleRaceObjective)
				{
				case EChallengeSingleRaceObjective.EarnXCoins:
					_Second = string.Format(Localization.instance.Get("MENU_CHALLENGE_SECOND_OBJ1"), this.m_iCoinsToEarn);
					break;
				case EChallengeSingleRaceObjective.NoDrift:
					_Second = Localization.instance.Get("MENU_CHALLENGE_SECOND_OBJ2");
					break;
				case EChallengeSingleRaceObjective.NoBonus:
					_Second = Localization.instance.Get("MENU_CHALLENGE_SECOND_OBJ3");
					break;
				case EChallengeSingleRaceObjective.NoFall:
					_Second = Localization.instance.Get("MENU_CHALLENGE_SECOND_OBJ4");
					break;
				}
			}
			else if (this.m_eGameMode == E_GameModeType.CHAMPIONSHIP)
			{
				EChallengeChampionshipObjective eChampionshipObjective = this.m_eChampionshipObjective;
				if (eChampionshipObjective != EChallengeChampionshipObjective.EarnXCoins)
				{
					if (eChampionshipObjective == EChallengeChampionshipObjective.FinishAllAtPosX)
					{
						_Second = string.Format(Localization.instance.Get("MENU_CHALLENGE_SECOND_OBJ5"), this.m_iPosToFinishForAll + 1);
					}
				}
				else
				{
					_Second = string.Format(Localization.instance.Get("MENU_CHALLENGE_SECOND_OBJ1_2"), this.m_iCoinsToEarn);
				}
			}
		}
	}

	// Token: 0x0600045A RID: 1114 RVA: 0x000052D0 File Offset: 0x000034D0
	public bool GetSomeoneToBeat()
	{
		return this.m_eFirstObjective == EChallengeFirstObjective.FinishBeforeX;
	}

	// Token: 0x0600045B RID: 1115 RVA: 0x000052DB File Offset: 0x000034DB
	public ECharacter GetCharacterToBeat()
	{
		return this.m_eCharacterToBeat;
	}

	// Token: 0x0600045C RID: 1116 RVA: 0x000275C0 File Offset: 0x000257C0
	public void ChooseOppositeCharacter()
	{
		switch (this.m_eCharacterToBeat)
		{
		case ECharacter.GARFIELD:
		{
			int num = UnityEngine.Random.Range(0, 3);
			if (num == 0)
			{
				this.m_eCharacterImposed = ECharacter.ARLENE;
			}
			else if (num == 1)
			{
				this.m_eCharacterImposed = ECharacter.ODIE;
			}
			else if (num == 2)
			{
				this.m_eCharacterImposed = ECharacter.NERMAL;
			}
			break;
		}
		case ECharacter.JON:
			this.m_eCharacterImposed = ECharacter.LIZ;
			break;
		case ECharacter.LIZ:
			this.m_eCharacterImposed = ECharacter.JON;
			break;
		case ECharacter.ODIE:
		case ECharacter.ARLENE:
		case ECharacter.NERMAL:
			this.m_eCharacterImposed = ECharacter.GARFIELD;
			break;
		case ECharacter.SQUEAK:
			this.m_eCharacterImposed = ECharacter.HARRY;
			break;
		case ECharacter.HARRY:
			this.m_eCharacterImposed = ECharacter.SQUEAK;
			break;
		}
	}

	// Token: 0x04000400 RID: 1024
	public const int FinishPosNoMonday = 2;

	// Token: 0x04000401 RID: 1025
	public const int FinishPosMonday = 1;

	// Token: 0x04000402 RID: 1026
	public const int FinishPosForAllMonday = 1;

	// Token: 0x04000403 RID: 1027
	public const int FinishPosForAllNoMonday = 2;

	// Token: 0x04000404 RID: 1028
	public const int EarnCoinsNoMonday = 5;

	// Token: 0x04000405 RID: 1029
	public const int EarnCoinsMonday = 10;

	// Token: 0x04000406 RID: 1030
	public const float TimerToShowFailedScreen = 2f;

	// Token: 0x04000407 RID: 1031
	private bool m_bIsMonday;

	// Token: 0x04000408 RID: 1032
	private EChallengeChampionshipObjective m_eChampionshipObjective;

	// Token: 0x04000409 RID: 1033
	private EChallengeFirstObjective m_eFirstObjective;

	// Token: 0x0400040A RID: 1034
	private EChallengeSingleRaceObjective m_eSingleRaceObjective;

	// Token: 0x0400040B RID: 1035
	private E_GameModeType m_eGameMode;

	// Token: 0x0400040C RID: 1036
	private ECharacter m_eCharacterToBeat;

	// Token: 0x0400040D RID: 1037
	private ECharacter m_eCharacterImposed;

	// Token: 0x0400040E RID: 1038
	private ECharacter m_eKartImposed;

	// Token: 0x0400040F RID: 1039
	private BonusCustom m_pHatImposed;

	// Token: 0x04000410 RID: 1040
	private KartCustom m_pCustoImposed;

	// Token: 0x04000411 RID: 1041
	private int m_iPosToFinish;

	// Token: 0x04000412 RID: 1042
	private int m_iPosToFinishForAll;

	// Token: 0x04000413 RID: 1043
	private int m_iCoinsToEarn;

	// Token: 0x04000414 RID: 1044
	private bool m_bIsChallengeActive;

	// Token: 0x04000415 RID: 1045
	private int m_iTrackImposed;

	// Token: 0x04000416 RID: 1046
	private ChampionShipData m_pChampionshipImposed;

	// Token: 0x04000417 RID: 1047
	private E_TimeTrialMedal m_eMedalImposed;

	// Token: 0x04000418 RID: 1048
	private EChallengeState m_eState;

	// Token: 0x04000419 RID: 1049
	private float m_iTimer;

	// Token: 0x0400041A RID: 1050
	private string m_sReward;

	// Token: 0x0400041B RID: 1051
	private E_RewardType m_eRewardType;

	// Token: 0x0400041C RID: 1052
	private EDifficulty m_eDifficulty;

	// Token: 0x0400041D RID: 1053
	private ERarity m_eRarity;

	// Token: 0x0400041E RID: 1054
	private bool m_bForceInit;

	// Token: 0x0400041F RID: 1055
	private bool m_bForceMonday;

	// Token: 0x04000420 RID: 1056
	private bool m_bSuccesFirstObjective;

	// Token: 0x04000421 RID: 1057
	private bool m_bSuccesSecondObjective;

	// Token: 0x04000422 RID: 1058
	private bool m_bCurrentFailed;
}

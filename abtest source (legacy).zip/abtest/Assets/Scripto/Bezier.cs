﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000244 RID: 580
public class Bezier
{
	// Token: 0x0600102C RID: 4140 RVA: 0x00065EF8 File Offset: 0x000640F8
	public Bezier(IBezierWaypoint[] waypointsArray)
	{
		this.waypointList = new List<IBezierWaypoint>();
		foreach (IBezierWaypoint item in waypointsArray)
		{
			this.waypointList.Add(item);
		}
	}

	// Token: 0x0600102D RID: 4141 RVA: 0x00065F5C File Offset: 0x0006415C
	public void SetUpDistanceLists(bool fullLoop)
	{
		this.distanceArray[0] = 0f;
		this.timeArray[0] = 0f;
		Vector3 a = this.GetPointAtTime(0f, fullLoop);
		Vector3 vector = Vector3.zero;
		float num = 0f;
		for (int i = 1; i < 1000; i++)
		{
			vector = this.GetPointAtTime((float)i * 0.001f, fullLoop);
			num += (a - vector).magnitude;
			this.distanceArray[i] = num;
			this.timeArray[i] = (float)i * 0.001f;
			a = vector;
		}
		this.MaxDistance = num;
	}

	// Token: 0x0600102E RID: 4142 RVA: 0x00065FF8 File Offset: 0x000641F8
	public Vector3 GetPointAtTime(float t, bool fullLoop)
	{
		t %= 1f;
		if (t < 0f)
		{
			t = 1f + t;
		}
		int num;
		if (fullLoop)
		{
			num = this.waypointList.Count;
		}
		else
		{
			num = this.waypointList.Count - 1;
		}
		int num2 = Mathf.FloorToInt(t * (float)num);
		float t2 = t * (float)num - (float)num2;
		Vector3 currentPosition = this.waypointList[this.CheckWithinArray(num2, this.waypointList.Count)].CurrentPosition;
		Vector3 currentPosition2 = this.waypointList[this.CheckWithinArray(num2, this.waypointList.Count)].RightPoint.CurrentPosition;
		Vector3 currentPosition3 = this.waypointList[this.CheckWithinArray(num2 + 1, this.waypointList.Count)].LeftPoint.CurrentPosition;
		Vector3 currentPosition4 = this.waypointList[this.CheckWithinArray(num2 + 1, this.waypointList.Count)].CurrentPosition;
		return this.DoBezierFor4Points(t2, currentPosition, currentPosition2, currentPosition3, currentPosition4);
	}

	// Token: 0x0600102F RID: 4143 RVA: 0x0000CE91 File Offset: 0x0000B091
	private int CheckWithinArray(int x, int c)
	{
		if (x >= c)
		{
			return x % c;
		}
		return x;
	}

	// Token: 0x06001030 RID: 4144 RVA: 0x00066104 File Offset: 0x00064304
	private Vector3 DoBezierFor4Points(float t, Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3)
	{
		Vector3 a = Vector3.zero;
		float d = 1f - t;
		a += p0 * d * d * d;
		a += p1 * t * 3f * d * d;
		a += p2 * 3f * t * t * d;
		return a + p3 * t * t * t;
	}

	// Token: 0x06001031 RID: 4145 RVA: 0x000661A0 File Offset: 0x000643A0
	public float FindTimePointAlongeSplineAtDistance(float distance)
	{
		distance %= this.MaxDistance;
		if (distance < 0f)
		{
			distance = this.MaxDistance + distance;
		}
		float result = 0f;
		for (int i = 0; i < 1000; i++)
		{
			result = this.timeArray[i];
			if (distance < this.distanceArray[i])
			{
				break;
			}
		}
		return result;
	}

	// Token: 0x06001032 RID: 4146 RVA: 0x00066208 File Offset: 0x00064408
	public float LookupDistanceOfExistingTime(float time)
	{
		time %= 1f;
		float result = 0f;
		for (int i = 0; i < 1000; i++)
		{
			result = this.distanceArray[i];
			if (time < this.timeArray[i])
			{
				break;
			}
		}
		return result;
	}

	// Token: 0x04000F83 RID: 3971
	private const int NumberOfArray = 1000;

	// Token: 0x04000F84 RID: 3972
	private const float OneOverNum = 0.001f;

	// Token: 0x04000F85 RID: 3973
	private List<IBezierWaypoint> waypointList;

	// Token: 0x04000F86 RID: 3974
	private Vector3[] vectorArray;

	// Token: 0x04000F87 RID: 3975
	private float[] distanceArray = new float[1000];

	// Token: 0x04000F88 RID: 3976
	private float[] timeArray = new float[1000];

	// Token: 0x04000F89 RID: 3977
	public float MaxDistance;
}

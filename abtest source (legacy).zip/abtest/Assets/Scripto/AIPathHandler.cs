﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020001D5 RID: 469
public class AIPathHandler : MonoBehaviour
{
	// Token: 0x1700019E RID: 414
	// (get) Token: 0x06000C9C RID: 3228 RVA: 0x0000ABF7 File Offset: 0x00008DF7
	protected GkAIManager _AIManager
	{
		get
		{
			return ((InGameGameMode)Singleton<GameManager>.Instance.GameMode).AIManager;
		}
	}

	// Token: 0x06000C9D RID: 3229 RVA: 0x0000AC0D File Offset: 0x00008E0D
	public RcFastValuePath GetLeftBorder(int index)
	{
		return null;
	}

	// Token: 0x06000C9E RID: 3230 RVA: 0x0000AC0D File Offset: 0x00008E0D
	public RcFastValuePath GetRightBorder(int index)
	{
		return null;
	}

	// Token: 0x06000C9F RID: 3231 RVA: 0x00053ECC File Offset: 0x000520CC
	private void CreateIdealPath(GameObject pGameObject, E_PathType pPathType)
	{
		RcFastValuePath rcFastValuePath = new RcFastValuePath(pGameObject);
		rcFastValuePath.PathType = pPathType;
		rcFastValuePath.SetLoop(true);
		switch (pPathType)
		{
		case E_PathType.GOOD:
			this._availableGoodPaths.Add(this._idealGoodPaths.Count);
			this._idealGoodPaths.Add(rcFastValuePath);
			break;
		case E_PathType.AVERAGE:
			this._availableAveragePaths.Add(this._idealAveragePaths.Count);
			this._idealAveragePaths.Add(rcFastValuePath);
			break;
		case E_PathType.BAD:
			this._availableBadPaths.Add(this._idealBadPaths.Count);
			this._idealBadPaths.Add(rcFastValuePath);
			break;
		case E_PathType.SHORTCUT:
			this._shortcutPaths.Add(pGameObject.GetInstanceID(), rcFastValuePath);
			break;
		}
	}

	// Token: 0x06000CA0 RID: 3232 RVA: 0x0000AC10 File Offset: 0x00008E10
	public RcFastPath GetShortcut(int pId)
	{
		return this._shortcutPaths[pId];
	}

	// Token: 0x06000CA1 RID: 3233 RVA: 0x00053F9C File Offset: 0x0005219C
	public int GetPathIndex(RcFastValuePath pPath)
	{
		switch (pPath.PathType)
		{
		case E_PathType.GOOD:
			if (pPath != null)
			{
				return this._idealGoodPaths.IndexOf(pPath);
			}
			return -1;
		case E_PathType.AVERAGE:
			if (pPath != null)
			{
				return this._idealAveragePaths.IndexOf(pPath);
			}
			return -1;
		case E_PathType.BAD:
			if (pPath != null)
			{
				return this._idealBadPaths.IndexOf(pPath);
			}
			return -1;
		default:
			return -1;
		}
	}

	// Token: 0x06000CA2 RID: 3234 RVA: 0x0005400C File Offset: 0x0005220C
	public void SetPathAvailable(RcFastValuePath pPreviousPath)
	{
		switch (pPreviousPath.PathType)
		{
		case E_PathType.GOOD:
			if (pPreviousPath != null)
			{
				int num = this._idealGoodPaths.IndexOf(pPreviousPath);
				if (num >= 0)
				{
					this._availableGoodPaths.Add(num);
				}
			}
			break;
		case E_PathType.AVERAGE:
			if (pPreviousPath != null)
			{
				int num2 = this._idealAveragePaths.IndexOf(pPreviousPath);
				if (num2 >= 0)
				{
					this._availableAveragePaths.Add(num2);
				}
			}
			break;
		case E_PathType.BAD:
			if (pPreviousPath != null)
			{
				int num3 = this._idealBadPaths.IndexOf(pPreviousPath);
				if (num3 >= 0)
				{
					this._availableBadPaths.Add(num3);
				}
			}
			break;
		}
	}

	// Token: 0x06000CA3 RID: 3235 RVA: 0x000540C0 File Offset: 0x000522C0
	public RcFastPath GetPath(E_PathType pPathType, E_AILevel pAILevel)
	{
		switch (pPathType)
		{
		case E_PathType.GOOD:
			if (this._availableGoodPaths.Count > 0)
			{
				int num = this._availableGoodPaths[Singleton<RandomManager>.Instance.Next(this._availableGoodPaths.Count - 1)];
				this._availableGoodPaths.Remove(num);
				return this._idealGoodPaths[num];
			}
			return this.GetPath(E_PathType.AVERAGE, pAILevel);
		case E_PathType.AVERAGE:
			if (this._availableAveragePaths.Count > 0)
			{
				int num2 = this._availableAveragePaths[Singleton<RandomManager>.Instance.Next(this._availableAveragePaths.Count - 1)];
				this._availableAveragePaths.Remove(num2);
				return this._idealAveragePaths[num2];
			}
			if (pAILevel == E_AILevel.GOOD)
			{
				return this.GetPath(E_PathType.GOOD, pAILevel);
			}
			if (pAILevel == E_AILevel.BAD)
			{
				return this.GetPath(E_PathType.BAD, pAILevel);
			}
			if (pAILevel == E_AILevel.AVERAGE)
			{
				EDifficulty difficulty = Singleton<GameConfigurator>.Instance.Difficulty;
				if (difficulty == EDifficulty.EASY)
				{
					return this.GetPath(E_PathType.BAD, pAILevel);
				}
				if (difficulty == EDifficulty.NORMAL)
				{
					return this.GetPath(E_PathType.BAD, pAILevel);
				}
				if (difficulty == EDifficulty.HARD)
				{
					return this.GetPath(E_PathType.GOOD, pAILevel);
				}
			}
			return null;
		case E_PathType.BAD:
			if (this._availableBadPaths.Count > 0)
			{
				int num3 = this._availableBadPaths[Singleton<RandomManager>.Instance.Next(this._availableBadPaths.Count - 1)];
				this._availableBadPaths.Remove(num3);
				return this._idealBadPaths[num3];
			}
			return this.GetPath(E_PathType.AVERAGE, pAILevel);
		default:
			return null;
		}
	}

	// Token: 0x06000CA4 RID: 3236 RVA: 0x0005424C File Offset: 0x0005244C
	public RcFastPath GetFirstPath(E_PathType pPathType)
	{
		switch (pPathType)
		{
		case E_PathType.GOOD:
			if (this._idealGoodPaths.Count > 0)
			{
				return this._idealGoodPaths[0];
			}
			break;
		case E_PathType.AVERAGE:
			if (this._idealAveragePaths.Count > 0)
			{
				return this._idealAveragePaths[0];
			}
			break;
		case E_PathType.BAD:
			if (this._idealBadPaths.Count > 0)
			{
				return this._idealBadPaths[0];
			}
			break;
		}
		return null;
	}

	// Token: 0x06000CA5 RID: 3237 RVA: 0x000542E0 File Offset: 0x000524E0
	protected virtual void StartIdealPath()
	{
		for (int i = 0; i < base.transform.childCount; i++)
		{
			Transform child = base.transform.GetChild(i);
			if (child != null)
			{
				GameObject gameObject = child.gameObject;
				if (gameObject != null)
				{
					PathType component = gameObject.GetComponent<PathType>();
					if (component != null)
					{
						this.CreateIdealPath(gameObject, component.Type);
					}
				}
			}
		}
	}

	// Token: 0x06000CA6 RID: 3238 RVA: 0x00054358 File Offset: 0x00052558
	public virtual void InitIdealPaths(RacingAI pAI, int pIndex)
	{
		E_PathType pathType = this._AIManager.GetPathType(pAI.Level);
		pAI.IdealPath = this.GetPath(pathType, pAI.Level);
	}

	// Token: 0x06000CA7 RID: 3239 RVA: 0x0005438C File Offset: 0x0005258C
	public virtual void Start()
	{
		if (Application.isPlaying)
		{
			this.StartIdealPath();
			this._AIManager.Init(this);
			for (int i = 0; i < 6; i++)
			{
				GameObject player = Singleton<GameManager>.Instance.GameMode.GetPlayer(i);
				if (player != null)
				{
					E_AILevel pLevel = E_AILevel.GOOD;
					if (i == 5)
					{
						pLevel = E_AILevel.BAD;
					}
					else if (i > 2)
					{
						pLevel = E_AILevel.AVERAGE;
					}
					this.RegisterController(player, pLevel);
				}
			}
		}
	}

	// Token: 0x06000CA8 RID: 3240 RVA: 0x00054408 File Offset: 0x00052608
	public void RegisterController(GameObject pPlayer, E_AILevel pLevel)
	{
		RcVirtualController componentInChildren = pPlayer.GetComponentInChildren<RcVirtualController>();
		this._AIManager.RegisterVirtualController(componentInChildren, pLevel);
	}

	// Token: 0x06000CA9 RID: 3241 RVA: 0x0005442C File Offset: 0x0005262C
	public bool UpdatePositionOnPath(RacingAI pAI)
	{
		RcFastPath currentPath = pAI.CurrentPath;
		Vector3 position = pAI.Vehicle.GetPosition();
		PathPosition pathPosition = pAI.PathPosition;
		currentPath.UpdatePathPosition(ref pathPosition, position, 10, 3, false, currentPath.IsLooping());
		bool result = false;
		if (pAI.PathPosition.index != pathPosition.index)
		{
			result = true;
		}
		pAI.PathPosition = pathPosition;
		return result;
	}

	// Token: 0x06000CAA RID: 3242 RVA: 0x0000AC1E File Offset: 0x00008E1E
	public virtual void OnDrawGizmos()
	{
		if (Application.isPlaying && Application.isEditor)
		{
			this._AIManager.DebugDrawGizmos(this.DebugDraw, this.AIDebugIndex);
		}
	}

	// Token: 0x04000C46 RID: 3142
	protected List<RcFastValuePath> _idealGoodPaths = new List<RcFastValuePath>();

	// Token: 0x04000C47 RID: 3143
	protected List<int> _availableGoodPaths = new List<int>();

	// Token: 0x04000C48 RID: 3144
	protected List<RcFastValuePath> _idealAveragePaths = new List<RcFastValuePath>();

	// Token: 0x04000C49 RID: 3145
	protected List<int> _availableAveragePaths = new List<int>();

	// Token: 0x04000C4A RID: 3146
	protected List<RcFastValuePath> _idealBadPaths = new List<RcFastValuePath>();

	// Token: 0x04000C4B RID: 3147
	protected List<int> _availableBadPaths = new List<int>();

	// Token: 0x04000C4C RID: 3148
	protected Dictionary<int, RcFastValuePath> _shortcutPaths = new Dictionary<int, RcFastValuePath>();

	// Token: 0x04000C4D RID: 3149
	public bool DebugDraw;

	// Token: 0x04000C4E RID: 3150
	public int AIDebugIndex = 1;
}

﻿using System;
using UnityEngine;

// Token: 0x0200022F RID: 559
public class DebugRemoveMaterial : MonoBehaviour
{
	// Token: 0x06000FD1 RID: 4049 RVA: 0x0000CB82 File Offset: 0x0000AD82
	public void Start()
	{
		this.RemoveMaterial(base.gameObject);
	}

	// Token: 0x06000FD2 RID: 4050 RVA: 0x000645C8 File Offset: 0x000627C8
	private void RemoveMaterial(GameObject pGameObject)
	{
		if (pGameObject.renderer != null)
		{
			pGameObject.renderer.material = null;
		}
		for (int i = 0; i < pGameObject.transform.childCount; i++)
		{
			this.RemoveMaterial(pGameObject.transform.GetChild(i).gameObject);
		}
	}
}

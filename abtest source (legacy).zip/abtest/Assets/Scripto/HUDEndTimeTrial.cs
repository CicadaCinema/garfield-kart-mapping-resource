﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200010A RID: 266
public class HUDEndTimeTrial : MonoBehaviour
{
	// Token: 0x06000736 RID: 1846 RVA: 0x00035D38 File Offset: 0x00033F38
	public virtual void Awake()
	{
		UnityEngine.Object[] array = Resources.LoadAll("Character", typeof(CharacterCarac));
		foreach (UnityEngine.Object @object in array)
		{
			this.m_oCharacterList.Add((CharacterCarac)@object);
		}
		UnityEngine.Object[] array3 = Resources.LoadAll("Kart", typeof(KartCarac));
		foreach (UnityEngine.Object object2 in array3)
		{
			this.m_oKartList.Add((KartCarac)object2);
		}
		UnityEngine.Object[] array5 = Resources.LoadAll("Kart", typeof(KartCustom));
		foreach (UnityEngine.Object object3 in array5)
		{
			if (object3.name.Contains("_Def"))
			{
				this.m_oKartCustomList.Insert(0, (KartCustom)object3);
			}
			else
			{
				this.m_oKartCustomList.Add((KartCustom)object3);
			}
		}
		int nbPlayers = this.GetNbPlayers();
		for (int l = 0; l < nbPlayers; l++)
		{
			string text = base.gameObject.name + "/Panel/Anchor_Center/Panel" + (l + 1).ToString() + "Place";
			GameObject gameObject = GameObject.Find(text + "/Name");
			this.CharacterName.Add(gameObject.GetComponent<UILabel>());
			GameObject gameObject2 = GameObject.Find(text + "/Time");
			this.RaceTime.Add(gameObject2.GetComponent<UILabel>());
			GameObject item = GameObject.Find(text + "/RecordText");
			this.RecordGO.Add(item);
			GameObject gameObject3 = GameObject.Find(text + "/GuiPersonage");
			this.GuiPerso.Add(gameObject3.GetComponent<UISprite>());
			GameObject gameObject4 = GameObject.Find(text + "/02custom");
			this.m_Custom.Add(gameObject4);
			gameObject4 = GameObject.Find(text + "/02custom/custom");
			this.m_CustomRarity.Add(gameObject4.GetComponent<UITexturePattern>());
			gameObject4 = GameObject.Find(text + "/02custom/customIcon");
			this.m_CustomSprite.Add(gameObject4.GetComponent<UISprite>());
			GameObject gameObject5 = GameObject.Find(text + "/iconpersonage");
			this.m_CharacterGO.Add(gameObject5);
			this.m_Character.Add(gameObject5.GetComponent<UISprite>());
			gameObject5 = GameObject.Find(text + "/kartIcon");
			this.m_KartGO.Add(gameObject5);
			this.m_Kart.Add(gameObject5.GetComponent<UISprite>());
			this.m_Stars.Add(new List<GameObject>());
			for (int m = 0; m < 3; m++)
			{
				string name = text + "/02star" + (m + 1);
				GameObject item2 = GameObject.Find(name);
				this.m_Stars[l].Add(item2);
			}
		}
		GameObject gameObject6 = GameObject.Find(base.gameObject.name + "/Panel/Anchor_Center/LabelTime");
		if (gameObject6)
		{
			this.LapTimes = gameObject6.GetComponent<UILabel>();
		}
		for (int n = 0; n < 3; n++)
		{
			GameObject gameObject7 = GameObject.Find(base.gameObject.name + "/Panel/Anchor_Center/RecordLap" + (n + 1));
			if (gameObject7)
			{
				this.Records.Add(gameObject7);
			}
		}
		this.m_iIndexToFillPlayerData = 0;
		this.m_fElapsedTime = Time.time;
	}

	// Token: 0x06000737 RID: 1847 RVA: 0x000360E8 File Offset: 0x000342E8
	public virtual void FillStats(PlayerData[] pPlayerData)
	{
		this.DifficultySprite.ChangeTexture((int)Singleton<GameConfigurator>.Instance.Difficulty);
		if (Singleton<GameConfigurator>.Instance.ChampionShipData != null)
		{
			this.ChampionshipIcon.ChangeTexture(Singleton<GameConfigurator>.Instance.ChampionShipData.Index);
		}
		if (Singleton<GameConfigurator>.Instance.ChampionShipData != null)
		{
			string arg = Singleton<GameConfigurator>.Instance.ChampionShipData.TracksName[Singleton<GameConfigurator>.Instance.CurrentTrackIndex];
			this.TrackName.text = string.Format(Localization.instance.Get("HUD_DYN_ENDTIMETRIAL_RESULTS"), arg);
		}
		PlayerData playerData = pPlayerData[0];
		if (this.CharacterName != null)
		{
			this.CharacterName[this.m_iIndexToFillPlayerData].text = Singleton<GameSaveManager>.Instance.GetPseudo();
		}
		foreach (CharacterCarac characterCarac in this.m_oCharacterList)
		{
			if (characterCarac.Owner == playerData.Character)
			{
				this.m_Character[this.m_iIndexToFillPlayerData].spriteName = characterCarac.spriteName;
				break;
			}
		}
		foreach (KartCarac kartCarac in this.m_oKartList)
		{
			if (kartCarac.Owner == playerData.Kart)
			{
				this.m_Kart[this.m_iIndexToFillPlayerData].spriteName = kartCarac.spriteName;
				break;
			}
		}
		if (playerData.Custom.Contains("_Def"))
		{
			this.m_Custom[this.m_iIndexToFillPlayerData].SetActive(false);
		}
		else
		{
			this.m_Custom[this.m_iIndexToFillPlayerData].SetActive(true);
			foreach (KartCustom kartCustom in this.m_oKartCustomList)
			{
				if (kartCustom.name == playerData.Custom)
				{
					this.m_CustomSprite[this.m_iIndexToFillPlayerData].spriteName = kartCustom.spriteName;
					this.m_CustomRarity[this.m_iIndexToFillPlayerData].ChangeTexture((int)kartCustom.Rarity);
					break;
				}
			}
		}
		foreach (GameObject gameObject in this.m_Stars[this.m_iIndexToFillPlayerData])
		{
			gameObject.SetActive(false);
		}
		for (int i = 0; i < playerData.NbStars; i++)
		{
			this.m_Stars[this.m_iIndexToFillPlayerData][i].SetActive(true);
		}
		Kart humanKart = Singleton<GameManager>.Instance.GameMode.GetHumanKart();
		RcVehicleRaceStats raceStats = humanKart.RaceStats;
		if (this.RaceTime != null)
		{
			this.RaceTime[this.m_iIndexToFillPlayerData].text = TimeSpan.FromMilliseconds((double)raceStats.GetRaceTime()).FormatRaceTime();
		}
		this.ShowLapTime(raceStats);
		if (LogManager.Instance != null)
		{
			this.m_fElapsedTime = Time.time - this.m_fElapsedTime;
			if (Singleton<GameConfigurator>.Instance.CurrentTrackIndex >= 0 && Singleton<GameConfigurator>.Instance.CurrentTrackIndex < Singleton<GameConfigurator>.Instance.ChampionShipData.TracksName.Length)
			{
				RaceScoreData scoreData = Singleton<GameConfigurator>.Instance.RankingManager.GetScoreData(Singleton<GameManager>.Instance.GameMode.GetHumanPlayerVehicleId());
			}
		}
	}

	// Token: 0x06000738 RID: 1848 RVA: 0x00004C05 File Offset: 0x00002E05
	public virtual int GetNbPlayers()
	{
		return 1;
	}

	// Token: 0x06000739 RID: 1849 RVA: 0x000364E0 File Offset: 0x000346E0
	public virtual void ShowLapTime(RcVehicleRaceStats pStats)
	{
		if (this.LapTimes != null)
		{
			this.LapTimes.text = string.Empty;
			for (int i = 0; i < 3; i++)
			{
				UILabel lapTimes = this.LapTimes;
				string text = lapTimes.text;
				lapTimes.text = string.Concat(new object[]
				{
					text,
					i + 1,
					"- ",
					TimeSpan.FromMilliseconds((double)pStats.GetLapTime(i)).FormatRaceTime()
				});
				if (i < 2)
				{
					UILabel lapTimes2 = this.LapTimes;
					lapTimes2.text += "\n";
				}
			}
		}
		string startScene = Singleton<GameConfigurator>.Instance.StartScene;
		int num = 0;
		Singleton<GameSaveManager>.Instance.GetTimeTrialRecord(startScene, ref num);
		if (pStats.GetRaceTime() < num || num < 0)
		{
			this.RecordGO[0].gameObject.SetActive(true);
		}
		else
		{
			this.RecordGO[0].gameObject.SetActive(false);
		}
		int num2 = 0;
		Singleton<GameSaveManager>.Instance.GetTimeTrialBestTime(startScene, ref num2);
		for (int j = 0; j < 3; j++)
		{
			if (this.Records[j] != null)
			{
				if (pStats.GetLapTime(j) == pStats.GetBestLapTime() && (pStats.GetBestLapTime() < num2 || num2 < 0))
				{
					this.Records[j].gameObject.SetActive(true);
				}
				else
				{
					this.Records[j].gameObject.SetActive(false);
				}
			}
		}
	}

	// Token: 0x0400070B RID: 1803
	protected List<UILabel> CharacterName = new List<UILabel>();

	// Token: 0x0400070C RID: 1804
	protected List<UILabel> RaceTime = new List<UILabel>();

	// Token: 0x0400070D RID: 1805
	protected List<GameObject> RecordGO = new List<GameObject>();

	// Token: 0x0400070E RID: 1806
	protected UILabel LapTimes;

	// Token: 0x0400070F RID: 1807
	public UILabel TrackName;

	// Token: 0x04000710 RID: 1808
	public UITexturePattern DifficultySprite;

	// Token: 0x04000711 RID: 1809
	public UITexturePattern ChampionshipIcon;

	// Token: 0x04000712 RID: 1810
	protected List<GameObject> m_Custom = new List<GameObject>();

	// Token: 0x04000713 RID: 1811
	protected List<UISprite> m_CustomSprite = new List<UISprite>();

	// Token: 0x04000714 RID: 1812
	protected List<UITexturePattern> m_CustomRarity = new List<UITexturePattern>();

	// Token: 0x04000715 RID: 1813
	protected List<UISprite> m_Character = new List<UISprite>();

	// Token: 0x04000716 RID: 1814
	protected List<GameObject> m_CharacterGO = new List<GameObject>();

	// Token: 0x04000717 RID: 1815
	protected List<UISprite> m_Kart = new List<UISprite>();

	// Token: 0x04000718 RID: 1816
	protected List<GameObject> m_KartGO = new List<GameObject>();

	// Token: 0x04000719 RID: 1817
	protected List<List<GameObject>> m_Stars = new List<List<GameObject>>();

	// Token: 0x0400071A RID: 1818
	protected List<CharacterCarac> m_oCharacterList = new List<CharacterCarac>();

	// Token: 0x0400071B RID: 1819
	protected List<KartCarac> m_oKartList = new List<KartCarac>();

	// Token: 0x0400071C RID: 1820
	protected List<KartCustom> m_oKartCustomList = new List<KartCustom>();

	// Token: 0x0400071D RID: 1821
	protected List<GameObject> Records = new List<GameObject>();

	// Token: 0x0400071E RID: 1822
	protected List<UISprite> GuiPerso = new List<UISprite>();

	// Token: 0x0400071F RID: 1823
	protected int m_iIndexToFillPlayerData;

	// Token: 0x04000720 RID: 1824
	private float m_fElapsedTime;
}

﻿using System;
using UnityEngine;

// Token: 0x02000053 RID: 83
public class UIGeometry
{
	// Token: 0x17000040 RID: 64
	// (get) Token: 0x06000218 RID: 536 RVA: 0x0000388A File Offset: 0x00001A8A
	public bool hasVertices
	{
		get
		{
			return this.verts.size > 0;
		}
	}

	// Token: 0x17000041 RID: 65
	// (get) Token: 0x06000219 RID: 537 RVA: 0x0000389A File Offset: 0x00001A9A
	public bool hasTransformed
	{
		get
		{
			return this.mRtpVerts != null && this.mRtpVerts.size > 0 && this.mRtpVerts.size == this.verts.size;
		}
	}

	// Token: 0x0600021A RID: 538 RVA: 0x000038D3 File Offset: 0x00001AD3
	public void Clear()
	{
		this.verts.Clear();
		this.uvs.Clear();
		this.cols.Clear();
		this.mRtpVerts.Clear();
	}

	// Token: 0x0600021B RID: 539 RVA: 0x000172D8 File Offset: 0x000154D8
	public void ApplyOffset(Vector3 pivotOffset)
	{
		for (int i = 0; i < this.verts.size; i++)
		{
			this.verts.buffer[i] += pivotOffset;
		}
	}

	// Token: 0x0600021C RID: 540 RVA: 0x00017324 File Offset: 0x00015524
	public void ApplyTransform(Matrix4x4 widgetToPanel, bool normals)
	{
		if (this.verts.size > 0)
		{
			this.mRtpVerts.Clear();
			int i = 0;
			int size = this.verts.size;
			while (i < size)
			{
				this.mRtpVerts.Add(widgetToPanel.MultiplyPoint3x4(this.verts[i]));
				i++;
			}
			this.mRtpNormal = widgetToPanel.MultiplyVector(Vector3.back).normalized;
			Vector3 normalized = widgetToPanel.MultiplyVector(Vector3.right).normalized;
			this.mRtpTan = new Vector4(normalized.x, normalized.y, normalized.z, -1f);
		}
		else
		{
			this.mRtpVerts.Clear();
		}
	}

	// Token: 0x0600021D RID: 541 RVA: 0x000173F0 File Offset: 0x000155F0
	public void WriteToBuffers(BetterList<Vector3> v, BetterList<Vector2> u, BetterList<Color32> c, BetterList<Vector3> n, BetterList<Vector4> t)
	{
		if (this.mRtpVerts != null && this.mRtpVerts.size > 0)
		{
			if (n == null)
			{
				for (int i = 0; i < this.mRtpVerts.size; i++)
				{
					v.Add(this.mRtpVerts.buffer[i]);
					u.Add(this.uvs.buffer[i]);
					c.Add(this.cols.buffer[i]);
				}
			}
			else
			{
				for (int j = 0; j < this.mRtpVerts.size; j++)
				{
					v.Add(this.mRtpVerts.buffer[j]);
					u.Add(this.uvs.buffer[j]);
					c.Add(this.cols.buffer[j]);
					n.Add(this.mRtpNormal);
					t.Add(this.mRtpTan);
				}
			}
		}
	}

	// Token: 0x040001B1 RID: 433
	public BetterList<Vector3> verts = new BetterList<Vector3>();

	// Token: 0x040001B2 RID: 434
	public BetterList<Vector2> uvs = new BetterList<Vector2>();

	// Token: 0x040001B3 RID: 435
	public BetterList<Color32> cols = new BetterList<Color32>();

	// Token: 0x040001B4 RID: 436
	private BetterList<Vector3> mRtpVerts = new BetterList<Vector3>();

	// Token: 0x040001B5 RID: 437
	private Vector3 mRtpNormal;

	// Token: 0x040001B6 RID: 438
	private Vector4 mRtpTan;
}

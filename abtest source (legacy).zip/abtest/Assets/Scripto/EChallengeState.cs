﻿using System;

// Token: 0x020000AC RID: 172
public enum EChallengeState
{
	// Token: 0x040003FD RID: 1021
	NotPlayed,
	// Token: 0x040003FE RID: 1022
	Failed,
	// Token: 0x040003FF RID: 1023
	Succeeded
}

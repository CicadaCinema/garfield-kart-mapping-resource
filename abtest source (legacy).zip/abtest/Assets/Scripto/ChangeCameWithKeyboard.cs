﻿using System;
using UnityEngine;

// Token: 0x0200026B RID: 619
public class ChangeCameWithKeyboard : MonoBehaviour
{
	// Token: 0x060010F5 RID: 4341 RVA: 0x000682F8 File Offset: 0x000664F8
	private void Start()
	{
		this.camera1.camera.enabled = true;
		this.camera2.camera.enabled = false;
		this.camera3.camera.enabled = false;
		this.camera4.camera.enabled = false;
		this.camera5.camera.enabled = false;
		this.camera6.camera.enabled = false;
		this.camera7.camera.enabled = false;
		this.camera8.camera.enabled = false;
		this.camera9.camera.enabled = false;
		this.camera10.camera.enabled = false;
		this.Kart1.SetActive(true);
		this.Kart2.SetActive(false);
		this.Kart3.SetActive(false);
		this.Kart4.SetActive(false);
		this.Kart5.SetActive(false);
		this.Kart6.SetActive(false);
		this.Kart7.SetActive(false);
		this.Kart8.SetActive(false);
		this.Kart9.SetActive(false);
		this.Kart10.SetActive(false);
	}

	// Token: 0x060010F6 RID: 4342 RVA: 0x00068428 File Offset: 0x00066628
	private void Update()
	{
		if (Input.GetKey(KeyCode.Alpha1))
		{
			this.camera1.camera.enabled = true;
			this.camera2.camera.enabled = false;
			this.camera3.camera.enabled = false;
			this.camera4.camera.enabled = false;
			this.camera5.camera.enabled = false;
			this.camera6.camera.enabled = false;
			this.camera7.camera.enabled = false;
			this.camera8.camera.enabled = false;
			this.camera9.camera.enabled = false;
			this.camera10.camera.enabled = false;
			this.Kart1.SetActive(true);
			this.Kart2.SetActive(false);
			this.Kart3.SetActive(false);
			this.Kart4.SetActive(false);
			this.Kart5.SetActive(false);
			this.Kart6.SetActive(false);
			this.Kart7.SetActive(false);
			this.Kart8.SetActive(false);
			this.Kart9.SetActive(false);
			this.Kart10.SetActive(false);
		}
		if (Input.GetKey(KeyCode.Alpha2))
		{
			this.camera1.camera.enabled = false;
			this.camera2.camera.enabled = true;
			this.camera3.camera.enabled = false;
			this.camera4.camera.enabled = false;
			this.camera5.camera.enabled = false;
			this.camera6.camera.enabled = false;
			this.camera7.camera.enabled = false;
			this.camera8.camera.enabled = false;
			this.camera9.camera.enabled = false;
			this.camera10.camera.enabled = false;
			this.Kart1.SetActive(false);
			this.Kart2.SetActive(true);
			this.Kart3.SetActive(false);
			this.Kart4.SetActive(false);
			this.Kart5.SetActive(false);
			this.Kart6.SetActive(false);
			this.Kart7.SetActive(false);
			this.Kart8.SetActive(false);
			this.Kart9.SetActive(false);
			this.Kart10.SetActive(false);
		}
		if (Input.GetKey(KeyCode.Alpha3))
		{
			this.camera1.camera.enabled = false;
			this.camera2.camera.enabled = false;
			this.camera3.camera.enabled = true;
			this.camera4.camera.enabled = false;
			this.camera5.camera.enabled = false;
			this.camera6.camera.enabled = false;
			this.camera7.camera.enabled = false;
			this.camera8.camera.enabled = false;
			this.camera9.camera.enabled = false;
			this.camera10.camera.enabled = false;
			this.Kart1.SetActive(false);
			this.Kart2.SetActive(false);
			this.Kart3.SetActive(true);
			this.Kart4.SetActive(false);
			this.Kart5.SetActive(false);
			this.Kart6.SetActive(false);
			this.Kart7.SetActive(false);
			this.Kart8.SetActive(false);
			this.Kart9.SetActive(false);
			this.Kart10.SetActive(false);
		}
		if (Input.GetKey(KeyCode.Alpha4))
		{
			this.camera1.camera.enabled = false;
			this.camera2.camera.enabled = false;
			this.camera3.camera.enabled = false;
			this.camera4.camera.enabled = true;
			this.camera5.camera.enabled = false;
			this.camera6.camera.enabled = false;
			this.camera7.camera.enabled = false;
			this.camera8.camera.enabled = false;
			this.camera9.camera.enabled = false;
			this.camera10.camera.enabled = false;
			this.Kart1.SetActive(false);
			this.Kart2.SetActive(false);
			this.Kart3.SetActive(false);
			this.Kart4.SetActive(true);
			this.Kart5.SetActive(false);
			this.Kart6.SetActive(false);
			this.Kart7.SetActive(false);
			this.Kart8.SetActive(false);
			this.Kart9.SetActive(false);
			this.Kart10.SetActive(false);
		}
		if (Input.GetKey(KeyCode.Alpha5))
		{
			this.camera1.camera.enabled = false;
			this.camera2.camera.enabled = false;
			this.camera3.camera.enabled = false;
			this.camera4.camera.enabled = false;
			this.camera5.camera.enabled = true;
			this.camera6.camera.enabled = false;
			this.camera7.camera.enabled = false;
			this.camera8.camera.enabled = false;
			this.camera9.camera.enabled = false;
			this.camera10.camera.enabled = false;
			this.Kart1.SetActive(false);
			this.Kart2.SetActive(false);
			this.Kart3.SetActive(false);
			this.Kart4.SetActive(false);
			this.Kart5.SetActive(true);
			this.Kart6.SetActive(false);
			this.Kart7.SetActive(false);
			this.Kart8.SetActive(false);
			this.Kart9.SetActive(false);
			this.Kart10.SetActive(false);
		}
		if (Input.GetKey(KeyCode.Alpha6))
		{
			this.camera1.camera.enabled = false;
			this.camera2.camera.enabled = false;
			this.camera3.camera.enabled = false;
			this.camera4.camera.enabled = false;
			this.camera5.camera.enabled = false;
			this.camera6.camera.enabled = true;
			this.camera7.camera.enabled = false;
			this.camera8.camera.enabled = false;
			this.camera9.camera.enabled = false;
			this.camera10.camera.enabled = false;
			this.Kart1.SetActive(false);
			this.Kart2.SetActive(false);
			this.Kart3.SetActive(false);
			this.Kart4.SetActive(false);
			this.Kart5.SetActive(false);
			this.Kart6.SetActive(true);
			this.Kart7.SetActive(false);
			this.Kart8.SetActive(false);
			this.Kart9.SetActive(false);
			this.Kart10.SetActive(false);
		}
		if (Input.GetKey(KeyCode.Alpha7))
		{
			this.camera1.camera.enabled = false;
			this.camera2.camera.enabled = false;
			this.camera3.camera.enabled = false;
			this.camera4.camera.enabled = false;
			this.camera5.camera.enabled = false;
			this.camera6.camera.enabled = false;
			this.camera7.camera.enabled = true;
			this.camera8.camera.enabled = false;
			this.camera9.camera.enabled = false;
			this.camera10.camera.enabled = false;
			this.Kart1.SetActive(false);
			this.Kart2.SetActive(false);
			this.Kart3.SetActive(false);
			this.Kart4.SetActive(false);
			this.Kart5.SetActive(false);
			this.Kart6.SetActive(false);
			this.Kart7.SetActive(true);
			this.Kart8.SetActive(false);
			this.Kart9.SetActive(false);
			this.Kart10.SetActive(false);
		}
		if (Input.GetKey(KeyCode.Alpha8))
		{
			this.camera1.camera.enabled = false;
			this.camera2.camera.enabled = false;
			this.camera3.camera.enabled = false;
			this.camera4.camera.enabled = false;
			this.camera5.camera.enabled = false;
			this.camera6.camera.enabled = false;
			this.camera7.camera.enabled = false;
			this.camera8.camera.enabled = true;
			this.camera9.camera.enabled = false;
			this.camera10.camera.enabled = false;
			this.Kart1.SetActive(false);
			this.Kart2.SetActive(false);
			this.Kart3.SetActive(false);
			this.Kart4.SetActive(false);
			this.Kart5.SetActive(false);
			this.Kart6.SetActive(false);
			this.Kart7.SetActive(false);
			this.Kart8.SetActive(true);
			this.Kart9.SetActive(false);
			this.Kart10.SetActive(false);
		}
		if (Input.GetKey(KeyCode.Alpha9))
		{
			this.camera1.camera.enabled = false;
			this.camera2.camera.enabled = false;
			this.camera3.camera.enabled = false;
			this.camera4.camera.enabled = false;
			this.camera5.camera.enabled = false;
			this.camera6.camera.enabled = false;
			this.camera7.camera.enabled = false;
			this.camera8.camera.enabled = false;
			this.camera9.camera.enabled = true;
			this.camera10.camera.enabled = false;
			this.Kart1.SetActive(false);
			this.Kart2.SetActive(false);
			this.Kart3.SetActive(false);
			this.Kart4.SetActive(false);
			this.Kart5.SetActive(false);
			this.Kart6.SetActive(false);
			this.Kart7.SetActive(false);
			this.Kart8.SetActive(false);
			this.Kart9.SetActive(true);
			this.Kart10.SetActive(false);
		}
		if (Input.GetKey(KeyCode.Alpha0))
		{
			this.camera1.camera.enabled = false;
			this.camera2.camera.enabled = false;
			this.camera3.camera.enabled = false;
			this.camera4.camera.enabled = false;
			this.camera5.camera.enabled = false;
			this.camera6.camera.enabled = false;
			this.camera7.camera.enabled = false;
			this.camera8.camera.enabled = false;
			this.camera9.camera.enabled = false;
			this.camera10.camera.enabled = true;
			this.Kart1.SetActive(false);
			this.Kart2.SetActive(false);
			this.Kart3.SetActive(false);
			this.Kart4.SetActive(false);
			this.Kart5.SetActive(false);
			this.Kart6.SetActive(false);
			this.Kart7.SetActive(false);
			this.Kart8.SetActive(false);
			this.Kart9.SetActive(false);
			this.Kart10.SetActive(true);
		}
	}

	// Token: 0x0400100A RID: 4106
	public Camera camera1;

	// Token: 0x0400100B RID: 4107
	public Camera camera2;

	// Token: 0x0400100C RID: 4108
	public Camera camera3;

	// Token: 0x0400100D RID: 4109
	public Camera camera4;

	// Token: 0x0400100E RID: 4110
	public Camera camera5;

	// Token: 0x0400100F RID: 4111
	public Camera camera6;

	// Token: 0x04001010 RID: 4112
	public Camera camera7;

	// Token: 0x04001011 RID: 4113
	public Camera camera8;

	// Token: 0x04001012 RID: 4114
	public Camera camera9;

	// Token: 0x04001013 RID: 4115
	public Camera camera10;

	// Token: 0x04001014 RID: 4116
	public GameObject Kart1;

	// Token: 0x04001015 RID: 4117
	public GameObject Kart2;

	// Token: 0x04001016 RID: 4118
	public GameObject Kart3;

	// Token: 0x04001017 RID: 4119
	public GameObject Kart4;

	// Token: 0x04001018 RID: 4120
	public GameObject Kart5;

	// Token: 0x04001019 RID: 4121
	public GameObject Kart6;

	// Token: 0x0400101A RID: 4122
	public GameObject Kart7;

	// Token: 0x0400101B RID: 4123
	public GameObject Kart8;

	// Token: 0x0400101C RID: 4124
	public GameObject Kart9;

	// Token: 0x0400101D RID: 4125
	public GameObject Kart10;
}

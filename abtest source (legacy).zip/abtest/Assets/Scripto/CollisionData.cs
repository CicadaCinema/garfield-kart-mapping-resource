﻿using System;
using UnityEngine;

// Token: 0x02000228 RID: 552
public struct CollisionData
{
	// Token: 0x06000F8B RID: 3979 RVA: 0x0000C954 File Offset: 0x0000AB54
	public void Reset()
	{
		this.solid = null;
		this.other = null;
		this.position = Vector3.zero;
		this.normal = Vector3.zero;
		this.depth = 0f;
		this.surface = 0;
	}

	// Token: 0x04000F19 RID: 3865
	public Rigidbody solid;

	// Token: 0x04000F1A RID: 3866
	public Rigidbody other;

	// Token: 0x04000F1B RID: 3867
	public Vector3 position;

	// Token: 0x04000F1C RID: 3868
	public Vector3 normal;

	// Token: 0x04000F1D RID: 3869
	public float depth;

	// Token: 0x04000F1E RID: 3870
	public int surface;
}

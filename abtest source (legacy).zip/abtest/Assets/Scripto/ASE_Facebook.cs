﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

// Token: 0x02000266 RID: 614
public class ASE_Facebook : MonoBehaviour
{
	// Token: 0x060010C0 RID: 4288
	[DllImport("__Internal")]
	private static extern void ASE_FacebookConnect(string appId);

	// Token: 0x060010C1 RID: 4289 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void Connect(string appId)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010C2 RID: 4290
	[DllImport("__Internal")]
	private static extern bool ASE_FacebookIsConnected();

	// Token: 0x060010C3 RID: 4291 RVA: 0x0000D301 File Offset: 0x0000B501
	public static bool IsConnected()
	{
		if (ASE_Tools.Available)
		{
		}
		return false;
	}

	// Token: 0x060010C4 RID: 4292
	[DllImport("__Internal")]
	private static extern void ASE_FacebookLogin();

	// Token: 0x060010C5 RID: 4293 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void Login()
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010C6 RID: 4294
	[DllImport("__Internal")]
	private static extern void ASE_FacebookLogout();

	// Token: 0x060010C7 RID: 4295 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void Logout()
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010C8 RID: 4296
	[DllImport("__Internal")]
	private static extern int ASE_FacebookGetUserId();

	// Token: 0x060010C9 RID: 4297 RVA: 0x0000D30E File Offset: 0x0000B50E
	public static string GetUserId()
	{
		if (ASE_Tools.Available)
		{
		}
		return string.Empty;
	}

	// Token: 0x060010CA RID: 4298
	[DllImport("__Internal")]
	private static extern int ASE_FacebookGetUserName();

	// Token: 0x060010CB RID: 4299 RVA: 0x0000D30E File Offset: 0x0000B50E
	public static string GetUserName()
	{
		if (ASE_Tools.Available)
		{
		}
		return string.Empty;
	}

	// Token: 0x060010CC RID: 4300
	[DllImport("__Internal")]
	private static extern void ASE_FacebookPublish(string name, string caption, string description, string link, string icon);

	// Token: 0x060010CD RID: 4301 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void Publish(string name, string caption, string description, string link, string icon)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010CE RID: 4302
	[DllImport("__Internal")]
	private static extern void ASE_FacebookSetGameObjectName(string sGameObjectName);

	// Token: 0x060010CF RID: 4303
	[DllImport("__Internal")]
	private static extern void ASE_FacebookSetMethodName(string sMethodName);

	// Token: 0x060010D0 RID: 4304 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetGameObjectName(string sGameObjectName)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010D1 RID: 4305 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetMethodName(string sMethodName)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x060010D2 RID: 4306 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
	public static void SetCallbackInformations(string sGameObjectName, string sMethodName)
	{
		if (ASE_Tools.Available)
		{
		}
	}

	// Token: 0x02000267 RID: 615
	public enum FacebookEvent
	{
		// Token: 0x04000FF4 RID: 4084
		FBEVENT_PUBLICATION_DID_SHARED,
		// Token: 0x04000FF5 RID: 4085
		FBEVENT_PUBLICATION_DID_CANCELED
	}
}

﻿using System;
using UnityEngine;

// Token: 0x02000225 RID: 549
public struct RcWheelStats
{
	// Token: 0x04000EFF RID: 3839
	public float fCompression;

	// Token: 0x04000F00 RID: 3840
	public float fAnchorSpeed;

	// Token: 0x04000F01 RID: 3841
	public float fRestHeight;

	// Token: 0x04000F02 RID: 3842
	public float fGroundHeight;

	// Token: 0x04000F03 RID: 3843
	public Vector3 vGroundNormal;

	// Token: 0x04000F04 RID: 3844
	public int iSurface;

	// Token: 0x04000F05 RID: 3845
	public bool bOnGround;
}

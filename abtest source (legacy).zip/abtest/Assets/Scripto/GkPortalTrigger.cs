﻿using System;
using UnityEngine;

// Token: 0x0200013C RID: 316
public class GkPortalTrigger : RcPortalTrigger
{
	// Token: 0x060008BB RID: 2235 RVA: 0x0003F39C File Offset: 0x0003D59C
	public override void OnTriggerEnter(Collider other)
	{
		base.OnTriggerEnter(other);
		if (!base.enabled)
		{
			return;
		}
		if (this.m_eTriggerSide == RcPortalTrigger.PortalSide.None)
		{
			return;
		}
		TimeTrialUFO componentInChildren = other.gameObject.GetComponentInChildren<TimeTrialUFO>();
		if (componentInChildren == null)
		{
			return;
		}
		if (this.m_eActionType == RcPortalTrigger.PortalAction.StartLine)
		{
			componentInChildren.CrossStartLine();
		}
	}
}

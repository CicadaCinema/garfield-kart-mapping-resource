﻿using System;

// Token: 0x020000F9 RID: 249
public enum ERarity
{
	// Token: 0x040006B0 RID: 1712
	Base = 1,
	// Token: 0x040006B1 RID: 1713
	Rare,
	// Token: 0x040006B2 RID: 1714
	Unique = 4
}

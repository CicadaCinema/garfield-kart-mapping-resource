﻿using System;
using UnityEngine;

// Token: 0x02000120 RID: 288
public class MenuOption : AbstractMenu
{
	// Token: 0x060007F4 RID: 2036 RVA: 0x0003C724 File Offset: 0x0003A924
	public override void OnEnter()
	{
		base.OnEnter();
		if (this.m_oIconLanguage)
		{
			this.m_oIconLanguage.ChangeTexture((int)Singleton<GameOptionManager>.Instance.GetCurrentLangId());
		}
		if (this.Controls && Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
		{
			this.Controls.SetActive(false);
		}
		if (this.Languages)
		{
			if (Localization.instance.languages.Length > 1)
			{
				this.Languages.SetActive(true);
			}
			else
			{
				this.Languages.SetActive(false);
			}
		}
	}

	// Token: 0x04000829 RID: 2089
	public UITexturePattern m_oIconLanguage;

	// Token: 0x0400082A RID: 2090
	public GameObject Controls;

	// Token: 0x0400082B RID: 2091
	public GameObject Languages;
}
